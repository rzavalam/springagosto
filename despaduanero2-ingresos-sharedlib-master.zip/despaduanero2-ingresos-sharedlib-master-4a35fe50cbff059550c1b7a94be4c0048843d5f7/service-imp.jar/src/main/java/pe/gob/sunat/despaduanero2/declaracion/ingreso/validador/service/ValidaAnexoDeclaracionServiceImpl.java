/*
 * Clase que define el servicio de validaciones de 
 * se modifico en el Pase 580
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.TIPO_PAGO_GARANTIA; //RIN10

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero.despacho.model.dao.NotiDudaCabDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.Cambio1;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.DataCatalogoDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.LogRegiService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.CabDeuda;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;//P46
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetPagodua;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeudaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetPagoDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;//P46
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.recauda2.garantia.model.dao.CabCtaCteGarDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.MovNGarantiaDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.CabDocliq;
import pe.gob.sunat.recauda2.genadeudo.model.Detaliq;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.model.MovCalctributo;
import pe.gob.sunat.recauda2.genadeudo.model.dao.CabDocliqDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.DetaliqDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.MovCabliqdiligDAO;
import pe.gob.sunat.recauda2.genadeudo.service.DeudaDeclaracionService;//P46
import pe.gob.sunat.recauda2.genadeudo.service.FuncionesLiquidacionService;	//PAS20175E220200077 - mtorralba 20170623
import pe.gob.sunat.recauda2.genadeudo.service.ImputacionService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionPecoAmazoniaService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.recauda2.util.Constantes;
import pe.gob.sunat.servicio2.registro.model.dao.DdpDAO;
//import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;//gmontoya PASE21065E2202XXXXX


/**
 * Realiza validaciones adicionales sobre la declaracion
 * 
 * @author rcalla
 * se modifico en el Pase 580
 */
//implements ValidaAnexoDeclaracionService 
//FJP 26/05/2011 
//se comentaron variables que no se usan
//se agrego el codigo de la aduana en algunos metodos 
// para la correcta seleccion del catalogo de tributos diferenciales (chimbote)
public class ValidaAnexoDeclaracionServiceImpl extends ValDuaAbstract implements ValidaAnexoDeclaracionService {

	//private DdpDAOService ddpDAOService;
	//GeneraLiquidacionService generaLiquidacionService;
	//private FabricaDeServicios fabricaDeServicios; 
	
	//LogRegiService logRegiService;
	
	//private AyudaService ayudaService;
	/*
	public LogRegiService getLogRegiService() {
		return logRegiService;
	}

	public void setLogRegiService(LogRegiService logRegiService) {
		this.logRegiService = logRegiService;
	}*/

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#setCalculoAdeudoService(pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GeneraLiquidacionService)
	 */
	/*
	@Override
	public void setCalculoAdeudoService(GeneraLiquidacionService generaLiquidacionService) {
		this.generaLiquidacionService = generaLiquidacionService;
	}*/
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#calculaLiquidacion(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer)
	 */
	@Override
	public Map<String, String> calculaLiquidacion(
			Declaracion declaracion,
			String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender, 
			String numOrden,
			String codUsuario, 
			String codTransaccion, 
			Integer nroErroresNegocio,
			Map variablesIngreso) {

		if (nroErroresNegocio==0) {
			GeneraLiquidacionService generaLiquidacionService = (GeneraLiquidacionService)fabricaDeServicios.getService("generaLiquidacionService");
			Map retorna = generaLiquidacionService.obtenerLiquidacion(declaracion,codTransaccion, numOrden,
					codUsuario, tipoDocumentoIdentidadSender,
					numeroDocumentoIdentidadSender);
			//RIN05 20141127 ya no va
//			if( retorna.get("MontoTPI100") != null ) {
//				variablesIngreso.put("MontoTPI100", retorna.get("MontoTPI100"));
//			}
			//jenciso RIN05 Inicio
			if( retorna.get("montoTPILC15_NO_9") != null ) {
				variablesIngreso.put("montoTPILC15_NO_9", retorna.get("montoTPILC15_NO_9"));
			}
			if( retorna.get("montoTPILC15_SI_9") != null ) {
				variablesIngreso.put("montoTPILC15_SI_9", retorna.get("montoTPILC15_SI_9"));
			}
			//jenciso RIN05 Fin

			//INICIO RIN08 - Para generar LC 0006 - PECO-Amazonia
			if( retorna.get("MontoLC0006") != null ) {
				variablesIngreso.put("MontoLC0006", retorna.get("MontoLC0006"));
			}
			//FIN RIN08 
		}

		return new HashMap<String, String>();
	}
	

	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#separaGarantia(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.util.Map, java.lang.String)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Map<String, ?>> separaGarantia(Declaracion declaracion,
			String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender, 
			String numOrden,
			String codUsuario,
			Integer nroErroresNegocio,
			Map<String, Object> variablesIngreso, 
			String codTransaccion){
		String tipoDesp 		= (String) variablesIngreso.get("tipoDesp");
		
	     
		//ResponseListManager responseList = new ResponseListManager();
		BigDecimal montoTributoTotalDolares = new BigDecimal(0);
		BigDecimal montoTributoTotalPercepcion = new BigDecimal(0);
		BigDecimal montoTributoTotalISCSoles = new BigDecimal(0);
		BigDecimal montoTributoTotalPercepcionDolares = new BigDecimal(0);
		BigDecimal montoTributoTotalISCSolesDolares = new BigDecimal(0);
		BigDecimal montoAcumuladoDolares = new BigDecimal(0);
		BigDecimal montoValorProvisional = new BigDecimal(0);
		
//INICIO RIN 08 PECO-Amazonia
		BigDecimal montoTributoPECOAmazoniaDolares = new BigDecimal(0); 
//FIN RIN 08 PECO-Amazonia		
		//Map<String, Object> cabDuaBD = new HashMap<String, Object>();
		//Map<String,Object> param=new HashMap<String,Object>();
		Map<String,Object> mapCambio1=new HashMap<String,Object>();
		List<Map<String,?>> resultadoError = new ArrayList<Map<String,?>>();
		String resultado="";
		String codErr="";
		int posFinalError=0;
		int posInicialError=0;
		
		DatoPago pago=declaracion.getDua().getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		String codGarantia=decla!=null?decla.getCodgarantia():null;		
		String codTipoPago=decla!=null?decla.getCodtipopago():null;
		String regimen=declaracion.getDua().getCodregimen();
		
		HashMap mapGarantia = new HashMap();
		
		
		if (nroErroresNegocio==0){
			if (SunatStringUtils.isEmpty(codGarantia) || SunatStringUtils.isEmpty(codTipoPago) ){
				return resultadoError;
			}
			if ( SunatStringUtils.include(regimen,new String[]{"20","21"})){
				if (! SunatStringUtils.isEmpty(codGarantia) && ! SunatStringUtils.isEmpty(codTipoPago)  ){// tiene una garantia 160
					if (!"G".equals(codTipoPago)){
						//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30355",""));
						 resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30355",new String[]{""}));
						 return resultadoError;
					}
				}
				if ("P".equals(codTipoPago)){
					//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30355",""));
					resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30355",new String[]{""}));
					 return resultadoError;
				}
			}
		    if ("G".equals(codTipoPago) && SunatStringUtils.isEmpty(codGarantia)){
		    	// error 30359
		    	//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30359",""));
		    	resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30359",new String[]{""}));
				 return resultadoError;
		    }
			
			Map<String,?> mpCalculoDiferencial = new HashMap();
			GeneraLiquidacionService generaLiquidacionService = (GeneraLiquidacionService)fabricaDeServicios.getService("generaLiquidacionService");
			//PARA EER buscamos con el regimen dc la liquidacion
			if(ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER.equals(codTransaccion) || ConstantesDataCatalogo.TRANSACCION_NUMERACION_DSEER_DESDE_MDEER.equals(codTransaccion)){
				declaracion.getDua().setCodregimen(ConstantesDataCatalogo.REG_IMPO_COURIER_EER);
			}
			mpCalculoDiferencial = generaLiquidacionService.obtenerDiferenciaTributaria(declaracion, codTransaccion,numOrden, codUsuario, tipoDocumentoIdentidadSender, numeroDocumentoIdentidadSender);
			variablesIngreso.put("mpCalculoDiferencial", mpCalculoDiferencial);
			//volvemos a poner el regimen de eer 28 para otras operaciones
			if(ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER.equals(codTransaccion) || ConstantesDataCatalogo.TRANSACCION_NUMERACION_DSEER_DESDE_MDEER.equals(codTransaccion)){
				declaracion.getDua().setCodregimen(ConstantesDataCatalogo.REGIMEN_EER);
			}

			if (CollectionUtils.isEmpty(mpCalculoDiferencial) || mpCalculoDiferencial.containsKey("ERROR")){
				//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30397",""));
				resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30397",new String[]{""}));
				return resultadoError;
			}
			if(!CollectionUtils.isEmpty(mpCalculoDiferencial) && !mpCalculoDiferencial.containsKey("ERROR")){
				
				//INICIO RIN08 - PECO-Amazonia - Si existe un monto a devolver por concepto de PECO-Amazonia se suma al monto total
				//						   De esta manera consideramos el monto de la LC 0006 a generarse posteriormente en la grabacion.
				montoTributoPECOAmazoniaDolares = (BigDecimal) mpCalculoDiferencial.get("MTO_TOTAL_DEV");
				//System.out.println("Monto adicional por PECO-Amazonia a afectar Temporal: " + montoTributoPECOAmazoniaDolares.toString());
				if (montoTributoPECOAmazoniaDolares.compareTo(BigDecimal.ZERO) != 0) {
					montoAcumuladoDolares = montoTributoPECOAmazoniaDolares;
				}
				//Fin RIN08
				
				// Tributos en dólares
				montoTributoTotalDolares = (BigDecimal) mpCalculoDiferencial.get("MTO_TOTAL");
				
				//RIN 08 - Rechaza siempre y cuando no se trate de una DUA con PECO-Amazonia
				//20121227 MATC - No puede garantizar DUAs con monto cero
				//if (montoTributoTotalDolares.compareTo(BigDecimal.ZERO) == 0) {
				if (montoTributoTotalDolares.compareTo(BigDecimal.ZERO) == 0 && montoTributoPECOAmazoniaDolares.compareTo(BigDecimal.ZERO) == 0) { //RIN 08 agrega &&...
					//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30558",""));
					resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30558",new String[]{""}));
					return resultadoError;	
				}
				// Percepción
				montoTributoTotalPercepcion = (BigDecimal) mpCalculoDiferencial.get("MPERCEP");
				// ISC en soles
				BigDecimal iscSoles = mpCalculoDiferencial.get("MSISC")==null?BigDecimal.ZERO:(BigDecimal) mpCalculoDiferencial.get("MSISC");
				BigDecimal igvSoles = mpCalculoDiferencial.get("MSIGV")==null?BigDecimal.ZERO:(BigDecimal) mpCalculoDiferencial.get("MSIGV");
				BigDecimal ipmSoles = mpCalculoDiferencial.get("MSIPM")==null?BigDecimal.ZERO:(BigDecimal) mpCalculoDiferencial.get("MSIPM");
				montoTributoTotalISCSoles = iscSoles.add(igvSoles).add(ipmSoles);
				// Obteniendo el total en dólares
				Integer fecIngreso= SunatDateUtils.getIntegerFromDate((Date) mpCalculoDiferencial.get("FEC_NUMDOCLIQ"));
				mapCambio1.put("fingreso",fecIngreso);
				mapCambio1.put("cmoneda", "USD");
//				Cambio1 cambio1=NumeracionServiceImpl.getInstance().getCambio1DAO().findByPK(mapCambio1);
				mapCambio1.put("ayudaID", "Cambio1");
				//Cambio1 cambio1 = (Cambio1)ayudaService.buscarObject(mapCambio1);
				Cambio1 cambio1 = (Cambio1)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).buscarObject(mapCambio1);
				if (montoTributoTotalPercepcion.compareTo(BigDecimal.ZERO)>0) {
					montoTributoTotalPercepcionDolares = montoTributoTotalPercepcion.divide(cambio1.getPventa(), 0, BigDecimal.ROUND_HALF_DOWN);
				}
				if (montoTributoTotalISCSoles.compareTo(BigDecimal.ZERO)>0) {
					montoTributoTotalISCSolesDolares = montoTributoTotalISCSoles.divide(cambio1.getPventa(), 0, BigDecimal.ROUND_HALF_DOWN);
				}
				
				
				//PAS201830001100004 - mtorralba - Se obtiene monto de Valor Provisional
				try {
					LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
					Boolean tieneIndicadorLCVP = liquidaDeclaracionService.validaIndicadorLCVP(declaracion);
					Map<String,BigDecimal> mapaValorProvisional = liquidaDeclaracionService.obtenerValorEstimadoDeValorProvisional(declaracion);
					if(tieneIndicadorLCVP && declaracion.getDua().getFecfinprovsional() != null ) 
						montoValorProvisional = mapaValorProvisional.get("MTOVALORPROV");
				}
				catch (Exception e){
					montoValorProvisional = BigDecimal.ZERO; 
				}

			}
			
//INICIO RIN08 - PECO-Amazonia - Sumamos la misma variable para que incluya en caso corresponda lo de PECO-Amazonia
			montoAcumuladoDolares = montoAcumuladoDolares.add(montoTributoTotalDolares).add(montoTributoTotalPercepcionDolares).add(montoTributoTotalISCSolesDolares).add(montoValorProvisional);;
			//montoAcumuladoDolares = montoTributoTotalDolares.add(montoTributoTotalPercepcionDolares).add(montoTributoTotalISCSolesDolares);
//Fin RIN 08
				
			 if ( SunatNumberUtils.isGreaterThanZero(montoAcumuladoDolares)){
			
				if (! SunatStringUtils.isEmpty(codGarantia)  && "G".equals(codTipoPago)){// tiene una garantia 160
					 Map params = new HashMap();
					 if(ConstantesDataCatalogo.REGIMEN_EER.equals(declaracion.getDua().getCodregimen())){
						 params.put("cRUC",(String) variablesIngreso.get("numRucValidoGarantia")); 
					 }else{
						 params.put("cRUC",declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()); // RUC del beneficiario
					 }
				     params.put("cADUANA",declaracion.getCodaduana());
				     params.put("cANO",null);
				     params.put("cREGIMEN",declaracion.getDua().getCodregimen());
				     params.put("cNUMERO"," ");
				     params.put("cNUMREF",codGarantia);
				     params.put("cCDA"," ");
				     params.put("cRUCAGENTE",numeroDocumentoIdentidadSender); // RUC del agente
				     params.put("cORDEN",numOrden); // viene año y numero
				     params.put("nMONTOA",montoAcumuladoDolares); // soles  + dolares
				     params.put("cMONEDAA","D");
				     params.put("nFECHA1",SunatDateUtils.getCurrentIntegerDate());
				     params.put("cMODULO",tipoDesp);
				     params.put("cTRANS","001");
//				     resultado=(String)NumeracionServiceImpl.getInstance().getPagarantiaDAO().procesarAfectaCtaCte(params);
				     resultado=(String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarAfectaCtaCte(params);
				     //DZC - Graba en LogRegi  
				     Map LogRegiparams = new HashMap();
				     LogRegiparams.put("regimen",declaracion.getDua().getCodregimen());
				     LogRegiparams.put("codi_aduan",declaracion.getCodaduana());
				     LogRegiparams.put("nume_corre",declaracion.getNumeroDeclaracion()); 
				     LogRegiparams.put("tipo",codTransaccion);
				     LogRegiparams.put("fech_error",SunatDateUtils.getCurrentIntegerDate());
				     LogRegiparams.put("cod_usumodif",numeroDocumentoIdentidadSender);
				     LogRegiparams.put("respuesta",resultado);
				     LogRegiparams.put("funcion","PAGARANTIA.fnafectactacte");
				     LogRegiparams.put("modulo","ValidaAnexoDeclaracionService#separaGarantia()");
				     LogRegiparams.put("ano_prese", (String)SunatStringUtils.toStringObj((Integer) variablesIngreso.get("annEnvio")));
				     LogRegiparams.put("nume_orden",(String)SunatStringUtils.toStringObj((Long) variablesIngreso.get("numEnvio")));
				     LogRegiService logRegiService = (LogRegiService)fabricaDeServicios.getService("garantia.logRegiService");
				     logRegiService.grabaLogGarantia(LogRegiparams,params);    
			        // DZC -Fin
				     
				}				
				if (resultado.length()>0){
			    	 if (resultado.substring(0, 1).equals("0")){//validacion incorrecta
			    		 for(int i=0; i<resultado.length(); i++){
			    			 posInicialError=i;
			    			 if (resultado.substring(i,i+1).equals("|")){
			    				 for(int j=i; j<resultado.length(); j++){
			    					 if (resultado.substring(j,j+1).equals("|")){
			    						 posFinalError=j;
			    						 j=resultado.length();
			    					 }
			    				 }
			    				 
			    				 if (posFinalError==1){
			    					 codErr=resultado.substring(2);
			    				 }else{
			    					 codErr=resultado.substring(posInicialError, posFinalError);
			    				 }
			    				 
			    				 //responseList.addError(codErr, "ERROR DEL PAGARANTIA");
			    				 //resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap(codErr,""));
			    				 resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr,new String[]{""}));
									
			    			 }
			    		 }
			    		 mapGarantia.put("resultado", "ERROR");
				    	 mapGarantia.put("mtoAfectado", BigDecimal.ZERO);
				    	 variablesIngreso.put("mapGarantia", mapGarantia);
			    	 } else {
			    		 mapGarantia.put("resultado", "OK");
				    	 mapGarantia.put("mtoAfectado", montoAcumuladoDolares);
				    	 variablesIngreso.put("mapGarantia", mapGarantia);
			    	 }
				} 
			}
		}
		
		return resultadoError;
     }
	

	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#calculaDeudaRectificacion(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.util.Map, java.lang.Integer)
	 */		
	@Override
	@ServicioAnnot(tipo="V",codServicio=3033, descServicio="Invocacion al servicio de calculo de diferencia y la almacena en memoria")
	@ServInstDetAnnot(tipoRpta={1,1,1},nomAtr={"declaracion","variablesIngreso","nroErroresNegocio"})
	@OrquestaDespaAnnot(codServInstancia=3033,numSecEjec=425,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public Map<String, String> calculaDeudaRectificacion(Declaracion declaracion
			,Map<String, Object> variablesIngreso , Integer nroErroresNegocio) 
	throws Exception{
		    /*P46 INICIO - cambio nombre deudadiferencial por diferenciaTributos*/
			Map<String,Object> diferenciaTributos=new HashMap<String,Object>();
			/*P46 FIN*/
			Map<String,String> resultadoError = new HashMap<String,String>();
			// invocacion al servicio de calculo de diferencias
			if(declaracion.getDua().getNumcorredoc()!=null){
				String numOrden=(String)variablesIngreso.get("numOrden");
				String codUsuario=(String)variablesIngreso.get("codUsuario");
				String tipoDocumentoIdentidadSender=(String)variablesIngreso.get("tipoDocumentoIdentidadSender");
				String numeroDocumentoIdentidadSender=(String)variablesIngreso.get("numeroDocumentoIdentidadSender");
				String codTransaccion=(String)variablesIngreso.get("codTransaccion");
				if(nroErroresNegocio==0){

					GeneraLiquidacionService generaLiquidacionService = (GeneraLiquidacionService)fabricaDeServicios.getService("generaLiquidacionService");
					//  calcula la liquidacion
//					Map retorna = RectificacionServiceImpl.getInstance().getCalculoAdeudoService().obtenerLiquidacion(declaracion
//							, codTransaccion, 
//							numOrden, codUsuario,
//							tipoDocumentoIdentidadSender, numeroDocumentoIdentidadSender);
					Map retorna = generaLiquidacionService.obtenerLiquidacion(declaracion
							, codTransaccion, 
							numOrden, codUsuario,
							tipoDocumentoIdentidadSender, numeroDocumentoIdentidadSender);
					// RPH 20140331 LC Tributos liberados
					if( retorna.get("MontoTPI100") != null ) {
						variablesIngreso.put("MontoTPI100", retorna.get("MontoTPI100"));
					}
					
					//Inicio de cambios del PAS20155E220200172 LC con indicador 15 y margen 9
					if( retorna.get("montoTPILC15_SI_9")!=null){						
						variablesIngreso.put("montoTPILC15_SI_9", retorna.get("montoTPILC15_SI_9"));
					}
					
					if( retorna.get("montoTPILC15_NO_9")!=null){						
						variablesIngreso.put("montoTPILC15_NO_9", retorna.get("montoTPILC15_NO_9"));
					}
					//Fin de cambios del PAS20155E220200172
					
					//Inicio MATC 20130327 - Se incluye obtener el monto liquidado en la rectificacion 
					MovCabliqdilig mapCabliqdilig = (MovCabliqdilig)retorna.get("movCabliqdilig");
					Declaracion declaracionBD = (Declaracion)variablesIngreso.get("declaracionBD");
					
					String codgarantiaBD = new String();
					String codgarantia   = new String();
					if(declaracionBD != null){
						codgarantiaBD = declaracionBD.getDua().getPago().getPagoDeclaracion() != null?declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia():"";
					}
					codgarantia   = declaracion.getDua().getPago().getPagoDeclaracion() !=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia():"";

					// Verificamos si recién garantiza en la rectificacion y monto liquidado es CERO
					if(!SunatStringUtils.isEmptyTrim(codgarantia) && SunatStringUtils.isEmptyTrim(codgarantiaBD)) { 
						boolean tieneLC0006 =  retorna.get("MontoLC0006") != null ? true : false;
							//INICIO RIN08 - PECO-Amazonia - Solo si no existe MontoLC0006 significa que se debe rechazar por tener CERO.
						if( mapCabliqdilig.getMtoTotpDolar().compareTo(BigDecimal.ZERO)==0  && !tieneLC0006 ){
								//resultadoError = RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30558","");
								resultadoError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30558",new String[]{""});
								return resultadoError;	
							}
						
							//PAS20175E220200077 - mtorralba 20170623 - Inicio
						//BigDecimal montoTotal = obtenerDeudaTotal();  
							FuncionesLiquidacionService funcionesLiquidacionService = fabricaDeServicios.getService("funcionesLiquidacionService");
						BigDecimal montoTotal = funcionesLiquidacionService.obtenerDeudaTotalDeclaracion(mapCabliqdilig, declaracionBD.getDua().getFecdeclaracion());
						
							List<Map<String,String>> lstErrores=validarAfectarGarantia160(declaracion, montoTotal, " ", Integer.valueOf("10101"), mapCabliqdilig.getCodAgente(), "TE", "005", null);
							if( lstErrores.size()>0)  resultadoError = lstErrores.get(0);

						if( !tieneLC0006 )  variablesIngreso.put("incluyeGarantiaEnRecti", "S");
						//return (resultadoError);
						
					}//Final recien garantiza en la rectificacion
					
					// recupera la liquidacion calculada
					//deudadiferencial=RectificacionServiceImpl.getInstance().getCalculoAdeudoService().obtenerDiferenciaTributaria(declaracion,codTransaccion, numOrden, codUsuario, tipoDocumentoIdentidadSender, numeroDocumentoIdentidadSender);
					/*P46 INICIO - cambio nombre deudadiferencial por diferenciaTributos*/
					diferenciaTributos=generaLiquidacionService.obtenerDiferenciaTributaria(declaracion,codTransaccion, numOrden, codUsuario, tipoDocumentoIdentidadSender, numeroDocumentoIdentidadSender);
					/*P46 FIN*/
					/*branch ingreso 2011-009 inicio*/
					
					/*P46 - cambio nombre deudadiferencial por diferenciaTributos*/
					if (CollectionUtils.isEmpty(diferenciaTributos) || diferenciaTributos.containsKey("ERROR")){
						//resultadoError=RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30397","");
						resultadoError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30397",new String[]{""});
						return resultadoError;
					}
					/*branch ingreso 2011-009 fin*/

					//INICIO RIN 08 - Para generar LC 0006 - PECO-Amazonia
					if(retorna.get("MontoLC0006") != null) {
						//System.out.println("******* calculaDeudaRectificacion ******  MontoLC0006 seteado en variablesIngreso.");
						variablesIngreso.put("MontoLC0006", retorna.get("MontoLC0006"));
					}				
					//Fin RIN 08
				}
					
					// recupera autoliquidacion
				/*branch ingreso 2011-009 hosorio inicio 25/06/2011*/
					//variablesIngreso.put("lstAutoliquidaciones",obtenerAutoliquidacion(declaracion));
				/*P46 MODIFICADO, se agrego 0006*/
				if(SunatStringUtils.isStringInList(codTransaccion, "1004,1005")){//PAra la regularizacion no se carga la 0027
					variablesIngreso.put("lstAutoliquidaciones",obtenerAutoliquidacion(declaracion,"0026,0038,0006,0029,0022"));//PAS20165E220200080-PAS20165E220200092
				}
				else{
				//variablesIngreso.put("lstAutoliquidaciones",obtenerAutoliquidacion(declaracion,"0026,0027,0038,0006"));
				  variablesIngreso.put("lstAutoliquidaciones",obtenerAutoliquidacion(declaracion,"0026,0027,0038,0006,0029"));//PAS20165E220200054
				}
				/*FIN P46 MODIFICADO*/
					/*branch ingreso 2011-009 hosorio fin 25/06/2011*/
					/*P46 - cambio nombre deudadiferencial por diferenciaTributos*/
					variablesIngreso.put("deudadiferencial",diferenciaTributos);
					//MATC 20150331 - P46 INICIO
					variablesIngreso.put("tienePERCEPCION", diferenciaTributos.get("generaPercepcion"));
					variablesIngreso.put("MontoPercepcion",diferenciaTributos.get("MPERCEP"));
					//P46 FIN
				
			}
			//return new HashMap<String, String>();
			return resultadoError;
			
		}

	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#validarliquidacionRectificacion(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.util.Map)
	 */		
	@Override
	@ServicioAnnot(tipo="V",codServicio=3034, descServicio="Realiza la validacion de la liquidacion de rectificacion")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=3034,numSecEjec=426,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public List<Map<String, String>> validarliquidacionRectificacion(Declaracion declaracion
			, Map<String,Object> variablesIngreso) throws Exception{

		List<Map<String,String>> resultadoError = new ArrayList<Map<String,String>>();
		String numeroDocumentoIdentidadSender=(String)variablesIngreso.get("numeroDocumentoIdentidadSender");
		String tipoDesp=(String)variablesIngreso.get("tipoDesp");
		String codTransaccion=(String)variablesIngreso.get("codTransaccion");
		/*branch ingreso-2011-009 hosorio inicio 20/04/2011*/
		String codGarantia = null;
		String codGarantiaBD =null;
		try {
			codGarantia= declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
		} catch (Exception e) {
			//  handle exception
		}
		Map<String, Object> mapDua = obtenerMapDua(declaracion);
		/*branch ingreso-2011-009 hosorio fin 20/04/2011*/
		Map<String,Object> deudadiferencial=(Map<String,Object>)variablesIngreso.get("deudadiferencial");
		//INICIO RIN 16 se mueve estaba antes abajo
		if (!CollectionUtils.isEmpty(deudadiferencial) && deudadiferencial.containsKey("ERROR")){
			//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30397",""));
			resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30397",new String[]{""}));
			return resultadoError;
		}
		//FIN RIN 16
		/**INICIO P46**/
		String codCanal = declaracion.getDua().getCodCanal()!=null?declaracion.getDua().getCodCanal().trim():"";
		String[] arrayTipIndicador = new String[] {
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL,
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL };
		boolean montosEnCero=false;
		String tipoTratamiento = declaracion.getDua().getCodtipotratamiento()!=null?declaracion.getDua().getCodtipotratamiento():"";
		BigDecimal montoTotal = BigDecimal.ZERO;    
		BigDecimal montoTotalAcumulado = BigDecimal.ZERO;
		if (!CollectionUtils.isEmpty(deudadiferencial)){
		montoTotal = deudadiferencial.get("MTO_TOTAL") != null? (BigDecimal)deudadiferencial.get("MTO_TOTAL"):BigDecimal.ZERO;
		montoTotalAcumulado = deudadiferencial.get("MTO_TOTAL_ACUMULADO") != null?(BigDecimal)deudadiferencial.get("MTO_TOTAL_ACUMULADO"):BigDecimal.ZERO;				
		}
		if(SunatNumberUtils.isEqual(montoTotal, BigDecimal.ZERO) && SunatNumberUtils.isEqual(montoTotalAcumulado, BigDecimal.ZERO)){
			montosEnCero=true;
		}
						
		String tipoCance = "";
		DeudaDocum tempDeudaDocum = new DeudaDocum();
		tempDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
		tempDeudaDocum.setCodTipdeuda("01");
		DeudaDocumDAO deudaDocumDAO = fabricaDeServicios.getService("deudaDocumDef");
		List<DeudaDocum> listDeudaDocum = deudaDocumDAO.selectByDocumento(tempDeudaDocum);
		if(!CollectionUtils.isEmpty(listDeudaDocum)){
			for(DeudaDocum deudaDocum: listDeudaDocum){
				DeudaDeclaracionService deudaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.deudaDeclaracionService");
				tipoCance = deudaDeclaracionService.obtenerTipoCancelacion(deudaDocum);
			}							
		}
		
		String indicadorNEW = "";
		String indicadorBD = "";
		boolean esDonacion = false;
		boolean esDonacionRegularizada = false;
		List<DatoIndicadores> listIndicadoresNEW = declaracion.getDua().getListIndicadores()!=null?declaracion.getDua().getListIndicadores():new ArrayList<DatoIndicadores>();
		if(!CollectionUtils.isEmpty(listIndicadoresNEW)){
			for(DatoIndicadores indicadores: listIndicadoresNEW){
				String indDuatmp = indicadores.getCodtipoindica()!=null?indicadores.getCodtipoindica():"";
				String indActivo = indicadores.getIndicadorActivo()!=null?indicadores.getIndicadorActivo():"";
				if(SunatStringUtils.include(indDuatmp, arrayTipIndicador) && !SunatStringUtils.isEqualTo("0", indActivo)){
					indicadorNEW = indDuatmp;
				}
			}							
		}
		
		Map<String,Object> paramsIndDua = new HashMap<String, Object>(); 
		paramsIndDua.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
		paramsIndDua.put("listaTipoIndica", new String[] { ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL});
		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		List<Map<String,Object>> listIndicadoresBD = indicadorDUADAO.findByDocumentoAndTipo(paramsIndDua);
		if(!CollectionUtils.isEmpty(listIndicadoresBD)){
			for(Map<String,Object> indicadoresBD: listIndicadoresBD){
				String indDuatmpBD = indicadoresBD.get("COD_INDICADOR")!=null?indicadoresBD.get("COD_INDICADOR").toString().trim():"";
				String indActivoBD = indicadoresBD.get("IND_ACTIVO")!=null?indicadoresBD.get("IND_ACTIVO").toString().trim():"";
				if(SunatStringUtils.include(indDuatmpBD, arrayTipIndicador) && SunatStringUtils.isEqualTo("1", indActivoBD)){
					indicadorBD = indDuatmpBD;
				}
			}							
		}
		
		if(SunatStringUtils.isEqualTo(tipoTratamiento, ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION) &&  SunatStringUtils.isEqualTo(String.valueOf(ConstantesDataCatalogo.TIPO_CANCELACION_IMPUGNACION_SIN_GARANTIA_DONACION), tipoCance)){
			esDonacion=true;							
		}
		
		if(esDonacion && !SunatStringUtils.include(indicadorNEW, arrayTipIndicador) && SunatStringUtils.include(indicadorBD, arrayTipIndicador) && !montosEnCero && !("").equals(codCanal)){
			deudadiferencial.put("tieneIncTribByTrib", true);
			BigDecimal MIGV = deudadiferencial.get("MIGV_ACUMULADO")!=null?(BigDecimal)deudadiferencial.get("MIGV_ACUMULADO"):BigDecimal.ZERO;
	      	BigDecimal MIPM = deudadiferencial.get("MIPM_ACUMULADO")!=null?(BigDecimal)deudadiferencial.get("MIPM_ACUMULADO"):BigDecimal.ZERO;
      	  	//SETEANDO VALORES IGV - IPM
	      	deudadiferencial.put("MIGV", MIGV);
	      	deudadiferencial.put("MIPM", MIPM);
	      	deudadiferencial.put("MTO_TOTAL", montoTotalAcumulado);
		}		
		/**FIN P46**/		
//esto esta arriba se ha movido	
//		if (!CollectionUtils.isEmpty(deudadiferencial) && deudadiferencial.containsKey("ERROR")){
//			//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30397",""));
//			resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30397",new String[]{""}));
	//		return resultadoError;
	//	}

		/*branch ingreso-2011-009 hosorio inicio 06/04/2011*/
		List<Liquida>  lstAutoliquidaciones = (List<Liquida>)variablesIngreso.get("lstAutoliquidaciones");
		List<Map<String,String>> lstErrAutoliq=new ArrayList<Map<String,String>>();
		//Manifiesto manifiesto= RectificacionServiceImpl.getInstance().getFuncionesService().getManifiestoNASigad(declaracion);
		Manifiesto manifiesto= ((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).getManifiestoNASigad(declaracion);
		Map<Object, Object> mapManif = null;
		if(manifiesto!=null){
			mapManif = new HashMap<Object, Object>();
			mapManif.put("fechaEfectivaDeLlegada", manifiesto.getFechaEfectivaDeLlegada());
			mapManif.put("fechaProgramadaLlegada", manifiesto.getFechaProgramadaLlegada());
			mapManif.put("fechaTerminoDeDescarga", manifiesto.getFechaTerminoDeDescarga());
		}
		codGarantiaBD = mapDua.get("codgarantia").toString();
		String codCatalogotributo="TRI";
		if(Constants.COD_ADUANA_CHIMBOTE.equals(declaracion.getDua().getCodaduanaorden())){
			codCatalogotributo=Constants.TRIBUTOS_DIFERENCIADOS_CHIMBOTE;
		}			
		// Se obtiene el detalle de la Deuda anterior a la rectificacion
		Map<String,BigDecimal> mpDeudaPendiente=obtenerDeudaAnterior(declaracion,codCatalogotributo,null);
		boolean existeIncidenciaTributaria=false;
		boolean blAplicarImputacion=false;
		boolean generaPercepcionRectificacion = false;
		boolean cancelado = isFCCancelado(declaracion);
		boolean esGarantiaRenovada = esGarantiaRenovada(codGarantia);
		//PAS20165E220200127
		//if(esGarantiaRenovada){
		//	codGarantiaBD = " ";
		//	codGarantia = " ";
		//}

		//INICIO RIN 16
		if(!cancelado && !CollectionUtils.isEmpty(deudadiferencial) && declaracion.getNumdeclRef().getCodregimen().equals(Constants.REGIMEN_IMPO_DEFINITIVA) && !SunatStringUtils.isEmptyTrim(codGarantia) && !esGarantiaRenovada && (codTransaccion.endsWith("04") || codTransaccion.endsWith("05"))){
			BigDecimal mtoTotalAcumulado = deudadiferencial.get("MTO_TOTAL_ACUMULADO") != null?(BigDecimal)deudadiferencial.get("MTO_TOTAL_ACUMULADO"):BigDecimal.ZERO;
			BigDecimal MIGV = deudadiferencial.get("MIGV_ACUMULADO")!=null?(BigDecimal)deudadiferencial.get("MIGV_ACUMULADO"):BigDecimal.ZERO;
	      	BigDecimal MIPM = deudadiferencial.get("MIPM_ACUMULADO")!=null?(BigDecimal)deudadiferencial.get("MIPM_ACUMULADO"):BigDecimal.ZERO;
	      	BigDecimal MDES = deudadiferencial.get("MDES_ACUMULADO")!=null?(BigDecimal)deudadiferencial.get("MDES_ACUMULADO"):BigDecimal.ZERO;
	      	BigDecimal MADV = deudadiferencial.get("MADV_ACUMULADO")!=null?(BigDecimal)deudadiferencial.get("MADV_ACUMULADO"):BigDecimal.ZERO;
      	  	//SETEANDO VALORES IGV - IPM
	      	deudadiferencial.put("MIGV", MIGV);
	      	deudadiferencial.put("MIPM", MIPM);
	      	deudadiferencial.put("MDES", MDES);
	      	deudadiferencial.put("MADV", MADV);
	      	deudadiferencial.put("MTO_TOTAL", mtoTotalAcumulado);
		}//FIN RIN 16

		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
		//List<DeudaDocum> listaDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);
		List<DeudaDocum> listaDeudaDocum=((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);

		existeIncidenciaTributaria=existeIncidencia( deudadiferencial,listaDeudaDocum);
		
		/*INICIO P46*/
		if(esDonacion && !SunatStringUtils.include(indicadorNEW, arrayTipIndicador) && SunatStringUtils.include(indicadorBD, arrayTipIndicador) && !montosEnCero && !("").equals(codCanal)){
			existeIncidenciaTributaria=true;
		}
		/*FIN P46*/
		
		// Inicio PAS20155E220000081 - MATC 20150219 - Atencion BUG 20988 
		boolean existeIncidenciaTributariaMenor = false;
		// Fin PAS20155E220000081 - MATC 20150219 - Atencion BUG 20988 
		
		//Map<String, String> validarPercepcion = validaGeneraPercepcion(declaracion,variablesIngreso); 
		
		BigDecimal totalMontoTributo=null;
		if(!CollectionUtils.isEmpty(deudadiferencial)){
			// Inicio PAS20155E220000081 - MATC 20150219 - Atencion BUG 20988 
			existeIncidenciaTributariaMenor = (Boolean) (deudadiferencial.get("diferenciaTributosMenor")!=null?deudadiferencial.get("diferenciaTributosMenor"):false);
			// Fin PAS20155E220000081 - MATC 20150219 - Atencion BUG 20988 

			//Sólo régimen 10
			if(declaracion.getNumdeclRef().getCodregimen().equals(Constants.REGIMEN_IMPO_DEFINITIVA)){

				//Si es una rectificación electrónica de una DUA SIN garantía del artículo 160º
				if((SunatStringUtils.isEmptyTrim(codGarantiaBD)  && SunatStringUtils.isEmptyTrim(codGarantia))){
					//11.1. 
					//Si existe incidencia en la liquidación de los tributos, intereses o recargos
					if(existeIncidenciaTributaria){
						boolean blFcCancelado=cancelado;
						boolean blLcIscSolecCancelado=false;
						
						//ECANA 2015060 variable que indica cancelación de las LC ISC Licor Dolar 
						boolean blLcIscDolarLicorCancelado = false;
						
						//String numero=buscarAutoliquidacion("0038", lstAutoliquidaciones);
						//if(!SunatStringUtils.isEmpty(numero)){
							//Declaracion declaracionBD = (Declaracion) variablesIngreso.get("declaracionBD");
						//	Map<String, String> validarPercepcion = validaGeneraPercepcion(declaracion,variablesIngreso); 
						//}
						
						//L/C de ISC en soles
						List<DeudaDocum> lstDeudaDocum=obtenerDocDeudasdeLCAsociadas(declaracion,"0022");
						
						if(!CollectionUtils.isEmpty(lstDeudaDocum)){
							for (DeudaDocum deudaDocum:lstDeudaDocum) {
								blLcIscSolecCancelado=isDeudaCancelada(deudaDocum,Constants.REGIMEN_IMPO_DEFINITIVA);
							}								
						}
						
						//ECANA 2015060 Se valida la cancelación de las LC en dolares originadas por las ISC Licores
						//Se consultan todas las LC del tipo "0010"
						List<DeudaDocum> lstDeudaDocumDolar=obtenerDocDeudasdeLCAsociadas(declaracion,"0010");
						
						LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
						
						if(!CollectionUtils.isEmpty(lstDeudaDocumDolar)){
							
							for (DeudaDocum deudaDocumDolar:lstDeudaDocumDolar) {
								
								//Si verifica que sea un LC de ISC licores
								MovCalctributo movCalctributoTemp= new MovCalctributo();
								movCalctributoTemp.setCod_aduana(declaracion.getNumdeclRef().getCodaduana());   
								movCalctributoTemp.setAnn_orden(declaracion.getNumorden().substring(0, 4));       
								movCalctributoTemp.setNum_orden(declaracion.getNumorden().substring(4));	
								movCalctributoTemp.setCod_regimen(declaracion.getNumdeclRef().getCodregimen());
								movCalctributoTemp.setAnn_prese(declaracion.getNumdeclRef().getAnnprese());	
								movCalctributoTemp.setNum_corre(SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));     
								//movCalctributoTemp.setInd_proceso("1");//"1": ISC
								//Se agrega el nro de lc
								movCalctributoTemp.setCod_aduliqcob(deudaDocumDolar.getCodAduliquida());
								movCalctributoTemp.setAnn_liqcob(deudaDocumDolar.getAnnLiquida().toString());
								movCalctributoTemp.setNum_liqcob(deudaDocumDolar.getNumLiquida());			
								// Parametro "1" para consultar ISC
								List<MovCalctributo> listaMovCalctributoTemp = liquidaDeclaracionService.consultarProcLC(movCalctributoTemp, "1"); 
								
								if (listaMovCalctributoTemp.size()>0) {
									//Se verifica que la LC ISC icor se encuentre cancelada
									blLcIscDolarLicorCancelado=isDeudaCancelada(deudaDocumDolar,Constants.REGIMEN_IMPO_DEFINITIVA);
								}
							}								
						}
						////
						
						/**P46**/						
						if(esDonacion){
							//Se cambia valor a falso para evitar las validaciones de diferencia de tributos cuando la donación tenga indicador de impuganción
							blFcCancelado=false;
							blLcIscSolecCancelado=false;
						}
						
						if(esDonacion && !SunatStringUtils.include(indicadorNEW, arrayTipIndicador) && SunatStringUtils.include(indicadorBD, arrayTipIndicador)){
							esDonacionRegularizada = true;
						}
						/**FIN P46**/

						//y el formato C de la DUA y/o la L/C de ISC en soles, se encuentran cancelados, debe enviar obligatoriamente autoliquidaciones canceladas
						//ECANA 2015060 Se valida la cancelación de las LC en dolares originadas por las ISC Licores  blLcIscDolarLicorCancelado
						if(blFcCancelado ||   blLcIscSolecCancelado || esGarantiaRenovada || esDonacionRegularizada || blLcIscDolarLicorCancelado){/*P46*/

							Map<String,BigDecimal> mpTributosAutoCanc=null;
							//debe enviar obligatoriamente autoliquidaciones canceladas (LC Tipo 0026)  que cubran el monto diferencial -
							//Lc tipo 38 para percepcion
							if (!CollectionUtils.isEmpty(lstAutoliquidaciones)){
								mpTributosAutoCanc=obtenerDetalleTributosAutoliquidado(lstAutoliquidaciones,codCatalogotributo);
							}
							lstErrAutoliq=autoLiquidacionTributoATributo2(deudadiferencial,mpTributosAutoCanc,codCatalogotributo);
							if (!CollectionUtils.isEmpty(lstErrAutoliq) && esGarantiaRenovada){
								lstErrAutoliq.add(ResponseMapManager.getErrorResponseMap("30815",
										"NO SE PERMITE ACOTAR DEUDA A UNA GARANTIA PREVIA RENOVADA, REQUIERE AUTOLIQUIDARSE"));								
							}
					
						}
					}// fin existe incidencia tributaria

					blAplicarImputacion=isAplicarImputacion(declaracion, mapDua, mapManif);

					if(blAplicarImputacion){
						
						//Declaracion declaracionBD = (Declaracion) variablesIngreso.get("declaracionBD");
						//Map<String, String> validarPercepcion = validaGeneraPercepcion(declaracion,variablesIngreso); 
						List<Map<String, Object>> conceptosImputados=obtenerConceptosImputados(declaracion, mapManif, deudadiferencial);
						variablesIngreso.put("conceptosImputadosRectificacion", conceptosImputados);
						aplicarImputacionenDeuda(deudadiferencial,conceptosImputados);
						//De existir monto diferencial por pagar como consecuencia de la imputación de pago (en dólares o en soles), 
						//se realizan las mismas validaciones del numeral 11.1.
						Map<String,BigDecimal> mpTributosAutoCanc=new HashMap<String, BigDecimal>();
						if (!CollectionUtils.isEmpty(lstAutoliquidaciones)){
							mpTributosAutoCanc=obtenerDetalleTributosAutoliquidado(lstAutoliquidaciones,codCatalogotributo);
						}		
						lstErrAutoliq=autoLiquidacionTributoATributo2(deudadiferencial,mpTributosAutoCanc,codCatalogotributo);
						if (!CollectionUtils.isEmpty(lstErrAutoliq)){							
							resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30335",new String[]{"DEBE PRESENTAR AUTOLIQUIDACION POR LOS TRIBUTOS DIFERENCIALES CALCULADO"}));
							lstErrAutoliq.add(ResponseMapManager.getErrorResponseMap("30451",
									"LOS INTERESES SE COMPUTARAN A PARTIR DEL DIA SIGUIENTE DEL PAGO DE LA AUTOLIQUIDACION"));	
						}
					}
					if (!CollectionUtils.isEmpty(lstErrAutoliq))
						resultadoError.addAll(lstErrAutoliq);
					// regimen 10 SIN GARANTIA					

				}// FIN NO TIENE GARANTIA


				//Si es una rectificación electrónica de una DUA CON garantía del artículo 160º
				if(!SunatStringUtils.isEmptyTrim(codGarantia))
				{
					// PUNTO 12 DE LA ESPECIFICACION TECNICA


					//12.1
					//Si existe incidencia en la liquidación de los tributos y/o recargos, esté o no cancelada la DUA, 
					//se verifica si ha enviado autoliquidaciones canceladas (LC Tipo 0026) que cubran el monto diferencial - validando por cada concepto de tributo
					if(existeIncidenciaTributaria){
//pase339 mordonezl
		boolean blLcPercepcionCancelado=false;
						//L/C de percepcion en soles
						List<DeudaDocum> lstDeudaDocumPer=obtenerDocDeudasdeLCAsociadas(declaracion,"0038");
						
						if(!CollectionUtils.isEmpty(lstDeudaDocumPer)){
							for (DeudaDocum deudaDocum:lstDeudaDocumPer) {
								blLcPercepcionCancelado=isDeudaCanceladaDeDuaGarantizada(deudaDocum,Constants.REGIMEN_IMPO_DEFINITIVA);
							}								
						}
						

						//se verifica si ha enviado autoliquidaciones canceladas (LC Tipo 0026) que cubran el monto diferencial -
						if (!CollectionUtils.isEmpty(lstAutoliquidaciones)){
							// si ha numerado sin garantia
							if(SunatStringUtils.isEmptyTrim(codGarantiaBD)){
								//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30485","AL SOLICITAR ACOGERSE A UNA GARANTIA, NO SE DEBE ENVIAR AUTOLIQUIDACIONES."));
								resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30485",new String[]{"AL SOLICITAR ACOGERSE A UNA GARANTIA, NO SE DEBE ENVIAR AUTOLIQUIDACIONES."}));
							}
							else{
								Map<String,BigDecimal> mpTributosAutoCanc=obtenerDetalleTributosAutoliquidado(lstAutoliquidaciones,codCatalogotributo);
								BigDecimal bgMPercepDeuda= (BigDecimal)deudadiferencial.get("MPERCEP");
								if(SunatNumberUtils.isGreaterThanZero((BigDecimal)bgMPercepDeuda)){
									generaPercepcionRectificacion=true;
								}							
								
								if(blLcPercepcionCancelado ||  generaPercepcionRectificacion ) {
								lstErrAutoliq=autoLiquidacionTributoATributo2(deudadiferencial,mpTributosAutoCanc,codCatalogotributo);
								}else{
								lstErrAutoliq=autoLiquidacionTributoATributo(deudadiferencial,mpTributosAutoCanc,codCatalogotributo);
								}
								// SI LA AUTOLIQUIDACION ES CORRECTA
								if(CollectionUtils.isEmpty(lstErrAutoliq)){
								     if(!blLcPercepcionCancelado){
									// SI EXISTE DEUDA POR PERCEPCIO  VALIDAR QUE GARANTIA CUBRA LA DEUDA DE PERCEPCION
									if(SunatNumberUtils.isGreaterThanZero((BigDecimal)deudadiferencial.get("MPERCEP"))){

										// Monto Garantizado Anterior 
										BigDecimal bgDolaresGarantizado= obtenerMontoGarantizadoNoCancelado(listaDeudaDocum,"USD");
										BigDecimal bgSoleGarantizado= obtenerMontoGarantizadoNoCancelado(listaDeudaDocum,"PEN");

										// El nuevo Monto a garantizar debe incluir la incidencia de Percepcion ya que no se autoliquida
										BigDecimal bgMontoAGarantizarDolares=bgDolaresGarantizado; 
										BigDecimal bgMontoAGarantizarSoles=SunatNumberUtils.sum(bgSoleGarantizado, (BigDecimal)deudadiferencial.get("MPERCEP"));

										if(SunatNumberUtils.isGreaterThanZero(bgMontoAGarantizarSoles)){
											BigDecimal montoCambio=obtenerCambio("USD",SunatDateUtils.getCurrentIntegerDate(),bgMontoAGarantizarSoles);
											bgMontoAGarantizarDolares=SunatNumberUtils.sum(bgMontoAGarantizarDolares, montoCambio);
										}
										bgMontoAGarantizarDolares=SunatNumberUtils.scaleHalfUp(bgMontoAGarantizarDolares, 0);


										List<Map<String,String>> lstErroresPercep=validarAfectarGarantia160(declaracion, bgMontoAGarantizarDolares, " ", SunatDateUtils.getCurrentIntegerDate(), numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);
										// si no hay saldo para cubrir la incidencia de percepcion
										if (!CollectionUtils.isEmpty(lstErroresPercep)){
											variablesIngreso.put("existeSaldoGarantiaDiferencialdePercepcion", Boolean.FALSE);
											resultadoError.addAll(lstErroresPercep);
										}
										deudadiferencial.put("MPERCEP",bgMPercepDeuda);
									}
									
								     }
								}
							}
						}
						//de no haber enviado autoliquidacion
						else{ 
							totalMontoTributo=calculoTotalTributo(deudadiferencial, 1); // el flag de 2 para obtener el total diferencia -- se modifica flag a 1, la garantia debe cubrir el total de la nueva deuda y no el diferencial porque el package considera lo inicialmente afectado
							// aplico el redondeo porque sale el erro 10032  SOLO ENVIAR EL MONTO  COMO ENTERO en la garantia
							totalMontoTributo=SunatNumberUtils.scaleHalfUp(totalMontoTributo, 0);
							//se verifica que la garantía esté vigente (incluyendo vigencia renovada) y que tenga saldo operativo que cubra el monto diferencial (suma todos los tributos en dólares y en soles, 
							//incluyendo el monto en soles de la percepción y se lo envía al componente de garantías convirtiendo previamente toda la deuda a dólares con el tipo de cambio venta vigente 
							//a la fecha de la transmisión de la rectificación, para que verifique si el saldo operativo cubre el monto
							// si Garantia presenta errores
							boolean garantiaPresentaErrores=false;
							List<Map<String,String>> lstErrores=validarAfectarGarantia160(declaracion, totalMontoTributo, " ", SunatDateUtils.getCurrentIntegerDate(), numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);
							if (CollectionUtils.isEmpty(lstErrores)){
								variablesIngreso.put("marcaAfectarGarantiaLC", true);
								variablesIngreso.put("montoAfectar", totalMontoTributo);
							}
							//caso contrario, se rechaza el envío, por cuanto no tiene autoliquidaciones, 
							//ni garantía vigente y/o saldo operativo que cubra el diferencial.
							else{
								//PAS20165E220200127
								for (int i =0; i<lstErrores.size();i++) {
									resultadoError.add(lstErrores.get(i));	//se toma primer error del package, el segundo muchas veces no es el correcto e induce al error							
								}
								garantiaPresentaErrores = true;
								//Fin PAS20165E220200127
							}
							
							// si esta cancelado la Declaracion Garantizada
							boolean blFcCancelado=cancelado;
							boolean blLcIscSolecCancelado=false;
							
							blFcCancelado = isFCCanceladoDeDuaGarantizada(declaracion);
													
							//L/C de ISC en soles
							List<DeudaDocum> lstDeudaDocum=obtenerDocDeudasdeLCAsociadas(declaracion,"0022");
							
							if(!CollectionUtils.isEmpty(lstDeudaDocum)){
								for (DeudaDocum deudaDocum:lstDeudaDocum) {
									blLcIscSolecCancelado=isDeudaCanceladaDeDuaGarantizada(deudaDocum,Constants.REGIMEN_IMPO_DEFINITIVA);
								}								
							}
							//PAS20165E220200127
							boolean reliquidaMenorConGarantia = false;
							if(existeIncidenciaTributariaMenor && SunatStringUtils.isEmptyTrim(codGarantiaBD)  && !SunatStringUtils.isEmptyTrim(codGarantia)){
								reliquidaMenorConGarantia = true;
							}
							if(existeIncidenciaTributariaMenor && !SunatStringUtils.isEmptyTrim(codGarantiaBD)  && !SunatStringUtils.isEmptyTrim(codGarantia)){
								reliquidaMenorConGarantia = true;
							}
							

							//y el formato C de la DUA y/o la L/C de ISC en soles se encuentran cancelados o Garantia presenta errores, debe enviar obligatoriamente autoliquidaciones canceladas
							//Fin PAS20165E220200127
							if(blFcCancelado ||   blLcIscSolecCancelado || blLcPercepcionCancelado || garantiaPresentaErrores || (esGarantiaRenovada && !reliquidaMenorConGarantia) ){ //PAS20165E220200127

								Map<String,BigDecimal> mpTributosAutoCanc=null;
								//debe enviar “obligatoriamente autoliquidaciones canceladas (LC Tipo 0026) que cubran el monto diferencial -
								//Lc tipo 38 para percepcion
								if (!CollectionUtils.isEmpty(lstAutoliquidaciones)){
									mpTributosAutoCanc=obtenerDetalleTributosAutoliquidado(lstAutoliquidaciones,codCatalogotributo);
								}
								lstErrAutoliq=autoLiquidacionTributoATributo2(deudadiferencial,mpTributosAutoCanc,codCatalogotributo);
									//PAS20165E220200127
									if (!CollectionUtils.isEmpty(lstErrAutoliq) && esGarantiaRenovada){							
										resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30335",new String[]{"DEBE PRESENTAR AUTOLIQUIDACION POR LOS TRIBUTOS DIFERENCIALES CALCULADO"}));
										lstErrAutoliq.add(ResponseMapManager.getErrorResponseMap("30451",
												"LOS INTERESES SE COMPUTARAN A PARTIR DEL DIA SIGUIENTE DEL PAGO DE LA AUTOLIQUIDACION"));	
									}
									//Fin PAS20165E220200127	
					
							}
					
							//resultadoError.add(ResponseMapManager.getErrorResponseMap("07208", "DUA cuenta con garantia de articulo 160, incidencia debe registrarse en la conclusión del despacho"));
						}							        				
					}
					else{
						// si no existe incidencia
						if (!CollectionUtils.isEmpty(lstAutoliquidaciones)){
							lstErrAutoliq.add(ResponseMapManager.getWarningResponseMap("07208", "NO EXISTE INCIDENCIA TRIBUTARIA . NO SE REQUIERE AUTOLIQUIDACIONES"));
						}
						if(existeIncidenciaTributariaMenor){
							BigDecimal bgDolaresGarantizado=obtenerMontoGarantizadoNoCancelado(listaDeudaDocum, "USD");
							BigDecimal bgSoleGarantizado=obtenerMontoGarantizadoNoCancelado(listaDeudaDocum, "PEN");
							BigDecimal bgDeudaPendienteNoGaranDolares=obtenerMontoSinGarantiaNoCancelado(listaDeudaDocum, "USD");
							BigDecimal bgDeudaPendienteNoGaranSoles=obtenerMontoSinGarantiaNoCancelado(listaDeudaDocum, "PEN");
						
			                /**INICIO RIN16**/
							//if(codTransaccion.endsWith("04") && ("V").equals(codCanal) && (SunatNumberUtils.isGreaterThanZero(bgDolaresGarantizado) ||  SunatNumberUtils.isGreaterThanZero(bgSoleGarantizado))) { PAS201830001100007 
                                                        //La validacion es para todos los canales excepto DAM con PECO
                                                        if(codTransaccion.endsWith("04") && (SunatNumberUtils.isGreaterThanZero(bgDolaresGarantizado) ||  SunatNumberUtils.isGreaterThanZero(bgSoleGarantizado)) && variablesIngreso.get("esPecoAmazonia")==null) {
			                resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35606",new String[]{""}));
			                return resultadoError;
			                }
			                /**FIN RIN16**/
							
							// en Acogimiento a la garantia se garantiza la deuda no garantiza
							BigDecimal bgMontoAGarantizarSoles=SunatNumberUtils.sum(bgDeudaPendienteNoGaranSoles, bgSoleGarantizado);
							BigDecimal bgMontoAGarantizarDolares=SunatNumberUtils.sum(bgDeudaPendienteNoGaranDolares, bgDolaresGarantizado);
						
							if(SunatNumberUtils.isGreaterThanZero(bgMontoAGarantizarSoles)){
								BigDecimal montoTributoTotalSolesTC=obtenerCambio("USD", SunatDateUtils.getCurrentIntegerDate(), bgMontoAGarantizarSoles);
								bgMontoAGarantizarDolares=SunatNumberUtils.sum(bgMontoAGarantizarDolares, montoTributoTotalSolesTC);
							}
						
							bgMontoAGarantizarDolares=SunatNumberUtils.scaleHalfUp(bgMontoAGarantizarDolares, 0);
							if(SunatNumberUtils.isGreaterThanZero(bgMontoAGarantizarDolares)){
								//amancilla PAS20155E220200039 SAU201510002900072 como es para menos ya no debe validarse
								/*List<Map<String,String>> lstErrores=validarAfectarGarantia160(declaracion, BigDecimal.ZERO, " ", SunatDateUtils.getCurrentIntegerDate(), numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);//PASE166
								if (CollectionUtils.isEmpty(lstErrores)){*/
									variablesIngreso.put("marcaAfectarGarantiaLC", true);
									variablesIngreso.put("montoAfectar", bgMontoAGarantizarDolares);
								/* amancilla PAS20155E220200039 SAU201510002900072}
								else{
									resultadoError.addAll(lstErrores);
								}*/
							}
							
						}
			
					}

					/* if(blAplicarImputacion){
								        	   List<Map<String, Object>> conceptosImputados=obtenerConceptosImputados(declaracion, mapManif, deudadiferencial);
								        	   variablesIngreso.put("conceptosImputadosRectificacion", conceptosImputados);
					            			    aplicarImputacionenDeuda(deudadiferencial,conceptosImputados);
												Map<String,BigDecimal> mpTributosAutoCanc=new HashMap<String, BigDecimal>();
									            if (!CollectionUtils.isEmpty(lstAutoliquidaciones)){
									            	mpTributosAutoCanc=obtenerDetalleTributosAutoliquidado(lstAutoliquidaciones,codCatalogotributo);
										            lstErrAutoliq=autoLiquidacionTributoATributo(deudadiferencial,mpTributosAutoCanc,codCatalogotributo);
									            }		

						}*/

					//
					if (!CollectionUtils.isEmpty(lstErrAutoliq))
						resultadoError.addAll(lstErrAutoliq);
				}// FIN SI TIENE GARANTIA





				// si es regimen 10 y tiene duda razonable no concluida
				// Si existe incidencia Tributaria
				if(existeIncidenciaTributaria){
					List<Map<String, Object>> listaDudaRazonable=obtenerDudaRazonableDua(declaracion);
					// Si tiene Duda Razonable
					if (!CollectionUtils.isEmpty(listaDudaRazonable)){
						// Si no esta concluida
						Map<String, Object> mpDudaRazonable=listaDudaRazonable.get(0);
						if( SunatStringUtils.isEqualTo(mpDudaRazonable.get("FECH_CONC_DILI").toString(), "0")){
							//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("07202","EXISTE DUDA RAZONABLE NO CONCLUIDA"));
							resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("07202",new String[]{"EXISTE DUDA RAZONABLE NO CONCLUIDA"}));
						}
					}

				}								            
			}// FIN REGIMEN 10

			// INICIO REGIMEN 20 21 70
			if(SunatStringUtils.isStringInList(declaracion.getDua().getCodregimen(), 
					Constants.REGIMEN_IMPORTACION_TEMPORAL+","+
							Constants.REGIMEN_ADMISION_TEMPORAL+","+
							Constants.REGI_DEPOSITO
					) ){

				// Si hay deuda Calculada
				if(!CollectionUtils.isEmpty(deudadiferencial) 
						&& (SunatNumberUtils.isGreaterThanZero((BigDecimal)deudadiferencial.get("MTO_TOTAL"))
								||	SunatNumberUtils.isGreaterThanZero((BigDecimal)deudadiferencial.get("MTO_TOTAL_SOL")) 
								)){
					//List<Map<String,String>> catalogoTributos=RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getElementosCat(codCatalogotributo);
					List<Map<String,String>> catalogoTributos=((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementosCat(codCatalogotributo);

					//tributos excluidos para la identificacion de la incidencia
					// En la Numeracion para regimen 20 21 no se generan LC por estos Tributos por lo que en la Rectificacion 
					//no se compara para identificar incidencia
					String listTributoExclu="MPERCEP,MSIGV,MSISC,MSIPM";
					if (SunatStringUtils.isStringInList(declaracion.getDua().getCodregimen(), "20,21"))
						listTributoExclu=listTributoExclu+",MTSERV";



					// Se recorre cada uno de los tributos y se verifica la diferencia de deudas
					for(Map<String,String> tributoBD:catalogoTributos){
						String codTributo =tributoBD.get("cod_datacat");
						String desCortTrib=tributoBD.get("des_corta");

						if (SunatStringUtils.isStringInList(desCortTrib, listTributoExclu))
							continue;

						BigDecimal deudaAnterior= (BigDecimal)mpDeudaPendiente.get(desCortTrib);
						BigDecimal deudaNueva= (BigDecimal)deudadiferencial.get(desCortTrib);
						if (deudaNueva!=null || deudaAnterior!=null){
							deudaAnterior=deudaAnterior==null?BigDecimal.ZERO:deudaAnterior;
							deudaNueva=deudaNueva==null?BigDecimal.ZERO:deudaNueva;
							// En regimen 20,21, 70 si La nueva deuda calculada es mayor a al anterior hay 
							//incidencia por lo tanto es un error
							if(SunatNumberUtils.isGreaterThanParam(deudaNueva, deudaAnterior)){

								//DataCatalogo datacatalogoTributo= RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(codCatalogotributo, codTributo);
								DataCatalogo datacatalogoTributo= ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(codCatalogotributo, codTributo);
								String descTributo=datacatalogoTributo != null && datacatalogoTributo.getDesDatacat()!=null?datacatalogoTributo.getDesDatacat():"";
								String mensaje  ="TRIBUTO: "+ descTributo +", CALCULADO: "+deudaNueva+ " DEUDA ANTERIOR: "+deudaAnterior+". REVISE";
								//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30447", mensaje));
								resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30447", new String[]{mensaje}));
							}
						}
					}


					//branch ingreso 2011-009 gmontoya 27/04/2011 13			
					if(codTransaccion.endsWith("03")){
						if(CollectionUtils.isEmpty(resultadoError)){
							// Si en la Numeracion no tiene garantia y en la rectificacion si declara garantia
							if(!SunatStringUtils.isEmptyTrim(codGarantia))
							{
								totalMontoTributo=calculoTotalTributo(deudadiferencial, 1);
								//branch ingreso 2011-009 gmontoya 13
								List<Map<String,String>> lstErrores=validarAfectarGarantia160(declaracion, totalMontoTributo, " ", SunatDateUtils.getCurrentIntegerDate(), numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);
								if (CollectionUtils.isEmpty(lstErrores)){
									variablesIngreso.put("marcaAfectarGarantiaLC", true);
									variablesIngreso.put("montoAfectar", totalMontoTributo);
								}
								else{
									resultadoError.addAll(lstErrores);
								}
							}
						}
					}
					//branch ingreso 2011-009 fin 27/04/2011															

				}

			}
			// FIN REGIMEN 20 21 70

		}            

		/*hosorio fin 25/04/2011*/

		if(declaracion.getDua().getNumcorredoc()!=null){
			if(!CollectionUtils.isEmpty(deudadiferencial) 
					&& SunatNumberUtils.isGreaterThanZero((BigDecimal)deudadiferencial.get("MTO_TOTAL"))
					){ // si hay deuda

				/*hosorio inicio 16/05/2011*/
				/*
					    boolean aplicaImputacion=verificarAplicaImputacion(declaracion,deudadiferencial,variablesIngreso);
						if(aplicaImputacion){

							 // se imputa y se actualiza la deuda diferencial con los nuevos saldos

							//1.- En caso la deuda resultante seha mayor de Cero Hacer 
							//1.1 .- Verificar si el usuario envia en el Segmento Documentos de Soporte  un documento de Soporte Tipo_proce='9' autoliquidacion 
							//1.2 .- Si no ha enviado nada Emitir el Error de Indicando que faltan tributos por Pagar 
							//1.3 .- De lo contrario Tomar los datos de la liquidacion enviada y buscar la informacion en la tabla Liquida
							//1.4 .- Validar el monto pagado en dicha liquidacion contra el monto de deuda , Si la deuda final es 0 proseguir con el proceso de manera ok (sin errores)
							//1.5 .- De lo contrario emitir error 



							 BigDecimal totalSaldoImputacion= imputacion(declaracion, variablesIngreso, deudadiferencial);
							 if(SunatNumberUtils.isGreaterThanZero(totalSaldoImputacion)){
								// si tiene autoliquidacion
								if(RectificacionServiceImpl.getInstance().getFuncionesService().isAutoliquidado(declaracion.getDua())){
				            		List<Liquida>  lstAutoliquidacion = (List<Liquida>)variablesIngreso.get("lstAutoliquidaciones");
				            		BigDecimal totalAutoliq=obtenerTotalAutoliquidado(lstAutoliquidacion);
				            			if(totalAutoliq.compareTo(totalSaldoImputacion)<0){
											 resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30279","FALTAN TRIBUTOS POR PAGAR"));
				            			}
				            			else{
				            				// este proceso lo hace el componente de juan por eso se comentaa
				            				//variablesIngreso.put("grabarPagoAutoliquidacion", true);
				            			}
								}
								else{
									resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30279","FALTAN TRIBUTOS POR PAGAR"));	
								}
							 }
						}
						else{
							if(declaracion.getNumdeclRef().getCodregimen().equals(Constants.REGIMEN_IMPO_DEFINITIVA)){
								Map<String,Object> mapDua=  obtenerMapDua(declaracion);
								String codcanal=(String)mapDua.get("codcanal");

								// si la dua ya esta cancelada
								boolean isDuacancelada =RectificacionServiceImpl.getInstance().getValidaciongeneralservice().verificarCancelacion(declaracion.getDua().getNumcorredoc())	;
								if(isDuacancelada){


									// si tiene autoliquidacion
									if(RectificacionServiceImpl.getInstance().getFuncionesService().isAutoliquidado(declaracion.getDua())){
										// valida los montos tributo por tributo (Exigir aautoliquidacion)
										resultadoError.addAll(infoautoliquidacion(declaracion, deudadiferencial,variablesIngreso));

									}
									else{ // si no tiene auto liquidacion

										// Si tiene canal
										if(StringUtils.hasText(codcanal)){
											// si es verde  (Exigir aautoliquidacion)
											if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_VERDE)){
												resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30270","DEBE PRESENTAR AUTOLIQUIDACION EN CANAL VERDE"));
											}
											else{
												// si tiene levante
												boolean tieneLevante=false;
												Date fecautlevante=(Date)mapDua.get("fecautlevante");					
												if(fecautlevante!= null && !DateUtil.isDefaultDate(fecautlevante)){
													tieneLevante=true;
												}

												if(tieneLevante){
													// (Exigir autoliquidacion)
													resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30335","DEBE PRESENTAR AUTOLIQUIDACION DESPUES DE LEVANTE"));
												}
											}

										}// fin si tiene canal
										else{ // si no tiene canal

											// si tiene garantia 
											if(StringUtils.hasText(codGarantia)){

												 totalMontoTributo=calculoTotalTributo(deudadiferencial, 2); // el flag de 2 lo uso para obtener el total diferencia
												// valida la afectacion con el diferencia de tributos 
												 resultadoError.addAll(validarAfectarGarantia160(declaracion, totalMontoTributo, " ", SunatDateUtils.getCurrentIntegerDate(), numeroDocumentoIdentidadSender, tipoDesp, "005"));
											    // si no hay errores
												if(CollectionUtils.isEmpty(resultadoError)){
													  // marca para afectacion de garantia
													  variablesIngreso.put("marcaGenerarLC", true);
													  variablesIngreso.put("montoAfectar", totalMontoTributo);
											    	  variablesIngreso.put("marcaAfectarGarantiaLC", true);						    	
											    }
												else{
											       // si hay errores en la garantia , no la podra afectar 		
													variablesIngreso.put("marcaGenerarLC", true);	
												}
										    }
											else{ // si no tiene garantia
												variablesIngreso.put("marcaGenerarLC", true);
											}
									}
								} // fin cuando no tiene autoliquidacion

							  } // fin de dua cancelada
								else{ // si la dua no esta cancelada

												// si tiene garantia 
											if(StringUtils.hasText(codGarantia)){

												    totalMontoTributo=calculoTotalTributo(deudadiferencial, 1); // el flag de 1 lo uso para obtener el total reliquidado
													// invoca la validacion de la garantia con todo el monto reliquidado  
												    resultadoError.addAll(validarAfectarGarantia160(declaracion, totalMontoTributo, " ", SunatDateUtils.getCurrentIntegerDate(), numeroDocumentoIdentidadSender, tipoDesp, "005"));
												    // si no hay errores
													if(CollectionUtils.isEmpty(resultadoError)){
														  // marca para afectacion de garantia ( Desafectar y volver a afectar	 la garantía) 
												    	  variablesIngreso.put("marcaDesafectarAfectarGarantia", true);
														  variablesIngreso.put("montoAfectar", totalMontoTributo);
												    }

											}
											//Coordinado con Edward: 10/03/2010 En impo definitiva, una dua no cancelada, no es obligatorio la garantia

											//else{
											//	resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30280","DEBE PRESENTAR GARANTIA"));
											//}

								}


							}
				 */
				if(!declaracion.getNumdeclRef().getCodregimen().equals(Constants.REGIMEN_IMPO_DEFINITIVA)){
					//else{// si no es impo definitiva = > la garantia es obligatoria
					/*hosorio fin 13/05/2011*/
					// si tiene garantia 
					if(StringUtils.hasText(codGarantia)){
						totalMontoTributo=calculoTotalTributo(deudadiferencial, 1); // el flag de 1 lo uso para obtener el total reliquidado
						// invoco la validacion de la garantia con todo el monto reliquidado , solo para validar , es decir no afecta
						resultadoError.addAll(validarAfectarGarantia160(declaracion, totalMontoTributo, " ", SunatDateUtils.getCurrentIntegerDate() , numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso));
						// si no hay errores
						if(CollectionUtils.isEmpty(resultadoError)){
							// marca para afectacion de garantia
							variablesIngreso.put("marcaDesafectarAfectarGarantia", true);
							variablesIngreso.put("montoAfectar", totalMontoTributo);
						}
					}
					/*Inicio ECC-29112010*/
					/*BUG 2650.- Calidad indica que la garantia no es obligatoria*/
					else if( codTransaccion.equals("04") &&  !codTransaccion.equals("05") ){
						//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30280","DEBE PRESENTAR GARANTIA"));
						resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30280",new String[]{"DEBE PRESENTAR GARANTIA"}));
					}
					/*Fin ECC-29112010*/
				}
				/*hosorio inicio 13/05/2011*/
				//}
				// fin proceso de validacion que no incluye imputacion
				/*hosorio fin 13/05/2011*/



			}
		}
		return resultadoError;
	}

   //Inicio RIN10 Refactor
	public List<Map<String,String>> validarSaldoOperativoDisponibleCtaCteGarantiaVP(Declaracion declaracion,Date fechaReferencia,BigDecimal sumaBaseImponibleSeries){
		List<Map<String, String>> listError = new ArrayList<Map<String,String>>();
		  DatoPago pago = declaracion.getDua().getPago();
		   DatoPagoDecla decla = pago!=null?pago.getPagoDeclaracion():null;
		   String codigoTipoPago = decla.getCodtipopago() != null ? decla.getCodtipopago() : "";
		   //si esta acogida a la garantia160 debe enviar el tipo de pago G y el numero de la cuenta corriente 
		   if(codigoTipoPago.equals(TIPO_PAGO_GARANTIA) || decla.getCodgarantia() != null){	// inicio PAS201830001100011 			   
			   Map<String, Object> params = new HashMap<String, Object>();
			   params.put("NUMCTACTE", decla.getCodgarantia());
			   params.put("FECHAPROCESO", fechaReferencia);
			   params.put("IND_ACTIVO", "1");
				  
			   // obtenemos los datos de la cta corriente
			   CabCtaCteGarDAO cabCtaCteGarDAO = (CabCtaCteGarDAO)fabricaDeServicios.getService("cabctactegarDef");
			   Map<String, Object> resultado = cabCtaCteGarDAO.findByNumCtaCte(params);
			   
			   if(!CollectionUtils.isEmpty(resultado)){
				   // si esta vigente la cta corriente obtiene el porcentaje de la base impobible
				   DataCatalogoDAO dataCatalogoDAO = (DataCatalogoDAO)fabricaDeServicios.getService("Ayuda.dataCatalogoDef");
				   DataCatalogo dataCatalogo = dataCatalogoDAO.buscarDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_PORCENTAJE_BIVP, ConstantesDataCatalogo.COD_DATACAT_VALOR_PORCENTAJE_BIVP);
				   BigDecimal porcentajeBaseImponible = new BigDecimal(dataCatalogo.getDesCorta());
				   
				   // obtenemos el saldo operativo de la cta corriente
				   BigDecimal saldoOperativoDisponible = resultado.get("MTOSALDOOPEDISP")!=null? 
							new BigDecimal(resultado.get("MTOSALDOOPEDISP").toString()):BigDecimal.ZERO;			   
					   
				   //base imponible = Monto Ajuste + Monto Flete + Monto Total de Seguros + Monto Total Fob
				   //el saldoOperativo debe ser mayor o igual al porcentaje de la suma de todas las series con valor provisional 
				   if(!SunatNumberUtils.isGreaterOrEqualsThanParam(saldoOperativoDisponible, sumaBaseImponibleSeries.multiply(porcentajeBaseImponible.divide(new BigDecimal("100"))))) {			   
					 //Inicio RIN10 BUG 22556
					   //listError.add(ResponseMapManager.getErrorResponseMap("10012", "LA CTACTE DE LA GARANTIA NO TIENE SALDO OPERATIVO"));
					   CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					   listError.add(catalogoAyudaService.getError("10012"));
					 //Fin RIN10 BUG 22556
				   }
			   }
			   
		   }
		   return listError;
		
	}
    //Fin RIN10 Refactor
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#validarAfectarGarantia160(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.math.BigDecimal, java.lang.String, java.lang.Integer, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<Map<String,String>> validarAfectarGarantia160(Declaracion declaracion,BigDecimal montoAcumuladoDolares, String cda,Integer fechaConclusionDespacho, String numeroDocumentoIdentidadSender, 
			String modulo, String ctrans,Map<String, Object> variablesIngreso){
		
		Map params = new HashMap();

		List<Map<String,String>> lstErrores=new ArrayList<Map<String,String>>();
		DatoPago pago=declaracion.getDua().getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		String codGarantia=decla!=null?decla.getCodgarantia():null;	
		
		//PAS20165E220200068 - Inicio
		if(SunatNumberUtils.isEqual(fechaConclusionDespacho, 10101)){
			fechaConclusionDespacho = 19010101;
		}
		//PAS20165E220200068 - Fin		
		
	    params.put("cRUC",declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()); // RUC del beneficiario
	    params.put("cADUANA",declaracion.getNumdeclRef().getCodaduana());
	    params.put("cANO",declaracion.getNumdeclRef().getAnnprese().substring(2));
	    params.put("cREGIMEN",declaracion.getDua().getCodregimen());
	    params.put("cNUMERO",Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre(), 6, '0'));
	    params.put("cNUMREF",codGarantia);
	    params.put("cCDA",cda);// es un espacio en blanco para la 005
	    params.put("cRUCAGENTE",numeroDocumentoIdentidadSender); // RUC del agente
	    params.put("cORDEN",declaracion.getNumorden());//anho mas numero de orden 2009000001
	    params.put("nMONTOA",montoAcumuladoDolares.setScale(0, BigDecimal.ROUND_HALF_UP)); // soles  + dolares
	    params.put("cMONEDAA","D");
	    params.put("nFECHA1",fechaConclusionDespacho);
	    params.put("cMODULO",modulo);// debe de ser TA o TE
	    params.put("cTRANS",ctrans);//005
	    //branch ingreso 2011-009 gmontoya 13
	    if(declaracion.getDua().getFecdeclaracion()!=null){	    	
	    	params.put("nFECNUMERA", SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion()));
		    params.put("nFECRECTI", SunatDateUtils.getCurrentIntegerDate());
	    }else{
		    params.put("nFECNUMERA", 0);
		    params.put("nFECRECTI", 0);
	    }
	    
//	    String resultado=(String)NumeracionServiceImpl.getInstance().getPagarantiaDAO().procesarAfectaCtaCte(params);
	    String resultado=(String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarAfectaCtaCte(params);
	    
	     //DZC - Graba en LogRegi  
	     if(variablesIngreso!=null)
	     {
		     Map LogRegiparams = new HashMap();
		     LogRegiparams.put("regimen",declaracion.getDua().getCodregimen());
		     LogRegiparams.put("codi_aduan",declaracion.getCodaduana());
		     LogRegiparams.put("nume_corre",declaracion.getNumeroDeclaracion()); 
		     LogRegiparams.put("tipo",(String)variablesIngreso.get("codTransaccion"));
		     LogRegiparams.put("fech_error",SunatDateUtils.getCurrentIntegerDate());
		     LogRegiparams.put("cod_usumodif",numeroDocumentoIdentidadSender);
		     LogRegiparams.put("respuesta",resultado);
		     LogRegiparams.put("funcion","PAGARANTIA.fnafectactacte");
		     LogRegiparams.put("modulo","ValidaAnexoDeclaracionService#validarAfectarGarantia160()");
		     LogRegiparams.put("ano_prese", (String)SunatStringUtils.toStringObj((Integer) variablesIngreso.get("annEnvio")));
		     LogRegiparams.put("nume_orden",(String)SunatStringUtils.toStringObj((Long) variablesIngreso.get("numEnvio")));
		     LogRegiService logRegiService = (LogRegiService)fabricaDeServicios.getService("garantia.logRegiService");
		     logRegiService.grabaLogGarantia(LogRegiparams,params);  
	     }
	     // DZC -Fin
	    
	    if(resultado.substring(0, 1).equals("0")){
	    	resultado=resultado.substring(2);
	    	String [] errores= resultado.split("\\|");
	    	
	    	
	    	for(String err:errores){
	    		//lstErrores.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap(err));
	    		lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(err));
	    	}
	       
	    }	 
	    
	    Map paramsVal = new HashMap();
	    paramsVal.put("cRUC",declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()); // RUC del declarante
	    paramsVal.put("cADUANA",declaracion.getDua().getCodaduanaorden());
	    paramsVal.put("cANO",SunatDateUtils.getCurrentIntegerDate().toString().substring(0, 4));// es el año actual
	    paramsVal.put("cREGIMEN",declaracion.getDua().getCodregimen());
	    paramsVal.put("cNUMERO",declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
	     //Confirmar con Elsa si el tipodesp es el mismo que en la numeracion.
	    paramsVal.put("cMODULO",modulo);
	    if(declaracion.getDua().getFecdeclaracion()!=null){	    	
	    	paramsVal.put("nFECNUMERA", SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion()));
	    	paramsVal.put("nFECRECTI", SunatDateUtils.getCurrentIntegerDate());
	    }else{
	    	paramsVal.put("nFECNUMERA", 0);
	    	paramsVal.put("nFECRECTI", 0);
	    }
	    
	    
	     
//	    resultado=(String)NumeracionServiceImpl.getInstance().getPagarantiaDAO().consultarFechaVencimientoGarantia(paramsVal);
	    resultado=(String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).consultarFechaVencimientoGarantia(paramsVal);
	    if(resultado.substring(0, 1).equals("0")){
	    	resultado=resultado.substring(2);
	    	String [] errores= resultado.split("\\|");
	    	for(String err:errores){
	    		boolean valErrorDuplica = false;
	    		for(int i=0; i<lstErrores.size(); i++)
	    		{ 	Map<String, Object> mapaTemp = (Map) lstErrores.get(i);
	    			if(mapaTemp.get("codError").toString().equals(err)) {
	    				valErrorDuplica=true;
	    			}
	    		}
				if (valErrorDuplica==false) {
	    		//lstErrores.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap(err));
	    		lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(err));
	    	}
	    }	
	    }	
	    
	    return 	lstErrores;
	    
		
	}
	


	/*
	 * La imputacion para el caso de la regularizacion se aplica cuando se cumplen los siguientes casos 1. Que tenga la fecha de vencimiento
	 * de pago igual a 29991231 del formato C 2. Que la dua este cancelada
 * 
	 * Cuando la dua es anticipada o urgente y tiene la fecha de vencimiento de pago igual a 29991231 y no hay errores en manifiestos y
	 * cuando la dua no esté garantizada, ejecutar imputación. Guardar una variable de sesion "imputable"
	 */
	private boolean verificarAplicaImputacionRegularizacion(Declaracion declaracion,Map<String,Object> variablesIngreso) throws Exception{
		  boolean aplicaImputacion=false;
		// caso 1 : que tenga fecha de vencimiento de pago 29991231 el formato C
        boolean fechaVencimiento=false;
        boolean cancelada=false;
        DeudaDocum deudaParam=new DeudaDocum();
        deudaParam.setNumCorredoc(declaracion.getDua().getNumcorredoc());
        Integer numReLiq=0;
        //List<DeudaDocum> lstDeuda= RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(deudaParam);
        List<DeudaDocum> lstDeuda= ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(deudaParam);
       
        if(!CollectionUtils.isEmpty(lstDeuda)){
        	for(DeudaDocum deuda:lstDeuda){
        		if (SunatDateUtils.getIntegerFromDate(deuda.getFecVenc())==29991231 && ("01".equals(deuda.getCodTipdeuda()) || "02".equals(deuda.getCodTipdeuda())) ){
        			fechaVencimiento=true;
        			break;
        		}
        		if ("01".equals(deuda.getCodTipdeuda())){ // formato C
        			if (deuda.getNumReliq()>numReLiq){
        				cancelada=false;
        				numReLiq=deuda.getNumReliq();
        				if (SunatNumberUtils.isGreaterOrEqualsThanParam(deuda.getMtoPagado(), deuda.getMtoDeuda())){
        					cancelada=true;
        				}
        			}
        		}
        		if ("02".equals(deuda.getCodTipdeuda())){ // LC
        	
        				if (SunatNumberUtils.isGreaterOrEqualsThanParam(deuda.getMtoPagado(), deuda.getMtoDeuda())){
        					cancelada=true;
        				}
        			
        		}
        		}
        	}       
        
        // caso 2 : que la dua este cancelada
        
         // caso 2
       /* List<Map<String,?>> resultadoError = new ArrayList<Map<String,?>>();
        boolean validacionOkManifiesto=false;
		 resultadoError= RectificacionServiceImpl.getInstance().getValidaciongeneralservice().validarDatado(declaracion, variablesIngreso);
			if(CollectionUtils.isEmpty(resultadoError)){
				validacionOkManifiesto=true;
			}
		
         // caso 3
        boolean duaNoGarantizada=false;
        String codGarantia ="";
    	DatoPago pago=declaracion.getDua().getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		codGarantia=decla!=null?decla.getCodgarantia():null;
        if (codGarantia==null && "".equals(codGarantia)){
        	duaNoGarantizada=true;
        }
        */
         // en este caso aplica imputacion para la regularizacion
         if(fechaVencimiento && cancelada){
        	 aplicaImputacion=true;
         }			
         
       return aplicaImputacion;
	}
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#imputacion(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.util.Map, java.util.Map)
	 */
	@Override
	public BigDecimal imputacion(Declaracion declaracion,Map<String,Object> variablesIngreso
			, Map<String,Object> deudadiferencial ) throws Exception{

		     //Map<String,Object> mapImputacion=RectificacionServiceImpl.getInstance().getImputacionService().Spgenimputacion(declaracion, deudadiferencial);
		     Map<String,Object> mapImputacion=((ImputacionService)fabricaDeServicios.getService("imputacionServiceDef")).Spgenimputacion(declaracion, deudadiferencial);
        	 Map<String,BigDecimal> mapSaldo= (Map<String,BigDecimal>) mapImputacion.get("detalleSaldoPendienteImputacion");
        	 actualizarDiferenciaTributaria(deudadiferencial,mapImputacion);
        	// BigDecimal totalSaldo=RectificacionServiceImpl.getInstance().getImputacionService().sumarSaldoImpuestos(mapSaldo);
        	 BigDecimal totalSaldo=((ImputacionService)fabricaDeServicios.getService("imputacionServiceDef")).sumarSaldoImpuestos(mapSaldo);
        	 
        	 return totalSaldo;
	}
	
	private List<Map<String,String>> autoLiquidacionTributoATributo(Declaracion declaracion
			,Map<String,Object> deudadiferencial,Map<String,Object> variablesIngreso){
		/* se valida, si el usuario transmitió  una autoliquidación ,si es así esta se valida contra 
		 * los montos diferenciales (tributo por tributo)determinados en la regla anterior(Calcadeudo)  .
		En el caso que dicha autoliquidación no cubre todos los  tributos y recargos el sistema rechazara el envío*/   
		
			List<Map<String,String>> resultadoError = new ArrayList<Map<String,String>>();
			List<Map<String,String>> catalogoTributos = new ArrayList<Map<String,String>>();
			Map<String,BigDecimal>  mpTributos=new HashMap<String, BigDecimal>();
			Map<String,BigDecimal>  mpTributosTmp=new HashMap<String, BigDecimal>();
			Map<String,Object> mapDua=  obtenerMapDua(declaracion);
			String codcanal=(String)mapDua.get("codcanal");
			boolean encontro=false;     
			
			String listaConceptosImputados = (String)variablesIngreso.get("listaConceptosImputados");
			
			/*  se genera un map del tipo [(Tributo1, Monto1), (Tributo2,Monto2).....]*/
			//resultadoError.addAll(RectificacionServiceImpl.getInstance().getFuncionesService().verificarTributosAutoliquidacion(declaracion, variablesIngreso));
			resultadoError.addAll(((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).verificarTributosAutoliquidacion(declaracion, variablesIngreso));

			
			if (CollectionUtils.isEmpty(resultadoError)) // si no hay errores
				//mpTributos= RectificacionServiceImpl.getInstance().getFuncionesService().obtenerTributosAutoliquidacion(declaracion, variablesIngreso);
				mpTributos= ((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).obtenerTributosAutoliquidacion(declaracion, variablesIngreso);
			
			/*COMPARACION */		
			// si se genero un map de tributo no vacio , se procede a la comparacion
			if(!CollectionUtils.isEmpty(mpTributos)){
				/*3.- Comparar el MAP1(diferencial) vs el MAP2 (detaliq)	Tributo por Tributo Verificar que se cumpla 
				      MAP2.monto>=MAP1.monto .	Es decir el total pagado por tributo debe ser mayor al tributo a pagar 
				  4.- Si en algún tributo no se cumple emitir un mensaje 
				   Tributo  ".."  Pagado = ####.00   cancelado #### .00  Revise*/
				
				// si no esta vacio el mapa de deuda diferencial se procede a comparar
				// completamos el mapTributos con los tributos faltantes n cero.
				mpTributosTmp=mpTributos;
				//FJP 06/05/2011 
				//los codigos de tributos diferenciados para la aduana de chimbote son diferentes que para el resto de aduanas 
				if(Constants.COD_ADUANA_CHIMBOTE.equals(declaracion.getDua().getCodaduanaorden())){
					//catalogoTributos=RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getElementosCat(Constants.TRIBUTOS_DIFERENCIADOS_CHIMBOTE);
					catalogoTributos=((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementosCat(Constants.TRIBUTOS_DIFERENCIADOS_CHIMBOTE);
				}else{
					//catalogoTributos=RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getElementosCat(Constants.TRIBUTOS_DIFERENCIADOS);
					catalogoTributos=((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementosCat(Constants.TRIBUTOS_DIFERENCIADOS);
				}
				
					for(Map<String,String> tributoBD:catalogoTributos){
						encontro=false;
						for(String codTribTx:mpTributosTmp.keySet()){
							if (tributoBD.get("cod_datacat").equals(codTribTx)){
								encontro=true;
							}
						}
						if (!encontro){// grabar el nuev tributo 
							mpTributos.put(tributoBD.get("cod_datacat"),BigDecimal.ZERO);
						}
					}
				
		
				if(!CollectionUtils.isEmpty(deudadiferencial)){
					for(String codTributo:mpTributos.keySet()){
						String desCortaTributo=null;
						
						//Si el tributo ya se encuentra en la lista de conceptos imputados ignorarlo
						if(SunatStringUtils.isStringInList(codTributo, listaConceptosImputados))
							continue;
						
						//DataCatalogo datacatalogoTributo= RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_CONCEPTOS_COBRO_LC, codTributo);
						//FJP 06/05/2011
						// los codigos de tributos diferenciados para la aduana de chimbote son diferentes que para el resto de aduanas
						DataCatalogo datacatalogoTributo = null;
						if(Constants.COD_ADUANA_CHIMBOTE.equals(declaracion.getDua().getCodaduanaorden())){
							
							//datacatalogoTributo= RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(Constants.TRIBUTOS_DIFERENCIADOS_CHIMBOTE, codTributo);
							datacatalogoTributo=((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(Constants.TRIBUTOS_DIFERENCIADOS_CHIMBOTE, codTributo);
						}else{
							
							//datacatalogoTributo= RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(Constants.TRIBUTOS_DIFERENCIADOS, codTributo);
							datacatalogoTributo=((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(Constants.TRIBUTOS_DIFERENCIADOS, codTributo);
						}
						
						desCortaTributo=datacatalogoTributo != null && datacatalogoTributo.getDesCorta()!=null?datacatalogoTributo.getDesCorta():"";
						// con la descripcion corta se va a el mapa de diferenciales
						BigDecimal montoTributoDif= (BigDecimal) deudadiferencial.get(desCortaTributo);
						BigDecimal montoTributocancela=(BigDecimal)mpTributos.get(codTributo);
						if(montoTributoDif!=null && montoTributocancela!=null){// considerarrrr 
							// si el monto diferencial calculado , es menor al monto cancelado , se genera error
							if(SunatNumberUtils.isLessThanParam(montoTributocancela,montoTributoDif )){// si el montotributodif es mayor al monto cancelado rechaza
								String mensaje  ="TRIBUTO: "+ datacatalogoTributo.getDesDatacat() +", CALCULADO: "+montoTributoDif+ " CANCELADO: "+montoTributocancela+". REVISE";
								// si es antes de canal es error
								if(!StringUtils.hasText(codcanal)){
									//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30447", mensaje));
									resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30447", new String[]{mensaje}));
								}
								// si es despues es warnig
								else{ // el componente catalohelper no añade errores del tipo warnig
									//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30447", mensaje));
									resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30447",new String[]{mensaje}));
								}
							}
						}else if (montoTributoDif!=null && montoTributocancela==null){// si se identifica un diferencial y no se ha cancelado se envia el error
							String mensaje  ="TRIBUTO: "+ datacatalogoTributo.getDesDatacat() +", CALCULADO: "+montoTributoDif+ " CANCELADO: 0 REVISE";
							//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30447", mensaje));
							resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30447",new String[]{mensaje}));
						}
					}
				}
			}
	        return resultadoError;
	}

	
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#infoautoliquidacion(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.util.Map, java.util.Map)
	 */		
	/*@ServicioAnnot(tipo="V",codServicio=3027, descServicio="valida la autoliquidacion contra los montos diferenciales calculados")
	@ServInstDetAnnot(tipoRpta={1,1,1},nomAtr={"declaracion","deudadiferencial","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=3027,numSecEjec=25,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")*/
	@Override
	public List<Map<String,String>> infoautoliquidacion(Declaracion declaracion
			,Map<String,Object> deudaCalculada,Map<String,Object> variablesIngreso) throws Exception{
		     
		    List<Map<String,String>> resultadoError = new ArrayList<Map<String,String>>();
	        resultadoError.addAll(autoLiquidacionTributoATributo(declaracion, deudaCalculada,variablesIngreso));
	         
	        return resultadoError;
		}

	
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#calculoTotalTributo(java.util.Map, int)
	 */
	@Override
	public BigDecimal calculoTotalTributo(	Map<String,Object> deudadiferencial,int tipoLiqui	){
		BigDecimal montoTributoTotalDolares=new BigDecimal(0);
		BigDecimal montoTributoTotalSoles=new BigDecimal(0);
		BigDecimal montoTributoTotalSolesTC=new BigDecimal(0);
		BigDecimal montoAcumuladoDolares=new BigDecimal(0);
		Map<String,Object> mapCambio1=new HashMap<String,Object>();
		// SE VERIFICA SI TIENE SALDO 
		if(!CollectionUtils.isEmpty(deudadiferencial)){
			if(tipoLiqui==1){ // reliquidacion total flag 
				montoTributoTotalDolares= (BigDecimal) deudadiferencial.get("MTO_TOTAL_ACUMULADO"); // el total recalculado
				montoTributoTotalSoles= (BigDecimal) deudadiferencial.get("MTO_TOTAL_ACUMULADO_SOL");

		    }
			else if(tipoLiqui==2) {// diferencial
				montoTributoTotalDolares= (BigDecimal) deudadiferencial.get("MTO_TOTAL"); // el diferencial
				montoTributoTotalSoles= (BigDecimal) deudadiferencial.get("MTO_TOTAL_SOL");
				
			}
			mapCambio1.put("fingreso", SunatDateUtils.getIntegerFromDate((Date)deudadiferencial.get("FEC_NUMDOCLIQ")));
			mapCambio1.put("cmoneda", "USD");
//			Cambio1 cambio1=NumeracionServiceImpl.getInstance().getCambio1DAO().findByPK(mapCambio1);
			mapCambio1.put("ayudaID", "Cambio1");
			Cambio1 cambio1 = (Cambio1)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).buscarObject(mapCambio1);
			//montoTributoTotalSolesTC=montoTributoTotalSoles.divide(cambio1.getPventa());
			montoTributoTotalSolesTC=SunatNumberUtils.divide(montoTributoTotalSoles, cambio1.getPventa(), 6);
		}
		montoAcumuladoDolares=montoTributoTotalDolares.add(montoTributoTotalSolesTC);
		 return montoAcumuladoDolares ;
	}

	
	private BigDecimal obtenerTotalAutoliquidado(List<Liquida> lstAutoliquidacion){
		
		BigDecimal totalAutoliq=BigDecimal.ZERO;
		if(!CollectionUtils.isEmpty(lstAutoliquidacion)){
			for(Liquida autoliquidacion:lstAutoliquidacion){
				totalAutoliq=BigDecimal.ZERO;
				if(SunatStringUtils.isEqualTo(autoliquidacion.getRlcodmon(), "D")){// segun hernan se tiene que convertir a soles
				Map<String,Object> params=new HashMap<String,Object>();
				params.put("fingreso",autoliquidacion.getRlfecliq());
				params.put("cmoneda", "USD");
			
//				Cambio1 cambio1 = FormatoAServiceImpl.getInstance().getCambio1DAO().findByPK(params);
				params.put("ayudaID", "Cambio1");
				Cambio1 cambio1 = (Cambio1)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).buscarObject(params);
				
				if (cambio1!=null){
					BigDecimal dolarVenta=cambio1.getPcompra();
					BigDecimal soles=SunatNumberUtils.multiply(autoliquidacion.getRldmontot(), dolarVenta);
					totalAutoliq=SunatNumberUtils.sum(totalAutoliq, soles);
					}
				
				}else
					totalAutoliq=SunatNumberUtils.sum(totalAutoliq,autoliquidacion.getRlsmontot());				
			}
		}
		
		return totalAutoliq;
		
	}  
	
	private List<Liquida> obtenerAutoliquidacion(Declaracion declaracion,String strLstTipLiqu){

		List<Liquida> listaAutoliquidaciones=new ArrayList<Liquida>();	    
		HashMap mapCabDeclaraActual=new HashMap();
		mapCabDeclaraActual.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
		mapCabDeclaraActual.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
		mapCabDeclaraActual.put("NUM_DECLARACION", declaracion.getNumdeclRef().getNumcorre());
		mapCabDeclaraActual.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
		mapCabDeclaraActual.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());		
		
		// obtener autoliquidaciones desde base de datos
		//List<Liquida> listaAutoliquidacionesBD=RectificacionServiceImpl.getInstance().getLiquidaDeclaracionService().obtenerAutoliquidaciones(mapCabDeclaraActual);
		List<Liquida> listaAutoliquidacionesBD=((LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService")).obtenerAutoliquidaciones(mapCabDeclaraActual);
		// obtener las autoliquidaciones declaradas
		
		List<DatoOtroDocSoporte> lstAutLiquiDeclarada=  getListDocSoporteByTypoProceso(declaracion.getDua(),ConstantesDataCatalogo.TIPO_DOC_AUTOLIQUIDACION);

		
		 if(!CollectionUtils.isEmpty(listaAutoliquidacionesBD) && !CollectionUtils.isEmpty(lstAutLiquiDeclarada) ){
			 for(DatoOtroDocSoporte autoliqDec:lstAutLiquiDeclarada){
				 for(Liquida liq:listaAutoliquidacionesBD){
					 // si es del tipo 0026 y el nro liq , año y aduana coincide con lo declarado,
					 //se genera una lista de autoliquidaciones validas
					 /*branch ingreso 2011-009 hosorio 23/06/2011 inicio*/
					 //if(liq.getRltipliq().equals("0026")
					 if(SunatStringUtils.isStringInList(liq.getRltipliq(), strLstTipLiqu)   
					/*branch ingreso 2011-009 hosorio 23/06/2011*/		 
							 && liq.getRlnroliq().equals(SunatStringUtils.lpad(autoliqDec.getNumdocasoc(), 6, '0'))
							 && liq.getRlano().equals(autoliqDec.getAnndocasoc().toString().substring(2, 4))
							 && liq.getRladuana().equals(declaracion.getDua().getCodaduanaorden())
					         ) 
					 {
						 listaAutoliquidaciones.add(liq);
					 }
					 
				 }
				 /*branch ingreso-2011-009 hosorio inicio 23/05/2011 */
				 /*
				 if (!encontro){
					 Liquida flag=new Liquida();
					 flag.setRlnroliq(autoliqDec.getNumdocasoc());
					 flag.setFlag("ERROR");
					 listaAutoliquidacionesError.add(flag);
				 }
				 */
				 /*branch ingreso-2011-009 hosorio fin */
				 
			 }
			 /*branch ingreso-2011-009 hosorio inicio 23/05/2011 */	 
		 }/*
		 }else if (CollectionUtils.isEmpty(listaAutoliquidacionesBD) && !CollectionUtils.isEmpty(lstAutLiquiDeclarada)){
			 for(DatoOtroDocSoporte autoliqDec:lstAutLiquiDeclarada){
			
				 Liquida flag=new Liquida();
				 flag.setRlnroliq(autoliqDec.getNumdocasoc());
				 flag.setFlag("ERROR");
				 listaAutoliquidacionesError.add(flag);
			 } 
		 }
		 */
		 /*
		 if (!CollectionUtils.isEmpty(listaAutoliquidacionesError)){// tiene errores
			 return listaAutoliquidacionesError;
		 }else{
			 return listaAutoliquidaciones;
		 }
		 */
		 return listaAutoliquidaciones;
		 /*branch ingreso-2011-009 hosorio fin 23/05/2011 */
       
	}
	
	
	private void actualizarDiferenciaTributaria(Map<String,Object> deudaDiferencialCalculada
			,Map<String,Object> mapImputacion ){
       /* 
	  if(!CollectionUtils.isEmpty(saldoDeuda)){
		  for(String tributo:deudaDiferencialCalculada.keySet()){
			  BigDecimal nuevoMonto=saldoDeuda.get(tributo);
			  if(nuevoMonto!=null){
				  deudaDiferencialCalculada.put(tributo, nuevoMonto);
			  }
		  }
	  }	*/
		
		Map<Long,Map<String,BigDecimal>> detalleMontosImputado= (Map<Long,Map<String,BigDecimal>>) mapImputacion.get("detalleMontosImputado");
		//BigDecimal totalInteresImputado=RectificacionServiceImpl.getInstance().getImputacionService().sumarTotalImputadoxTributo(detalleMontosImputado, "INTERES") ;
		BigDecimal totalInteresImputado=((ImputacionService)fabricaDeServicios.getService("imputacionServiceDef")).sumarTotalImputadoxTributo(detalleMontosImputado, "INTERES") ;
		
		deudaDiferencialCalculada.put("INTERES", totalInteresImputado); // ES EL INTERES CALCULADO EN LA IMPUTACION
		Map<String,BigDecimal> mapSaldo= (Map<String,BigDecimal>) mapImputacion.get("detalleSaldoPendienteImputacion");
		//BigDecimal totalSaldo=RectificacionServiceImpl.getInstance().getImputacionService().sumarSaldoImpuestos(mapSaldo);
		BigDecimal totalSaldo=((ImputacionService)fabricaDeServicios.getService("imputacionServiceDef")).sumarSaldoImpuestos(mapSaldo);
		mapSaldo.put("MTO_TOTAL", totalSaldo);
		deudaDiferencialCalculada.put("detalleSaldoPendienteImputacion", mapSaldo);
		
		
		
	}
	/*pase 580*/
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#obtenerMapDua(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion)
	 */
	@Override
	public Map<String,Object> obtenerMapDua(Declaracion declaracion){
		
	    Map<String,Object> params= new HashMap<String, Object>();
	    /*estos datos son clabes de la dua*/
	    params.put("codigoAduana", declaracion.getNumdeclRef().getCodaduana());
	    params.put("annoPresentacion", declaracion.getNumdeclRef().getAnnprese());
	    params.put("codigoRegimen", declaracion.getNumdeclRef().getCodregimen());
	    params.put("numeroDeclaracion", declaracion.getNumdeclRef().getNumcorre());
		//List<Map<String,Object>> lstdua= RectificacionServiceImpl.getInstance().getCabdeclaraDAO().listCabDeclaraMapByParameterMap(params);
	    List<Map<String,Object>> lstdua=((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).listCabDeclaraMapByParameterMap(params);
		
		if(!CollectionUtils.isEmpty(lstdua))
			return lstdua.get(0); 
		
	    return null;
		
	}


	protected List<DatoOtroDocSoporte> getListDocSoporteByTypoProceso(DUA dua,String codTipoProceso)
	{
		List<DatoOtroDocSoporte> lista=new ArrayList<DatoOtroDocSoporte>(); 
		
		if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
			for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
				if(StringUtils.hasText(soporte.getCodtipoproceso()) && soporte.getCodtipoproceso()
						.equals(codTipoProceso) ){
					 lista.add(soporte);
				}
			}
		}
		return lista;
	}		
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#validarLiquidacionRegularizacionAntiguo(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.util.Map)
	 */
	@Override
	@ServicioAnnot(tipo="V",codServicio=3311, descServicio="Servicio de Validacion de Liquidacion de la Regularizacion")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=3311,numSecEjec=3,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public List<Map<String,String>>  validarLiquidacionRegularizacionAntiguo( Declaracion declaracion,Map<String,Object> variablesIngreso) throws Exception{
		List<Map<String,String>> resultadoError = new ArrayList<Map<String,String>>();
	    BigDecimal totalMontoTributo=new BigDecimal(0);
	    String numeroDocumentoIdentidadSender = (String) variablesIngreso .get("numeroDocumentoIdentidadSender");
		Map<String,Object> deudadiferencial=(Map<String,Object>)variablesIngreso.get("deudadiferencial");
		String tipoDesp=(String)variablesIngreso.get("tipoDesp");
		DatoPago pago=declaracion.getDua().getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		//String xcbco_pael=decla!=null?decla.getCodbcopagoelec():null;
		//String xccta_pael=decla!=null?decla.getNumctapagoelec():null;
		String codGarantia=decla!=null?decla.getCodgarantia():null;	
		if(declaracion.getDua().getNumcorredoc()!=null){
			if(!CollectionUtils.isEmpty(deudadiferencial) && 
					SunatNumberUtils.isGreaterThanZero((BigDecimal)deudadiferencial.get("MTO_TOTAL"))){ // si hay deuda
				
					boolean aplicaImputacion=verificarAplicaImputacionRegularizacion(declaracion,variablesIngreso);
					variablesIngreso.put("aplicaImputacion", aplicaImputacion);
					if(aplicaImputacion){
						 // se imputa y se actualiza la deuda diferencial con los nuevos saldos
						/*
						1.- En caso la deuda resultante seha mayor de Cero 
						Hacer 
						1.1 .- Verificar si el usuario envia en el Segmento Documentos de Soporte  un documento de Soporte Tipo_proce='9' autoliquidacion 
						1.2 .- Si no ha enviado nada Emitir el Error de Indicando que faltan tributos por Pagar 
						1.3 .- De lo contrario Tomar los datos de la liquidacion enviada y buscar la informacion en la tabla Liquida
						1.4 .- Validar el monto pagado en dicha liquidacion contra el monto de deuda , Si la deuda final es 0 proseguir con el proceso de manera ok (sin errores)
						1.5 .- De lo contrario emitir error 
						 */
						
						
						 BigDecimal totalSaldoImputacion= imputacion(declaracion, variablesIngreso, deudadiferencial);
						 if(SunatNumberUtils.isGreaterThanZero(totalSaldoImputacion)){
							// si tiene autoliquidacion
							//if(RectificacionServiceImpl.getInstance().getFuncionesService().isAutoliquidado(declaracion.getDua())){
							if(((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isAutoliquidado(declaracion.getDua())){
			            		List<Liquida>  lstAutoliquidacion = (List<Liquida>)variablesIngreso.get("lstAutoliquidaciones");
			            		BigDecimal totalAutoliq=obtenerTotalAutoliquidado(lstAutoliquidacion);
			            			if(totalAutoliq.compareTo(totalSaldoImputacion)<0){
										 //resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30279","FALTAN TRIBUTOS POR PAGAR"));
										 resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30279",new String[]{"FALTAN TRIBUTOS POR PAGAR"}));
			            			}
			            			else{
			            				// este proceso lo hace el componente de juan por eso se comentaa
			            				//variablesIngreso.put("grabarPagoAutoliquidacion", true);
			            			}
							}
							else{
								//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30279","FALTAN TRIBUTOS POR PAGAR"));
								resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30279",new String[]{"FALTAN TRIBUTOS POR PAGAR"}));
							}
						 }
					}else{
			
			
	    if (!declaracion.getDua().getCodregimen().equals("10")){// Si no es importtacion definitiva
	    	// recalculan los tributos
	    	  totalMontoTributo=calculoTotalTributo(deudadiferencial, 1); // el flag de 1 lo uso para obtener el total reliquidado
				
	    	if (SunatStringUtils.isEmpty( codGarantia ) ){ // si no tiene garantia 160 se rechaza
	    		// genera rechazao
	    		//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30280","DEBE PRESENTAR GARANTIA"));
	    		resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30280",new String[]{"DEBE PRESENTAR GARANTIA"}));
	    		
	    	}else{// si tiene garantia 160 se verifica que cubra la garantia
	    		resultadoError =validarAfectarGarantia160(declaracion, totalMontoTributo, " ", SunatDateUtils.getCurrentIntegerDate(), numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);
			    // si no hay errores
				if(CollectionUtils.isEmpty(resultadoError)){
					  // marca para afectacion de garantia ( Desafectar y volver a afectar	 la garantía) 
			    	  variablesIngreso.put("marcaDesafectarAfectarGarantia", true);
					  variablesIngreso.put("montoAfectar", totalMontoTributo);					    	
			    }
				else{
			       // si hay errores en la garantia , no la podra afectar 		
					//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30364","LA GARANTIA NO PUEDE SER AFECTADA"));
					resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30364",new String[]{"LA GARANTIA NO PUEDE SER AFECTADA"}));
				}
	    	}
	    }else{// Si es importacion temporal
	    	//Calculo de tributos diferenciales
	    	 totalMontoTributo=calculoTotalTributo(deudadiferencial, 2); // el flag de 2 lo uso para obtener el total diferencia
	    	// si tiene autoliquidacion
				//if(RectificacionServiceImpl.getInstance().getFuncionesService().isAutoliquidado(declaracion.getDua())){
				if(((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isAutoliquidado(declaracion.getDua())){
					// valida los montos tributo por tributo (Exigir aautoliquidacion)
					resultadoError=infoautoliquidacion(declaracion, deudadiferencial,variablesIngreso);
				}
				else{ // si no tiene auto liquidacion
					if (! SunatStringUtils.isEmpty( codGarantia ) ){ // si tiene garantia 160 
						// si tiene garantia 160 se verifica que cubra la garantia
			    		resultadoError =validarAfectarGarantia160(declaracion, totalMontoTributo, " ",SunatDateUtils.getCurrentIntegerDate() , numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);
			    		// si no hay errores
						if(CollectionUtils.isEmpty(resultadoError)){
							  // marca para afectacion de garantia ( Desafectar y volver a afectar	 la garantía) 
					    	  variablesIngreso.put("marcaDesafectarAfectarGarantia", true);
							  variablesIngreso.put("montoAfectar", totalMontoTributo);	
							  if (declaracion.getDua().getCodmodalidad().equals("10")){// anticipado
								  variablesIngreso.put("marcaGenerarLC", true);
						    	  variablesIngreso.put("marcaAfectarGarantiaLC", true);	
							  }
							  
					    }
						else{
					       // si hay errores en la garantia , no la podra afectar 		
							//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30364","LA GARANTIA NO PUEDE SER AFECTADA"));
							resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30364",new String[]{"LA GARANTIA NO PUEDE SER AFECTADA"}));
						}
					}else{// Si no tiene garantia o la garantia no cubre
						// es anticipado
						if (declaracion.getDua().getCodmodalidad().equals("10")){// anticipado
							// exigir autoliquidacion
							// valida los montos tributo por tributo (Exigir aautoliquidacion)
							resultadoError=infoautoliquidacion(declaracion, deudadiferencial,variablesIngreso);
						}
					}
				}
	    }
		}// fin proceso de validacion que no incluye imputacion
			}
		}
		return resultadoError;
	}
	
	/**
	 * Valida imputacion regularización.
	 * 
	 * @param declaracion Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return lista de errorres
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,String>>  validaImputacionRegularizacion(Declaracion declaracion,Map<String,Object> variablesIngreso){
		List<Map<String,String>> listErr = new ArrayList<Map<String,String>>();
		//Manifiesto manifiesto= RectificacionServiceImpl.getInstance().getFuncionesService().getManifiestoNASigad(declaracion);
		Manifiesto manifiesto= ((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).getManifiestoNASigad(declaracion);
		Map<Object, Object> mapManif = null;
		if(manifiesto!=null){
			mapManif = new HashMap<Object, Object>();
			mapManif.put("fechaEfectivaDeLlegada", manifiesto.getFechaEfectivaDeLlegada());
			mapManif.put("fechaProgramadaLlegada", manifiesto.getFechaProgramadaLlegada());
			mapManif.put("fechaTerminoDeDescarga", manifiesto.getFechaTerminoDeDescarga());
		}
		
		Map<String,Object> deudadiferencial=(Map<String,Object>)variablesIngreso.get("deudadiferencial");
		//Date fecVenciPago=RectificacionServiceImpl.getInstance().getFuncionesService().getFechaVencimientoPagoDespacho(declaracion,mapManif);
		Date fecVenciPago=((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).getFechaVencimientoPagoDespacho(declaracion,mapManif);
		String listaConceptosImputados = "";
		String codGarantia = null;		
		try {
			codGarantia=declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
		} catch (Exception e) {		
		}
		
		List<Liquida>  lstAutoliquidaciones = (List<Liquida>)variablesIngreso.get("lstAutoliquidaciones");
		
		Map<String, Object> mapCabDeclara = new HashMap<String, Object>();
		mapCabDeclara.put("numeroCorrelativo", declaracion.getDua().getNumcorredoc());
		
		String codCatalogotributo="TRI";
		if(Constants.COD_ADUANA_CHIMBOTE.equals(declaracion.getDua().getCodaduanaorden()))
			codCatalogotributo=Constants.TRIBUTOS_DIFERENCIADOS_CHIMBOTE;

		if (SunatStringUtils.isEmptyTrim(codGarantia))
			mapCabDeclara.put("numeroCtaCte", codGarantia); 
		
		mapCabDeclara.put("codigoRegimen", declaracion.getDua().getCodregimen());
		mapCabDeclara.put("fechaTerminoDescarga", fecVenciPago);
		mapCabDeclara.put("fechaLlegada", declaracion.getDua().getManifiesto().getFectermino());	
		mapCabDeclara.put("codTransaccion", variablesIngreso.get("codTransaccion").toString().substring(2,4) );

		if(!CollectionUtils.isEmpty(deudadiferencial) && SunatStringUtils.isEmptyTrim(codGarantia)){
		
		//List<Map<String, Object>> conceptosImputados = RectificacionServiceImpl.getInstance().getImputacionService().calculaImputacion(
		List<Map<String, Object>> conceptosImputados = ((ImputacionService)fabricaDeServicios.getService("imputacionServiceDef")).calculaImputacion(
				declaracion.getDua().getCodaduanaorden() , mapCabDeclara, deudadiferencial);

			if(!CollectionUtils.isEmpty(conceptosImputados)){
			
				variablesIngreso.put("conceptosImputadosRectificacion", conceptosImputados);
				aplicarImputacionenDeuda(deudadiferencial,conceptosImputados);

					
				Map<String,BigDecimal> mpTributosAutoCanc=new HashMap<String, BigDecimal>();
				if (!CollectionUtils.isEmpty(lstAutoliquidaciones)){
					mpTributosAutoCanc=obtenerDetalleTributosAutoliquidado(lstAutoliquidaciones,codCatalogotributo);
						}
				listErr=autoLiquidacionTributoATributo(deudadiferencial,mpTributosAutoCanc,codCatalogotributo);
				if (!CollectionUtils.isEmpty(listErr)){							
					listErr.add(ResponseMapManager.getErrorResponseMap("30335", "DEBE PRESENTAR AUTOLIQUIDACION POR DIFERENCIA DE TRIBUTOS"));
					listErr.add(ResponseMapManager.getErrorResponseMap("30451",
								"LOS INTERESES SE COMPUTARAN A PARTIR DEL DIA SIGUIENTE DEL PAGO DE LA AUTOLIQUIDACION"));
					}
						
			 }
		}
		
		if(!SunatStringUtils.isEmpty(listaConceptosImputados))
			variablesIngreso.put("listaConceptosImputados", listaConceptosImputados);
		
		return listErr;
	}
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#validarLiquidacionRegularizacion(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	@Override
	@ServicioAnnot(tipo="V",codServicio=3311, descServicio="Servicio de Validacion de Liquidacion de la Regularizacion")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=3311,numSecEjec=3,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public List<Map<String,String>>  validarLiquidacionRegularizacion( Declaracion declaracion,Map<String,Object> variablesIngreso) throws Exception{
		List<Map<String,String>> resultadoError = new ArrayList<Map<String,String>>();
	    BigDecimal totalMontoTributo=new BigDecimal(0);
	    String numeroDocumentoIdentidadSender = (String) variablesIngreso .get("numeroDocumentoIdentidadSender");
		Map<String,Object> deudadiferencial=(Map<String,Object>)variablesIngreso.get("deudadiferencial");
		//RIN16
//   		List<Liquida>  lstAutoliquidacion = (List<Liquida>)variablesIngreso.get("lstAutoliquidaciones");
   		List<Map<String, Object>> listGarantiaGlobal =  new ArrayList<Map<String,Object>>();
   		List<Map<String, Object>> listGarantiaEspecifica =  new ArrayList<Map<String,Object>>();
   		DatoPago pago=declaracion.getDua().getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		//String xcbco_pael=decla!=null?decla.getCodbcopagoelec():null;
		//String xccta_pael=decla!=null?decla.getNumctapagoelec():null;
		String codGarantia=decla!=null?decla.getCodgarantia():null;	
		String tipoDesp=(String)variablesIngreso.get("tipoDesp");
		NumdeclRef numdeclRef = declaracion.getNumdeclRef(); 
		Date fechaConclusionDespa = (Date) variablesIngreso .get("fechaConclusionDespa");
		//PAS20145E220000623 - hsaenz - mtorralba 28/01/2015 - Inicio
		Date fechaVenConclusion = (Date) variablesIngreso .get("fechaVenConclusion");
		//PAS20145E220000623 - hsaenz - mtorralba 28/01/2015 - Fin

		Map<String,Object> params=new HashMap<String,Object>();
		//lstAutoliquidacion = (List<Liquida>)variablesIngreso.get("lstAutoliquidaciones");
		
   		if(declaracion.getDua().getNumcorredoc()!=null){
			if(!CollectionUtils.isEmpty(deudadiferencial) && 
					SunatNumberUtils.isGreaterThanZero((BigDecimal)deudadiferencial.get("MTO_TOTAL"))){ // Mayor diferencia de tributos
				totalMontoTributo=(BigDecimal)deudadiferencial.get("MTO_TOTAL");
				/*boolean aplicaImputacion=verificarAplicaImputacionRegularizacion(declaracion,variablesIngreso);
				variablesIngreso.put("aplicaImputacion", aplicaImputacion);
				if(aplicaImputacion){
					se imputa y se actualiza la deuda diferencial con los nuevos saldos
					 BigDecimal totalSaldoImputacion= imputacion(declaracion, variablesIngreso, deudadiferencial);
					 if(SunatNumberUtils.isGreaterThanZero(totalSaldoImputacion)){
						// si tiene autoliquidacion
						if(RectificacionServiceImpl.getInstance().getFuncionesService().isAutoliquidado(declaracion.getDua())){
		            		  
		            		  BigDecimal totalAutoliq=obtenerTotalAutoliquidado(lstAutoliquidacion);
		            		  if(totalAutoliq.compareTo(totalSaldoImputacion)<0){
									 resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30279",totalSaldoImputacion)); // AUTOLIQUIDACION NO CUBRE LA DEUDA: totalsaldoimputadcion
		            			}
		            			else{
		            				// este proceso lo hace el componente de juan por eso se comentaa
		            				//variablesIngreso.put("grabarPagoAutoliquidacion", true);
		            			}
						}
						else{
							resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30335","DEBE PRESENTAR AUTOLIQUIDACION DESPUES DE LEVANTE"));	// 
						}
					 }
				}else{*/
				if (SunatStringUtils.isEmpty( codGarantia ) ){ // si no tiene garantia 160 se rechaza
					if ("10".equals(declaracion.getDua().getCodregimen()) || "70".equals(declaracion.getDua().getCodregimen())){ // Si es impo definitiva o deposito
						 // exige autoliquidaciones
						// si tiene autoliquidacion
						 
						if(variablesIngreso.get("conceptosImputadosRectificacion")==null || 
								((List<Map<String,Object>>) variablesIngreso.get("conceptosImputadosRectificacion")).size()==0){
						//if(RectificacionServiceImpl.getInstance().getFuncionesService().isAutoliquidado(declaracion.getDua())){
							if(((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isAutoliquidado(declaracion.getDua())){
								// valida los montos tributo por tributo (Exigir aautoliquidacion)
								resultadoError.addAll(infoautoliquidacion(declaracion, deudadiferencial,variablesIngreso));
							}else{// Si no tiene autoliquidacion , emito rechazo
								//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30335","DEBE PRESENTAR AUTOLIQUIDACION DESPUES DE LEVANTE"));
								resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30335",new String[]{"DEBE PRESENTAR AUTOLIQUIDACION DESPUES DE LEVANTE"}));
								if("70".equals(declaracion.getDua().getCodregimen())){
									resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35275", new String[]{"Valor en aduanas supero las tres UIT, sirvase cancelar la tasa de despacho"}));
								}
								
							}
						}
						}else{// Si son admisiones temporales Reg 20 y 21
						// se deben de garantizar mediante garantias globales y especificas
						// Se consultara a las tablas de garantias globales y especificas para ver si tienen garantias activas
							// Si no tiene garantia ni global ni especifica sale el siguiente mensaje
							// 30/04/2016 Se homologa validacion con Procesos Automaticos -- DUAs de Admision Temporal tipo 02 (Ferias), 11 (Aeronaves-5 años) y 12 (Marina Mercante-5 años) no se garantizan
							if (!SunatStringUtils.include(declaracion.getDua().getCodtipoperacion(), new String[]{"2002","2011","2012"})){ //PAS20165E220200063
							params.put("CADUA_DOCAFI", numdeclRef.getCodaduana());
							params.put("FANNO_DOCAFI", numdeclRef.getAnnprese());
							params.put("CEST_ACCVIG", "00"); // activo
							params.put("CTIPO_DOCAFI", "01");// declaracion
							params.put("CEST_DOCAFI", "00");// activo
							params.put("CREG_DOCAFI", numdeclRef.getCodregimen());
							params.put("CTIPO_GLOESP", "0"); // 0: grantia global, 1: garantia especifica
							params.put("NUME_DOCAFI",SunatStringUtils.lpad(numdeclRef.getNumcorre(),6,'0'));
												 
							//listGarantiaGlobal=RectificacionServiceImpl.getInstance().getMovNGarantiaDAO().getGarantiasEspGlo(params);
							listGarantiaGlobal=((MovNGarantiaDAO)fabricaDeServicios.getService("movNGarantiaDAO")).getGarantiasEspGlo(params);
							
							params.put("CTIPO_GLOESP", "1"); // 0: grantia global, 1: garantia especif
							//listGarantiaEspecifica=RectificacionServiceImpl.getInstance().getMovNGarantiaDAO().getGarantiasEspGlo(params);
							listGarantiaEspecifica=((MovNGarantiaDAO)fabricaDeServicios.getService("movNGarantiaDAO")).getGarantiasEspGlo(params);
							
							if (listGarantiaGlobal.isEmpty() && listGarantiaEspecifica.isEmpty()){
								 //resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30446","DEBE PRESENTAR GARANTIA GLOBAL O ESPECIFICA"));
								resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30446",new String[]{"DEBE PRESENTAR GARANTIA GLOBAL O ESPECIFICA"}));
							}else{
								/* RBC - Pendiente de validacion, se debe averiguar que se debe de considerar como deuda.. 
								 * 1. La suma de todas las deudas totales 
								 * 2. La suma de las deudas totales menos los montos pagados
								 * 3. Se debe validar los montos de las deudas.
								 * Es mas complejo de lo que parece
								BigDecimal montoDeudaTotal = BigDecimal.ZERO;
								DeudaDocum tmpDeudaDocum = new DeudaDocum();
								tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
								List<DeudaDocum> listaDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);
								for (DeudaDocum deudaDocum : listaDeudaDocum) {
									montoDeudaTotal = montoDeudaTotal.add( deudaDocum.getMtoDeuda() );
								} 
 
								if(! CollectionUtils.isEmpty(listGarantiaGlobal))
									for(Map<String, Object> map : listGarantiaGlobal){
										BigDecimal montoGarantizado = SunatNumberUtils.toBigDecimal(map.get("VTVINCU_DOCAFI"));
										
										if( SunatNumberUtils.isLessThanParam(montoGarantizado, montoDeudaTotal) )
											resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30446","DEBE PRESENTAR GARANTIA GLOBAL O ESPECIFICA"));
									}
								
								if(! CollectionUtils.isEmpty(listGarantiaEspecifica))	
									for(Map<String, Object> map : listGarantiaEspecifica){
										BigDecimal montoGarantizado = SunatNumberUtils.toBigDecimal(map.get("VTVINCU_DOCAFI"));
										
										if( SunatNumberUtils.isLessThanParam(montoGarantizado, montoDeudaTotal) )
											resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30446","DEBE PRESENTAR GARANTIA GLOBAL O ESPECIFICA"));
									}
									*/
							}
						}	
					}
				}else{// si tiene garantia 160
					if ("10".equals(declaracion.getDua().getCodregimen())){ // Si es impo definitiva
						// validar que la garantia 160 cubra, esta vigente etc
						//PAS20145E220000623 - hsaenz - mtorralba 28/01/2015 - Inicio - Se cambia el parámetro fechaConclusionDespa por fechaVenConclusion
			    		//resultadoError =validarAfectarGarantia160(declaracion, totalMontoTributo, " ",  SunatDateUtils.getIntegerFromDate(fechaConclusionDespa), numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);
						resultadoError =validarAfectarGarantia160(declaracion, totalMontoTributo, " ",  SunatDateUtils.getIntegerFromDate(fechaVenConclusion), numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);
			    		//PAS20145E220000623 - hsaenz - mtorralba 28/01/2015 - Fin

			    		// si no hay errores
						if(CollectionUtils.isEmpty(resultadoError)){
							  // marca para afectacion de garantia ( Desafectar y volver a afectar	 la garantía) 
					    	  variablesIngreso.put("marcaDesafectarAfectarGarantia", true);
							  variablesIngreso.put("montoAfectar", totalMontoTributo);					    	
					    }
						// esta en el grabar liquidacion la reliquidacion
						else{
					       // si hay errores en la garantia , no la podra afectar 		
							//El SIGAD pedira autoliquidaciones
							//if(RectificacionServiceImpl.getInstance().getFuncionesService().isAutoliquidado(declaracion.getDua())){
							if(((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isAutoliquidado(declaracion.getDua())){
								// valida los montos tributo por tributo (Exigir aautoliquidacion)
									resultadoError=infoautoliquidacion(declaracion, deudadiferencial,variablesIngreso);
								}else{// Si no tiene autoliquidacion , emito rechazo
									//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30335","DEBE PRESENTAR AUTOLIQUIDACION DESPUES DE LEVANTE"));	
									resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30335"));
								}
							
						   }
						}else{// Si son admisiones temporales Reg 20 y 21
						// validara el pagarantia
							// validar que la garantia 160 cubra, esta vigente etc
				    		resultadoError =validarAfectarGarantia160(declaracion, totalMontoTributo, " ",  SunatDateUtils.getIntegerFromDate(fechaConclusionDespa), numeroDocumentoIdentidadSender, tipoDesp, "005",variablesIngreso);
						    // si no hay errores
							if(CollectionUtils.isEmpty(resultadoError)){
								  // marca para afectacion de garantia ( Desafectar y volver a afectar	 la garantía) 
						    	  variablesIngreso.put("marcaDesafectarAfectarGarantia", true);
								  variablesIngreso.put("montoAfectar", totalMontoTributo);					    	
						    }else{
							       // si hay errores en la garantia , no la podra afectar 		
								//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30364","LA GARANTIA NO PUEDE SER AFECTADA"));
						    	resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30364"));
							}
							
					}
					
				}
			}else{// Menor diferencia de tributos no hay deuda al contrario se le ha cobrado de mas
				if (!SunatStringUtils.isEmpty( codGarantia ) ){ // si tiene garantia 160 se regulariza normal
					if ("10".equals(declaracion.getDua().getCodregimen())){ // Si es impo definitiva
						// grabar liquidacion
					}
				}// sino tiene garantia 160 se regulariza normal
			}
   		}
		
		
		
		
		return resultadoError;
   		//KIBreturn new ArrayList<Map<String,String>>();
	}
	
	
	
	/**
	 * Retorna el valor de monto por pagar y monto auto liquidado.
	 * 
	 * @param codigoAduana codigo de la aduana dodne se registro la DUA
	 * @param codTributo String
	 * @param deudadiferencial Map<String,Object>
	 * @param tributosLiquidados Map
	 * @return  monto por pagar y monto auto liquidado
	 */
	private BigDecimal[] getMontoPorPagarYMontoAutoLiquidado(String codigoAduana, String codTributo, Map<String, Object> deudadiferencial, Map tributosLiquidados){
		//declaracion.getDua().getCodaduanaorden()
		
		//DataCatalogo datacatalogoTributo= RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_CONCEPTOS_COBRO_LC, codTributo);
		// los codigos de tributos diferenciados para la aduana de chimbote son diferentes que para el resto de aduanas
		//FJP 06/05/2011
		// se agrego el codigo de la aduana para seleccionar el catalgo de tributos diferenciados
		DataCatalogo datacatalogoTributo = null;
		if(Constants.COD_ADUANA_CHIMBOTE.equals(codigoAduana)){
			
			//datacatalogoTributo= RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(Constants.TRIBUTOS_DIFERENCIADOS_CHIMBOTE, codTributo);
			datacatalogoTributo= ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(Constants.TRIBUTOS_DIFERENCIADOS_CHIMBOTE, codTributo);
		}else{
			
			//datacatalogoTributo= RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(Constants.TRIBUTOS_DIFERENCIADOS, codTributo);
			datacatalogoTributo= ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(Constants.TRIBUTOS_DIFERENCIADOS, codTributo);
		}
		
		
		String desCortaTributo=datacatalogoTributo != null && datacatalogoTributo.getDesCorta()!=null?datacatalogoTributo.getDesCorta():"";
		
		BigDecimal montoTributoDif= SunatNumberUtils.toBigDecimal( deudadiferencial.get(desCortaTributo) );
		
		BigDecimal montoTributoCancelado = BigDecimal.ZERO;
		
		if(! CollectionUtils.isEmpty(tributosLiquidados))
			montoTributoCancelado= SunatNumberUtils.toBigDecimal( tributosLiquidados.get(codTributo) );
	
		return new BigDecimal[]{montoTributoDif, montoTributoCancelado};
	}



	/*hosorio inicio 11/04/2011*/
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#obtenerDeudaAnterior(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.lang.String, java.lang.String)
	 */
	@Override
	public Map<String,BigDecimal> obtenerDeudaAnterior(Declaracion declaracion,String codCatalogotributo,String codEstaAdmin){
		
		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		List<DeudaDocum> lstDeudaDocum=null;
		Map<String,BigDecimal> mpDeudaPendiente=new HashMap<String, BigDecimal>();
		BigDecimal bgDeudaDolar=BigDecimal.ZERO;
		BigDecimal bgDeudaSoles=BigDecimal.ZERO;
		tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());					
		tmpDeudaDocum.setCodEstpago("E");// Pendiente
		if (!SunatStringUtils.isEmptyTrim(codEstaAdmin)){
			tmpDeudaDocum.setCodEstadmin(codEstaAdmin);
		}
		
		//lstDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);
		lstDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);

		for(DeudaDocum deudaDocum:lstDeudaDocum){
			CabDeuda tmpCadDeuda = new CabDeuda();
			tmpCadDeuda.setNumCorredoc(declaracion.getDua().getNumcorredoc());
			tmpCadDeuda.setNumIdentdeuda(deudaDocum.getNumIdentdeuda());
			//List<CabDeuda> listaCabDeuda =RectificacionServiceImpl.getInstance().getCabDeudaDAO().selectByDeuda(tmpCadDeuda);
			List<CabDeuda> listaCabDeuda =((CabDeudaDAO)fabricaDeServicios.getService("cabDeudaDef")).selectByDeuda(tmpCadDeuda);
			String codMoneda =deudaDocum.getCodMoneda();
			codMoneda=codMoneda.equals("USD")?"D":"S";
			for(CabDeuda cadDeuda : listaCabDeuda){
				String codTributo =cadDeuda.getCodTributo();
				codTributo=codTributo.concat(codMoneda);
				BigDecimal mtoDeuda =cadDeuda.getMtoValpag();
				//DataCatalogo datacatalogoTributo = RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(codCatalogotributo, codTributo);
				DataCatalogo datacatalogoTributo = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(codCatalogotributo, codTributo);
		        String desCortaTributo = datacatalogoTributo != null && datacatalogoTributo.getDesCorta() != null ? datacatalogoTributo.getDesCorta()
				: "";
		        
		        mpDeudaPendiente.put(desCortaTributo, SunatNumberUtils.sum(mpDeudaPendiente.get(desCortaTributo), mtoDeuda));
		        
		        if(SunatStringUtils.isEqualTo(deudaDocum.getCodMoneda(), "USD")){
		        	bgDeudaDolar=SunatNumberUtils.sum(bgDeudaDolar, mtoDeuda);
		        }
		        else{
		        	bgDeudaSoles=SunatNumberUtils.sum(bgDeudaSoles, mtoDeuda);
		        }
			}// fOR cAB dEUDA
		} // for dEUDA dOCUM		
		mpDeudaPendiente.put("MTO_TOTAL",bgDeudaDolar); 
		mpDeudaPendiente.put("MTO_TOTAL_SOL",bgDeudaSoles);
		return mpDeudaPendiente;
	}
	
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#recalculoDiferenciaTrib(java.util.Map, java.util.Map, java.lang.String)
	 */
	@Override
	public Map<String,Object> recalculoDiferenciaTrib(Map<String,Object> mapTributos1,Map<String,BigDecimal> mapTributos2,String codCatalogoTrib){
		
		//List<Map<String,String>> catalogoTributos=RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getElementosCat(codCatalogoTrib);
		List<Map<String,String>> catalogoTributos=((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementosCat(codCatalogoTrib);
		Map<String,Object> mpDiferencia=new HashMap<String, Object>();
		BigDecimal lnMto_total=BigDecimal.ZERO;
		BigDecimal lnMto_total_sol=BigDecimal.ZERO;

		for(Map<String,String> tributoBD:catalogoTributos){
			String codTrib=tributoBD.get("des_corta");
			String codDataCat=tributoBD.get("cod_datacat");
			BigDecimal diferencia=SunatNumberUtils.diference((BigDecimal)mapTributos1.get(codTrib),mapTributos2.get(codTrib) );
			if(SunatNumberUtils.isGreaterThanZero(diferencia)){
				mpDiferencia.put(codTrib,diferencia );
				if(codDataCat.indexOf("D")>0)
					lnMto_total=SunatNumberUtils.sum(lnMto_total, diferencia);
				else
					lnMto_total_sol=SunatNumberUtils.sum(lnMto_total_sol, diferencia);
				
				mapTributos1.put(codTrib, diferencia);
			}
			else{
				mapTributos1.put(codTrib, BigDecimal.ZERO);
			}
		}
		mpDiferencia.put("MTO_TOTAL", lnMto_total);
		mpDiferencia.put("MTO_TOTAL_SOL", lnMto_total_sol);
		mapTributos1.put("MTO_TOTAL", lnMto_total);
		mapTributos1.put("MTO_TOTAL_SOL", lnMto_total_sol);

		

	    return mpDiferencia;
	}	
	/*Pase 580*/
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#autoLiquidacionTributoATributo(java.util.Map, java.util.Map, java.lang.String)
	 */
	@Override
	public List<Map<String,String>> autoLiquidacionTributoATributo(Map<String,Object> deudadiferencial,Map<String,BigDecimal> mapTributos2,String codCatalogoTrib){
		return autoLiquidacionTributoATributo(deudadiferencial,mapTributos2,codCatalogoTrib,"MPERCEP");
		
		
	}
	
	public List<Map<String,String>> autoLiquidacionTributoATributo2(Map<String,Object> deudadiferencial,Map<String,BigDecimal> mapTributos2,String codCatalogoTrib){
		//return autoLiquidacionTributoATributo(deudadiferencial,mapTributos2,codCatalogoTrib,"MPERCEP");
		// se modifica para considerar la Percepcion de IGV
		return autoLiquidacionTributoATributo(deudadiferencial,mapTributos2,codCatalogoTrib,"");
	}

	
	// metodo sobrecargado del anterior	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#autoLiquidacionTributoATributo(java.util.Map, java.util.Map, java.lang.String, java.lang.String)
	 */
	@Override
	public List<Map<String,String>> autoLiquidacionTributoATributo(Map<String,Object> deudadiferencial,Map<String,BigDecimal> mapTributos2,String codCatalogoTrib,String listTribNoAutoliqui){		
		List<Map<String,String>> resultadoError = new ArrayList<Map<String,String>>();
		Map<String,BigDecimal>  mpTributos=new HashMap<String, BigDecimal>();
		//List<Map<String,String>> catalogoTributos=RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getElementosCat(codCatalogoTrib);
		List<Map<String,String>> catalogoTributos=((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementosCat(codCatalogoTrib);
		
		for(Map<String,String> tributoBD:catalogoTributos){
				mpTributos.put(tributoBD.get("cod_datacat"),BigDecimal.ZERO);
		}
		
		// no se autoliquida la percepcion
				
		if(!CollectionUtils.isEmpty(deudadiferencial)){
			//mordonezl pase105
			boolean generaReliquidacion = true;
			if(deudadiferencial.get("generaReLiquidacion")!=null){
				generaReliquidacion = (Boolean) deudadiferencial.get("generaReLiquidacion");
			}
			if(!generaReliquidacion){
				return resultadoError;
			}
			if (mapTributos2== null) mapTributos2=new HashMap<String, BigDecimal>();
			for(String codTributo:mpTributos.keySet()){
				String desCortaTributo=null;
				
				//DataCatalogo datacatalogoTributo= RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(codCatalogoTrib, codTributo);
				DataCatalogo datacatalogoTributo= ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(codCatalogoTrib, codTributo);
				desCortaTributo=datacatalogoTributo != null && datacatalogoTributo.getDesCorta()!=null?datacatalogoTributo.getDesCorta():"";
				
				if (SunatStringUtils.isStringInList(desCortaTributo, listTribNoAutoliqui))
				     continue;
				boolean generaPercepcion = false;
				if(deudadiferencial.get("generaPercepcion")!= null){
					generaPercepcion = (Boolean) deudadiferencial.get("generaPercepcion");
				}
				BigDecimal montoTributoDif= (BigDecimal) deudadiferencial.get(desCortaTributo);
				BigDecimal montoTributocancela=(BigDecimal)mapTributos2.get(desCortaTributo);
				if (montoTributocancela==null) montoTributocancela=BigDecimal.ZERO;  
				if(montoTributoDif!=null && montoTributoDif.compareTo(BigDecimal.ZERO)>0){ 
					// si el monto diferencial calculado , es menor al monto cancelado , se genera error
				
					if(SunatNumberUtils.isLessThanParam(montoTributocancela,montoTributoDif )){
						// si el montotributodif es mayor al monto cancelado rechaza
						String mensaje  ="TRIBUTO: "+ datacatalogoTributo.getDesDatacat() +", CALCULADO: "+montoTributoDif+ " CANCELADO: "+montoTributocancela+". REVISE";
						//resultadoError.add(RectificacionServiceImpl.getInstance().getCatalogoHelper().getErrorMap("30447", mensaje));
						resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30447",new String[]{mensaje}));
						
						//resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35266",new String[]{mensaje}));
						
//						if(generaPercepcion){
//						//mensaje adicional si genera diferencia de percepcion por IGV
//						if("MPERCEP".equals(desCortaTributo) && montoTributocancela.compareTo(BigDecimal.ZERO)==0){
//							resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35266",new String[]{mensaje}));	
//						}else{
//							if("MPERCEP".equals(desCortaTributo)){
//								resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35267",new String[]{mensaje}));	
//							}
//						}
//				    	}
					}
				}
			}
		       for(int i=0; i<resultadoError.size(); i++)
               {
                      if(resultadoError.get(i).get("codError").toString().equals("30447")){
                             resultadoError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35266",new String[]{}));
                            break; 
                      }
               }      
		}	
		
		return resultadoError;
		
	}	
	
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#obtenerDudaRazonableDua(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion)
	 */
	@Override
	public List<Map<String, Object>> obtenerDudaRazonableDua (Declaracion declaracion){
		Map<String, Object> parametrosIbatis = new HashMap<String, Object>();
		
		parametrosIbatis.put("CODI_ADUAN", declaracion.getDua().getCodaduanaorden());
		parametrosIbatis.put("ANO_PRESE", declaracion.getNumdeclRef().getAnnprese());
		parametrosIbatis.put("CODI_REGI", declaracion.getNumdeclRef().getCodregimen());
		parametrosIbatis.put("NUME_CORRE", Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre().trim(), 6, '0'));
		//List<Map<String, Object>> listaDudaRazonable=RectificacionServiceImpl.getInstance().getNotiDudaCabDAO().listDudaByParameterMap(parametrosIbatis);
		List<Map<String, Object>> listaDudaRazonable=((NotiDudaCabDAO)fabricaDeServicios.getService("asignacion.notiDudaCabDAO")).listDudaByParameterMap(parametrosIbatis);
		
		return listaDudaRazonable;
 
		
		
	}
	

	/*hosorio fin 11/04/2011*/
	





	/*hosorio inicio 26/04/2011*/
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#obtenerAutoliquiDeclarada(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion, java.lang.String)
	 */
	@Override
	public List<DatoOtroDocSoporte> obtenerAutoliquiDeclarada(Declaracion declaracion,String strLstAutoAsociada){
		List<DatoOtroDocSoporte> lstAutLiquiDeclarada=  null;
		if(!CollectionUtils.isEmpty(declaracion.getDua().getListOtrosDocSoporte())){
			for(DatoOtroDocSoporte soporte:declaracion.getDua().getListOtrosDocSoporte()){
				if(StringUtils.hasText(soporte.getCodtipoproceso()) && soporte.getCodtipoproceso()
						.equals(ConstantesDataCatalogo.TIPO_DOC_AUTOLIQUIDACION) 
				    && SunatStringUtils.isStringInList(soporte.getCodtipodocasoc(), strLstAutoAsociada)
				    && 0==soporte.getIndicadorEliminado()
				){
					if (lstAutLiquiDeclarada ==null ) lstAutLiquiDeclarada=new ArrayList<DatoOtroDocSoporte>();
					lstAutLiquiDeclarada.add(soporte);
				}
			}
		 }	
		return lstAutLiquiDeclarada;
	}
	
	private String obtenerTipoLCAsociada(DeudaDocum deudaDocum){
		
		Liquida tmpLiquida = new Liquida();
		String strTipoLiquidacion=null;
		tmpLiquida.setRladuana(deudaDocum.getCodAduliquida());
		tmpLiquida.setRlano(SunatStringUtils.substring(deudaDocum.getAnnLiquida().toString(), 2, 4));
		tmpLiquida.setRlnroliq(deudaDocum.getNumLiquida());
		//Liquida objLiquida  =RectificacionServiceImpl.getInstance().getLiquidaDAO().selectByPrimaryKey(tmpLiquida);
		Liquida objLiquida  =((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).selectByPrimaryKey(tmpLiquida);
		
				if(objLiquida!=null){
					strTipoLiquidacion=objLiquida.getRltipliq();
				}
		return strTipoLiquidacion;
	}
	
	
	private Map<String,BigDecimal>  obtenerDetalleTributosLiquidado(Liquida objLiquida,Map<String,BigDecimal> mpTributosAutoCanc,String codCatalogoTributo){

		Map<String, Object> params=new HashMap<String, Object>();
		
		if (mpTributosAutoCanc==null) mpTributosAutoCanc=new HashMap<String, BigDecimal>(); 
		
		params.put("rdaduana", objLiquida.getRladuana());
		params.put("rdano", objLiquida.getRlano());
		params.put("rdnroliq", objLiquida.getRlnroliq());
		//List<Detaliq> lstDetaliq= RectificacionServiceImpl.getInstance().getDetaliqDAO().listByParameterMap(params);
		//inicio gmontoya PAS20165E220200106
		DataSourceContextHolder.setKeyDataSource(objLiquida.getRladuana());
		DetaliqDAO detaliqDAOTemp = (DetaliqDAO)fabricaDeServicios.getService("recaudacion2.detaliqDS");
		if(detaliqDAOTemp==null){
			detaliqDAOTemp = (DetaliqDAO) fabricaDeServicios.getService("detaliqDAO");
			HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
			swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds."+objLiquida.getRladuana()));
		}
		List<Detaliq> lstDetaliq= detaliqDAOTemp.listByParameterMap(params);
		//fin gmontoya PAS20165E220200106
		String codMoneda=objLiquida.getRlcodmon();
			if(!CollectionUtils.isEmpty(lstDetaliq)){
								for(Detaliq tributo:lstDetaliq ){
									String codTributo =tributo.getRdcodrub();
									BigDecimal mtoDeuda =tributo.getRdmondet();
									codTributo=codTributo.concat(codMoneda);
									//DataCatalogo datacatalogoTributo = RectificacionServiceImpl.getInstance().getCatalogoayudaservice().getDataCatalogo(codCatalogoTributo, codTributo);
									DataCatalogo datacatalogoTributo = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(codCatalogoTributo, codTributo);
							        String desCortaTributo = datacatalogoTributo != null && datacatalogoTributo.getDesCorta() != null ? datacatalogoTributo.getDesCorta()
									: "";
							        mpTributosAutoCanc.put(desCortaTributo, SunatNumberUtils.sum(mpTributosAutoCanc.get(desCortaTributo), mtoDeuda));
				}
		}
			return mpTributosAutoCanc;
	}
	
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#obtenerDetalleTributosAutoliquidado(java.util.List, java.lang.String)
	 */
	@Override
	public Map<String,BigDecimal> obtenerDetalleTributosAutoliquidado(List<Liquida>  lstAutoliquidaciones			,String codCatalogTributo){
		Map<String,BigDecimal> mpTributosAutoCanc=new HashMap<String, BigDecimal>();
		if (!CollectionUtils.isEmpty(lstAutoliquidaciones)){
			for(Liquida objLiquida:lstAutoliquidaciones){
				//Si Son autoliquidaciones y Los tipos de cancelación aceptados son 1 y 2
					if(objLiquida !=null && SunatStringUtils.isStringInList(objLiquida.getRltipcan().toString(), "1,2,7,11") //PAS20165E220200092
					   ){
						//validando por cada concepto de tributo - 
						//tanto en dólares como en soles, excepto percepción porque no puede autoliquidarse
						mpTributosAutoCanc=obtenerDetalleTributosLiquidado(objLiquida,mpTributosAutoCanc,codCatalogTributo);
					}
			}
		}		
		
		
		return mpTributosAutoCanc;
	}
	
	
private Date obtenerFechaPagoDeuda(DeudaDocum deudaDocum){
	
	DetPagodua tmpDetPagodua = new DetPagodua();
	Date dtFechaPagoDeuda=null;
	tmpDetPagodua.setNumCorredoc(deudaDocum.getNumCorredoc());
	tmpDetPagodua.setNumIdentdeuda(deudaDocum.getNumIdentdeuda());
	//List<DetPagodua> lstPagos = RectificacionServiceImpl.getInstance().getDetPagoDuaDAO().selectByDocumento(tmpDetPagodua);
	List<DetPagodua> lstPagos = ((DetPagoDuaDAO)fabricaDeServicios.getService("detPagoDuaDef")).selectByDocumento(tmpDetPagodua);
	if(!CollectionUtils.isEmpty(lstPagos)){
		DetPagodua detPago=lstPagos.get(0);
		dtFechaPagoDeuda=detPago.getFecPago();
	}
	
	return dtFechaPagoDeuda;
}

private boolean isFormatoCCanceladoFueraPlazo(Declaracion declaracion,Date dtFecVencimiento){
	boolean blFcCanceladoFueraPlazo=false;
	DeudaDocum tmpDeudaDocum = new DeudaDocum();
	tmpDeudaDocum = new DeudaDocum();
	tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
	tmpDeudaDocum.setCodTipdeuda("01");// Tipo De Deuda FC	
	//List<DeudaDocum> lstDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);	
	List<DeudaDocum> lstDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
	if(!CollectionUtils.isEmpty(lstDeudaDocum)){
		for (DeudaDocum deudaDocum:lstDeudaDocum) {
			Date dtFechaPagoDeuda=obtenerFechaPagoDeuda(deudaDocum);
			if(isDeudaCancelada(deudaDocum, declaracion.getNumdeclRef().getCodregimen())){
				if(SunatNumberUtils.isGreaterThanParam(SunatDateUtils.getIntegerFromDate(dtFechaPagoDeuda), SunatDateUtils.getIntegerFromDate(dtFecVencimiento))){
					blFcCanceladoFueraPlazo=true;
					break;
				 }
			}
		}
	}			
	return blFcCanceladoFueraPlazo;
}

private List<DeudaDocum>  obtenerDocDeudasdeLCAsociadas(Declaracion declaracion,String lstStrLCAsociada){
	DeudaDocum tmpDeudaDocum = new DeudaDocum();
	tmpDeudaDocum = new DeudaDocum();
	tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
	tmpDeudaDocum.setCodTipdeuda("02");// Tipo De Deuda LC
	//List<DeudaDocum> lstDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);	
	List<DeudaDocum> lstDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
	List<DeudaDocum> lstDeudas =new ArrayList<DeudaDocum>();
	if(!CollectionUtils.isEmpty(lstDeudaDocum)){
		for (DeudaDocum deudaDocum:lstDeudaDocum) {
			String strTipoLcAsociada= obtenerTipoLCAsociada(deudaDocum);
			if(SunatStringUtils.isStringInList(strTipoLcAsociada, lstStrLCAsociada)){
				lstDeudas.add(deudaDocum);
			}
		}								
	}	
	return lstDeudas;
}

private List<DeudaDocum> obtenerDocDeudasdeLCAsociadasCanceladas(Declaracion declaracion,String lstStrLCAsociada){
	List<DeudaDocum> lstDeudaDocum =obtenerDocDeudasdeLCAsociadas(declaracion,lstStrLCAsociada);
	List<DeudaDocum> lstDeudaCanceladas=new ArrayList<DeudaDocum>();
	if(!CollectionUtils.isEmpty(lstDeudaDocum)){
		for (DeudaDocum deudaDocum:lstDeudaDocum) {
			String strTipoLcAsociada= obtenerTipoLCAsociada(deudaDocum);
			if(SunatStringUtils.isStringInList(strTipoLcAsociada, lstStrLCAsociada)){
				if(isDeudaCancelada(deudaDocum, declaracion.getNumdeclRef().getCodregimen())){
					lstDeudaCanceladas.add(deudaDocum);
				}
			}
		}								
	}	
	return lstDeudaCanceladas;
}

/* (non-Javadoc)
 * @see pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValidaAnexoDeclaracionService#isFCCancelado(pe.gob.sunat.despaduanero2.declaracion.model.Declaracion)
 */
@Override
public boolean isFCCancelado(Declaracion declaracion){
	boolean cancelado = false;
	DeudaDocum tmpDeudaDocum = new DeudaDocum();
	tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
	tmpDeudaDocum.setCodTipdeuda("01");// Tipo De Deuda FC
	//List<DeudaDocum> lstDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);
	List<DeudaDocum> lstDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
	
	for (DeudaDocum deudaDocum:lstDeudaDocum) {
		cancelado=isDeudaCancelada(deudaDocum, declaracion.getNumdeclRef().getCodregimen());
	}
	return cancelado;
}

public boolean isFCCanceladoDeDuaGarantizada(Declaracion declaracion){
	boolean cancelado = false;
	DeudaDocum tmpDeudaDocum = new DeudaDocum();
	tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
	tmpDeudaDocum.setCodTipdeuda("01");// Tipo De Deuda FC
	//List<DeudaDocum> lstDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);
	List<DeudaDocum> lstDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
	
	for (DeudaDocum deudaDocum:lstDeudaDocum) {
		cancelado=isDeudaCanceladaDeDuaGarantizada(deudaDocum, declaracion.getNumdeclRef().getCodregimen());
	}
	return cancelado;
}

public Map<String, String> validaGeneraPercepcion(Declaracion declaracion , Map<String, Object> variablesIngreso){
	
	Declaracion declaracionBD = (Declaracion) variablesIngreso.get("declaracionBD");
	Date fechSalida= declaracionBD.getDua().getFecSalteralm();
	Date fechLevante = declaracionBD.getDua().getFecAutlevante();
	Map<String,Object> deudadiferencial=(Map<String,Object>)variablesIngreso.get("deudadiferencial");
	Boolean existediferencialPercep = deudadiferencial!=null && deudadiferencial.get("generaPercepcion")!=null? (Boolean) deudadiferencial.get("generaPercepcion"):false;//cuando no hay deudadiferencial queda en error 24
	if(!CollectionUtils.isEmpty(deudadiferencial) && existediferencialPercep){
	if( fechSalida.compareTo(SunatDateUtils.getDefaultDate())>0){
		deudadiferencial.put("generaPercepcion", false);
		
	}else{
		if(fechLevante.compareTo(SunatDateUtils.getDefaultDate())>0){
			deudadiferencial.put("generaPercepcion", false);
		}
	}
//	! SunatStringUtils.isEqualTo( declaracion.getDua().getCodmodalidad() , "01")	&& 
	if( SunatStringUtils.isEqualTo( declaracion.getDua().getIndSocorro(), "S")){
		deudadiferencial.put("generaPercepcion", false);
	}
	boolean generaPercepcion = (Boolean) deudadiferencial.get("generaPercepcion");
	if(!generaPercepcion){
		deudadiferencial.put("MPERCEP",BigDecimal.ZERO);
	}
	}
	return new HashMap<String, String>();
}

/*
 * Adicionado para considerar bug 18768
*/
public Map<String, String> validaReLiquidacionDelConsignatario(Declaracion declaracion , Map<String, Object> variablesIngreso){
	 String numDocConsigAnterior=null;
     String numDocConsigActual=null;
	Declaracion declaracionBD = (Declaracion) variablesIngreso.get("declaracionBD");
    if(declaracionBD!=null)
   	 numDocConsigAnterior=declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad();
    Map<String,Object> deudadiferencial=(Map<String,Object>)variablesIngreso.get("deudadiferencial");
    
    if(deudadiferencial!=null){
    if(declaracion!=null) 
      numDocConsigActual=declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
	 	
	Map mapDdp = ((DdpDAO)fabricaDeServicios.getService("servicio.registro.model.ddpDAO")).findByPK(numDocConsigActual);
	String estadoActual = mapDdp!=null?(String)mapDdp.get("ddp_estado"):" ";	
	String flag22Actual = mapDdp!=null?(String)mapDdp.get("ddp_flag22"):" ";

	if(SunatStringUtils.isEqualTo(numDocConsigActual, numDocConsigAnterior) && ( SunatStringUtils.include(estadoActual, new String[]{"01","02","03","10", "11","12"})  || flag22Actual.equals("12")) ){
    	deudadiferencial.put("generaReLiquidacion", false);
    	
    	deudadiferencial.put("generaPercepcion", false);
    }
    }
	return new HashMap<String, String>();
}

private boolean isLcCanceladoFueraPlazo(Declaracion declaracion,String lstStrLCAsociada, Date dtFecVencimiento){
	boolean blLcCompleCanceladoFueraPlazo=false;

	List<DeudaDocum> lstDeudaDocum = obtenerDocDeudasdeLCAsociadasCanceladas(declaracion,lstStrLCAsociada);
	if(!CollectionUtils.isEmpty(lstDeudaDocum)){
		for (DeudaDocum deudaDocum:lstDeudaDocum) {
					Date dtFechaPagoDeuda=obtenerFechaPagoDeuda(deudaDocum);
					// De haberse cancelado fuera de plazo
					if(SunatNumberUtils.isGreaterThanParam(SunatDateUtils.getIntegerFromDate(dtFechaPagoDeuda), SunatDateUtils.getIntegerFromDate(dtFecVencimiento))
					){
						blLcCompleCanceladoFueraPlazo=true;
						break;
			         }
		}								
	}
	return blLcCompleCanceladoFueraPlazo;
}

/*Pase 580  se agrego un parametro regimen*/
private boolean isDeudaCancelada(DeudaDocum deudaDocum, String regimen){
	boolean blCancelado=false;
	BigDecimal mtoCancelado=SunatNumberUtils.sum(SunatNumberUtils.sum(deudaDocum.getMtoPagado(), deudaDocum.getMtoImpugna()),deudaDocum.getMtoGarant());
	
	if ( mtoCancelado.compareTo(deudaDocum.getMtoDeuda())>=0	
			&& SunatStringUtils.isEqualTo(deudaDocum.getCodEstpago().trim(), "P")	&& "10".equals(regimen)) {
		return true;
	}
	if ( mtoCancelado.compareTo(deudaDocum.getMtoDeuda())>=0   	
			&& !"10".equals(regimen)) {
		return true;
	}
	
	return blCancelado;
}

private boolean isDeudaCanceladaDeDuaGarantizada(DeudaDocum deudaDocum, String regimen){
	boolean blCancelado=false;
	BigDecimal mtoCancelado=SunatNumberUtils.sum(SunatNumberUtils.sum(deudaDocum.getMtoPagado(), deudaDocum.getMtoImpugna()),deudaDocum.getMtoGarant());

	if ( mtoCancelado.compareTo(deudaDocum.getMtoDeuda())>=0 && SunatStringUtils.isEqualTo(deudaDocum.getCodEstpago().trim(), "P")	&& "10".equals(regimen)) {
			return true;
		}
	
	
	return blCancelado;
}


private void reemplazaDeudaConMontosImputados(List<Map<String, Object>> conceptosImputados,Map<String,Object>  diferenciaTributos){
	BigDecimal lnMto_total = new BigDecimal(diferenciaTributos.get("MTO_TOTAL").toString());
	BigDecimal lnMto_total_sol = new BigDecimal(diferenciaTributos.get("MTO_TOTAL_SOL").toString());
	
	//se reemplaza los montos que fueron imputados en la diferencia de tributos.
	
	 if(conceptosImputados!=null && conceptosImputados.size()!=0){
		for (Map<String, Object> concepto : conceptosImputados) {
			if(SunatStringUtils.substring(concepto.get("COD_TRIBUTO").toString(), 4, 5).equals("D")){
				lnMto_total = lnMto_total.subtract((BigDecimal)diferenciaTributos.get(concepto.get("DES_CORTA")))
				.add((BigDecimal)concepto.get("MTO_VALDEBE"));
			}else{
				lnMto_total_sol = lnMto_total_sol.subtract((BigDecimal)diferenciaTributos.get(concepto.get("DES_CORTA")))
				.add((BigDecimal)concepto.get("MTO_VALDEBE"));
			}
			diferenciaTributos.put(concepto.get("DES_CORTA").toString(), concepto.get("MTO_VALDEBE"));
			diferenciaTributos.put(concepto.get("DES_CORTA").toString().concat("X"), "*");
			
			
		}
		diferenciaTributos.put("MTO_TOTAL", lnMto_total);
		diferenciaTributos.put("MTO_TOTAL_SOL", lnMto_total_sol);
	  }
	
	
	
}
//PAS20165E220200127
public boolean isAplicarImputacion(Declaracion declaracion,Map<String, Object> mapDua,Map<Object,Object> mapManif){
	String codModalidad=declaracion.getDua().getCodmodalidad();
	//Date fecLlegada =RectificacionServiceImpl.getInstance().getFuncionesService().getFechaLlegadaIngreso(declaracion, mapManif);
	Date fecLlegada =((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).getFechaLlegadaIngreso(declaracion, mapManif);
	//Date fecVenciPago=RectificacionServiceImpl.getInstance().getFuncionesService().getFechaVencimientoPagoDespacho(declaracion,mapManif);
	Date fecVenciPago=((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).getFechaVencimientoPagoDespacho(declaracion,mapManif);
	
	Date dtFecNumeracion =declaracion.getDua().getFecdeclaracion();
	Date dtFecTerminoDescarga=null;
	if(mapManif!=null)
		dtFecTerminoDescarga=(Date)mapManif.get("fechaTerminoDeDescarga");
	
	//11.2 existe cambio de modalidad: de anticipado (1-0) ó urgente (0-1) a excepcional (00)
	String codModalidaBD=mapDua.get("codmodalidad").toString();
	if(codModalidad.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)
	    && 	SunatStringUtils.isStringInList(codModalidaBD, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO+","+ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)	
	            	){
		                
		                boolean blFcCanceladoFueraPlazo=false;
	            		boolean blLcCompleCanceladoFueraPlazo=false;
	            		blFcCanceladoFueraPlazo=isFormatoCCanceladoFueraPlazo(declaracion,fecVenciPago);
	            		blLcCompleCanceladoFueraPlazo=isLcCanceladoFueraPlazo(declaracion,"0022,0038",fecVenciPago);
						
						//De haberse cancelado fuera de plazo 
						// se realiza la imputación de pago de los tributos liquidados en dólares en la DUA 
						//y adicionalmente se efectúa la imputación de pago del ISC liquidado en soles, en forma independiente
	            		if (blFcCanceladoFueraPlazo || blLcCompleCanceladoFueraPlazo){
	            			
					            return true;
	            		}
	}
	
	//CASOS ESPECIALES:
	//8. Si al momento de la rectificación se cuenta con la fecha real del término de la descarga (en los casos de despacho anticipado y urgente antes de la llegada)
	//Seguidamente se verifica si la DUA fue cancelada y ésta se efectuó fuera del plazo; de ser así se realiza la imputación de pago de los tributos liquidados
	if(  SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) 
		      ||
		      (SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE))
		        // &&  SunatDateUtils.esFecha1MayorQueFecha2(fecLlegada, dtFecNumeracion, "COMPARA_SOLO_FECHA") )
           ){
  		
      			if(dtFecTerminoDescarga!=null && 
      					!SunatDateUtils.isDefaultDate(dtFecTerminoDescarga)){
      				
		                boolean blFcCanceladoFueraPlazo=false;
	            		boolean blLcCompleCanceladoFueraPlazo=false;
	            		blFcCanceladoFueraPlazo=isFormatoCCanceladoFueraPlazo(declaracion,fecVenciPago);
	            		blLcCompleCanceladoFueraPlazo=isLcCanceladoFueraPlazo(declaracion,"0022,0038",fecVenciPago);
						
						//De haberse cancelado fuera de plazo 
						// se realiza la imputación de pago de los tributos liquidados en dólares en la DUA 
						//y adicionalmente se efectúa la imputación de pago del ISC liquidado en soles, en forma independiente
	            		if (blFcCanceladoFueraPlazo || blLcCompleCanceladoFueraPlazo){
	            			return true;
	            			
	            		}
      			}
  	}	
	return false;
}

 private void aplicarImputacionenDeuda(Map<String,Object> deudadiferencial,List<Map<String, Object>> conceptosImputados){
	 

		reemplazaDeudaConMontosImputados(conceptosImputados, deudadiferencial);
 
 }
 
 private List<Map<String, Object>>  obtenerConceptosImputados(Declaracion declaracion,Map<Object,Object> mapManif,Map<String,Object> deudadiferencial){
		String codGarantia = null;
		try {
			codGarantia=declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
		} catch (Exception e) {
			// : handle exception
		}
	   //Date fecVenciPago=RectificacionServiceImpl.getInstance().getFuncionesService().getFechaVencimientoPagoDespacho(declaracion,mapManif);
	   Date fecVenciPago=((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).getFechaVencimientoPagoDespacho(declaracion,mapManif);
	   Date fecLlegada=(Date)mapManif.get("fechaEfectivaDeLlegada");
	   
       Map<String, Object> mapCabDeclaraImput = new HashMap<String, Object>();
       mapCabDeclaraImput.put("numeroCorrelativo", declaracion.getDua().getNumcorredoc() );
       mapCabDeclaraImput.put("numeroCtaCte", codGarantia);
       mapCabDeclaraImput.put("codigoRegimen", declaracion.getDua().getCodregimen());
       mapCabDeclaraImput.put("fechaTerminoDescarga",fecVenciPago);
       mapCabDeclaraImput.put("fechaLlegada",fecLlegada); 
       mapCabDeclaraImput.put("codTransaccion","03");
       


       //List<Map<String, Object>> conceptosImputados=  RectificacionServiceImpl.getInstance().getImputacionService().calculaImputacion(declaracion.getDua().getCodaduanaorden(), mapCabDeclaraImput, deudadiferencial);
       List<Map<String, Object>> conceptosImputados=  ((ImputacionService)fabricaDeServicios.getService("imputacionServiceDef")).calculaImputacion(declaracion.getDua().getCodaduanaorden(), mapCabDeclaraImput, deudadiferencial);
       return conceptosImputados;
 }
 
 private BigDecimal obtenerMontoGarantizadoNoCancelado(List<DeudaDocum> listaDeudaDocum,String codMoneda){
	   BigDecimal bgMonto=BigDecimal.ZERO;
		if (listaDeudaDocum!=null && listaDeudaDocum.size()>0) {
			DeudaDocum deudaDocum;
			for (int i = 0; i<listaDeudaDocum.size(); i++){
				deudaDocum = listaDeudaDocum.get(i);
				if(deudaDocum.getCodEstadmin().equals("G") && deudaDocum.getCodEstpago().equals("E")){
					if (deudaDocum.getCodMoneda().equals(codMoneda)
					) {
						bgMonto = bgMonto.add(deudaDocum.getMtoDeuda()); // Va sumando
					} 
				}
			}
		}
    return bgMonto;
 }
 
 private BigDecimal obtenerMontoSinGarantiaNoCancelado(List<DeudaDocum> listaDeudaDocum,String codMoneda){
	   BigDecimal bgMonto=BigDecimal.ZERO;
		if (listaDeudaDocum!=null && listaDeudaDocum.size()>0) {
			DeudaDocum deudaDocum;
			for (int i = 0; i<listaDeudaDocum.size(); i++){
				deudaDocum = listaDeudaDocum.get(i);
				if( deudaDocum.getCodEstpago().equals("E") && !deudaDocum.getCodEstadmin().equals("G")){
					if (deudaDocum.getCodMoneda().equals(codMoneda)
					) {
						bgMonto = bgMonto.add(deudaDocum.getMtoDeuda()); // Va sumando
					}					
				}

			}
		}
  return bgMonto;
} 
 
 private BigDecimal obtenerCambio(String codMonedaDestino , Integer fechaCembio, BigDecimal monto){
		Map<String,Object> mapCambio1=new HashMap<String,Object>();
		mapCambio1.put("fingreso", fechaCembio);
		mapCambio1.put("cmoneda", codMonedaDestino);
//		Cambio1 cambio1=NumeracionServiceImpl.getInstance().getCambio1DAO().findByPK(mapCambio1);
		mapCambio1.put("ayudaID", "Cambio1");
		Cambio1 cambio1 = (Cambio1)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).buscarObject(mapCambio1);
		BigDecimal montoCambio=SunatNumberUtils.divide(monto, cambio1.getPventa(), 6);

	  return montoCambio;
 }
//PAS20165E220200127
 public boolean existeIncidencia(Map<String,Object> deudadiferencial,List<DeudaDocum> listaDeudaDocum){
		BigDecimal lnDeudaAnteriorDolares = BigDecimal.ZERO;
		BigDecimal lnDeudaAnteriorSoles = BigDecimal.ZERO;			
        boolean existeIncidenciaTributaria=false;
		if (listaDeudaDocum!=null && listaDeudaDocum.size()>0) {
			DeudaDocum deudaDocum;
			for (int i = 0; i<listaDeudaDocum.size(); i++){
				deudaDocum = listaDeudaDocum.get(i);
					if (deudaDocum.getCodMoneda().equals("USD")) {
						lnDeudaAnteriorDolares = lnDeudaAnteriorDolares.add(deudaDocum.getMtoDeuda()); // Va sumando
					} else {
						lnDeudaAnteriorSoles = lnDeudaAnteriorSoles.add(deudaDocum.getMtoDeuda()); // Va sumando
					}
					}
			}			
		
		if(!CollectionUtils.isEmpty(deudadiferencial)  && deudadiferencial.get("MTO_TOTAL_ACUMULADO")!=null && deudadiferencial.get("MTO_TOTAL_ACUMULADO_SOL")!=null){
				if(	(   (BigDecimal)deudadiferencial.get("MTO_TOTAL_ACUMULADO")).compareTo(lnDeudaAnteriorDolares) == 1
						||
						((BigDecimal)deudadiferencial.get("MTO_TOTAL_ACUMULADO_SOL")).compareTo(lnDeudaAnteriorSoles) == 1
						|| 
						(deudadiferencial.get("diferenciaAlgunTributoFCAMayor")!=null?(Boolean)deudadiferencial.get("diferenciaAlgunTributoFCAMayor"):false) //// inicio PAS201830001100011 
						||
						(deudadiferencial.get("diferenciaTributosMayor")!=null?(Boolean)deudadiferencial.get("diferenciaTributosMayor"):false) // fin PAS201830001100011 
					)
				{
					existeIncidenciaTributaria=true;
				}
		
			
		}
		return existeIncidenciaTributaria;
 }

 	public boolean esGarantiaRenovada(String numCtaCte) {
		Map<String, Object> params = new HashMap<String, Object>();
		boolean tieneGarantia160 = (!StringUtils.isEmpty(numCtaCte));
		if(tieneGarantia160){
		params.put("NUMCTACTE", numCtaCte);
		params.put("IND_ACTIVO", Constantes.INDICADOR_GARANTIA_RENOVADA);
		Integer esGarantiaRenovada = ((CabCtaCteGarDAO)fabricaDeServicios.getService("cabctactegarDef")).getCountCtaCte(params);
		if(esGarantiaRenovada > 0){
			return true;
		 }
		}
		return false;
	}
 

	/*branch ingreso 2011-009 hosorio fin 26/04/2011*/

//public AyudaService getAyudaService() {
//	return ayudaService;
//}
//
//public void setAyudaService(AyudaService ayudaService) {
//	this.ayudaService = ayudaService;
//}
/*
public FabricaDeServicios getFabricaDeServicios() {
	return fabricaDeServicios;
}

public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
	this.fabricaDeServicios = fabricaDeServicios;
}*/

public String buscarAutoliquidacion (String tipo, List lstAutoliquidaciones) {
	String existe ="";		
	Liquida liquida = new Liquida();
	
	for (int i = 0; i<lstAutoliquidaciones.size(); i++){
		liquida = (Liquida)lstAutoliquidaciones.get(i);
		liquida.getRlnroliq();
		if (!(SunatStringUtils.isEqualTo(liquida.getRltipliq(), "0038"))) {
			existe = liquida.getRlnroliq();
		}
	}

	return existe;
	
}	
/*
public DdpDAOService getDdpDAOService() {
	return ddpDAOService;
}

public void setDdpDAOService(DdpDAOService ddpDAOService) {
	this.ddpDAOService = ddpDAOService;
}*/
	@Override
	public Map<String, String> calculaLiquidacionEER(
			Declaracion declaracion,
			String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender,
			String numOrden,
			String codUsuario,
			String codTransaccion,
			Integer nroErroresNegocio,
            Map variablesCancelacion) {

	    String codTransaccionTmp = codTransaccion;
	    if(ConstantesDataCatalogo.TRANSACCION_NUMERACION_DSEER_DESDE_MDEER.equals(codTransaccion)){
            codTransaccionTmp = ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER;
        }

		if (nroErroresNegocio==0) {

			GeneraLiquidacionService generaLiquidacionService = (GeneraLiquidacionService)fabricaDeServicios.getService("generaLiquidacionService");
			Map retorna = generaLiquidacionService.obtenerLiquidacion(declaracion,codTransaccionTmp, numOrden,
					codUsuario, tipoDocumentoIdentidadSender,
					numeroDocumentoIdentidadSender);
		}
		
		return new HashMap<String, String>();

	}

	@Override
	public List<Map<String, ?>> separaGarantiaEER(Declaracion declaracion,
											   String numeroDocumentoIdentidadSender,
											   String tipoDocumentoIdentidadSender,
											   String numOrden,
											   String codUsuario,
											   Integer nroErroresNegocio,
											   Map variablesCancelacion,
											   String codTransaccion){
		//rtineo: proxy para la llamada a garantia desde DSEER
        //colocar aqui las particularidades de DSEER
        String codTransaccionTmp = codTransaccion;
        if(ConstantesDataCatalogo.TRANSACCION_NUMERACION_DSEER_DESDE_MDEER.equals(codTransaccion)){
            codTransaccionTmp = ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER;
        }
		return separaGarantia(declaracion,numeroDocumentoIdentidadSender,tipoDocumentoIdentidadSender,
				numOrden,codUsuario,nroErroresNegocio,variablesCancelacion,codTransaccionTmp);
	}
	
	/***** Solo para el codigo de regimen 28,si se acoge a garantia 160  debe de estar lleno 
     * @param dua

	 */
	public List<Map<String, String>> validarGarantiaEER(DUA dua, String numeroDocumentoIdentidadSender,Map<String, Object> variablesCancelacion){
		List<Map<String, String>> resultadoError = new ArrayList<Map<String,String>>();
		
		String resultado="";
		String resultado1="";
		String tipoDesp=""; 

		boolean validaGarantia = false;
		tipoDesp=(String)  variablesCancelacion.get("tipoDesp");

		DatoPago pago=dua.getPago();
		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		String codgarantia=decla!=null?decla.getCodgarantia():null;
		String codTipoPago=decla!=null?decla.getCodtipopago():null;
		String regimen=dua.getCodregimen();
		String numRucValido=null;

		if (! SunatStringUtils.isEmpty( codgarantia ) && codTipoPago!=null){
			if( ConstantesDataCatalogo.REGIMEN_EER.equals(regimen)) {
				validaGarantia = codTipoPago.equals(ConstantesDataCatalogo.DEUDA_GARANTIZADA);  //Para Impo, solo valida cuando CodTipoPago='G'
			}
			
			if (validaGarantia) {
				String numdeclaracion = " ";
				Integer nFECRECTI = 0;
				/*Declaracion declaracionDB= (Declaracion)variablesCancelacion.get("declaracionDB");
				if(declaracionDB!=null){
					numdeclaracion = declaracionDB.getNumeroDeclaracion().toString();
					nFECRECTI=SunatDateUtils.getCurrentIntegerDate();
				}*/
				PagarantiaDAO pagarantiaDao = (PagarantiaDAO) fabricaDeServicios.getService("pagarantiaDAO");
				  
				 Map params = new HashMap();
			     params.put("cRUC",numeroDocumentoIdentidadSender); // RUC del declarante ESER
			     params.put("cADUANA",dua.getCodaduanaorden());
			     params.put("cANO",SunatDateUtils.getCurrentIntegerDate().toString().substring(2, 4)); 	//Anoo a 2 digitos
			     params.put("cREGIMEN",dua.getCodregimen());
			     params.put("cNUMERO",codgarantia);
			     params.put("nFECNUMERA", SunatDateUtils.getIntegerFromDate(dua.getFecdeclaracion())); // Se pasa fecha de declaracion
			     params.put("nFECRECTI", nFECRECTI);
			     params.put("cNUMECORRE", numdeclaracion);
			     params.put("cMODULO",tipoDesp);
			     resultado=(String)pagarantiaDao.consultarFechaVencimientoGarantia(params);
			     if (resultado.length()>0){
				    	 if (resultado.substring(0, 1).equals("0")){//validacion incorrecta
				    		 List<String> CodigosError = Arrays.asList(resultado.split("\\|"));
				    		 CodigosError =  CodigosError.subList(1, CodigosError.size()); //Eliminamos el "0"
				    		 for(String codErr1: CodigosError){
				    			 if("4".equals(dua.getConsignatario().getTipoDocumentoIdentidad().getCodDatacat())){
					    			 if("10003".equals(codErr1)){
					    				 params.put("cRUC",dua.getConsignatario().getNumeroDocumentoIdentidad());
					    				 resultado1=(String)pagarantiaDao.consultarFechaVencimientoGarantia(params);
					    				 if (resultado1.substring(0, 1).equals("0")){//validacion incorrecta
					    					 List<String> CodigosError1 = Arrays.asList(resultado1.split("\\|"));
								    		 CodigosError1 =  CodigosError1.subList(1, CodigosError1.size()); //Eliminamos el "0"
								    		 for(String codErr2: CodigosError1){
								    			 if("10003".equals(codErr2)){
								    				 resultadoError.add(getErrorMap(codErr1, ""));
								    				 return resultadoError;
								    			 }else{
								    				 resultadoError.add(getErrorMap(codErr2, ""));
								    			 }
								    		 }
								    		 return resultadoError;
					    					 
					    				 }else{//validacion correcta
					    					 //resultadoError.add(getErrorMap(codErr1, ""));
					    					 numRucValido=dua.getConsignatario().getNumeroDocumentoIdentidad();
					    				     //seteo del numero de ruc valido con la garantia 
					    					 variablesCancelacion.put("numRucValidoGarantia", numRucValido);
                                             dua.setRucCtaCorriente(numRucValido);
					    					 return resultadoError;
					    				 }
					    				
					    			 }
				    			 }
				    			 resultadoError.add(getErrorMap(codErr1, ""));
				    		 }
				    	 }else{
				    		 numRucValido=numeroDocumentoIdentidadSender;
				    		//seteo del numero de ruc valido con la garantia 
				    		 variablesCancelacion.put("numRucValidoGarantia", numRucValido);
				    		 dua.setRucCtaCorriente(numRucValido);
				    	 }
			     }

			} //fin validaGarantia == true
		}
		return resultadoError;
	} 	


	//PAS20191U220200026 - mtorralba 20190528 - INICIO Nuevo servicio para validar Garantia 159
	@Override
	@ServicioAnnot(tipo="V",codServicio=3330, descServicio="Invocacion al servicio de validación de monto de Garantía 159")
	@OrquestaDespaAnnot(codServInstancia=3330,numSecEjec=582,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.AnexoDeclaracion")
	public Map<String, String> validaMontoGarantia159(Declaracion declaracion) throws Exception{
		
		Map<String,String> resultadoError = new HashMap<String,String>();

		//Obtenemos la liquidacion más reciente de la DAM
		CabDocliq tmpCabDocliq = new CabDocliq();
		tmpCabDocliq.setAnnDocliq(declaracion.getNumdeclRef().getAnnprese());
		tmpCabDocliq.setCodAduDocliq(declaracion.getCodaduana());
		tmpCabDocliq.setCodRegDocliq(declaracion.getNumdeclRef().getCodregimen());
		tmpCabDocliq.setNumDocliq(Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre().trim(), 6, '0'));
		CabDocliqDAO cabDocliqDAO = fabricaDeServicios.getService("cabDocliqDef");
		CabDocliq cabdoc = cabDocliqDAO.selectMostRecentByDUA(tmpCabDocliq);
		
		FuncionesLiquidacionService funcionesLiquidacionService = fabricaDeServicios.getService("funcionesLiquidacionService");
		MovCabliqdilig mapCabliqdilig = funcionesLiquidacionService.obtenerCabeceraPreliquidacion(cabdoc);
		
		//PAS20191U220200026 - mtorralba 20190528 - INICIO
		if( mapCabliqdilig != null ) {
			LiquidaDeclaracionPecoAmazoniaService liquidaDeclaracionPecoAmazoniaService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionPecoAmazoniaService");
			BigDecimal montoAGarantizar = mapCabliqdilig.getMtoLadv().add(mapCabliqdilig.getMtoLdes().add(mapCabliqdilig.getMtoLigv().add(mapCabliqdilig.getMtoLipm())));
			Map<String,Object> mapaGarantia159 = liquidaDeclaracionPecoAmazoniaService.montoCubiertoPorGarantia159(declaracion, montoAGarantizar); 
			if( mapaGarantia159!=null && mapaGarantia159.get("ERROR")!=null) {
				resultadoError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("10075",new String[]{mapaGarantia159.get("NUME_GARANT").toString(),mapaGarantia159.get("FIAN_MONTO").toString(), String.valueOf(montoAGarantizar)});
			}
		}
		//PAS20191U220200026 - mtorralba 20190528 - FIN
				
		return resultadoError;
	}

}
	