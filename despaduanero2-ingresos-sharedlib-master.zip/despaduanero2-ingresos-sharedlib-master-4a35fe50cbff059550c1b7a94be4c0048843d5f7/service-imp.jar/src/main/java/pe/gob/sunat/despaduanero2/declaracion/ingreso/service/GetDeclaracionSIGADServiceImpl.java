package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero.catalogo.tg.model.Dfrecdoc;
import pe.gob.sunat.despaduanero.catalogo.tg.model.dao.DfrecdocDAO;
import pe.gob.sunat.despaduanero.despacho.comun.impo.model.TabImpDU;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Polizad;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionDepositoAduaneroService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoConsumoService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImportacionAdmisionPerfecService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImportacionAdmisionReexpService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDespachoAnticipadoUrgenteService;

public class GetDeclaracionSIGADServiceImpl extends IngresoAbstractServiceImpl implements	GetDeclaracionSIGADService {
	
	//private FabricaDeServicios fabricaDeServicios;
	
	public List<TabImpDU> getDeclaracionPendienteRegularizarSIGAD(Participante importador, String codiAduan, Date fechareferencia, String tipoDespa){
		ConsultaDespachoAnticipadoUrgenteService consultaDespachoAnticipadoUrgenteService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDespachoAnticipadoUrgenteService");	
		Map<String,Object> paramPendienteReg=new HashMap<String,Object>();
        if (importador != null) {
	        paramPendienteReg.put("tipoDocum", importador.getTipoDocumentoIdentidad().getCodDatacat());
	        paramPendienteReg.put("librTribu", importador.getNumeroDocumentoIdentidad());
        }
        paramPendienteReg.put("fechRegul", 0);
        paramPendienteReg.put("listaNoFlagAnul", new String[]{"R", "A", "N"});
        paramPendienteReg.put("fechIngsi", 19991004); //valor por defecto
        paramPendienteReg.put("fechVenci", SunatDateUtils.getIntegerFromDate(fechareferencia));
        paramPendienteReg.put("codiAduan", codiAduan); 
        paramPendienteReg.put("tipoDespa", tipoDespa);
        
        List<TabImpDU> declaracionesPorRegularizar =  consultaDespachoAnticipadoUrgenteService.consultarDeclaracionesPendientesRegularizar(paramPendienteReg);
        Iterator<TabImpDU> iteratordeclaracionPendiente = declaracionesPorRegularizar.iterator(); 
        while(iteratordeclaracionPendiente.hasNext()){
        	TabImpDU declaracionPendiente = iteratordeclaracionPendiente.next();
        	String codiregi = declaracionPendiente.getCodiRegi();
        	if (SunatStringUtils.isEqualTo(codiregi, ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
        		ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
        		Map<String,Object> params=new HashMap<String,Object>();
    			params.put("CODIADUAN", declaracionPendiente.getCodiAduan());
    			params.put("ANOPRESE", SunatStringUtils.substring(declaracionPendiente.getAnoPrese(),2,4));
    			params.put("NUMECORRE", declaracionPendiente.getNumeCorre());
    			params.put("NO_LEGAJADO", true);
    			Map<String, Object> declaracionDI = consultaDeclaracionImpoConsumoService.consultarDeclaracionImportacionConsumo(params, declaracionPendiente.getCodiAduan());
    			if (declaracionDI == null){
    				iteratordeclaracionPendiente.remove();
    			} else{
    				if (SunatNumberUtils.isEqualToZero(SunatNumberUtils.toInteger(declaracionDI.get("FEC_LEVANTE"))) ||
    					(tipoDespa.equals(ConstantesDataCatalogo.TIPO_DESPACHO_ANTICIPADO) && 
    							!SunatStringUtils.isEqualTo(SunatStringUtils.toStringObj(declaracionDI.get("COD_TIP_LLEGADA")),ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION))){
    					iteratordeclaracionPendiente.remove();
    				}
    			}
        	}
        	if (SunatStringUtils.isEqualTo(codiregi, ConstantesDataCatalogo.REG_DEPOSITO)){
        		ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService =  fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
        		Map<String,Object> params=new HashMap<String,Object>();			
    			params.put("CODIADUAN", declaracionPendiente.getCodiAduan());
    			params.put("NUMECORRE", declaracionPendiente.getNumeCorre());
    			params.put("ANOPRESE", SunatStringUtils.substring(declaracionPendiente.getAnoPrese(),2,4));
    			params.put("NO_LEGAJADO", true);
    			Map<String, Object> declaraciondeposito = consultaDeclaracionDepositoAduaneroService.consultarDeclaracionDepositoAduanero(params, declaracionPendiente.getCodiAduan());
    			if (declaraciondeposito == null){    				
    				iteratordeclaracionPendiente.remove();
    			}else{
    				if (SunatNumberUtils.isEqualToZero(SunatNumberUtils.toInteger(declaraciondeposito.get("FEC_LEVANTE")))||
        					(tipoDespa.equals(ConstantesDataCatalogo.TIPO_DESPACHO_ANTICIPADO) && 
        							!SunatStringUtils.isEqualTo(SunatStringUtils.toStringObj(declaraciondeposito.get("COD_TIP_LLEGADA")),ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION))){
    					iteratordeclaracionPendiente.remove();
    				}
    			}      		
        	}
        	if (SunatStringUtils.isEqualTo(codiregi, ConstantesDataCatalogo.REG_ADM_TEMP_RME)){
        		ConsultaDeclaracionImportacionAdmisionReexpService consultaDeclaracionImportacionAdmisionReexpService =  fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImportacionAdmisionReexpService");
        		Map<String,Object> params=new HashMap<String,Object>();			
    			params.put("CODIADUAN", declaracionPendiente.getCodiAduan());
    			params.put("ANOPRESE", SunatStringUtils.substring(declaracionPendiente.getAnoPrese(),2,4));
    			params.put("NUMECORRE", declaracionPendiente.getNumeCorre());
    			params.put("NO_LEGAJADO", true);
    			Map<String, Object> declaracionpit = consultaDeclaracionImportacionAdmisionReexpService.consultarDeclaracionAdmisionReexp(params);
    			if (declaracionpit == null){    				
    				iteratordeclaracionPendiente.remove();
    			}else{
    				if (SunatNumberUtils.isEqualToZero(SunatNumberUtils.toInteger(declaracionpit.get("FEC_LEVANTE")))||
        					(tipoDespa.equals(ConstantesDataCatalogo.TIPO_DESPACHO_ANTICIPADO) && 
        							!SunatStringUtils.isEqualTo(SunatStringUtils.toStringObj(declaracionpit.get("COD_TIP_LLEGADA")),ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION))){
    					iteratordeclaracionPendiente.remove();
    				}
    			}
        	}
        	if (SunatStringUtils.isEqualTo(codiregi, ConstantesDataCatalogo.REG_ADM_TEMP_PA)){        		
        		ConsultaDeclaracionImportacionAdmisionPerfecService consultaDeclaracionImportacionAdmisionPerfecService =  fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImportacionAdmisionPerfecService");
        		Map<String,Object> params=new HashMap<String,Object>();			
    			params.put("CODIADUAN", declaracionPendiente.getCodiAduan());
    			params.put("ANOPRESE", SunatStringUtils.substring(declaracionPendiente.getAnoPrese(),2,4));
    			params.put("NUMECORRE", declaracionPendiente.getNumeCorre());
    			params.put("NO_LEGAJADO", true);
    			Map<String, Object> declaracionpat = consultaDeclaracionImportacionAdmisionPerfecService.consultarDeclaracionAdmisionPerfec(params);
    			if (declaracionpat == null){
    				iteratordeclaracionPendiente.remove();
    			}else{
    				if (SunatNumberUtils.isEqualToZero(SunatNumberUtils.toInteger(declaracionpat.get("FEC_LEVANTE")))||
        					(tipoDespa.equals(ConstantesDataCatalogo.TIPO_DESPACHO_ANTICIPADO) && 
        							!SunatStringUtils.isEqualTo(SunatStringUtils.toStringObj(declaracionpat.get("COD_TIP_LLEGADA")),ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION))){
    					iteratordeclaracionPendiente.remove();
    				}
    			}      
        	}
        }
        return declaracionesPorRegularizar;
	}
	
	

	public Date getFechaSegundaRecepcionSIGAD(String codaduana, String anoprese, String codiregi, String numecorre){
		
		Date fechSegundaRecepcion = null;
		if (SunatStringUtils.isEqualTo(codiregi, ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
			ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
			Map<String,Object> params=new HashMap<String,Object>();
			params.put("NUMECORRE", numecorre);
			params.put("ANOPRESE", SunatStringUtils.substring(anoprese,2,4));
			params.put("CODIADUAN", codaduana);
			Map<String,Object> declaracionSigad = consultaDeclaracionImpoConsumoService.consultarDeclaracionImportacionConsumo(params, codaduana);
			if (declaracionSigad!= null) {
				fechSegundaRecepcion = SunatDateUtils.getDateFromInteger(SunatNumberUtils.toInteger(declaracionSigad.get("FECH_RECE3")));
			}
		}
		if (SunatStringUtils.isEqualTo(codiregi, ConstantesDataCatalogo.REG_DEPOSITO)){
			ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService =  fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
			Map<String,Object> params=new HashMap<String,Object>();			
			params.put("codiAduan", codaduana);
			params.put("numeCorre", numecorre);
			params.put("anoPrese", SunatStringUtils.substring(anoprese, 2, 4));
			Polizad declaracionDeposito = consultaDeclaracionDepositoAduaneroService.consultarDeclaracionDeposito(params, codaduana).get(0);
			if (declaracionDeposito!= null){
				fechSegundaRecepcion = SunatDateUtils.getDateFromInteger(declaracionDeposito.getFechRece3());
			}
		}

		if (SunatStringUtils.isEqualTo(codiregi, ConstantesDataCatalogo.REG_ADM_TEMP_RME) || SunatStringUtils.isEqualTo(codiregi, ConstantesDataCatalogo.REG_ADM_TEMP_PA)){
			DfrecdocDAO dfrecdocDAO = fabricaDeServicios.getService("tg.model.dfrecdocDAODef");
			DataSourceContextHolder.setKeyDataSource(codaduana);
			Map<String,Object> params=new HashMap<String,Object>();	
			params.put("tipotrami", codiregi.concat("03"));
			params.put("codiaduan", codaduana);
			params.put("anoprese", anoprese);
			params.put("numdui", numecorre);
			params.put("fechrecha", "0"); 
			Dfrecdoc declaracionrecepcion = dfrecdocDAO.select(params);
			if (declaracionrecepcion != null){
				Integer fechingsi = declaracionrecepcion.getFechingsi();
				String horaingsi = declaracionrecepcion.getHoraingsi();
				if (fechingsi.toString().length() == 8 && horaingsi.length() == 6){
					fechSegundaRecepcion = SunatDateUtils.getDate(fechingsi.toString().concat(horaingsi), "yyyyMMddHH:mm:ss");
				}
			}
		}
		return fechSegundaRecepcion;
	}

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
