/*
 * Clase que define el servicio de validaciones de Equipamiento
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.service.EquipamientoDetalleService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValEquipa. Clase que define el servicio de validaciones de Equipamiento.
 */
public class ValEquipaServiceImpl extends ValDuaAbstract implements ValEquipa{
	
	//private FabricaDeServicios fabricaDeServicios;

	/**
	 * Valida la Identificaci�n de equipamiento o contenedor  (furgon o contenedor).<br>
	 * Valida que el par&aacute;metro tenga valor. Se valida adem&aacute;s que los primeros 4 d&iacute;gitos sean letras y los
	 * siguientes 7 d&iacute;gitos del 0 al 9.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numequipo String. Numero de Identificaci�n de equipamiento o contenedor  (furgon o contenedor)
	 * @return Map
	 */
	public Map<String, String> numequipo(String numequipo){
		if (SunatStringUtils.isEmptyTrim(numequipo))
			return getDUAError("00229","");
//		if (numequipo.trim().length()<11)
//			return getDUAError("00229","");
		java.util.Map<String, String> result = numContenedor(numequipo);
		if( result != null )
			return getDUAError("00229","");
		return new HashMap<String,String>();
		
		//if (!SunatStringUtils.isAlphanumeric(numequipo))
//			return getDUAError("00229","");
//		if (!SunatStringUtils.isAlpha(numequipo.trim().substring(0, 4)))
//			return getDUAError("00229","");
//		if (!SunatStringUtils.isNumeric(numequipo.trim().substring(4)))
//			return getDUAError("00229","");
//		return new HashMap<String,String>();
	}

	/**
	 * Valida el C�digo del tama�o del equipamiento.<br> 
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtamequip String
	 * @return Map
	 */
	public Map<String, String> codtamequip(String codtamequip){
		
		if( SunatStringUtils.isEmpty(codtamequip) )
			return new HashMap<String,String>();
		
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("209", codtamequip) )
			//|| FormatoAServiceImpl.getInstance().isValidCatalogo("212", codtamequip))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("209", codtamequip,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30331","Error catalogo codtamequip");
	}

	/**
	 * Valida el C�digo de condici�n del equipamiento.<br>
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codcondequip String. C�digo de condici�n del equipamiento.
	 * @return Map
	 */
	public Map<String, String> codcondequip(String codcondequip){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("210", codcondequip))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("210", codcondequip,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30031","Error catalogo codcondequip");
	}
	
	/**
	 * Valida los numeros de contenedores.
	 * @deprecated No es invocado.
	 * @param arg String
	 * @return el mapa de errores
	 */
	public Map<String, String> numContenedor(String arg) {
//		String tlf="";
//		if (!SunatStringUtils.isEmptyTrim(arg)){
//			for(int i=0;i<arg.length();i++)
//				if(arg.charAt(i)!='(' && arg.charAt(i)!=')' && arg.charAt(i)!='-' && arg.charAt(i)!=' ')
//					tlf+=arg.substring(i, i+1);
//		}
		
		boolean containsDigit=true;
		for(int i=0;i<arg.length();i++){
			if (!SunatStringUtils.isStringInList(arg.substring(i,i+1), "-,/") && !SunatStringUtils.isAlphanumeric(arg.substring(i,i+1))){
				containsDigit=false;
				break;
			}
		}
		if(/*! SunatStringUtils.isNumeric(arg) &&*/ !containsDigit)
		{
			return new HashMap<String, String>();	
		}
		
		return null;
	}
	

	/**
	 * Servicio de Validaci�n que verifica que los contenedores declarados est�n registrados en el manifiesto de carga
	 * @param declaracion
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=3455, descServicio="Validaci�n que verifica que los contenedores declarados est�n registrados en el manifiesto de carga")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=3455,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, String>> valEquipamientoDeclaracion(Declaracion declaracion){
	  return valEquipamientoDeclaracion(declaracion, "0001");
	}
		
	/**
	 * Si codTransaccion esta lleno significa que fue invocado por el SEIDA u Otro Proceso
	 * Si codTransaccion es 9901 (dummy)  significa que fue invocado por Procesos Automaticos 
	 */
	public List<Map<String, String>> valEquipamientoDeclaracion(Declaracion declaracion, String codTransaccion){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		IndicadorDuaService indicadorDuaService = (IndicadorDuaService)fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");		
		boolean tieneIndicadorManifiesto = indicadorDuaService.tieneIndicadorManifiesto(declaracion, codTransaccion);
		
		List<String> listaEquipamientos = new ArrayList<String>();//PAS201930001100004
		for(DatoEquipamiento datoEquip:declaracion.getDua().getManifiesto().getListEquipamientos()){
			String numEquipamiento=datoEquip.getNumequipo();
			if(listaEquipamientos.contains(numEquipamiento)){
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("11557",new String[] {numEquipamiento}));
				continue;
			}else{
				listaEquipamientos.add(numEquipamiento);
				}
			}  
		
		if (tieneIndicadorManifiesto) 
			return listError;	
		
		
		if( declaracion.getDua().getManifiesto()!=null && 
				declaracion.getDua().getManifiesto().getListEquipamientos()!=null && 
				!declaracion.getDua().getManifiesto().getListEquipamientos().isEmpty()){
			Map<String, Object> parameterMap = new HashMap<String, Object>();
			parameterMap.put("codigoTipoManifiesto", declaracion.getDua().getManifiesto().getCodtipomanif());
			parameterMap.put("codigoViaTransporte", declaracion.getDua().getManifiesto().getCodmodtransp());
			parameterMap.put("numeroManifiesto", SunatStringUtils.lpad(SunatNumberUtils.toInteger(declaracion.getDua().getManifiesto().getNummanif()).toString(),6,' '));				
			if (declaracion.getDua().getManifiesto().getAnnmanif()!=null)
				parameterMap.put("anioManifiesto", declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4));
			else {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("00015",new String[] {}));
				return listError;
			}
			
			parameterMap.put("codigoAduana", declaracion.getDua().getManifiesto().getCodaduamanif());

			ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
			List<Manifiesto> listManifiesto = manifiestoService.obtenerManifiestoByParameterMap(parameterMap);
			
			if (listManifiesto!=null && !listManifiesto.isEmpty()){
				Long numCorreDocManifiesto=listManifiesto.get(0).getNumeroCorrelativo();
				EquipamientoDetalleService equipamientoDetalleService = fabricaDeServicios.getService("manifiesto.equipamientoDetalleService");
				//Por cada contenedor declarado verificamos si existe.
//				List<String> listaEquipamientos = new ArrayList<String>();//gmontoya pase 31
				for(DatoEquipamiento datoEquip:declaracion.getDua().getManifiesto().getListEquipamientos()){
					String numEquipamiento=datoEquip.getNumequipo();
//					if(listaEquipamientos.contains(numEquipamiento)){
//						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("11557",new String[] {numEquipamiento}));
//						continue;
//					}else{
//						listaEquipamientos.add(numEquipamiento);
//					}
					Map<String, Object> params = new HashMap<String, Object>();
					String numManifiesto = declaracion.getDua().getManifiesto().getCodaduamanif().concat("-").concat(declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4).
							concat("-").concat(declaracion.getDua().getManifiesto().getCodtipomanif().concat("-").concat(declaracion.getDua().getManifiesto().getNummanif())));
					params.put("numeroCorrelativo", numCorreDocManifiesto);
					params.put("numeroEquipamiento", numEquipamiento);
					//Normalmente retornara un solo registro
					List<String> listDetalleDocumentos = equipamientoDetalleService.selectNumeroDetalleNumeroDocumentoTransporte(params);
					if (CollectionUtils.isEmpty(listDetalleDocumentos)){
						//ERROR NO EXISTE CONTENEDOR EN MANIFIESTO DE CARGA
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("32011",new String[] {numEquipamiento,numManifiesto}));
						continue;
					}
					//Se busca que los Documentos de transporte del Equipamiento formen parte de aquellos enviados en la DUA
					String[] listDoctransporte = listDetalleDocumentos.toArray(new String[listDetalleDocumentos.size()]);
			        String listDoctransporteString = StringUtils.arrayToCommaDelimitedString(listDoctransporte);
			        boolean encontroEquipamiento = false;
			        String documentoTransporteDuaString = new String();
					for(DatoDocTransporte docTransp:declaracion.getDua().getListDocTransporte()){
						String numDocTransporteDUA = docTransp.getNumdoctransporte();
						documentoTransporteDuaString = documentoTransporteDuaString.concat("(").concat(numDocTransporteDUA).concat(") "); 
						if (StringUtils.countOccurrencesOf(listDoctransporteString,numDocTransporteDUA)>0) {
							encontroEquipamiento = true;
							break;
						}
					}
					//ERROR Equipamiento no se encuentra asociado a documentos de transporte declarados en el manifiesto.
					if (!encontroEquipamiento){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("32012",new String[] {numEquipamiento,numManifiesto,documentoTransporteDuaString}));						
					}
					
				}
			}
		}		
		return listError;
	}
		
	
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
