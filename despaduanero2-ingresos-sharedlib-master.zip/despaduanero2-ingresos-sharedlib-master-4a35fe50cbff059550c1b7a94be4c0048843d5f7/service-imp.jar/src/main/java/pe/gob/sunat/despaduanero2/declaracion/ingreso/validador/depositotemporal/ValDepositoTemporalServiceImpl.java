package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.depositotemporal;

import java.util.*;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;

public class ValDepositoTemporalServiceImpl  extends IngresoAbstractServiceImpl implements ValDepositoTemporalService {
	
	//Metodo Gral usado para DSEER y MDEER
	public List<Map<String, String>> valEstadoRegistroDTEERGral(String numRuc){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		
		
		OperadorValidaService operadorValidaService = fabricaDeServicios.getService("Ayuda.operadorValidaServicePrincipal");
		
		List<Map<String, String>> listValidarOperador = operadorValidaService.validarOperador(
				numRuc, 
				ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER);
		
		if (!CollectionUtils.isEmpty(listValidarOperador)) { 
			for (Map<String, String> validarOperador : listValidarOperador) {
				if (validarOperador.containsValue(Constantes.ERR_OPERADOR_NO_REGISTRADO)){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70107",
							new String[] { numRuc }));
				}
			}
		}		   
		return listError;
	}
	
	public List<Map<String, String>> valEstadoRegistroDTEER(Declaracion declaracion) {				
		String numRuc = declaracion.getDua().getDepositoTemporal().getNumeroDocumentoIdentidad();
		return valEstadoRegistroDTEERGral(numRuc);
	}
	
	public List<Map<String, String>> valEstadoHabilitacionDTEERGral(String numRuc) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		
		
		OperadorValidaService operadorValidaService = fabricaDeServicios.getService("Ayuda.operadorValidaServicePrincipal");
		
		List<Map<String, String>> listValidarOperador = operadorValidaService.validarOperador(
				numRuc, 
				ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER);
		
		if (!CollectionUtils.isEmpty(listValidarOperador)) { 
			for (Map<String, String> validarOperador : listValidarOperador) {
				if (validarOperador.containsValue(Constantes.ERR_OPERADOR_INHABILITADO)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70108",
							new String[] { numRuc }));
				}
			}
		}
		
		return listError;
	}

	public List<Map<String, String>> valEstadoHabilitacionDTEER(Declaracion declaracion) {		
		String numRuc = declaracion.getDua().getDepositoTemporal().getNumeroDocumentoIdentidad();
		return valEstadoHabilitacionDTEERGral(numRuc);
	}
		   
	public List<Map<String, String>> valEstadoNumeroRucDTEERGral(String numRuc){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		
		
		OperadorValidaService operadorValidaService = fabricaDeServicios.getService("Ayuda.operadorValidaServicePrincipal");
		
		List<Map<String, String>> listValidarOperador = operadorValidaService.validarOperador(
				numRuc, 
				ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER);
		
		
		if (!CollectionUtils.isEmpty(listValidarOperador)) { 
			for (Map<String, String> validarOperador : listValidarOperador) {
				if (validarOperador.containsValue(Constantes.ERR_RUC_NO_ACTIVO)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70109",
							new String[] { numRuc }));
				}else if (validarOperador.containsValue(Constantes.ERR_RUC_INVALIDO)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70156",
							new String[] { numRuc }));
				}
			}
		}
		return listError;
	}
	
	public List<Map<String, String>> valEstadoNumeroRucDTEER(Declaracion declaracion) {		
		String numRuc = declaracion.getDua().getDepositoTemporal().getNumeroDocumentoIdentidad();		
		return valEstadoNumeroRucDTEERGral(numRuc);
	}
	
	public List<Map<String, String>> valCondicionNumeroRucDTEERGral(String numRuc){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		OperadorValidaService operadorValidaService = fabricaDeServicios.getService("Ayuda.operadorValidaServicePrincipal");
		
		List<Map<String, String>> listValidarOperador = operadorValidaService.validarOperador(
				numRuc, 
				ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER);
		
		if (!CollectionUtils.isEmpty(listValidarOperador)) { 
			for (Map<String, String> validarOperador : listValidarOperador) {
				if (validarOperador.containsValue(Constantes.ERR_RUC_NO_HABIDO)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70110",
							new String[] { numRuc }));
				}
			}
		}		  
		return listError;
	}
	
	public List<Map<String, String>> valCondicionNumeroRucDTEER(Declaracion declaracion) {
		
		String numRuc = declaracion.getDua().getDepositoTemporal().getNumeroDocumentoIdentidad();
		return valCondicionNumeroRucDTEERGral(numRuc);
	}
		   
	public List<Map<String, String>> valCircunscripcionDTEERGral(String numRuc, String codAduana){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		
		
		OperadorValidaService operadorValidaService = fabricaDeServicios.getService("Ayuda.operadorValidaServicePrincipal");
		
		List<Map<String, String>> listValidarOperador = operadorValidaService.validarOperador(
				numRuc, 
				ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER,
				codAduana,
				new Date());
		
		if (!CollectionUtils.isEmpty(listValidarOperador)) { 
			for (Map<String, String> validarOperador : listValidarOperador) {
				if (validarOperador.containsValue(Constantes.ERR_ADUANA_NO_REGISTRADO) || validarOperador.containsValue(Constantes.ERR_ADUANA_INHABILITADO)) { //mlaura 03082018
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70111",
							new String[] { numRuc, codAduana }));
				}
			}
		}
		return listError;
	}
	
	public List<Map<String, String>> valCircunscripcionDTEER(Declaracion declaracion) {
		
		String numRuc = declaracion.getDua().getDepositoTemporal().getNumeroDocumentoIdentidad();
		String codAduana = declaracion.getCodaduana();		
		return valCircunscripcionDTEERGral( numRuc, codAduana);
	}
}
