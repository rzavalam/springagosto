package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_NUMERACION;
import static pe.gob.sunat.estrategico2.aduanero.vuce.util.Constantes.INDICADOR_CERT_ELECTRONICO; //PAS20181U220200056

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen.CertiOrigenElectronicoService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.ContingentesUtil;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaEntidadService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
import pe.gob.sunat.despaduanero2.declaracion.model.CabCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPrecinto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DocumentoSoporteFormatoB;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjAtpaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FinUbicacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionBatchService;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.Equipamiento;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.MovimientoDeEquipamiento;
import pe.gob.sunat.despaduanero2.manifiesto.model.Precinto;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.EquipamientoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.MovEquipamientoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.PrecintoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.DocumentoDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.estrategico2.aduanero.vuce.model.acuerdo.DocCertificadoOrigen;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
//import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.manifiesto.consulta.service.ProrrogaService;
import pe.gob.sunat.despaduanero2.manifiesto.util.Constantes;

public class GrabarFormatoAServiceImpl extends ValDuaAbstract implements GrabarFormatoAService{

	//private SequenceDAO sequenceDAO;
	//private DocumentoDAO documentoDAO;
	//private CabDeclaraDAO cabDeclaraDAO;
	//private CabAdjAtpaDAO cabAdjAtpaDAO;
	//private FinUbicacionDAO finUbicacionDAO;
	//private EquipamientoDAO equipamientoDAO;
	//private ParticipanteDocDAO participanteDAO;
	//private PrecintoDAO precintoDAO;
	//private ObservacionDAO observacionDAO;
	//private IndicadorDUADAO indicadorDUADAO;
	//private DocAutAsociadoDAO docAutAsociadoDAO;
	//private CabAdjImpoconsuDAO cabAdjImpoconsuDAO;
	//private MovEquipamientoDAO movEquipamientoDAO;
	//private ManifiestoService manifiestoService;
	//private ProveedorFuncionesService funcionesService;
	//private FabricaDeServicios fabricaDeServicios; 

	//private DeclaracionBatchService declaracionBatchService;
	//private ProrrogaService prorrogaService;
	//private CatalogoAyudaService catalogoAyudaService;

	public Map<String,String> grabaFA(Declaracion declaracion, String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender,Date fechaConclusionDespa, String numOrden, String codTransaccion) throws Exception{
		// HSAENZ: 08/09/2014: Todo lo que se tenia anteriormente en este metodo, pasa al metodo grabaFormatoA
		//         Llama a nuevo metodo, la fecha de vencimiento de conclusion por defecto pasa el valor null 
		Date fechaVencimientoConclusion = null;
		return grabaFormatoA(declaracion, tipoSender, numeroDocumentoIdentidadSender, tipoDocumentoIdentidadSender, fechaConclusionDespa, numOrden, codTransaccion, fechaVencimientoConclusion);
		//Fin HSAENZ: 08/09/2014
	}

	
	public Map<String,String> grabaFormatoA(Declaracion declaracion, String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender,Date fechaConclusionDespa, String numOrden, String codTransaccion, 
			Date fechaVencimientoConclusion )  throws Exception {
		return 	grabaFormatoA(declaracion, tipoSender, numeroDocumentoIdentidadSender, tipoDocumentoIdentidadSender,fechaConclusionDespa, numOrden, codTransaccion, fechaVencimientoConclusion, null ); 
	}

 
	
	/*
	 * PAS20181U220200022: se trajo toda la logica existente de marcado, 
	 * los cambios de la norma se gestionan por la vigencia del catalogo 380, c�digo 0034
	 * para que se inscriba en todas las trx necesarias
	 * por si en algun momento cambian la logica del marcado
	 * para recti y numeracion
	 * oficio usa diligenciaserviceImpl.grabarRectificaManual *puro mapas!
	 * 
	 */	
	public void grabarIndicadorImportadorFrecuente(Declaracion declaracion, String codTransaccion) {
		
		try {
			ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
			 
			//Boolean actualizaCtaCteContingente = variablesIngreso.get("actualizaCtaCteContingente") == null ? Boolean.FALSE :  (Boolean)variablesIngreso.get("actualizaCtaCteContingente");
			//int nroErrores = variablesIngreso.get("nroErrores")== null ? 0 : (Integer)variablesIngreso.get("nroErrores");
			
			Long numCorreDoc = SunatStringUtils.isEqualTo(codTransaccion, ConstantesDataCatalogo.TRANSACCION_NUMERACION)
					?declaracion.getNumeroCorrelativo():declaracion.getDua().getNumcorredoc();
			String codregimen = declaracion.getDua().getCodregimen().toString();
			Date fechaNumeracion = SunatStringUtils.isEqualTo(codTransaccion, ConstantesDataCatalogo.TRANSACCION_NUMERACION)?new Date():declaracion.getDua().getFecNumeracion();
			String codModalidad = declaracion.getDua().getCodmodalidad();
			Elementos<DatoSerie> listSeries = declaracion.getDua().getListSeries();
			
			String tipoDocum = "";
			String numeDocum = "";
			boolean vaIndicadorImpFrecuente = false;
			
			//si es importador frecuente
			if (SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getTipoParticipante().getCodDatacat(),
					ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
				tipoDocum = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
				numeDocum = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
			}
			
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> MapaModImporFrec =catalogoAyudaService.getElementoCat("380", "0034",fechaNumeracion);
			
			Map<String,Object> mapIndicadoresDUAExiste=new HashMap<String, Object>();
			mapIndicadoresDUAExiste.put("num_corredoc", numCorreDoc);
			mapIndicadoresDUAExiste.put("cod_indicador", "05");
			 
			//Antigua validacion:
			if ( CollectionUtils.isEmpty(MapaModImporFrec)){
				if (funcionesService.isImportadorFrecuente(codregimen, tipoDocum, numeDocum)) {
					vaIndicadorImpFrecuente = true;					
				}
			}else {
				//R1804: ATRG201802 PAS20181U220200022 Los beneficios del importador frecuente se aplican solo cuando se numera una 
				//declaraci�n de modalidad anticipada de los reg�menes 10,20,21,
				//o modalidad de despacho urgente o diferido del r�gimen 10 sujeta a una cuota o contingente arancelario. 
				vaIndicadorImpFrecuente = esImportadorFrecuenteNuevasCondiciones(codregimen, tipoDocum, numeDocum, codModalidad, listSeries);
			}
			
			actualizarIndicadorImportadorFrecuente(numCorreDoc, vaIndicadorImpFrecuente) ;
			
			
		}catch (Exception e) { 
			e.printStackTrace(); //Si existe error en envio a VUCE no debe impedir la numeracion
			log.error("Error al momento de Registrar el Indicador de Importador Frecuente para la DAM:"+e.getMessage());
		}
	}
	
	public boolean esImportadorFrecuenteNuevasCondiciones(String codregimen, String tipoDocum, String numeDocum, String codModalidad, Elementos<DatoSerie>listSeries){
		return esImportadorFrecuenteNuevasCondiciones( codregimen,  tipoDocum,  numeDocum,  codModalidad, listSeries, false);
	}
		
		
	//R1804: ATRG201802 PAS20181U220200022 Los beneficios del importador frecuente se aplican solo cuando se numera una 
	//declaraci�n de modalidad anticipada de los reg�menes 10,20,21,
	//o modalidad de despacho urgente o diferido del r�gimen 10 sujeta a una cuota o contingente arancelario. 
	public boolean esImportadorFrecuenteNuevasCondiciones(String codregimen, String tipoDocum, String numeDocum, String codModalidad, Elementos<DatoSerie>listSeries, boolean tieneMargenYTpi){
		boolean indImpFrecuente = false; 
        boolean tieneContingente = false;
        boolean vaIndicadorImpFrecuente = false;
        
        ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		
        if (funcionesService.isImportadorFrecuente(codregimen, tipoDocum, numeDocum)) {
        	indImpFrecuente = true;
        }  
        if (indImpFrecuente) {	            
        	if(codModalidad.equals( ConstantesDataCatalogo.MODA_ANTICIPADA ) ) {
        		vaIndicadorImpFrecuente = true;
        	}
        	
        	if(codModalidad.equals( ConstantesDataCatalogo.MODA_URGENTE )
        			|| codModalidad.equals( ConstantesDataCatalogo.MODA_EXCEPCIONAL)) {
        		
        		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
        		
        		if(listSeries!=null && listSeries.size()>0){
	    			for (DatoSerie serie : listSeries)
	    			{ 
	    				String tipoMargen = serie.getCodtipomarge() == null ? "":serie.getCodtipomarge();
	    				if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen )) {
	    					tieneContingente = true;
	    					break;
	    				}
	    			}
        		}else{//para recti oficio
        			tieneContingente = tieneMargenYTpi;
        		}
        		
	        	if(tieneContingente)vaIndicadorImpFrecuente = true;
        	}
        } 
        
        return vaIndicadorImpFrecuente;
	}
	
	/**
	 * Gestiona el grabado, si corresponde graba actualiza o rehabilita el indicador
	 * @param numCorreDoc
	 * @param vaIndicadorImpFrecuente
	 */
	public void actualizarIndicadorImportadorFrecuente(Long numCorreDoc, boolean vaIndicadorImpFrecuente) {
		
		Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
		Map<String,Object> mapIndicadoresDUAExiste=new HashMap<String, Object>();
		mapIndicadoresDUAExiste.put("num_corredoc", numCorreDoc);
		mapIndicadoresDUAExiste.put("cod_indicador", "05");
		IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
		
		int existeIndicador = ((BigDecimal) indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(mapIndicadoresDUAExiste).get("CANT")).intValue();
		
		if(vaIndicadorImpFrecuente){
			if(existeIndicador==0){
	            mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
	            mapIndicadoresDUA.put("codIndicador", "05");
				mapIndicadoresDUA.put("codTiporegistro", "A");
				indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
				log.info("Se grabo el indicador de importador frecuente a la dam: "+numCorreDoc);
			}else{
				mapIndicadoresDUAExiste.put("ind_activo", "0");
				int estaDesactivado = ((BigDecimal) indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(mapIndicadoresDUAExiste).get("CANT")).intValue();
				
				if(estaDesactivado>0){
		            mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
		            mapIndicadoresDUA.put("codIndicador", "05");
					mapIndicadoresDUA.put("indActivo", "1");
					indicadorDUADAO.update(mapIndicadoresDUA);
					log.info("Se revive el indicador de importador frecuente a la dam: "+numCorreDoc);
				}
			}								
        } else {
			if(existeIndicador > 0){
	            mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
	            mapIndicadoresDUA.put("codIndicador", "05");
				mapIndicadoresDUA.put("codTiporegistro", "A");
				mapIndicadoresDUA.put("indActivo", "0");
				indicadorDUADAO.update(mapIndicadoresDUA);
				log.info("Se actualizo el indicador de importador frecuente a la dam: "+numCorreDoc);
			}								
		
        }
		 
	}
	
	/**
	 * @author hsaenz
	 * @since 08/09/2014
	 * Grabar. 
	 */	
	public Map<String,String> grabaFormatoA(Declaracion declaracion, String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender,Date fechaConclusionDespa, String numOrden, String codTransaccion, 
			Date fechaVencimientoConclusion, List<DatoDocAutorizante> listaVUCE) throws Exception{
		DocumentoDAO documentoDAO = (DocumentoDAO) fabricaDeServicios.getService("documentoDAO");
		Map<String,String> mapRpta=new HashMap<String,String>();
		
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",declaracion.getDua().getFecNumeracion());
				
		/*try{*/
		FechaBean fbCurrent=new FechaBean();
		Integer anho=new Integer(fbCurrent.getAnho());

		Long numCorreDoc=declaracion.getNumeroCorrelativo();
		Long numDeclaracion= declaracion.getNumeroDeclaracion();

		declaracion.setNumeroCorrelativo(numCorreDoc);
		declaracion.getDua().setNumcorredoc(numCorreDoc);

		declaracion.getDua().setAnnpresen(anho);
		declaracion.setAnnorden(numOrden.substring(0, 4));

		Documento documento=new Documento();
		documento.setNumeroCorrelativo(numCorreDoc);
		documento.setEstado("00");
		String codtipdoc=null;

		if (! codTransaccion.substring(2, 4).equals(ConstantesDataCatalogo.TRANSACCION_NUMERACION)) {
			declaracion.getNumdeclRef().setNumcorre(String.valueOf(numDeclaracion));
			declaracion.getNumdeclRef().setAnnprese(anho.toString());
			codtipdoc=declaracion.getNumdeclRef().getCodtipodoc();
		}

		documento.setTipoDocumento(codtipdoc==null?"929":codtipdoc);

		documento.setCodAduana(declaracion.getCodaduana());
		documento.setFechaGeneracion( SunatDateUtils.getCurrentDate() );
		documentoDAO.insertSelective(documento);
		//insert cab_declara
		Map<String,Object> mapCabDeclara=new HashMap<String,Object>();
		// HSAENZ: 08/09/2014: Se modifica metodo para pasar fecha de vencimiento de conclusion
		//fillCabDeclara(mapCabDeclara,declaracion,numCorreDoc,numDeclaracion,fechaConclusionDespa,numOrden,codTransaccion);
		fillCabDeclara(mapCabDeclara,declaracion,numCorreDoc,numDeclaracion,
				fechaConclusionDespa,numOrden,codTransaccion,fechaVencimientoConclusion);
		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
		cabDeclaraDAO.insertMapSelective(mapCabDeclara);

		//insert cab_adj_atpa
		if("20".equals(declaracion.getDua().getCodregimen()) || "70".equals(declaracion.getDua().getCodregimen())){
			Map<String,Object> mapCabAdjAtpa=new HashMap<String,Object>();
			if (fillCabAdjAtpa(mapCabAdjAtpa,declaracion,numCorreDoc)){
				CabAdjAtpaDAO cabAdjAtpaDAO = (CabAdjAtpaDAO) fabricaDeServicios.getService("cabAdjAtpaDAO");
				FinUbicacionDAO finUbicacionDAO = (FinUbicacionDAO) fabricaDeServicios.getService("finUbicacionDAO");
				cabAdjAtpaDAO.insertMapSelective(mapCabAdjAtpa);
				//insert fin_ubicacion
				Map<String,Object> mapFinUbicacion=new HashMap<String,Object>();
				if (fillFinUbicacion(mapFinUbicacion,declaracion,numCorreDoc))
					finUbicacionDAO.insertMapSelective(mapFinUbicacion);
			}
		}

		//insert adj_transito
		//TODO DESCOMENTAR MAS ADELANTE
		//			Map<String,Object> mapAdjTransito=new HashMap<String,Object>();
		//			fillAdjTransito(mapAdjTransito,declaracion,numCorreDoc);
		//			cabAdjTransitoDAO.insertMapSelective(mapAdjTransito);


		//insert participante_doc
		SequenceDAO sequenceDAO = (SequenceDAO) fabricaDeServicios.getService("Framework.sequenceDef");
		ParticipanteDocDAO participanteDAO = (ParticipanteDocDAO) fabricaDeServicios.getService("participanteDAO");
		Long numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);

		//insert participante_doc			
		Participante rucAnUb=declaracion.getDua().getRucAnexoUbicacion();
		if(rucAnUb!=null && ! SunatStringUtils.isEmpty(rucAnUb.getNumeroDocumentoIdentidad()) )
		{
			rucAnUb.setSecuenciaDeParticipantes(numSecParticipante);
			rucAnUb.getDocumento().setNumeroCorrelativo(numCorreDoc);
			rucAnUb.getTipoParticipante().setCodDatacat("94");
			participanteDAO.insertSelective((Participante)rucAnUb);

			numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);

		}

		Participante declarante=declaracion.getDua().getDeclarante();
		declarante.setSecuenciaDeParticipantes(numSecParticipante);
		declarante.getDocumento().setNumeroCorrelativo(numCorreDoc);
		declarante.getTipoParticipante().setCodDatacat("45");
		//RectificacionServiceImpl.getInstance().getSoporteService().completarParticipante(declarante);
		((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).completarParticipante(declarante);
		participanteDAO.insertSelective((Participante)declarante);
	
		Participante agente=new Participante();
		agente.getDocumento().setNumeroCorrelativo(numCorreDoc);
		numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
		agente.setSecuenciaDeParticipantes(numSecParticipante);
		fillAgente(agente,tipoSender,declaracion.getDua().getNumdocumento(),declaracion.getDua().getCodtipooper());
		participanteDAO.insertSelective(agente);

		//insert empresa transporte
		if (declaracion.getDua().getManifiesto()!=null && declaracion.getDua().getManifiesto().getEmpTransporte()!=null){

			Participante empTransporte=declaracion.getDua().getManifiesto().getEmpTransporte();

			if(empTransporte!=null && ! SunatStringUtils.isEmpty(empTransporte.getNumeroDocumentoIdentidad() ))
			{
				ManifiestoService manifiestoService = (ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService");
				String viaTransporte=declaracion.getDua().getManifiesto().getCodmodtransp();
				
				/** inicio PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:**/
				boolean considerarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
				Manifiesto manifiesto = null;				
				if(!ResponseListManager.responseListHasErrors(listaOMA)){
					manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
							declaracion.getDua().getManifiesto().getCodmodtransp(), 
							declaracion.getDua().getManifiesto().getCodaduamanif(), 
							Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
							declaracion.getDua().getManifiesto().getNummanif(),true,declaracion.getDua().getFecNumeracion(),considerarEER);					
			
				}else{
					manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
						declaracion.getDua().getManifiesto().getCodmodtransp(), 
						declaracion.getDua().getManifiesto().getCodaduamanif(), 
						Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
						declaracion.getDua().getManifiesto().getNummanif(),true);
				}		
				/***fin PAS20181U220200049***/
				//Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
				//		declaracion.getDua().getManifiesto().getCodmodtransp(), 
				//		declaracion.getDua().getManifiesto().getCodaduamanif(), 
				//		Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
				//		declaracion.getDua().getManifiesto().getNummanif(),true);

				String codTipoOper= ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
				if (manifiesto != null) {
					if (manifiesto.getTransportista().getTipoParticipante().getCodDatacat()!= null){
						codTipoOper = manifiesto.getTransportista().getTipoParticipante().getCodDatacat();
					}
				} else {
					if (Constants.COD_VIA_TRANSPORTE_MARITIMO.equals(viaTransporte)){
						codTipoOper=ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA;
					}else if (Constants.COD_VIA_TRANSPORTE_AEREA.equals(viaTransporte)){
						codTipoOper=ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
					}						
				}						
				numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
				empTransporte.getDocumento().setNumeroCorrelativo(numCorreDoc);
				empTransporte.setSecuenciaDeParticipantes(numSecParticipante);
				empTransporte.getTipoParticipante().setCodDatacat(codTipoOper);

				//RectificacionServiceImpl.getInstance().getSoporteService().completarParticipante(empTransporte);
				((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).completarParticipante(empTransporte);
				if (empTransporte.getNombreRazonSocial() == null || SunatStringUtils.isEmptyTrim(empTransporte.getNombreRazonSocial())){
					if (manifiesto != null) {
						empTransporte.setNombre(manifiesto.getTransportista().getNombreRazonSocial());
						empTransporte.setNombreRazonSocial(manifiesto.getTransportista().getNombreRazonSocial());
					}
				}

				participanteDAO.insertSelective(empTransporte);
			}
		}

		//Crea el Participante de deposito aduanero
		Participante depositoTemporal = new Participante();
		numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
		depositoTemporal.getDocumento().setNumeroCorrelativo(numCorreDoc);
		depositoTemporal.setSecuenciaDeParticipantes(numSecParticipante);
		depositoTemporal.getTipoParticipante().setCodDatacat("31");
		depositoTemporal.getTipoDocumentoIdentidad().setCodDatacat("4");
		depositoTemporal.setNumeroDocumentoIdentidad(declaracion.getDua().getNumruclugarecep());
		//PAS20191U220200019 - mtorralba 20190528 - Se obtiene tipo de operador asociado al punto de llegada
		String tipoOperador = obtenerOperadorPorPuntoLlegada(declaracion.getDua().getCodlugarecepcion().toString());
		DataCatalogo rolParticipante = new DataCatalogo();
		rolParticipante.setCodCatalogo("123");
		rolParticipante.setCodDatacat(tipoOperador);
		depositoTemporal.setRolParticipante(rolParticipante);

		//RectificacionServiceImpl.getInstance().getSoporteService().completarParticipante(depositoTemporal);
		((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).completarParticipante(depositoTemporal);
		participanteDAO.insertSelective(depositoTemporal);


		if( SunatStringUtils.isEqualTo(declaracion.getDua().getCodregimen(), "70")  )
		{
			Participante depositoAduanero = new Participante();
			numSecParticipante=sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
			depositoAduanero.getDocumento().setNumeroCorrelativo(numCorreDoc);
			depositoAduanero.setSecuenciaDeParticipantes(numSecParticipante);
			depositoAduanero.getTipoParticipante().setCodDatacat("32");
			depositoAduanero.getTipoDocumentoIdentidad().setCodDatacat("4");
			depositoAduanero.setNumeroDocumentoIdentidad(declaracion.getDua().getNumrucdeposito());
			((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).completarParticipante(depositoAduanero);
			participanteDAO.insertSelective(depositoAduanero);
		}


		//insert equipamiento
		//TODO
		MercanciaRestringidaEntidadService mRestriEntidadService = (MercanciaRestringidaEntidadService) fabricaDeServicios.getService("mercanciaRestringidaEntidadService");
		DeclaracionBatchService declaracionBatchService = (DeclaracionBatchService) fabricaDeServicios.getService("declaracion.DeclaracionBatchService");
		declaracionBatchService.iniciarRegistrarDeclaracionesFormatoA();
		mRestriEntidadService.iniciaBatchAutorizante();
		if( !declaracion.getDua().getManifiesto().getListEquipamientos().isEmpty()){
			PrecintoDAO precintoDAO = (PrecintoDAO) fabricaDeServicios.getService("manifiesto.precintoDAO");
			for(DatoEquipamiento datoEquip:declaracion.getDua().getManifiesto().getListEquipamientos()){
				String numEquipamiento=datoEquip.getNumequipo();
				Equipamiento equipamiento=new Equipamiento();
				equipamiento.setNumeroEquipamiento(numEquipamiento);
				equipamiento.getSubTipoTamanio().setCodDatacat(datoEquip.getCodtamequip());
				equipamiento.getIndicadorLlenado().setCodDatacat(datoEquip.getCodcondequip());

				equipamiento.setManifiesto( new Manifiesto() );
				if( declaracion.getDua().getManifiesto().getNummanif() != null && 
						declaracion.getDua().getManifiesto().getAnnmanif() !=null && 
						declaracion.getDua().getManifiesto().getCodaduamanif()!=null)
				{
					/* equipamiento.getManifiesto().setCodAduana(declaracion.getDua().getManifiesto().getCodaduamanif());
					 * PAS20112A600000721 Se cambia el modo de grabar los datos del manifiesto asociado al equipamiento	
					 */
					equipamiento.getManifiesto().setAduana(new DataCatalogo());
					equipamiento.getManifiesto().getAduana().setCodDatacat(declaracion.getDua().getManifiesto().getCodaduamanif());
					equipamiento.getManifiesto().setAnioManifiesto( new Integer(declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4)));
					equipamiento.getManifiesto().setNumeroManifiesto(SunatStringUtils.lpad(declaracion.getDua().getManifiesto().getNummanif(),6,' '));
					equipamiento.getManifiesto().setTipoManifiesto(new DataCatalogo());
					equipamiento.getManifiesto().getTipoManifiesto().setCodDatacat(declaracion.getDua().getManifiesto().getCodtipomanif());
					equipamiento.getManifiesto().setViaTransporte(new DataCatalogo());
					equipamiento.getManifiesto().getViaTransporte().setCodDatacat(declaracion.getDua().getManifiesto().getCodmodtransp());								
				}

				//equipamiento.getManifiesto().setNumeroCorrelativo(numCorreDocManifiesto);				
				equipamiento.getManifiesto().setNumeroCorrelativo(declaracion.getNumeroCorrelativo());
				EquipamientoDAO equipamientoDAO = (EquipamientoDAO) fabricaDeServicios.getService("manifiesto.equipamientoDAO");
				MovEquipamientoDAO movEquipamientoDAO = (MovEquipamientoDAO) fabricaDeServicios.getService("manifiesto.movEquipamientoDAO");
				equipamientoDAO.insertSelective(equipamiento);

				MovimientoDeEquipamiento movEquipamiento=new MovimientoDeEquipamiento();
				movEquipamiento.setTipoMovimiento(new DataCatalogo());
				movEquipamiento.getTipoMovimiento().setCodDatacat("99");
				movEquipamiento.setEquipamiento(equipamiento);
				movEquipamiento.setOperadorCarga(declarante);
				movEquipamientoDAO.insertSelectivo(movEquipamiento);
				if (datoEquip.getListPrecintos()!=null)
					for(DatoPrecinto datoPrecin:datoEquip.getListPrecintos()){
						//insert precinto
						Precinto precinto=new Precinto();

						precinto.setNumeroDePrecinto(datoPrecin.getNumprecinto());
						if(precinto.getMovimientoDeEquipamiento()==null)
							precinto.setMovimientoDeEquipamiento(new MovimientoDeEquipamiento());
						if (precinto.getMovimientoDeEquipamiento().getTipoMovimiento()==null)
							precinto.getMovimientoDeEquipamiento().setTipoMovimiento(new DataCatalogo());
						precinto.getMovimientoDeEquipamiento().getTipoMovimiento().setCodDatacat("99");
						if(precinto.getMovimientoDeEquipamiento().getEquipamiento()==null)
							precinto.getMovimientoDeEquipamiento().setEquipamiento(new Equipamiento());
						if(precinto.getMovimientoDeEquipamiento().getEquipamiento().getManifiesto()==null)
							precinto.getMovimientoDeEquipamiento().getEquipamiento().setManifiesto(new Manifiesto());
						precinto.getMovimientoDeEquipamiento().getEquipamiento().setNumeroEquipamiento(datoEquip.getNumequipo());
						//precinto.getMovimientoDeEquipamiento().getEquipamiento().getManifiesto().setNumeroCorrelativo(numCorreDocManifiesto);
						precinto.getMovimientoDeEquipamiento().getEquipamiento().getManifiesto().setNumeroCorrelativo(declaracion.getNumeroCorrelativo());
						precintoDAO.insertSelective(precinto);
					}
			}
		}

		//insert observacion
		ObservacionDAO observacionDAO = (ObservacionDAO) fabricaDeServicios.getService("observacionDAO");
		for(Observacion obs:declaracion.getDua().getListObservaciones()){
			obs.setNumcorredoc( declaracion.getNumeroCorrelativo()  );
			observacionDAO.insert(obs);
		}

		//insert indicador_dua
		IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
		Map<String,Object> mapIndicadorDUA=new HashMap<String,Object>();
		for(DatoIndicadores indicador:declaracion.getDua().getListIndicadores()){

			if(! SunatStringUtils.isEmpty(indicador.getCodtipoindica()) )
			{
				// PAS20155E220000521 Solo se considera el indicador importador frecuente cuando se encuentra en el cat�logo de la SUNAT de importadores frecuentes.
				//region amancillaa SDA2-RIN18-PAS20171U220200035
				if(indicador.getCodtipoindica().equals(ConstantesDataCatalogo.INDICADOR_IMPORTADOR_FRECUENTE)
						|| ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA.equals(indicador.getCodtipoindica())){
					continue;
				}
				//endregion amancillaa
				fillIndicadorDUA(mapIndicadorDUA,declaracion,indicador,numCorreDoc);
				indicadorDUADAO.insertMapSelective(mapIndicadorDUA);					
			}
		}

		//PAS20181U220200022 solo se queda esto:
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		 
		String numeDocum = "";
		if (SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getTipoParticipante().getCodDatacat(),
				ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
			numeDocum = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
		}
		
		/*
		 * PAS20181U220200022: 
		 * Se va a comentar todo esto para que sea un metodo externo, mucho codigo que se puede reusar:
		 * usar grabarIndicadorImportadorFrecuente que ahora se puede invocar desde cualquier metodo
		 * 
		 */
		/*ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");

		String tipoDocum = "";
		String numeDocum = "";
		//si es importador frecuente
		if (SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getTipoParticipante().getCodDatacat(),
				ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
			tipoDocum = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
			numeDocum = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
		}

		//PAS20155E220000521 para todas las modalidadles no solo para el anticipado, se marca el importador frecuente
		//            if ((declaracion.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)) && 
		//                  (funcionesService.isImportadorFrecuente(declaracion.getDua().getCodregimen().toString(), tipoDocum, numeDocum))) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> MapaModImporFrec =catalogoAyudaService.getElementoCat("380", "0034",declaracion.getDua().getFecNumeracion());
		if ( CollectionUtils.isEmpty(MapaModImporFrec)){
		if (funcionesService.isImportadorFrecuente(declaracion.getDua().getCodregimen().toString(), tipoDocum, numeDocum)) {
			Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
			mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
			//PAS20155E220000521
			//mapIndicadoresDUA.put("codIndicador", "03");
			//PAS20155E220200019 Se pone el tipo de registro para que no se pueda modificar
			mapIndicadoresDUA.put("codIndicador", "05");
			mapIndicadoresDUA.put("codTiporegistro", "A");
			indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
		}
		} else {
				boolean indImpFrecuente = false; 
	            if (funcionesService.isImportadorFrecuente(declaracion.getDua().getCodregimen().toString(), tipoDocum, numeDocum)) {
	            	indImpFrecuente = true;
	            } else {
	    			Map<String, Object> MapaInvitadoOEA =catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.CATALOGO_INVITADO_OEA, numeDocum,declaracion.getDua().getFecNumeracion());
	    			if (!CollectionUtils.isEmpty(MapaInvitadoOEA)){
	    				indImpFrecuente = true;
	    			}	            	
	            } 
	            if (indImpFrecuente && declaracion.getDua().getCodmodalidad().equals( ConstantesDataCatalogo.MODA_ANTICIPADA ) ) {
	            		  Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
		                   mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
		                   mapIndicadoresDUA.put("codIndicador", "05");
		                   mapIndicadoresDUA.put("codTiporegistro", "A");
		                   indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
	            	} 
	            }  
		}*/
		
		ManifiestoService manifiestoService = (ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService");
		ProrrogaService prorrogaService = (ProrrogaService) fabricaDeServicios.getService("manifiesto.prorrogaService");
		//region amancillaa SDA2-RIN18-PAS20171U220200035
		if (!"70".equals(declaracion.getDua().getCodregimen()) && funcionesService.isOEA(numeDocum,declaracion.getDua().getFecNumeracion())) {
		//if (funcionesService.isOEA(numeDocum,declaracion.getDua().getFecNumeracion())) {
			Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
			mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
			mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
			mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_AUTOMATICO);
			indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
		}
		//endregion amancillaa
		DataCatalogo catPlazoModalidadDiferida = catalogoAyudaService.getDataCatalogo(
				ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,ConstantesDataCatalogo.COD_PLAZO_VALIDACION_NUEVA_LGA );
		Date fecVigenciaLGA = catPlazoModalidadDiferida.getFecInidatcat();
		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecVigenciaLGA, SunatDateUtils.COMPARA_SOLO_FECHA)){
			if (declaracion.getDua().getCodmodalidad().equals( ConstantesDataCatalogo.MODA_EXCEPCIONAL) ) {
				
				/** inicio PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:**/
				Manifiesto manifiesto = null;
				boolean considerarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
				
				if(!ResponseListManager.responseListHasErrors(listaOMA)){
					manifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
							declaracion.getDua().getManifiesto().getCodmodtransp(), 
							declaracion.getDua().getManifiesto().getCodaduamanif(), 
							Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
							declaracion.getDua().getManifiesto().getNummanif(),true, declaracion.getDua().getFecNumeracion(),considerarEER);					
				}else{
					manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
						declaracion.getDua().getManifiesto().getCodmodtransp(), 
						declaracion.getDua().getManifiesto().getCodaduamanif(), 
						Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
						declaracion.getDua().getManifiesto().getNummanif(),true);
				}
				/***fin PAS20181U220200049***/
				
				//Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
				//		declaracion.getDua().getManifiesto().getCodmodtransp(), 
				//		declaracion.getDua().getManifiesto().getCodaduamanif(), 
				//		Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
				//		declaracion.getDua().getManifiesto().getNummanif(),true);

				if(manifiesto != null ){
					if(!CollectionUtils.isEmpty(declaracion.getDua().getListDocTransporte())){
						boolean graboIndicador = false;
						for(DatoDocTransporte docTrans:declaracion.getDua().getListDocTransporte()){
							Map<String,Object> datos=new HashMap<String,Object>();
							datos.put("indDel", Constantes.IND_REGISTRO_ACTIVO);
							datos.put("codEstSol", Constantes.CODIGO_ESTADO_SOLICITUD_PROSUS);
							if(  SunatNumberUtils.isGreaterThanZero(manifiesto.getNumeroCorrelativo()) )
							{
								datos.put("numCorrManif", manifiesto.getNumeroCorrelativo());
								datos.put("numDetalleSDA", docTrans.getNumdetalle()  );
							} else  {
								datos.put("numDetalleSIGAD", docTrans.getNumdetalle()  );
								datos.put("numManif", manifiesto.getNumeroManifiesto().trim());
								datos.put("annManif", manifiesto.getAnioManifiesto() );
								datos.put("codViaManif", manifiesto.getViaTransporte().getCodDatacat() );
								datos.put("codAduanaManif", manifiesto.getAduana().getCodDatacat() );
							}
							datos.put("numDocTransporte", docTrans.getNumdoctransporte()  );
							String numDetalle = "";
							Map<String,Object> datosManif=new HashMap<String,Object>();
							if (  SunatNumberUtils.isGreaterThanZero( docTrans.getNumdetalle())  ) {
								numDetalle = docTrans.getNumdetalle().toString();
								if(  SunatNumberUtils.isGreaterThanZero(manifiesto.getNumeroCorrelativo()) )
								{
									datosManif.put("numDetalleSDA",numDetalle );	
								} else  {
									datosManif.put("numDetalleSIGAD", numDetalle  );
								}
							} 

							List<String> listTipSol = new ArrayList<String>();
							listTipSol.add("30");//30, 31 o ambas
							listTipSol.add("31");//30, 31 o ambas 
							datos.put("codTipSol", listTipSol);
							Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
							String codTipSol = "";
							List<Map<String, Object>> lisProrroga = prorrogaService.getLstMapProSusManif(datos);
							if(!CollectionUtils.isEmpty(lisProrroga)){
								for(Map<String, Object> mapaProrroga:lisProrroga){
									if(!CollectionUtils.isEmpty(mapaProrroga)){
										numDetalle = mapaProrroga.get("numDetalle").toString();
										codTipSol = mapaProrroga.get("codTipSol").toString();

										SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
										if ( codTipSol.trim().equals("31") ) {
											Date fIni = originalFormat.parse(mapaProrroga.get("inicioSuspension").toString());
											Date fFin = originalFormat.parse(mapaProrroga.get("finSuspension").toString());
											if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fIni, SunatDateUtils.COMPARA_SOLO_FECHA) &&
													SunatDateUtils.esFecha1MayorIgualQueFecha2(fFin ,new Date(),  SunatDateUtils.COMPARA_SOLO_FECHA)	){
												mapIndicadoresDUA = new HashMap<String, Object>();
												mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
												mapIndicadoresDUA.put("codIndicador", "30");
												mapIndicadoresDUA.put("codTiporegistro", "A");
												indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
												graboIndicador = true;
												break;

											}
										}
										if ( codTipSol.trim().equals("30") ) {
											if ( !SunatStringUtils.isEmptyTrim( numDetalle )  ) {

												if(  SunatNumberUtils.isGreaterThanZero(manifiesto.getNumeroCorrelativo()) )
												{
													datosManif.put("numDetalleSDA",numDetalle );	
												} else  {
													datosManif.put("numDetalleSIGAD", numDetalle  );
												}
												datosManif.put("numeroManifiesto", manifiesto.getNumeroManifiesto().trim());
												datosManif.put("anioManifiesto", manifiesto.getAnioManifiesto() );
												datosManif.put("codViaManifiesto", manifiesto.getViaTransporte().getCodDatacat() );
												datosManif.put("aduanaManifiesto", manifiesto.getAduana().getCodDatacat() );
												datosManif.put("tipoInterfaz", "1");
												Map<String, Object> temp = prorrogaService.fechaMenorAFechaAbandoLegal(new Date(),datosManif,new HashMap<String,Object>());
												if((Boolean)temp.get("band")){
													mapIndicadoresDUA = new HashMap<String, Object>();
													mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
													mapIndicadoresDUA.put("codIndicador", "30");
													mapIndicadoresDUA.put("codTiporegistro", "A");
													indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
													graboIndicador = true;
													break;
												}
											}

										}


									}
								}
								//Ya grabo el indicador 30
								if (graboIndicador ) {
									break;
								}
							} else {
								break;
							}

						}
					}

				}
			}
		}
        
		//dua can , agregar resolucion a documentos de soporte
		if (!CollectionUtils.isEmpty(declaracion.getListDAVs())) {
			Elementos<DatoOtroDocSoporte> lstResolucionB = new Elementos<DatoOtroDocSoporte>();
			int numSecDocum = 1;
			for (DAV dav : declaracion.getListDAVs()) {
				if (!CollectionUtils.isEmpty(dav.getListDocumentoSoporteFormatoB())) {				
					for(DocumentoSoporteFormatoB docSoporteB : dav.getListDocumentoSoporteFormatoB()) {
						if(docSoporteB.getTipoDocumento().equals("998") && !SunatStringUtils.isEmpty(docSoporteB.getCodResolucion())) {
							DatoOtroDocSoporte docSoporte = new DatoOtroDocSoporte();
							docSoporte.setNumsecdocum(numSecDocum);
							docSoporte.setNumcorredoc(declaracion.getDua().getNumcorredoc());
							docSoporte.setCodtipoproceso("B");
							docSoporte.setCodtipodocasoc(docSoporteB.getCodResolucion());
							docSoporte.setDesentidad(docSoporteB.getDesResolucion());
							docSoporte.setNumdocasoc(docSoporteB.getNumResolucion());
							docSoporte.setFecdocasoc(docSoporteB.getFechaResolucion());
							docSoporte.setNumeroItemDocumento(dav.getNumsecuprov());
							numSecDocum++;
							lstResolucionB.add(docSoporte);							
							break;
						}
					}
				}
			}
			if (!CollectionUtils.isEmpty(lstResolucionB)) {
				if (declaracion.getDua().getListOtrosDocSoporte() != null){
					declaracion.getDua().getListOtrosDocSoporte().addAll(lstResolucionB);
				} else {
					declaracion.getDua().setListOtrosDocSoporte(lstResolucionB);
				}				
			}
		}
		

		// INICIO PAS20155E220000054
		// Bug 21163 grabado de Documentos de Soporte Nivel DUA.
		// 
		//RIN 10 - BUG 21495 - inicio - verifica que no duplique por secuencia y tipo
		List<String> listNumDocSoporteValidacion = new ArrayList<String>();            
		DocAutAsociadoDAO docAutAsociadoDAO =  (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
		boolean documentodeSoporteSerie= existeDocSoportNivelSerie(declaracion);
		if (!documentodeSoporteSerie) {
			if (declaracion.getDua().getListOtrosDocSoporte()!=null){
				for(DatoOtroDocSoporte docSop:declaracion.getDua().getListOtrosDocSoporte()){
					Map<String,Object> mapDocAutAsociado=new HashMap<String,Object>();                                  
					fillDocAutAsociado(mapDocAutAsociado,docSop,declaracion.getCodaduana(),numCorreDoc);
					if (declaracion.getDua().getListOtrosDocSoporte()!=null)
					{                               
						docAutAsociadoDAO.insertMapSelective(mapDocAutAsociado);
						//RIN 10 - BUG 21495 - inicio
						String cadenaNumDocSoporte = mapDocAutAsociado.get("numSecdoc").toString().concat(mapDocAutAsociado.get("codTipoper").toString());
						listNumDocSoporteValidacion.add(cadenaNumDocSoporte);
						//RIN 10 - BUG 21495 - fin
					}
				}
			}
		}
		// FIN PAS20155E220000054

		ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService"); 
		Map<String,Object> mapaIndicadorTPN21 = valMercanciaVigenteService.obtenerIndicadorMercanciaVigente(declaracion.getDua().getListIndicadores());  

		boolean esTPN21 = false; //PAS20155E220200012 - mtorralba 20150618
		boolean tieneIndicadorMV = !mapaIndicadorTPN21.isEmpty(); //PAS20171U220200005 - mtorralba 20171015
		Integer valorIndicadorTPN21 = 0;

		for(DatoSerie serie:declaracion.getDua().getListSeries()){
			//insert det_declara
			Map<String,Object> mapDetDeclara=new HashMap<String,Object>();
			fillDetDeclara(mapDetDeclara,declaracion.getDua(),serie,numCorreDoc);
			//				detDeclaraDAO.insertMapSelective(mapDetDeclara);
			declaracionBatchService.registraDetDeclara(mapDetDeclara);

			//insert convenio_serie
			Map<String,Object> mapConvenioSerie=new HashMap<String,Object>();
			if (serie.getCodconvinter()!=null && serie.getCodconvinter()!=0){
				if (fillConvenioSerie(mapConvenioSerie,serie,numCorreDoc,"I"))
					//						convenioSerieDAO.insertMapSelective(mapConvenioSerie); 
					declaracionBatchService.registraConvenioSeries(mapConvenioSerie);
			}
			mapConvenioSerie=new HashMap<String,Object>();
			if (serie.getCodliberatorio()!=null && serie.getCodliberatorio()!=0){
				if (fillConvenioSerie(mapConvenioSerie,serie,numCorreDoc,"C"))
					//						convenioSerieDAO.insertMapSelective(mapConvenioSerie);
					declaracionBatchService.registraConvenioSeries(mapConvenioSerie);
			}
			mapConvenioSerie=new HashMap<String,Object>();
			if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()!=0){
				esTPN21 = serie.getCodtratprefe()==21;
				if (fillConvenioSerie(mapConvenioSerie,serie,numCorreDoc,"T"))
					//						convenioSerieDAO.insertMapSelective(mapConvenioSerie);
					declaracionBatchService.registraConvenioSeries(mapConvenioSerie);
			}


			//insert det_adi_impoconsu
			Map<String,Object> mapDetAdiImpoconsu=new HashMap<String,Object>();
			fillDetAdiImpoconsu(mapDetAdiImpoconsu,serie,numCorreDoc);
			if (sizeMap(mapDetAdiImpoconsu)>2)
				//					detAdiImpoconsuDAO.insertMapSelective(mapDetAdiImpoconsu);
				declaracionBatchService.registrarDetAdiImpoconsu(mapDetAdiImpoconsu);

			//insert det_adi_atpa
			if ("21".equals(declaracion.getDua().getCodregimen()) || ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(declaracion.getDua().getCodregimen())){
				Map<String,Object> mapDetAdiAtpa=new HashMap<String,Object>();
				fillDetAdiAtpa(mapDetAdiAtpa,serie,numCorreDoc,declaracion.getDua().getCodregimen());
				//					detAdiAtpaDAO.insertMapSelective(mapDetAdiAtpa);
				declaracionBatchService.registrarDetAdiAtpa(mapDetAdiAtpa);
			}
			//insert det_adi_atreex
			Map<String,Object> mapDetAdiAtreex=new HashMap<String,Object>();
			if (fillDetAdiAtreex(mapDetAdiAtreex,serie,numCorreDoc))
				//					detAdiAtreexDAO.insertMapSelective(mapDetAdiAtreex);
				declaracionBatchService.registrarDetAdiAtreex(mapDetAdiAtreex);

			//insert docuprece_dua
			for(DatoRegPrecedencia prec:serie.getListRegPrecedencia()){
				Map<String,Object> mapDocuPreceDua=new HashMap<String,Object>();
				fillDocuPreceDua(mapDocuPreceDua,serie,prec,numCorreDoc);
				//					docuPreceDuaDAO.insertMapSelective(mapDocuPreceDua);
				declaracionBatchService.registrarDocuprecDua(mapDocuPreceDua);

				//PAS20155E220200012 - mtorralba 20150618 - Inicio
				if( esTPN21 ) {
					//Si es TPN21 debe actualizar la cuenta corriente de la declaraci�n
					if( !tieneIndicadorMV )
						fillCabCtacteRegimen(serie, prec, numCorreDoc);
					else if( SunatNumberUtils.isEqual(valorIndicadorTPN21, 0) ) {
						String anoPrece = prec.getAnndeclpre().substring(0,4);
						String numPrece = SunatStringUtils.lpad(prec.getNumdeclpre().trim(),6,'0');
						valorIndicadorTPN21 = valMercanciaVigenteService.obtenerSecuenciaEnvio(prec.getCodaduapre(), anoPrece, prec.getCodregipre(), numPrece);
						mapaIndicadorTPN21.put("desIndicador", valorIndicadorTPN21.toString());
					}
				}
				//PAS20155E220200012 - mtorralba 20150618 - Fin
			}

			//insert vehi_cetico
			for(DatoVehiculo vehic:serie.getListVehiculos()){
				Map<String,Object> mapVehiCetico=new HashMap<String,Object>();
				fillVehiCetico(mapVehiCetico,vehic,serie.getNumserie(),numCorreDoc);
				//					vehiCeticoDAO.insertMapSelective(mapVehiCetico);
				declaracionBatchService.registrarVehiCetico(mapVehiCetico);
				for(DatoMontoGasto mtoGastos:vehic.getListMontoGastos()){
					Map<String,Object> mapVehConceptoGasto=new HashMap<String,Object>();
					fillMontoGasto(mapVehConceptoGasto,mtoGastos,serie.getNumserie(),numCorreDoc);
					//						montoGastoDAO.insertMapSelective(mapVehConceptoGasto);
					declaracionBatchService.registrarMontoGasto(mapVehConceptoGasto);
				}
			}

		}
		//insert cab_adj_impoconsu
		Map<String,Object> mapAdjImpoconsu=new HashMap<String,Object>();
		fillCabAdjImpoconsu(mapAdjImpoconsu,declaracion,numCorreDoc, mapaIndicadorTPN21, esTPN21);
		if (sizeMap(mapAdjImpoconsu)>1){
			CabAdjImpoconsuDAO cabAdjImpoconsuDAO = (CabAdjImpoconsuDAO) fabricaDeServicios.getService("cabAdjImpoconsuDAO");
			cabAdjImpoconsuDAO.insertMapSelective(mapAdjImpoconsu);
		}
		//insert datoseriedocsoporte
		List<String> listNumDocSoporte=new ArrayList<String>();
		List<String> listNumDocAutorizante=new ArrayList<String>();
		List<String> listNumFactura=new ArrayList<String>();
		List<String> listNumCertiOrigen=new ArrayList<String>();	
		List<String> listNumDetAutorizacion=new ArrayList<String>();
		//P46
		List<String> listNumDetAutorizacionSoporte=new ArrayList<String>();
		Integer secDocAutoriz=1;
		Integer secFactura=1;
		boolean usarCodigoNuevo = false;
		Date fecVigencia = SunatDateUtils.getDate(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
				.getElementoCat("517", "FEC_INIVIG")
				.get("des_datacat").toString());

		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			usarCodigoNuevo = true;
		}
		for(DatoSerie serie:declaracion.getDua().getListSeries()){
			for(DatoSerieDocSoporte serieDoc:serie.getListSerieDocSoporte()){
				String numdoc;
				if(DOC_SOPORTE.equals(serieDoc.getCodtipodocsoporte())){
					List<DatoOtroDocSoporte> listDocSoporte=getDocSoporte(declaracion.getDua(),serie);
					for(DatoOtroDocSoporte docSoporte:listDocSoporte){
						numdoc=docSoporte.getNumsecdocum().toString();
						secDocAutoriz=docSoporte.getNumsecdocum();
						if(!SunatStringUtils.isEmptyTrim(numdoc) && !include(listNumDocSoporte,numdoc) && documentodeSoporteSerie){
							listNumDocSoporte.add(numdoc);
							//								secDocAutoriz=docSoporte.getNumsecdocum();//gmontoya Pase 436 - 2015
							//								insertDocSoporte(docAutAsociadoDAO, detAutorizacionDAO, numCorreDoc,docSoporte,serie,secDocAutoriz, declaracion.getCodaduana());
							//RIN 10 - BUG 21495 - inicio - verifica que no duplique por secuencia y tipo
							String cadenaNumDocSoporte = docSoporte.getNumsecdocum().toString().concat(docSoporte.getCodtipoproceso());
							if(!include(listNumDocSoporteValidacion, cadenaNumDocSoporte)){
								//RIN 10 - BUG 21495 - fin
								insertDocSoporte(declaracionBatchService, numCorreDoc,docSoporte,serie,secDocAutoriz, declaracion.getCodaduana());
								//RIN 10 - BUG 21495 - inicio
								listNumDocSoporteValidacion.add(cadenaNumDocSoporte);	
							}
							//RIN 10 - BUG 21495 - fin
						}
						//INICIO EJHM P46
						String numrelacion = SunatStringUtils.lpad(serie.getNumserie().toString(), 4, '0').concat(SunatStringUtils.lpad(numdoc, 4, '0'));
						if( !include(listNumDetAutorizacionSoporte,numrelacion)){
							listNumDetAutorizacionSoporte.add(numrelacion);
							insertDocDetAutorizanteSoporte( declaracionBatchService,  numCorreDoc, docSoporte, serie, secDocAutoriz);
						}
						//FIN EJHM P46
					}
				}else if(FACTURA.equals(serieDoc.getCodtipodocsoporte())){
					//SAU20123P000000026-NSR-El bucle externo ya recorre los documentos de soporte
					//entonces se espera que solo devuelva una factura a la vez y no una lista, se corrige
					//List<DatoFacturaref> listFactura=getFacturaRef(declaracion.getDua(),serie);
					DatoFacturaref facturaRef =	getFacturaRefPorDocSoporte(declaracion.getDua(), serieDoc);
					//for(DatoFacturaref facturaRef:listFactura){
					if(facturaRef != null) //Aqui si o si debe devolver una factura
					{
						numdoc=facturaRef.getNumsecfactu().toString();
						if(!SunatStringUtils.isEmptyTrim(numdoc)){
							secFactura=facturaRef.getNumsecfactu();
							if(!include(listNumFactura,numdoc)){
								listNumFactura.add(numdoc);
								//										insertFacturaref(formaFactuDAO, facturaSerieDAO, numCorreDoc,facturaRef,serie,secFactura);
								insertFacturaref(declaracionBatchService, numCorreDoc,facturaRef,serie,secFactura);
							}else{
								//										insertFacturaSerie(facturaSerieDAO, numCorreDoc, serie, secFactura);
								insertFacturaSerie(declaracionBatchService, numCorreDoc, serie, secFactura);
							}
						}
					}
					//}
				}else if(DOC_AUTORIZANTE.equals(serieDoc.getCodtipodocsoporte())){
					List<DatoDocAutorizante> listDocAutorizante=getDocAutorizante(declaracion.getDua(),serie);
					for(DatoDocAutorizante docAutorizante:listDocAutorizante){
						numdoc=docAutorizante.getNumsecdocum().toString();
						if( !include(listNumDocAutorizante,numdoc)){
							listNumDocAutorizante.add(numdoc);
							secDocAutoriz=docAutorizante.getNumsecdocum();
							if(listaVUCE!=null){
								docAutorizante = actualizaDocAutorizante(docAutorizante, listaVUCE); //PAS20165E220200025 - VUCE 
							}

							//								insertDocAutorizante(docAutAsociadoDAO, detAutorizacionDAO, numCorreDoc,docAutorizante,serie,secDocAutoriz, declaracion.getCodaduana());
							//RIN 10 - BUG 21495 - inicio - verifica que no duplique en DOCAUT_ASOCIADO por secuencia y tipo P
							String cadenaNumDocSoporte = docAutorizante.getNumsecdocum().toString().concat("P");
							if(!include(listNumDocSoporteValidacion, cadenaNumDocSoporte)){
								//RIN 10 - BUG 21495 - fin
								insertDocAutorizante(declaracionBatchService, numCorreDoc,docAutorizante,serie,secDocAutoriz, declaracion.getCodaduana(),usarCodigoNuevo,mRestriEntidadService);
								//RIN 10 - BUG 21495 - inicio
								listNumDocSoporteValidacion.add(cadenaNumDocSoporte);	
							}
							//RIN 10 - BUG 21495 - fin								
						}
						String numrelacion = SunatStringUtils.lpad(serie.getNumserie().toString(), 4, '0').concat(SunatStringUtils.lpad(numdoc, 4, '0'));
						if( !include(listNumDetAutorizacion,numrelacion)){
							listNumDetAutorizacion.add(numrelacion);
							//	insertDocDetAutorizante(detAutorizacionDAO, numCorreDoc,serie,SunatNumberUtils.toInteger(numdoc));
							insertDocDetAutorizante(declaracionBatchService, numCorreDoc,serie,SunatNumberUtils.toInteger(numdoc));
						}
					}
				}else if(CERTI_ORIGEN.equals(serieDoc.getCodtipodocsoporte())){
					List<DatoAutocertificacion> listCertiOrigen=getCertiOrigen(declaracion.getDua(),serie);
					List<String> listNumDetCertificado=new ArrayList<String>();	
					for(DatoAutocertificacion docCertiOrig:listCertiOrigen){
						numdoc=docCertiOrig.getNumsecCO().toString();							
						if( !include(listNumCertiOrigen,numdoc)){
							listNumCertiOrigen.add(numdoc);
							secDocAutoriz=docCertiOrig.getNumsecCO();
							//			                    insertCertiOrigen(cabCertiOrigenDAO, numCorreDoc,docCertiOrig,serie,secDocAutoriz,declaracion);
							//RIN 10 - BUG 21495 - inicio - verifica que no duplique en DOCAUT_ASOCIADO por secuencia y tipo C
							String cadenaNumDocSoporte = docCertiOrig.getNumsecCO().toString().concat("C");
							if(!include(listNumDocSoporteValidacion, cadenaNumDocSoporte)){
								//RIN 10 - BUG 21495 - fin
								insertCertiOrigen(declaracionBatchService, numCorreDoc,docCertiOrig,serie,secDocAutoriz,declaracion,codTransaccion); //Se adiciono codTransaccion - PAS20181U220200056
								//RIN 10 - BUG 21495 - inicio
								listNumDocSoporteValidacion.add(cadenaNumDocSoporte);	
							}
							//RIN 10 - BUG 21495 - fin								
						}
						if( !include(listNumDetCertificado,numdoc)){
							listNumDetCertificado.add(numdoc);
							//								insertDetAutorizacion(detAutorizacionDAO, numCorreDoc,docCertiOrig,serie);
							insertDetAutorizacion(declaracionBatchService, numCorreDoc,docCertiOrig,serie);
						}
					}
				}
				//INICIO EJHM P46 inserta todos los doc. sop que no hayn sido insertados
				else {
					for(DatoOtroDocSoporte docSoporte:declaracion.getDua().getListOtrosDocSoporte()){

						numdoc=docSoporte.getNumsecdocum().toString();
						if(!SunatStringUtils.isEmptyTrim(numdoc) && !include(listNumDocSoporte,numdoc)){
							listNumDocSoporte.add(numdoc);
							secDocAutoriz=docSoporte.getNumsecdocum();
							//Inicio PAS20145E220000365 - mtorralba - 20150327 - Atencion BUG 21231
							String cadenaNumDocSoporte = docSoporte.getNumsecdocum().toString().concat(docSoporte.getCodtipoproceso());
							if(!include(listNumDocSoporteValidacion, cadenaNumDocSoporte)){
								insertDocSoporte(declaracionBatchService, numCorreDoc,docSoporte,serie,secDocAutoriz, declaracion.getCodaduana());
								listNumDocSoporteValidacion.add(cadenaNumDocSoporte);	
							}
							//Fin PAS20145E220000365 - mtorralba - 20150327 - Atencion BUG 21231
						}
					}	
				}
				//FIN EJHM P46

			}
		}

		declaracionBatchService.procesarRegistrarDeclaraciones();
		mRestriEntidadService.procesarBatchAutorizante();

		return mapRpta;
	}

	public void grabarParticipanteSEIDA(String codUsuario, String tipoSender, Long numCorreDoc){
		// Se crea participante de Usuario SEIDA (Representante Legal o Despachador Oficial)
		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
		SequenceDAO sequenceDAO = (SequenceDAO) fabricaDeServicios.getService("Framework.sequenceDef");
		ParticipanteDocDAO participanteDAO = (ParticipanteDocDAO) fabricaDeServicios.getService("participanteDAO");
		Map<String, Object> personalOCE = funcionesService.obtenerPersonalOCE(codUsuario, tipoSender);
		
		Participante usuarioSEIDA = new Participante();
		Long numSecParticipante = sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
		usuarioSEIDA.getDocumento().setNumeroCorrelativo(numCorreDoc);
		usuarioSEIDA.setSecuenciaDeParticipantes(numSecParticipante);		
		String nombreRazonSocial = SunatStringUtils.trimNotNull(
				SunatStringUtils.trimNotNull(SunatStringUtils.toStringObj(personalOCE.get("des_apepat")))+" "+ 
						SunatStringUtils.trimNotNull(SunatStringUtils.toStringObj(personalOCE.get("des_apemat")))+" "+
						SunatStringUtils.trimNotNull(SunatStringUtils.toStringObj(personalOCE.get("des_nombres"))));
		usuarioSEIDA.getTipoParticipante().setCodDatacat(ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_OCE);
		usuarioSEIDA.getTipoDocumentoIdentidad().setCodDatacat(SunatStringUtils.toStringObj(personalOCE.get("cod_tipodocid")));
		usuarioSEIDA.setNumeroDocumentoIdentidad(SunatStringUtils.toStringObj(personalOCE.get("num_docid")));
		usuarioSEIDA.setNombreRazonSocial(nombreRazonSocial);
		usuarioSEIDA.setDireccion(SunatStringUtils.toStringObj(personalOCE.get("des_direccion")));
		participanteDAO.insertSelective(usuarioSEIDA);	
	}

	private void insertDocSoporte(DeclaracionBatchService declaracionBatchService, Long numCorreDoc,DatoOtroDocSoporte docSoporte,DatoSerie serie,Integer secDocAutoriz, String aduana){
		Map<String,Object> mapDocAutAsociado=new HashMap<String,Object>();
		mapDocAutAsociado.put("numCorredoc", numCorreDoc);
		mapDocAutAsociado.put("numSecdoc", docSoporte.getNumsecdocum());
		mapDocAutAsociado.put("codTipoper", docSoporte.getCodtipoproceso());
		mapDocAutAsociado.put("codTipdocaso", docSoporte.getCodtipodocasoc());
		if (SunatStringUtils.length(docSoporte.getAnndocasoc())>4)
			mapDocAutAsociado.put("annDoc", docSoporte.getAnndocasoc().substring(0,4));
		mapDocAutAsociado.put("numDoc", docSoporte.getNumdocasoc());
		mapDocAutAsociado.put("fecEmis", docSoporte.getFecdocasoc());
		mapDocAutAsociado.put("fecVenc", docSoporte.getFecvencimiento());
		mapDocAutAsociado.put("codEnti", docSoporte.getCodtipoentidad());
		mapDocAutAsociado.put("codTipdoc", docSoporte.getCodtipodocentidad());
		mapDocAutAsociado.put("codIdent", docSoporte.getCodentidademisora());
		mapDocAutAsociado.put("obsObs", docSoporte.getDesentidad());
		mapDocAutAsociado.put("codAduAut", docSoporte.getCodigoAduanaAutoriza());
		declaracionBatchService.registrarDocAutAsociado(mapDocAutAsociado);
	}


	private void insertDocDetAutorizanteSoporte(DeclaracionBatchService declaracionBatchService, Long numCorreDoc,DatoOtroDocSoporte docSoporte,DatoSerie serie,Integer secDocAutoriz){
		Map<String,Object> mapDetAutorizacion=new HashMap<String,Object>();
		mapDetAutorizacion.put("numCorredoc", numCorreDoc);
		mapDetAutorizacion.put("numSecserie", serie.getNumserie());
		mapDetAutorizacion.put("numSecdoc", secDocAutoriz);
		mapDetAutorizacion.put("codTipoper", docSoporte.getCodtipoproceso());
		declaracionBatchService.registrarDetAutorizacion(mapDetAutorizacion);
	}



	private void insertCertiOrigen(DeclaracionBatchService declaracionBatchService, Long numCorreDoc, DatoAutocertificacion docCertiOrig,DatoSerie serie,Integer secDocAutoriz,Declaracion declaracion, String codTransaccion){//Se adiciono codTransaccion - PAS20181U220200056
		Map<String,Object> mapDocAutAsociado=new HashMap<String,Object>();
		mapDocAutAsociado.put("numCorredoc", numCorreDoc);
		mapDocAutAsociado.put("numSecdoc", docCertiOrig.getNumsecCO());
		mapDocAutAsociado.put("codTipdocaso", docCertiOrig.getCodtipoCO());
		Integer annDoc=SunatDateUtils.getAnho(docCertiOrig.getFecemision());
		if (annDoc.intValue()!=0)
			mapDocAutAsociado.put("annDoc", annDoc);
		mapDocAutAsociado.put("numDoc", docCertiOrig.getNumdocumento());
		mapDocAutAsociado.put("fecEmis", docCertiOrig.getFecemision());
		Date fecVencimiento=SunatDateUtils.getDate("31/12/9999", "dd/MM/yyyy");
		mapDocAutAsociado.put("fecVenc", fecVencimiento);
		mapDocAutAsociado.put("codTipoper", "C");
		//		docAutAsociadoDAO.insertMapSelective(mapDocAutAsociado);
		declaracionBatchService.registrarDocAutAsociado(mapDocAutAsociado);

		Map<String,Object> mapCabCertiOrigen=new HashMap<String,Object>();
		mapCabCertiOrigen.put("numCorredoc", numCorreDoc);
		mapCabCertiOrigen.put("numSecdoc", docCertiOrig.getNumsecCO());
		mapCabCertiOrigen.put("codTipcertificado", docCertiOrig.getCodtipoCO());
		mapCabCertiOrigen.put("codEmiscert", docCertiOrig.getCodtipoemisorCO());
		mapCabCertiOrigen.put("nomEmiscertif", docCertiOrig.getNomemisorCO());
		mapCabCertiOrigen.put("numCertorigen",docCertiOrig.getNumdocumento() );
		mapCabCertiOrigen.put("fecCertificado", docCertiOrig.getFecemision());
		mapCabCertiOrigen.put("fecIniperiodoemb", docCertiOrig.getFeciniembarque());
		mapCabCertiOrigen.put("fecFinperemb", docCertiOrig.getFecfinembarque());
		//mapCabCertiOrigen.put("nomProdmerc", docCertiOrig.getDesmercancia());
		mapCabCertiOrigen.put("nomproduc", docCertiOrig.getNomproduc());
		mapCabCertiOrigen.put("codCriterioorigen", docCertiOrig.getCodcriterioO());
		mapCabCertiOrigen.put("indProcetercerpais", docCertiOrig.getIndtrans());
		mapCabCertiOrigen.put("codFfco", docCertiOrig.getCodffco());
		mapCabCertiOrigen.put("codTipOper", "C");
		mapCabCertiOrigen.put("indTipoElectronico", docCertiOrig.getIndElectronico());//PAS20181U220200056

		mapCabCertiOrigen.put("numautoexp", docCertiOrig.getNumautoexp());
		mapCabCertiOrigen.put("codmoneda", docCertiOrig.getCodmoneda());
		mapCabCertiOrigen.put("mtofobmon", docCertiOrig.getMtofobmon());
		DatoDocTransporte documentoTransporte = getDocTransporte(declaracion.getDua(), serie);
		mapCabCertiOrigen.put("codpuertoorg", documentoTransporte.getCodpuertoorg());
		mapCabCertiOrigen.put("fecEmborigen", documentoTransporte.getFecembarqueorg());

		if (declaracion.getListDAVs()!=null && declaracion.getListDAVs().size()>0){	
			for( DAV dav: declaracion.getListDAVs()){
				if(dav.getProveedor()!=null)
					mapCabCertiOrigen.put("nomProve", dav.getProveedor().getNombreRazonSocial());
			}
		}

		//		cabCertiOrigenDAO.insertMapSelective(mapCabCertiOrigen);
		declaracionBatchService.registrarCabCertiOrigen(mapCabCertiOrigen);
		registroUsoCertificadoOrigenElectronico(docCertiOrig, declaracion, codTransaccion);//PAS20181U220200056
	}

	//PAS20181U220200056
	private void registroUsoCertificadoOrigenElectronico(DatoAutocertificacion docCertiOrig, Declaracion declaracion, String codTransaccion) {
		Boolean esValidoVUCECO = ((CertiOrigenElectronicoService)fabricaDeServicios.getService("certiOrigenElectronicoService"))
	    		  .esValidoCambiosDiligVUCECO(SunatDateUtils.getCurrentDate());
		if(esValidoVUCECO) { //Correccion al pase 56
			
		final String URL_VUCE_CERT_ELECT = "http://api.sunat.peru/v1/estrategico/vuce/e/certificadoorigenelectronico";
		//final String URL_VUCE_CERT_ELECT = "http://localhost:7001/ol-ad-aduanerovucews/certificadoorigenelectronico";

		if(INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(docCertiOrig.getIndElectronico())) {
			try{
				DocCertificadoOrigen docCertificadoOrigen = new DocCertificadoOrigen();
				docCertificadoOrigen.setNumeroCertificadoOrigen(docCertiOrig.getNumdocumento());
				docCertificadoOrigen.setNumeroCorrelativoDAMUso(declaracion.getNumeroCorrelativo());
				docCertificadoOrigen.setCodTransaccionUso(codTransaccion);
				docCertificadoOrigen.setNumeroDAMUso(declaracion.getNumeroDeclaracion().toString());				
				RestTemplate restTemplate = new RestTemplate();
				String responseUpdate = restTemplate.postForObject(URL_VUCE_CERT_ELECT, docCertificadoOrigen, String.class);		
                log.info("registroUsoCertificadoOrigenElectronicio " + responseUpdate);
			}
			catch(Exception e){
				log.info("Error registroUsoCertificadoOrigenElectronicio : " + e.getMessage());
			}
		}
		}
	}

	private void insertDetAutorizacion(DeclaracionBatchService declaracionBatchService, Long numCorreDoc, DatoAutocertificacion docCertiOrig, DatoSerie serie){
		Map<String,Object> mapDetAutorizacion=new HashMap<String,Object>();
		mapDetAutorizacion.put("numCorredoc", numCorreDoc);
		mapDetAutorizacion.put("numSecserie", serie.getNumserie());
		mapDetAutorizacion.put("codTipoper", "C");		
		mapDetAutorizacion.put("numSecdoc", docCertiOrig.getNumsecCO());		
		//		detAutorizacionDAO.insertMapSelective(mapDetAutorizacion);
		declaracionBatchService.registrarDetAutorizacion(mapDetAutorizacion);
	}
	//inicio gmontoya bug 17526
	private void insertDocAutorizante(DeclaracionBatchService declaracionBatchService, Long numCorreDoc,DatoDocAutorizante docAutorizante,DatoSerie serie,Integer secDocAutoriz, String aduana, boolean usarCodigoNuevo,MercanciaRestringidaEntidadService mRestriEntidadService){
		Map<String,Object> mapDocAutAsociado=new HashMap<String,Object>();
		List<DatoRegPrecedencia> lstPreceDua = serie.getListRegPrecedencia();
		boolean noTieneRegPreDepAduanero = true; // PAS201830001100011
		
		if (!CollectionUtils.isEmpty(lstPreceDua)) {   
			for (DatoRegPrecedencia preceDua : lstPreceDua) {
				if (preceDua.getCodregipre().equals(Constants.REGIMEN_DEPOSITO)) {
					noTieneRegPreDepAduanero = false;
				}
			}
		}
		
		mapDocAutAsociado.put("numCorredoc", numCorreDoc);
		mapDocAutAsociado.put("numSecdoc", docAutorizante.getNumsecdocum());
		mapDocAutAsociado.put("codTipdocaso", docAutorizante.getCodtipodocum());
		if( SunatStringUtils.length(docAutorizante.getAnndocum())>3)
			mapDocAutAsociado.put("annDoc", docAutorizante.getAnndocum().substring(0,4));
		mapDocAutAsociado.put("numDoc", docAutorizante.getNumdocum());
		mapDocAutAsociado.put("fecEmis", docAutorizante.getFecemision());
		mapDocAutAsociado.put("fecVenc", docAutorizante.getFecvencimiento());
		mapDocAutAsociado.put("obsObs", docAutorizante.getDesentidad());
		mapDocAutAsociado.put("codEnti", docAutorizante.getCodentidad());
		mapDocAutAsociado.put("codTipoper", "P");
		mapDocAutAsociado.put("codAduAut", aduana);
		if(usarCodigoNuevo){
			mapDocAutAsociado.put("codSubEnti", docAutorizante.getCodsubentidad()!=null && !docAutorizante.getCodsubentidad().isEmpty()?docAutorizante.getCodsubentidad():" ");//es default
			mapDocAutAsociado.put("codSubTipo", docAutorizante.getCodsubtipodocum());
			mapDocAutAsociado.put("numItemDoc", docAutorizante.getNroitemdocum());
		}
		declaracionBatchService.registrarDocAutAsociado(mapDocAutAsociado);
		if(usarCodigoNuevo){
			if ( Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(docAutorizante.getCodentidad()) && 
					Constants.COD_TIPO_DOCAUT_IQBF.equals(docAutorizante.getCodtipodocum()) &&
					(Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(docAutorizante.getCodsubentidad()) ||
							Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA.equals(docAutorizante.getCodsubentidad()))// && lstPreceDua.isEmpty()) { //PAS20155E220000487 - se agrega IQBF Mineria
								&& noTieneRegPreDepAduanero) {//PAS201830001100011 - regimen 70 no actualiza el estado de la Autorizacion 
				Declaracion declara = (Declaracion) serie.getPadre().getPadre(); //PAS201830001100003 solo para DAMs que no tienen regimen precedente
				//PAS20155E220000487 - se modifico para que no consulte al cab_declara, se envia ya el num_declaracion en vez del num_corredoc
				mRestriEntidadService.actualizarDocAutorizanteIQBFBatch(Constants.IND_REGISTRO_DOCAUTORIZANTE, Constants.EST_DOCAUT_DESTINADA, docAutorizante, 
						declara.getDua().getCodaduanaorden(), declara, serie);
			}	
		}
	}

	private void insertDocDetAutorizante(DeclaracionBatchService declaracionBatchService, Long numCorreDoc,DatoSerie serie,Integer secDocAutoriz){
		Map<String,Object> mapDetAutorizacion=new HashMap<String,Object>();
		mapDetAutorizacion.put("numCorredoc", numCorreDoc);
		mapDetAutorizacion.put("numSecserie", serie.getNumserie());
		mapDetAutorizacion.put("numSecdoc", secDocAutoriz);
		mapDetAutorizacion.put("codTipoper", "P");
		declaracionBatchService.registrarDetAutorizacion(mapDetAutorizacion);
	}


	private void insertFacturaref(DeclaracionBatchService declaracionBatchService, Long numCorreDoc,DatoFacturaref facturaRef,DatoSerie serie,Integer secFactura){
		Map<String,Object> mapFormaFactu=new HashMap<String,Object>();
		mapFormaFactu.put("NUM_CORREDOC", numCorreDoc);
		mapFormaFactu.put("NUM_SECFACT", facturaRef.getNumsecfactu());
		mapFormaFactu.put("NUM_FACT", facturaRef.getNumfactura());
		mapFormaFactu.put("FEC_FACT", facturaRef.getFecfactura());
		mapFormaFactu.put("COD_MOMGRAB", "00");
		declaracionBatchService.registrarFormaFactu(mapFormaFactu);
		insertFacturaSerie(declaracionBatchService, numCorreDoc, serie, secFactura);
	}

	private void insertFacturaSerie(DeclaracionBatchService declaracionBatchService, Long numCorreDoc, DatoSerie serie,Integer secFactura){
		Map<String,Object> mapFacturaSerie=new HashMap<String,Object>();
		mapFacturaSerie.put("NUM_CORREDOC", numCorreDoc);
		mapFacturaSerie.put("NUM_SECFACT", secFactura);
		mapFacturaSerie.put("NUM_SECSERIE", serie.getNumserie());
		declaracionBatchService.registrarFacturaSerie(mapFacturaSerie);
	}

	// HSAENZ: 08/09/2014: Se agrega nuevo parametro para la fecha de vencimiento de conclusion
	//private void fillCabDeclara(Map<String,Object> mapCabDeclara,Declaracion declaracion,Long numCorreDoc, Long numDeclaracion, Date fechaConclusionDespa, String numOrden, String codTransaccion){
	private void fillCabDeclara(Map<String,Object> mapCabDeclara,Declaracion declaracion,
			Long numCorreDoc, Long numDeclaracion, Date fechaConclusionDespa, String numOrden, 
			String codTransaccion, Date fechaVencimientoConclusion){
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		// fin HSAENZ: 08/09/2014:
		DUA dua=declaracion.getDua();
		mapCabDeclara.put("numcorredoc", numCorreDoc);
		mapCabDeclara.put("codTipgrabado", "T");
		mapCabDeclara.put("codRegimen", dua.getCodregimen());
		mapCabDeclara.put("codAduana", dua.getCodaduanaorden());
		mapCabDeclara.put("codModalidad", dua.getCodmodalidad());
		mapCabDeclara.put("codTipdesp", dua.getCodtipoperacion());
		mapCabDeclara.put("codTiplugarrecep", dua.getCodlugarecepcion());
		mapCabDeclara.put("codLugarrecep", dua.getCodtiplugarrecep());
		mapCabDeclara.put("codRuclugrecep", dua.getNumruclugarecep());//TODO numrucdeposito
		mapCabDeclara.put("codLocalanexo", dua.getCodanexo());
		mapCabDeclara.put("mtoTotfobdol", dua.getMtotfobclvta());
		mapCabDeclara.put("mtoTotfletedol", dua.getMtotflecomex());
		mapCabDeclara.put("mtoTotsegdol", dua.getMtotsegotros());
		mapCabDeclara.put("mtoTotajustesdol", dua.getMtotajustes());		
		mapCabDeclara.put("mtoTotvaloradu", dua.getMtovaladuana());
		mapCabDeclara.put("cntPesobrutoTotal", dua.getCnttpesobruto());
		mapCabDeclara.put("cntPesonetoTotal", dua.getCnttpesoneto());
		mapCabDeclara.put("cntTotbultos", dua.getCnttcantbulto());
		mapCabDeclara.put("cntTqunifis", dua.getCnttqunifis());
		mapCabDeclara.put("cntTotseries", dua.getCntnumseries());
		mapCabDeclara.put("cntTqunicom", dua.getCnttqunicom());
		mapCabDeclara.put("mtoTotautoliq", dua.getMtototautoliq());		
		mapCabDeclara.put("codPropiedad", dua.getCodpropiedad());
		mapCabDeclara.put("codTipoplazo", dua.getCodtipoplazo());
		mapCabDeclara.put("numPlazosol", dua.getNumplazosol());
		mapCabDeclara.put("codTiptratmerc", dua.getCodtipotratamiento());
		mapCabDeclara.put("codProdurgente", dua.getCodprodurgente());		
		mapCabDeclara.put("fecFinprovsional", dua.getFecfinprovsional());
		mapCabDeclara.put("indSocorro", dua.getIndSocorro());
		mapCabDeclara.put("codRiesgoOea", dua.getCodRiesgoOea());//pase PAS20181U220200016 operadoroea
		
		if (dua.getManifiesto()!=null){
			mapCabDeclara.put("codViatrans", dua.getManifiesto().getCodmodtransp());
			mapCabDeclara.put("codPuerPresemani", dua.getManifiesto().getCodpuerto());//Agregado		
			mapCabDeclara.put("codAduamanifiesto", dua.getManifiesto().getCodaduamanif());
			mapCabDeclara.put("codTipmanifiesto", dua.getManifiesto().getCodtipomanif());
			if (dua.getManifiesto().getAnnmanif()!=null)
				mapCabDeclara.put("annManifiesto", Integer.valueOf(dua.getManifiesto().getAnnmanif().substring(0,4)));
			mapCabDeclara.put("numManifiesto", SunatNumberUtils.toInteger(dua.getManifiesto().getNummanif()));
			//mapCabDeclara.put("fecTerm", dua.getManifiesto().getFectermino());

			if(! SunatStringUtils.isEmptyTrim(dua.getManifiesto().getNumviaje()))
				mapCabDeclara.put("numViaje", dua.getManifiesto().getNumviaje());

			mapCabDeclara.put("fecIniembarque", dua.getManifiesto().getFeciniembarque());
		}

		/* ONEYRAJ PAS20144E610000245 INICIO */
		boolean esFechaLlegada = funcionesService.esFechaLlegada(dua, Calendar.getInstance().getTime(), codTransaccion);
		if (esFechaLlegada) {
			mapCabDeclara.put("fecLlegada", dua.getManifiesto().getFectermino());
			//mapCabDeclara.put("fecTerm", dua.getManifiesto().getFectermino()); se depura por bug 18338 arey
		}
		else {//Cambios PAS20181U220200049
			/* SE DEJA EL CODIGO - VER ESTO EN EL PASE QUE VALIDARA DIFERIDOS
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Date fechaReferencia = dua.getFecdeclaracion()!=null?dua.getFecdeclaracion():new Date(); 
			Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", fechaReferencia);
			if (!CollectionUtils.isEmpty(MapaValManNum)){
				if(ConstantesDataCatalogo.MODA_EXCEPCIONAL.equalsIgnoreCase(dua.getCodmodalidad()) ) {
				
					//aqu� si la modalidad es excepcional, tomar la fecha de llegada de la informaci�n del manifiesto asociado 
					ManifiestoService manifiestoService = (ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService");
					
					// inicio PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:
					Manifiesto manifiesto = null;
					List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
					boolean considerarEER = dua.getCodlugarecepcion()!=null && dua.getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
					
					if(!ResponseListManager.responseListHasErrors(listaOMA)){
						manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
								declaracion.getDua().getManifiesto().getCodmodtransp(), 
								declaracion.getDua().getManifiesto().getCodaduamanif(), 
								Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
								declaracion.getDua().getManifiesto().getNummanif(),true,fechaReferencia, considerarEER );					
					}else{
						manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
									declaracion.getDua().getManifiesto().getCodmodtransp(), 
									declaracion.getDua().getManifiesto().getCodaduamanif(), 
									Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
									declaracion.getDua().getManifiesto().getNummanif(),true);					
					}
					//fin PAS20181U220200049
					
					//Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(declaracion.getDua().getManifiesto().getCodtipomanif(), 
					//		declaracion.getDua().getManifiesto().getCodmodtransp(), 
					//		declaracion.getDua().getManifiesto().getCodaduamanif(), 
					//		Integer.valueOf(declaracion.getDua().getManifiesto().getAnnmanif()!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4):"0"),
					//		declaracion.getDua().getManifiesto().getNummanif(),true);
					mapCabDeclara.put("fecTerm", manifiesto.getFechaEfectivaDeLlegada());
				}
				else {
					mapCabDeclara.put("fecTerm", dua.getManifiesto().getFectermino());
				}
				
			}
			else {
				mapCabDeclara.put("fecTerm", dua.getManifiesto().getFectermino());
			}
			*/
			mapCabDeclara.put("fecTerm", dua.getManifiesto().getFectermino());
		}
		
		/* ONEYRAJ PAS20144E610000245 FIN */

		if (dua.getPago()!=null){
			if(dua.getPago().getPagoDeclaracion()!=null){
				mapCabDeclara.put("numCtacte", dua.getPago().getPagoDeclaracion().getCodgarantia());
				mapCabDeclara.put("codModpago", dua.getPago().getPagoTransaccion().getCodmodpago());
			}
			if (dua.getPago().getPagoTransaccion()!=null){
				mapCabDeclara.put("codEntipago", SunatStringUtils.isEmpty(dua.getPago().getPagoTransaccion().getCodentipago())?" ":dua.getPago().getPagoTransaccion().getCodentipago());
				mapCabDeclara.put("cntPlzcredito", dua.getPago().getPagoTransaccion().getNumplazcredito());
				mapCabDeclara.put("fecCarcr", dua.getPago().getPagoTransaccion().getFeccarcr());
			}
		}
		String codopadusal=dua.getOtraAduana()!=null?dua.getOtraAduana().getCodopadusal():null;
		mapCabDeclara.put("codAdudest", codopadusal);
		mapCabDeclara.put("numDeclaracion", numDeclaracion);

		FechaBean fbCurrent=new FechaBean();
		Integer anho=new Integer(fbCurrent.getAnho());
		mapCabDeclara.put("annPresen", anho);
		mapCabDeclara.put("annOrden", numOrden.substring(0, 4));
		mapCabDeclara.put("numOrden", numOrden.substring(4, 10));
		mapCabDeclara.put("codEstdua", "01");
		mapCabDeclara.put("fecDeclaracion", SunatDateUtils.getCurrentDate());
		// hsaenz: 08/09/2014: Si fecha de conclusion es diferente de null, se pasa dentro del map
		//mapCabDeclara.put("fecConclusion", fechaConclusionDespa);
		if(fechaConclusionDespa != null) {
			mapCabDeclara.put("fecConclusion", fechaConclusionDespa);
		}
		// Fin hsaenz: 08/09/2014
		if(dua.getFecfinacoregimen() != null)
			mapCabDeclara.put("fecVenregimen", dua.getFecfinacoregimen());

		String tipadudest=" ";
		if (!SunatStringUtils.isEmptyTrim(dua.getOtraAduana().getCodopadusal()))
			tipadudest="01";
		else if (!SunatStringUtils.isEmptyTrim(dua.getOtraAduana().getCodopaduing()))
			tipadudest="02";
		else if (!SunatStringUtils.isEmptyTrim(dua.getOtraAduana().getCodopadutra()))
			tipadudest="03";
		if (!SunatStringUtils.isEmptyTrim(tipadudest))
			mapCabDeclara.put("codTipadudest", tipadudest);

		boolean requiereRegularizacion = !CollectionUtils.isEmpty(getListIndicadorByTipo(dua, ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION));
		if (dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) ||
				(dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) &&  requiereRegularizacion)) {
			mapCabDeclara.put("codEstregul", "01");
		}
		// HSAENZ: 08/09/2014: Se agrega fecha de vencimiento de conclusion
		if(fechaVencimientoConclusion != null) {
			mapCabDeclara.put("fecVenConclu", fechaVencimientoConclusion);
		}
		// Fin HSAENZ: 08/09/2014
	}

	private boolean fillCabAdjAtpa(Map<String,Object> mapCabAdjAtpa,Declaracion declaracion,Long numCorreDoc){
		DUA dua=declaracion.getDua();
		mapCabAdjAtpa.put("numCorredoc",numCorreDoc);
		mapCabAdjAtpa.put("codFeria",dua.getCodferia());
		return true;
	}


	private boolean fillFinUbicacion(Map<String,Object> mapFinUbicacion,Declaracion declaracion,Long numCorreDoc){
		DUA dua=declaracion.getDua();
		mapFinUbicacion.put("numCorredoc", numCorreDoc);
		mapFinUbicacion.put("desFinalidad", dua.getDesfinalidad());
		mapFinUbicacion.put("codLocanexo", dua.getCodlocalanexo());
		mapFinUbicacion.put("codTipdoclocmerc", "4" );

		if(dua.getRucAnexoUbicacion() != null || dua.getNumrucdeposito() != null){
			if("20".equals(declaracion.getDua().getCodregimen())){
				mapFinUbicacion.put("numDocLocmerc", dua.getRucAnexoUbicacion().getNumeroDocumentoIdentidad());
				if (SunatStringUtils.isEmptyTrim(dua.getRucAnexoUbicacion().getNumeroDocumentoIdentidad()))
					return false;
			} else if("70".equals(declaracion.getDua().getCodregimen())){
				mapFinUbicacion.put("numDocLocmerc", dua.getNumrucdeposito());
				if (SunatStringUtils.isEmptyTrim(dua.getNumrucdeposito()))
					return false;
			}			
		}else
			return false;
		return true;
	}

	private void fillIndicadorDUA(Map<String,Object> mapIndicadoresDUA,Declaracion declaracion, DatoIndicadores indicador, Long numCorreDoc){
		mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
		mapIndicadoresDUA.put("codIndicador", indicador.getCodtipoindica());
		mapIndicadoresDUA.put("codTiporegistro", "T");
	}

	private void fillDocAutAsociado(Map<String,Object> mapDocAutAsociado, DatoOtroDocSoporte docSop, String aduana, Long numeCorreDoc){
		mapDocAutAsociado.put("numCorredoc", numeCorreDoc);
		mapDocAutAsociado.put("numSecdoc", docSop.getNumsecdocum());
		mapDocAutAsociado.put("codTipoper", docSop.getCodtipoproceso());
		mapDocAutAsociado.put("codTipdocaso", docSop.getCodtipodocasoc());
		mapDocAutAsociado.put("codAduAut", aduana);
		if (SunatStringUtils.length(docSop.getAnndocasoc())>4) {
			mapDocAutAsociado.put("annDoc", docSop.getAnndocasoc().substring(0,4));
		}
		//PAS20134E610000296 - Para que las Resoluciones de Incentivo Migratorio las grabe con ceros adelante, longitud 6 caracteres
		String numDoc = "";
		if ("I".equals(docSop.getCodtipoproceso()) && "02".equals(docSop.getCodtipodocasoc())) {
			numDoc = SunatStringUtils.lpad(docSop.getNumdocasoc(), 6, '0');
		}
		else {
			numDoc = docSop.getNumdocasoc();
		}
		mapDocAutAsociado.put("numDoc", numDoc );
		mapDocAutAsociado.put("fecEmis", docSop.getFecdocasoc());
		mapDocAutAsociado.put("fecVenc", docSop.getFecvencimiento());
		mapDocAutAsociado.put("codEnti", docSop.getCodtipoentidad());
		mapDocAutAsociado.put("codIdent", docSop.getCodentidademisora());
		mapDocAutAsociado.put("codTipdoc", docSop.getCodtipodocentidad());
		mapDocAutAsociado.put("codTipoper", docSop.getCodigoUsuario());
		mapDocAutAsociado.put("obsObs", docSop.getDesentidad());
		mapDocAutAsociado.put("codTipoper", docSop.getCodtipoproceso());

		/*pruizcr pase42 fin*/
	}


	private void fillCabAdjImpoconsu(Map<String,Object> mapCabAdjImpoconsu, Declaracion declaracion, Long numCorreDoc, Map<String,Object> indicadorMV, boolean esTPN21 ){
		mapCabAdjImpoconsu.put("numCorredoc", numCorreDoc);
		if(declaracion.getDua().getPago()!=null && declaracion.getDua().getPago().getPagoDeclaracion()!=null){
			mapCabAdjImpoconsu.put("codBcopagoelec", declaracion.getDua().getPago().getPagoDeclaracion().getCodbcopagoelec());
			mapCabAdjImpoconsu.put("numCuentapagoe", declaracion.getDua().getPago().getPagoDeclaracion().getNumctapagoelec());
		}
		//PAS20171U220200005 - mtorralba 20170810 - Inicio
		boolean tieneIndicadorMV = !indicadorMV.isEmpty();
		if( tieneIndicadorMV ) {
			if( esTPN21 ) 
				mapCabAdjImpoconsu.put("numEnvioparcial",Integer.valueOf(indicadorMV.get("desIndicador").toString()));
			else {
				mapCabAdjImpoconsu.put("numEnvioparcial", Integer.valueOf("1"));
				mapCabAdjImpoconsu.put("numTotalenvios",Integer.valueOf(indicadorMV.get("desIndicador").toString()));
			}
		}
		//PAS20171U220200005 - mtorralba 20170810 - Inicio
		if(declaracion.getDua().getUnidadCarga() != null && declaracion.getDua().getUnidadCarga().getCodCarga() != null){
			mapCabAdjImpoconsu.put("codCarga", declaracion.getDua().getUnidadCarga().getCodCarga());
			mapCabAdjImpoconsu.put("cntCarga", declaracion.getDua().getUnidadCarga().getCntCarga());
		}
		return;
	}

	private void fillDetDeclara(Map<String,Object> mapDetDeclara,DUA dua,DatoSerie serie,Long numCorreDoc){
		mapDetDeclara.put("numCorredoc",numCorreDoc);
		mapDetDeclara.put("numSecserie",serie.getNumserie());
		mapDetDeclara.put("codUltractividad",serie.getCodaplultra()!=null?serie.getCodaplultra():" ");
		mapDetDeclara.put("codUnicomer",serie.getCodunicomer()!=null?serie.getCodunicomer():" ");
		mapDetDeclara.put("cntComer",serie.getCntunicomer()!=null?serie.getCntunicomer():0);
		mapDetDeclara.put("codClasebultos",serie.getCodclasbul()!=null?serie.getCodclasbul():" ");
		mapDetDeclara.put("cntBulto",serie.getCntbultos()!=null?serie.getCntbultos():0);
		mapDetDeclara.put("cntPesoNeto",serie.getCntpesoneto()!=null?serie.getCntpesoneto():0);
		mapDetDeclara.put("cntPesoBruto",serie.getCntpesobruto()!=null?serie.getCntpesobruto():0);
		mapDetDeclara.put("cntPesovehic",serie.getCntpesovehic()!=null?serie.getCntpesovehic():0);
		mapDetDeclara.put("codUnifisica",serie.getCodunifis()!=null?serie.getCodunifis():" ");
		mapDetDeclara.put("cntUnifis",serie.getCntunifis()!=null?serie.getCntunifis():0);
		mapDetDeclara.put("codUniIsc",serie.getCodunicomisc()!=null?serie.getCodunicomisc():" ");
		mapDetDeclara.put("cntUniisc",serie.getCntunicomisc()!=null?serie.getCntunicomisc():0);
		mapDetDeclara.put("numPartnandi",serie.getNumpartnandi()!=null?serie.getNumpartnandi():0);
		mapDetDeclara.put("numParnaladisa",serie.getNumpartnalad()!=null?serie.getNumpartnalad():" ");
		mapDetDeclara.put("numParnabandina",serie.getNumpartnaban()!=null?serie.getNumpartnaban():" ");
		mapDetDeclara.put("numParcorrelacion",serie.getNumpartcorre()!=null?serie.getNumpartcorre():" ");
		mapDetDeclara.put("codPaisorigen",serie.getCodpaisorige()!=null?serie.getCodpaisorige():" ");
		mapDetDeclara.put("codPaisadqui",serie.getCodpaisadqui()!=null?serie.getCodpaisadqui():" ");
		mapDetDeclara.put("codMonetrans",serie.getCodmoneda()!=null?serie.getCodmoneda():" ");
		mapDetDeclara.put("mtoFobmontrans",serie.getMtofobmon()!=null?serie.getMtofobmon():0);
		mapDetDeclara.put("mtoFobdol",serie.getMtofobdol()!=null?serie.getMtofobdol():0);
		mapDetDeclara.put("mtoFletedol",serie.getMtofledol()!=null?serie.getMtofledol():0);
		mapDetDeclara.put("mtoSegdol",serie.getMtosegdol()!=null?serie.getMtosegdol():0);
		mapDetDeclara.put("mtoAjuste",serie.getMtoajuste()!=null?serie.getMtoajuste():0);
		mapDetDeclara.put("mtoValoradu",serie.getMtovaladuana()!=null?serie.getMtovaladuana():0);
		mapDetDeclara.put("codTipseg",serie.getCodtiposeg()!=null?serie.getCodtiposeg():" ");
		mapDetDeclara.put("codTipflete",serie.getCodtipoflete()!=null?serie.getCodtipoflete():" ");
		mapDetDeclara.put("desComer",serie.getDescomercial()!=null?serie.getDescomercial():" ");
		mapDetDeclara.put("desFormapresen",serie.getDesformapres()!=null?serie.getDesformapres():" ");
		mapDetDeclara.put("desMatecomp",serie.getDesmatecomp()!=null?serie.getDesmatecomp():" ");
		mapDetDeclara.put("desUsoaplic",serie.getDesusoaplica()!=null?serie.getDesusoaplica():" ");
		mapDetDeclara.put("desOtroscarac",serie.getDesotros()!=null?serie.getDesotros():" ");
		mapDetDeclara.put("codEstmerc",serie.getCodestamerca()!=null?serie.getCodestamerca():" ");
		mapDetDeclara.put("fecExpiracion",serie.getFecexpiracion()!=null?serie.getFecexpiracion():SunatDateUtils.getDefaultDate());//TODO solo deposito
		mapDetDeclara.put("codTiptasaaplicar",serie.getCodtnan()!=null?serie.getCodtnan():" ");
		mapDetDeclara.put("codTipmargen",serie.getCodtipomarge()!=null?serie.getCodtipomarge():" ");
		mapDetDeclara.put("mtoEstimado",serie.getValestimado()!=null?serie.getValestimado():0);
		mapDetDeclara.put("codValorajuste",serie.getCodvalajuste());
		if(serie.getProducto()!=null){
			mapDetDeclara.put("codExpoaplicantid",serie.getProducto().getCodexpantidum());
			mapDetDeclara.put("codProdantid",serie.getProducto().getCodpantidum());
			mapDetDeclara.put("mtoFobfact",serie.getProducto().getMtofobfactu());
		}else{
			mapDetDeclara.put("codExpoaplicantid"," ");
			mapDetDeclara.put("codProdantid"," ");
			mapDetDeclara.put("mtoFobfact",0);
		}
		if(serie.getMercancia()!=null){
			mapDetDeclara.put("codTipexonrestri",serie.getMercancia().getCodtipoexoneracion());
			mapDetDeclara.put("codExmercrest",serie.getMercancia().getCodexoneracion());
			mapDetDeclara.put("codProdrestr",serie.getMercancia().getCodproducto());
			mapDetDeclara.put("codRssenasa",serie.getMercancia().getCodriesgosanitario());
		}else{
			mapDetDeclara.put("codTipexonrestri"," ");
			mapDetDeclara.put("codExmercrest"," ");
			mapDetDeclara.put("codProdrestr"," ");
			mapDetDeclara.put("codRssenasa"," ");
		}
		DatoDocTransporte docTransporte=getDocTransporte(dua,serie);
		if(docTransporte!=null){
			mapDetDeclara.put("codPuerEmbar",docTransporte.getCodpuerto());
			mapDetDeclara.put("fecEmbarque",docTransporte.getFecembarque());
			//TODO codtipodoctrans pedir que cambien tama�o campo a 3
			mapDetDeclara.put("codTipdoctransp",docTransporte.getCodtipodoctrans());
			mapDetDeclara.put("numDoctransp",getDocTransporte(dua,serie).getNumdoctransporte());
			mapDetDeclara.put("numDoctranspmaster",getDocTransporte(dua,serie).getNumdocmaster());
			mapDetDeclara.put("fecEmborigen",getDocTransporte(dua,serie).getFecembarqueorg());
			mapDetDeclara.put("fecEmborigen",getDocTransporte(dua,serie).getFecembarqueorg());
			mapDetDeclara.put("numDetalle",docTransporte.getNumdetalle());
		}else{
			mapDetDeclara.put("codPuerEmbar"," ");
			mapDetDeclara.put("fecEmbarque",SunatDateUtils.getDefaultDate());
			//TODO codtipodoctrans pedir que cambien tama�o campo a 3
			mapDetDeclara.put("codTipdoctransp"," ");
			mapDetDeclara.put("numDoctransp"," ");
			mapDetDeclara.put("numDoctranspmaster"," ");
			mapDetDeclara.put("fecEmborigen",SunatDateUtils.getDefaultDate());
			mapDetDeclara.put("fecEmborigen",SunatDateUtils.getDefaultDate());
			mapDetDeclara.put("numDetalle",0);
		}

		mapDetDeclara.put("codPaisproced",serie.getCodpaisprodes()!=null?serie.getCodpaisprodes():" ");
	}

	private boolean fillConvenioSerie(Map<String, Object> mapConvenioSerie, DatoSerie serie, Long numCorreDoc, String codTipconvenio){
		Integer codConvenio;
		if ("I".equals(codTipconvenio))
			codConvenio=serie.getCodconvinter();
		else if("C".equals(codTipconvenio))
			codConvenio=serie.getCodliberatorio();
		else //codTipoconvenio="T"
			codConvenio=serie.getCodtratprefe();
		String convenio="";
		if (codConvenio!=null)
			convenio=String.valueOf(codConvenio.intValue());
		else 
			return false;
		mapConvenioSerie.put("codConvenio", SunatStringUtils.lpad(convenio,4,' '));
		mapConvenioSerie.put("codTipconvenio", codTipconvenio);
		mapConvenioSerie.put("numCorredoc", numCorreDoc);
		mapConvenioSerie.put("numSecserie", serie.getNumserie());
		return true;
	}

	private void fillDetAdiImpoconsu(Map<String, Object> mapDetAdiImpoconsu,DatoSerie serie,Long numCorreDoc){
		mapDetAdiImpoconsu.put("numCorredoc", numCorreDoc);
		mapDetAdiImpoconsu.put("numSecserie", serie.getNumserie());
		mapDetAdiImpoconsu.put("indAcogcodliber", serie.getValindcodlib());
		if (serie.getValpreciovta()!=null && BigDecimal.ZERO.compareTo(serie.getValpreciovta())!=0)
			mapDetAdiImpoconsu.put("mtoPvpmonnac", serie.getValpreciovta());
		//		mapDetAdiImpoconsu.put("indZonafranca", serie.getIndzonafranca());

		if( ! SunatStringUtils.isEmpty(serie.getDeszonafranca()) )
			mapDetAdiImpoconsu.put("desZonafranca", serie.getDeszonafranca());

		if (serie.getMtofobnet()!=null && BigDecimal.ZERO.compareTo(serie.getMtofobnet())!=0)
			mapDetAdiImpoconsu.put("mtoFobpneto", serie.getMtofobnet());

		if (serie.getIndParteVehiculo()!=null && !SunatStringUtils.isEmpty(serie.getIndParteVehiculo()))
			mapDetAdiImpoconsu.put("indPartesVehic", serie.getIndParteVehiculo());

		// Inicio: PAS20145E220000337 - rcontreras
		if (serie.getPoralcohol() !=null && serie.getPoralcohol().compareTo(BigDecimal.ZERO) > 0 )
			mapDetAdiImpoconsu.put("porAlcohol", serie.getPoralcohol());
		//	Fin: PAS20145E220000337 - rcontreras
		//dua can
		if (serie.getCodRegion() != null && !SunatStringUtils.isEmpty(serie.getCodRegion())) {
			mapDetAdiImpoconsu.put("codRegion", serie.getCodRegion());
		}
	}

	private void fillDetAdiAtpa(Map<String, Object> mapDetAdiAtpa, DatoSerie serie, Long numCorreDoc, String regimen){
		DatoProducto product=serie.getProducto();
		String codtipoequi=product!=null?product.getCodtipoequi():null;
		BigDecimal cntunimedidaequi=product!=null?product.getCntunimedidaequi():null;
		String numitem=product!=null?product.getNumitem():null;

		mapDetAdiAtpa.put("numCorredoc", numCorreDoc);
		mapDetAdiAtpa.put("numSecserie", serie.getNumserie());

		mapDetAdiAtpa.put("codInsumo", numitem);
		//		if (regimen.equals("21")){// coordinado con Elsa
		mapDetAdiAtpa.put("cntUniEqui", cntunimedidaequi);
		mapDetAdiAtpa.put("codUmEqui", codtipoequi);
		//		}
	}

	private boolean fillDetAdiAtreex(Map<String, Object> mapDetAdiAtreex, DatoSerie serie, Long numCorreDoc){

		DatoProducto product=serie.getProducto();
		BigDecimal pormerma=product!=null?product.getPormerma():null;

		mapDetAdiAtreex.put("numCorredoc",numCorreDoc);
		mapDetAdiAtreex.put("numSecserie",serie.getNumserie());
		mapDetAdiAtreex.put("porMerma",serie.getProducto().getPormerma());
		return pormerma!=null;
	}

	private void fillDocuPreceDua(Map<String,Object> mapDocuPreceDua, DatoSerie serie, DatoRegPrecedencia prec, Long numCorreDoc){
		mapDocuPreceDua.put("numCorredoc", numCorreDoc);
		mapDocuPreceDua.put("numSecserie", serie.getNumserie());
		mapDocuPreceDua.put("codAduanapre", prec.getCodaduapre());
		mapDocuPreceDua.put("codRegimenpre", prec.getCodregipre());
		Integer annDecl=null;
		if(SunatStringUtils.length(prec.getAnndeclpre())>3){
			String strAnndcl=prec.getAnndeclpre().substring(0,4);
			annDecl=SunatNumberUtils.toInteger(strAnndcl);
		}

		mapDocuPreceDua.put("annPresenpre", annDecl);
		mapDocuPreceDua.put("numDeclaracionpre", SunatNumberUtils.toInteger(prec.getNumdeclpre()));
		mapDocuPreceDua.put("numSecseriepre", prec.getNumserpre());
		mapDocuPreceDua.put("fecVencregpre", prec.getFecvencpre());
	}

	private void fillVehiCetico(Map<String,Object> mapVehiCetico, DatoVehiculo vehiculo, Integer numSerie, Long numCorreDoc){
		mapVehiCetico.put("numCorredoc", numCorreDoc);
		mapVehiCetico.put("numSecserie", numSerie);
		mapVehiCetico.put("nomPubli", vehiculo.getNomlibro());
		mapVehiCetico.put("numEjemplarpub", vehiculo.getCodejempl());

		if(! SunatStringUtils.isEmpty(vehiculo.getAnnmespubli()) )
		{
			String s1 = vehiculo.getAnnmespubli();
			String s2 = s1.substring(0, 4);
			String s3 = s1.substring(5, 7);
			mapVehiCetico.put("perPubli", new Integer( (s2+s3) ));			
		}

		mapVehiCetico.put("numPagina", vehiculo.getNumpagin());
		mapVehiCetico.put("codFactorconv", vehiculo.getNumfactconve());
	}

	private void fillMontoGasto(Map<String,Object> mapVehConceptoGasto, DatoMontoGasto mtoGasto, Integer numSerie, Long numCorreDoc){
		mapVehConceptoGasto.put("numCorredoc", numCorreDoc);
		mapVehConceptoGasto.put("numSecserie", numSerie);		
		mapVehConceptoGasto.put("codCptogastos", mtoGasto.getTipmonto());
		mapVehConceptoGasto.put("mtoGasto", mtoGasto.getValmonto());
	}
	private void fillAgente(Participante agente,String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender){
		DataCatalogo tipo= new DataCatalogo();

		tipo.setCodCatalogo("316");//Tipo de participante
		tipo.setCodDatacat(tipoSender);
		agente.setNumeroDocumentoIdentidad(numeroDocumentoIdentidadSender);
		agente.getTipoDocumentoIdentidad().setCodDatacat(tipoDocumentoIdentidadSender);
		agente.getTipoParticipante().setCodDatacat("41");
		//RectificacionServiceImpl.getInstance().getSoporteService().completarParticipante(agente);
		((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).completarParticipante(agente);
	}

	private boolean include(List<String> list, String str){
		if (!SunatStringUtils.isEmptyTrim(str)){
			for(String val:list){
				if (val.trim().equals(str.trim()))
					return true;
			}
			return false;
		}else
			return true;
	}

	//INICIO PAS20155E220000054
    private boolean existeDocSoportNivelSerie(Declaracion declaracion){
    	for(DatoSerie serie:declaracion.getDua().getListSeries()){   
    		for(DatoSerieDocSoporte serieDoc:serie.getListSerieDocSoporte()){             
    			if(DOC_SOPORTE.equals(serieDoc.getCodtipodocsoporte())){                   
    				return true;
    			}
            }   
    	}
		return false;
	}
	//FIN PAS20155E220000054


	private void fillCabCtacteRegimen(DatoSerie serie, DatoRegPrecedencia prec, Long numCorredoc){

		DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
		Map<String,Object> paramCtaCte = new HashMap<String,Object>();
		paramCtaCte.put("codAduana", prec.getCodaduapre());
		paramCtaCte.put("annPresen", prec.getAnndeclpre().substring(0, 4));
		paramCtaCte.put("codRegimen", prec.getCodregipre());
		paramCtaCte.put("numDeclaracion", prec.getNumdeclpre());
		paramCtaCte.put("numSecserie", prec.getNumserpre());
		List<CabCtacteRegimen> listaCabCtacteRegimen = ctaCteService.obtenerCabeceraCtaCte(paramCtaCte);
		if( listaCabCtacteRegimen.size()>0 ) {
			CabCtacteRegimen ctacte = listaCabCtacteRegimen.get(0);  	
			ctaCteService.actualizaCtacteRegimen(ctacte, serie, numCorredoc);	
		}

		return;
	}


	//PAS20165E220200025 - Inicio
	private DatoDocAutorizante actualizaDocAutorizante(DatoDocAutorizante doc, List<DatoDocAutorizante> listaVUCE) {

		for( DatoDocAutorizante docvuce :  listaVUCE ) {
			if( doc.getNumdocum() == docvuce.getNumdocum() ) {
				doc = docvuce;
				break;
			}   
		}
		return doc;
	}


	//PAS20191U220200019 - mtorralba 20190528 - M�todo para obtener tipo de operador asociado a punto de llegada (DATACATASOC 510)
	private String obtenerOperadorPorPuntoLlegada(String puntoLlegada) {
		String operador = "";
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codAsociacion", "510");
		parametros.put("codElemento", puntoLlegada);
		parametros.put("codSelElemento", "C");
		parametros.put("ayudaID", "DataCatAsoc");
		List<Map<String,Object>>  listDataCatAsoc = (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findByMapDataCatAsoc(parametros);
		if( listDataCatAsoc.size() > 0 ) {
			Map<String,Object> mapa = listDataCatAsoc.get(0);
			operador = mapa.get("cod_datacatasoc").toString();
		}
		return operador;
	}

	/*
	public void setSequenceDAO(SequenceDAO sequenceDAO) {
		this.sequenceDAO = sequenceDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public void setCabAdjAtpaDAO(CabAdjAtpaDAO cabAdjAtpaDAO) {
		this.cabAdjAtpaDAO = cabAdjAtpaDAO;
	}

	public void setFinUbicacionDAO(FinUbicacionDAO finUbicacionDAO) {
		this.finUbicacionDAO = finUbicacionDAO;
	}

	public void setEquipamientoDAO(EquipamientoDAO equipamientoDAO) {
		this.equipamientoDAO = equipamientoDAO;
	}

	public void setParticipanteDAO(ParticipanteDocDAO participanteDAO) {
		this.participanteDAO = participanteDAO;
	}

	public void setPrecintoDAO(PrecintoDAO precintoDAO) {
		this.precintoDAO = precintoDAO;
	}

	public void setObservacionDAO(ObservacionDAO observacionDAO) {
		this.observacionDAO = observacionDAO;
	}

	public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
		this.indicadorDUADAO = indicadorDUADAO;
	}

	public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO) {
		this.docAutAsociadoDAO = docAutAsociadoDAO;
	}

	public void setCabAdjImpoconsuDAO(CabAdjImpoconsuDAO cabAdjImpoconsuDAO) {
		this.cabAdjImpoconsuDAO = cabAdjImpoconsuDAO;
	}*/

	/*
	public void setDocumentoDAO(DocumentoDAO documentoDAO) {
		this.documentoDAO = documentoDAO;
	}*/

	public int sizeMap(Map<String,Object> map){
		int size=0;
		for(Map.Entry<String,Object> e: map.entrySet()){
			if (e.getValue()!=null)
				size++;
		}
		return size;
	}
	/*
	public void setMovEquipamientoDAO(MovEquipamientoDAO movEquipamientoDAO) {
		this.movEquipamientoDAO = movEquipamientoDAO;
	}

	public void setManifiestoService(ManifiestoService manifiestoService) {
		this.manifiestoService = manifiestoService;
	}

	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public DeclaracionBatchService getDeclaracionBatchService() {
		return declaracionBatchService;
	}

	public void setDeclaracionBatchService(DeclaracionBatchService declaracionBatchService) {
		this.declaracionBatchService = declaracionBatchService;
	}
	public void setProrrogaService(ProrrogaService prorrogaService) {
		this.prorrogaService = prorrogaService;
	}
	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}*/

}
