package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.cierres;

import java.util.List;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

public class ValidadorCierreAbstract extends ValidadorAbstract{

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception{
    return null;
  }
  
}
