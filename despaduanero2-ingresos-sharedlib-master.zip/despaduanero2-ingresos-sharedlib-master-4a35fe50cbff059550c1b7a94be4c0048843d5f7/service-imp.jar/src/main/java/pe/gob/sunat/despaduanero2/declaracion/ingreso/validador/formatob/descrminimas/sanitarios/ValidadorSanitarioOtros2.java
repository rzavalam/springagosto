package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.sanitarios;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioOtros;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValidadorSanitarioOtros2 extends ValidadorSanitarioAbstract{
	public static final String COD_URINARIO = "URI";	
	public static final String COD_CISTERNA = "CTK";
	public static final String COD_LAVABO = "LAV";
	public static final String COD_BIDE = "BDT"; 
	
	
	@Override
	public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception{


		List<ErrorDescrMinima> lstErroresDescrMin = validarEstructura(objeto);
        lstErroresDescrMin.addAll(validartipo(objeto));
        lstErroresDescrMin.addAll(validarValvula(objeto, dua.getDua().getFecdeclaracion()));

        //lstErroresDescrMin.addAll(validarEstructura(objeto));

        lstErroresDescrMin.addAll(super.validarNombreComercial(objeto,dua));
        if (CollectionUtils.isEmpty(lstErroresDescrMin)){        	
        	//lstErroresDescrMin.addAll(validarEstructura(objeto));//duplicado
            lstErroresDescrMin.addAll(super.validarMarcaComercial(objeto));
            lstErroresDescrMin.addAll(super.validarModeloComercial(objeto));
            lstErroresDescrMin.addAll(super.validarCalidad(objeto));
            lstErroresDescrMin.addAll(super.validarColor(objeto));
            lstErroresDescrMin.addAll(super.validarMaterial(objeto));
            lstErroresDescrMin.addAll(validarConsumoAgua(objeto));
       }

   	    return lstErroresDescrMin;
	}
	
	public List<ErrorDescrMinima> validartipo(ModelAbstract objeto){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioOtros sanitarioOtros = (SanitarioOtros) objeto;
		String NombreComercialSanitario = sanitarioOtros.getNombreComercial().getValtipdescri().trim(); 
		String datoAValidar = sanitarioOtros.getTipo()!=null?sanitarioOtros.getTipo().getValtipdescri():" ";
		if(COD_CISTERNA.equalsIgnoreCase(NombreComercialSanitario)){
			//se retira la mandatoriedad PAS20165E220200137
			/*if(datoAValidar.isEmpty()||datoAValidar==null){
				ErrorDescrMinima error = obtenerError("31074", sanitarioOtros.getTipo());
				lstErroresDescrMin.add(error);
			}*/
			if(!datoAValidar.trim().isEmpty()){				
				Object[] argumentos = new Object[] { sanitarioOtros.getNombreComercial().getValtipdescri() };
				ErrorDescrMinima error = obtenerError("33016",sanitarioOtros.getTipo(), argumentos);
				lstErroresDescrMin.add(error);
			}
			
		}
		else if(COD_LAVABO.equalsIgnoreCase(NombreComercialSanitario)){
			if(datoAValidar.trim().isEmpty()){
				ErrorDescrMinima error = obtenerError("31076", sanitarioOtros.getTipo());
				lstErroresDescrMin.add(error);
			}
		}
		else if(COD_BIDE.equalsIgnoreCase(NombreComercialSanitario)){
			if(datoAValidar.trim().isEmpty()){
				ErrorDescrMinima error = obtenerError("31078", sanitarioOtros.getTipo());
				lstErroresDescrMin.add(error);
			}
		}
		else if(COD_URINARIO.equalsIgnoreCase(NombreComercialSanitario)){
			if(datoAValidar.trim().isEmpty()){
				ErrorDescrMinima error = obtenerError("31080", sanitarioOtros.getTipo());
				lstErroresDescrMin.add(error);
			}
		}			
		return lstErroresDescrMin;
	}
	
	public List<ErrorDescrMinima> validarValvula(ModelAbstract objeto,  Date fechaVigencia){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioOtros sanitarioOtros = (SanitarioOtros) objeto;		
		String NombreComercialSanitario = sanitarioOtros.getNombreComercial().getValtipdescri().trim();
		
		//se retira la mandatoriedad para CISTERNA - CTK PAS20165E220200137
		
		/*if(COD_CISTERNA.equals(NombreComercialSanitario)){
			String datoAValidar = sanitarioOtros.getValvula().getValtipdescri();

			if(SunatStringUtils.isEmpty(datoAValidar)){
				ErrorDescrMinima error = obtenerError("31082",sanitarioOtros.getValvula());
			    lstErroresDescrMin.add(error);
			} 
		}
		else  {*/
			/*No debe consignar valvula para los dem�s casos en Sanitario OTROS */
			if(!SunatStringUtils.isEmpty(sanitarioOtros.getValvula()!=null?sanitarioOtros.getValvula().getValtipdescri().trim():""))
				
				{String descripcionNombreComercial = obtenerDescripcionDelCalogo("467", NombreComercialSanitario, fechaVigencia);
				lstErroresDescrMin.add(obtenerError("35027",sanitarioOtros.getValvula(),new Object[] {descripcionNombreComercial})); }
			
			
		/*}se retira mandatoriedad*/
		return lstErroresDescrMin;		
	}	

	public List<ErrorDescrMinima> validarConsumoAgua(ModelAbstract objeto){
		List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
		SanitarioOtros sanitarioOtros = (SanitarioOtros) objeto;
		String NombreComercialSanitario = sanitarioOtros.getNombreComercial().getValtipdescri().trim();
		if(COD_URINARIO.equals(NombreComercialSanitario)){
			String datoAValidar = sanitarioOtros.getConsumoAgua().getValtipdescri().trim();
			if(SunatStringUtils.isEmpty(datoAValidar)){
				ErrorDescrMinima error = obtenerError("31084",sanitarioOtros.getConsumoAgua());
			    lstErroresDescrMin.add(error);
			}
		}
		return lstErroresDescrMin;
	}
}