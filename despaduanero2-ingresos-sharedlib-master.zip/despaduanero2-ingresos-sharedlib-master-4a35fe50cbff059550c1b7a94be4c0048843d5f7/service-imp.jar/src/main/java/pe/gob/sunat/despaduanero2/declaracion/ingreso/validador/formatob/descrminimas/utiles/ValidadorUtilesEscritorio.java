package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.utiles;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.utiles.model.UtilesEscritorio;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorUtilesEscritorio extends ValidadorUtilesAbstract {

  private static final String CON_COLOR = "001";

  public ValidadorUtilesEscritorio() {
    super();
  }

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto,
                                                     Declaracion dua) throws Exception {
    
    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

    //lstErrorres.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores))  {
          DatoItem item =  obtenerItem(objeto, dua);
          lstErrores.addAll(super.validarUnidadComercial(objeto, item));
          lstErrores.addAll(validarColor(objeto));
          lstErrores.addAll(validarAcabado(objeto));
          lstErrores.addAll(validarDimensiones(objeto, item));
          lstErrores.addAll(validarPesoVolumen(objeto));
          lstErrores.addAll(validarAplicacionUso(objeto));          
          lstErrores.addAll(validarComposicionMercancia(objeto, item));
      }

    return lstErrores;
  }
  
  public List<ErrorDescrMinima> validarComposicionMercancia(ModelAbstract objeto,
                                                            DatoItem item) {
    return new ArrayList<ErrorDescrMinima>();
  }
  
  /**
   * @param objeto
   * @return Lista de Errores
   */
  public List<ErrorDescrMinima> validarColor(ModelAbstract objeto) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    UtilesEscritorio utiles = (UtilesEscritorio) objeto;
    String datoAValidar = utiles.getColor().getValtipdescri();
    if(CON_COLOR.equals(datoAValidar))
      if( utiles.getDescripcionColor() == null ||
    	  SunatStringUtils.isEmpty(utiles.getDescripcionColor().getValtipdescri()) || 
    	  utiles.getDescripcionColor().getValtipdescri().length() < 3){
    	  	lst.add(obtenerError("31200", utiles.getDescripcionColor()));
    }
    return lst;
  }
}