package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida;


import java.math.BigDecimal;
//import java.math.MathContext;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
//import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Polizad;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.PolizadDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatAsoc;
//import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDataCatAsoc;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
//Rin 14 - INI - JYC
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
//Rin 14 - FIN - JYC
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.CabMrDocAutoriz;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetMrDocAutoriz;
import pe.gob.sunat.despaduanero2.declaracion.model.MRestri;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabMrDocAutorizBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabMrDocAutorizDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetMrDocAutorizBatchDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetMrDocAutorizDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MrestriDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.ArchivoAnexoDocControlMR;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.DocControlMercRestringidaVuce;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.prevcontrabando2.operativo.model.dao.CabActasDAO;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionComunService;


public class MercanciaRestringidaEntidadServiceImpl extends IngresoAbstractServiceImpl implements MercanciaRestringidaEntidadService {

	//protected final Log log = LogFactory.getLog(getClass());

	//private FabricaDeServicios	fabricaDeServicios;
	//private CabMrDocAutorizBatchDAO cabMrDocAutorizBatchDAO;
	//private DetMrDocAutorizBatchDAO detMrDocAutorizBatchDAO;
	//private CatalogoAyudaService catalogoAyudaService;
	public static final String DOC_AUTORIZACION_OTROS = "99";//adicionados pase10 arey:
	public static final String DOC_PERMISO_SANITARIO = "09";
	public static final String DOC_CERTIFICADO = "03";
	public static final String DOC_AUTORIZACION = "01";
	public static final String REG_SANITARIO = "08";
	public static final String EXPED_TRAMITE = "12";
	public static final String NOTIF_SANITARIA = "16";	
	public static final String RESOL_DIRECTORAL = "02";
	public static final String COPIA_CERTIFICADA = "17";
	public static final String DOC_INFORME_INSPEC = "07";//adicionado pase23 arey:
	public static final String DOC_RESOLUTIVO = "21";
	public static final String SOLICITUD_SUCE = "20";
	public static final String COD_ASOCIA_SUBENTIDAD_VS_CUT_PARA_DR = "376";//adicionado pase72 VUCE RECTI
	public static final String DOC_EXONERACION = "98"; 
	public static final String DOC_EXONERACION80 = "80";

	private static final String String = null;
	/**
	 * rtineo optimizacion
	 * Realizar la carga inicial de variables
	 * @param declaracion
	 * @param fechaReferencia
	 * @param variablesIngreso
	 */
	@Override
	@ServicioAnnot(tipo="V",codServicio=9140, descServicio="Almacena las Variables Iniciales de Mercaderias Restringidas")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9140,numSecEjec=0,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")	
	public Map<String, Object> setupMercanciaRestringida(Declaracion declaracion, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		if(declaracion.getDua()!= null){
			List<Long> partidasInList = new ArrayList<Long>();
			StringBuilder partidas  = new StringBuilder();
			for(DatoSerie serie : declaracion.getDua().getListSeries()){
				Long numeroPartida = serie.getNumpartnandi();
				if(numeroPartida != null && !partidasInList.contains(numeroPartida)){
					partidasInList.add(numeroPartida);
					partidas.append(numeroPartida).append(",");
				}
			}
			if(!partidasInList.isEmpty()){
				//Map<String,List<MRestri>> mercanciasRestringidasCache = new HashMap<String,List<MRestri>>();
				Map<Long,List<MRestri>> mercanciasRestringidasCache = new HashMap<Long,List<MRestri>>(); //PAS20155E220000487 - la partida es Long no String, sino no invoca a los servicios de validaci�n
				String codigoRegimen = declaracion.getDua().getCodregimen();
				partidas.deleteCharAt(partidas.length()-1);
				Map<String,Object> parametros = new HashMap<String,Object>();
				parametros.put("codiregi", codigoRegimen);
				parametros.put("NUM_PARTNANDI_ALL", partidas.toString());
				parametros.put("fechaVigencia", SunatDateUtils.getIntegerFromDate(fechaReferencia));
				MrestriDAO mrestriDAO = (MrestriDAO) fabricaDeServicios.getService("mrestriDAO"); 
				List<MRestri> mercanciasRestringidas = mrestriDAO.listadoMercRestringida(parametros);

				//agrupamos registros por partida
				for(MRestri mercanciaRestringida:mercanciasRestringidas){
					//String partida = mercanciaRestringida.getCnan().toString(); //PAS20155E220000487 - la partida es Long no String, sino no invoca a los servicios de validaci�n
					Long partida = mercanciaRestringida.getCnan();
					List<MRestri> mercanciasRestringidasGroup = mercanciasRestringidasCache.get(partida);
					if(mercanciasRestringidasGroup == null){
						mercanciasRestringidasGroup = new ArrayList<MRestri>();
						mercanciasRestringidasCache.put(partida, mercanciasRestringidasGroup);
					}
					mercanciasRestringidasGroup.add(mercanciaRestringida);
				}
				variablesIngreso.put("mercanciasRestringidas", mercanciasRestringidasCache);
			}
		}
		return new HashMap<String,Object>();
	}

	/**
	 * rtineo optimizacion
	 * Realizar la carga inicial de variables
	 * @param declaracion
	 * @param fechaReferencia
	 * @param variablesIngreso
	 */
	@Override
	@ServicioAnnot(tipo = "V", codServicio = 9141, descServicio = "Configurar el subtipo de documento de cada documento autorizante")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "fechaReferencia","variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 9141, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public Map<String, Object> setupDocumentoAutorizadoSubTipoDocumento(Declaracion declaracion, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		Long tiempo_inicial = System.currentTimeMillis();
		System.out.println("Empieza carga de variables \n");
		if (declaracion.getDua() != null) {
			if (!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())) {
				Map<Integer, List<DatoDocAutorizante>> variablesDocumentoAutorizadoPorSerie = new HashMap<Integer, List<DatoDocAutorizante>>();

				//inicio agrupamiento
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				//consultamos una sola vez los catalogos via rest
				List<Map<String, String>> subTiposPorSubEntidadAll =  catalogoAyudaService.getListaAsociado(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU, fechaReferencia);
				List<Map<String, String>> subTiposPorTipoDocumentoAll =  catalogoAyudaService.getListaAsociado(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, fechaReferencia);

				//agrupamos los catalogos... se trata de no modificar drasticamente logica original, solo mejorar
				//1. subEntidades agrupados por docAutoriza.getCodsubentidad()
				Map<String, List<Map<String, String>>> subTiposPorSubEntidadGroup = new HashMap<String, List<Map<String, String>>>();
				for (Map<String, String> item : subTiposPorSubEntidadAll) {
					String codigo = item.get("cod_datacat");
					List<Map<String, String>> subTiposExistente = subTiposPorSubEntidadGroup.get(codigo);
					if (subTiposExistente == null) {
						subTiposExistente = new ArrayList<Map<String, String>>();
						subTiposPorSubEntidadGroup.put(codigo, subTiposExistente);
					}
					subTiposExistente.add(item);
				}

				//2. subTipos agrupados por docAutoriza.getCodtipodocum()
				Map<String, List<Map<String, String>>> subTiposPorTipoDocumentoGroup = new HashMap<String, List<Map<String, String>>>();
				for (Map<String, String> item : subTiposPorTipoDocumentoAll) {
					String codigo = item.get("cod_datacat");
					List<Map<String, String>> subTiposExistente = subTiposPorTipoDocumentoGroup.get(codigo);
					if (subTiposExistente == null) {
						subTiposExistente = new ArrayList<Map<String, String>>();
						subTiposPorTipoDocumentoGroup.put(codigo, subTiposExistente);
					}
					subTiposExistente.add(item);
				}

				//tambien lo requieren en otros metodos agrupado por subTipoDocumento :S
				Map<String, List<Map<String, String>>> tiposDocumentoPorSubTipoDocumentoGroup = new HashMap<String, List<Map<String, String>>>();
				for (Map<String, String> item : subTiposPorTipoDocumentoAll) {
					String codigo = item.get("cod_datacatasoc");
					List<Map<String, String>> tiposDocumentoExistente = tiposDocumentoPorSubTipoDocumentoGroup.get(codigo);
					if (tiposDocumentoExistente == null) {
						tiposDocumentoExistente = new ArrayList<Map<String, String>>();
						tiposDocumentoPorSubTipoDocumentoGroup.put(codigo, tiposDocumentoExistente);
					}
					tiposDocumentoExistente.add(item);
				}
				//fin agrupamiento


				//inicio agrupamiento catalogos asociacion ConstantesTipoCatalogo: CATALOGO_ASOCIACION_ENTIDAD_SUBENTIDAD, CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU
				List<Map<String, String>> subEntidadesPorEntidadAll =  catalogoAyudaService.getListaAsociado(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_ENTIDAD_SUBENTIDAD, fechaReferencia);
				Map<String, List<Map<String, String>>> subEntidadesPorEntidadGroup = new HashMap<String, List<Map<String, String>>>();
				for (Map<String, String> item : subEntidadesPorEntidadAll) {
					String codigo = item.get("cod_datacat");
					List<Map<String, String>> subEntidadesExistente = subEntidadesPorEntidadGroup.get(codigo);
					if (subEntidadesExistente == null) {
						subEntidadesExistente = new ArrayList<Map<String, String>>();
						subEntidadesPorEntidadGroup.put(codigo, subEntidadesExistente);
					}
					subEntidadesExistente.add(item);
				}
				//fin agrupamiento catalogos asociacion ConstantesTipoCatalogo: CATALOGO_ASOCIACION_ENTIDAD_SUBENTIDAD, CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU

				//inicio agrupamiento servicios de validacion por sub tipo documentos
				List<Map<String, String>> serviciosPorSubTipoDocumentoAll =  catalogoAyudaService.getListaAsociado(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBTIPODOCU_SERVICIO, fechaReferencia);
				Map<String, List<Map<String, String>>> serviciosPorSubTipoDocumentoGroup = new HashMap<String, List<Map<String, String>>>();
				for (Map<String, String> item : serviciosPorSubTipoDocumentoAll) {
					String codigo = item.get("cod_datacat");
					List<Map<String, String>> serviciosExistente = serviciosPorSubTipoDocumentoGroup.get(codigo);
					if (serviciosExistente == null) {
						serviciosExistente = new ArrayList<Map<String, String>>();
						serviciosPorSubTipoDocumentoGroup.put(codigo, serviciosExistente);
					}
					serviciosExistente.add(item);
				}
				//fin

				//en otros metodos tambien requieren subtipos documentos agrupados por servicio (por cod_datacatasoc)
				Map<String, List<Map<String, String>>> subTiposDocumentoPorServicioGroup = new HashMap<String, List<Map<String, String>>>();
				for (Map<String, String> item : serviciosPorSubTipoDocumentoAll) {
					String codigo = item.get("cod_datacatasoc");
					List<Map<String, String>> subTiposExistente = subTiposDocumentoPorServicioGroup.get(codigo);
					if (subTiposExistente == null) {
						subTiposExistente = new ArrayList<Map<String, String>>();
						serviciosPorSubTipoDocumentoGroup.put(codigo, subTiposExistente);
					}
					subTiposExistente.add(item);
				}


				//String descripDocAutoriza = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_SUBTIPO_DOCAUTORIZA, docAutoriza.getCodsubtipodocum());
				List<Map<String, String>> elementosSubTipoDocumentoAutorizado = catalogoAyudaService.getElementosCat(ConstantesTipoCatalogo.CATALOGO_SUBTIPO_DOCAUTORIZA);

				//cargamos codigo subtipo documento de cada documento autorizado de las series
				cargarDocumentoAutorizadoPorSerie(declaracion, subTiposPorSubEntidadGroup, subTiposPorTipoDocumentoGroup, subEntidadesPorEntidadGroup, variablesDocumentoAutorizadoPorSerie, elementosSubTipoDocumentoAutorizado);
				//cargarDocumentoAutorizadoPorSerie(declaracion, subTiposPorSubEntidadGroup, subTiposPorTipoDocumentoGroup, subEntidadesPorEntidadGroup, variablesDocumentoAutorizadoPorSerie);
				cargarInformacionAdicionalDocumentoAutorizado(variablesDocumentoAutorizadoPorSerie, variablesIngreso);

				//se adiciona en el map variablesIngreso el map de variablesDocumentoAutorizadoPorSerie final
				variablesIngreso.put("variablesDocumentoAutorizadoPorSerie", variablesDocumentoAutorizadoPorSerie);
				variablesIngreso.put("serviciosPorSubTipoDocumentoGroup", serviciosPorSubTipoDocumentoGroup);
				variablesIngreso.put("subTiposPorSubEntidadGroup", subTiposPorSubEntidadGroup);
				variablesIngreso.put("subTiposDocumentoPorServicioGroup", subTiposDocumentoPorServicioGroup);
				variablesIngreso.put("tiposDocumentoPorSubTipoDocumentoGroup", tiposDocumentoPorSubTipoDocumentoGroup);
				//adicionamos los registros agrupados en variablesIngreso para posteriormente ser utilizado... evitando ejecutar mas querys a la base datos por cada documento autorizado
			}
		}
		Long tiempo_final = System.currentTimeMillis();
		System.out.println("Tiempo total en demora de carga: " + (tiempo_final-tiempo_inicial)/1000 +  " segundos" );
		return new HashMap<String, Object>();
	}
	//rtineo Inicio Optimizacion
	private void cargarInformacionAdicionalDocumentoAutorizado(Map<Integer, List<DatoDocAutorizante>> variablesDocumentoAutorizadoPorSerie, Map<String, Object> variablesIngreso) {
		StringBuilder documentosAutorizadosAll = new StringBuilder();
		List<String> documentosAutorizadosAdicionadosEnLista = new ArrayList<String>();
		for (Map.Entry<Integer, List<DatoDocAutorizante>> entry : variablesDocumentoAutorizadoPorSerie.entrySet()) {
			List<DatoDocAutorizante> documentosAutorizados = entry.getValue();
			for (DatoDocAutorizante documentoAutorizado : documentosAutorizados) {
				//formateamos los datos
				//logica copiada
				String anio = null;
				if (SunatStringUtils.length(documentoAutorizado.getAnndocum())>3){
					anio = documentoAutorizado.getAnndocum().substring(0,4);
				}else{
					anio = documentoAutorizado.getAnndocum();
				}
				//anio 4 caracteres
				anio = StringUtils.rightPad(anio, 2, " ");
				//codigo entidad 2 caracteres
				String codigoEntidad = StringUtils.rightPad(documentoAutorizado.getCodentidad(), 2, " ");
				//codigo tipo documento 2 caracteres
				String codigoTipoDocumento = StringUtils.rightPad(documentoAutorizado.getCodtipodocum(), 2, " ");
				//numero de documento 12 caracteres
				String numeroDocumento = StringUtils.rightPad(documentoAutorizado.getNumdocum(), 12, " ");
				//generamos el identificador
				String identificador = codigoEntidad + "-" + codigoTipoDocumento + "-" + numeroDocumento + "-" + anio;
				if (!documentosAutorizadosAdicionadosEnLista.contains(identificador)) {
					documentosAutorizadosAdicionadosEnLista.add(identificador);
					documentosAutorizadosAll.append(identificador).append(",");
				}
			}
		}
		//ejecutamos una sola consulta sobre la tabla CAB_MR_DOCAUTORIZ
		CabMrDocAutorizDAO cabMrDocAutorizDAO = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NUM_DOCUMENTO_LIST", documentosAutorizadosAll.toString());
		List<CabMrDocAutoriz> registros = cabMrDocAutorizDAO.listCabMrdocAutoriz(parametros);

		//agrupamos los registros obtenidos por documento autorizado... un documento autorizado puede sustentarse en distintas aduanas
		//tambien se requiere busqueda adicional por aduana... entonces tambien agrupamos por aduana
		Map<String, List<CabMrDocAutoriz>> grupo = new HashMap<String, List<CabMrDocAutoriz>>();
		Map<String, List<CabMrDocAutoriz>> grupoPorAduana = new HashMap<String, List<CabMrDocAutoriz>>();
		for (CabMrDocAutoriz registro : registros) {
			//agrupamos por codigoEntidad-correlativo-tipoDocumento-anio
			String identificador = registro.getCodiEntidad() + "-" + registro.getCcordoc() + "-" + registro.getCcoddoc() + "-" + registro.getAnodoc();
			List<CabMrDocAutoriz> registrosExistentes = grupo.get(identificador);
			if (registrosExistentes == null) {
				registrosExistentes = new ArrayList<CabMrDocAutoriz>();
				grupo.put(identificador, registrosExistentes);
			}
			registrosExistentes.add(registro);

			//agrupamos por codigoEntidad-correlativo-tipoDocumento-anio-aduana
			String identificadorPorAduana = registro.getCodiEntidad() + "-" + registro.getCcordoc() + "-" + registro.getCcoddoc() + "-" + registro.getAnodoc() + "-" + registro.getCodiAduan();
			List<CabMrDocAutoriz> registrosPorAduanaExistentes = grupoPorAduana.get(identificadorPorAduana);
			if (registrosPorAduanaExistentes == null) {
				registrosPorAduanaExistentes = new ArrayList<CabMrDocAutoriz>();
				grupoPorAduana.put(identificadorPorAduana, registrosPorAduanaExistentes);
			}
			registrosPorAduanaExistentes.add(registro);
		}
		variablesIngreso.put("grupoDocumentosAutorizados", grupo);
		variablesIngreso.put("grupoDocumentosAutorizadosPorAduana", grupoPorAduana);
	}


	private void cargarDocumentoAutorizadoPorSerie(Declaracion declaracion, Map<String, List<Map<String, String>>> subTiposPorSubEntidadGroup, Map<String, List<Map<String, String>>> subTiposPorTipoDocumentoGroup, 
			Map<String, List<Map<String, String>>> subEntidadesPorEntidadGroup, Map<Integer, List<DatoDocAutorizante>> variablesDocumentoAutorizadoPorSerie,List<Map<String, String>> elementosSubTipoDocumentoAutorizado) {

		for (DatoSerie serie : declaracion.getDua().getListSeries()) {

			List<DatoDocAutorizante> listDocAutorizaSerie = new ArrayList<DatoDocAutorizante>();
			List<String> listDocSoporteSerie = new ArrayList<String>();

			if (!CollectionUtils.isEmpty(serie.getListSerieDocSoporte())) {
				for (DatoSerieDocSoporte serieDoc : serie.getListSerieDocSoporte()) {
					if (serieDoc.getCodtipodocsoporte().equals(Constants.DOCUMENTO_AUTORIZACION)) {
						listDocSoporteSerie.add(serieDoc.getNumiddocsoporte().toString());
					}
				}
			}

			if (!CollectionUtils.isEmpty(listDocSoporteSerie) && !CollectionUtils.isEmpty(declaracion.getDua().getListDocAutorizantes())) {
				for (DatoDocAutorizante docAutoriza : declaracion.getDua().getListDocAutorizantes() ) {
					if(CollectionUtils.contains(listDocSoporteSerie.iterator(), docAutoriza.getNumsecdocum().toString())){
						listDocAutorizaSerie.add(docAutoriza);
					}
				}
			}

			for (DatoDocAutorizante docAutoriza : listDocAutorizaSerie) {
				//cargamos el indicador de tipo documento autorizado valido
				boolean entidadTipoDocumentoAutorizadoValido = isEntidadTipoDocumentoAutorizadoValido(docAutoriza, subEntidadesPorEntidadGroup, subTiposPorTipoDocumentoGroup, subTiposPorSubEntidadGroup);
				//seteamos el indicador
				docAutoriza.setEntidadTipoDocumentoAutorizadoValido(entidadTipoDocumentoAutorizadoValido);

				//obtenemos la descripcion del subtipodocumento
				for(Map<String, String> subTipoDocumentoAutorizado : elementosSubTipoDocumentoAutorizado){
					if(subTipoDocumentoAutorizado.get("cod_datacat").equals(docAutoriza.getCodsubtipodocum())){
						docAutoriza.setDescripcionSubTipoDocumentoAutorizado(subTipoDocumentoAutorizado.get("cod_datacat"));
						break;
					}
				}

				//continuamos con el resto de logica
				if (docAutoriza.getCodsubentidad() == null) {
					continue;
				}
				//Se excluye la subentidad 0801 MTC, por que ellos si mandan subtipodocumento
				if (docAutoriza.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_MTC01)) {
					continue;
				}
				List<Map<String, String>> lstSubTipoDocuPorSubEntidad =  subTiposPorSubEntidadGroup.get(docAutoriza.getCodsubentidad()== null ? "" : docAutoriza.getCodsubentidad());
				List<Map<String, String>> lstSubTipoDocuPorTipo =  subTiposPorTipoDocumentoGroup.get(docAutoriza.getCodtipodocum());
				String codSubTipoDocum = null;
				for (Map<String, String> subTipoDocuPorTipo : lstSubTipoDocuPorTipo) {	
					for (Map<String, String> subTipoDocuPorSubEntidad : lstSubTipoDocuPorSubEntidad) {
						if (subTipoDocuPorTipo.get("cod_datacat").equals(subTipoDocuPorSubEntidad.get("cod_datacat"))) {
							codSubTipoDocum = subTipoDocuPorTipo.get("cod_datacat");
							break;
						}
					}
				}
				//seteamos el sub tipo documento
				docAutoriza.setCodsubtipodocum(codSubTipoDocum);
			}
			//se adiciona en el map adicional la lista de documentos autorizados calculado para la serie
			variablesDocumentoAutorizadoPorSerie.put(serie.getNumserie(), listDocAutorizaSerie);
		}
	}

	private boolean isEntidadTipoDocumentoAutorizadoValido(DatoDocAutorizante documentoAutorizado, Map<String, List<Map<String, String>>> subEntidadesPorEntidadGroup, 
			Map<String, List<Map<String, String>>> subTiposPorTipoDocumentoGroup, Map<String, List<Map<String, String>>> subTiposPorSubEntidadGroup) {

		boolean indRetorna = true;

		if ( SunatStringUtils.isEmptyTrim(documentoAutorizado.getCodentidad()) || 
				SunatStringUtils.isEmptyTrim(documentoAutorizado.getCodtipodocum()) || 
				SunatStringUtils.isEmptyTrim(documentoAutorizado.getCodsubentidad()) || 
				documentoAutorizado.getCodtipodocum().equals(Constants.COD_EXONERACION) ||
				( documentoAutorizado.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) && 
						( documentoAutorizado.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_SENASA01) || 
								documentoAutorizado.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_SENASA03) ) ) ) {
			return false;
		}

		List<Map<String, String>> subEntidades = subEntidadesPorEntidadGroup.get(documentoAutorizado.getCodentidad());
		List<Map<String, String>> subTiposPorTipoDocumento = subTiposPorTipoDocumentoGroup.get(documentoAutorizado.getCodtipodocum());

		List<Map<String, String>> lstSubTipoDocuPorSubEntidad  = null;

		if (!documentoAutorizado.getCodsubentidad().isEmpty() && documentoAutorizado.getCodsubentidad() != null) {
			lstSubTipoDocuPorSubEntidad = subTiposPorSubEntidadGroup.get(documentoAutorizado.getCodsubentidad());
		} else {
			return false;
		}

		boolean indExisteAsociacion = false;

		for (Map<String, String> subEntidad : subEntidades){
			if (subEntidad.get("cod_datacat").equals(documentoAutorizado.getCodsubentidad())){
				indExisteAsociacion = true;
				break;
			}
		}

		if (!indExisteAsociacion) indRetorna = false;

		indExisteAsociacion = false;

		for (Map<String, String> subTipoDocuPorTipo : subTiposPorTipoDocumento){
			if (subTipoDocuPorTipo.get("cod_datacat").equals(documentoAutorizado.getCodsubtipodocum())){
				indExisteAsociacion = true;
				break;
			}
		}

		if (!indExisteAsociacion) indRetorna = false;


		indExisteAsociacion = false;

		for (Map<String, String> subTipoDocuPorSubEntidad : lstSubTipoDocuPorSubEntidad){
			if (subTipoDocuPorSubEntidad.get("cod_datacat").equals(documentoAutorizado.getCodsubtipodocum())){
				indExisteAsociacion = true;
				break;
			}
		}

		if (!indExisteAsociacion) indRetorna = false;

		return indRetorna;		
	}

	/**
	 * obtener la lista de subentidades
	 * @param codigoServicio
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<String> obtenerSubEntidadesPorServicio(String codigoServicio, Date fechaReferencia, Map<String, Object> variablesIngreso){
		Map<String, List<String>> subEntidadesPorServicio = (Map<String, List<String>>) variablesIngreso.get("subEntidadesPorServicio");
		//rtineo optimizacion verificamos si es que ya se creo anteriormente el map de subEntidadesPorServicio
		if (subEntidadesPorServicio == null) {
			//de no existir creamos el map
			subEntidadesPorServicio = new HashMap<String, List<String>>();
			variablesIngreso.put("subEntidadesPorServicio", subEntidadesPorServicio);
		}
		//obtenemos las subEntidades correspondientes al codigo de servicio 
		List<String> subEntidades = subEntidadesPorServicio.get(codigoServicio);
		if (subEntidades == null) {
			//entonces invocamos al metodo original que se encarga de hacer la logica pesada
			subEntidades = obtenerSubEntidadesPorServicio(codigoServicio, fechaReferencia);
			//adicionamos en el map subEntidadesPorServicio para que las siguientes invocaciones eviten ejecutar la consulta pesada
			subEntidadesPorServicio.put(codigoServicio, subEntidades);
		}
		return subEntidades;
	}

	// fin rtineo optimizacion

	@Override

	/**
	 * Realiza la consulta para validar si la DUA a rectificar tiene fecha de regularizaci�n y 
	 * adem�s si existe diferencias en la serie del XML con las series declaradas anteriormente, 
	 * asimismo verifica las diferencias para cada documento autorizante
	 * @param declaracion
	 * @param declaracionBD
	 * @param fechaReferencia
	 * @param variablesIngreso
	 */

	@ServicioAnnot(tipo="V",codServicio=9101, descServicio="Validar diferencias de documentos autorizantes")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","declaracionBD","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9101,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")

	public List<Map<String, String>> valDiferenciaSerieDocAutDuaConLevante(
			Declaracion declaracion, Declaracion declaracionBD,
			Date fechaReferencia, Map<String, Object> variablesIngreso)  {

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (declaracion.getDua().getNumcorredoc() == null) {
			return lstErrores;
		}

		//Date fecDefecto = SunatDateUtils.getDefaultDate(); //se comenta PAS20155E220000487 

		//Integer intFecDefecto = SunatDateUtils.getIntegerFromDate(SunatDateUtils.getDefaultDate()); //se comenta PAS20155E220000487 
		//Integer intFecAutLevante = SunatDateUtils.getIntegerFromDate(declaracionBD.getDua().getFecAutlevante()); //se comenta PAS20155E220000487 

		String codServicio = obtenerCodigoServicioAnotacion(this);

		if (declaracionBD == null || declaracionBD.getDua().getCodCanal() == null ||
				SunatStringUtils.isEmptyTrim(declaracionBD.getDua().getCodCanal()) ||
				//intFecDefecto.compareTo(intFecAutLevante) == 0 ||
				SunatDateUtils.isDefaultDate(declaracionBD.getDua().getFecAutlevante()) ||
				CollectionUtils.isEmpty(declaracionBD.getDua().getListSeries())){
			return lstErrores;
		}
		List<DatoSerie> lstSeriesBD = declaracionBD.getDua().getListSeries();

		//Incializamos la clase comparadora

		//PAS20155E220000487 - se comenta para hacer las comparaciones mas especificas de acuerdo a los casos
		/*Comparator<DatoDocAutorizante> docAutoCompara = new Comparator<DatoDocAutorizante>() {
            @Override
            public int compare(DatoDocAutorizante o1, DatoDocAutorizante o2) {
                if (o1.getCodentidad().equals(o2.getCodentidad()) && 
                	o1.getCodsubentidad().equals(o2.getCodsubentidad()) && 
                	o1.getCodsubtipodocum().equals(o2.getCodsubtipodocum()) && 
                	o1.getCodtipodocum().equals(o2.getCodtipodocum()) && 
                	o1.getNumdocum().equals(o2.getNumdocum()) && 
                	//o1.getAnndocum().equals(o2.getAnndocum()) && //BUG 24309-24326 - PAS20155E220000487
                	o1.getAnndocum().substring(0,4).equals(o2.getAnndocum()) && //BUG 24309-24326 - PAS20155E220000487
                	//o1.getFecemision().equals(o2.getFecemision()) && //BUG 24309-24326 - PAS20155E220000487
                	SunatDateUtils.sonIguales(o1.getFecemision(), o2.getFecemision(), SunatDateUtils.COMPARA_SOLO_FECHA) && //BUG 24309-24326 - PAS20155E220000487
                	o1.getNroitemdocum().equals(o2.getNroitemdocum()) ) return 0; else return -1; }
        };*/

		//PAS20155E220000487
		Comparator<DatoDocAutorizante> docAutoCompara1 = new Comparator<DatoDocAutorizante>() {
			@Override
			public int compare(DatoDocAutorizante o1, DatoDocAutorizante o2) {
				if (o1.getCodentidad().equals(o2.getCodentidad()) && 
						o1.getCodsubentidad().equals(o2.getCodsubentidad()) && 
						o1.getCodsubtipodocum().equals(o2.getCodsubtipodocum()) && 
						o1.getCodtipodocum().equals(o2.getCodtipodocum()) && 
						o1.getNumdocum().equals(o2.getNumdocum()) && 
						//o1.getAnndocum().equals(o2.getAnndocum()) && //BUG 24309-24326 - PAS20155E220000487
						o1.getAnndocum().substring(0,4).equals(o2.getAnndocum()) && //BUG 24309-24326 - PAS20155E220000487
						SunatDateUtils.sonIguales(o1.getFecvencimiento(), o2.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA) && //BUG 24458 (Vigencia) - PAS20155E220000487
						o1.getNroitemdocum().equals(o2.getNroitemdocum()) ) return 0; else return -1; }
		};

		//PAS20155E220000487
		Comparator<DatoDocAutorizante> docAutoCompara2 = new Comparator<DatoDocAutorizante>() {
			@Override
			public int compare(DatoDocAutorizante o1, DatoDocAutorizante o2) {
				if (o1.getCodentidad().equals(o2.getCodentidad()) && 
						o1.getCodsubentidad().equals(o2.getCodsubentidad()) && 
						o1.getCodsubtipodocum().equals(o2.getCodsubtipodocum()) && 
						o1.getCodtipodocum().equals(o2.getCodtipodocum()) && 
						o1.getNumdocum().equals(o2.getNumdocum()) && 
						//o1.getAnndocum().equals(o2.getAnndocum()) && //BUG 24309-24326 - PAS20155E220000487
						o1.getAnndocum().substring(0,4).equals(o2.getAnndocum()) && //BUG 24309-24326 - PAS20155E220000487
						SunatDateUtils.sonIguales(o1.getFecvencimiento(), o2.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA) && //BUG 24458 (Vigencia) - PAS20155E220000487
						o1.getNroitemdocum().equals(o2.getNroitemdocum()) ) return 0; else return -1; }
		};

		//PAS20155E220000487
		Comparator<DatoDocAutorizante> docAutoCompara3 = new Comparator<DatoDocAutorizante>() {
			@Override
			public int compare(DatoDocAutorizante o1, DatoDocAutorizante o2) {
				if (o1.getCodentidad().equals(o2.getCodentidad()) && 
						o1.getCodsubentidad().equals(o2.getCodsubentidad()) && 
						o1.getCodsubtipodocum().equals(o2.getCodsubtipodocum()) && 
						o1.getCodtipodocum().equals(o2.getCodtipodocum()) && 
						o1.getNumdocum().equals(o2.getNumdocum()) && 
						//o1.getAnndocum().equals(o2.getAnndocum()) && //BUG 24309-24326 - PAS20155E220000487
						o1.getAnndocum().substring(0,4).equals(o2.getAnndocum()) && //BUG 24309-24326 - PAS20155E220000487
						//o1.getFecemision().equals(o2.getFecemision()) && //BUG 24309-24326 - PAS20155E220000487
						SunatDateUtils.sonIguales(o1.getFecemision(), o2.getFecemision(), SunatDateUtils.COMPARA_SOLO_FECHA) && //BUG 24309-24326 - PAS20155E220000487
						SunatDateUtils.sonIguales(o1.getFecvencimiento(), o2.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA) && //BUG 24458 (Vigencia) - PAS20155E220000487
						o1.getNroitemdocum().equals(o2.getNroitemdocum()) ) return 0; else return -1; }
		};


		Comparator<DatoSerie> serieCompara = new Comparator<DatoSerie>() {
			@Override
			public int compare(DatoSerie o1, DatoSerie o2) {
				if (o1.getNumserie().equals(o2.getNumserie()) ) return 0; else return -1; }
		};        

		//PAS20155E220000487 - se comenta para hacer las comparaciones mas especificas de acuerdo a los casos
		/*Comparator<DatoSerie> serieComparaPartida = new Comparator<DatoSerie>() {
            @Override
            public int compare(DatoSerie o1, DatoSerie o2) {
                if (o1.getNumserie().equals(o2.getNumserie()) &&  
                	o1.getNumpartnandi().equals(o2.getNumpartnandi()) && 
                	o1.getCodunicomer().equals(o2.getCodunicomer()) && 
                	o1.getCntunicomer().compareTo(o2.getCntunicomer()) == 0 && 
                	o1.getCntpesoneto().compareTo(o2.getCntpesoneto()) == 0 ) return 0; else return -1; } //PAS20155E220000487
        };*/

		//PAS20155E220000487
		Comparator<DatoSerie> serieComparaPartida1 = new Comparator<DatoSerie>() {
			@Override
			public int compare(DatoSerie o1, DatoSerie o2) {
				if (o1.getNumserie().equals(o2.getNumserie()) &&  
						o1.getNumpartnandi().equals(o2.getNumpartnandi()) && 
						o1.getCodunicomer().equals(o2.getCodunicomer()) && 
						o1.getCntunicomer().compareTo(o2.getCntunicomer()) == 0 && 
						o1.getCntpesoneto().compareTo(o2.getCntpesoneto()) == 0 ) return 0; else return -1; } 
		};    

		//PAS20155E220000487
		Comparator<DatoSerie> serieComparaPartida2 = new Comparator<DatoSerie>() {
			@Override
			public int compare(DatoSerie o1, DatoSerie o2) {
				if (o1.getNumserie().equals(o2.getNumserie()) &&  
						o1.getNumpartnandi().equals(o2.getNumpartnandi()) ) return 0; else return -1; }
		};         


		/**Fin de cambios VUCE**/
		if(variablesIngreso.get("esTratamDonacion")==null){
			String codTipoTratamiento = declaracionBD.getDua().getCodtipotratamiento()==null ? "" : declaracionBD.getDua().getCodtipotratamiento();
			boolean tieneTratamientoDonacion=false; 
			if(codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO)){
				tieneTratamientoDonacion=true;
			}
			variablesIngreso.put("esTratamDonacion",tieneTratamientoDonacion);
		}
		/**Fin de cambios VUCE**/
		//Integer intFecRegulariza = SunatDateUtils.getIntegerFromDate(declaracionBD.getDua().getFecregulariza()); //se comenta PAS20155E220000487 

		for (DatoSerie serieBD : lstSeriesBD){
			//List<DatoDocAutorizante> listDocAutoBD = obtenerListaDocAutorizaSerie(serieBD,declaracionBD.getDua(),variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
			List<DatoDocAutorizante> listDocAutoBD = obtenerListaDocAutorizaSerie(serieBD,declaracionBD.getDua(),variablesIngreso,true); //BUG 24309-24326 - PAS20155E220000487
			if (!CollectionUtils.isEmpty(listDocAutoBD)){
				for (DatoDocAutorizante docAutoBD : listDocAutoBD){
					if (valServicioSubTipoDocAutoriza(codServicio, docAutoBD, fechaReferencia, variablesIngreso)){

						//PAS20155E220000487 - se hace las comparaciones mas especificas de acuerdo a los casos
						if(declaracionBD.getDua().getCodmodalidad().equals(Constants.DESPACHO_EXCEPCIONAL)){
							if (!verificarExisteError(lstErrores,"35378")){											 										 
								//Verifica si se realiz� alguna modificaci�n a los documentos
								boolean indExisteDocu = false;

								//List<DatoDocAutorizante> lstDocAuto = obtenerListaDocAutorizaSerie(serieBD,declaracion.getDua(),variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
								List<DatoDocAutorizante> lstDocAuto = obtenerListaDocAutorizaSerie(serieBD,declaracion.getDua(),variablesIngreso,false); //BUG 24309-24326 - PAS20155E220000487

								if (buscarObjeto(lstDocAuto, docAutoBD, docAutoCompara1) > -1 && buscarObjeto(declaracion.getDua().getListSeries(), serieBD, serieComparaPartida1) > -1 &&
										declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad().equals(declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad())) //BUG 24393 - PAS20155E220000487
									indExisteDocu = true;

								if (!indExisteDocu) {
									lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35378"
											, new String[] {serieBD.getNumserie().toString()}));
								}
							}
							//Verificar si se realiz� la eliminaci�n de la serie
							if (!verificarExisteError(lstErrores,"35379")){

								boolean indExisteSerie = false;

								if (buscarObjeto(declaracion.getDua().getListSeries(), serieBD, serieCompara) > -1)
									indExisteSerie = true;

								if (!indExisteSerie) {
									lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35379"
											, new String[] {serieBD.getNumserie().toString()}));
								}
							}									 

						}else if(SunatDateUtils.isDefaultDate(declaracionBD.getDua().getFecregulariza())) { //antes de la Regularizaci�n
							if((declaracionBD.getDua().getCodmodalidad().equals(Constants.DESPACHO_ANTICIPADO) || declaracionBD.getDua().getCodmodalidad().equals(Constants.DESPACHO_URGENTE)) &&
									!verificarExisteError(lstErrores,"35378")) {
								//Verifica si se realiz� alguna modificaci�n a los documentos
								boolean indExisteDocu = false;

								List<DatoDocAutorizante> lstDocAuto = obtenerListaDocAutorizaSerie(serieBD,declaracion.getDua(),variablesIngreso,false); 

								 /**Inicio adicionado por error 24 en docAutoCompara2 al buscar el item INC 2017-118469**/
								 for(DatoDocAutorizante docAuto : lstDocAuto){
									 if(docAuto.getCodentidad().equals(Constants.COD_ENTIDAD_DOCAUT_IQBF)){
										 if(docAuto.getNroitemdocum()==null || docAuto.getNroitemdocum()==0){
											 lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35403", new String[] {serieBD.getNumserie().toString()}));
										 }
									 }
								 }
								 if(!verificarExisteError(lstErrores,"35403")){
								 /**Fin adicionado por error 24 INC 2017-118469**/
								 
									 //Validar que no se cambie la partida, cantidad y/o peso de la serie
									 if (buscarObjeto(lstDocAuto, docAutoBD, docAutoCompara2) > -1 && buscarObjeto(declaracion.getDua().getListSeries(), serieBD, serieComparaPartida2) > -1){
											 indExisteDocu = true;
									 }		 
									 
									 if (!indExisteDocu) {
										 lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35378"
												 , new String[] {serieBD.getNumserie().toString()}));
									 }
								 }/***llave adicionada por error 24 INC 2017-118469***/
						 	}
					 }else if(!SunatDateUtils.isDefaultDate(declaracionBD.getDua().getFecregulariza())){ //con posterioridad a la Regularizaci�n 
						 if (!verificarExisteError(lstErrores,"35378")){											 										 
								//Verifica si se realiz� alguna modificaci�n a los documentos
								 boolean indExisteDocu = false;
								 
								 List<DatoDocAutorizante> lstDocAuto = obtenerListaDocAutorizaSerie(serieBD,declaracion.getDua(),variablesIngreso,false);
								 
								 /**Inicio adicionado por error 24 en docAutoCompara3 al buscar el item INC 2017-118469**/
								 for(DatoDocAutorizante docAuto : lstDocAuto){
									 if(docAuto.getCodentidad().equals(Constants.COD_ENTIDAD_DOCAUT_IQBF)){
										 if(docAuto.getNroitemdocum()==null || docAuto.getNroitemdocum()==0){
											 lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35403", new String[] {serieBD.getNumserie().toString()}));
										 }
									 }
								 }
								 if(!verificarExisteError(lstErrores,"35403")){
								 /**Fin adicionado por error 24 INC 2017-118469**/
								 
									 if (buscarObjeto(lstDocAuto, docAutoBD, docAutoCompara3) > -1 && buscarObjeto(declaracion.getDua().getListSeries(), serieBD, serieComparaPartida1) > -1 &&
											 declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad().equals(declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad())) 
										 indExisteDocu = true;
									 
									 if (!indExisteDocu) {
										 lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35378"
												 , new String[] {serieBD.getNumserie().toString()}));
									 }
								 }/***llave adicionada por error 24 INC 2017-118469***/
							  }
							//Verificar si se realiz� la eliminaci�n de la serie
							if (!verificarExisteError(lstErrores,"35379")){

								boolean indExisteSerie = false;

								if (buscarObjeto(declaracion.getDua().getListSeries(), serieBD, serieCompara) > -1)
									indExisteSerie = true;

								if (!indExisteSerie) {
									lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35379"
											, new String[] {serieBD.getNumserie().toString()}));
								}

							}									 

							variablesIngreso.put("indExcluyeIQBFDua",true);		
						}		 

						//PAS20155E220000487 - se comenta para hacer las comparaciones mas especificas de acuerdo a los casos
						/*
					 //if (declaracionBD.getDua().getFecregulariza().equals(fecDefecto) && //BUG 24309  - PAS20155E220000487
					 if(SunatDateUtils.isDefaultDate(declaracionBD.getDua().getFecregulariza()) && //BUG 24309  - PAS20155E220000487
					 //if(intFecRegulariza.compareTo(intFecDefecto) == 0 && //BUG 24309  - PAS20155E220000487
					     (declaracionBD.getDua().getCodmodalidad().equals(Constants.DESPACHO_URGENTE)||declaracionBD.getDua().getCodmodalidad().equals(Constants.DESPACHO_ANTICIPADO)) &&
					     !verificarExisteError(lstErrores,"35378")) {

						 //Verifica si se realiz� alguna modificaci�n a los documentos
						 boolean indExisteDocu = false;

						 //List<DatoDocAutorizante> lstDocAuto = obtenerListaDocAutorizaSerie(serieBD,declaracion.getDua(),variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
						 List<DatoDocAutorizante> lstDocAuto = obtenerListaDocAutorizaSerie(serieBD,declaracion.getDua(),variablesIngreso,false); //BUG 24309-24326 - PAS20155E220000487
						//Validar que no se cambie la partida, cantidad y/o peso de la serie
						 if (buscarObjeto(lstDocAuto, docAutoBD, docAutoCompara) > -1 && buscarObjeto(declaracion.getDua().getListSeries(), serieBD, serieComparaPartida) > -1){
								 indExisteDocu = true;
						 }		 

						 if (!indExisteDocu) {
							 lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35378"
									 , new String[] {serieBD.getNumserie().toString()}));
						 }

					 }
					 //if (!declaracionBD.getDua().getFecregulariza().equals(fecDefecto) || //BUG 24326 - PAS20155E220000487
					 if (!SunatDateUtils.isDefaultDate(declaracionBD.getDua().getFecregulariza()) || //BUG 24326 - PAS20155E220000487
						  declaracionBD.getDua().getCodmodalidad().equals(Constants.DESPACHO_EXCEPCIONAL)) {

						 if (!verificarExisteError(lstErrores,"35378")){											 										 
							//Verifica si se realiz� alguna modificaci�n a los documentos
							 boolean indExisteDocu = false;

							 //List<DatoDocAutorizante> lstDocAuto = obtenerListaDocAutorizaSerie(serieBD,declaracion.getDua(),variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
							 List<DatoDocAutorizante> lstDocAuto = obtenerListaDocAutorizaSerie(serieBD,declaracion.getDua(),variablesIngreso,false); //BUG 24309-24326 - PAS20155E220000487

							 if (buscarObjeto(lstDocAuto, docAutoBD, docAutoCompara) > -1 && buscarObjeto(declaracion.getDua().getListSeries(), serieBD, serieComparaPartida) > -1 &&
									 declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad().equals(declaracionBD.getDua().getDeclarante().getNumeroDocumentoIdentidad())) //BUG 24393 - PAS20155E220000487
								 indExisteDocu = true;

							 if (!indExisteDocu) {
								 lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35378"
										 , new String[] {serieBD.getNumserie().toString()}));
							 }
						  }
						 //Verificar si se realiz� la eliminaci�n de la serie
						 if (!verificarExisteError(lstErrores,"35379")){

							 boolean indExisteSerie = false;

							 if (buscarObjeto(declaracion.getDua().getListSeries(), serieBD, serieCompara) > -1)
								 indExisteSerie = true;

							 if (!indExisteSerie) {
								 lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35379"
										 , new String[] {serieBD.getNumserie().toString()}));
							 }

						 }									 

						 variablesIngreso.put("indExcluyeIQBFDua",true);										 

						 }*/									   								 
					}								 
				}
			}
		}		

		return lstErrores;
	}


	@Override
	/**
	 * Realizar validaciones para que el documento autorizante sea igual para todas las series de la declaraci�n y 
	 * que no se consigne un mismo �tem para m�s de una serie
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 */
	@ServicioAnnot(tipo="V",codServicio=9102, descServicio="Valida items de documento autorizante")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9102,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")	
	public List<Map<String, String>> validarItemDocAutoriza(Declaracion declaracion, Date fechaReferencia,
			Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer declaracion de variablesIngreso para casos de transaccion 04
		declaracion = obtenerDeclaracionReguAnticipado(declaracion,variablesIngreso);

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indExcluyeIQBFDua")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBFDua")){
				return lstErrores;
			}
		}

		String codServicio = obtenerCodigoServicioAnotacion(this);

		DatoDocAutorizante docAutoriza = null;
		Map<String, Object> mapDocItemSerie = new HashMap<String, Object> ();
		boolean indDocIQBFigual = true;
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		//Obtenemos la lista de las series
		List<DatoSerie> lstSeries = declaracion.getDua().getListSeries();


		/**Fin de cambios VUCE**/
		if(variablesIngreso.get("esTratamDonacion")==null){
			String codTipoTratamiento = declaracion.getDua().getCodtipotratamiento()==null ? "" : declaracion.getDua().getCodtipotratamiento();
			boolean tieneTratamientoDonacion=false; 
			if(codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO)){
				tieneTratamientoDonacion=true;
			}
			variablesIngreso.put("esTratamDonacion",tieneTratamientoDonacion);
		}
		/**Fin de cambios VUCE**/
		for (DatoSerie serie : lstSeries){

			//Se obtendr�n la lista de documentos autorizantes
			//List<DatoDocAutorizante> listDocAuto = obtenerListaDocAutorizaSerie(serie,declaracion.getDua(),variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
			List<DatoDocAutorizante> listDocAuto = obtenerListaDocAutorizaSerie(serie,declaracion.getDua(),variablesIngreso,false); //BUG 24309-24326 - PAS20155E220000487
			for (DatoDocAutorizante docAuto : listDocAuto){

				if (valServicioSubTipoDocAutoriza (codServicio,docAuto, fechaReferencia, variablesIngreso) && docAuto.getNroitemdocum()!=null){

					if (docAutoriza == null){
						docAutoriza = docAuto;
						mapDocItemSerie.put(docAuto.getNroitemdocum().toString(),serie.getNumserie());

					} else {

						if (docAutoriza.getCodentidad().equals(docAuto.getCodentidad()) && 
								docAutoriza.getCodsubentidad().equals(docAuto.getCodsubentidad()) && 
								docAutoriza.getCodsubtipodocum().equals(docAuto.getCodsubtipodocum()) && 
								docAutoriza.getCodtipodocum().equals(docAuto.getCodtipodocum()) && 
								docAutoriza.getNumdocum().equals(docAuto.getNumdocum()) && 
								docAutoriza.getAnndocum().equals(docAuto.getAnndocum()) &&
								docAutoriza.getFecemision().equals(docAuto.getFecemision())) {

							if (mapDocItemSerie.containsKey(docAuto.getNroitemdocum().toString())){
								lstErrores.add(catalogoAyudaService.getError("35366", 
										new String[] {docAuto.getNroitemdocum().toString(),mapDocItemSerie.get(docAuto.getNroitemdocum().toString()).toString()}));
							} else {
								mapDocItemSerie.put(docAuto.getNroitemdocum().toString(),serie.getNumserie());
							}
						} else {
							//	indDocIQBFigual = false;
							/* PAS20181U220200003
							 * R1172 RIN14: Asimismo el SEIDA valida que la Autorizaci�n IQBF debe ser la misma para todas las series de la declaraci�n,
							 *  caso contrario se rechaza indicando el siguiente mensaje: 
							 *  "Solo se debe transmitir una Autorizaci�n IQBF en todas las series para la declaraci�n".
							 */
							//el sistema no consideraba que pod�a ser un doc IQBF que amparara dos subentidades diferentes:
							if(docAutoriza.getCodentidad().equals(docAuto.getCodentidad()) && 
									docAutoriza.getCodtipodocum().equals(docAuto.getCodtipodocum()) && 
									docAutoriza.getNumdocum().equals(docAuto.getNumdocum()) && 
									docAutoriza.getAnndocum().equals(docAuto.getAnndocum()) &&
									docAutoriza.getFecemision().equals(docAuto.getFecemision())) {								
							}else{
								indDocIQBFigual = false;
							}
						}
					}				
				}
			}
		}

		if (!indDocIQBFigual && !CollectionUtils.isEmpty(mapDocItemSerie)){
			lstErrores.add(catalogoAyudaService.getError("35365"));
		}

		return lstErrores;
	}

	/***
	 * Factorizacion hecha por PAS20165E220200072
	 * tamano longitud de cadena a ingresar , rrecorremos cada posicion para ver si es digito, letra o caracter
	 * valor==2 indica que hay dos constantes ('.' , '/' , '-') consecutivas,valor==1 las constantes son diferentes
	 * caracter validamos si es caracter diferente de ('.' , '/' , '-') .
	 * @param numeroDocAutorizante
	 * @param numeroSerie
	 * @return
	 */
	public  List<Map<String, String>> validacionCaracteresNumeroDocControl(String numeroDocAutorizante, String numeroSerie){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		int tamano = numeroDocAutorizante.length();			   
		int valor = 0;
		char caracter;	
		int ind_error = 0 ;
		for(int i = 0; i<tamano; i++){				
			if(i==0){																
				if(numeroDocAutorizante.indexOf("-") == i || numeroDocAutorizante.indexOf(".") == i || numeroDocAutorizante.indexOf("/") == i){
					ind_error = 1;
					break;								
				}			
				if(!Character.isDigit(numeroDocAutorizante.charAt(i)) && !Character.isLetter(numeroDocAutorizante.charAt(i))){							
					caracter = numeroDocAutorizante.charAt(i);
					if(caracter != '-' || caracter != '.' || caracter != '/'){
						ind_error = 1;
						break;									
					}
				}						
			}else{
				if(i>1){
					if(numeroDocAutorizante.indexOf("-") == i || numeroDocAutorizante.indexOf(".") == i || numeroDocAutorizante.indexOf("/") == i){							
						valor = valor + 1;
						if(valor == 2){
							ind_error = 1;
							break;									
						}
					}
					else{
						valor = 0; 
					}						
					if(numeroDocAutorizante.indexOf("+") == i ){
						ind_error = 1;
						break;								
					}///PAS201830001100009
					if(numeroDocAutorizante.indexOf(".") == i ){
						ind_error = 1;
						break;								
					}///PAS201930001100002
				}
			}							 
		}
		if(ind_error == 1){
			listErrores.add(catalogoAyudaService.getError("35313", new String []{numeroSerie, numeroDocAutorizante.toString()}));
		}
		return listErrores;
	}

	/***
	 * Validacion de vigencia de Vuce solo por la fecha de referencia
	 * */
	public boolean esVigenteVucePorFecha(String codRegimen, Date fechaReferencia){
		boolean esVigenteVucePorFecha = false;  
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		//	    Map<String, Object> fechaHabilitacion= catalogoAyudaService.getElementoCat("380","0009","01",new Date());
		//	    Date fechaHabilVuce=SunatDateUtils.getDateFromUnknownFormat(MapUtils.getString(fechaHabilitacion, "fec_inidatcat", "31/12/9999"));//ajuste fecha

		Map<String, Object> atributoVigenciaRegimenVuce=catalogoAyudaService.getDataAtributo(
				ConstantesTipoCatalogo.CATALOGO_DE_FECHA_VIGENCIA_VUCE_REGIMEN,
				ConstantesTipoCatalogo.CATALOGO_GRUPO_REGIMENES_VUCE,
				ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO,
				codRegimen);

		Date fechaVigenciaPorRegimen = SunatDateUtils.getDateFromUnknownFormat(
				atributoVigenciaRegimenVuce.get("val_atributo") == null ? "31/12/9999" : atributoVigenciaRegimenVuce.get("val_atributo").toString());

		if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fechaVigenciaPorRegimen, SunatDateUtils.COMPARA_SOLO_FECHA)){
			esVigenteVucePorFecha=true; 
		}

		return esVigenteVucePorFecha;
	}

	/***
	 * Validacion de vigencia de Vuce cuando hay documento 
	 * */
	public boolean esVigenteVucePorSubentidad(DatoDocAutorizante docAutorizante, Date fechaReferencia, boolean esVigenteVucePorFecha, Map<String, Object> variablesIngreso){
		boolean esVigenteVucePorSubentidad = false;  
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		String valAtributoFecha=" "; 
		String codSubEntidad="";
		String codigoSubEntidadVuce=" ";
		String cutVuce =" ";
		DataGrupoCat catalogo = null;
		if(docAutorizante!=null){
			codSubEntidad=docAutorizante.getCodsubentidad()==null ? "" : docAutorizante.getCodsubentidad().toString(); 

			try {
				DocControlMercRestringidaVuce docControlMercRestringidaVuce= obtenerDocumentoVuce(SunatNumberUtils.toLong(docAutorizante.getNumdocum()), docAutorizante.getCodtipodocum());
				if(docControlMercRestringidaVuce!=null){
					codigoSubEntidadVuce=docControlMercRestringidaVuce.getSubEntidad()==null?"":docControlMercRestringidaVuce.getSubEntidad().toString();
					cutVuce = docControlMercRestringidaVuce.getNumeroCUT()==null?"":docControlMercRestringidaVuce.getNumeroCUT().toString();//adicionado VUCE RECTI
				}
			} catch (Exception e){
				log.error("ERROR obtenerTipoValidacionDocumentoAutorizante:", e);
			}

			if(SunatStringUtils.isEmptyTrim(codSubEntidad)){
				codSubEntidad=codigoSubEntidadVuce;
			}

			List<MRestri> lstMrestri = variablesIngreso.get("listMercRestringida") != null ? (List<MRestri>) variablesIngreso.get("listMercRestringida") : null;

			if(SunatStringUtils.isEmptyTrim(codSubEntidad)){
				List<String> listSuEntidadesCut= obtenerSubentidadesPorCut(cutVuce, fechaReferencia);
				codSubEntidad = obtenerRegistroPorCut( listSuEntidadesCut, obtenerRegistrosMrestri(lstMrestri));
			}

			catalogo = catalogoAyudaService.getDataGrupoCat("942", codSubEntidad);
			if(catalogo!=null){
				Map<String, Object> atributosEntidadesVuce=catalogoAyudaService.getDataAtributo(
						ConstantesTipoCatalogo.CATALOGO_DE_DATOS_SUBENTIDAD,
						ConstantesTipoCatalogo.CATALOGO_DE_FECHA_VIGENCIA_VUCE, 
						ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA,codSubEntidad);
				valAtributoFecha = atributosEntidadesVuce.get("val_atributo") == null ? null:atributosEntidadesVuce.get("val_atributo").toString();
			}
		}

		if(docAutorizante!=null && (docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO)||docAutorizante.getCodtipodocum().equals(SOLICITUD_SUCE)) && catalogo!=null){
			esVigenteVucePorSubentidad=true;            
		} else {
			if(esVigenteVucePorFecha){
				Date fechaExigVuce1=valAtributoFecha!=null?SunatDateUtils.getDateFromUnknownFormat(valAtributoFecha):null;
				if(fechaExigVuce1!=null && docAutorizante!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(docAutorizante.getFecemision(),fechaExigVuce1, SunatDateUtils.COMPARA_SOLO_FECHA)){
					boolean codTipoTratamientoDonacion=variablesIngreso.get("esTratamDonacion")!=null?(Boolean)variablesIngreso.get("esTratamDonacion"):false;		                    	          		

					if(codTipoTratamientoDonacion && (catalogoAyudaService.getDataGrupoCat("946", codSubEntidad)!=null)){
						esVigenteVucePorSubentidad=true;
					} else {
						if((catalogoAyudaService.getDataGrupoCat("947", codSubEntidad)!=null) &&  (SunatStringUtils.isStringInList(codSubEntidad, "0401"))){
							esVigenteVucePorSubentidad=true;
						} else {
							esVigenteVucePorSubentidad=true;
						}  
					} 
				} else {
					esVigenteVucePorSubentidad=false;
				}      
			}
		}

		return esVigenteVucePorSubentidad;
	}


	public List<Map<String, String>> validarMercanciaRestringidaRIN14(DatoSerie serie, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		listErrores.addAll(validarSubEntidadesDocAutorizaPrecedente(serie, variablesIngreso));
		boolean indExcluyeBienesFisca =false ; 
		if (variablesIngreso.containsKey("indExcluyeIQBF")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBF")){
				//return listErrores;
				indExcluyeBienesFisca = true;
			}
		}

		if (variablesIngreso.containsKey("indExcluyeDIQBF")){
			if ((Boolean) variablesIngreso.get("indExcluyeDIQBF")){
				//return listErrores;
				indExcluyeBienesFisca = true;
			}			
		}

		if (variablesIngreso.containsKey("indExcluyeSENASA01")){
			if ((Boolean) variablesIngreso.get("indExcluyeSENASA01")){
				//return listErrores;
				indExcluyeBienesFisca = true;
			}			
		}

		DUA dua = (DUA)serie.getPadre();
		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		Date fechaReferencia = SunatDateUtils.getCurrentDate();
		List<MRestri> lstMrestri = obtenerListaMercRestringida(serie, fechaReferencia, variablesIngreso);
		//List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, dua,variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
		List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, dua,variablesIngreso, false); //BUG 24309-24326 - PAS20155E220000487

		variablesIngreso.put("lstDocAutoriza", lstDocAutoriza);

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {

			codTransaccion = (String)variablesIngreso.get("codTransaccion");
		}
		/**Inicio ajustes PAS20155E220200168**/
		boolean esReguAnt = false ; 
		if(codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION)){
			esReguAnt=true;
		}
		/**Fin ajustes PAS20155E220200168**/

		//Obtiene el indicador R (Obliga a la transmisi�n de doc. control autorizante)
		String codTipoExoneracion  = serie.getMercancia()==null ? "" : serie.getMercancia().getCodtipoexoneracion()==null ? "" : serie.getMercancia().getCodtipoexoneracion();
		codTipoExoneracion = codTipoExoneracion.trim();
		if (indExcluyeBienesFisca && codTipoExoneracion.equals(Constants.COD_TIPO_EXONERACION) && lstMrestri.isEmpty()){
			codTipoExoneracion = "";
		}

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia()==null ? "" : serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		//Obtiene el c�digo de tipo de tratamiento
		String codTipoTratamiento = dua.getCodtipotratamiento()==null ? "" : dua.getCodtipotratamiento();

		//Obtiene una lista de indicadores asociados a la DUA
		List<DatoIndicadores> lstIndDua = dua.getListIndicadores()==null ? new ArrayList<DatoIndicadores>() : dua.getListIndicadores();

		List<String> lstCodSubEntidad = new ArrayList<String>();
		List<String> lstCodEntidad = new ArrayList<String>();

		boolean indImpugnada = false;
		/* Si la declaraci�n se encuentra sujeta a donaci�n (tipo 04) 
		 * impugnada (impugnaci�n Parcial � indicador 06, o impugnaci�n Total � indicador 07), 
		 * no aplicar�n las verificaciones de mercanc�a restringida)
		 */
		for (DatoIndicadores datoIndicadores : lstIndDua) {
			//P46 EJHM evaluar que el dato no llegue nulo ya q enviaron el tag pero no contenido
			if (datoIndicadores.getCodtipoindica()!=null &&( datoIndicadores.getCodtipoindica().equals(Constants.IND_IMPUGNACION_PARCIAL) ||
					datoIndicadores.getCodtipoindica().equals(Constants.IND_IMPUGNACION_TOTAL))) {
				indImpugnada = true;
				break;
			}
		}

		variablesIngreso.put("indImpugnada", indImpugnada);

		if (codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) && indImpugnada ==true){
			variablesIngreso.put("indValMrestri", false);
			return listErrores;
		}

		/**Inicio de cambios arey PAS20155E220200010**/
		boolean tieneTratamientoDonacion=false; 

		if(codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO)){
			tieneTratamientoDonacion=true;
		}
		variablesIngreso.put("esTratamDonacion",tieneTratamientoDonacion);
		/**Fin de cambios**/

		/*
		if ( !(Boolean)variablesIngreso.get("indValMrestri") ) {
			return listErrores;
		}
		 */
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		//se comenta pq no se usa - PAS20155E220000487
		/*Comparator<DatoDocAutorizante> docAutCom = new Comparator<DatoDocAutorizante>() {
            @Override
            public int compare(DatoDocAutorizante o1, DatoDocAutorizante o2) {
                if ( o1.getCodentidad().trim().equals(o2.getCodentidad().trim()) ) return 0; else return -1; }
        };*/
		Comparator<MRestri> mrestriCom01 = new Comparator<MRestri>() {
			@Override
			public int compare(MRestri o1, MRestri o2) {
				if ( o1.getEntidad().trim().equals(o2.getEntidad().trim()) ) return 0; else return -1; }
		};
		Comparator<MRestri> mrestriCom02 = new Comparator<MRestri>() {
			@Override
			public int compare(MRestri o1, MRestri o2) {
				if ( o1.getEntidad().trim().equals(o2.getEntidad().trim()) && 
						o1.getRegistro().trim().equals(o2.getRegistro().trim()) ){
					return 0; 
				}else{ return -1;}
			}
		};
		//PAS20155E220000487
		Comparator<MRestri> mrestriCom03 = new Comparator<MRestri>() {
			@Override
			public int compare(MRestri o1, MRestri o2) {
				if ( o1.getEntidad().trim().equals(o2.getEntidad().trim()) && 
						o1.getRegistro().trim().equals(o2.getRegistro().trim()) &&
						StringUtils.leftPad(o1.getTipodoc().trim(), 2, '0').equals(o2.getTipodoc().trim())){
					return 0; 
				}else{ return -1;}
			}
		};

		boolean indRestringida = false;
		boolean indCodExo98 = true;
		for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {

			docAutorizante.setCodentidad(docAutorizante.getCodentidad()==null ? "" : docAutorizante.getCodentidad());
			docAutorizante.setCodsubentidad(docAutorizante.getCodsubentidad()==null ? "" : docAutorizante.getCodsubentidad());
			docAutorizante.setCodtipodocum(docAutorizante.getCodtipodocum()==null ? "" : docAutorizante.getCodtipodocum());

			if ( !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) && !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) ) {
				indRestringida = true;
			}
			if (!docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION)){
				indCodExo98 = false;
			}
			if (docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && !esReguAnt) {
				for (DatoDocAutorizante docAutorizanteAux : lstDocAutoriza) {
					if ( docAutorizante.getCodentidad().equals(docAutorizanteAux.getCodentidad()) &&
							!docAutorizanteAux.getCodtipodocum().equals(Constants.COD_EXONERACION)	) {
						/* No se puede transmitir  el documento de control autorizante y a la vez declarar
						 * el c�digo de exoneraci�n 98 para una misma entidad*/
						listErrores.add(catalogoAyudaService.getError("35303", new String []{serie.getNumserie().toString()}));
						break;
					}
				}
			}
		}
		/*El usuario transmiti� los datos del documento de control autorizante pero 
		 * no transmiti� el indicador "R" de mercanc�a restringida en los datos de la serie respectiva*/
		if (indRestringida && codTipoExoneracion.isEmpty() && !esReguAnt) {
			listErrores.add(catalogoAyudaService.getError("35300", new String[] {serie.getNumserie().toString()}));
		}

		/*Si se transmitio el indicador R no debe declararse el c�digo de exoneracion 98 en todas las entidades*/
		if (!CollectionUtils.isEmpty(lstDocAutoriza) && indCodExo98 && !codTipoExoneracion.isEmpty() && !indExcluyeBienesFisca && !esReguAnt) {
			listErrores.add(catalogoAyudaService.getError("35302", new String []{serie.getNumserie().toString()}));
		}

		//MRestri mrestriParam1 = new MRestri();


		lstCodEntidad.clear(); 
		/* Si la mercancia no es restringida (No se envia el indicador R) pero la partida se encuentra registrada en el MRESTRI
		 * entonces se validar� que se haya transmitido el c�digo 98 de exoneraci�n por cada entidad*/
		if (!CollectionUtils.isEmpty(lstMrestri)) 
		{
			//PAS20155E220000371
			Map<String,Object> mapDocAutorizPreceDeposito = (Map<String, Object>) variablesIngreso.get("mapDocAutorizPreceDeposito");
			List<Map<String,Object>> lstDocAutorizPreceDeposito = (List<Map<String, Object>>) mapDocAutorizPreceDeposito.get("lstDocAutorizPreceDeposito"); //se saca sin evaluar x la serie pq se setea en este mismo metodo 

			for (MRestri mrestri : lstMrestri) {
				if (!lstCodEntidad.contains(mrestri.getEntidad()) && !mrestri.getCprod().equals(Constants.COD_PRODUCTO) ) {
					if (CollectionUtils.isEmpty(lstDocAutoriza)) {
						listErrores.add(catalogoAyudaService.getError("35301", new String []{serie.getNumserie().toString(),mrestri.getEntidad()}));
					}else{
						boolean indReqDocAut = true;
						boolean indCodExoRegPrece = false; //PAS20155E220300013
						for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {
							//if (docAutorizante.getCodentidad().equals(mrestri.getEntidad()) || docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION)) { //PAS20155E220300013
							if (docAutorizante.getCodentidad().equals(mrestri.getEntidad())){ //PAS20155E220300013
								/*Inicio de cambios por PAS20155E220000306 - SAU201510002000033
	    	        			Si envia codigo de exoneracion en la Declaracion, el regimen precedente si esta en SIGAD 
	    	        			debe tener documento de autorizacion aceptado o codigo de exoneracion, sino rechaza la Declaracion enviada.*/	    	        					    	        		

								//PAS20155E220000371
								//Para DAM 10 (con r�gimen precedente)  cuente con exoneraci�n 98;
								//Se verificar� que la declaraci�n de precedencia no haya documento de control para la entidad � est� exonerado con c�digo 98 para la entidad, 
								//de lo contrario  se rechazar�  la exoneraci�n de la declaraci�n 
								//if(docAutorizante.getCodentidad().equals(Constants.COD_EXONERACION) || docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION)){
								//if (docAutorizante.getCodentidad().equals(mrestri.getEntidad()) && docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION)){ //PAS20155E220300013
								if(docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION)){
									if(!CollectionUtils.isEmpty(lstDocAutorizPreceDeposito)){
										//hay documento de control autorizante precedente
										for(Map<String,Object> docAutorizantePrece : lstDocAutorizPreceDeposito){
											//las validaciones son para la entidad
											if(docAutorizante.getCodentidad().equals(docAutorizantePrece.get("CODI_ENTI"))){ //hay documento autorizante para la entidad
												if(!Constants.COD_EXONERACION.equals(docAutorizantePrece.get("CODI_DOCUM"))){ //que este exonerado con c�digo 98 para la entidad 
													indCodExoRegPrece = true;
												}else{
													indCodExoRegPrece = false;
													break;
												}
											}
										}
									}
								}	
								/*Fin de cambios por PAS20155E220000306 - SAU201510002000033*/
								indReqDocAut = false; 
								break;
							} //PAS20155E220300013

							/**Inicio Ajustes por VUCE PAS20155E220200195**/
							//se comenta por que es una validacion general de la RIN 14 PARA QUE SE CUMPLA LA REGLA 35301
							//	    					else{
							//	    						String tipoValidacion= " ";
							//	    						tipoValidacion=obtenerTipoValidacionDocumentoAutorizante(docAutorizante,fechaReferencia,variablesIngreso);
							//	    						if(tipoValidacion.equals("vuce") && SunatStringUtils.isEmptyTrim(docAutorizante.getCodentidad())){
							//	    							indReqDocAut=false;
							//	    							//break;//no considera mandatoriedad de la casilla de codigo de entidad, se evalua en validarMercanciaRestringidaPorSerie
							//	    						}
							//	    					}
							/**Fin Ajustes por VUCE PAS20155E220200195**/
						}
						
						if(SunatStringUtils.include(codTransaccion.substring(2,4), new String[] { "04" })){
							indReqDocAut=false;
						}

						if(indReqDocAut){  //PAS201830001100009
							listErrores.add(catalogoAyudaService.getError("35301", new String []{serie.getNumserie().toString(),mrestri.getEntidad()}));
						}
						//se comenta a solicitud de beatriz campo, solo debe mostrar este mensaje
						//si no envia documentos autorizantes
						//	    				if (indReqDocAut) {//mrestri TRX04 llega solo con iqbf y debe estar transmitido
						//		        			listErrores.add(catalogoAyudaService.getError("35301", new String []{serie.getNumserie().toString(),mrestri.getEntidad()}));
						//						}
						//PAS20155E220300013
						if((indCodExoRegPrece && !esReguAnt) || (indCodExoRegPrece && esReguAnt && mrestri.getEntidad().equals(Constants.COD_ENTIDAD_DOCAUT_IQBF))){//PAS20155E220200168 
							listErrores.add(catalogoAyudaService.getError("35574", new String []{serie.getNumserie().toString(), mrestri.getEntidad().toString()}));
						}
					}
					lstCodEntidad.add(mrestri.getEntidad());
				}	
				//PAS20155E220300001 - se agrega de lineas abajo con la modificacion para que arroje error cuando existe CPROD 00 
				//y si ha enviado doc autorizante pero para otras entidades que no es la del CPROD 00 
				/*SPN transmitido es restringido y tiene c�digo de producto (CPROD) �00� 
				 *en el r�gimen correspondiente, y se transmiti� el c�digo 98*/
				if (Constants.COD_PRODUCTO.equals(mrestri.getCprod())){
					boolean hasDocAutoriza = false;

					if (!CollectionUtils.isEmpty(lstDocAutoriza)) {
						for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {
							if (docAutorizante.getCodentidad().equals(mrestri.getEntidad()) && 
									docAutorizante.getCodsubentidad().equals(mrestri.getRegistro())){
								if(!docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION)){
									hasDocAutoriza = true;
								}
								break;	
							}
						}
					}
					// si es Trx04 debe dejar pasar PAS20155E22020015 y no valida
					if(SunatStringUtils.include(codTransaccion.substring(2,4), new String[] { "04" })){
						hasDocAutoriza=true;
					}

					if(!hasDocAutoriza){
						listErrores.add(catalogoAyudaService.getError("35305", new String []{serie.getNumserie().toString(), mrestri.getEntidad(), mrestri.getRegistro()})); //SAU201510002000126(PAS20155E220300013)
					}
				}
			}

			//PAS20155E220300001 - se comento para agregar lineas arriba, con la modificacion para que arroje error cuando existe CPROD 00 
			//y si se ha enviado doc autorizante pero para otras entidades que no es la del CPROD 00 
			/*for (MRestri mrestri : lstMrestri) {
				//SPN transmitido es restringido y tiene c�digo de producto (CPROD) �00� 
				 //en el r�gimen correspondiente, y se transmiti� el c�digo 98
		        if (mrestri.getCprod().equals(Constants.COD_PRODUCTO)){
		        	if (CollectionUtils.isEmpty(lstDocAutoriza)) {
		        		listErrores.add(catalogoAyudaService.getError("35305", new String []{serie.getNumserie().toString()}));
		        		continue;
		        	}

		        	for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {
						if ( docAutorizante.getCodentidad().equals(mrestri.getEntidad()) && 
							 docAutorizante.getCodsubentidad().equals(mrestri.getRegistro()) &&
							 docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) ) 
						{
							listErrores.add(catalogoAyudaService.getError("35305", new String []{serie.getNumserie().toString()}));
							break;
						}
					}
		        }	
			}*/
		}

		/* Las validaciones de los datos de documentos de control autorizante
		 * se efectuar�n de acuerdo a lo registrado en el cat�logo de Mercanc�as 
		 * Restringidas y sus cat�logos respectivos*/
		List<String> lstCodTipoDoc = new ArrayList<String>();
		lstCodEntidad.clear();
		lstCodSubEntidad.clear();

		if (!CollectionUtils.isEmpty(lstMrestri)) 
		{	
			for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {

				/***Inicio cambios VUCE***/	
				String tipoValidacion= " ";
				tipoValidacion=obtenerTipoValidacionDocumentoAutorizante(docAutorizante,fechaReferencia,variablesIngreso, dua.getCodregimen());
				/***Fin cambios VUCE***/				

				if (!lstCodEntidad.contains(docAutorizante.getCodentidad())) {

					docAutorizante.setCodentidad(docAutorizante.getCodentidad()==null ? "" : docAutorizante.getCodentidad());

					//se refactoriza por ordenamiento para facilitar gestion de VUCE:
					listErrores.addAll(validarEntidadRin14(serie, docAutorizante,lstMrestri,mrestriCom01,codTransaccion,tipoValidacion));  
					/*** REFACTORIZADO
					//DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_ENTIDADES_DOCAUTORIZA, docAutorizante.getCodentidad()); //PAS20155E220000487 no usa cache
					Map<String, Object> dataCatalogo = catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_ENTIDADES_DOCAUTORIZA, docAutorizante.getCodentidad()); //PAS20155E220000487 usa cache
					if ( dataCatalogo == null ){ 
						listErrores.add(catalogoAyudaService.getError("35308", new String []{serie.getNumserie().toString(),docAutorizante.getCodentidad()}));
					}
					MRestri mrestriParam = new MRestri();
					mrestriParam.setEntidad(docAutorizante.getCodentidad());
					if (buscarObjeto(lstMrestri, mrestriParam, mrestriCom01) == -1 && !codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION) ){
						listErrores.add(catalogoAyudaService.getError("35309", new String []{serie.getNumserie().toString(),docAutorizante.getCodentidad()}));
					}***/
					lstCodEntidad.add(docAutorizante.getCodentidad());
				}

				/* JLUNAH INICIO
				 * PAS20155E220000371 - RIN14 FSW SE AGREGO LA VALIDACION QUE ANTES ESTABA LINEAS ABAJO
				 * */

				//Valida aduana 
				//hCastillo mail 23/09/2015 
				//gg vuce solo se exonera si es codigo 80 y subentidad 0501, 0503
				if ((docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) && SunatStringUtils.isStringInList(docAutorizante.getCodsubentidad(),Constants.COD_SUBENTIDAD_SENASA01,Constants.COD_SUBENTIDAD_SENASA03)) 
						|| docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && !docAutorizante.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_DIQPF03)) {

					//if ( (docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) || docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && !docAutorizante.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_DIQPF03) ) ) {
					continue;
				}
				if ( docAutorizante.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_DIGESA02) && !dua.getCodaduanaorden().equals(Constants.COD_ADUANA_MARITIMA_CALLAO) ) {
					if (!verificarExisteError(listErrores,"35326") && !esReguAnt){//PAS20155E220200168
						listErrores.add(catalogoAyudaService.getError("35326", new String []{serie.getNumserie().toString()}));
					}					
				}


				/* JLUNAH FIN*/
				boolean existeSubEntidad = false;
				boolean isNuevoSubTipoDocumento = false;
				if (!lstCodSubEntidad.contains(docAutorizante.getCodsubentidad())) {
					docAutorizante.setCodsubentidad(docAutorizante.getCodsubentidad()==null ? "" : docAutorizante.getCodsubentidad());

					if(!tipoValidacion.equals("vuce")){//RIN14	

						//DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA, docAutorizante.getCodsubentidad()); //PAS20155E220000487 no usa cache
						Map<String, Object> mapDataCatalogo = catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA, docAutorizante.getCodsubentidad()); //PAS20155E220000487 usa cache
						//PAS20155E220000487 - replica mrestri (SUBENTIDAD) a datacatalogo 
						if (!CollectionUtils.isEmpty(mapDataCatalogo)) { //existe en datacatalogo
							//se verifica que subentidad exista en lstMrestri
							MRestri mrestriParam = new MRestri();
							mrestriParam.setEntidad(docAutorizante.getCodentidad());
							mrestriParam.setRegistro(docAutorizante.getCodsubentidad());
							if (buscarObjeto(lstMrestri, mrestriParam, mrestriCom02) > -1){ //existe en lstMrestri
								existeSubEntidad = true;
							}else{ //no existe en lstMrestri 
								if(!esReguAnt)//PAS20155E220200168
									listErrores.add(catalogoAyudaService.getError("35311", new String []{serie.getNumserie().toString(),docAutorizante.getCodsubentidad(), mrestriParam.getEntidad()}));
							}
						} else { //No existe el datacatalogo de SUBENTIDAD
							//Buscamos si esta en mrestri
							MRestri mrestriParam = new MRestri();
							mrestriParam.setEntidad(docAutorizante.getCodentidad());
							mrestriParam.setRegistro(docAutorizante.getCodsubentidad());
							if (buscarObjeto(lstMrestri, mrestriParam, mrestriCom02) > -1){ //existe en lstMrestri
								//No existe en BD pero si esta en mrestri, se registra en datacatalogo SUBENTIDAD
								existeSubEntidad = this.replicarDataCatalogo(ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA, docAutorizante.getCodsubentidad(), docAutorizante.getCodsubentidad()); //descripcion ???

								if(existeSubEntidad){
									isNuevoSubTipoDocumento = true;
								}else{ //no existe en datacatalogo 
									listErrores.add(catalogoAyudaService.getError("35310", new String []{serie.getNumserie().toString(), docAutorizante.getCodsubentidad()}));
								}
							}else{//no existe en el datacatalogo y no existe en lstMrestri  
								if(!esReguAnt){//PAS20155E220200168
									listErrores.add(catalogoAyudaService.getError("35310", new String []{serie.getNumserie().toString(), docAutorizante.getCodsubentidad()}));
									listErrores.add(catalogoAyudaService.getError("35311", new String []{serie.getNumserie().toString(),docAutorizante.getCodsubentidad(), mrestriParam.getEntidad()}));
								}
							}
						}

						//PAS20155E220000487 - se busca el elemento (subentidad) especifico
						Map<String, Object> mapSubEntidad = catalogoAyudaService.getElementoAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_ENTIDAD_SUBENTIDAD, docAutorizante.getCodentidad(), docAutorizante.getCodsubentidad());
						boolean existeEntidadSubEntidad = false;

						if(!CollectionUtils.isEmpty(mapSubEntidad)){
							existeEntidadSubEntidad = true;
						}else{
							//No existe asociacion
							//Si se registro en dataCatalogo registramos la ASOCIACION ENTIDAD CON SUBENTIDAD
							if(existeSubEntidad &&  (docAutorizante.getCodsubentidad().substring(0,2).equals(docAutorizante.getCodentidad()))){//P_SNADE046-2098 sin este filtro inserta a ciegas lo que manda el usuario
								existeEntidadSubEntidad = this.replicarDataCatAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_ENTIDAD_SUBENTIDAD, 
										ConstantesTipoCatalogo.CATALOGO_ENTIDADES_DOCAUTORIZA, docAutorizante.getCodentidad(), 
										ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA, docAutorizante.getCodsubentidad());
							}
						}

						if (!existeEntidadSubEntidad){
							listErrores.add(catalogoAyudaService.getError("35311", new String []{serie.getNumserie().toString(),docAutorizante.getCodsubentidad(), docAutorizante.getCodentidad()}));
						}

					}//fin if ajuste vuce
					lstCodSubEntidad.add(docAutorizante.getCodsubentidad());
				}	


				if (!lstCodTipoDoc.contains(docAutorizante.getCodtipodocum()) && !tipoValidacion.equals("vuce")){//RIN14 P_SNADE046-2098
					docAutorizante.setCodtipodocum(docAutorizante.getCodtipodocum()==null ? "" : StringUtils.leftPad(docAutorizante.getCodtipodocum().trim(), 2, '0')); //se registra con dos digitos
					//DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_DOCUMENTO_AUTORIZANTE, docAutorizante.getCodtipodocum()); //PAS20155E220000487 no usa cache
					Map<String, Object> mapDataCatalogo = catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_TIPO_DOCUMENTO_AUTORIZANTE, docAutorizante.getCodtipodocum()); //PAS20155E220000487 usa cache
					//PAS20155E220000487 - replica mrestri (TIPODOCUMENTO) a datacatalogo 
					boolean existeTipoDocumento = false;

					if(!CollectionUtils.isEmpty(mapDataCatalogo)){
						existeTipoDocumento = true;
					}else{
						if(existeSubEntidad){
							//No existe el datacatalogo de TIPODOCUMENTO
							//Buscamos si esta en mrestri
							MRestri mrestriParam = new MRestri();
							mrestriParam.setEntidad(docAutorizante.getCodentidad());
							mrestriParam.setRegistro(docAutorizante.getCodsubentidad());
							mrestriParam.setTipodoc(docAutorizante.getCodtipodocum());
							if (buscarObjeto(lstMrestri, mrestriParam, mrestriCom03) > -1){
								//No existe en BD pero si esta en mrestri, se registra en datacatalogo TIPODOCUMENTO
								existeTipoDocumento = this.replicarDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_DOCUMENTO_AUTORIZANTE, docAutorizante.getCodtipodocum(), docAutorizante.getCodtipodocum()); //descripcion ???

								if(existeTipoDocumento){
									isNuevoSubTipoDocumento = true;
								}
							}else{
								//No existe en mrestri 
								existeTipoDocumento = false;
							}
						}
					}

					if(existeTipoDocumento){
						//Se verifica si se debe registrar SUBTIPODOCUMENTO
						if(isNuevoSubTipoDocumento){
							String descripcionDataCatalogo;
							if(!CollectionUtils.isEmpty(mapDataCatalogo)){
								descripcionDataCatalogo = (String)mapDataCatalogo.get("des_datacat");
							}else{
								descripcionDataCatalogo = docAutorizante.getCodsubentidad() + "-" + docAutorizante.getCodtipodocum();
							}
							//Registro SUBTIPODOCUMENTO
							String codigoSubTipoDocumento = this.replicarDataCatalogo(ConstantesTipoCatalogo.CATALOGO_SUBTIPO_DOCAUTORIZA, descripcionDataCatalogo);

							if(codigoSubTipoDocumento != null){
								boolean isRegistroExitoso = false;
								//Registro ASOCIACION SUBENTIDAD CON SUBTIPODOCUMENTO
								isRegistroExitoso = this.replicarDataCatAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU, 
										ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA, docAutorizante.getCodsubentidad(), 
										ConstantesTipoCatalogo.CATALOGO_SUBTIPO_DOCAUTORIZA, codigoSubTipoDocumento);

								//Registro ASOCIACION TIPODOCUMENTO CON SUBTIPODOCUMENTO
								isRegistroExitoso = this.replicarDataCatAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, 
										ConstantesTipoCatalogo.CATALOGO_TIPO_DOCUMENTO_AUTORIZANTE, docAutorizante.getCodtipodocum(), 
										ConstantesTipoCatalogo.CATALOGO_SUBTIPO_DOCAUTORIZA, codigoSubTipoDocumento);

								if(isRegistroExitoso){
									docAutorizante.setCodsubtipodocum(codigoSubTipoDocumento);
								}
							}
						}
					}else{
						listErrores.add(catalogoAyudaService.getError("35312", new String []{serie.getNumserie().toString(),docAutorizante.getCodtipodocum()}));
					}

					/*if ( dataCatalogo == null ){
						listErrores.add(catalogoAyudaService.getError("35312", new String []{serie.getNumserie().toString(),docAutorizante.getCodtipodocum()}));
					}*/

					lstCodTipoDoc.add(docAutorizante.getCodtipodocum());
				}

				if(tipoValidacion.equals("rin14") ||(tipoValidacion.equals("vuce") && !SunatStringUtils.isEmptyTrim(docAutorizante.getCodsubentidad()))){//ajuste de vuce

					if (!validaEntidadTipoDocAutoriza(docAutorizante, fechaReferencia)) {
						listErrores.add(catalogoAyudaService.getError("35404", new String []{serie.getNumserie().toString(), docAutorizante.getCodtipodocum(), docAutorizante.getCodentidad(), docAutorizante.getCodsubentidad()}));
					}

				}

				/* verificar que el numero de documento de control (docAuto.getNumdocum()) no se encuentre vacio  
				 * y permita el ingreso de numeros (0..9), letras (A..Z) y los caracteres �-�, �.� y �/�. 
				 * Estos ultimos caracteres no podran ir seguidos uno tras otro y solo se aceptaran a partir de 
				 * la segunda posicion combinados con letras y/o numeros.*/
				if (docAutorizante.getNumdocum().isEmpty()) {
					listErrores.add(catalogoAyudaService.getError("35313", new String []{serie.getNumserie().toString()}));
				}else{			
					listErrores.addAll(validacionCaracteresNumeroDocControl(docAutorizante.getNumdocum(),serie.getNumserie().toString()));//reemplaza validacion PAS20165E220200072
				}

				// Rin 14 - FIN - JYC
				Date fecemision = docAutorizante.getFecemision();
				Date fecvencimiento = docAutorizante.getFecvencimiento();
				// La fecha de emision no debe ser mayor a la fecha de vencimiento del documento transmitido  
				if (fecemision!=null && !SunatDateUtils.sonIguales(fecemision,SunatDateUtils.getDefaultDate(),SunatDateUtils.COMPARA_SOLO_FECHA) && 
						fecvencimiento!=null && !SunatDateUtils.sonIguales(fecvencimiento, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) && 
						SunatDateUtils.compareDate(fecemision, fecvencimiento) > 0 ) {
					listErrores.add(catalogoAyudaService.getError("35316", new String []{serie.getNumserie().toString()}));
				}			
			}//Fin lstDocAutoriza

			Date fecDeclaracion = declaracion.getDua().getFecdeclaracion();
			List<Date> lstFecEmision = new ArrayList<Date>();

			//En Rectificaci�n electr�nica antes del canal
			boolean indRectiAntesCanal = true;
			if (codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION)) {
				CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
				Map<String, Object> param = new HashMap<String, Object>();
				param.put("numeroCorrelativo", declaracion.getNumeroCorrelativo());
				DUA duaAux = cabDeclaraDAO.selectByNumCorredoc(param);
				if (!SunatStringUtils.isEmpty(duaAux.getCodCanal())) {
					indRectiAntesCanal = false;
				}
			}
			//En el proceso de numeraci�n o rectificaci�n electr�nica antes del canal
			if ( codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION) || 
					(codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION) && indRectiAntesCanal) ) 
			{
				for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {
					Date fecemision = docAutorizante.getFecemision();
					if (!lstFecEmision.contains(fecemision)) {
						//La fecha de emisi�n no debe ser mayor a la fecha actual del sistema
						if (codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION) && SunatDateUtils.compareDate(fecemision, SunatDateUtils.getCurrentDate()) > 0 ){
							listErrores.add(catalogoAyudaService.getError("35314", new String []{serie.getNumserie().toString()}));
						}
						//La fecha de emisi�n no debe ser mayor a la fecha de la declaraci�n
						if (codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION) && SunatDateUtils.compareDate(fecemision, fecDeclaracion) > 0 ){
							listErrores.add(catalogoAyudaService.getError("35314", new String []{serie.getNumserie().toString()}));
						}
						lstFecEmision.add(fecemision);
					}
				}
			}

			/* En el proceso de rectificaci�n electr�nica despu�s del canal o 
			 * transmisi�n de regularizaci�n para despacho urgente*/
			lstFecEmision.clear();
			if ( codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION_URGENTE) || 
					(codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION) && indRectiAntesCanal) ) 
			{
				for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {
					Date fecemision = docAutorizante.getFecemision();
					if (!lstFecEmision.contains(fecemision)) {
						//La fecha de emisi�n no debe ser mayor a la fecha actual del sistema
						if (SunatDateUtils.compareDate(fecemision, SunatDateUtils.getCurrentDate()) > 0 ){
							listErrores.add(catalogoAyudaService.getError("35315", new String []{serie.getNumserie().toString()}));
						}
						lstFecEmision.add(fecemision);
					}
				}
			}

		}

		/*Validaci�n adicional cuando la SPN no se encuentra en el c�talogo de Mercancias Restringidas*/
		if (CollectionUtils.isEmpty(lstMrestri) && codTipoExoneracion.equals(Constants.COD_TIPO_EXONERACION) && !esReguAnt) {
			/* Se transmiti� el indicador �R� y no se transmitieron 
			 * los datos del documento de control autorizante respectivo*/
			for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {
				if ( docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) || docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) ) {
					continue;
				}
				if (!lstCodEntidad.contains(docAutorizante.getCodentidad())) {
					lstCodEntidad.add(docAutorizante.getCodentidad());
				}
				if (!lstCodSubEntidad.contains(docAutorizante.getCodsubentidad())) {
					lstCodSubEntidad.add(docAutorizante.getCodsubentidad());
				}
				if (!lstCodTipoDoc.contains(docAutorizante.getCodtipodocum())) {
					lstCodTipoDoc.add(docAutorizante.getCodtipodocum());
				}
			}
			if (!indRestringida){
				listErrores.add(catalogoAyudaService.getError("35317", new String []{serie.getNumserie().toString()}));
			}
			//La entidad declarada no figura en el cat�logo de entidades autorizantes
			for (String  codEntidad : lstCodEntidad) {
				//DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_ENTIDADES_DOCAUTORIZA, codEntidad); //PAS20155E220000487 no usa cache
				Map<String, Object> dataCatalogo = catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_ENTIDADES_DOCAUTORIZA, codEntidad); //PAS20155E220000487 usa cache
				if ( dataCatalogo == null ){ 
					listErrores.add(catalogoAyudaService.getError("35308", new String []{serie.getNumserie().toString(), codEntidad}));
				}
			}
			//La sub entidad declarada no figura en el cat�logo de sub entidades autorizantes
			for (String  codSubEntidad : lstCodSubEntidad) {
				//DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA, codSubEntidad); //PAS20155E220000487 no usa cache
				Map<String, Object> dataCatalogo = catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA, codSubEntidad);  //PAS20155E220000487 usa cache
				if ( dataCatalogo == null ){
					listErrores.add(catalogoAyudaService.getError("35310", new String []{serie.getNumserie().toString(), codSubEntidad}));
				}
			}
			//El tipo de documento de control declarado no figura en el cat�logo de Tipos de documentos autorizantes
			for (String  codTipoDoc : lstCodTipoDoc) {
				//DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_DOCUMENTO_AUTORIZANTE, codTipoDoc); //PAS20155E220000487 no usa cache
				Map<String, Object> dataCatalogo = catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_TIPO_DOCUMENTO_AUTORIZANTE, codTipoDoc); //PAS20155E220000487 usa cache
				if ( dataCatalogo == null ){
					listErrores.add(catalogoAyudaService.getError("35312", new String []{serie.getNumserie().toString(),codTipoDoc}));
				}
			}
		}

		return listErrores;
	}

	/**
	 * Creado por refactorizar RIN14 mejor entendimiento para ajuste de vuce
	 * @param serie
	 * @param docAutorizante
	 * @param lstMrestri
	 * @param mrestriCom01
	 * @param codTransaccion
	 * @param tipoValidacion
	 * @return
	 */
	public List<Map<String, String>> validarEntidadRin14(DatoSerie serie, DatoDocAutorizante docAutorizante,List<MRestri> lstMrestri,Comparator<MRestri> mrestriCom01,String codTransaccion,String tipoValidacion){

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		if(tipoValidacion.equals("vuce") && SunatStringUtils.isEmptyTrim(docAutorizante.getCodsubentidad())){		
			return listErrores;//si es vuce y no envia subentidad que no valide
		}

		/**INICIO CODIGO ORIGINAL DE RIN14**/
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		Map<String, Object> dataCatalogo = catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_ENTIDADES_DOCAUTORIZA, docAutorizante.getCodentidad()); //PAS20155E220000487 usa cache
		if ( dataCatalogo == null ){ 
			listErrores.add(catalogoAyudaService.getError("35308", new String []{serie.getNumserie().toString(),docAutorizante.getCodentidad()}));
		}
		MRestri mrestriParam = new MRestri();
		mrestriParam.setEntidad(docAutorizante.getCodentidad());
		if (buscarObjeto(lstMrestri, mrestriParam, mrestriCom01) == -1 && !codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION) ){
			listErrores.add(catalogoAyudaService.getError("35309", new String []{serie.getNumserie().toString(),docAutorizante.getCodentidad()}));
		}
		/**FIN CODIGO ORIGINAL DE RIN14**/
		return listErrores;

	}

	public boolean  validardiferenciaFechas(Date fechaReferencia,Date fechaNumeracionVuce,String codAduana){

		Map<String, Object> paramDias = new HashMap<String, Object>();
		boolean fechaHabileParaNumerar=false;

		if(SunatDateUtils.sonIguales(fechaNumeracionVuce, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
			return fechaHabileParaNumerar; 
		}
		fechaReferencia = SunatDateUtils.getCurrentDate();
		Date fecVencNumerVuceNueva=SunatDateUtils.addDay(fechaNumeracionVuce,7);
		Integer fecVencNumerVuceAsInteger = SunatDateUtils.getIntegerFromDate(fecVencNumerVuceNueva);

		paramDias.put("FECHADESDE", fecVencNumerVuceAsInteger);
		paramDias.put("FECHAHASTA", 0);
		paramDias.put("TIPO", 2);
		paramDias.put("INCLUYE", "N");
		paramDias.put("SUSPENDE", "S");
		DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
		DataSourceContextHolder.setKeyDataSource(codAduana);
		String fecVencDeclara = diasUtilesDAOsolicitud.getSPDiasUtiles(paramDias);
		Date fecHabilDeNumeracion= SunatDateUtils.getDate(fecVencDeclara,"yyyyMMdd");

		if((SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fecHabilDeNumeracion,SunatDateUtils.COMPARA_SOLO_FECHA))){
			fechaHabileParaNumerar=true;
		}else{
			fechaHabileParaNumerar=false;
		}
		return fechaHabileParaNumerar; 
	}


	//gg vuce
	public DocControlMercRestringidaVuce obtenerDocumentoVuce(Long numDoc, String tipoDoc){

		return obtenerDocumentoVuce(numDoc,tipoDoc,"");
	}

	//cambios amancilla RIN04 vuce
	public DocControlMercRestringidaVuce obtenerDocumentoVuce(Long numDoc, String tipoDoc, String usuario){

		String uri= "http://api.sunat.peru/v1/estrategico/vuce/e/" +
				"documentoscontrol?nrodocum=" + numDoc + "&tipo=" + tipoDoc+"&usuario="+usuario;

		RestTemplate restTemplate = new RestTemplate();
		DocControlMercRestringidaVuce docControlMercRestringidaVuce;
		try {
			docControlMercRestringidaVuce = restTemplate.getForObject(uri, DocControlMercRestringidaVuce.class);
		} catch (HttpClientErrorException e) {
			log.error("no se pudo determinar la existencia del Documento Resolutivo:" + numDoc);
			throw new HttpClientErrorException(e.getStatusCode(), "no se pudo determinar la existencia del Documento Resolutivo:" + numDoc);
		} catch (Exception e) {
			log.error("no existe el Documento Resolutivo:" + numDoc);
			throw new ServiceException(e, "no se pudo determinar la existencia del Documento Resolutivo:" + numDoc);
		}
		return docControlMercRestringidaVuce;
	}

	public void obtenerArchivoPDF(ArchivoAnexoDocControlMR archivo, String numeroDocumentoControl, String usuario){
		String uri= "http://api.sunat.peru/v1/estrategico/vuce/e/" +
				"documentoscontrolPdf?numCorreDoc=" + archivo.getNumeroCorrelativo() +
				"&codIdDocAdjunto=" + archivo.getCodigoIdDocAdjunto() +
				"&numDocControl=" + numeroDocumentoControl +
				"&usuario=" + usuario;
		RestTemplate restTemplate = new RestTemplate(); 
		ArchivoAnexoDocControlMR archivoUbicado;
		try {
			archivoUbicado = restTemplate.getForObject(uri, ArchivoAnexoDocControlMR.class);
		} catch (HttpClientErrorException e) {
			log.error("no se pudo determinar la existencia del PDF del Documento Resolutivo:" +
					archivo.getNumeroCorrelativo().toString());
			throw new HttpClientErrorException(e.getStatusCode(),
					"no se pudo determinar la existencia del pdf del Documento Resolutivo:" +
							archivo.getNumeroCorrelativo().toString());
		} catch (Exception e) {
			log.error("no existe el pdF del Documento Resolutivo:" +  archivo.getNumeroCorrelativo().toString());
			throw new ServiceException(e, "no se pudo determinar la existencia del PDF del Doc Resolutivo:" +
					archivo.getNumeroCorrelativo().toString());
		}
		archivo.setArchivoDocAdjunto(archivoUbicado.getArchivoDocAdjunto());
	}

	private boolean replicarDataCatalogo(String codigoCatalogo, String codigoDataCatalogo, String descripcionDataCatalogo){
		Map<String, Object> paramsCatalogo = new HashMap<String, Object>();
		paramsCatalogo.put("ayudaID", "Catalogo");
		paramsCatalogo.put("catalogoID", codigoCatalogo);
		paramsCatalogo.put("fechaVigencia", new Date());
		AyudaService ayudaService = (AyudaService) fabricaDeServicios.getService("Ayuda.ayudaService");
		List<Map<String, Object>> listaCatalogo = ayudaService.buscar(paramsCatalogo);
		if(!CollectionUtils.isEmpty(listaCatalogo)){
			Map<String, Object> mapCatalogo = listaCatalogo.get(0);

			DataCatalogo dataCatalogo = new DataCatalogo();
			dataCatalogo.setCodCatalogo((String)mapCatalogo.get("codCatalogo"));
			dataCatalogo.setFecInicat((new FechaBean((String)mapCatalogo.get("fecInicat"), "yyyy-MM-dd")).getSQLDate());
			dataCatalogo.setCodDatacat(codigoDataCatalogo);
			dataCatalogo.setFecInidatcat(new Date());
			FechaBean fbFechaFinal = new FechaBean("31/12/9999", "dd/MM/yyyy");
			Date fechaFinal = fbFechaFinal.getSQLDate();
			dataCatalogo.setFecFindatcat(fechaFinal);
			dataCatalogo.setFecFinvigorig(fechaFinal);
			dataCatalogo.setDesDatacat(descripcionDataCatalogo);
			dataCatalogo.setDesCorta(descripcionDataCatalogo.length() > 100 ? descripcionDataCatalogo.substring(0, 100) : descripcionDataCatalogo);
			dataCatalogo.setCodEstado("01");
			dataCatalogo.setIndRegActual("1");
			AyudaServiceDataCatalogo ayudaServiceDataCatalogo = (AyudaServiceDataCatalogo) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo");
			ayudaServiceDataCatalogo.insert(dataCatalogo);

			//Actualiza cache DataCatalogo
			ayudaServiceDataCatalogo.actualizarCacheDataCatalogo();

			return true;
		}
		return false;
	}

	private String replicarDataCatalogo(String codigoCatalogo, String descripcionDataCatalogo){
		String codigoDataCatalogo = null;

		Map<String, Object> paramsCatalogo = new HashMap<String, Object>();
		paramsCatalogo.put("ayudaID", "Catalogo");
		paramsCatalogo.put("catalogoID", codigoCatalogo);
		paramsCatalogo.put("fechaVigencia", new Date());
		AyudaService ayudaService = (AyudaService) fabricaDeServicios.getService("Ayuda.ayudaService");
		List<Map<String, Object>> listaCatalogo = ayudaService.buscar(paramsCatalogo);
		if(!CollectionUtils.isEmpty(listaCatalogo)){
			AyudaServiceDataCatalogo ayudaServiceDataCatalogo = (AyudaServiceDataCatalogo) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo");

			Map<String, Object> mapCatalogo = listaCatalogo.get(0);

			DataCatalogo dataCatalogo = new DataCatalogo();
			dataCatalogo.setCodCatalogo((String)mapCatalogo.get("codCatalogo"));
			dataCatalogo.setFecInicat((new FechaBean((String)mapCatalogo.get("fecInicat"), "yyyy-MM-dd")).getSQLDate());
			codigoDataCatalogo = "" + (new Integer(ayudaServiceDataCatalogo.getMaxElemento(dataCatalogo.getCodCatalogo())) + 1);
			dataCatalogo.setCodDatacat(codigoDataCatalogo); //debe ser numerico
			dataCatalogo.setFecInidatcat(new Date());
			FechaBean fbFechaFinal = new FechaBean("31/12/9999", "dd/MM/yyyy");
			Date fechaFinal = fbFechaFinal.getSQLDate();
			dataCatalogo.setFecFindatcat(fechaFinal);
			dataCatalogo.setFecFinvigorig(fechaFinal);
			dataCatalogo.setDesDatacat(descripcionDataCatalogo); 
			dataCatalogo.setDesCorta(descripcionDataCatalogo.length() > 100 ? descripcionDataCatalogo.substring(0, 100) : descripcionDataCatalogo);
			dataCatalogo.setCodEstado("01");
			dataCatalogo.setIndRegActual("1");
			ayudaServiceDataCatalogo.insert(dataCatalogo);

			//Actualiza cache DataCatalogo
			ayudaServiceDataCatalogo.actualizarCacheDataCatalogo();

			return codigoDataCatalogo;
		}
		return codigoDataCatalogo;
	}

	private boolean replicarDataCatAsoc(String codigoAsociacion, String codigoCatalogo, String codigoDataCatalogo, String codigoCatalogoAsociado, String codigoDataCatalogoAsociado){
		Map<String, Object> paramsAsociacion = new HashMap<String, Object>();
		paramsAsociacion.put("ayudaID", "Asociacatalog");
		paramsAsociacion.put("codAsociacion", codigoAsociacion);
		paramsAsociacion.put("fecha", new Date());
		AyudaService ayudaService = (AyudaService) fabricaDeServicios.getService("Ayuda.ayudaService");
		List<Map<String, Object>> listaAsociacion = ayudaService.buscar(paramsAsociacion);
		if(!CollectionUtils.isEmpty(listaAsociacion)){
			Map<String, Object> mapAsociacion = listaAsociacion.get(0);
			DataCatAsoc dataCatAsoc = new DataCatAsoc();
			dataCatAsoc.setCodAsoccat((String)mapAsociacion.get("codAsoccat"));
			dataCatAsoc.setFecIniasoccat((new FechaBean((String)mapAsociacion.get("fecIniasoccat"), "yyyy-MM-dd")).getSQLDate());
			dataCatAsoc.setCodCatalogo(codigoCatalogo);
			dataCatAsoc.setCodDatacat(codigoDataCatalogo);
			dataCatAsoc.setCodCatalogoasoc(codigoCatalogoAsociado);
			dataCatAsoc.setCodDatacatasoc(codigoDataCatalogoAsociado);
			dataCatAsoc.setFecIniasoc(new Date());
			//dataCatAsoc.setFecInidatcat(fecInidatcat);
			FechaBean fbFechaFinal = new FechaBean("31/12/9999", "dd/MM/yyyy");
			Date fechaFinal = fbFechaFinal.getSQLDate();
			dataCatAsoc.setFecFinasoc(fechaFinal);
			dataCatAsoc.setFecFinasocorig(fechaFinal);
			dataCatAsoc.setCodEstado("01");
			dataCatAsoc.setIndRegActual("1");

			AyudaServiceDataCatAsoc ayudaServiceDataCatAsoc = (AyudaServiceDataCatAsoc) fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatAsoc");
			ayudaServiceDataCatAsoc.insert(dataCatAsoc);

			//Actualiza cache DataCatalogo
			ayudaServiceDataCatAsoc.actualizarCacheDataCatAsoc();

			return true;
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	private List<Map<String, Object>> getListDocAutorizPreceDeposito(DatoSerie serie, List<String> listaEntidad){
		List<Map<String,Object>> lstDocAutorizPreceDeposito = new ArrayList<Map<String, Object>>();

		ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");

		if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
			for(DatoRegPrecedencia preceDua : serie.getListRegPrecedencia()){
				if(Constants.REGIMEN_DEPOSITO.toString().equals(preceDua.getCodregipre())){
					Map<String, Object> params = new HashMap<String,Object>();
					params.put("codi_aduan", preceDua.getCodaduapre());
					params.put("ano_prese", preceDua.getAnndeclpre().substring(0, 4));
					params.put("nume_corre", SunatStringUtils.lpad(preceDua.getNumdeclpre(), 6, '0'));
					params.put("codi_regi", preceDua.getCodregipre());		
					params.put("nume_serie", preceDua.getNumserpre());
					params.put("listaEntidad", listaEntidad);
					lstDocAutorizPreceDeposito.addAll(consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(params));
				} 
			}
		}
		return lstDocAutorizPreceDeposito;
	}

	@SuppressWarnings("unchecked")
	private List<Map<String, Object>> getListDocAutorizPreceDeposito(DatoSerie serie, String entidad){
		List<Map<String,Object>> lstDocAutorizPreceDeposito = new ArrayList<Map<String, Object>>();

		ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");

		if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
			for(DatoRegPrecedencia preceDua : serie.getListRegPrecedencia()){
				if(Constants.REGIMEN_DEPOSITO.toString().equals(preceDua.getCodregipre())){
					Map<String, Object> params = new HashMap<String,Object>();
					params.put("codi_aduan", preceDua.getCodaduapre());
					params.put("ano_prese", preceDua.getAnndeclpre().substring(0, 4));
					params.put("nume_corre", SunatStringUtils.lpad(preceDua.getNumdeclpre(), 6, '0'));
					params.put("codi_regi", preceDua.getCodregipre());		
					params.put("nume_serie", preceDua.getNumserpre());
					params.put("codi_enti", entidad);
					lstDocAutorizPreceDeposito.addAll(consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(params));
				} 
			}
		}
		return lstDocAutorizPreceDeposito;
	}


	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Valida la transmici�n de documentos autorizantes para la subentidad "0501" 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 */
	@ServicioAnnot(tipo="V",codServicio=9104, descServicio="Valida la transmici�n de documentos autorizantes para la subentidad 0501")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9104,numSecEjec=04,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarSubEntidadCodExoneracion(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		DUA duaAux = null;

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		List<MRestri> lstMRestri = (List<MRestri>) variablesIngreso.get("listMercRestringida");

		String codServicio = obtenerCodigoServicioAnotacion(this);

		List<String> lstSubEntidadServicio = obtenerSubEntidadesPorServicio(codServicio, fechaReferencia);
		boolean indValMrestri = variablesIngreso.get("indValMrestri") == null ? false : (Boolean)variablesIngreso.get("indValMrestri") ; //ajustes PAS20175E220200043

		if (indValMrestri) 
		{			
			//Lista de documentos Autorizantes por SubEntidad ("0501" y "0503")
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante datoDocAutorizante : lstDocAutorizaMrestri) {
				if (datoDocAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO)) {
					listErrores.add(catalogoAyudaService.getError("35352", new String []{serie.getNumserie().toString()}));
				}
			}

			//SAU201510002000127(PAS20155E220300013)
			//Debe permitir s�lo enviar un documento autorizante por entidad
			List<String> lstSubEntidadServicioValidar = new ArrayList<String>();
			//List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, (DUA) serie.getPadre(), variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
			List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, (DUA) serie.getPadre(), variablesIngreso, false); //BUG 24309-24326 - PAS20155E220000487

			for(String subEntidadServicio : lstSubEntidadServicio){
				String codigoEntidad = subEntidadServicio.substring(0, 2);

				boolean indExisteDocAutorizanteEntidad = false;

				for(DatoDocAutorizante datoDocAutorizante : lstDocAutoriza){
					if(datoDocAutorizante.getCodentidad().equals(codigoEntidad)){
						indExisteDocAutorizanteEntidad = true;
						break;
					}
				}

				if(!indExisteDocAutorizanteEntidad){
					lstSubEntidadServicioValidar.add(subEntidadServicio);
				}
			}

			if(!CollectionUtils.isEmpty(lstSubEntidadServicioValidar)){
				//Permitira identificar si existe mercancia restringida para "0501" y "0503"
				boolean indSubEntidad = false;
				boolean indRectiLevante = false;

				String cadenaEntidad = null; //SAU201510002000126(PAS20155E220300013)
				String cadenaSubEntidad = null; //SAU201510002000126(PAS20155E220300013)

				//for (String subEntidadServicio : lstSubEntidadServicio) {
				for (String subEntidadServicio : lstSubEntidadServicioValidar) {
					for (MRestri mrestri : lstMRestri) {
						if (subEntidadServicio.equals(mrestri.getRegistro())){
							if(!indSubEntidad){
								indSubEntidad = true;
								cadenaEntidad = mrestri.getEntidad(); //SAU201510002000126(PAS20155E220300013)
								cadenaSubEntidad = mrestri.getRegistro(); //SAU201510002000126(PAS20155E220300013)
							}else{
								cadenaSubEntidad += (" o " + mrestri.getRegistro());
							}
							break;
						}
					}
				}

				if ( codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION) ) {
					Map<String, Object> param = new HashMap<String, Object>();
					param.put("numeroCorrelativo", declaracion.getNumeroCorrelativo() );
					CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
					duaAux = cabDeclaraDAO.selectByNumCorredoc(param);
					if ( SunatDateUtils.getDefaultDate().compareTo(duaAux.getFecAutlevante()) == 0 ) {
						indRectiLevante = true;
					}
				}

				if ( (codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION) || (codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION) && indRectiLevante )) && indSubEntidad) 
				{
					if (CollectionUtils.isEmpty(lstDocAutorizaMrestri)){
						listErrores.add(catalogoAyudaService.getError("35307", new String []{serie.getNumserie().toString(), cadenaEntidad, cadenaSubEntidad})); //SAU201510002000126(PAS20155E220300013)
					}	
				}

				//			for (String subEntidadServicio : lstSubEntidadServicio) {
				//				for (MRestri mrestri : lstMRestri) {
				//					if (subEntidadServicio.equals(mrestri.getRegistro())){
				//						indSubEntidad = true;
				//						break;
				//					}else{ 
				//						indSubEntidad = false; 
				//					}
				//				}
				//			}
				//			if ( indSubEntidad && !CollectionUtils.isEmpty(lstDocAutorizaMrestri) && 
				//				 (codExoneracion.equals(Constants.COD_EXONERACION_INFO) || codExoneracion.equals(Constants.COD_EXONERACION)) ) {
				//					listErrores.add(catalogoAyudaService.getError("35306", new String []{serie.getNumserie().toString(), codExoneracion}));
				//			}
				//				
				//				if ( codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION) ) {
				//					Map<String, Object> param = new HashMap<String, Object>();
				//					param.put("numeroCorrelativo", declaracion.getNumeroCorrelativo() );
				//					CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
				//					duaAux = cabDeclaraDAO.selectByNumCorredoc(param);
				//					if ( SunatDateUtils.getDefaultDate().compareTo(duaAux.getFecAutlevante()) == 0 ) {
				//						indRectiLevante = true;
				//					}
				//				}
				//				
				//				if ( (codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION) || 
				//					 (codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION) && indRectiLevante )) && 
				//					 indSubEntidad) {
				//					if (!codExoneracion.equals(Constants.COD_EXONERACION_INFO) && CollectionUtils.isEmpty(lstDocAutorizaMrestri)){
				//						listErrores.add(catalogoAyudaService.getError("35307", new String []{serie.getNumserie().toString()}));
				//					}else{
				//						if (codExoneracion.equals(Constants.COD_EXONERACION_INFO) && 
				//							codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
				//							//WARNING
				//							//listErrores.add(catalogoAyudaService. getError("35352", "W", new String[]{}));
				//							listErrores.add(catalogoAyudaService.getError("35352", new String []{serie.getNumserie().toString()}));
				//							variablesIngreso.put("indValDocAutoSenasa", false);
				//						}
				//					}
				//				}
			}
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida la transmici�n de documentos autorizantes para SPN Restringidas
	 * sin los c�digos de exoneraci�n 80 y 98. Transacci�n 1003 y 1005 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9105, descServicio="Valida documentos autorizantes sin c�digo de exoneraci�n")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9105,numSecEjec=05,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarTipDocExoneracionInfo(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		DUA dua = (DUA)serie.getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		//Obtiene el c�digo de tipo de tratamiento
		String codTipoTratamiento = dua.getCodtipotratamiento();

		String codServicio = obtenerCodigoServicioAnotacion(this);
		Boolean indValMrestri = variablesIngreso.get("indValMrestri")!=null?(Boolean)(variablesIngreso.get("indValMrestri")):false;//ajustes PAS20175E220200043 RSV
		Boolean indImpugnada = (Boolean)variablesIngreso.get("indImpugnada");
		//Boolean indValDocAutoSenasa = (Boolean)variablesIngreso.containsKey("indValDocAutoSenasa")==true ? (Boolean)variablesIngreso.get("indValDocAutoSenasa") : true;   
		/*
		if( indValMrestri && codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) &&
			(!codExoneracion.equals(Constants.COD_EXONERACION_INFO) && !codExoneracion.equals(Constants.COD_EXONERACION)) && 
			!indImpugnada && indValDocAutoSenasa) 
		{
		 */
		if( indValMrestri && codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) && !indImpugnada) 
		{			
			listErrores = validarDocAutServicioSubEntidad(serie, codServicio, "35354", fechaReferencia, variablesIngreso); 
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida la transmici�n de documentos autorizantes para SPN Restringidas
	 * sin el c�digo de exoneraci�n  98 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9106, descServicio="Valida documentos autorizantes sin c�digo de exoneraci�n")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9106,numSecEjec=06,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarTipDocExoneracion(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		DUA dua = (DUA)serie.getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		//Obtiene el c�digo de tipo de tratamiento
		String codTipoTratamiento = dua.getCodtipotratamiento();

		String codServicio = obtenerCodigoServicioAnotacion(this);
		Boolean indValMrestri = variablesIngreso.get("indValMrestri")!=null?(Boolean)(variablesIngreso.get("indValMrestri")):false;//ajustes PAS20175E220200043 RSV
		Boolean indImpugnada = (Boolean)variablesIngreso.get("indImpugnada");
		/*
		if( indValMrestri && codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) && !indImpugnada &&
			!codExoneracion.equals(Constants.COD_EXONERACION) ) 
		{
		 */
		if( indValMrestri && codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) && !indImpugnada) 
		{
			listErrores = validarDocAutServicioSubEntidad(serie, codServicio, "35354", fechaReferencia, variablesIngreso); 
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida la transmici�n de documentos autorizantes para SPN Restringidas
	 * sin tomar en cuenta los c�digos de exoneraci�n 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9107, descServicio="Valida transmici�n de documentos autorizantes")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9107,numSecEjec=06,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarTipDocSinExoneracion(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//		if (variablesIngreso.containsKey("indExcluyeDIQBF")){
		//			if ((Boolean) variablesIngreso.get("indExcluyeDIQBF")){
		//				return listErrores;
		//			}
		//		}	

		DUA dua = (DUA)serie.getPadre();

		//Obtiene el c�digo de tipo de tratamiento
		String codTipoTratamiento = dua.getCodtipotratamiento();

		String codServicio = obtenerCodigoServicioAnotacion(this);
		Boolean indValMrestri = variablesIngreso.get("indValMrestri")!=null?(Boolean)(variablesIngreso.get("indValMrestri")):false;//ajustes PAS20175E220200043 RSV
		Boolean indImpugnada = (Boolean)variablesIngreso.get("indImpugnada");

		if( indValMrestri && codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) && !indImpugnada) {
			listErrores = validarDocAutServicioSubEntidad(serie, codServicio, "35354", fechaReferencia, variablesIngreso); 
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida la transmici�n de documentos autorizantes para SPN Restringidas
	 * sin los c�digos de exoneraci�n 80 y 98. 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9108, descServicio="Valida transmici�n de documentos autorizantes")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9108,numSecEjec=07,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarTipDocExoneracionInfoOtros(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		DUA dua = (DUA)serie.getPadre();//se reactiva para atender bug diferido PAS20155E220200023 arey

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		//Obtiene el c�digo de tipo de tratamiento
		String codTipoTratamiento = dua.getCodtipotratamiento()==null ? "" : dua.getCodtipotratamiento();//se reactiva para atender bug diferido PAS20155E220200023 23 arey

		String codServicio = obtenerCodigoServicioAnotacion(this);
		Boolean indValMrestri = variablesIngreso.get("indValMrestri")!=null?(Boolean)(variablesIngreso.get("indValMrestri")):false;//ajustes PAS20165E220200072
		//Boolean indImpugnada = (Boolean)variablesIngreso.get("indImpugnada");
		//Boolean indValDocAutoSenasa = (Boolean)variablesIngreso.containsKey("indValDocAutoSenasa")==true ? (Boolean)variablesIngreso.get("indValDocAutoSenasa") : true;   

		/*
		if( indValMrestri && codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) && !indImpugnada &&
			(!codExoneracion.equals(Constants.COD_EXONERACION_INFO) && !codExoneracion.equals(Constants.COD_EXONERACION)) && indValDocAutoSenasa) 
		{
		 */
		//		if( indValMrestri /*&& codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) && !indImpugnada*/)
		if( indValMrestri && !codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) )//se utiliza esto para atender bug diferido PAS20155E220200023 arey
		{
			listErrores = validarDocAutServicioSubEntidad(serie, codServicio, "35354", fechaReferencia, variablesIngreso); 
		}

		return listErrores;
	}

	@ServicioAnnot(tipo="V",codServicio=91130 , descServicio="Valida si la transmision es donacion y es tipodoc 99")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=91130 ,numSecEjec=10,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarTratamientoDonacionSubentidad(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		String codServicio = obtenerCodigoServicioAnotacion(this);
		Boolean indValMrestri = variablesIngreso.get("indValMrestri")!=null?(Boolean)(variablesIngreso.get("indValMrestri")):false;//ajustes PAS20175E220200043 RSV 

		DUA dua = (DUA)serie.getPadre();
		String codRegimen = dua.getCodregimen();  

		String codTransaccion = SunatStringUtils.substring(String.valueOf(variablesIngreso.get("codTransaccion")),2,4);
		String codTipoTratamiento = dua.getCodtipotratamiento()==null ? "" : dua.getCodtipotratamiento();
		boolean tieneTratamientoDonacion=false; 
		if(codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO)){
			tieneTratamientoDonacion=true;
		}

		List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

		for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

			boolean indValidarDonacion = false;
			boolean indEvitarTransmision = false;//adicionado Arey pase23-2015
			if(tieneTratamientoDonacion && codRegimen.equals(Constants.REGIMEN_IMPO_DEFINITIVA.toString()) && 
					(!docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) || !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION))){	
				//si es regimen 10 tiene donacion y no esta exonerada con 80 o 98:	

				//si es numeracion con tipo de documento 7 que valideee porq no debe enviarlo, en los demas casos que entre tbm:
				if(codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION)|| (!codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION) && !docAutorizante.getCodtipodocum().equals("07"))){


					int subtipo = new Integer(docAutorizante.getCodsubentidad().toString());

					if(subtipo==501 || subtipo==503){
						if(!docAutorizante.getCodtipodocum().equals(DOC_PERMISO_SANITARIO) && !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS))
							indValidarDonacion=true;//no es 09 ni 99 
						if((docAutorizante.getCodtipodocum().equals("07") && codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION))){//arey Pase 23 - 2015
							indEvitarTransmision=true; 
						}

					}else if(subtipo==504){						
						if(!docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION) && !docAutorizante.getCodtipodocum().equals(DOC_CERTIFICADO)
								&& !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS))
							indValidarDonacion=true; //no es 01, 03 ni 99
						if((docAutorizante.getCodtipodocum().equals("07") && codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION))){//arey Pase 23 - 2015
							indEvitarTransmision=true; 
						}						

					}else if(subtipo==301){						
						if(!docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION) && !docAutorizante.getCodtipodocum().equals(DOC_CERTIFICADO)
								&& !docAutorizante.getCodtipodocum().equals(REG_SANITARIO) && !docAutorizante.getCodtipodocum().equals(EXPED_TRAMITE)
								&& !docAutorizante.getCodtipodocum().equals(NOTIF_SANITARIA) && !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){
							indValidarDonacion=true; //no es 01, 03, 08, 12 � 16 ni 99
						} 
						if((docAutorizante.getCodtipodocum().equals("07") && codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION))){//arey Pase 23 - 2015
							indEvitarTransmision=true; 
						}

					}else if(subtipo==401){
						if(!docAutorizante.getCodtipodocum().equals(DOC_CERTIFICADO)
								&& !docAutorizante.getCodtipodocum().equals(REG_SANITARIO) && !docAutorizante.getCodtipodocum().equals(EXPED_TRAMITE)
								&& !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){
							indValidarDonacion=true; 	//no es 03, 08 � 12 ni 99 
						}
						if((docAutorizante.getCodtipodocum().equals("07") && codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION))){//arey Pase 23 - 2015
							indEvitarTransmision=true; 
						}

					}else if(subtipo==406 || subtipo==407 ){
						if(!docAutorizante.getCodtipodocum().equals(RESOL_DIRECTORAL)
								&& !docAutorizante.getCodtipodocum().equals(COPIA_CERTIFICADA) && !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){
							indValidarDonacion=true; 	//no es �02� o�17�, ni 99 
						}						 
						if((docAutorizante.getCodtipodocum().equals("07") && codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION))){//arey Pase 23 - 2015
							indEvitarTransmision=true; 
						}

					}else if(subtipo==701){
						if(!docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION) && !docAutorizante.getCodtipodocum().equals(RESOL_DIRECTORAL)
								&& !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){
							indValidarDonacion=true; 	//no es �01� o �02� ni 99 
						}	
						if((docAutorizante.getCodtipodocum().equals("07") && codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION))){//arey Pase 23 - 2015
							indEvitarTransmision=true; 
						}
					}
				}

			}
			if( indValMrestri && indValidarDonacion)//si es restringida y debe validar si es donacion:
			{
				variablesIngreso.put("indEvitarTransmision",indEvitarTransmision);//adicionado arey pase 23 - 2015
				//este metodo botara el msj de error dinamica si  esta inscrito en el servicio el tipo de documento 
				listErrores = validarDocAutServicioSubEntidad(serie, codServicio, "35354", fechaReferencia, variablesIngreso); 
			}
		}
		return listErrores;
	}
	@Override
	/**
	 * Valida la transmici�n de documentos autorizantes para SPN Restringidas
	 * sin el c�digo de exoneraci�n  98 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9109, descServicio="Valida transmici�n de documentos autorizantes")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9109,numSecEjec=10,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarTipDocExoneracionOtros(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		DUA dua = (DUA)serie.getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		//Obtiene el c�digo de tipo de tratamiento
		String codTipoTratamiento = dua.getCodtipotratamiento()==null ? "" : dua.getCodtipotratamiento();

		String codServicio = obtenerCodigoServicioAnotacion(this);
		Boolean indValMrestri = variablesIngreso.get("indValMrestri")!=null?(Boolean)(variablesIngreso.get("indValMrestri")):false;//ajustes PAS20175E220200043 RSV
		//Boolean indImpugnada = (Boolean)variablesIngreso.get("indImpugnada");

		if( indValMrestri && !codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) ) 
		{
			listErrores = validarDocAutServicioSubEntidad(serie, codServicio, "35354", fechaReferencia, variablesIngreso); 
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida la transmici�n de documentos autorizantes para SPN Restringidas
	 * sin tomar en cuenta los c�digos de exoneraci�n 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9110, descServicio="Valida transmici�n de documentos autorizantes")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9110,numSecEjec=11,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarTipDocSinExoneracionOtros(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		//DUA dua = (DUA)serie.getPadre();

		//Obtiene el c�digo de tipo de tratamiento
		//String codTipoTratamiento = dua.getCodtipotratamiento()==null ? "" : dua.getCodtipotratamiento();

		String codServicio = obtenerCodigoServicioAnotacion(this);
		Boolean indValMrestri = variablesIngreso.get("indValMrestri")!=null?(Boolean)(variablesIngreso.get("indValMrestri")):false;//ajustes PAS20175E220200043 RSV 
		//Boolean indImpugnada = (Boolean)variablesIngreso.get("indImpugnada");

		if( indValMrestri /*&& codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO) && !indImpugnada */) {
			listErrores = validarDocAutServicioSubEntidad(serie, codServicio, "35354", fechaReferencia, variablesIngreso); 
		}

		return listErrores;		
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Valida la vigencia del documento de control y si fue usado anteiormente
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9111, descServicio="Valida vigencia y uso del documento de control")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9111,numSecEjec=12,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutImportadorVigente(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		DUA dua = (DUA)serie.getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String numDocIdentidad = dua.getDeclarante().getNumeroDocumentoIdentidad();
		String codRegimen = dua.getCodregimen();
		String codAduana = dua.getCodaduanaorden();
		Map<String, Object> param = new HashMap<String, Object>();
		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");
		Boolean indValDocAutoSenasa = (Boolean)variablesIngreso.containsKey("indValDocAutoSenasa")==true ? (Boolean)variablesIngreso.get("indValDocAutoSenasa") : true;   


		/*
		if (indValMrestri && (!codExoneracion.equals(Constants.COD_EXONERACION_INFO) && 
			!codExoneracion.equals(Constants.COD_EXONERACION)) && indValDocAutoSenasa ) {
		 */
		if (indValMrestri && indValDocAutoSenasa ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);
			ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			//CabMrDocAutorizDAO cabMrDocAutorizDAO = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");
			ParticipanteDocDAO participanteDAO = (ParticipanteDocDAO) fabricaDeServicios.getService("despaduanero2.participanteDocDAO");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

				/***Inicio cambios VUCE***/	
				String tipoValidacion = obtenerTipoValidacionDocumentoAutorizante(docAutorizante, fechaReferencia, variablesIngreso, codRegimen);
				if(tipoValidacion.equals("vuce")){
					continue;
				}
				/***Fin cambios VUCE***/

				if (validaEntidadTipoDocAutoriza(docAutorizante, fechaReferencia)) {
					List<DatoDocAutorizante> lstDatoDocAutorizante= validarUsoDocAutorizante(docAutorizante, param);
					boolean indDocAutoUsado = false;
					//PAS20155E220000371 - <KAH RIN14>
					boolean indDocAutVencido= false;
					if(CollectionUtils.isEmpty(lstDatoDocAutorizante)){	
						Map<String, Object> parametroConsultarRestring = new HashMap<String, Object>();								
						parametroConsultarRestring.put("codi_enti",docAutorizante.getCodentidad());
						parametroConsultarRestring.put("codi_docum",docAutorizante.getCodtipodocum());
						parametroConsultarRestring.put("numaut", docAutorizante.getNumdocum());
						parametroConsultarRestring.put("feemiaut",SunatDateUtils.getIntegerFromDate(docAutorizante.getFecemision()));							

						List<Map<String,Object>> lstDocAutorizRegistradosAsigad = (List<Map<String,Object>>) consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(parametroConsultarRestring);
						for (Map<String, Object> mapResultadoRestring : lstDocAutorizRegistradosAsigad) {
							DatoDocAutorizante datoDocAutorizante_restring=new DatoDocAutorizante();
							datoDocAutorizante_restring.setCodentidad(mapResultadoRestring.get("CODI_ENTI").toString());
							datoDocAutorizante_restring.setCodtipodocum(mapResultadoRestring.get("CODI_DOCUM").toString());
							datoDocAutorizante_restring.setAnndocum(mapResultadoRestring.get("ANOAUT").toString());
							datoDocAutorizante_restring.setNumdocum(mapResultadoRestring.get("NUMAUT").toString());
							datoDocAutorizante_restring.setNumcorredoc(Long.valueOf(mapResultadoRestring.get("NUME_CORRE").toString()));
							datoDocAutorizante_restring.setFecemision(SunatDateUtils.getDateFromInteger(Integer.parseInt(mapResultadoRestring.get("FEEMIAUT").toString())));
							lstDatoDocAutorizante.add(datoDocAutorizante_restring);

						}
					}
					//PAS20155E220000371 - </KAH RIN14>
					for (DatoDocAutorizante datoDocAutorizante : lstDatoDocAutorizante) {
						if (SunatStringUtils.length(docAutorizante.getAnndocum())>3){
							docAutorizante.setAnndocum(docAutorizante.getAnndocum().substring(0,4));
						}else{
							docAutorizante.setAnndocum(docAutorizante.getAnndocum());
						}
						/*
							Map<String, Object> params = new HashMap<String, Object>();
							params.put("codTipDocum", datoDocAutorizante.getCodtipodocum());
							params.put("annDocum", datoDocAutorizante.getAnndocum());
							params.put("numDocum", datoDocAutorizante.getNumdocum());
							params.put("codEntidad", datoDocAutorizante.getCodentidad());
							params.put("codAduana", codAduana);
							params.put("codRegimen", codRegimen);
							params.put("fecEmision", SunatDateUtils.getIntegerFromDate(datoDocAutorizante.getFecemision()));
							params.put("numRuc", numDocIdentidad);
							List<CabMrDocAutoriz> lstCabMrDocAutoriz = cabMrDocAutorizDAO.listCabMrdocAutoriz(params);
						 */

						Map<String, Object> params = new HashMap<String, Object>();
						params.put("numeroCorrelativo", datoDocAutorizante.getNumcorredoc());
						params.put("tipoDocumentoIdentidad", ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC);
						params.put("numeroDocumentoIdentidad", numDocIdentidad);
						List<Participante> lstParticipante = participanteDAO.findParticipantesByMap(params);
						if (!CollectionUtils.isEmpty(lstParticipante)){
							indDocAutoUsado = true;
						}
					}
					//PAS20155E220000371 - <KAH RIN14>
					boolean indDocAutoRegimenPrecedente=validarDocControlAutorizanteTieneRegimenPrecedente(lstDatoDocAutorizante,serie,docAutorizante);
					if(indDocAutoRegimenPrecedente | indDocAutoUsado){
						indDocAutVencido=true;
					}
					//PAS20155E220000371 - </KAH RIN14>
					if (!indDocAutVencido) {
						/* El Doc. Autorizanteser� usado por primera vez. Valida que se encuentre
						 * vigente a la fecha de numeraci�n de la declaraci�n.*/
						Integer intFecAcutal = SunatDateUtils.getCurrentIntegerDate();
						Integer intFecVencimiento = SunatDateUtils.getIntegerFromDate(docAutorizante.getFecvencimiento());
						if (SunatNumberUtils.isGreaterThanParam(intFecAcutal, intFecVencimiento)) {
							listErrores.add(catalogoAyudaService.getError("35318", new String []{serie.getNumserie().toString()}));
						}
					}else{
						if (codRegimen.equals(Constants.REGIMEN_IMPORTACION_CONSUMO.toString()) && codAduana.equals(Constants.COD_ADUANA_MARITIMA_CALLAO)) {
							//WARNING
							listErrores.add(catalogoAyudaService.getError("35353", new String []{serie.getNumserie().toString()}));
						}
					}
				}
			}

		}

		return listErrores;
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Valida si el  documento de control corresponde a la primera declaraci�n
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9112, descServicio="Valida si es la primera declaraci�n del documento de control")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9112,numSecEjec=13,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutPrimeraDeclaracion(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");
		//Boolean indValDocAutoSenasa = (Boolean)variablesIngreso.containsKey("indValDocAutoSenasa")==true ? (Boolean)variablesIngreso.get("indValDocAutoSenasa") : true;   

		/*
		if ( indValMrestri && (!codExoneracion.equals(Constants.COD_EXONERACION_INFO) && 
			 !codExoneracion.equals(Constants.COD_EXONERACION)) && indValDocAutoSenasa  ) {
		 */
		if ( indValMrestri ) 
		{
			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			/**AREY para concretar RN-1033 (SAU20153D211000714)**/
			DUA dua = (DUA)serie.getPadre();
			String numDocIdentidad = dua.getDeclarante().getNumeroDocumentoIdentidad();
			/*String codRegimen = dua.getCodregimen();
			String codAduana = dua.getCodaduanaorden();*/
			Map<String, Object> param = new HashMap<String, Object>();

			ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService"); 
			ParticipanteDocDAO participanteDAO = (ParticipanteDocDAO) fabricaDeServicios.getService("despaduanero2.participanteDocDAO");
			/***AREY para concretar RN-1033 (SAU20153D211000714)**/
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

				/***Inicio cambios VUCE- si es vuce debe salir***/       
				String tipoValidacion = obtenerTipoValidacionDocumentoAutorizante(docAutorizante, fechaReferencia, variablesIngreso, dua.getCodregimen());
				if(tipoValidacion.equals("vuce")){
					continue;
				}
				/***Fin cambios VUCE***/   


				if (validaEntidadTipoDocAutoriza(docAutorizante, fechaReferencia)) {
					/**inicio de cambios para id si es la primera vez que se ha utilizado la autorizacion- AREY para concretar RN-1033 (SAU20153D211000714)**/
					List<DatoDocAutorizante> lstDatoDocAutorizante= validarUsoDocAutorizante(docAutorizante, param);
					boolean indDocAutoUsado = false;
					boolean indDocAutVencido= false;
					if(CollectionUtils.isEmpty(lstDatoDocAutorizante)){	
						Map<String, Object> parametroConsultarRestring = new HashMap<String, Object>();								
						parametroConsultarRestring.put("codi_enti",docAutorizante.getCodentidad());
						parametroConsultarRestring.put("codi_docum",docAutorizante.getCodtipodocum());
						parametroConsultarRestring.put("numaut", docAutorizante.getNumdocum());
						parametroConsultarRestring.put("feemiaut",SunatDateUtils.getIntegerFromDate(docAutorizante.getFecemision()));							

						List<Map<String,Object>> lstDocAutorizRegistradosAsigad = (List<Map<String,Object>>) consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(parametroConsultarRestring);
						for (Map<String, Object> mapResultadoRestring : lstDocAutorizRegistradosAsigad) {
							DatoDocAutorizante datoDocAutorizante_restring=new DatoDocAutorizante();
							datoDocAutorizante_restring.setCodentidad(mapResultadoRestring.get("CODI_ENTI").toString());
							datoDocAutorizante_restring.setCodtipodocum(mapResultadoRestring.get("CODI_DOCUM").toString());
							datoDocAutorizante_restring.setAnndocum(mapResultadoRestring.get("ANOAUT").toString());
							datoDocAutorizante_restring.setNumdocum(mapResultadoRestring.get("NUMAUT").toString());
							datoDocAutorizante_restring.setNumcorredoc(Long.valueOf(mapResultadoRestring.get("NUME_CORRE").toString()));
							datoDocAutorizante_restring.setFecemision(SunatDateUtils.getDateFromInteger(Integer.parseInt(mapResultadoRestring.get("FEEMIAUT").toString())));
							lstDatoDocAutorizante.add(datoDocAutorizante_restring);								
						}
					}
					for (DatoDocAutorizante datoDocAutorizante : lstDatoDocAutorizante) {
						if (SunatStringUtils.length(docAutorizante.getAnndocum())>3){
							docAutorizante.setAnndocum(docAutorizante.getAnndocum().substring(0,4));
						}else{
							docAutorizante.setAnndocum(docAutorizante.getAnndocum());
						}
						Map<String, Object> params = new HashMap<String, Object>();
						params.put("numeroCorrelativo", datoDocAutorizante.getNumcorredoc());
						params.put("tipoDocumentoIdentidad", ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC);
						params.put("numeroDocumentoIdentidad", numDocIdentidad);
						List<Participante> lstParticipante = participanteDAO.findParticipantesByMap(params);
						if (!CollectionUtils.isEmpty(lstParticipante)){
							indDocAutoUsado = true;
						}
					} 
					boolean indDocAutoRegimenPrecedente=validarDocControlAutorizanteTieneRegimenPrecedente(lstDatoDocAutorizante,serie,docAutorizante);
					if(indDocAutoRegimenPrecedente || indDocAutoUsado){
						indDocAutVencido=true;
					}
					/**Fin de cambios AREY**/

					if(!indDocAutVencido){//Adicionado por AREY para concretar RN-1033 (SAU20153D211000714)
						//Valida que se encuentre vigente a la fecha de numeraci�n de la declaraci�n.
						Integer intFecAcutal = SunatDateUtils.getCurrentIntegerDate();
						Integer intFecVencimiento = SunatDateUtils.getIntegerFromDate(docAutorizante.getFecvencimiento());
						if (SunatNumberUtils.isGreaterThanParam(intFecAcutal, intFecVencimiento)){
							listErrores.add(catalogoAyudaService.getError("35318", new String []{serie.getNumserie().toString()}));
						}
					}
				}
			}
		}//AREY para concretar RN-1033 (SAU20153D211000714)

		return listErrores;
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Valida fecha de vencimiento y regimen precedente del documento de control
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9113, descServicio="Valida fecha de vencimiento y fecha de control")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9113,numSecEjec=14,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutFecVenciRegPrece(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");
		//Boolean indValDocAutoSenasa = (Boolean)variablesIngreso.containsKey("indValDocAutoSenasa")==true ? (Boolean)variablesIngreso.get("indValDocAutoSenasa") : true;   

		/*
		if ( indValMrestri && (!codExoneracion.equals(Constants.COD_EXONERACION_INFO) && 
			 !codExoneracion.equals(Constants.COD_EXONERACION)) && indValDocAutoSenasa ) {
		 */
		if ( indValMrestri ) 
		{
			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);


			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			List<DatoRegPrecedencia> listRegPrecedencia =  serie.getListRegPrecedencia();

			//Inicio - PAS20155E220000371 la variable se va seteando x serie y en el metodo validarMercancia
			Map<String,Object> mapDocAutorizPreceDeposito = (Map<String, Object>) variablesIngreso.get("mapDocAutorizPreceDeposito");
			List<Map<String,Object>> lstDocAutorizPreceDeposito = null;

			if(mapDocAutorizPreceDeposito != null && serie.getNumserie().toString().equals(mapDocAutorizPreceDeposito.get("numeroSerie").toString().trim())){
				lstDocAutorizPreceDeposito = (List<Map<String, Object>>) mapDocAutorizPreceDeposito.get("lstDocAutorizPreceDeposito");
			}
			//Fin - PAS20155E220000371

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				if (validaEntidadTipoDocAutoriza(docAutorizante, fechaReferencia)) {
					if (docAutorizante.getFecvencimiento()==null) {
						listErrores.add(catalogoAyudaService.getError("35323", new String []{serie.getNumserie().toString()}));
					}

					if ( !CollectionUtils.isEmpty(listRegPrecedencia) ) {
						//Inicio - PAS20155E220000371
						boolean docAutRegPre  = false;

						List<Map<String, Object>> lstDocAutorizPrece = null;
						if(lstDocAutorizPreceDeposito != null){
							lstDocAutorizPrece = lstDocAutorizPreceDeposito;
						}else{
							lstDocAutorizPrece = this.getListDocAutorizPreceDeposito(serie, docAutorizante.getCodentidad());
						}

						if(!CollectionUtils.isEmpty(lstDocAutorizPrece)){
							for(Map<String,Object> docAutorizantePrece : lstDocAutorizPrece){
								if(docAutorizante.getCodentidad().equals(docAutorizantePrece.get("CODI_ENTI")) && 
										docAutorizante.getCodtipodocum().equals(docAutorizantePrece.get("CODI_DOCUM")) && 
										docAutorizante.getAnndocum().substring(2, 4).equals(docAutorizantePrece.get("ANOAUT").toString()) && 
										docAutorizante.getNumdocum().equals(docAutorizantePrece.get("NUMAUT")) &&
										(docAutorizantePrece.get("FEEMIAUT") != null && 
										SunatDateUtils.getFormatDate(docAutorizante.getFecemision(), "yyyyMMdd").equals(docAutorizantePrece.get("FEEMIAUT").toString()))){
									docAutRegPre = true;
									break;
								}	
							}
						}
						//Fin - PAS20155E220000371

						//PAS20155E220000371 - Se comento porque el regimen precedente deposito se debe validar en el asigad 
						/*boolean docAutRegPre  = false;
						for (DatoRegPrecedencia regPrecedente : listRegPrecedencia) {
							Map<String, Object> param = new HashMap<String, Object>();
							param.put("numCorreDoc", regPrecedente.getNumcorredoc());
							param.put("indDocAutoUsado", Constants.IND_DOCAUT_PERTENECE_DECLARACION);
							List<DatoDocAutorizante> lstDatoDocAutorizante= validarUsoDocAutorizante(docAutorizante, param);
							if (!CollectionUtils.isEmpty(lstDatoDocAutorizante)){
								docAutRegPre = true;
								break;
							}
						}*/
						if (!docAutRegPre) {
							listErrores.add(catalogoAyudaService.getError("35324", new String []{serie.getNumserie().toString()}));
						}
					}
				}		
			}
		}

		return listErrores;
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Valida la interconexi�n de documentos de control con SENASA
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9114, descServicio="Valida interconexi�n de documentos de control")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9114,numSecEjec=14,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarInterconexionSenasa(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		String codExoneracion  = serie.getMercancia()==null ? "" : serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		DUA dua = (DUA)serie.getPadre();
		String codRegimen = dua.getCodregimen();
		String numDocIdentidad = dua.getDeclarante().getNumeroDocumentoIdentidad();
		String codAduana = dua.getCodaduanaorden();
		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");
		Boolean indValDocAutoSenasa = (Boolean)variablesIngreso.containsKey("indValDocAutoSenasa")==true ? (Boolean)variablesIngreso.get("indValDocAutoSenasa") : true;   
		String codTransaccion = SunatStringUtils.substring(String.valueOf(variablesIngreso.get("codTransaccion")),2,4);//arey pase10

		if ( indValMrestri && (!codExoneracion.equals(Constants.COD_EXONERACION_INFO) && 
				!codExoneracion.equals(Constants.COD_EXONERACION)) && indValDocAutoSenasa && 
				codAduana.equals(Constants.COD_ADUANA_MARITIMA_CALLAO)) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			List<DatoRegPrecedencia> listRegPrecedencia =  serie.getListRegPrecedencia();
			//DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
			ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");

			boolean indDocuAutorizaPermitido = true;
			/**Inicio de cambios arey PAS20155E220200010**/
			String codTipoTratamiento = dua.getCodtipotratamiento()==null ? "" : dua.getCodtipotratamiento();
			boolean tieneTratamientoDonacion=false; 
			if(codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO)){
				tieneTratamientoDonacion=true;
			}
			/**Fin de cambios arey PAS20155E220200010**/

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

				/***Inicio cambios VUCE***/	
				String tipoValidacion= " ";
				tipoValidacion=obtenerTipoValidacionDocumentoAutorizante(docAutorizante,fechaReferencia,variablesIngreso, codRegimen);
				if(tipoValidacion.equals("vuce")){
					continue;
				}
				/***Fin cambios VUCE***/				

				if (validaEntidadTipoDocAutoriza(docAutorizante, fechaReferencia)) 
				{
					boolean indRegPreceDocAuto = false;
					//boolean indRegPreDepAduanero = false; //PAS20155E220300001 se comenta

					if (SunatStringUtils.length(docAutorizante.getAnndocum())>3){
						docAutorizante.setAnndocum(docAutorizante.getAnndocum().substring(0,4));
					}else{
						docAutorizante.setAnndocum(docAutorizante.getAnndocum());
					}

					for (DatoRegPrecedencia regPrecedente : listRegPrecedencia) {
						if(Constants.REGIMEN_DEPOSITO.toString().equals(regPrecedente.getCodregipre())){ //PAS20155E220300001 - s�lo debe validar cuando r�gimen precedente sea 70 (DEPOSITO)
							/*Map<String, Object> param = new HashMap<String, Object>();
						param.put("numCorreDoc", regPrecedente.getNumcorredoc());
						param.put("numSerie", regPrecedente.getNumserie());
						param.put("codEntidad", docAutorizante.getCodentidad());
						param.put("annDocum", docAutorizante.getAnndocum());
						param.put("numDocum", docAutorizante.getNumdocum());
						param.put("codTipoDocum", docAutorizante.getCodtipodocum());
						param.put("codTipOper", Constants.COD_TIPOPER_DOCAUT);

						List<DatoDocAutorizante> lstDatoDocAutorizante= docAutAsociadoDAO.listDetDocAutorizante(param);*/
							CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");

							Map<String,Object> params = new HashMap<String,Object>();
							params.put("NUM_DECLARACION",Long.parseLong(regPrecedente.getNumdeclpre()));
							params.put("COD_ADUANA",regPrecedente.getCodaduapre());
							params.put("ANN_PRESEN", Integer.parseInt(regPrecedente.getAnndeclpre().substring(0, 4)) );
							params.put("COD_REGIMEN",regPrecedente.getCodregipre());

							Map<String, Object> cabDeclaraPrece = cabDeclaraDAO.findMapDUAByPk(params);

							if (cabDeclaraPrece == null){

								PolizadDAO polizadDAO = fabricaDeServicios.getService("polizadDAO");

								Map<String,Object> paramsPolizad=new HashMap<String,Object>();
								paramsPolizad.put("anoPrese", regPrecedente.getAnndeclpre().substring(2, 4));
								paramsPolizad.put("codiAduan", regPrecedente.getCodaduapre());
								paramsPolizad.put("numeCorre", SunatStringUtils.lpad(regPrecedente.getNumdeclpre(),6,'0'));
								List<Polizad> lstPolizad = polizadDAO.selectByMap(paramsPolizad);

								if(lstPolizad.isEmpty() &&  (!tieneTratamientoDonacion && !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS))){//ajuste arey PAS20155E220200010
									listErrores.add(catalogoAyudaService.getError("00124", new String[]{serie.getNumserie().toString(),params.get("COD_ADUANA").toString()+"-"+
											params.get("ANN_PRESEN").toString()+"-"+params.get("COD_REGIMEN").toString()+"-"+params.get("NUM_DECLARACION").toString() }));
									//continue;
									break;  //PAS20155E220300001
								}
							}						

							params=new HashMap<String,Object>();
							params.put("codi_aduan",regPrecedente.getCodaduapre());
							params.put("ano_prese",regPrecedente.getAnndeclpre().substring(0, 4));
							params.put("nume_corre",SunatStringUtils.lpad(regPrecedente.getNumdeclpre(),6,'0'));
							params.put("codi_regi",regPrecedente.getCodregipre());							
							params.put("codi_enti",docAutorizante.getCodentidad());
							params.put("codi_docum",docAutorizante.getCodtipodocum());
							params.put("anoaut",docAutorizante.getAnndocum().substring(2,4));
							params.put("numaut", docAutorizante.getNumdocum());
							params.put("codlug",regPrecedente.getCodaduapre());
							params.put("feemiaut",SunatDateUtils.getIntegerFromDate(docAutorizante.getFecemision()));							

							List<Map<String,Object>> lstDocAutorizPrece = (List<Map<String,Object>>) consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(params);

							if (!lstDocAutorizPrece.isEmpty()){
								indRegPreceDocAuto = true;
							}
							/*if (regPrecedente.getCodregipre().equals(Constants.REGIMEN_DEPOSITO)) { //PAS20155E220300001 - en este punto siempre es r�gimen precedente 70 (DEPOSITO)
							indRegPreDepAduanero = true;
							}*/
							break; //PAS20155E220300001
						}
					}
					//if (!indRegPreceDocAuto || !indRegPreDepAduanero) { //PAS20155E220300001 se comenta xq
					//De tener la serie r�gimen de precedencia �Deposito Aduanero�  entonces no se verifica la existencia del registro del documento de control autorizante, 
					//solo si en la serie correspondiente de la Declaraci�n del Regimen de Deposito se ha consignado el documento de control.
					if (!indRegPreceDocAuto) { //PAS20155E220300001
						CabMrDocAutorizDAO cabMrDocAutorizDAO = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");
						Map<String, Object> param = new HashMap<String, Object>();
						param.put("ccordoc", docAutorizante.getNumdocum());
						param.put("anodoc", docAutorizante.getAnndocum());
						param.put("codientidad", docAutorizante.getCodentidad());
						param.put("cregimen", codRegimen);
						List<Map<String, Object>> lstCabMrDocAutoriz = cabMrDocAutorizDAO.findMrDocAutorizBase(param);

						/**Inicio de Cambios Arey PAS20155E220200010**/
						boolean indPermitido = true;
						if(tieneTratamientoDonacion && dua.getCodregimen().equals(Constants.REGIMEN_IMPO_DEFINITIVA.toString()) && 
								(!docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) || !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION))){	

							int subtipo = new Integer(docAutorizante.getCodsubentidad().toString());
							if(subtipo==501 || subtipo==503){
								if(!docAutorizante.getCodtipodocum().equals(DOC_PERMISO_SANITARIO) && !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS))
									indPermitido=false;
								//indDocuAutorizaPermitido=false;
								if((docAutorizante.getCodtipodocum().equals("07") && codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION))){//gmontoya Pase 10 - 2015
									indPermitido=false;
								}
							}else if(subtipo==504){
								if(!docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION) && !docAutorizante.getCodtipodocum().equals(DOC_CERTIFICADO)
										&& !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS))
									indPermitido=false;
								//indDocuAutorizaPermitido=false;
								if((docAutorizante.getCodtipodocum().equals("07") && codTransaccion.equals(Constants.COD_TRANSAC_NUMERACION))){//gmontoya Pase 10 - 2015
									indPermitido=false;
								}
							}  
						}
						/**Inicio de Cambios Arey PAS20155E220200010**/

						if(indPermitido){
							/*Verifca que los datos transmitidos del doc. autorizante correspondan a los registrados en MRESTRI*/
							if (CollectionUtils.isEmpty(lstCabMrDocAutoriz) && !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){//ajuste arey PAS20155E220200010
								listErrores.add(catalogoAyudaService.getError("35319", new String []{serie.getNumserie().toString()}));
							}
							/*la serie tenga asociada el documento de control con el tipo 09 Permiso de Importaci�n*/
							if (!valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)){
								indDocuAutorizaPermitido = false;
							}

							//PAS20155E220000371 - SAU201510002000080
							/*Map<String, Object> mapDocAutoBio = null;
						BigDecimal vPesoAcumuladoAutorizado=BigDecimal.ZERO;
							 */

							if(!docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){//ajuste arey PAS20155E220200010
								for (Map<String, Object> mapCabMrestri : lstCabMrDocAutoriz) {
									/* El n�mero de RUC del importador indicado en la declaraci�n 
									 * sea el mismo que el consignado en el documento de control autorizante*/
									if (!((String)mapCabMrestri.get("librtribu")).equals(numDocIdentidad)){
										listErrores.add(catalogoAyudaService.getError("35321", new String []{serie.getNumserie().toString()}));
									}
									//SAU201510002000061
									//ACTUALMENTE SE ENCUENTRA VALIDANDO EN EL SDA INTERCONEXI�N CON SENASA QUE EL C�DIGO DE LA ADUANA DONDE SE NUMERA 
									//LA DUA DEBE DE SER LA MISMA QUE LA QUE FIGURA EN EL DOCUMENTO DE CONTROL REGISTRADA EN NUESTRA BASE DE DATOS, 
									//AL ENCONTRARSE INSCRITA CON EL C�DIGO DE ADUANA 000 VARIAS DE LAS AUTORIZACIONES DE ESTA ENTIDAD A FIN DE NO GENERAR 
									//MUCHOS RECHAZOS ES CONVENIENTE SE RETIRE TAL VALIDACI�N.
									/*if ( !((String)mapCabMrestri.get("codiaduan")).equals(codAduana) ){
								listErrores.add(catalogoAyudaService.getError("35327", new String []{serie.getNumserie().toString()}));
							}*/
									//PAS20155E220000371 - SAU201510002000080
									/*if ( !((String)mapCabMrestri.get("ctrlbio")).equals(Constants.IND_CONTROL_BIOLOGICO) ){ 
								// Si la mercanc�a tiene indicador de control biol�gico diferente a 1, 
								// verificar que el peso neto solicitado en la declaraci�n en la SPN respectiva 
								// no sea mayor que el saldo del documento de control autorizante
								mapDocAutoBio = mapCabMrestri;
							}*/

									//BigDecimal bdNumSerie = new  BigDecimal(serie.getNumserie().toString());

									//if( bdNumSerie.compareTo((BigDecimal)mapCabMrestri.get("numeserie"))==0){
									//vPesoAcumuladoAutorizado= SunatNumberUtils.sum(vPesoAcumuladoAutorizado, (BigDecimal)mapCabMrestri.get("cntPesoNeto"));
									//}
								}
							}//arey PAS20155E220200010

							/*if (mapDocAutoBio!=null) {

							BigDecimal vPesoUtilizadoActual = (BigDecimal)mapDocAutoBio.get("cntutil");
							BigDecimal vSaldoDePeso;
							if ( vPesoAcumuladoAutorizado == new BigDecimal(0) ) {
								vSaldoDePeso= vPesoUtilizadoActual;
							}else{
								vSaldoDePeso= SunatNumberUtils.diference(vPesoAcumuladoAutorizado, vPesoUtilizadoActual);
							}

							// [El peso neto a usarse debe ser menor o igual al Saldo por usarse del peso autorizado ]
							// Si el Peso Neto de la Serie es Mayor al Saldo del Peso Autorizado
							if(SunatNumberUtils.isGreaterThanParam(serie.getCntpesoneto(), vSaldoDePeso)){
								listErrores.add(catalogoAyudaService.getError("35322", new String []{serie.getNumserie().toString()}));
							}
						}

						param = new HashMap<String, Object>();
						List<DatoDocAutorizante> lstDatoDocAutorizante= validarUsoDocAutorizante(docAutorizante, param);
						if ( !CollectionUtils.isEmpty(lstDatoDocAutorizante) ) {
							listErrores.add(catalogoAyudaService.getError("35298", new String []{serie.getNumserie().toString()}));
						}*/


							Map<String,Object> params = new HashMap<String,Object>();					
							params.put("codi_enti",docAutorizante.getCodentidad());
							params.put("codi_docum",docAutorizante.getCodtipodocum());
							params.put("anoaut",docAutorizante.getAnndocum().substring(2,4));
							params.put("numaut", docAutorizante.getNumdocum());
							params.put("feemiaut",SunatDateUtils.getIntegerFromDate(docAutorizante.getFecemision()));							

							List<Map<String,Object>> lstDocAutorizUsados = (List<Map<String,Object>>) consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(params);

							if (lstDocAutorizUsados.isEmpty()) continue;						

							if(!lstDocAutorizUsados.isEmpty() &&  !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){//ajuste arey PAS20155E220200010)
								//validacion de permiso ya usados [RN 1027]
								listErrores.add(catalogoAyudaService.getError("35298", new String []{serie.getNumserie().toString()}));
							}//arey PAS20155E220200010
							//PAS20155E220000371 - SAU201510002000080
							/*if (mapDocAutoBio==null) continue;

						for (Map<String,Object> docAutorizUsados : lstDocAutorizUsados){
							BigDecimal pesoBrutoDocUsado = (BigDecimal) docAutorizUsados.get("PESO_BRUTO");
							vPesoAcumuladoAutorizado = vPesoAcumuladoAutorizado.add(pesoBrutoDocUsado);
						}

						//validacion de saldos de pesos [RN 1030]
						if (SunatNumberUtils.scaleHalfUp(vPesoAcumuladoAutorizado, 3).compareTo(SunatNumberUtils.scaleHalfUp(serie.getCntpesoneto(), 3)) == 1){
							listErrores.add(catalogoAyudaService.getError("35322", new String []{serie.getNumserie().toString()}));
						}*/
						}//arey
					}
				}				
			}
			if (!indDocuAutorizaPermitido) {
				listErrores.add(catalogoAyudaService.getError("35320", new String []{serie.getNumserie().toString() }));
			}
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida que la fecha de vencimiento del documento de control 
	 * no exceda los 180 d�as calendarios
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9115, descServicio="Valida que fecha de vencimiento no exceda los 180 d�as calendarios")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9115,numSecEjec=15,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutDiasUsoDeclara(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		String codServicio = obtenerCodigoServicioAnotacion(this);
		Long numCorreDoc =  declaracion.getNumeroCorrelativo();
		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");


		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					/* La vigencia del documento no debe pasar de 180 d�as */
					if (docAutorizante.getFecvencimiento() != null && docAutorizante.getFecemision() != null) {
						if (SunatDateUtils.getDiferenciaDiasCalendarios(docAutorizante.getFecvencimiento(), docAutorizante.getFecemision()) > 180 ){//gmontoya Pase 451 - 2015
							listErrores.add(catalogoAyudaService.getError("35328", new String []{serie.getNumserie().toString()}));
						}
					}

					/* Si la transacci�n no es numeraci�n, enviar� el numcorredoc y 
					 * activar� el indicador indDocAutoUsado para que no busque 
					 * documentos de autorizaci�n asociados al  numcorredoc enviado*/
					Map<String, Object> param = new HashMap<String, Object>();
					/*param.put("indDocAutoUsado", Constants.IND_DOCAUT_PERTENECE_DECLARACION);
					if (codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
						param.put("indDocAutoUsado", Constants.IND_DOCAUT_DIFERENTE_DECLARACION);
						param.put("numCorreDoc", numCorreDoc);
					}*/
					//PAS20155E220000487
					if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
						param.put("numCorreDoc", numCorreDoc);
						param.put("indDocAutoUsado", Constants.IND_DOCAUT_DIFERENTE_DECLARACION);
					}

					List<DatoDocAutorizante> lstDatoDocAutorizante= validarUsoDocAutorizante(docAutorizante, param);
					if ( !CollectionUtils.isEmpty(lstDatoDocAutorizante)) {
						param = new HashMap<String, Object>();
						param.put("numeroCorrelativo", lstDatoDocAutorizante.get(0).getNumcorredoc());
						CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
						DUA duaAux = cabDeclaraDAO.selectByNumCorredoc(param);
						listErrores.add(catalogoAyudaService.getError("35329", new String[]{serie.getNumserie().toString(), duaAux.getCodaduanaorden() +"-"+ duaAux.getAnnpresen() +"-"+ duaAux.getCodregimen() +"-"+
								SunatStringUtils.lpad(duaAux.getNumdocumento().toString(), 6, '0')}));
					}
				}
			}
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida la interconexi�n de documentos de control con DIGESA 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9116, descServicio="Valida la interconexi�n de documentos de control con DIGESA")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9116,numSecEjec=16,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarInterconexionDigesa(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		DUA dua = (DUA)serie.getPadre();
		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		String numDocIdentidad = dua.getDeclarante().getNumeroDocumentoIdentidad();
		String codAduana = dua.getCodaduanaorden();
		String codRegimen = dua.getCodregimen(); 
		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		/**Inicio de cambios arey PAS20155E220200010**/
		/*String codTipoTratamiento = dua.getCodtipotratamiento()==null ? "" : dua.getCodtipotratamiento();
		boolean tieneTratamientoDonacion=false; 
		if(codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO)){
			tieneTratamientoDonacion=true;
		}*/
		/**Fin de cambios arey PAS20155E220200010**/

		//En Rectificaci�n electr�nica antes del canal
		boolean indRectiAntesCanal = true;
		if (codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION)) {
			CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("numeroCorrelativo", declaracion.getNumeroCorrelativo());
			DUA duaAux = cabDeclaraDAO.selectByNumCorredoc(param);
			if (!SunatStringUtils.isEmpty(duaAux.getCodCanal())) {
				indRectiAntesCanal = false;
			}
		}

		if ( indValMrestri && ( codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION) || 
				(codTransaccion.endsWith(Constants.COD_TRANSAC_RECTIFICACION) && indRectiAntesCanal) ) && 
				codAduana.equals(Constants.COD_ADUANA_MARITIMA_CALLAO) ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

				/***Inicio cambios VUCE***/	
				String tipoValidacion= " ";
				tipoValidacion=obtenerTipoValidacionDocumentoAutorizante(docAutorizante,fechaReferencia,variablesIngreso, codRegimen);
				if(tipoValidacion.equals("vuce")){
					continue;
				}
				/***Fin cambios VUCE***/	


				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					//SAU201510002000047 //Si el Tipo de documento es �03� Certificado de Uso, no se valida el documento de control autorizante en la base de datos de SUNAT
					if (!docAutorizante.getCodtipodocum().equals("03")) {
						CabMrDocAutorizDAO cabMrDocAutorizDAO = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");
						Map<String, Object> param = new HashMap<String, Object>();

						if (SunatStringUtils.length(docAutorizante.getAnndocum())>3){
							docAutorizante.setAnndocum(docAutorizante.getAnndocum().substring(0,4));
						}else{
							docAutorizante.setAnndocum(docAutorizante.getAnndocum());
						}
						/*
					param.put("ccordoc", docAutorizante.getNumdocum());					
					param.put("anodoc", docAutorizante.getAnndocum());
					param.put("codientidad", docAutorizante.getCodentidad());
					param.put("cregimen", codRegimen);
					List<Map<String, Object>> lstCabMrDocAutoriz = cabMrDocAutorizDAO.findMrDocAutorizBase(param);
						 */
						String codTipoDocAux = docAutorizante.getCodtipodocum();
						param.put("codientidad", docAutorizante.getCodentidad());
						//SAU201510002000047 //Si el Tipo de documento es �03� Certificado de Uso, no se valida el documento de control autorizante en la base de datos de SUNAT
						/*if (docAutorizante.getCodtipodocum().equals("03")) {
						codTipoDocAux = "08";
						}*/
						param.put("ccoddoc", codTipoDocAux);
						param.put("anodoc", docAutorizante.getAnndocum());
						param.put("cregimen", codRegimen);
						param.put("codregsani", docAutorizante.getNumdocum());
						param.put("fecvigencia",SunatDateUtils.getIntegerFromDate(docAutorizante.getFecvencimiento()));

						List<Map<String, Object>> lstCabMrDocAutoriz = cabMrDocAutorizDAO.findMrDocAutorizDigesa(param);

						if ( CollectionUtils.isEmpty(lstCabMrDocAutoriz) && !docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){//ajuste arey PAS20155E220200010
							listErrores.add(catalogoAyudaService.getError("35319", new String []{serie.getNumserie().toString()}));
						}
						//verificar que la serie no tenga asociado el documento de control autorizante
						//					DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAO");
						//					param = new HashMap<String, Object>();
						//					param.put("codiEntidad", docAutorizante.getCodentidad());
						//					param.put("codTipDocum", docAutorizante.getCodtipodocum());
						//					param.put("numDocum", docAutorizante.getNumdocum());
						//					param.put("annDocum", docAutorizante.getAnndocum());
						//					param.put("codRegimen", codRegimen);
						//					param.put("numSerie",  serie.getNumserie().toString());
						//					List<DetMrDocAutoriz> lstDetMrDocAutoriz =  detMrDocAutorizDAO.listDetMrdocAutoriz(param);
						//					if ( CollectionUtils.isEmpty(lstDetMrDocAutoriz) ){
						//						listErrores.add(catalogoAyudaService.getError("35331", new String []{serie.getNumserie().toString()}));
						//					}
						/* El n�mero de RUC del importador indicado en la declaraci�n
						 * sea el mismo que el consignado en el documento de control autorizante*/
						if(!docAutorizante.getCodtipodocum().equals(DOC_AUTORIZACION_OTROS)){//ajuste arey PAS20155E220200010
							for (Map<String, Object> mapCabDocAuto : lstCabMrDocAutoriz) {
								if ( !((String)mapCabDocAuto.get("librtribu")).equals(numDocIdentidad) ) {
									listErrores.add(catalogoAyudaService.getError("35321", new String []{serie.getNumserie().toString()}));
								}
							}
						}//arey PAS20155E220200010
						Date fecNumeracion = SunatDateUtils.getCurrentDate();
						if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
							fecNumeracion = declaracion.getDua().getFecdeclaracion(); 
						}
						// La fecha de numeraci�n no debe ser mayor a la fecha de vencimiento
						if ( SunatDateUtils.esFecha1MayorQueFecha2(fecNumeracion, docAutorizante.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA) ) {
							listErrores.add(catalogoAyudaService.getError("35325", new String []{serie.getNumserie().toString()}));
						}
					}
				}
			}	
		}	
		return listErrores;
	}

	@Override
	/**
	 * Valida la transmici�n de la fecha de vencimiento del documento
	 * de control  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9117, descServicio="Valida fecha de vencimiento del documento control")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9117,numSecEjec=17,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarFecVencimiento(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");


		if ( indValMrestri) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					if (docAutorizante.getFecvencimiento()==null) {
						listErrores.add(catalogoAyudaService.getError("35323", new String []{serie.getNumserie().toString()}));
					}
				}
			}
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida que el documento de control se encuentre vigente a la
	 * fecha de numeraci�n
	 * de control  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9118, descServicio="Valida vigencia del documentro de control seg�n fecha denumeraci�n")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9118,numSecEjec=18,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarFecNumeracion(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");


		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					Date fecNumeracion = SunatDateUtils.getCurrentDate();
					if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
						fecNumeracion = declaracion.getDua().getFecdeclaracion(); 
					}
					//El documento de control debe encontrarse vigente a la fecha de numeraci�n
					if ( SunatDateUtils.esFecha1MayorQueFecha2(fecNumeracion, docAutorizante.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA) ) {
						listErrores.add(catalogoAyudaService.getError("35325", new String []{serie.getNumserie().toString()}));
					}
				}
			}
		}

		return listErrores;

	}

	@Override
	/**
	 * Valida que la fecha de vigencia no sea mayor de 01 a�o
	 * de control  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9119, descServicio="Valida que la fecha de vigencia no sea mayor de 01 a�o")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9119,numSecEjec=19,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarFecVencimientoAnio(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");


		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					//Date fecEmision =  docAutorizante.getFecemision();
					//Date fecVencimiento =  docAutorizante.getFecvencimiento();

					//Calendar cFecVencimiento = Calendar.getInstance();
					//Calendar cFecEmision = Calendar.getInstance();

					//cFecVencimiento.setTime(docAutorizante.getFecvencimiento());
					//cFecEmision.setTime(docAutorizante.getFecemision());

					Date fecEmisionAnio = SunatDateUtils.addYear(docAutorizante.getFecemision(), 1);

					if (SunatDateUtils.esFecha1MenorQueFecha2(fecEmisionAnio, docAutorizante.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA)){
						listErrores.add(catalogoAyudaService.getError("35332", new String []{serie.getNumserie().toString()}));
					} 					
					/* La vigencia del documento no debe pasar de 01 a�o (considerar bisiesto) */
					/*if (FechaBean.getDiferencia(cFecEmision, cFecVencimiento, Calendar.YEAR) > 1){
				    	listErrores.add(catalogoAyudaService.getError("35332", new String []{serie.getNumserie().toString()}));
				    }*/
				}
			}
		}
		return listErrores;
	}

	@Override
	/**
	 * Valida que la fecha de vigencia no sea mayor de 02 a�o
	 * de control  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9120, descServicio="Valida que la fecha de vigencia no sea mayor de 02 a�o")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9120,numSecEjec=20,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarFecVencimientoDosAnio(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");


		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {

					Date fecVencimiento =  docAutorizante.getFecvencimiento();
					Date fecEmision = SunatDateUtils.addYear(docAutorizante.getFecemision(), 2);					
					/* La vigencia del documento no debe pasar de 02 a�o (considerar bisiesto) */
					if (SunatDateUtils.esFecha1MenorQueFecha2(fecEmision, fecVencimiento, SunatDateUtils.COMPARA_SOLO_FECHA)){
						listErrores.add(catalogoAyudaService.getError("35333", new String []{serie.getNumserie().toString()}));
					}

				}
			}
		}
		return listErrores;
	}

	@Override
	/**
	 * Valida que no hayan transcurrido 7 d�as h�biles a la fecha de numeraci�n 
	 * contados desde la fecha de emisi�n del documento de control  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9121, descServicio="Valida que no hayan transcurrido 7 d�as h�biles a la fecha de numeraci�n")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9121,numSecEjec=21,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarFecNumeracionDias(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);	

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");


		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			DiasUtilesDAO diasUtilesDAO = (DiasUtilesDAO) fabricaDeServicios.getService("diasUtilesDAO");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					Date fecNumeracion = SunatDateUtils.getCurrentDate();
					if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
						fecNumeracion = declaracion.getDua().getFecdeclaracion(); 
					}
					Map<String,Object> params = new HashMap<String,Object>();
					params.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(docAutorizante.getFecemision()));
					params.put("FECHAHASTA", SunatDateUtils.getIntegerFromDate(fecNumeracion));
					params.put("TIPO", 1);
					params.put("INCLUYE", "N");
					params.put("SUSPENDE", "S");

					int diasDesdeEmision = Integer.parseInt(diasUtilesDAO.getSPDiasUtiles(params));

					if (diasDesdeEmision > Constants.DOCAUT_MR_SIETE_DIAS_HABILES){
						listErrores.add(catalogoAyudaService.getError("35330", new String []{serie.getNumserie().toString()}));
					}
				}
			}
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida que la declaraci�n tenga modalidad de despacho excepcional o urgente, 
	 * numerada despu�s de la fecha de llegada (este dato es transmitido en la declaraci�n 
	 * y se valida contra la que figura en el manifiesto de carga) 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9122, descServicio="Valida Que la declaraci�n tenga modalidad de despacho excepcional o urgente")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9122,numSecEjec=22,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarFecModalidadDeclara(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		DUA dua = (DUA)serie.getPadre();
		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		Date fecLLegada = dua.getManifiesto().getFectermino();
		String codModalidad = dua.getCodmodalidad();
		String codServicio = obtenerCodigoServicioAnotacion(this);
		Date fecNumeracion = SunatDateUtils.getCurrentDate();
		if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
			fecNumeracion = declaracion.getDua().getFecdeclaracion(); 
		}		

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");


		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					boolean indModalidad = false;
					if (codModalidad.equals(Constants.DESPACHO_EXCEPCIONAL) || ( codModalidad.equals(Constants.DESPACHO_URGENTE) && 
							SunatDateUtils.esFecha1MayorQueFecha2(fecNumeracion, fecLLegada, SunatDateUtils.COMPARA_SOLO_FECHA) )) {
						indModalidad = true;
					}
					if ( !indModalidad ){
						listErrores.add(catalogoAyudaService.getError("35334", new String []{serie.getNumserie().toString()}));
					}
				}
			}
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida que se consigne el subtipo del tipo de documento de control  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9123, descServicio="Valida que se consigne el subtipo del tipo de documento de control")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9123,numSecEjec=23,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarSubTipoDocumento(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		//String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if ( indValMrestri  ) {

			String codServicio = obtenerCodigoServicioAnotacion(this);

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			boolean indDocuAutorizaPermitido = false;
			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

				/***Inicio cambios VUCE***/       
				String tipoValidacion= " ";
				String codRegimen = ((DUA)serie.getPadre()).getCodregimen();
				tipoValidacion=obtenerTipoValidacionDocumentoAutorizante(docAutorizante,fechaReferencia,variablesIngreso, codRegimen);
				if(tipoValidacion.equals("vuce")){
					indDocuAutorizaPermitido = true;
					continue;
				}
				/***Fin cambios VUCE***/   

				//SAU201510002000041 - si el documento autorizante esta exonerado 98 no se debe validar
				if (docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) || 
						valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					indDocuAutorizaPermitido = true;
				}else{ 
					//si un documento autorizante cumplio (indDocuAutorizaPermitido = true) no significa que los demas tambien cumplan se debe validar a todos
					indDocuAutorizaPermitido = false; 
					break; //para que seguir evaluando si ya uno no cumplio
				}
			}
			if ( !CollectionUtils.isEmpty(lstDocAutorizaMrestri) && !indDocuAutorizaPermitido) {
				listErrores.add(catalogoAyudaService.getError("35335", new String []{serie.getNumserie().toString()}));
			}
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida que se consigne el subtipo del tipo de documento de control dinitivo  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9124, descServicio="Valida que se consigne el subtipo del tipo de documento de control dinitivo")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9124,numSecEjec=24,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarSubTipoDocDifinitivo(DatoSerie serie, Date fechaReferencia,Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		//String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if ( indValMrestri ) {

			String codServicio = obtenerCodigoServicioAnotacion(this);

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			boolean indDocuAutorizaPermitido = false;
			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

				/***Inicio cambios VUCE***/       
				String tipoValidacion= " ";
				String codRegimen = ((DUA)serie.getPadre()).getCodregimen();
				tipoValidacion=obtenerTipoValidacionDocumentoAutorizante(docAutorizante,fechaReferencia,variablesIngreso, codRegimen);
				if(tipoValidacion.equals("vuce")){
					indDocuAutorizaPermitido = true;
					continue;
				}
				/***Fin cambios VUCE***/   


				//SAU201510002000041 - si el documento autorizante esta exonerado 98 no se debe validar
				if (docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) || 
						valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					indDocuAutorizaPermitido = true;
				}else{
					//si un documento autorizante cumplio (indDocuAutorizaPermitido = true) no significa que los demas tambien cumplan se debe validar a todos
					indDocuAutorizaPermitido = false; 
					break; //para que seguir evaluando si ya uno no cumplio
				}
			}
			if ( !CollectionUtils.isEmpty(lstDocAutorizaMrestri) && !indDocuAutorizaPermitido) {
				listErrores.add(catalogoAyudaService.getError("35336", new String []{serie.getNumserie().toString()}));
			}
		}

		return listErrores;

	}

	@Override
	/**
	 * Valida que se consigne el subtipo del tipo de documento de control dinitivo  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9125, descServicio="Valida que se consigne el subtipo del tipo de documento de control dinitivo")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9125,numSecEjec=25,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarSubTipoDocTemporal(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		//String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if ( indValMrestri ) {

			String codServicio = obtenerCodigoServicioAnotacion(this);

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				//SAU201510002000041 - si el documento autorizante esta exonerado 98 no se debe validar
				if (!docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && 
						valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {
					Date fecNumeracion = SunatDateUtils.getCurrentDate();
					if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
						fecNumeracion = declaracion.getDua().getFecdeclaracion(); 
					}
					if (docAutorizante.getFecvencimiento()==null) {
						listErrores.add(catalogoAyudaService.getError("35323", new String []{serie.getNumserie().toString()}));
						docAutorizante.setFecvencimiento(SunatDateUtils.getDefaultDate());	
					}
					/*
					Calendar cFecVencimiento = Calendar.getInstance();
					Calendar cFecEmision = Calendar.getInstance();

					cFecVencimiento.setTime(docAutorizante.getFecvencimiento());
					cFecEmision.setTime(docAutorizante.getFecemision());

					//Que la vigencia del documento de control autorizante no sea mayor que 06 meses
					long fecVenciFecEmi = FechaBean.getDiferencia(cFecVencimiento,cFecEmision, Calendar. MONTH);
					String fecDiasExacta = FechaBean.calcularDiferenciaExcata(docAutorizante.getFecvencimiento(), docAutorizante.getFecemision());

					int iDias = 0;
					if (fecVenciFecEmi == 6) {
						int dd = fecDiasExacta.indexOf("DD");
						int mm = fecDiasExacta.indexOf("MM");
						String dias = fecDiasExacta.substring(mm+2, dd);
						iDias = Integer.parseInt(dias.trim().isEmpty()?"0":dias.trim());
					}
					 */
					Date fecEmisionMes = SunatDateUtils.addMonth(docAutorizante.getFecemision(), 6);

					if (SunatDateUtils.esFecha1MenorQueFecha2(fecEmisionMes, docAutorizante.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA))
					{
						listErrores.add(catalogoAyudaService.getError("35337", new String []{serie.getNumserie().toString()}));
					}
					if(SunatDateUtils.esFecha1MayorQueFecha2(fecNumeracion, docAutorizante.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA)){
						listErrores.add(catalogoAyudaService.getError("35325", new String []{serie.getNumserie().toString()}));
					}
				}
			}
		}

		return listErrores;
	}

	@Override
	/**
	 * Valida uso del documento de control y que el a�o de emisi�n sea el
	 * mismo que el a�o de numeraci�n de la declaraci�n  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9126, descServicio="Valida uso del documento de control y a�o de emision y numeraci�n")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9126,numSecEjec=26,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutAnioUsoDeclara(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);


			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> param = new HashMap<String, Object>();

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				if (valServicioSubTipoDocAutoriza(codServicio, docAutorizante, fechaReferencia, variablesIngreso)) {

					int annNumeracion = SunatDateUtils.getAnho(SunatDateUtils.getCurrentDate());
					int annEmision = SunatDateUtils.getAnho(docAutorizante.getFecemision());

					if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
						annNumeracion = SunatDateUtils.getAnho(declaracion.getDua().getFecdeclaracion());
						param.put("numCorreDoc", declaracion.getDua().getNumcorredoc());
						param.put("indDocAutoUsado", Constants.IND_DOCAUT_DIFERENTE_DECLARACION);
					}

					if ( annEmision != annNumeracion){
						listErrores.add(catalogoAyudaService.getError("35338", new String []{serie.getNumserie().toString()}));
					}

					List<DatoDocAutorizante> lstDatoDocAutorizante= validarUsoDocAutorizante(docAutorizante, param);
					if ( !CollectionUtils.isEmpty(lstDatoDocAutorizante) ) {
						param = new HashMap<String, Object>();
						param.put("numeroCorrelativo", lstDatoDocAutorizante.get(0).getNumcorredoc());
						CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
						DUA duaAux = cabDeclaraDAO.selectByNumCorredoc(param);
						String num_declaracion = duaAux.getCodaduanaorden() +"-"+ duaAux.getAnnpresen() +"-"+ duaAux.getCodregimen() +"-"+ SunatStringUtils.lpad(duaAux.getNumdocumento().toString(), 6, '0');
						listErrores.add(catalogoAyudaService.getError("35339", new String []{serie.getNumserie().toString(), num_declaracion}));
					}
				}
			}
		}

		return listErrores;


	}

	@Override
	/**
	 * Valida descripciones minimas de Pilas y Bater�as de Pilas
	 * formato B  
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9127, descServicio="Valida descripciones minimas de Pilas y Bater�as de Pilas")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9127,numSecEjec=27,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutCodExoDescripcion(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();


		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codServicio = obtenerCodigoServicioAnotacion(this);

		boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if ( indValMrestri  ) {
			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			boolean indCodExo98 = false;
			for (DatoDocAutorizante docAutoMrestri: lstDocAutorizaMrestri) {
				if (docAutoMrestri.getCodtipodocum().equals(Constants.COD_EXONERACION)) {
					indCodExo98 = true;
					break;
				}
			}

			if (indCodExo98) {

				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

				List<DatoItem>  lstDatoItem = obtenerListDatoSerieItem(serie);
				String strDesignacion = "I012,I013,I014,I015,I065,J012,J013,J014,J015,J065,A012,A013,A014,A015,A065";
				boolean indTipo, indForma, indDescrMinima;

				for (DatoItem datoItem : lstDatoItem) {
					List<DatoDescrMinima> lstDecrMinima = datoItem.getListDecrMinima();
					indTipo =  false;
					indForma = false;
					indDescrMinima = false;
					for (DatoDescrMinima datoDescrMinima : lstDecrMinima) {
						//if (datoDescrMinima.getCtipo().equals(Constants.COD_DESCRIP_CATALOGO)) {
						if (datoDescrMinima.getCodtipdescr().equals(Constants.COD_EVALUAR_TIPO)) {
							//Si el �tem es del tipo �MNR : Pilas y Bater�as de Pilas�
							if ( datoDescrMinima.getValtipdescri().equals("MNR") ) {
								indTipo = true;
							}
						}
						if (datoDescrMinima.getCodtipdescr().equals(Constants.COD_EVALUAR_FORMATO)) {
							//Si la forma es: �CIL : Cil�ndrica� o �CUR : Cuadrada o Rectangular
							if ( SunatStringUtils.isStringInList(datoDescrMinima.getValtipdescri(), "CIL,CUR") ) {
								indForma = true;
							}
						}
						if ( SunatStringUtils.isStringInList(datoDescrMinima.getValtipdescri(), strDesignacion) ) {
							//Si la designaci�n esta en la lista
							if ( indTipo && indForma && SunatStringUtils.isStringInList(datoDescrMinima.getValtipdescri(), strDesignacion) ) {
								indDescrMinima = true;
							}
						}
						//}
					}
					if (indTipo && indForma && indDescrMinima ) {
						listErrores.add(catalogoAyudaService.getError("35340", new String []{serie.getNumserie().toString()}));
						break;
					}
				}
			}
		}

		return listErrores;

	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Valida que no se transmita el c�digo de exoneraci�n �98�. De transmitirse el c�digo 98
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9128, descServicio="Valida que no se transmita el c�digo de exoneraci�n �98�. De transmitirse el c�digo 98")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9128,numSecEjec=28,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutNoCodExoneracion(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		//		if (variablesIngreso.containsKey("indExcluyeDIQBF")){
		//			if ((Boolean) variablesIngreso.get("indExcluyeDIQBF")){
		//				return listErrores;
		//			}
		//		}	

		//Obtiene el c�digo de exoneraci�n (80 / 98) 
		//String codExoneracion  = serie.getMercancia().getCodexoneracion()==null ? "" : serie.getMercancia().getCodexoneracion();

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if ( indValMrestri ) {
			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);


			if (CollectionUtils.isEmpty(lstDocAutorizaMrestri)) {
				List<MRestri> lstMRestri = (List<MRestri>) variablesIngreso.get("listMercRestringida");
				for (MRestri mrestri : lstMRestri) {
					if (mrestri.getCnan().toString().equals(Constants.SPN_ALCOHOL_METILICO)) {
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						listErrores.add(catalogoAyudaService.getError("35341", new String []{serie.getNumserie().toString()}));
						break;
					}
				}
			}

			for (DatoDocAutorizante docAutoMrestri: lstDocAutorizaMrestri) {
				if (docAutoMrestri.getCodtipodocum().equals(Constants.COD_EXONERACION)) {
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					listErrores.add(catalogoAyudaService.getError("35341", new String []{serie.getNumserie().toString()}));
					break;
				}
			}
		}

		return listErrores;


	}

	@Override
	/**
	 * Valida regimen precedente del documento de control sin tomar en cuenta c�digo de exoneraci�n
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9129, descServicio="Valida regimen precedente del documento de control sin c�digo de exoneraci�n")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9129,numSecEjec=29,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutRegPrecede(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		//		if (variablesIngreso.containsKey("indExcluyeDIQBF")){
		//			if ((Boolean) variablesIngreso.get("indExcluyeDIQBF")){
		//				return listErrores;
		//			}
		//		}	

		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		Long numCorreDoc = declaracion.getNumeroCorrelativo();
		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);


			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			DiasUtilesDAO diasUtilesDAO = (DiasUtilesDAO) fabricaDeServicios.getService("diasUtilesDAO");

			Map<String, Object> param = new HashMap<String, Object>();

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {

				if (!validaEntidadTipoDocAutoriza(docAutorizante, fechaReferencia)) continue;

				/* Si la transacci�n no es numeraci�n, enviar� el numcorredoc y activar� el 
				 * indicador indDocAutoUsado para que no busque documentos de autorizaci�n
				 * asociados al  numcorredoc enviado */
				param.clear(); //PAS20155E220000487
				//param.put("indDocAutoUsado", Constants.IND_DOCAUT_PERTENECE_DECLARACION); //PAS20155E220000487 - se usa solo con el numCorreDoc en la numeraci�n aun no existe
				Date fecNumeracion = SunatDateUtils.getCurrentDate();
				if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
					fecNumeracion = declaracion.getDua().getFecdeclaracion(); 
					param.put("indDocAutoUsado", Constants.IND_DOCAUT_DIFERENTE_DECLARACION);
					param.put("numCorreDoc", numCorreDoc);
				}
				List<DatoDocAutorizante> lstDatoDocAutorizante= validarUsoDocAutorizante(docAutorizante, param);
				if ( !CollectionUtils.isEmpty(lstDatoDocAutorizante)) {
					//param = new HashMap<String, Object>(); //PAS20155E220000487
					param.clear();
					param.put("numeroCorrelativo", lstDatoDocAutorizante.get(0).getNumcorredoc());
					CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
					DUA duaAux = cabDeclaraDAO.selectByNumCorredoc(param);
					listErrores.add(catalogoAyudaService.getError("35342", new String[]{serie.getNumserie().toString(), 
							duaAux.getCodaduanaorden() +"-"+ duaAux.getAnnpresen() +"-"+ duaAux.getCodregimen() +"-"+
									SunatStringUtils.lpad(duaAux.getNumdocumento().toString(), 6, '0')}));
				}

				List<DatoRegPrecedencia> listRegPrecedencia =  serie.getListRegPrecedencia();
				boolean docAutRegPre = false;

				for (DatoRegPrecedencia regPrecedente : listRegPrecedencia) {
					lstDatoDocAutorizante.clear();
					if (regPrecedente.getCodregipre().equals(Constants.REGIMEN_DEPOSITO)) {
						param.put("numCorreDoc", regPrecedente.getNumcorredoc());
						param.put("indDocAutoUsado", Constants.IND_DOCAUT_PERTENECE_DECLARACION);
						lstDatoDocAutorizante= validarUsoDocAutorizante(docAutorizante, param);
						if ( !CollectionUtils.isEmpty(lstDatoDocAutorizante)) {
							docAutRegPre = true;
							break;
						}
					}
				}
				if ( !docAutRegPre ) {
					if (SunatDateUtils.esFecha1MayorQueFecha2(fecNumeracion, docAutorizante.getFecvencimiento(), SunatDateUtils.COMPARA_SOLO_FECHA)) {
						listErrores.add(catalogoAyudaService.getError("35325", new String[]{serie.getNumserie().toString()}));
					}
					param = new HashMap<String,Object>();
					param.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(docAutorizante.getFecemision()));
					param.put("FECHAHASTA", SunatDateUtils.getIntegerFromDate(fecNumeracion));
					param.put("TIPO", 1);
					param.put("INCLUYE", "N");
					param.put("SUSPENDE", "S");

					int diasDesdeEmision = Integer.parseInt(diasUtilesDAO.getSPDiasUtiles(param));

					if (diasDesdeEmision > Constants.DOCAUT_MR__SESENTA_DIAS_HABILES){
						listErrores.add(catalogoAyudaService.getError("35343", new String[]{serie.getNumserie().toString()}));
					}

				}
			}
		}

		return listErrores;


	}

	@Override
	/**
	 * Valida  Se valida que la fecha de la numeraci�n de la Declaraci�n respecto 
	 * a la fecha de la Resoluci�n Directoral de Autorizaci�n de 
	 * Importaci�n debe ser como m�ximo un a�o
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return listErrores
	 */
	@ServicioAnnot(tipo="V",codServicio=9130, descServicio="Valida fecha numeraci�n y fecha de resoluci�n")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9130,numSecEjec=30,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarDocAutFecNumDeclara(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		String codTransaccion = declaracion.getCodtipotrans();
		if (SunatStringUtils.isEmpty(codTransaccion)) {
			codTransaccion = (String)variablesIngreso.get("codTransaccion"); 
		}

		String codServicio = obtenerCodigoServicioAnotacion(this);

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if ( indValMrestri ) {

			//Obtiene lista con los documentos Autorizantes por SubEntidad
			List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			Date fecNumeracion = SunatDateUtils.getCurrentDate();
			if (!codTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)) {
				fecNumeracion = declaracion.getDua().getFecdeclaracion(); 
			}

			for (DatoDocAutorizante docAutorizante : lstDocAutorizaMrestri) {
				//gg vuce no ejecutar si es vuce
				String tipoValidacion = obtenerTipoValidacionDocumentoAutorizante(docAutorizante, fechaReferencia, variablesIngreso, declaracion.getDua().getCodregimen());
				if(tipoValidacion.equals("vuce")){
					continue;
				}

				if (!docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION)) 
				{
					Date fecEmision = SunatDateUtils.addYear(docAutorizante.getFecemision(), 1);					
					/* La diferencia en d�as no debe pasar de 01 a�o (considerar bisiesto) */
					if (SunatDateUtils.esFecha1MenorQueFecha2(fecEmision, fecNumeracion, SunatDateUtils.COMPARA_SOLO_FECHA)){
						listErrores.add(catalogoAyudaService.getError("35332", new String[]{serie.getNumserie().toString()}));
					}
				}
			}

		}

		return listErrores;
	}

	@SuppressWarnings("unchecked")
	@Override
	/** Verificar que la declaracion de deposito precedente tenga registrada el documento IQBF y que se encuentre concluida 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9131, descServicio="Validar declaracion precedente deposito")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9131,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")
	public List<Map<String, String>> validarPrecedenteDepositoDocAut(DatoSerie serie, Date fechaReferencia,
			Map<String, Object> variablesIngreso) {

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indExcluyeIQBFDua")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBFDua")){
				return lstErrores;
			}
		}
		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if (!indValMrestri) return lstErrores;

		String codServicio = obtenerCodigoServicioAnotacion(this);

		String codModalidad = ((DUA) serie.getPadre()).getCodmodalidad(); 
		List<DatoRegPrecedencia> lstPreceDua = serie.getListRegPrecedencia();

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		boolean indDocuPrece = false;
		//PAS20155E220300013 esta validaci�n ya se realiza en el metodo validarSubEntidadesDocAutorizaPrecedente
		for(DatoRegPrecedencia preceDua : lstPreceDua){
			if (preceDua.getCodregipre().equals(Constants.REGIMEN_DEPOSITO.toString()) && 
					codModalidad.equals(Constants.DESPACHO_EXCEPCIONAL)){
				indDocuPrece = true;
				List<DatoDocAutorizante> lstDocAutorizaMRestri = obtenerListaDocAutorizaMRestri(serie,fechaReferencia,variablesIngreso,codServicio);

				for (DatoDocAutorizante docAutoriza : lstDocAutorizaMRestri){
					if (valServicioSubTipoDocAutoriza (codServicio,docAutoriza, fechaReferencia, variablesIngreso)){
						//Validaci�n r�gimen precedente Deposito [RN 1179]
						CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
						Map<String,Object> params = new HashMap<String,Object>();
						params.put("NUM_DECLARACION",Long.parseLong(preceDua.getNumdeclpre()));
						params.put("COD_ADUANA",preceDua.getCodaduapre());
						params.put("ANN_PRESEN", Integer.parseInt(preceDua.getAnndeclpre().substring(0, 4)) );
						params.put("COD_REGIMEN",preceDua.getCodregipre());

						Map<String, Object> cabDeclaraPrece = cabDeclaraDAO.findMapDUAByPk(params);

						if (cabDeclaraPrece == null){

							PolizadDAO polizadDAO = fabricaDeServicios.getService("polizadDAO");

							Map<String,Object> paramsPolizad=new HashMap<String,Object>();
							paramsPolizad.put("anoPrese", preceDua.getAnndeclpre().substring(2, 4));
							paramsPolizad.put("codiAduan", preceDua.getCodaduapre());
							paramsPolizad.put("numeCorre", SunatStringUtils.lpad(preceDua.getNumdeclpre(),6,'0'));
							List<Polizad> lstPolizad = polizadDAO.selectByMap(paramsPolizad);

							if(lstPolizad.isEmpty()){
								lstErrores.add(catalogoAyudaService.getError("00124", new String[]{serie.getNumserie().toString(),params.get("COD_ADUANA").toString()+"-"+
										params.get("ANN_PRESEN").toString()+"-"+params.get("COD_REGIMEN").toString()+"-"+params.get("NUM_DECLARACION").toString() }));
								continue;
							}
						}

						if(!docAutoriza.getCodtipodocum().equals(Constants.COD_EXONERACION)){//<KAH - RIN14>
							ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");
							params=new HashMap<String,Object>();
							params.put("codi_aduan",preceDua.getCodaduapre());
							params.put("ano_prese",preceDua.getAnndeclpre().substring(0, 4));
							params.put("nume_corre",SunatStringUtils.lpad(preceDua.getNumdeclpre(),6,'0'));
							params.put("codi_regi",preceDua.getCodregipre());							
							/*params.put("codi_enti",docAutoriza.getCodentidad());
							params.put("codi_docum",docAutoriza.getCodtipodocum());
							params.put("anoaut",docAutoriza.getAnndocum().substring(2,4));
							params.put("numaut", docAutoriza.getNumdocum());
							params.put("codlug",preceDua.getCodaduapre());
							params.put("feemiaut",SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));*/

							List<Map<String,Object>> lstDocAutorizPrece = (List<Map<String,Object>>) consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(params);

							if (lstDocAutorizPrece.isEmpty()){
								lstErrores.add(catalogoAyudaService.getError("35373", new String[]{serie.getNumserie().toString()}));
								continue;
							}

							CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");

							for (Map<String,Object> docAutorizPrece :lstDocAutorizPrece){

								params = new HashMap<String,Object>();
								params.put("codientidad", docAutorizPrece.get("CODI_ENTI"));
								params.put("ccoddoc", docAutorizPrece.get("CODI_DOCUM"));
								params.put("ccordoc", docAutorizPrece.get("NUMAUT"));
								params.put("anodoc", docAutorizPrece.get("ANOAUT"));
								params.put("codiAduana", docAutorizPrece.get("CODLUG"));
								//<KAH - RIN14>
								CabMrDocAutoriz docAutoPreceDuaBD = cabMrDocAutorizDao.getCabMrDocAutoriz(params);
								if (docAutoPreceDuaBD == null){ //&& !docAutorizPrece.get("CODI_DOCUM").toString().equals(Constants.COD_EXONERACION)){//adicionado por PAS20155E220000306 - SAU201510002000033
									lstErrores.add(catalogoAyudaService.getError("35357",new String[] {serie.getNumserie().toString()}));
									continue;
								}
								//<KAH - RIN14>
								if ( docAutoPreceDuaBD!=null && !docAutoPreceDuaBD.getCodEstAut().equals(Constants.EST_DOCAUT_CONCLUIDA) && !verificarExisteError(lstErrores,"35374")){
									//&& !docAutorizPrece.get("CODI_DOCUM").toString().equals(Constants.COD_EXONERACION)){//adicionado por PAS20155E220000306 - SAU201510002000033
									lstErrores.add(catalogoAyudaService.getError("35374", new String[]{serie.getNumserie().toString()}));
								} 

							}
						}




						/*preceDua.setNumcorredoc(SunatNumberUtils.toLong(cabDeclaraPrece.get("NUM_CORREDOC")));

					  DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");

					  params = new HashMap<String,Object>();
					  params.put("numCorreDoc",preceDua.getNumcorredoc());
					  params.put("codTipoOper",docAutoriza.getCodTipoOper());
					  params.put("codTipoDocum",docAutoriza.getCodtipodocum());
					  params.put("codEntidad",docAutoriza.getCodentidad());
					  params.put("numDocum",docAutoriza.getNumdocum());
					  if (SunatStringUtils.length(docAutoriza.getAnndocum())>3){
							params.put("annDocum",docAutoriza.getAnndocum().substring(0,4));
					  }else{
			    	    	params.put("annDocum",docAutoriza.getAnndocum());
					  }
					  params.put("fecEmision",docAutoriza.getFecemision());
					  params.put("indDocAutoUsado",Constants.IND_DOCAUT_PERTENECE_DECLARACION);
					  params.put("indDel", Constants.INDICADOR_NO_ELIMINADO);

					  List<DatoDocAutorizante> lstDocAutoPreceDua = docAutAsociadoDAO.listDocAutorizante(params);

					  if (CollectionUtils.isEmpty(lstDocAutoPreceDua)){
						  lstErrores.add(catalogoAyudaService.getError("35373", new String[]{serie.getNumserie().toString()}));
					  }	else {
						  CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");
						  for (DatoDocAutorizante docAutoPreceDua : lstDocAutoPreceDua){
							  params = new HashMap<String,Object>();
							  params.put("codientidad", docAutoPreceDua.getCodentidad());
							  params.put("ccoddoc", docAutoPreceDua.getCodtipodocum());
							  params.put("ccordoc", docAutoPreceDua.getNumdocum());
							  params.put("anodoc", docAutoPreceDua.getAnndocum());
//							  params.put("cregimen", preceDua.getCodregipre());
//							  params.put("fecemis", docAutoPreceDua.getFecemision());
							  params.put("codiAduana", preceDua.getCodaduapre());

							  CabMrDocAutoriz docAutoPreceDuaBD = cabMrDocAutorizDao.getCabMrDocAutoriz(params);

							  if ( !docAutoPreceDuaBD.getCodEstAut().equals(Constants.EST_DOCAUT_CONCLUIDA)){
								  lstErrores.add(catalogoAyudaService.getError("35374", new String[]{serie.getNumserie().toString()}));
							  }
						   }
					  }*/
					}
				}

			}

		}
		if (indDocuPrece){
			variablesIngreso.put("indExcluyeIQBF",true);
		} else {
			variablesIngreso.remove("indExcluyeIQBF");
		}
		return lstErrores;
	}

	@Override
	/** Validar que se haya declarado los documentos autorizantes necesarios para validar las mercanc�as restringidas de los documento IQBF
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9132, descServicio="Validar documentos permitidos para mercancia restringida")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9132,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")	
	public List<Map<String, String>> validarDocAutPermitidosIQBF(DatoSerie serie, Date fechaReferencia,
			Map<String, Object> variablesIngreso) {

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indExcluyeIQBFDua")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBFDua")){
				return lstErrores;
			}
		}

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if (!indValMrestri) return lstErrores;

		String codServicio = obtenerCodigoServicioAnotacion(this);

		lstErrores.addAll(validarDocAutServicioSubEntidad(serie,codServicio,"35354",fechaReferencia,variablesIngreso));

		return lstErrores;
	}

	@Override
	/** Verifica que el documento cumpla con las reglas de negocio para modalidad anticipada, reutilizaci�n de un documento autorizante y 
	 * validaciones entre la fecha de emisi�n del documento contra la fecha de llegada y la fecha de numeraci�n de la declaraci�n
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9133, descServicio="Validar indicador regularizacion y fecha de emision del documento")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9133,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")	
	public List<Map<String, String>> valIndicadorRegularizaFecEmisionDocAut(
			DatoSerie serie, Date fechaReferencia,
			Map<String, Object> variablesIngreso) {

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indExcluyeIQBFDua")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBFDua")){
				return lstErrores;
			}
		}

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if (!indValMrestri) return lstErrores;

		String codServicio = obtenerCodigoServicioAnotacion(this);		
		DUA dua = (DUA) serie.getPadre();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		List<DatoDocAutorizante> lstDocAutorizaMRestri = obtenerListaDocAutorizaMRestri(serie,fechaReferencia,variablesIngreso,codServicio);

		for (DatoDocAutorizante docAutoriza : lstDocAutorizaMRestri){
			if (valServicioSubTipoDocAutoriza(codServicio,docAutoriza, fechaReferencia, variablesIngreso)){
				boolean validaIndRegula = false;

				//Validaci�n indicador regularizable 02 [RN 1162A]
				if (Constants.DESPACHO_ANTICIPADO.equals(dua.getCodmodalidad())){
					for (DatoIndicadores indicadores : dua.getListIndicadores()){
						if (Constantes.IND_DUA_REQ_REGULARIZ.equals(indicadores.getCodtipoindica())){
							validaIndRegula = true;
						}
					}

					if (!validaIndRegula){
						lstErrores.add(catalogoAyudaService.getError("35355",new String[] {serie.getNumserie().toString()}));
					}
				}
				Map<String,Object> params = new HashMap<String,Object>();

				CabMrDocAutoriz cabMrDocAutoriz = new CabMrDocAutoriz();				
				CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");

				params = new HashMap<String,Object>();
				params.put("codiEntidad", docAutoriza.getCodentidad());
				params.put("ccoddoc", docAutoriza.getCodtipodocum());
				params.put("ccordoc", docAutoriza.getNumdocum());
				if (SunatStringUtils.length(docAutoriza.getAnndocum())>3){
					params.put("anodoc",docAutoriza.getAnndocum().substring(0,4));
				}else{
					params.put("anodoc",docAutoriza.getAnndocum());
				}

				cabMrDocAutoriz = cabMrDocAutorizDao.getCabMrDocAutoriz(params);

				if (cabMrDocAutoriz != null){				
					boolean indDocAutoUsado = true;

					if (SunatStringUtils.isEmptyTrim(cabMrDocAutoriz.getAnnPrese()) &&
							SunatStringUtils.isEmptyTrim(cabMrDocAutoriz.getNumCorre()) &&
							SunatStringUtils.isEmptyTrim(cabMrDocAutoriz.getCodRegDcl()) ) {

						indDocAutoUsado = false;

					} else if (dua.getNumcorredoc() != null){

						CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
						params = new HashMap<String,Object>();
						params.put("NUM_CORREDOC",dua.getNumcorredoc());

						Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(params);

						if (cabMrDocAutoriz.getAnnPrese().equals(cabDeclara.get("ANN_PRESEN").toString()) &&
								cabMrDocAutoriz.getNumCorre().equals(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0')) &&
								cabMrDocAutoriz.getCodRegDcl().equals(dua.getCodregimen()) &&
								cabMrDocAutoriz.getCodiAduan().equals(dua.getCodaduanaorden())){

							indDocAutoUsado = false;							
						}
					}

					if (indDocAutoUsado){
						String cadDeclaracion = cabMrDocAutoriz.getCodiAduan()+" - "+cabMrDocAutoriz.getAnnPrese()+" - "+cabMrDocAutoriz.getCodRegDcl()+" - "+cabMrDocAutoriz.getNumCorre();					  
						lstErrores.add(catalogoAyudaService.getError("35360",new String[] {serie.getNumserie().toString(), cadDeclaracion})); 					  
					}
				} 

				//Validaci�n fecha de emisi�n documento autorizante IQBF menor a fecha de llegada [RN 1170]
				if ((Constants.DESPACHO_EXCEPCIONAL.equals(dua.getCodmodalidad()) || Constants.DESPACHO_URGENTE.equals(dua.getCodmodalidad())) && 
						(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()) > SunatDateUtils.getIntegerFromDate(dua.getManifiesto().getFectermino()) ) ){
					lstErrores.add(catalogoAyudaService.getError("35362",new String[] {serie.getNumserie().toString()}));
				}
				String tipoTransaccion = variablesIngreso.get("codTransaccion").toString().substring(2,4); 
				Date fecNumeracion = fechaReferencia;
				if (!Constants.COD_TRANSAC_NUMERACION.equals(tipoTransaccion)) {

					CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
					params = new HashMap<String,Object>();
					params.put("NUM_CORREDOC",dua.getNumcorredoc());

					Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(params);

					fecNumeracion = (Date) cabDeclara.get("FEC_DECLARACION");
				}

				//Validaci�n fecha de emisi�n de documento autorizante IQBF menor a fecha de numeracion [RN 1171]
				if ((Constants.DESPACHO_ANTICIPADO.equals(dua.getCodmodalidad()) || Constants.DESPACHO_URGENTE.equals(dua.getCodmodalidad())) &&
						(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()) > SunatDateUtils.getIntegerFromDate(fecNumeracion) ) ){
					lstErrores.add(catalogoAyudaService.getError("35363",new String[] {serie.getNumserie().toString()}));
				}
			}
		}

		return lstErrores;
	}

	@Override

	/**Verifica que el documento declarado coincida con los datos registrados por las entidades autorizantes 
	 * en cuanto al RUC del beneficiario/Importador, aduana de la declaracion, numero y item del documento autorizante 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9134, descServicio="Validar cabecera del documento autorizante")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9134,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")	
	public List<Map<String, String>> validarCabDocAutorizaEntidad(DatoSerie serie, Date fechaReferencia,
			Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indExcluyeIQBFDua")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBFDua")){
				return lstErrores;
			}
		}		
		//RIN14 CUS14.04 mpoblete
		obtenerListaMercRestringida(serie,fechaReferencia,variablesIngreso);
		//RIN14 CUS14.04 mpoblete

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if (!indValMrestri) return lstErrores;

		DUA dua = (DUA) serie.getPadre();
		String codServicio = obtenerCodigoServicioAnotacion(this);

		//Lista de documentos autorizantes por mercanc�a restringida
		List<DatoDocAutorizante> lstDocAutorizaMRestri = obtenerListaDocAutorizaMRestri(serie,fechaReferencia,variablesIngreso,codServicio); 
		CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		for (DatoDocAutorizante docAutoriza : lstDocAutorizaMRestri){
			if (valServicioSubTipoDocAutoriza (codServicio,docAutoriza, fechaReferencia, variablesIngreso)){

				Map<String,Object> params = new HashMap<String,Object>();
				params.put("codiEntidad", docAutoriza.getCodentidad());
				params.put("ccoddoc", docAutoriza.getCodtipodocum());
				params.put("ccordoc", docAutoriza.getNumdocum());
				if (SunatStringUtils.length(docAutoriza.getAnndocum())>3){
					params.put("anodoc",docAutoriza.getAnndocum().substring(0,4));
				}else{
					params.put("anodoc",docAutoriza.getAnndocum());
				}
				//				params.put("cregimen", dua.getCodregimen());
				//				params.put("fecEmis",SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
				//params.put("codiAduan", dua.getCodaduanaorden());

				CabMrDocAutoriz cabMrDocAutoriz = cabMrDocAutorizDao.getCabMrDocAutoriz(params);

				if (cabMrDocAutoriz == null){
					//Validacion existencia del documento [RN 1164]
					lstErrores.add(catalogoAyudaService.getError("35357",new String[] {serie.getNumserie().toString()}));
				} else {
					//Validaci�n RUC del documento [RN 1163]
					lstErrores.addAll(validarRucDocAutoriza(docAutoriza, dua.getCodaduanaorden(), dua.getCodregimen(), cabMrDocAutoriz ,dua.getDeclarante().getNumeroDocumentoIdentidad(),serie.getNumserie().toString()));

					//Validaci�n la aduana del documento [RN 1169]
					if (!dua.getCodaduanaorden().equals(cabMrDocAutoriz.getCodiAduan())){
						lstErrores.add(catalogoAyudaService.getError("35361",new String[] {serie.getNumserie().toString()}));
					}

					//Validaci�n Transmisi�n del nro de item de la autorizaci�n [RN 1172]					
					if (docAutoriza.getNroitemdocum() == null){
						lstErrores.add(catalogoAyudaService.getError("35364", new String[] {serie.getNumserie().toString()}));
					} else if (docAutoriza.getNroitemdocum() == 0){
						lstErrores.add(catalogoAyudaService.getError("35364", new String[] {serie.getNumserie().toString()}));
					}
				}
			}
		}

		return lstErrores;
	}

	@Override
	/**Verifica que el documento declarado coincida con los datos registrados por las entidades autorizantes 
	 * en cuanto a la partida arancelaria y unidad comercial, control de las cantidades y pesos del documento autorizante
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9135, descServicio="Valida detalle del documento autorizante")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9135,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")	
	public List<Map<String, String>> validarDetDocAutorizaEntidad(DatoSerie serie, Date fechaReferencia,
			Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indExcluyeIQBFDua")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBFDua")){
				return lstErrores;
			}
		}	

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if (!indValMrestri) return lstErrores;

		DUA dua = (DUA) serie.getPadre();
		String codServicio = obtenerCodigoServicioAnotacion(this);

		//Lista de documentos autorizantes por mercanc�a restringida
		List<DatoDocAutorizante> lstDocAutorizaMRestri = obtenerListaDocAutorizaMRestri(serie,fechaReferencia,variablesIngreso,codServicio); 

		Map<String,Object>  mapValoresSerie = new HashMap<String,Object>();

		mapValoresSerie.put("codAduana", dua.getCodaduanaorden());
		mapValoresSerie.put("codRegimen", dua.getCodregimen());
		mapValoresSerie.put("partNandi", serie.getNumpartnandi());
		mapValoresSerie.put("codUniComer", serie.getCodunicomer());
		mapValoresSerie.put("cntUniComer", serie.getCntunicomer());
		mapValoresSerie.put("cntPesoNeto", serie.getCntpesoneto());
		mapValoresSerie.put("codModalidad", dua.getCodmodalidad());
		mapValoresSerie.put("numSerie", serie.getNumserie().toString());
		//Rin 14 - INI - JYC
		//		if(dua.getPadre() == null){			
		//		mapValoresSerie.put("tipoTransaccion", "00");
		//	}else{
		//		mapValoresSerie.put("tipoTransaccion", ((Declaracion)dua.getPadre()).getCodtipotrans().substring(2,4));	
		//	}
		if(variablesIngreso.containsKey("codTransaccion")){
			mapValoresSerie.put("tipoTransaccion",variablesIngreso.get("codTransaccion").toString().substring(2,4)); 
		}else{
			mapValoresSerie.put("tipoTransaccion","");
		}



		//Rin 14 - FIN - JYC						
		lstErrores.addAll(validarSpnUnidadCantidadPesoDocAut(lstDocAutorizaMRestri, mapValoresSerie, codServicio, fechaReferencia, variablesIngreso));

		return lstErrores;
	}

	@Override
	/** Validar si el documento autorizante se encuentra vencido 
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9136, descServicio="Validar vencimiento del documento autorizante")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9136,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")	
	public List<Map<String, String>> validarVencimientoDocAut(DatoSerie serie,
			Date fechaReferencia, Map<String, Object> variablesIngreso) {

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indExcluyeIQBFDua")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBFDua")){
				return lstErrores;
			}
		}	

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		Boolean tienePrecedenteDeposito = false;

		if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
			for(DatoRegPrecedencia preceDua : serie.getListRegPrecedencia()){
				if(Constants.REGIMEN_DEPOSITO.toString().equals(preceDua.getCodregipre())){
					tienePrecedenteDeposito=true;
				}
			}
		}
		if (!indValMrestri || tienePrecedenteDeposito) return lstErrores; // PAS20175E220200053

		DUA dua = (DUA) serie.getPadre();
		String codServicio = obtenerCodigoServicioAnotacion(this);

		List<DatoDocAutorizante> lstDocAutorizaMRestri = obtenerListaDocAutorizaMRestri(serie,fechaReferencia,variablesIngreso,codServicio);

		for (DatoDocAutorizante docAutoriza : lstDocAutorizaMRestri){
			if (valServicioSubTipoDocAutoriza (codServicio, docAutoriza, fechaReferencia, variablesIngreso)) {

				CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");

				Map<String,Object> params = new HashMap<String,Object>();

				params.put("codiEntidad", docAutoriza.getCodentidad());
				params.put("ccoddoc", docAutoriza.getCodtipodocum());
				params.put("ccordoc", docAutoriza.getNumdocum());
				if (SunatStringUtils.length(docAutoriza.getAnndocum())>3){
					params.put("anodoc",docAutoriza.getAnndocum().substring(0,4));
				}else{
					params.put("anodoc",docAutoriza.getAnndocum());
				}
				//				params.put("cregimen", dua.getCodregimen());
				//				params.put("fecEmis",SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
				params.put("codiAduan", dua.getCodaduanaorden());

				CabMrDocAutoriz cabMrDocAutoriz = cabMrDocAutorizDao.getCabMrDocAutoriz(params);

				if (cabMrDocAutoriz!=null){

					//Validacion de Documento Vencido  [RN 1165, RN 1166]

					//DiasUtilesDAO diasUtilesDAO = (DiasUtilesDAO) fabricaDeServicios.getService("diligencia.ingreso.diasUtilesDef");

					params = new HashMap<String,Object>();
					//params.put("FECHADESDE", cabMrDocAutoriz.getFecEmis()); 
					params.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(cabMrDocAutoriz.getFecEmiAut())); //PAS20155E220000487
					params.put("FECHAHASTA", SunatDateUtils.getIntegerFromDate(fechaReferencia));
					params.put("TIPO", 1);
					params.put("INCLUYE", "N");
					params.put("SUSPENDE", "S");

					int diasDesdeEmision = Integer.parseInt(((DiasUtilesDAO)fabricaDeServicios.getService("diasUtilesDAO")).getSPDiasUtiles(params));
					//int diasDesdeEmision = 1;//Integer.parseInt(diasUtilesDAO.getSPDiasUtiles(params));

					if (diasDesdeEmision > Constants.DOCAUT_IQBF_DIAS_VIGENCIA){
						lstErrores.add(((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35358", new String[] {serie.getNumserie().toString()}));
					}					
				}				
			}
		}
		return lstErrores;
	}

	@Override
	@SuppressWarnings("unchecked")
	/** Validar si el documento autorizante se encuentra en estado otorgada o destinada
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9137, descServicio="Validar estado del documento autorizante")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9137,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")		
	public List<Map<String, String>> validarEstadoDocAutoriza(DatoSerie serie,
			Date fechaReferencia, Map<String, Object> variablesIngreso) {

		//FCO - Se agrega metodo para traer serie de variablesIngreso para casos de transaccion 04
		serie = obtenerSerieReguAnticipado(serie, variablesIngreso);

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indExcluyeIQBFDua")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBFDua")){
				return lstErrores;
			}
		}	

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if (!indValMrestri) return lstErrores;

		DUA dua = (DUA) serie.getPadre();
		String codServicio = obtenerCodigoServicioAnotacion(this);

		Long numCorreDoc = dua.getNumcorredoc();		
		//List<DatoDocAutorizante> listDocAutAsociadoSerie = new ArrayList<DatoDocAutorizante>();
		List<Map<String, Object>> listDocAutAsociadoSerie = new ArrayList<Map<String, Object>>();

		if (numCorreDoc != null){
			//rtineo optimizacion: verificamos si es que los documentos autorizantes ya fueron cargadas anteriormente
			listDocAutAsociadoSerie = (List<Map<String,Object>>) variablesIngreso.get("listDocAutAsociadoSerie");
			if(listDocAutAsociadoSerie == null){
				Map<String,Object> params = new HashMap<String,Object>();
				params.put("numCorreDoc", numCorreDoc);
				params.put("codTipOper", Constants.COD_TIPOPER_DOCAUT);
				params.put("indDel", Constants.INDICADOR_NO_ELIMINADO);
				//				Se cambia la instancia a lectura por problemas reportados por conexiones cerradas en WL
				//				antes estaba asociado a dxbdsigad ahora a dcbdsigad
				//				DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
				DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoLecturaDAO");


				listDocAutAsociadoSerie = docAutAsociadoDAO.listDocAutorizaSerie(params);

				//Cargamos por unica vez la lista en variablesIngreso
				variablesIngreso.put("listDocAutAsociadoSerie", listDocAutAsociadoSerie);
			}
			//fin Optimizacion
		}

		List<DatoDocAutorizante> lstDocAutorizaMRestri = obtenerListaDocAutorizaMRestri(serie,fechaReferencia,variablesIngreso,codServicio) ;

		CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		for (DatoDocAutorizante docAutoriza : lstDocAutorizaMRestri){
			if (valServicioSubTipoDocAutoriza (codServicio,docAutoriza, fechaReferencia, variablesIngreso)){
				//rtineo optimizacion: verificamos si es que el grupo de documentos autorizados fue cargado anteriormente mediante un solo query en base datos
				Map<String, List<CabMrDocAutoriz>> grupoDocumentosAutorizadosPorAduana = (Map<String, List<CabMrDocAutoriz>>) variablesIngreso.get("grupoDocumentosAutorizadosPorAduana");
				CabMrDocAutoriz cabMrDocAutoriz = null;
				if (grupoDocumentosAutorizadosPorAduana != null) {
					//entonces solo extraemos los documentos autorizados del map calculado anteriormente
					String anio = null;
					if (SunatStringUtils.length(docAutoriza.getAnndocum())>3){
						anio = docAutoriza.getAnndocum().substring(0,4);
					}else{
						anio = docAutoriza.getAnndocum();
					}
					String identificador = docAutoriza.getCodentidad() + "-" + docAutoriza.getCodtipodocum() + "-" + docAutoriza.getNumdocum() + "-" + anio + "-" + dua.getCodaduanaorden();
					List<CabMrDocAutoriz> registros = grupoDocumentosAutorizadosPorAduana.get(identificador);
					if (registros != null && !registros.isEmpty()) {
						cabMrDocAutoriz = registros.get(0);
					}
				} else {
					//sino ejecutamos la logica pesada... query por cada documento autorizado de cada serie
					Map<String,Object> params = new HashMap<String,Object>();
					params.put("codiEntidad", docAutoriza.getCodentidad());
					params.put("ccoddoc", docAutoriza.getCodtipodocum());
					params.put("ccordoc", docAutoriza.getNumdocum());
					if (SunatStringUtils.length(docAutoriza.getAnndocum())>3){
						params.put("anodoc",docAutoriza.getAnndocum().substring(0,4));
					}else{
						params.put("anodoc",docAutoriza.getAnndocum());
					}
					//					params.put("cregimen", dua.getCodregimen());
					//					params.put("fecEmis",SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
					params.put("codiAduan", dua.getCodaduanaorden());

					cabMrDocAutoriz = cabMrDocAutorizDao.getCabMrDocAutoriz(params);
				}
				//fin optimizacion

				if (cabMrDocAutoriz != null){

					boolean indExisteDocu = false;

					for(Map<String, Object> docAutSerie : listDocAutAsociadoSerie ){											
						Integer intFecEmisDoc = SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision());
						Integer intFecEmisDocSerie = SunatDateUtils.getIntegerFromDate((Date) docAutSerie.get("fecEmis"));

						if(docAutoriza.getCodentidad().equals(docAutSerie.get("codEntidad").toString()) &&
								SunatStringUtils.toNotNull(docAutoriza.getCodsubentidad()).equals(SunatStringUtils.toNotNull(docAutSerie.get("codSubEntidad").toString())) && 
								SunatStringUtils.toNotNull(docAutoriza.getCodsubtipodocum()).equals(SunatStringUtils.toNotNull(docAutSerie.get("codSubTipoDoc").toString())) && 
								docAutoriza.getCodtipodocum().equals(docAutSerie.get("codTipDoc").toString()) && 
								docAutoriza.getNumdocum().equals(docAutSerie.get("numDoc").toString()) &&
								docAutoriza.getAnndocum().substring(0,4).equals(docAutSerie.get("annDoc").toString()) &&
								intFecEmisDoc.compareTo(intFecEmisDocSerie) == 0  &&
								SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(docAutoriza.getNroitemdocum()))
								.equals(SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(docAutSerie.get("nroitemdocum"))))){
							indExisteDocu = true;
						}
					}

					if (!indExisteDocu){
						//Validacion de estado OTORGADO  [RN 1167]
						if (!Constants.EST_DOCAUT_OTORGADA.equals(cabMrDocAutoriz.getCodEstAut())){
							lstErrores.add(catalogoAyudaService.getError("35359", new String[] {serie.getNumserie().toString()}));
						}
					} else {
						//Validacion de estado DESTINADA  [RN 1195]
						if (!Constants.EST_DOCAUT_CONCLUIDA.equals(cabMrDocAutoriz.getCodEstAut())){
							if(!Constants.EST_DOCAUT_DESTINADA.equals(cabMrDocAutoriz.getCodEstAut())){
								lstErrores.add(catalogoAyudaService.getError("35375", new String[] {serie.getNumserie().toString()}));
							}	
						}
					}

				}

			}
		}

		return lstErrores;
	}

	@Override
	/** Validar que se haya declarado los documentos autorizantes requeridos para validar las mercanc�as restringidas en el proceso de diligencia
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9138, descServicio="Validar documentos requeridos")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9138,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")	
	public List<Map<String, String>> validarDocAutorizaRequerido( DatoSerie serie, Date fechaReferencia,
			Map<String, Object> variablesIngreso) {

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		List<String> lstCodEntidad = new ArrayList<String>();
		obtenerListaMercRestringida(serie,fechaReferencia,variablesIngreso);

		String codRegimen = ((DUA)serie.getPadre()).getCodregimen();

		Boolean indValMrestri = (Boolean)variablesIngreso.get("indValMrestri");

		if (!indValMrestri) return lstErrores;

		String codServicio = obtenerCodigoServicioAnotacion(this);

		//Se obtendr�n las mercanc�as restringidas relacionada con la partida
		List<MRestri> lstMrestri = obtenerListaMercRestringida(serie,fechaReferencia,variablesIngreso);

		//Se obtendr�n la lista de documentos autorizantes
		//List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie,(DUA)serie.getPadre(),variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
		List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie,(DUA)serie.getPadre(),variablesIngreso,false); //BUG 24309-24326 - PAS20155E220000487

		//Se obtenendran las sub entidades afectos al servicio 
		//rtineo optimizacion 
		List<String> lstSubEntidadesPorServicio = obtenerSubEntidadesPorServicio(codServicio, fechaReferencia,variablesIngreso);
		//fin optimizacion

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		for (MRestri itemMRestri : lstMrestri){
			if (lstCodEntidad.contains(itemMRestri.getRegistro())) continue;
			if(CollectionUtils.contains(lstSubEntidadesPorServicio.iterator(), itemMRestri.getRegistro())){
				boolean indDocAutorizaRequerido = false;
				boolean indExoneraDocAutoriza = false;
				List<String> lstDescripDocuRequeridos = new ArrayList<String>();
				for (DatoDocAutorizante docAutoriza : lstDocAutoriza){

					/***Inicio cambios VUCE, si es vuce ya no entra***/
					if(SunatStringUtils.isStringInList(docAutoriza.getCodsubentidad(), "0501,0503,0502,0504,0201")){
						String tipoValidacion= " ";
						tipoValidacion=obtenerTipoValidacionDocumentoAutorizante(docAutoriza,fechaReferencia,variablesIngreso, codRegimen);
						if(tipoValidacion.equals("vuce")){//P_SNADE046-2103
							indDocAutorizaRequerido= true;
							indExoneraDocAutoriza = true;
							break;
						}                      	    		
					}
					/***Fin cambios VUCE***/ 

					if (docAutoriza.getCodsubentidad().equals(itemMRestri.getRegistro())){

						if (docAutoriza.getCodtipodocum().equals(Constants.COD_EXONERACION)) {
							indDocAutorizaRequerido = true;
							indExoneraDocAutoriza = true;
							break;
						}

						if (valServicioSubTipoDocAutoriza(codServicio ,docAutoriza, fechaReferencia, variablesIngreso)){
							//rtineo optimizacion
							String descripDocAutoriza = null;
							if(docAutoriza.getDescripcionSubTipoDocumentoAutorizado() != null && !docAutoriza.getDescripcionSubTipoDocumentoAutorizado().trim().isEmpty()){
								descripDocAutoriza = docAutoriza.getDescripcionSubTipoDocumentoAutorizado();
							}else{
								//continua con la laogica anterior
								descripDocAutoriza = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_SUBTIPO_DOCAUTORIZA, docAutoriza.getCodsubtipodocum());
							}
							//rtineo fin optimizacion

							if(!CollectionUtils.contains(lstDescripDocuRequeridos.iterator(), descripDocAutoriza)){
								lstDescripDocuRequeridos.add(descripDocAutoriza);		    					
							}

							indDocAutorizaRequerido = true;
						}
					}
				}

				/***Inicio cambios VUCE, si es vuce ya no entra***/      
				if(SunatStringUtils.isStringInList(itemMRestri.getRegistro(), "0501,0503,0502,0504,0201")){
					boolean esVigenteVucePorFecha = esVigenteVucePorFecha(codRegimen, fechaReferencia);
					if(CollectionUtils.isEmpty(lstDocAutoriza) && esVigenteVucePorFecha){//este para los casos que no manden el documento vuce
						boolean esExigible = esExigibleSubentidadPorVuce(esVigenteVucePorFecha,itemMRestri.getRegistro(), SunatDateUtils.getCurrentDate());
						if(esExigible){
							indDocAutorizaRequerido= true;
							indExoneraDocAutoriza = true;
						}
					}
				}
				/***Fin cambios VUCE***/ 

				if (!indDocAutorizaRequerido){
					//rtineo optimizacion
					//String desDocAutoriza = obtenerDescripDocAutorizaPorServicio(codServicio,itemMRestri.getRegistro(),fechaReferencia);
					String desDocAutoriza = obtenerDescripDocAutorizaPorServicio(codServicio,itemMRestri.getRegistro(),itemMRestri.getDescripcionRegistro(),fechaReferencia,variablesIngreso);
					//fin optimizacion

					lstErrores.add(catalogoAyudaService.getError("35391",new String[] {serie.getNumserie().toString(), desDocAutoriza }));
					/*Map<String,String> itemError = new HashMap<String,String>();
		    		itemError.put("desError", "SERIE "+serie.getNumserie().toString()+" - DEBE CONSIGNAR EL "+desDocAutoriza+" ¿DESEA CONTINUAR CON LA DILIGENCIA? SI, NO");
		    		itemError.put("codError", "35391");
		    		lstErrores.add(itemError);*/

				} else {
					//rtineo optimizacion
					List<String> lstSubTipoDocAutoriza = obtenerSubTipoPorSubEntidadServicio(codServicio, itemMRestri.getRegistro(), fechaReferencia,variablesIngreso);
					//fin optimizacion
					if (lstSubTipoDocAutoriza.size() != lstDescripDocuRequeridos.size() && !indExoneraDocAutoriza){
						//rtineo optimizacion
						String desDocAutoriza = obtenerDescripDocAutorizaPorServicio(codServicio,
								itemMRestri.getRegistro(),itemMRestri.getDescripcionRegistro(),fechaReferencia,variablesIngreso).replace(" o ", " y ");
						//fin optimizacion
						lstErrores.add(catalogoAyudaService.getError("35391",new String[] {serie.getNumserie().toString(), desDocAutoriza }));
						/*Map<String,String> itemError = new HashMap<String,String>();
			    		itemError.put("desError", "SERIE "+serie.getNumserie().toString()+" - DEBE CONSIGNAR EL "+desDocAutoriza+" ¿DESEA CONTINUAR CON LA DILIGENCIA? SI, NO");
			    		itemError.put("codError", "35391");
			    		lstErrores.add(itemError);*/
					}


				}
			}
			lstCodEntidad.add(itemMRestri.getRegistro());
		}


		if (CollectionUtils.isEmpty(lstErrores)){
			variablesIngreso.put("indValidaDocNoRequeridos",true);
		}

		return lstErrores;
	}

	@Override
	/** Validar que se haya declarado los documentos autorizantes no requeridos para validar las mercanc�as restringidas en el proceso de diligencia
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@ServicioAnnot(tipo="V",codServicio=9139, descServicio="Validar documentos no requeridos")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","fechaReferencia","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9139,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")		
	public List<Map<String, String>> validarDocAutorizaNoRequerido( DatoSerie serie, Date fechaReferencia,
			Map<String, Object> variablesIngreso) {

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		if (variablesIngreso.containsKey("indValidaDocNoRequeridos")){
			if ((Boolean) variablesIngreso.get("indValidaDocNoRequeridos")){

				String codServicio = obtenerCodigoServicioAnotacion(this);

				//Realizamos la validaci�n de los documentos requerido
				lstErrores.addAll(validarDocAutServicioSubEntidad(serie,codServicio,"35392",fechaReferencia,variablesIngreso));
			}
		}
		variablesIngreso.remove("indValidaDocNoRequeridos");
		return lstErrores;

	}

	/**
	 * Retorna los mensajes de las validaciones de docs Vuce u otros en caso de diligencia
	 * @param docAutorizante
	 * @param numeroSerie
	 * @param mercanciaSpn
	 * @return
	 */
	public List<Map<String, String>> validarDiligenciaConVigenciaVuceConDoc(List<DatoDocAutorizante> lstDocAutorizante,  String numeroSerie, String mercanciaSpn, String subEntidadAEval){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		//		String numCut = "";
		//		if(docAutorizante!=null && docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO)){
		//				 DocControlMercRestringidaVuce docControlMercRestringidaVuce= null;	
		//				 docControlMercRestringidaVuce = obtenerDocumentoVuce(SunatNumberUtils.toLong(docAutorizante.getNumdocum()),docAutorizante.getCodtipodocum());
		//				 numCut=docControlMercRestringidaVuce.getNumeroCUT().toString();
		//		}  
		//LOGICA DEL RIN:
		if(subEntidadAEval.equals("0501")){
			//			if(lstDocAutorizante==null ||  (docAutorizante!=null && !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && !docAutorizante.getCodtipodocum().equals("07") && !(docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO) && numCut.equals("33"))) ){
			if(!tieneDocumentoAutorizanteCorrecto(lstDocAutorizante, "98,07", "33")){
				listErrores.add(catalogoAyudaService.getError("37015", new String []{numeroSerie}));//EXCEP3
			}
		}
		if(subEntidadAEval.equals("0503")){
			//			if(lstDocAutorizante==null || (docAutorizante!=null && !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && !docAutorizante.getCodtipodocum().equals("07") && !(docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO) && numCut.equals("35"))) ){
			if(!tieneDocumentoAutorizanteCorrecto(lstDocAutorizante, "98,07", "35")){
				listErrores.add(catalogoAyudaService.getError("37016", new String []{numeroSerie}));//EXCEP5
			}
		}
		if(subEntidadAEval.equals("0502")){
			//			if(lstDocAutorizante==null || (docAutorizante!=null && !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && !docAutorizante.getCodtipodocum().equals("07") && !(docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO) && SunatStringUtils.isStringInList(numCut, "52,112,113,114"))) ){
			if(!tieneDocumentoAutorizanteCorrecto(lstDocAutorizante, "98,07", "52,112,113,114")){
				listErrores.add(catalogoAyudaService.getError("37017", new String []{numeroSerie}));//EXCEP4
			}
		}
		if(subEntidadAEval.equals("0504")){
			//			if(lstDocAutorizante==null || (docAutorizante!=null && !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && !docAutorizante.getCodtipodocum().equals("07") && !(docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO) && numCut.equals("49"))) ){
			if(!tieneDocumentoAutorizanteCorrecto(lstDocAutorizante, "98,07", "49")){
				listErrores.add(catalogoAyudaService.getError("37018", new String []{numeroSerie}));//EXCEP6
			}
		}
		if(subEntidadAEval.equals("0201")){
			//			if(lstDocAutorizante==null || (docAutorizante!=null && !docAutorizante.getCodtipodocum().equals(Constants.COD_EXONERACION) && !docAutorizante.getCodtipodocum().equals("99") && !docAutorizante.getCodtipodocum().equals("02"))
			//				&& !(docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO) && SunatStringUtils.isStringInList(numCut, "208,211,231,324,339")) ){
			if(!tieneDocumentoAutorizanteCorrecto(lstDocAutorizante, "98,99, 02", "208,211,231,324,339")){
				listErrores.add(catalogoAyudaService.getError("37019", new String []{numeroSerie}));//EXCEP1
			}
		}

		return listErrores;
	}

	private boolean tieneDocumentoAutorizanteCorrecto(List<DatoDocAutorizante> lstDocAutorizante, String listExcepcionesTipoDocumento, String cutsAceptadas){		
		if(lstDocAutorizante == null){
			return false;
		}

		for (DatoDocAutorizante docAutorizante : lstDocAutorizante) {
			String numCut = "";			
			if(SunatStringUtils.isStringInList(docAutorizante.getCodtipodocum(), listExcepcionesTipoDocumento)){
				return true;
			}

			if(docAutorizante!=null && docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO)){
				DocControlMercRestringidaVuce docControlMercRestringidaVuce = obtenerDocumentoVuce(SunatNumberUtils.toLong(docAutorizante.getNumdocum()),docAutorizante.getCodtipodocum());
				numCut = SunatStringUtils.toStringObj(docControlMercRestringidaVuce != null ? docControlMercRestringidaVuce.getNumeroCUT() : "");
			}

			if(docAutorizante.getCodtipodocum().equals(DOC_RESOLUTIVO) && SunatStringUtils.isStringInList(numCut, cutsAceptadas)){
				return true;
			}

		}
		return false;
	}

	/**
	 * Retorna los mensajes de las validaciones de docs Vuce u otros en caso de diligencia
	 * @param docAutorizante
	 * @param numeroSerie
	 * @param mercanciaSpn
	 * @return
	 */
	public List<Map<String, String>> validarDiligenciaConVigenciaVuceSinDoc(String numeroSerie, String mercanciaSpn, String subEntidadAEval){
		return validarDiligenciaConVigenciaVuceConDoc(null, numeroSerie, mercanciaSpn, subEntidadAEval);
	}

	/**
	 * Valida si es exigible por vuce por la fecha de referencia contra la fecha de catalogo y
	 * la subentidad delregistro con las fechas de exigibilidad de vuce
	 * @param docAutorizante
	 * @param numeroSerie
	 * @param mercanciaSpn
	 * @return
	 */
	public boolean esExigibleSubentidadPorVuce(boolean esVigenteVucePorFecha, String subEntidadEval, Date fechaReferencia){
		boolean esExigible=false;
		String val_atributoFecha=" ";   
		if(esVigenteVucePorFecha){//es vigente todo VUCE, se procede a validar la subentidad con la exigibilidad
			CatalogoAyudaService catalogoAyudaService1= (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> atributosEntidadesVuce=catalogoAyudaService1.getDataAtributo(
					ConstantesTipoCatalogo.CATALOGO_DE_DATOS_SUBENTIDAD,
					ConstantesTipoCatalogo.CATALOGO_DE_FECHA_VIGENCIA_VUCE, 
					ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA,
					subEntidadEval);
			val_atributoFecha = atributosEntidadesVuce.get("val_atributo") == null ? null:atributosEntidadesVuce.get("val_atributo").toString();

			Date fechaExigVuce=val_atributoFecha!=null?SunatDateUtils.getDateFromUnknownFormat(val_atributoFecha):null;

			if(fechaExigVuce!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia,fechaExigVuce, SunatDateUtils.COMPARA_SOLO_FECHA)){
				esExigible=true;
			}

		} 
		return esExigible;
	}              	

	/** Identifica si un determinado servicio deber� ser ejecutado como parte de la validaci�n de Mercanc�as Restringidas
	 * @param codServicio
	 * @param docAutoriza
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean valServicioSubTipoDocAutoriza (String codServicio, DatoDocAutorizante docAutoriza, Date fechaReferencia, Map<String, Object> variablesIngreso){

		//Boolean indValMrestri = (Boolean) variablesIngreso.get("indValMrestri");

		//if (indValMrestri){
		if ( validaEntidadTipoDocAutoriza(docAutoriza, fechaReferencia)){
			//rtineo optimizacion: primero verificamos si es que existen servicios cargados previamente para evitar logica pesada
			Map<String, List<Map<String, String>>> serviciosPorSubTipoDocumentoGroup = (Map<String, List<Map<String, String>>>) variablesIngreso.get("serviciosPorSubTipoDocumentoGroup");
			List<Map<String, String>> listServAsociados = null;
			if(serviciosPorSubTipoDocumentoGroup != null){
				//obtenemos los servios precargados
				listServAsociados = serviciosPorSubTipoDocumentoGroup.get(docAutoriza.getCodsubtipodocum());
			}else{
				//rtineo continuamos con la logica anterior metodo pesado
				listServAsociados = obtenerServiciosAsociadosDocAutoriza(docAutoriza.getCodsubtipodocum(),fechaReferencia);
			}
			//rtineo fin optimizacion
			if (!CollectionUtils.isEmpty(listServAsociados)){
				for (Map<String, String> servAsociados : listServAsociados){
					if (servAsociados.get("cod_datacat").equals(codServicio))
						return true;
				}
			}				
		}
		//}

		return false;
	}

	/** Obtiene la asociacion del sub tipo del documento con los servicios asociados
	 * @param codSubTipo
	 * @param fechaReferencia
	 * @return
	 */
	private List<Map<String, String>> obtenerServiciosAsociadosDocAutoriza(String codSubTipo, Date fechaReferencia){
		List<Map<String, String>> listServAsociados =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBTIPODOCU_SERVICIO, "C",codSubTipo,fechaReferencia);
		return listServAsociados;
	}

	/** Verifica si la entidad, subentidad, tipo y subtipo del documento corresponden seg�n catalogo asociacion
	 * @param docAutoriza
	 * @param fechaReferencia
	 * @return
	 */
	private boolean validaEntidadTipoDocAutoriza(DatoDocAutorizante	docAutoriza,Date fechaReferencia){
		//rtineo: optimizacion, verificamos si es que la validez ya fue verificada anteriormente
		if (docAutoriza.getEntidadTipoDocumentoAutorizadoValido() != null) {
			//si es que fue verificado anteriormente entonces retornamos su valor
			return docAutoriza.getEntidadTipoDocumentoAutorizadoValido();
		}
		//fin rtineo: optimizacion, sino fue verificado anteriormente entonces ejecutamos la logica pesada

		boolean indRetorna = true;

		if ( SunatStringUtils.isEmptyTrim(docAutoriza.getCodentidad()) || 
				SunatStringUtils.isEmptyTrim(docAutoriza.getCodtipodocum()) || 
				SunatStringUtils.isEmptyTrim(docAutoriza.getCodsubentidad()) || 
				docAutoriza.getCodtipodocum().equals(Constants.COD_EXONERACION) ||
				( docAutoriza.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) && 
						( docAutoriza.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_SENASA01) || 
								docAutoriza.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_SENASA03) ) ) ) {
			return false;
		}

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		List<Map<String, String>> lstSubEntidad =  catalogoAyudaService
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_ENTIDAD_SUBENTIDAD, "C",docAutoriza.getCodentidad(),fechaReferencia);

		List<Map<String, String>> lstSubTipoDocuPorTipo =  catalogoAyudaService
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, "C",docAutoriza.getCodtipodocum(),fechaReferencia);

		List<Map<String, String>> lstSubTipoDocuPorSubEntidad  = new ArrayList<Map<String, String>>();

		if (!docAutoriza.getCodsubentidad().isEmpty() && docAutoriza.getCodsubentidad() != null){
			lstSubTipoDocuPorSubEntidad =  catalogoAyudaService
					.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU, "C",docAutoriza.getCodsubentidad(),fechaReferencia);
		} else {
			return false;
		}

		boolean indExisteAsociacion = false;

		for (Map<String, String> subEntidad : lstSubEntidad){
			if (subEntidad.get("cod_datacat").equals(docAutoriza.getCodsubentidad())){
				indExisteAsociacion = true;
				break;
			}
		}

		if (!indExisteAsociacion) indRetorna = false;

		indExisteAsociacion = false;

		for (Map<String, String> subTipoDocuPorTipo : lstSubTipoDocuPorTipo){
			if (subTipoDocuPorTipo.get("cod_datacat").equals(docAutoriza.getCodsubtipodocum())){
				indExisteAsociacion = true;
				break;
			}
		}

		if (!indExisteAsociacion) indRetorna = false;


		indExisteAsociacion = false;

		for (Map<String, String> subTipoDocuPorSubEntidad : lstSubTipoDocuPorSubEntidad){
			if (subTipoDocuPorSubEntidad.get("cod_datacat").equals(docAutoriza.getCodsubtipodocum())){
				indExisteAsociacion = true;
				break;
			}
		}

		if (!indExisteAsociacion) indRetorna = false;

		return indRetorna;		

	}	

	@SuppressWarnings("unchecked")
	/** Obtiene una lista con las Mercanc�as Restringidas de la tabla MRESTRI@PRAD1
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<MRestri>
	 */
	private List<MRestri> obtenerListaMercRestringida (DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso){

		//List<MRestri> lstMrestri = null;
		boolean indExcluyeIQBF = false;
		boolean indExcluyeDIQBF = false;
		boolean indExcluyeSENASA01 = false;

		if (variablesIngreso.containsKey("indExcluyeIQBF")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBF")){
				indExcluyeIQBF = true;
			}
		}

		if (variablesIngreso.containsKey("indExcluyeDIQBF")){
			if ((Boolean) variablesIngreso.get("indExcluyeDIQBF")){
				indExcluyeDIQBF = true;
			}
		}

		if (variablesIngreso.containsKey("indExcluyeSENASA01")){
			if ((Boolean) variablesIngreso.get("indExcluyeSENASA01")){
				indExcluyeSENASA01 = true;
			}
		}

		if ( (Long)variablesIngreso.get("numPartida")!=serie.getNumpartnandi() ) {
			List<MRestri> lstMrestri = null;
			//rtineo: Optimizacion, se obtiene de variablesIngreso precargado anteriormente
			Map<String,List<MRestri>> mercanciasRestringidasCache = (Map<String,List<MRestri>>) variablesIngreso.get("mercanciasRestringidas");
			if(mercanciasRestringidasCache != null){
				lstMrestri = mercanciasRestringidasCache.get(serie.getNumpartnandi());
			}else{
				variablesIngreso.put("indValMrestri", false);//ADICIONADO PASE79-vuce_recti
				DUA dua = (DUA)serie.getPadre();
				MrestriDAO mrestriDAO = ((MrestriDAO)fabricaDeServicios.getService("mrestriDAO"));

				Map<String, Object> params = new HashMap<String, Object>();
				params.put("cnan", serie.getNumpartnandi());
				params.put("fechaVigencia", SunatDateUtils.getIntegerFromDate(fechaReferencia));
				params.put("codiRegi", dua.getCodregimen());

				lstMrestri = mrestriDAO.listadoMercRestringida(params);

				if (!CollectionUtils.isEmpty(lstMrestri)) {
					//Bloque para eliminar registros de Subentidades duplicadas VUCE PAS201930001100005
					Set<MRestri> lstMrestriNew = new HashSet<MRestri>(); 
					for (MRestri mrestri : lstMrestri) {
						lstMrestriNew.add(mrestri);
					}
					/*String codSubEntidad = "";
					List<MRestri> lstMrestriAux = new ArrayList<MRestri>();
					for (MRestri mrestri : lstMrestri) {
						if( !codSubEntidad.equals(mrestri.getRegistro())) {
							codSubEntidad = mrestri.getRegistro();
							lstMrestriAux.add(mrestri);
						}
					}*/
					//lstMrestri = lstMrestriAux;
					lstMrestri.clear();
					lstMrestri.addAll(lstMrestriNew);
					variablesIngreso.put("indValMrestri", true);
				} else {
					variablesIngreso.put("indValMrestri", false);
				}

			}
			/*
			if (!CollectionUtils.isEmpty(lstMrestri)) {
				variablesIngreso.put("indValMrestri", true);
			} else {
				variablesIngreso.put("indValMrestri", false);
			}
			 */
			variablesIngreso.put("listMercRestringida", lstMrestri);
			variablesIngreso.put("numPartida", serie.getNumpartnandi());
		}

		List<MRestri> lstMrestri = (List<MRestri>) variablesIngreso.get("listMercRestringida");

		if (lstMrestri != null){
			variablesIngreso.put("indValMrestri", true);
			///eliminar las partidas con precedente IQBF y DIQBF
			for (Iterator<MRestri> iter = lstMrestri.iterator(); iter.hasNext();) {
				MRestri mRestri = iter.next();
				if ((mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF) ||
						mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA)) //PAS20155E220000487 - Incluye IQBF Mineria
						&& indExcluyeIQBF){
					iter.remove();
				}

				if ((mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF03) ||
						mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF04)) && indExcluyeDIQBF){
					iter.remove();
				}

				if (mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_SENASA01) && indExcluyeSENASA01){
					iter.remove();
				}
				//si es trx04 y la lista de restringidas requeridas no es IQBF retirar el error de solicitud de incorporaci�n PAS20155E220200154
				if(variablesIngreso.get("codTransaccion")!=null &&SunatStringUtils.include(variablesIngreso.get("codTransaccion").toString().substring(2,4), new String[] { "04" })
						&& ( !mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF)
						&& !mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA)
								/*&& !mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF03)
							&& !mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF04)*/)){
					iter.remove();
				}
			}
		}

		if (lstMrestri==null || CollectionUtils.isEmpty(lstMrestri)) {//ADICIONADO PASE79-vuce_recti
			variablesIngreso.put("indValMrestri", false);
		}

		return lstMrestri;
	}

	@SuppressWarnings("unchecked")
	/** Obtiene una lista con los documentos autorizantes transmitidos por serie 
	 * @param serie
	 * @param dua
	 * @param variablesIngreso
	 * @param isBaseDatos true identifica si la declaraci�n es de Base de Datos y false si la declaraci�n es del XML
	 * @return List<DatoDocAutorizante>  Lista de Documentos autorizantes
	 */
	private List<DatoDocAutorizante> obtenerListaDocAutorizaSerie (DatoSerie serie, DUA dua, Map<String, Object> variablesIngreso, boolean isBaseDatos){
		//private List<DatoDocAutorizante> obtenerListaDocAutorizaSerie (DatoSerie serie, DUA dua, Map<String, Object> variablesIngreso){ //BUG 24309-24326 - PAS20155E220000487

		List<DatoDocAutorizante> listDocAutorizaSerie = new ArrayList<DatoDocAutorizante>();
		Date fechaReferencia = SunatDateUtils.getCurrentDate();	

		boolean indExcluyeIQBF = false;
		boolean indExcluyeDIQBF = false;
		boolean indExcluyeSENASA01 = false;
		if (variablesIngreso.containsKey("indExcluyeIQBF")){
			if ((Boolean) variablesIngreso.get("indExcluyeIQBF")){
				indExcluyeIQBF = true;
			}
		}		

		if (variablesIngreso.containsKey("indExcluyeDIQBF")){
			if ((Boolean) variablesIngreso.get("indExcluyeDIQBF")){
				indExcluyeDIQBF = true;
			}			
		}		

		if (variablesIngreso.containsKey("indExcluyeSENASA01")){
			if ((Boolean) variablesIngreso.get("indExcluyeSENASA01")){
				indExcluyeSENASA01 = true;
			}			
		}

		//if ( (Integer)variablesIngreso.get("numSerie")!=serie.getNumserie()){ //BUG 24309  - PAS20155E220000487
		/*if ( (Integer)variablesIngreso.get("numSerie")!=serie.getNumserie() || (!isBaseDatos && variablesIngreso.get("lstDocAutoriza") == null) || (isBaseDatos && variablesIngreso.get("lstDocAutorizaBD") == null)){
		if ( (!isBaseDatos && ((Integer)variablesIngreso.get("numSerie") != serie.getNumserie() || variablesIngreso.get("lstDocAutoriza") == null)) || 
				(isBaseDatos && ((Integer)variablesIngreso.get("numSerieBD") != serie.getNumserie() || variablesIngreso.get("lstDocAutorizaBD") == null))){*/
		//rtineo optimizacion se obtiene de cache
		if ( (!isBaseDatos && ((Integer)variablesIngreso.get("numSerie") != serie.getNumserie())) || 
				(isBaseDatos && ((Integer)variablesIngreso.get("numSerieBD") != serie.getNumserie()))){ //BUG 24309  - PAS20155E220000487

			Map<Integer, List<DatoDocAutorizante>> variablesDocumentoAutorizadoPorSerie = (Map<Integer, List<DatoDocAutorizante>>) variablesIngreso.get("variablesDocumentoAutorizadoPorSerie");
			if(variablesDocumentoAutorizadoPorSerie != null){
				//rtineo mejora... se evita consultar via rest catalogos por cada serie
				listDocAutorizaSerie = variablesDocumentoAutorizadoPorSerie.get(serie.getNumserie());
			}else{
				//rtineo logica anterior
				List<String> listDocSoporteSerie = new ArrayList<String>();

				if (!CollectionUtils.isEmpty(serie.getListSerieDocSoporte())) {
					for (DatoSerieDocSoporte serieDoc : serie.getListSerieDocSoporte()) {
						// Ini P46
						if (SunatStringUtils.isEqualTo(Constants.DOCUMENTO_AUTORIZACION, serieDoc.getCodtipodocsoporte())) {
							Integer numiddocsoporte = serieDoc.getNumiddocsoporte()!=null?serieDoc.getNumiddocsoporte():0;
							listDocSoporteSerie.add(numiddocsoporte.toString());
						}
						// Fin P46
					}
				}

				if (!CollectionUtils.isEmpty(listDocSoporteSerie) && !CollectionUtils.isEmpty(dua.getListDocAutorizantes())) {
					for (DatoDocAutorizante docAutoriza : dua.getListDocAutorizantes() ) {
//cambio pase 13
						if(docAutoriza.getNumsecdocum()!=null
								&& CollectionUtils.contains(listDocSoporteSerie.iterator(), docAutoriza.getNumsecdocum().toString())){
							listDocAutorizaSerie.add(docAutoriza);
						}
					}
				}

				//Inicio Cambio: ya no se enviar� el subtipodocumento y para no afectar la estructura, se dijara el sub tipo documento de manera interna.
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				for (DatoDocAutorizante docAutoriza : listDocAutorizaSerie) {

					/***Inicio cambios VUCE***/       
					String tipoValidacion = obtenerTipoValidacionDocumentoAutorizante(docAutoriza, fechaReferencia, variablesIngreso, dua.getCodregimen());
					/***Fin cambios VUCE***/

					if (docAutoriza.getCodsubentidad() == null){
						continue;
					}
					if(tipoValidacion==null || (tipoValidacion!=null && !tipoValidacion.equals("vuce"))){//adicionado por vuce control cambios
						if (docAutoriza.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_MTC01) && docAutoriza.getCodtipodocum().equals("09")) {
							continue;
						}
					}

					List<Map<String, String>> lstSubTipoDocuPorSubEntidad =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU, "C",(docAutoriza.getCodsubentidad()== null ? "" : docAutoriza.getCodsubentidad()),fechaReferencia);
					List<Map<String, String>> lstSubTipoDocuPorTipo =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, "C",docAutoriza.getCodtipodocum(),fechaReferencia);
					String codSubTipoDocum = null;	
					for (Map<String, String> subTipoDocuPorTipo : lstSubTipoDocuPorTipo) {
						for (Map<String, String> subTipoDocuPorSubEntidad : lstSubTipoDocuPorSubEntidad) {
							if (subTipoDocuPorTipo.get("cod_datacat").equals(subTipoDocuPorSubEntidad.get("cod_datacat"))) {
								codSubTipoDocum = subTipoDocuPorTipo.get("cod_datacat");
								break;
							}
						}
					}
					docAutoriza.setCodsubtipodocum(codSubTipoDocum);
				}
				//Fin Cambio
			}

			//variablesIngreso.put("lstDocAutoriza",listDocAutorizaSerie); //BUG 24309  - PAS20155E220000487
			//variablesIngreso.put("numSerie", serie.getNumserie()); //BUG 24309  - PAS20155E220000487

			//BUG 24309 - PAS20155E220000487
			if(!isBaseDatos){
				variablesIngreso.put("lstDocAutoriza",listDocAutorizaSerie);
				variablesIngreso.put("numSerie", serie.getNumserie());
			}else{
				variablesIngreso.put("lstDocAutorizaBD", listDocAutorizaSerie);
				variablesIngreso.put("numSerieBD", serie.getNumserie()); 
			}

		}

		if(!isBaseDatos){//BUG 24309  - PAS20155E220000487
			listDocAutorizaSerie = (List<DatoDocAutorizante>) variablesIngreso.get("lstDocAutoriza");

			if(!CollectionUtils.isEmpty(listDocAutorizaSerie) ){

				///eliminar las partidas con precedente IQBF y DIQBF				
				for (Iterator<DatoDocAutorizante> iter = listDocAutorizaSerie.iterator(); iter.hasNext();) {
					DatoDocAutorizante docAutoriz = iter.next();
					if(docAutoriz.getCodsubentidad()!=null){
						if ((docAutoriz.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF) || 
								docAutoriz.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA)) //PAS20155E220000487 - Incluye IQBF Mineria
								&& indExcluyeIQBF){
							iter.remove();
						}

						if ((docAutoriz.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_DIQPF03) || 
								docAutoriz.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_DIQPF04)) && indExcluyeDIQBF){
							iter.remove();
						}

						if (docAutoriz.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_SENASA01) && indExcluyeSENASA01){
							iter.remove();
						}
					}
				}
			}
		}else{
			listDocAutorizaSerie = (List<DatoDocAutorizante>) variablesIngreso.get("lstDocAutorizaBD");
		}

		return listDocAutorizaSerie;
	}

	private void setearSubTipoDeDocumentoDeControl(DatoDocAutorizante docAutoriza, Date fechaReferencia){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> lstSubTipoDocuPorSubEntidad =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU, "C",(docAutoriza.getCodsubentidad()== null ? "" : docAutoriza.getCodsubentidad()),fechaReferencia);
		List<Map<String, String>> lstSubTipoDocuPorTipo =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, "C",docAutoriza.getCodtipodocum(),fechaReferencia);
		String codSubTipoDocum = null;
		for (Map<String, String> subTipoDocuPorTipo : lstSubTipoDocuPorTipo) {
			for (Map<String, String> subTipoDocuPorSubEntidad : lstSubTipoDocuPorSubEntidad) {
				if (subTipoDocuPorTipo.get("cod_datacat").equals(subTipoDocuPorSubEntidad.get("cod_datacat"))) {
					codSubTipoDocum = subTipoDocuPorTipo.get("cod_datacat");
					break;
				}
			}
		}
		docAutoriza.setCodsubtipodocum(codSubTipoDocum);
	}


	/** Obtener la lista de documentos autorizantes por mercanc�a restringida  y matriz de servicio
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<DatoDocAutorizante> Lista de Documentos autorizantes
	 */
	private List<DatoDocAutorizante> obtenerListaDocAutorizaMRestri(DatoSerie serie, Date fechaReferencia,
			Map<String, Object>	variablesIngreso,String codServicio){

		List<DatoDocAutorizante> lstDocAutorizaMRestri = new ArrayList<DatoDocAutorizante>();
		List<String> lstCodSubEntidad = new ArrayList<String>();

		List<MRestri> lstMrestri = obtenerListaMercRestringida(serie, fechaReferencia, variablesIngreso);

		//List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, (DUA) serie.getPadre(),variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
		List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, (DUA) serie.getPadre(),variablesIngreso, false); //BUG 24309-24326 - PAS20155E220000487

		//rtineo optimizacion
		List<String> lstSubEntidadServicio = obtenerSubEntidadesPorServicio(codServicio, fechaReferencia, variablesIngreso);
		//PASE 484 - se comenta para que no incluya el 3002
		/*//inicio gmontoya Pase 469 - 2015
		if(lstSubEntidadServicio.contains("3001")){
			lstSubEntidadServicio.add("3002");
		}
		//fin gmontoya Pase 469 - 2015*/
		//fin optimizacion

		if (!CollectionUtils.isEmpty(lstMrestri) && !CollectionUtils.isEmpty(lstDocAutoriza)){
			for (MRestri mRestri:lstMrestri){
				if (!lstCodSubEntidad.contains(mRestri.getRegistro())) {
					if (lstSubEntidadServicio.contains(mRestri.getRegistro())){
						for(DatoDocAutorizante docAutoriza :lstDocAutoriza){
							if (mRestri.getRegistro().equals(docAutoriza.getCodsubentidad())){// || docAutoriza.getCodsubentidad().equals("3001")){//gmontoya Pase 469 - 2015 //PASE 484 se comenta no se identifico xq se agrego 
								lstDocAutorizaMRestri.add(docAutoriza);
							}
						}
					}
					lstCodSubEntidad.add(mRestri.getRegistro());
				}				
			}
		}

		return lstDocAutorizaMRestri;
	}


	/** Verifica si en la lista de Mapas ya se encuentra registrado el error
	 * @param lstErrores
	 * @param codError
	 * @return boolean indicador de existencia
	 */
	private boolean verificarExisteError(List<Map<String,String>> lstErrores,String codError){

		for (Map<String,String> itemError : lstErrores){
			if(itemError.get("codError").endsWith(codError)){
				return true;
			}
		}
		return false;
	}

	/** rtineo optimizacion sobrecarga del metodo Verifica que el RUC del documento declarado sea el mismo 
	 * que del Declarante de la DUA
	 * @param docAutoriza
	 * @param codAduana
	 * @param codRegimen
	 * @param cabMrDocAutoriz
	 * @param rucImportador
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarRucDocAutoriza(DatoDocAutorizante docAutoriza, String codAduana,
			String codRegimen, CabMrDocAutoriz cabMrDocAutoriz, String rucImportador,String numSerie){
		return validarRucDocAutoriza(docAutoriza,codAduana,codRegimen,cabMrDocAutoriz,rucImportador,numSerie,null);
	}

	/** Verifica que el RUC del documento declarado sea el mismo que del Declarante de la DUA
	 * @param docAutoriza
	 * @param codAduana
	 * @param codRegimen
	 * @param cabMrDocAutoriz
	 * @param rucImportador
	 * @return List<Map<String, String>> Lista de Errores
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, String>> validarRucDocAutoriza(DatoDocAutorizante docAutoriza, String codAduana,
			String codRegimen, CabMrDocAutoriz cabMrDocAutoriz, String rucImportador,String numSerie,Map<String,Object> variablesIngreso){

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		if (cabMrDocAutoriz == null){
			//rtineo optimizacion se verifica que se llama al nuevo metodo
			if(variablesIngreso!=null && variablesIngreso.containsKey("grupoDocumentosAutorizados")){
				//se aplica la mejora
				Map<String,List<CabMrDocAutoriz>> grupoDocumentosAutorizados = (Map<String,List<CabMrDocAutoriz>>) variablesIngreso.get("grupoDocumentosAutorizados");
				/*String anio = null;
				if(SunatStringUtils.length(docAutoriza.getAnndocum())>3){
					anio = docAutoriza.getAnndocum().substring(0,4);
				}else{
					anio = docAutoriza.getAnndocum();
				}
				String identificador = docAutoriza.getCodentidad() + "-" + docAutoriza.getCodtipodocum() + "-" + docAutoriza.getNumdocum() + anio;*/
				List<CabMrDocAutoriz> registros = grupoDocumentosAutorizados.get("identificador");
				for(CabMrDocAutoriz registro : registros){
					if(codAduana.equals(registro.getCodiAduan())){
						cabMrDocAutoriz = registro;
						break;
					}
				}
			}else{
				//rtineo continua metodo anterior
				CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");

				Map<String,Object> params = new HashMap<String,Object>();
				params.put("codientidad", docAutoriza.getCodentidad());
				params.put("ccoddoc", docAutoriza.getCodtipodocum());
				params.put("ccordoc", docAutoriza.getNumdocum());
				//params.put("anodoc", docAutoriza.getAnndocum());
				if (SunatStringUtils.length(docAutoriza.getAnndocum())>3)
					params.put("anodoc",docAutoriza.getAnndocum().substring(0,4));
				else
					params.put("anodoc",docAutoriza.getAnndocum());			
				//				params.put("cregimen", codRegimen);
				//				params.put("fecemis", docAutoriza.getFecemision());
				params.put("codiAduana", codAduana);

				cabMrDocAutoriz = cabMrDocAutorizDao.getCabMrDocAutoriz(params);		
			}

			//RIN14 mpoblete 
			if (cabMrDocAutoriz == null){
				lstErrores.add(catalogoAyudaService.getError("35357", new String[] {numSerie}));
				return lstErrores; 
			}
			//RIN14 mpoblete
		} 

		if (!cabMrDocAutoriz.getLibrTribu().equals(rucImportador)){
			lstErrores.add(catalogoAyudaService.getError("35356", new String[] {numSerie}));
		}

		return lstErrores;
	}

	/**Verifica que el documento declarado coincida con los datos registrados por las entidades autorizantes 
	 * en cuanto a la partida arancelaria y unidad comercial, el control de las cantidades y pesos del documento autorizante
	 * @param lstDocAutorizaMRestri
	 * @param mapValoresSerie
	 * @param codServicio
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	public List<Map<String, String>> validarSpnUnidadCantidadPesoDocAut(List<DatoDocAutorizante> lstDocAutorizaMRestri,
			Map<String, Object>	mapValoresSerie, String	codServicio,Date fechaReferencia, Map<String, Object> variablesIngreso){

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();

		String codModalidad = mapValoresSerie.get("codModalidad").toString(); 
		String tipoTransaccion = mapValoresSerie.get("tipoTransaccion").toString();
		String numSerie = mapValoresSerie.get("numSerie").toString();

		if (!CollectionUtils.isEmpty(lstDocAutorizaMRestri)){

			DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAO");
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

			for (DatoDocAutorizante docAutoriza : lstDocAutorizaMRestri){
				if (valServicioSubTipoDocAutoriza (codServicio, docAutoriza, fechaReferencia, variablesIngreso) && docAutoriza.getNroitemdocum() != null ) {

					Map<String,Object> params = new HashMap<String,Object>();
					params.put("codientidad", docAutoriza.getCodentidad());					
					params.put("ccoddoc", docAutoriza.getCodtipodocum());
					params.put("ccordoc", docAutoriza.getNumdocum());
					if (SunatStringUtils.length(docAutoriza.getAnndocum())>3)
						params.put("anodoc",docAutoriza.getAnndocum().substring(0,4));
					else
						params.put("anodoc",docAutoriza.getAnndocum());
					params.put("codiAduan", mapValoresSerie.get("codAduana"));					
					//					params.put("cregimen", mapValoresSerie.get("codRegimen"));
					params.put("csecdoc", docAutoriza.getNroitemdocum());			
					//					params.put("fecEmis", SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));

					DetMrDocAutoriz detMrDocAutoriz = detMrDocAutorizDAO.getDetMrDocAutoriza(params);

					if (detMrDocAutoriz !=null){

						//Validaci�n de SPN [RN 1174]
						String spnSerie  = mapValoresSerie.get("partNandi").toString();

						if (!spnSerie.equals(detMrDocAutoriz.getPartNandi().toString())){
							lstErrores.add(catalogoAyudaService.getError("35367", new String[] {numSerie, spnSerie}));
						}

						//Validaci�n tipo de unidad comercial [RN 1175]											
						String codUnidSerie = mapValoresSerie.get("codUniComer").toString().trim();
						//SAU201510002000015
						//if (!codUnidSerie.equals(detMrDocAutoriz.getCodUniMedc())){
						if (!codUnidSerie.equals(detMrDocAutoriz.getUnidFides())){
							if (tipoTransaccion.equals(Constants.COD_TRANSAC_DILIGENCIADESPA)){
								lstErrores.add(catalogoAyudaService.getError("35383", new String[] {numSerie, spnSerie}));
							} else {
								lstErrores.add(catalogoAyudaService.getError("35368", new String[] {numSerie}));
							}
						}

						//Validaci�n cantidad y pesos [RN 1176]
						String docAutoIndGranel = detMrDocAutoriz.getIndGraItem();

						BigDecimal cntUniSerie = new BigDecimal( mapValoresSerie.get("cntUniComer").toString());
						BigDecimal cntPesoNetoSerie = new BigDecimal(mapValoresSerie.get("cntPesoNeto").toString());

						//SAU201510002000015
						//BigDecimal cntUniItemDocAuto =  detMrDocAutoriz.getCntQuniCom();
						//BigDecimal cntPesoNetoItemDocAuto = detMrDocAutoriz.getCntPesoNeto();
						BigDecimal cntUniComDocAuto =  detMrDocAutoriz.getUnidFiqty(); //Cantidad de Unidades Comerciales de su item correspondiente de la Autorizaci�n IQBF
						BigDecimal cntNetaAutDocAuto = detMrDocAutoriz.getCntNetAut(); //Cantidad Neta Autorizada de su item correspondiente de la Autorizaci�n IQBF

						if ((Constants.DOCAUT_INDICA_GRANEL).equals(docAutoIndGranel)){//fixed
							//SAU201510002000015
							//if (SunatNumberUtils.scaleHalfUp(cntUniSerie, 3).compareTo(SunatNumberUtils.scaleHalfUp(cntUniItemDocAuto.multiply(Constants.FACTOR_EXCESO_PESO_CANTIDAD), 3)) == 1){
							if (SunatNumberUtils.scaleHalfUp(cntUniSerie, 3).compareTo(SunatNumberUtils.scaleHalfUp(cntUniComDocAuto.multiply(Constants.FACTOR_EXCESO_PESO_CANTIDAD), 3)) == 1){
								if (Constants.COD_TRANSAC_RECTIFICACION.equals(tipoTransaccion) ||
										Constants.COD_TRANSAC_DILIGENCIADESPA.equals(tipoTransaccion)){
									if (Constants.DESPACHO_EXCEPCIONAL.equals(codModalidad)){
										if (Constants.COD_TRANSAC_RECTIFICACION.equals(tipoTransaccion)){
											lstErrores.add(catalogoAyudaService.getError("35376", new String[] {numSerie}));
										}
										if (Constants.COD_TRANSAC_DILIGENCIADESPA.equals(tipoTransaccion)){
											lstErrores.add(catalogoAyudaService.getError("35384",new String[] {numSerie, spnSerie}));
										}
									} else if (Constants.DESPACHO_ANTICIPADO.equals(codModalidad) || 
											Constants.DESPACHO_URGENTE.equals(codModalidad)) {
										if (Constants.COD_TRANSAC_RECTIFICACION.equals(tipoTransaccion)){
											lstErrores.add(catalogoAyudaService.getError("35369", new String[] {numSerie}));
										}
										if (Constants.COD_TRANSAC_DILIGENCIADESPA.equals(tipoTransaccion)){
											lstErrores.add(catalogoAyudaService.getError("35385",new String[] {numSerie, spnSerie}));
										}
									}
								} else {
									if (Constants.COD_TRANSAC_NUMERACION.equals(tipoTransaccion)){
										lstErrores.add(catalogoAyudaService.getError("35369", new String[] {numSerie}));
									} else {
										if (Constants.DESPACHO_EXCEPCIONAL.equals(codModalidad)){
											lstErrores.add(catalogoAyudaService.getError("35371", new String[] {numSerie}));
										} else if (Constants.DESPACHO_ANTICIPADO.equals(codModalidad) || 
												Constants.DESPACHO_URGENTE.equals(codModalidad)) {
											lstErrores.add(catalogoAyudaService.getError("35369", new String[] {numSerie}));
										}
									}
								}
							}

							if (Constants.DOCAUT_UNIDAD_MEDIDA_DEFECTO.trim().equals(detMrDocAutoriz.getCodUniMedc().trim()) &&
									//SAU201510002000015
									//SunatNumberUtils.scaleHalfUp(cntPesoNetoSerie, 3).compareTo(SunatNumberUtils.scaleHalfUp(cntPesoNetoItemDocAuto.multiply(Constants.FACTOR_EXCESO_PESO_CANTIDAD), 3)) == 1){
									SunatNumberUtils.scaleHalfUp(cntPesoNetoSerie, 3).compareTo(SunatNumberUtils.scaleHalfUp(cntNetaAutDocAuto.multiply(Constants.FACTOR_EXCESO_PESO_CANTIDAD), 3)) == 1){

								if (Constants.COD_TRANSAC_RECTIFICACION.equals(tipoTransaccion) ||
										Constants.COD_TRANSAC_DILIGENCIADESPA.equals(tipoTransaccion)){

									if (Constants.DESPACHO_EXCEPCIONAL.equals(codModalidad)){

										if (Constants.COD_TRANSAC_RECTIFICACION.equals(tipoTransaccion)){
											lstErrores.add(catalogoAyudaService.getError("35377", new String[] {numSerie}));
										}

										if (Constants.COD_TRANSAC_DILIGENCIADESPA.equals(tipoTransaccion)){
											lstErrores.add(catalogoAyudaService.getError("35386",new String[] {numSerie, spnSerie}));
										}

									} else if (Constants.DESPACHO_ANTICIPADO.equals(codModalidad) || 
											Constants.DESPACHO_URGENTE.equals(codModalidad)){

										if (Constants.COD_TRANSAC_RECTIFICACION.equals(tipoTransaccion)){
											lstErrores.add(catalogoAyudaService.getError("35370", new String[] {numSerie}));
										}

										if (Constants.COD_TRANSAC_DILIGENCIADESPA.equals(tipoTransaccion)){
											lstErrores.add(catalogoAyudaService.getError("35387",new String[] {numSerie, spnSerie}));
										}
									}
								} else {

									if (Constants.COD_TRANSAC_NUMERACION.equals(tipoTransaccion)){
										lstErrores.add(catalogoAyudaService.getError("35370", new String[] {numSerie}));
									} else {
										if (Constants.DESPACHO_EXCEPCIONAL.equals(codModalidad)){
											lstErrores.add(catalogoAyudaService.getError("35372", new String[] {numSerie}));
										} else if (Constants.DESPACHO_ANTICIPADO.equals(codModalidad) || 
												Constants.DESPACHO_URGENTE.equals(codModalidad)) {
											lstErrores.add(catalogoAyudaService.getError("35370", new String[] {numSerie}));
										}
									}	


								}

							}
						} else {
							//SAU201510002000015
							//if (cntUniSerie.compareTo(cntUniItemDocAuto)==1){
							if (cntUniSerie.compareTo(cntUniComDocAuto) == 1){

								if (Constants.COD_TRANSAC_RECTIFICACION.equals(tipoTransaccion)){
									lstErrores.add(catalogoAyudaService.getError("35376", new String[] {numSerie}));
								} else if (Constants.COD_TRANSAC_DILIGENCIADESPA.equals(tipoTransaccion)){
									lstErrores.add(catalogoAyudaService.getError("35384", new String[] {numSerie, spnSerie}));
								} else {
									lstErrores.add(catalogoAyudaService.getError("35371", new String[] {numSerie}));
								}

							}

							if (Constants.DOCAUT_UNIDAD_MEDIDA_DEFECTO.trim().equals(detMrDocAutoriz.getCodUniMedc().trim()) &&
									//SAU201510002000015
									//cntPesoNetoSerie.compareTo(cntPesoNetoItemDocAuto) == 1){
									cntPesoNetoSerie.compareTo(cntNetaAutDocAuto) == 1){

								if (Constants.COD_TRANSAC_RECTIFICACION.equals(tipoTransaccion)){
									lstErrores.add(catalogoAyudaService.getError("35377", new String[] {numSerie}));
								} else if (Constants.COD_TRANSAC_DILIGENCIADESPA.equals(tipoTransaccion)){
									lstErrores.add(catalogoAyudaService.getError("35386",new String[] {numSerie, spnSerie}));
								} else {
									lstErrores.add(catalogoAyudaService.getError("35372", new String[] {numSerie}));
								}

							}
						}

					} else {
						//Validacion existencia del destalle del documento 
						lstErrores.add(catalogoAyudaService.getError("35403", new String[] {numSerie}));
					}

				}
			}
		}

		return lstErrores;
	}

	/** Identificar que se haya declarado los documentos autorizantes necesarios para validar las mercanc�as restringidas
	 * @param serie
	 * @param codServicio
	 * @param codError
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return List<Map<String, String>> Lista de Errores
	 */
	private List<Map<String, String>> validarDocAutServicioSubEntidad(DatoSerie	serie, String codServicio,
			String codError, Date fechaReferencia, Map<String, Object> variablesIngreso){

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		Boolean indValMrestri = variablesIngreso.get("indValMrestri")!=null? (Boolean)variablesIngreso.get("indValMrestri"):false;
		Boolean indEvitarTransmision = variablesIngreso.get("indEvitarTransmision")!=null? (Boolean)variablesIngreso.get("indEvitarTransmision"):false;//adicionado por arey Pase 23-2015
		Boolean indRetirarDoc = variablesIngreso.get("codTransaccion")!=null  && variablesIngreso.get("codTransaccion").equals("1001")? true: false;//adicioando por arey Pase 23-2015
		//aca verificara si est� inscrito la subentidad en el servicio: arey
		List<DatoDocAutorizante> lstDocAutorizaMrestri = obtenerListaDocAutorizaMRestri(serie, fechaReferencia, variablesIngreso, codServicio);

		if (!indValMrestri) return lstErrores;
		if (CollectionUtils.isEmpty(lstDocAutorizaMrestri)) return lstErrores; //si no esta inscrito no coteja arey

		List<MRestri> lstMrestri = obtenerListaMercRestringida(serie, fechaReferencia, variablesIngreso);
		//List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie,(DUA) serie.getPadre(),variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
		List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie,(DUA) serie.getPadre(),variablesIngreso,false); //BUG 24309-24326 - PAS20155E220000487

		//rtineo optimizacion llamado al metodo sobrecargado
		List<String> lstSubEntidadesPorServicio = obtenerSubEntidadesPorServicio(codServicio, fechaReferencia,variablesIngreso);
		// fin optimizacion

		boolean esTratamientoDonacion = variablesIngreso.get("esTratamDonacion")!=null?(Boolean) variablesIngreso.get("esTratamDonacion"):false;//arey PAS20155E220200010
		boolean esDocumentoNoPermitido = false;
		if (CollectionUtils.isEmpty(lstDocAutorizaMrestri)) return lstErrores; 

		List<String> lstCodSubEntidad = new ArrayList<String>();

		for (MRestri itemMRestri : lstMrestri){

			if (!lstCodSubEntidad.contains(itemMRestri.getRegistro())) {
				if(CollectionUtils.contains(lstSubEntidadesPorServicio.iterator(), itemMRestri.getRegistro())){
					boolean indDocAutorizaPermitido = false;
					boolean indCodExoneracion = false;
					ArrayList<String> listDocAutoNoPer = new ArrayList<String>();//arey PAS20155E220200010	    			

					for (DatoDocAutorizante docAutoriza : lstDocAutoriza){
						/***Inicio cambios VUCE- si es vuce debe salir***/  
						String codRegimen = ((DUA)serie.getPadre()).getCodregimen();
						String tipoValidacion = obtenerTipoValidacionDocumentoAutorizante(docAutoriza, fechaReferencia, variablesIngreso, codRegimen);
						if(tipoValidacion.equals("vuce"))
						{
							indCodExoneracion=true;
							indDocAutorizaPermitido = true;
							continue;
						}
						/***Fin cambios VUCE***/   


						if (docAutoriza.getCodsubentidad().equals(itemMRestri.getRegistro())){
							if ( docAutoriza.getCodtipodocum().equals(Constants.COD_EXONERACION) ||
									( docAutoriza.getCodtipodocum().equals(Constants.COD_EXONERACION_INFO) && 
											(docAutoriza.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_SENASA01) || docAutoriza.getCodsubentidad().equals(Constants.COD_SUBENTIDAD_SENASA03)) )) 
							{
								indCodExoneracion = true;
								continue;
							}
							if (valServicioSubTipoDocAutoriza(codServicio ,docAutoriza, fechaReferencia, variablesIngreso)){
								indDocAutorizaPermitido = true;
								if(indEvitarTransmision &&  docAutoriza.getCodtipodocum().equals(DOC_INFORME_INSPEC)){//adicionado por arey pase 23 - 2015 basta que se deba no permitir
									indDocAutorizaPermitido = false;
								}
							}
							if(!indCodExoneracion && !indDocAutorizaPermitido){//condicion adicionada por arey PAS20155E220200010
								listDocAutoNoPer.add(docAutoriza.getCodtipodocum().toString());
							}
						}
					}

					if (!indCodExoneracion && !indDocAutorizaPermitido){
						if(listDocAutoNoPer.contains(DOC_INFORME_INSPEC)){
							esDocumentoNoPermitido=true;
						}
						if(indRetirarDoc){
							esDocumentoNoPermitido=true;//adicioando por arey Pase 23-2015
						}
						String desDocAutoriza = obtenerDescripDocAutorizaPorServicio(codServicio,
								itemMRestri.getRegistro(),fechaReferencia,esTratamientoDonacion, esDocumentoNoPermitido);//arey PAS20155E220200010

						if(!CollectionUtils.isEmpty(listDocAutoNoPer)){//condicion adicionada por arey PAS20155E220200010
							for(String tipoDocum: listDocAutoNoPer){
								lstErrores.add(((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).
										getError(codError,new String[] {serie.getNumserie().toString(), desDocAutoriza, itemMRestri.getEntidad(), itemMRestri.getRegistro(), tipoDocum})); //arey PAS20155E220200010 + SAU201510002000126(PAS20155E220300013)
							}
						}

					}
				}
				lstCodSubEntidad.add(itemMRestri.getRegistro());
			}
		}



		return lstErrores;
	}

	/** Obtener la lista de subentidades por servicio
	 * @param codServicio
	 * @param fechaReferencia
	 * @return List Lista de Sub Entidades por Servicio
	 */
	private List<String> obtenerSubEntidadesPorServicio(String codServicio, Date fechaReferencia){

		List<String> lstSubEntidades = new ArrayList<String>();

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		List<Map<String, String>> lstSubTipoDocu = catalogoAyudaService
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBTIPODOCU_SERVICIO, "A",codServicio,fechaReferencia);		

		for (Map<String, String> itemSubTipoDocu : lstSubTipoDocu) {
			List<Map<String, String>> lstSubEntidad = catalogoAyudaService
					.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU, "A",itemSubTipoDocu.get("cod_datacat"),fechaReferencia);

			for (Map<String, String> itemSubEntidad : lstSubEntidad){
				if ( !lstSubEntidades.contains(itemSubEntidad.get("cod_datacat"))) {
					lstSubEntidades.add(itemSubEntidad.get("cod_datacat"));
				}
			}
		}	

		return lstSubEntidades;
	}

	//rtineo optimizacion, sobrecargamos el metodo para ejecutar la mejor o continuar el metodo normal
	/**
	 * obrecargamos el metodo para ejecutar la mejor o continuar el metodo normal
	 * @param codServicio
	 * @param subEntidad
	 * @param descripcionSubEntidad
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String obtenerDescripDocAutorizaPorServicio(String codServicio, String subEntidad, String descripcionSubEntidad, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		Map<String, List<Map<String, String>>> subTiposPorSubEntidadGroup = (Map<String, List<Map<String, String>>>) variablesIngreso.get("subTiposPorSubEntidadGroup");
		Map<String, List<Map<String, String>>> subTiposDocumentoPorServicioGroup = (Map<String, List<Map<String, String>>>) variablesIngreso.get("subTiposDocumentoPorServicioGroup");
		Map<String, List<Map<String, String>>> tiposDocumentoPorSubTipoDocumentoGroup = (Map<String, List<Map<String, String>>>) variablesIngreso.get("tiposDocumentoPorSubTipoDocumentoGroup");

		if (subTiposPorSubEntidadGroup == null || subTiposDocumentoPorServicioGroup == null || tiposDocumentoPorSubTipoDocumentoGroup == null) {
			//entonces ejecutamos el metodo pesado
			boolean esTratamientoDonacion = variablesIngreso.get("esTratamDonacion")!=null?(Boolean) variablesIngreso.get("esTratamDonacion"):false;//arey PAS20155E220200010 pase 23
			return obtenerDescripDocAutorizaPorServicio(codServicio, subEntidad, fechaReferencia, esTratamientoDonacion, false);
		}
		//sino entonces ejecutamos la mejora

		String desDocAutoriza = "";

		List<Map<String, String>> listDocAutoMrestri = subTiposPorSubEntidadGroup.get(subEntidad);
		List<Map<String, String>> listDocAutoPermitidos = subTiposDocumentoPorServicioGroup.get(codServicio);

		String desDocAutorizaUltimo ="";

		for (Map<String, String> docAutoMrestri: listDocAutoMrestri){
			for (Map<String, String> docAutoPermitidos : listDocAutoPermitidos){
				if (docAutoPermitidos.get("cod_datacat").equals(docAutoMrestri.get("cod_datacat")) ){
					//String descDataCat = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_SUBTIPO_DOCAUTORIZA, docAutoPermitidos.get("cod_datacat"));
					String descDataCat = descripcionSubEntidad;

					//List<Map<String, String>> lstTipoDocu =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, "A",docAutoPermitidos.get("cod_datacat"),fechaReferencia);
					List<Map<String, String>> lstTipoDocu =  tiposDocumentoPorSubTipoDocumentoGroup.get(docAutoPermitidos.get("cod_datacat"));

					desDocAutorizaUltimo = ", " +  lstTipoDocu.get(0).get("cod_datacat") + " - " + descDataCat;
					//desDocAutorizaUltimo = ", " +  docAutoPermitidos.get("cod_datacat") + " - " + descDataCat;
					desDocAutoriza += desDocAutorizaUltimo;
				}
			}
		}
		desDocAutoriza = desDocAutoriza.substring(2);

		if (desDocAutoriza.indexOf(desDocAutorizaUltimo) > -1){
			desDocAutoriza = desDocAutoriza.replace(desDocAutorizaUltimo, " o " +  desDocAutorizaUltimo.substring(2));
		}

		return desDocAutoriza;
	}
	//fin optimizacion

	/** Obtener las descripci�n de los documentos Permitidos
	 * @param codServicio
	 * @param subEntidad
	 * @param fechaReferencia
	 *@param esDonacion arey PAS20155E220200010
	 * @return String Descripcion de los documentos permitidos
	 */
	private String obtenerDescripDocAutorizaPorServicio(String codServicio, String subEntidad, Date fechaReferencia, boolean esDonacion, boolean docInformeInspNoPermitido){

		String desDocAutoriza = "";

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		List<Map<String, String>> listDocAutoMrestri = catalogoAyudaService
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU, "C",subEntidad,fechaReferencia);

		List<Map<String, String>> listDocAutoPermitidos = catalogoAyudaService
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBTIPODOCU_SERVICIO, "A",codServicio,fechaReferencia);

		String desDocAutorizaUltimo ="";

		for (Map<String, String> docAutoMrestri: listDocAutoMrestri){
			for (Map<String, String> docAutoPermitidos : listDocAutoPermitidos){
				if (docAutoPermitidos.get("cod_datacat").equals(docAutoMrestri.get("cod_datacat")) ){
					String descDataCat = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_SUBTIPO_DOCAUTORIZA, docAutoPermitidos.get("cod_datacat"));

					List<Map<String, String>> lstTipoDocu =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TIPODOCU_SUBTIPODOCU, "A",docAutoPermitidos.get("cod_datacat"),fechaReferencia);

					if(!esDonacion){//si no es donacion que no pinte el 99 arey PAS20155E220200010
						//si no esta permitido transmitir 07-INSPECCION (TRX01) no debe colocarlo como documento autorizante en la transmision PASE 23 - 2015 arey
						if((!lstTipoDocu.get(0).get("cod_datacat").equals(DOC_AUTORIZACION_OTROS) && !docInformeInspNoPermitido) 
								|| (!lstTipoDocu.get(0).get("cod_datacat").equals(DOC_AUTORIZACION_OTROS) && docInformeInspNoPermitido && !lstTipoDocu.get(0).get("cod_datacat").equals(DOC_INFORME_INSPEC))){

							desDocAutorizaUltimo = ", " +  lstTipoDocu.get(0).get("cod_datacat") + " - " + descDataCat;
							desDocAutoriza += desDocAutorizaUltimo;
						}
					}else{//arey PAS20155E220200010
						if(!docInformeInspNoPermitido || (docInformeInspNoPermitido && !lstTipoDocu.get(0).get("cod_datacat").equals(DOC_INFORME_INSPEC)) ){//adicionado por pase 23 - 2015

							desDocAutorizaUltimo = ", " +  lstTipoDocu.get(0).get("cod_datacat") + " - " + descDataCat;
							desDocAutoriza += desDocAutorizaUltimo;
						}
					}
				}//arey pase23-2015

			}
		}
		//PASE 484 - se agrega para que cuando las cadenas esten vacias no salga abort 24, problema del StringIndexOutOfBoundsException
		if(!desDocAutoriza.isEmpty() && !desDocAutorizaUltimo.isEmpty()){
			desDocAutoriza = desDocAutoriza.substring(2);

			if (desDocAutoriza.indexOf(desDocAutorizaUltimo) > -1){
				desDocAutoriza = desDocAutoriza.replace(desDocAutorizaUltimo, " o " +  desDocAutorizaUltimo.substring(2));
			}
		}

		return desDocAutoriza;
	}

	/** Obtiene lista de documentos autorizantes usados
	 * @param docAutorizante
	 * @param param
	 * @return 
	 */
	private List<DatoDocAutorizante> validarUsoDocAutorizante(DatoDocAutorizante docAutorizante, Map<String, Object> param){

		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");

		Map<String,Object> params = new HashMap<String,Object>();

		params = new HashMap<String,Object>();
		params.put("numCorreDoc", param.get("numCorreDoc"));
		params.put("indDocAutoUsado", param.get("indDocAutoUsado"));
		params.put("codEntidad",docAutorizante.getCodentidad());
		params.put("codTipoOper", Constants.COD_TIPOPER_DOCAUT);
		params.put("numDocum",docAutorizante.getNumdocum());
		if (SunatStringUtils.length(docAutorizante.getAnndocum())>3){
			params.put("annDocum",docAutorizante.getAnndocum().substring(0,4));
		}else{
			params.put("annDocum",docAutorizante.getAnndocum());
		}
		params.put("codTipoDocum", docAutorizante.getCodtipodocum());
		String fecEmision = SunatDateUtils.getFormatDate(docAutorizante.getFecemision(), "dd/MM/yyyy");
		params.put("fecEmision",SunatDateUtils.getDate(fecEmision, "dd/MM/yyyy"));

		params.put("indDel",Constants.INDICADOR_NO_ELIMINADO);

		List<DatoDocAutorizante> lstDatoDocAutorizante = docAutAsociadoDAO.listDocAutorizante(params);	  

		return lstDatoDocAutorizante;
	}

	//rtineo optimizacion sobrecargamos el metodo para ejecutar las mejoras o continuar con el metodo pesado
	/**
	 * sobrecargamos el metodo para ejecutar las mejoras o continuar con el metodo pesado
	 * @param codServicio
	 * @param subEntidad
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<String> obtenerSubTipoPorSubEntidadServicio(String codServicio, String subEntidad, Date fechaReferencia, Map<String, Object> variablesIngreso) {

		Map<String, List<Map<String, String>>> subTiposPorSubEntidadGroup = (Map<String, List<Map<String, String>>>) variablesIngreso.get("subTiposPorSubEntidadGroup");
		Map<String, List<Map<String, String>>> subTiposDocumentoPorServicioGroup = (Map<String, List<Map<String, String>>>) variablesIngreso.get("subTiposDocumentoPorServicioGroup");

		if (subTiposPorSubEntidadGroup == null || subTiposDocumentoPorServicioGroup == null) {
			//entonces ejecutamos el metodo pesado
			return obtenerSubTipoPorSubEntidadServicio(codServicio, subEntidad, fechaReferencia);
		}
		//sino entonces ejecutamos la mejora
		List<String> lstSubTipoDocAutoriza = new ArrayList<String>();

		//Obtenemos la lista de subtipos por servicio
		List<Map<String, String>> lstSubTipoPorServicio = subTiposDocumentoPorServicioGroup.get(codServicio);

		//Obtenemos los subtipos por subentidad
		List<Map<String, String>> lstSubTipoPorSubEntidad = subTiposPorSubEntidadGroup.get(subEntidad);

		for ( Map<String, String> subTipoPorSubEntidad: lstSubTipoPorSubEntidad ) {
			for( Map<String, String> subTipoPorServicio: lstSubTipoPorServicio ) {
				if (subTipoPorSubEntidad.get("cod_datacat").equals(subTipoPorServicio.get("cod_datacat")))
					lstSubTipoDocAutoriza.add(subTipoPorSubEntidad.get("cod_datacat"));				
			}
		}
		return lstSubTipoDocAutoriza;
	}

	//fin optimizacion

	/** Obtener las descripci�n de los documentos Permitidos y del documento no Permitido
	 * @param codServicio
	 * @param subEntidad
	 * @param fechaReferencia
	 * @return
	 */
	private List<String> obtenerSubTipoPorSubEntidadServicio(String codServicio,String subEntidad, Date	fechaReferencia){

		List<String> lstSubTipoDocAutoriza = new ArrayList<String>();

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		//Obtenemos la lista de subtipos de documentos por servicio
		List<Map<String, String>> lstSubTipoPorServicio = catalogoAyudaService
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBTIPODOCU_SERVICIO, "A",codServicio,fechaReferencia);

		//Obtenemos los subtipos por subentidad
		List<Map<String, String>> lstSubTipoPorSubEntidad = catalogoAyudaService
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_SUBTIPODOCU, "C",subEntidad,fechaReferencia);

		for ( Map<String, String> subTipoPorSubEntidad: lstSubTipoPorSubEntidad ) {
			for( Map<String, String> subTipoPorServicio: lstSubTipoPorServicio ) {
				if (subTipoPorSubEntidad.get("cod_datacat").equals(subTipoPorServicio.get("cod_datacat")))
					lstSubTipoDocAutoriza.add(subTipoPorSubEntidad.get("cod_datacat"));				
			}
		}

		return lstSubTipoDocAutoriza;

	}


	/** Busca un objeto en una lista de objetos seg�n la condici�n
	 * de comparaci�n previamente creado 
	 * @param lstObject
	 * @param key
	 * @param c
	 * @return pos
	 */
	private static <T> int buscarObjeto(List<? extends T> lstObject, T key, Comparator<? super T> c) {
		int pos = -1;
		for (int i=0; i< lstObject.size();i++) {
			T midVal = lstObject.get(i);
			if (c.compare(midVal, key)==0){
				pos = i;
				break;
			}
		}
		return pos;
	}	

	//Rin 14 - INI - JYC
	public Map<String, Object> validarDocAutorizaLevanteDUA(Long numCorreDoc, String codAduana, String codRegi, Integer annPrese, Integer numDeclara ){
		Map<String, Object> mapRetorna = new HashMap<String, Object>();
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		boolean indDocAutorizaIQBF = false;

		Map<String, Object> mapa = new HashMap<String, Object>();
		mapa.put("numCorreDoc", numCorreDoc);
		mapa.put("codTipOper", Constants.COD_TIPOPER_DOCAUT);
		mapa.put("codEntidad", Constants.COD_ENTIDAD_DOCAUT_IQBF);
		//mapa.put("codSubEntidad", Constants.COD_SUBENTIDAD_DOCAUT_IQBF); //PAS20155E220000487
		mapa.put("codTipoDocu", Constants.COD_TIPO_DOCAUT_IQBF);
		//mapa.put("codsubtipodocum", Constants.COD_SUBTIPO_DOCAUT_IQBF); //PAS20155E220000487
		mapa.put("indDel", Constants.INDICADOR_NO_ELIMINADO);
		//Inicio - PAS20155E220000487 - se agrega IQBF Mineria
		mapa.put("listaSubEntidad", new String[]{Constants.COD_SUBENTIDAD_DOCAUT_IQBF, Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA});
		//Fin - PAS20155E220000487

		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
		//List<DatoDocAutorizante> lstDocAutorizaSerie = docAutAsociadoDAO.listDocAutorizaSerie(mapa);		
		if(log.isDebugEnabled()) log.debug("IVMR: Entro a validarDocAutorizaLevanteDUA: "+mapa);
		List<Map<String, Object>> lstDocAutorizaSerie = new ArrayList<Map<String,Object>>();
		try {
			lstDocAutorizaSerie = docAutAsociadoDAO.listDocAutorizaSerie(mapa);
		}
		catch( Exception e ) {
			log.debug(e.getMessage());
		}
		if(log.isDebugEnabled()) log.debug("IVMR: lstDocAutorizaSerie: "+lstDocAutorizaSerie.size());

		if(!CollectionUtils.isEmpty(lstDocAutorizaSerie)) { //|| !lstDocAutorizaSerie.equals(null) || !lstDocAutorizaSerie.equals("") ) {

			indDocAutorizaIQBF = true;

			GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
			Declaracion declaracionBD = getDeclaracionService.getDeclaracion(codAduana, numDeclara, annPrese, codRegi) ;
			if(log.isDebugEnabled()) log.debug("IVMR: declaracionBD: "+declaracionBD.getEstado());

			Date fechaReferencia = new Date();			
			Map<String, Object> variablesIngreso = new HashMap<String, Object>(); 
			variablesIngreso.put("indValMrestri", true);

			lstErrores = validarItemDocAutoriza(declaracionBD,fechaReferencia,variablesIngreso) ;
			if(log.isDebugEnabled()) log.debug("IVMR: validarItemDocAutoriza: "+lstErrores);

			List<DatoSerie> lstSeriesBD = declaracionBD.getDua().getListSeries();
			if (!CollectionUtils.isEmpty(lstSeriesBD)){
				for (DatoSerie serie : lstSeriesBD){
					if(log.isDebugEnabled()) log.debug("IVMR: itera lstSeriesBD: "+lstSeriesBD.size());

					obtenerListaMercRestringida(serie,fechaReferencia,variablesIngreso);
					if(log.isDebugEnabled()) log.debug("IVMR: obtenerListaMercRestringida ");

					lstErrores.addAll(validarCabDocAutorizaEntidad(serie, fechaReferencia, variablesIngreso)) ;
					if(log.isDebugEnabled()) log.debug("IVMR: validarCabDocAutorizaEntidad: "+lstErrores);

					lstErrores.addAll(validarDetDocAutorizaEntidad(serie, fechaReferencia, variablesIngreso)) ;
					if(log.isDebugEnabled()) log.debug("IVMR: validarDetDocAutorizaEntidad: "+lstErrores);

					lstErrores.addAll(validarVencimientoDocAut(serie, fechaReferencia, variablesIngreso)) ;
					if(log.isDebugEnabled()) log.debug("IVMR: validarDetDocAutorizaEntidad: "+lstErrores);

					lstErrores.addAll(validarEstadoDocAutoriza(serie, fechaReferencia, variablesIngreso)) ;
					if(log.isDebugEnabled()) log.debug("IVMR: validarEstadoDocAutoriza: "+lstErrores);
				}
				for (Map<String,String> mapError : lstErrores) {
					if(log.isDebugEnabled()) log.debug("IVMR: DesError: "+mapError.get("desError"));
				}
			}
		}
		mapRetorna.put("indDocAutorizaIQBF", indDocAutorizaIQBF);
		mapRetorna.put("lstErrores", lstErrores);
		mapRetorna.put("lstDocAutorizaSerie", lstDocAutorizaSerie);

		if(log.isDebugEnabled()) log.debug("IVMR: mapRetorna: "+mapRetorna);

		return mapRetorna;
	}
	//Rin 14 - FIN - JYC

	@Override
	public Map<String, Object> validarMRestriSPNDiligencia(List<DatoDocAutorizante> lstDocAutoriza,
			Map<String, Object> mapValoresSerie) {

		Map<String,Object> mapRetorna = new HashMap<String,Object>();

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		List<String> lstCodEntidad = new ArrayList<String>();
		//Obtenemos tipo de transacci�n 
		String tipoDiligencia = (String) mapValoresSerie.get("tipoDiligencia");


		String codRegimen = (String) mapValoresSerie.get("codRegimen");

		if (!codRegimen.equals(Constants.REGIMEN_IMPO_DEFINITIVA) && !codRegimen.equals(Constants.REGIMEN_IMPORTACION_TEMPORAL) &&
				!codRegimen.equals(Constants.REGIMEN_ADMISION_TEMPORAL) && !codRegimen.equals(Constants.REGI_DEPOSITO))
			return mapRetorna;

		//Se obtendr�n las mercanc�as restringidas relacionada con la partida
		MrestriDAO mrestriDAO = ((MrestriDAO)fabricaDeServicios.getService("mrestriDAO"));

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cnan", mapValoresSerie.get("partNandi"));
		params.put("fechaVigencia", SunatDateUtils.getIntegerFromDate(SunatDateUtils.getCurrentDate()));
		params.put("codiRegi", codRegimen);

		List<MRestri> lstMrestri = mrestriDAO.listadoMercRestringida(params);

		if (CollectionUtils.isEmpty(lstMrestri))
			return mapRetorna;

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		//Se guardaran los mensajes para las partidas con SPN igual a cero 
		//List<String> lstMensajeSPNCero = new ArrayList<String>();
		String MensajeSPNCero = "";
		//Se guardaran los mensajes para las partidas con SPN diferente a cero 
		//List<String> lstMensajeSPN = new ArrayList<String>();
		String MensajeSPN = "";

		//Indicador de cancelaci�n
		boolean indCancelacion = false;

		//Indicador de Serie ACE
		boolean indSerieAce = false;

		for ( MRestri itemMrestri : lstMrestri ) {
			if (lstCodEntidad.contains(itemMrestri.getRegistro())) continue;
			//indicador de existencia de documentos autorizantes
			boolean indExisteDocAut = false;

			for (DatoDocAutorizante docAutoriza : lstDocAutoriza){
				if (docAutoriza.getCodentidad().equals(itemMrestri.getEntidad()) && 
						docAutoriza.getCodsubentidad().equals(itemMrestri.getRegistro()) )
					indExisteDocAut = true;
			}

			if (!indExisteDocAut){

				String cadDescripEntidad = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo. CATALOGO_ENTIDADES_DOCAUTORIZA , 
						itemMrestri.getEntidad()) +  " - " + catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo. CATALOGO_SUBENTIDADES_DOCAUTORIZA , itemMrestri.getRegistro());

				if (itemMrestri.getCprod().equals("00")){
					//lstMensajeSPNCero.add(cadDescripEntidad);
					MensajeSPNCero += ", " + cadDescripEntidad ;
				} else {
					//lstMensajeSPN.add(cadDescripEntidad);
					MensajeSPN += ", " + cadDescripEntidad ;
				}

			}			
			lstCodEntidad.add(itemMrestri.getRegistro());
		}

		//Validaci�n SPN es igual a cero	
		if (!SunatStringUtils.isEmptyTrim(MensajeSPNCero)){	

			//Formamos el mensaje legible
			MensajeSPNCero = MensajeSPNCero.substring(2);

			if(!(MensajeSPNCero.indexOf(", ") + 1 == 0)){
				MensajeSPNCero = MensajeSPNCero.replace(MensajeSPNCero.substring(MensajeSPNCero.lastIndexOf(", ")),
						" y " + MensajeSPNCero.substring(MensajeSPNCero.lastIndexOf(", ") + 2 ) );	
			};

			Long numCorreDoc = Long.parseLong(mapValoresSerie.get("numCorreDoc").toString());

			//EspeDocuDAO espeDocuDAO = (EspeDocuDAO) fabricaDeServicios.getService("asignacion.espeDocuDAO");
			CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");

			params = new HashMap<String, Object>();
			params.put("NUM_CORREDOC", numCorreDoc);
			params.put("COD_ESTREV", "09");

			params = new HashMap<String, Object>();
			params.put("NUM_CORREDOC", numCorreDoc);

			Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(params);

			//Consultamos si tiene autorizaci�n de levante
			Date fecAutLevante = cabDeclaraDAO.findFecAutLevante(params);

			//Consultamos si tiene acta de inmovilizaci�n
			//List lstActas = espeDocuDAO.findEstadoRevisionByDocumento(params);
			CabActasDAO cabActasDAO = (CabActasDAO)fabricaDeServicios.getService("diligencia.ingreso.cabActasDef");
			Map<String,Object> mapPkDua = new HashMap<String, Object>();
			mapPkDua.put("COD_REGIMEN", cabDeclara.get("COD_REGIMEN"));       
			mapPkDua.put("COD_ADUANA", cabDeclara.get("COD_ADUANA"));
			mapPkDua.put("ANN_PRESEN", cabDeclara.get("ANN_PRESEN"));
			mapPkDua.put("NUM_DECLARACION", cabDeclara.get("NUM_DECLARACION"));
			List<Map<String, Object>> lstActas =  cabActasDAO.findIncautacionAndInmovilizacionAsociadosDua(mapPkDua);

			if (CollectionUtils.isEmpty(lstActas)){
				//Si no tiene acta de inmovilizacion
				if (Constantes.COD_TIPO_DILIGENCIA_RECTIFICACION_OFICIO.equals(tipoDiligencia)){
					SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
					String fecAutLevantetmp = formatter.format(fecAutLevante);
					if (fecAutLevantetmp.equals(Constantes.DEFAULT_FECHA_BD)){
						//Validaci�n si no tiene autorizaci�n de levante
						lstErrores.add(catalogoAyudaService.getError("35381",new String[] {mapValoresSerie.get("numSerie").toString(),mapValoresSerie.get("partNandi").toString(),MensajeSPNCero}));
					} else {
						//Validaci�n si tiene autorizaci�n de levante
						lstErrores.add(catalogoAyudaService.getError("35380",new String[] {mapValoresSerie.get("numSerie").toString(),mapValoresSerie.get("partNandi").toString(),MensajeSPNCero}));
						indCancelacion = true;
					}
				} else if (Constantes.COD_TIPO_DILIGENCIA_DESPACHO.substring(0,2).equals(tipoDiligencia) || Constantes.COD_TIPO_DILIGENCIA_DESPACHO.substring(3,5).equals(tipoDiligencia)||
						Constantes.COD_TIPO_DILIGENCIA_REGULARIZACION.equals(tipoDiligencia)){

					lstErrores.add(catalogoAyudaService.getError("35380",new String[] {mapValoresSerie.get("numSerie").toString(), mapValoresSerie.get("partNandi").toString(),MensajeSPNCero}));
					indCancelacion = true;
				}
			} else {
				//Si tiene acta de inmovilizacion [RN1144]
				indSerieAce = true;
			}

		}

		//Validaci�n SPN es diferente a cero [RN1145] [RN1146]	
		if (!SunatStringUtils.isEmptyTrim(MensajeSPN)){

			//Formamos el mensaje legible
			MensajeSPN = MensajeSPN.substring(2);

			if(!(MensajeSPNCero.indexOf(", ") + 1 == 0)){
				MensajeSPN = MensajeSPN.replace(MensajeSPN.substring(MensajeSPN.lastIndexOf(", ")),
						" y " + MensajeSPN.substring(MensajeSPN.lastIndexOf(", ") + 2 ) );				
			}

			lstErrores.add(catalogoAyudaService.getError("35382",new String[] {mapValoresSerie.get("numSerie").toString(),mapValoresSerie.get("partNandi").toString(),MensajeSPN}));
		}

		mapRetorna.put("indCancelacion", indCancelacion);
		mapRetorna.put("indSerieAce", indSerieAce);
		mapRetorna.put("lstErrores", lstErrores);

		return mapRetorna;

	}

	public List<DatoItem> obtenerListDatoSerieItem(DatoSerie serie){

		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();
		List<DatoItem> lstDatoItem = new ArrayList<DatoItem>();
		List<DatoItem> lstDatoItemReturn = new ArrayList<DatoItem>();
		Integer numSerie = serie.getNumserie();
		List<DAV> lstDav = declaracion.getListDAVs();
		List<DatoFactura> lstDatoFactura = null;
		List<DatoSerieItem> lstSerieItem = null;

		for (DAV dav :  lstDav) {
			lstDatoFactura =  dav.getListFacturas();
			for (DatoFactura datoFactura : lstDatoFactura) {
				lstDatoItem = datoFactura.getListItems();
				for (DatoItem datoItem : lstDatoItem) {
					lstSerieItem = datoItem.getListSerieItems();
					for (DatoSerieItem datoSerieItem : lstSerieItem) {
						if (numSerie.equals(datoSerieItem.getNumserie())) {
							lstDatoItemReturn.add(datoItem);
							break;							
						}
					}
				}
			}

		}

		return lstDatoItemReturn;
	}


	public void actualizarEstadoDocAutorizaIQBF(Long numCorreDoc){
		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");

		Map<String,Object> params = new HashMap<String,Object>();
		params.put("numCorreDoc", numCorreDoc);
		params.put("codTipOper", Constants.COD_TIPOPER_DOCAUT);
		params.put("codEntidad",Constants.COD_ENTIDAD_DOCAUT_IQBF);
		//params.put("codSubEntidad",Constants.COD_SUBENTIDAD_DOCAUT_IQBF);  //PAS20155E220000487
		params.put("codTipoDocum",Constants.COD_TIPO_DOCAUT_IQBF);
		//params.put("codSubTipoDocum",Constants.COD_SUBTIPO_DOCAUT_IQBF); //PAS20155E220000487
		//params.put("indDocAutUsado",Constants.IND_DOCAUT_PERTENECE_DECLARACION); //PAS20155E220000487 
		params.put("indDocAutoUsado",Constants.IND_DOCAUT_PERTENECE_DECLARACION); //PAS20155E220000487 - se corrige variable
		params.put("indDel",Constants.INDICADOR_NO_ELIMINADO);
		//Inicio - PAS20155E220000487 - se agrega IQBF Mineria
		params.put("listaSubEntidad", new String[]{Constants.COD_SUBENTIDAD_DOCAUT_IQBF, Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA});
		//Fin - PAS20155E220000487

		List<DatoDocAutorizante> lstDocAutorizante = docAutAsociadoDAO.listDocAutorizante(params);

		for(DatoDocAutorizante docAutoriza : lstDocAutorizante){
			Map<String,Object> paramsTemp = new HashMap<String,Object>();
			paramsTemp.put("numCorreDoc", numCorreDoc);
			//paramsTemp.put("codTipoDocum", docAutoriza.getCodTipoOper()); //PAS20155E220000487 - se corrige
			paramsTemp.put("codTipOper", docAutoriza.getCodTipoOper()); //PAS20155E220000487
			paramsTemp.put("codTipoDocum", docAutoriza.getCodtipodocum()); //PAS20155E220000487
			paramsTemp.put("codEntidad",docAutoriza.getCodentidad());
			paramsTemp.put("numDocum",docAutoriza.getNumdocum());
			paramsTemp.put("annDocum",docAutoriza.getAnndocum());
			paramsTemp.put("fecEmision",docAutoriza.getFecemision());
			//PAS20155E220000487
			//se cambia a indDocAutoUsado = 1 para que tome num_corredoc <> sino en el listado se va a traer tambien al docAutoriza 
			//paramsTemp.put("indDocAutoUsado",Constants.IND_DOCAUT_PERTENECE_DECLARACION);
			paramsTemp.put("indDocAutoUsado",Constants.IND_DOCAUT_DIFERENTE_DECLARACION); 

			List<DatoDocAutorizante> lstDocAutoUsados = docAutAsociadoDAO.listDocAutorizante(paramsTemp);

			if(lstDocAutoUsados.isEmpty()){
				//PAS20155E220000487 - se modifico para que no vuelva a consultar al cab_declara
				/*CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
				Map<String,Object> paramCabDeclara =  new HashMap<String,Object>();
				paramCabDeclara.put("NUM_CORREDOC", numCorreDoc);
				Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(paramCabDeclara);
				actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DOCAUTORIZANTE,Constants.EST_DOCAUT_OTORGADA,docAutoriza,
						(String)cabDeclara.get("COD_ADUANA"), (String)cabDeclara.get("COD_REGIMEN"),"","","","",
						"",null,null);*/

				actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DOCAUTORIZANTE, Constants.EST_DOCAUT_OTORGADA, docAutoriza, docAutoriza.getCodigoAduanaAut(), null, null); //en otorgada no utiliza los datos de la declaracion y serie
			}
		}
	}

	public void actualizarDocAutorizaIQBF(Declaracion declaracion, String codEstado){
		Map <String,Object> variablesIngreso = new HashMap<String,Object>();

		for(DatoSerie serie :declaracion.getDua().getListSeries()){
			//List<DatoDocAutorizante>  lstDocAutorizaSerie = obtenerListaDocAutorizaSerie(serie, declaracion.getDua(), variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
			List<DatoDocAutorizante>  lstDocAutorizaSerie = obtenerListaDocAutorizaSerie(serie, declaracion.getDua(), variablesIngreso, false); //BUG 24309-24326 - PAS20155E220000487

			for(DatoDocAutorizante docAutoriza  : lstDocAutorizaSerie){
				//PAS20155E220000487 - se agrega IQBF Mineria
				/*if(Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodentidad().toString()) &&
    					Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodsubentidad().toString())  &&  
    					Constants.COD_TIPO_DOCAUT_IQBF.equals(docAutoriza.getCodtipodocum().toString()) &&
    					Constants.COD_SUBTIPO_DOCAUT_IQBF.equals(docAutoriza.getCodsubtipodocum().toString()) ){*/
				if(Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodentidad()) &&
						Constants.COD_TIPO_DOCAUT_IQBF.equals(docAutoriza.getCodtipodocum()) &&
						(Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodsubentidad()) ||
								Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA.equals(docAutoriza.getCodsubentidad()))){
					//PAS20155E220000487 - se modifico para que no vuelva a consultar al cab_declara
					/*actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DOCAUTORIZANTE, codEstado, docAutoriza,
    						declaracion.getDua().getCodaduanaorden(), declaracion.getDua().getCodregimen(),
    						declaracion.getDua().getNumcorredoc().toString(), declaracion.getDua().getAnnpresen().toString(),serie.getNumserie().toString(),
    						declaracion.getDua().getCodmodalidad(),	serie.getCodunicomer(),serie.getCntunicomer(),serie.getCntpesoneto());*/    			
					actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DOCAUTORIZANTE, codEstado, docAutoriza, declaracion.getDua().getCodaduanaorden(), declaracion, serie);
				}
			}
		}    	
	}

	//PAS20155E220000487 - se modifico para que no consulte al cab_declara
	/*public void actualizarDocAutorizanteIQBF(String indRegistro, String estadoDoc ,DatoDocAutorizante docAutoriza,String codAduana,
		String codRegimen, String numeCorre, String annPrese, String numeSerie, String codModalidad,String codUniComer, BigDecimal cntUniComer,BigDecimal cntPesoNeto){ //PAS20155E220000487 - se modifico para que no consulte al cab_declara
    	//Obtener el num_declara
    	Map<String, Object> cabDeclara = new HashMap<String,Object>();
    	if (numeCorre != null){
    		if (!SunatStringUtils.isEmptyTrim(numeCorre)){
            	Map<String,Object> mapKey = new HashMap<String,Object>();
            	mapKey.put("NUM_CORREDOC", numeCorre);
        		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
        		cabDeclara = cabDeclaraDAO.findMapDUAByPk(mapKey); 	
    		}
    	}	   	

    	if ( Constants.IND_REGISTRO_DOCAUTORIZANTE.equals(indRegistro) || Constants.IND_REGISTRO_CAB_DOCAUTORIZANTE.equals(indRegistro) ){

    		//verificamos si el DET_MR_DOCAUTORIZ no hace referencia a otra declaracion
    		boolean indCambiaEstado = true;
	    		if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
    			//DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAO"); //se cambia por el ds XA - BUG 24375 - PAS20155E220000487
					Map<String, Object> param = new HashMap<String, Object>();
					param.put("codiEntidad", docAutoriza.getCodentidad());
					param.put("codTipDocum", docAutoriza.getCodtipodocum());
					param.put("numDocum", docAutoriza.getNumdocum());
					param.put("annDocum", docAutoriza.getAnndocum().substring(0,4));
					param.put("codAduana", codAduana);

				DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAOTx"); //BUG 24375 - PAS20155E220000487
					List<DetMrDocAutoriz> lstDetMrDocAutoriz =  detMrDocAutorizDAO.listDetMrdocAutoriz(param);

					if ( !CollectionUtils.isEmpty(lstDetMrDocAutoriz) ){
						for (DetMrDocAutoriz itemDetMrDocAutoriz : lstDetMrDocAutoriz){
							if (!itemDetMrDocAutoriz.getCsecdoc().toString().equals(docAutoriza.getNroitemdocum().toString())
								&& !itemDetMrDocAutoriz.getNumeCorre().trim().equals("")){
								indCambiaEstado = false;
								break;
							}
						}
					}
	    		}
    		//
	    	if (indCambiaEstado){
    		CabMrDocAutoriz cabMrDocAutoriz = new CabMrDocAutoriz();
			cabMrDocAutoriz.setAnodoc(docAutoriza.getAnndocum().substring(0,4));
			cabMrDocAutoriz.setCcoddoc(docAutoriza.getCodtipodocum());
			cabMrDocAutoriz.setCcordoc(docAutoriza.getNumdocum());
			cabMrDocAutoriz.setCodiAduan(codAduana);
			cabMrDocAutoriz.setCodiEntidad(docAutoriza.getCodentidad());
//			cabMrDocAutoriz.setCregimen(codRegimen);
//			cabMrDocAutoriz.setFecEmis(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
			cabMrDocAutoriz.setCodEstAut(estadoDoc);

			if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
				cabMrDocAutoriz.setAnnPrese(" ");
				cabMrDocAutoriz.setCodTipoDesp(" ");
				cabMrDocAutoriz.setNumCorre(" ");
				cabMrDocAutoriz.setFecIngDcl(SunatDateUtils.getDefaultDate());
				cabMrDocAutoriz.setCodRegDcl(" ");

			} else if (Constants.EST_DOCAUT_DESTINADA.equals(estadoDoc)|| Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){ // 
				cabMrDocAutoriz.setAnnPrese(annPrese);
				cabMrDocAutoriz.setCodTipoDesp(codModalidad);
				//cabMrDocAutoriz.setNumCorre(numeCorre);
				//cabMrDocAutoriz.setNumCorre(cabDeclara.get("NUM_DECLARACION").toString());
					//cabMrDocAutoriz.setNumCorre(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0')); //PAS20155E220000487
					cabMrDocAutoriz.setNumCorre(SunatStringUtils.lpad(numDeclaracion, 6, '0')); //PAS20155E220000487
				cabMrDocAutoriz.setFecIngDcl(SunatDateUtils.getCurrentDate());
				cabMrDocAutoriz.setCodRegDcl(codRegimen);
			}

				CabMrDocAutorizDAO cabMrDocAutorizDAO = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAOTx");
	    		cabMrDocAutorizDAO.updateByPrimaryKeySelective(cabMrDocAutoriz);
			}
    	}

    	if ( Constants.IND_REGISTRO_DOCAUTORIZANTE.equals(indRegistro) || Constants.IND_REGISTRO_DET_DOCAUTORIZANTE.equals(indRegistro) ){


    		 DetMrDocAutoriz detMrDocAutoriz = new DetMrDocAutoriz();
		     detMrDocAutoriz.setAnodoc(docAutoriza.getAnndocum().substring(0,4));
		     detMrDocAutoriz.setCcoddoc(docAutoriza.getCodtipodocum());
		     detMrDocAutoriz.setCcordoc(docAutoriza.getNumdocum());
		     detMrDocAutoriz.setCodiAduan(codAduana);
		     detMrDocAutoriz.setCodiEntidad(docAutoriza.getCodentidad());
//		     detMrDocAutoriz.setCregimen(codRegimen);
//		     detMrDocAutoriz.setFecEmis(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
		     detMrDocAutoriz.setCsecdoc(docAutoriza.getNroitemdocum().toString());

		     DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAOTx");//movido por PAS20155E220000306

		     if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
		    	 detMrDocAutoriz.setAnoPrese(" ");
			     detMrDocAutoriz.setNumeCorre(" ");
			     detMrDocAutoriz.setCodiRegi(" ");
			     detMrDocAutoriz.setNumeSerie(" "); 	 

		     } else if (Constants.EST_DOCAUT_DESTINADA.equals(estadoDoc) || Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){
		    	 //Inicio Bloque movido PAS20155E220000487
		         //Inicio de cambios por PAS20155E220000306 - SAU201510002000033
		     //Se cambio selectByPrimaryKey por SAU20153P002000123
		     //DetMrDocAutoriz detMrDocAutoExiste=detMrDocAutorizDAO.selectByPrimaryKey(docAutoriza.getAnndocum().substring(0,4), docAutoriza.getCodtipodocum(), docAutoriza.getNumdocum(), codAduana,
		     //			docAutoriza.getCodentidad(), codRegimen, docAutoriza.getNroitemdocum().toString(), SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
		     Map<String,Object> params = new HashMap<String,Object>();
		     params.put("codientidad", docAutoriza.getCodentidad());					
		     params.put("ccoddoc", docAutoriza.getCodtipodocum());
		     params.put("ccordoc", docAutoriza.getNumdocum());
		     if (SunatStringUtils.length(docAutoriza.getAnndocum())>3)
		    	 params.put("anodoc",docAutoriza.getAnndocum().substring(0,4));
		     else
		    	 params.put("anodoc",docAutoriza.getAnndocum());
		     params.put("codiAduan", codAduana);					
		     params.put("cregimen", codRegimen);
		     params.put("csecdoc", docAutoriza.getNroitemdocum());			
		     params.put("fecEmis", SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));		     
		     DetMrDocAutoriz detMrDocAutoExiste = detMrDocAutorizDAO.getDetMrDocAutoriza(params);

		     Boolean existeDetMrDocAuto = false;
		     if(detMrDocAutoExiste!=null && detMrDocAutoExiste.getAnoPrese()!=" " && detMrDocAutoExiste.getCodiRegi()!=" " && 
		    		 detMrDocAutoExiste.getNumeCorre()!= " " && detMrDocAutoExiste.getNumeSerie()!=" "){
		    	 existeDetMrDocAuto=true;
		     }
		     //Fin de cambios por PAS20155E220000306 - SAU201510002000033
			     //Fin Bloque movido PAS20155E220000487

		    	 if(!existeDetMrDocAuto){//Adicionado por PAS20155E220000306 - SAU201510002000033
		    	 if(annPrese.length() == 4)
		    	 detMrDocAutoriz.setAnoPrese(annPrese.substring(2,4));
			     //detMrDocAutoriz.setNumeCorre(numeCorre);
		    	 //detMrDocAutoriz.setNumeCorre(cabDeclara.get("NUM_DECLARACION").toString());
			    	 //detMrDocAutoriz.setNumeCorre(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0')); //PAS20155E220000487
			    	 detMrDocAutoriz.setNumeCorre(SunatStringUtils.lpad(numDeclaracion, 6, '0')); //PAS20155E220000487
			     detMrDocAutoriz.setCodiRegi(codRegimen);
			     detMrDocAutoriz.setNumeSerie(numeSerie);
		     } 
		     } 

		     if (Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){
 				 detMrDocAutoriz.setCodUniMedc(codUniComer);	   
			     detMrDocAutoriz.setCntQuniCom(cntUniComer);	   
			     detMrDocAutoriz.setCntPesoNeto(cntPesoNeto);
		     }

//    		DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAOTx");//movido arriba por PAS20155E220000306
    		detMrDocAutorizDAO.updateByPrimaryKeySelective(detMrDocAutoriz);
    	}
	}*/

	//PAS20155E220000487 - se modifico para que no consulte al cab_declara
	@Deprecated
	public void actualizarDocAutorizanteIQBF(String indRegistro, String estadoDoc, DatoDocAutorizante docAutoriza, String codAduana,
			String codRegimen, String numCorreDoc, String annPrese, String numeSerie, String codModalidad, String codUniComer, BigDecimal cntUniComer, BigDecimal cntPesoNeto){

		if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
			this.actualizarDocAutorizanteIQBF(indRegistro, estadoDoc, docAutoriza, codAduana, null, null);

		}else{
			//Obtener el num_declara
			Map<String, Object> cabDeclara = new HashMap<String,Object>();
			if (numCorreDoc != null){
				if (!SunatStringUtils.isEmptyTrim(numCorreDoc)){
					Map<String,Object> mapKey = new HashMap<String,Object>();
					mapKey.put("NUM_CORREDOC", numCorreDoc);
					CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
					cabDeclara = cabDeclaraDAO.findMapDUAByPk(mapKey); 	
				}
			}

			Declaracion declaracion = new Declaracion();
			declaracion.setDua(new DUA());
			declaracion.setNumeroDeclaracion(new Long(cabDeclara.get("NUM_DECLARACION").toString()));
			declaracion.getDua().setAnnpresen(new Integer(annPrese));
			//declaracion.getDua().setCodaduanaorden(codAduana);
			declaracion.getDua().setCodregimen(codRegimen);
			declaracion.getDua().setCodmodalidad(codModalidad);

			DatoSerie serie = new DatoSerie();
			serie.setNumserie(new Integer(numeSerie));
			serie.setCodunicomer(codUniComer);
			serie.setCntunicomer(cntUniComer);
			serie.setCntpesoneto(cntPesoNeto);

			this.actualizarDocAutorizanteIQBF(indRegistro, estadoDoc, docAutoriza, codAduana, declaracion, serie);
		}
	}

	//PAS20155E220000487 - se modifico para que no consulte al cab_declara
	public void actualizarDocAutorizanteIQBF(String indRegistro, String estadoDoc, DatoDocAutorizante docAutoriza, String codAduana, Declaracion declaracion, DatoSerie serie){
		/*//Obtener el num_declara
    	Map<String, Object> cabDeclara = new HashMap<String,Object>();
    	if (numeCorre != null){
    		if (!SunatStringUtils.isEmptyTrim(numeCorre)){
            	Map<String,Object> mapKey = new HashMap<String,Object>();
            	mapKey.put("NUM_CORREDOC", numeCorre);
        		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
        		cabDeclara = cabDeclaraDAO.findMapDUAByPk(mapKey); 	
    		}
    	}*/	   	

		if ( Constants.IND_REGISTRO_DOCAUTORIZANTE.equals(indRegistro) || Constants.IND_REGISTRO_CAB_DOCAUTORIZANTE.equals(indRegistro) ){

			//verificamos si el DET_MR_DOCAUTORIZ no hace referencia a otra declaracion
			boolean indCambiaEstado = true;
			if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
				//DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAO"); //se cambia por el ds XA - BUG 24375 - PAS20155E220000487
				Map<String, Object> param = new HashMap<String, Object>();
				param.put("codiEntidad", docAutoriza.getCodentidad());
				param.put("codTipDocum", docAutoriza.getCodtipodocum());
				param.put("numDocum", docAutoriza.getNumdocum());
				param.put("annDocum", docAutoriza.getAnndocum().substring(0,4));
				param.put("codAduana", codAduana);

				DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAOTx"); //BUG 24375 - PAS20155E220000487
				List<DetMrDocAutoriz> lstDetMrDocAutoriz =  detMrDocAutorizDAO.listDetMrdocAutoriz(param);

				if ( !CollectionUtils.isEmpty(lstDetMrDocAutoriz) ){
					for (DetMrDocAutoriz itemDetMrDocAutoriz : lstDetMrDocAutoriz){
						if (!itemDetMrDocAutoriz.getCsecdoc().toString().equals(docAutoriza.getNroitemdocum().toString())
								&& !itemDetMrDocAutoriz.getNumeCorre().trim().equals("")){
							indCambiaEstado = false;
							break;
						}
					}
				}
			}
			//
			if (indCambiaEstado){
				CabMrDocAutoriz cabMrDocAutoriz = new CabMrDocAutoriz();
				cabMrDocAutoriz.setAnodoc(docAutoriza.getAnndocum().substring(0,4));
				cabMrDocAutoriz.setCcoddoc(docAutoriza.getCodtipodocum());
				cabMrDocAutoriz.setCcordoc(docAutoriza.getNumdocum());
				cabMrDocAutoriz.setCodiAduan(codAduana);
				cabMrDocAutoriz.setCodiEntidad(docAutoriza.getCodentidad());
				//			cabMrDocAutoriz.setCregimen(codRegimen);
				//			cabMrDocAutoriz.setFecEmis(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
				cabMrDocAutoriz.setCodEstAut(estadoDoc);

				if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
					cabMrDocAutoriz.setAnnPrese(" ");
					cabMrDocAutoriz.setCodTipoDesp(" ");
					cabMrDocAutoriz.setNumCorre(" ");
					cabMrDocAutoriz.setFecIngDcl(SunatDateUtils.getDefaultDate());
					cabMrDocAutoriz.setCodRegDcl(" ");

				} else if (Constants.EST_DOCAUT_DESTINADA.equals(estadoDoc)|| Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){ // 
					cabMrDocAutoriz.setAnnPrese(declaracion.getDua().getAnnpresen().toString());
					cabMrDocAutoriz.setCodTipoDesp(declaracion.getDua().getCodmodalidad());
					//cabMrDocAutoriz.setNumCorre(numeCorre);
					//cabMrDocAutoriz.setNumCorre(cabDeclara.get("NUM_DECLARACION").toString());
					//cabMrDocAutoriz.setNumCorre(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0')); //PAS20155E220000487
					cabMrDocAutoriz.setNumCorre(SunatStringUtils.lpad(declaracion.getNumeroDeclaracion().toString(), 6, '0')); //PAS20155E220000487
					cabMrDocAutoriz.setFecIngDcl(SunatDateUtils.getCurrentDate());
					cabMrDocAutoriz.setCodRegDcl(declaracion.getDua().getCodregimen());
				}

				CabMrDocAutorizDAO cabMrDocAutorizDAO = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAOTx");
				cabMrDocAutorizDAO.updateByPrimaryKeySelective(cabMrDocAutoriz);
			}
		}

		if ( Constants.IND_REGISTRO_DOCAUTORIZANTE.equals(indRegistro) || Constants.IND_REGISTRO_DET_DOCAUTORIZANTE.equals(indRegistro) ){
			DetMrDocAutoriz detMrDocAutoriz = new DetMrDocAutoriz();
			detMrDocAutoriz.setAnodoc(docAutoriza.getAnndocum().substring(0,4));
			detMrDocAutoriz.setCcoddoc(docAutoriza.getCodtipodocum());
			detMrDocAutoriz.setCcordoc(docAutoriza.getNumdocum());
			detMrDocAutoriz.setCodiAduan(codAduana);
			detMrDocAutoriz.setCodiEntidad(docAutoriza.getCodentidad());
			//		     detMrDocAutoriz.setCregimen(codRegimen);
			//		     detMrDocAutoriz.setFecEmis(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
			detMrDocAutoriz.setCsecdoc(docAutoriza.getNroitemdocum().toString());

			DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAOTx");//movido por PAS20155E220000306

			if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
				detMrDocAutoriz.setAnoPrese(" ");
				detMrDocAutoriz.setNumeCorre(" ");
				detMrDocAutoriz.setCodiRegi(" ");
				detMrDocAutoriz.setNumeSerie(" "); 	 

			} else if (Constants.EST_DOCAUT_DESTINADA.equals(estadoDoc) || Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){
				//Inicio Bloque movido PAS20155E220000487
				//Inicio de cambios por PAS20155E220000306 - SAU201510002000033
				//Se cambio selectByPrimaryKey por SAU20153P002000123
				//DetMrDocAutoriz detMrDocAutoExiste=detMrDocAutorizDAO.selectByPrimaryKey(docAutoriza.getAnndocum().substring(0,4), docAutoriza.getCodtipodocum(), docAutoriza.getNumdocum(), codAduana,
				//			docAutoriza.getCodentidad(), codRegimen, docAutoriza.getNroitemdocum().toString(), SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
				Map<String,Object> params = new HashMap<String,Object>();
				params.put("codientidad", docAutoriza.getCodentidad());					
				params.put("ccoddoc", docAutoriza.getCodtipodocum());
				params.put("ccordoc", docAutoriza.getNumdocum());
				if (SunatStringUtils.length(docAutoriza.getAnndocum())>3)
					params.put("anodoc",docAutoriza.getAnndocum().substring(0,4));
				else
					params.put("anodoc",docAutoriza.getAnndocum());
				params.put("codiAduan", codAduana);					
				params.put("cregimen", declaracion.getDua().getCodregimen());
				params.put("csecdoc", docAutoriza.getNroitemdocum());			
				params.put("fecEmis", SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));		     
				DetMrDocAutoriz detMrDocAutoExiste = detMrDocAutorizDAO.getDetMrDocAutoriza(params);

				Boolean existeDetMrDocAuto = false;
				if(detMrDocAutoExiste!=null && detMrDocAutoExiste.getAnoPrese()!=" " && detMrDocAutoExiste.getCodiRegi()!=" " && 
						detMrDocAutoExiste.getNumeCorre()!= " " && detMrDocAutoExiste.getNumeSerie()!=" "){
					existeDetMrDocAuto=true;
				}
				//Fin de cambios por PAS20155E220000306 - SAU201510002000033
				//Fin Bloque movido PAS20155E220000487

				if(!existeDetMrDocAuto){//Adicionado por PAS20155E220000306 - SAU201510002000033
					if(declaracion.getDua().getAnnpresen().toString().length() == 4)
						detMrDocAutoriz.setAnoPrese(declaracion.getDua().getAnnpresen().toString().substring(2,4));
					//detMrDocAutoriz.setNumeCorre(numeCorre);
					//detMrDocAutoriz.setNumeCorre(cabDeclara.get("NUM_DECLARACION").toString());
					//detMrDocAutoriz.setNumeCorre(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0')); //PAS20155E220000487
					detMrDocAutoriz.setNumeCorre(SunatStringUtils.lpad(declaracion.getNumeroDeclaracion().toString(), 6, '0')); //PAS20155E220000487
					detMrDocAutoriz.setCodiRegi(declaracion.getDua().getCodregimen());
					detMrDocAutoriz.setNumeSerie(serie.getNumserie().toString());
				} 
			} 

			if (Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){
				detMrDocAutoriz.setCodUniMedc(serie.getCodunicomer());	   
				detMrDocAutoriz.setCntQuniCom(serie.getCntunicomer());	   
				detMrDocAutoriz.setCntPesoNeto(serie.getCntpesoneto());
			}

			//DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAOTx");//movido arriba por PAS20155E220000306
			detMrDocAutorizDAO.updateByPrimaryKeySelective(detMrDocAutoriz);
		}

	}

	public void iniciaBatchAutorizante(){
		CabMrDocAutorizBatchDAO cabMrDocAutorizBatchDAO = (CabMrDocAutorizBatchDAO) fabricaDeServicios.getService("cabMrDocAutorizBatchDAO");
		DetMrDocAutorizBatchDAO detMrDocAutorizBatchDAO = (DetMrDocAutorizBatchDAO) fabricaDeServicios.getService("detMrDocAutorizBatchDAO");
		cabMrDocAutorizBatchDAO.iniciar();
		detMrDocAutorizBatchDAO.iniciar();
	}

	public void procesarBatchAutorizante() throws Exception{
		CabMrDocAutorizBatchDAO cabMrDocAutorizBatchDAO = (CabMrDocAutorizBatchDAO) fabricaDeServicios.getService("cabMrDocAutorizBatchDAO");
		DetMrDocAutorizBatchDAO detMrDocAutorizBatchDAO = (DetMrDocAutorizBatchDAO) fabricaDeServicios.getService("detMrDocAutorizBatchDAO");
		cabMrDocAutorizBatchDAO.procesarBatch();
		detMrDocAutorizBatchDAO.procesarBatch();
	}

	//PAS20155E220000487 - se modifico para que no consulte al cab_declara
	/*public void actualizarDocAutorizanteIQBFBatch(String indRegistro, String estadoDoc ,DatoDocAutorizante docAutoriza,String codAduana,
    		String codRegimen, String numeCorre, String annPrese, String numeSerie, String codModalidad,String codUniComer, BigDecimal cntUniComer,BigDecimal cntPesoNeto){
    	//Obtener el num_declara
    	Map<String, Object> cabDeclara = new HashMap<String,Object>();
    	if (numeCorre != null){
    		if (!SunatStringUtils.isEmptyTrim(numeCorre)){
            	Map<String,Object> mapKey = new HashMap<String,Object>();
            	mapKey.put("NUM_CORREDOC", numeCorre);
        		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
        		cabDeclara = cabDeclaraDAO.findMapDUAByPk(mapKey); 	
    		}
    	}	   	

    	if ( Constants.IND_REGISTRO_DOCAUTORIZANTE.equals(indRegistro) || Constants.IND_REGISTRO_CAB_DOCAUTORIZANTE.equals(indRegistro) ){

    		CabMrDocAutoriz cabMrDocAutoriz = new CabMrDocAutoriz();
			cabMrDocAutoriz.setAnodoc(docAutoriza.getAnndocum().substring(0,4));
			cabMrDocAutoriz.setCcoddoc(docAutoriza.getCodtipodocum());
			cabMrDocAutoriz.setCcordoc(docAutoriza.getNumdocum());
			cabMrDocAutoriz.setCodiAduan(codAduana);
			cabMrDocAutoriz.setCodiEntidad(docAutoriza.getCodentidad());
//			cabMrDocAutoriz.setCregimen(codRegimen);
//			cabMrDocAutoriz.setFecEmis(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));

			cabMrDocAutoriz.setCodEstAut(estadoDoc);
			if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
				cabMrDocAutoriz.setAnnPrese(" ");
				cabMrDocAutoriz.setCodTipoDesp(" ");
				cabMrDocAutoriz.setNumCorre(" ");
				cabMrDocAutoriz.setFecIngDcl(SunatDateUtils.getDefaultDate());
				cabMrDocAutoriz.setCodRegDcl(" ");
			} else if (Constants.EST_DOCAUT_DESTINADA.equals(estadoDoc)|| Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){ 
				cabMrDocAutoriz.setAnnPrese(annPrese);
				cabMrDocAutoriz.setCodTipoDesp(codModalidad);
				//cabMrDocAutoriz.setNumCorre(numeCorre);
				//cabMrDocAutoriz.setNumCorre(cabDeclara.get("NUM_DECLARACION").toString());
				//cabMrDocAutoriz.setNumCorre(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0'));  //PAS20155E220000487
				cabMrDocAutoriz.setNumCorre(SunatStringUtils.lpad(numDeclaracion, 6, '0'));  //PAS20155E220000487
				cabMrDocAutoriz.setFecIngDcl(SunatDateUtils.getCurrentDate());
				cabMrDocAutoriz.setCodRegDcl(codRegimen);
			}

    		cabMrDocAutorizBatchDAO.updateByPrimaryKeySelective(cabMrDocAutoriz);
    	}

    	if ( Constants.IND_REGISTRO_DOCAUTORIZANTE.equals(indRegistro) || Constants.IND_REGISTRO_DET_DOCAUTORIZANTE.equals(indRegistro) ){

    		 DetMrDocAutoriz detMrDocAutoriz = new DetMrDocAutoriz();
		     detMrDocAutoriz.setAnodoc(docAutoriza.getAnndocum().substring(0,4));
		     detMrDocAutoriz.setCcoddoc(docAutoriza.getCodtipodocum());
		     detMrDocAutoriz.setCcordoc(docAutoriza.getNumdocum());
		     detMrDocAutoriz.setCodiAduan(codAduana);
		     detMrDocAutoriz.setCodiEntidad(docAutoriza.getCodentidad());
//		     detMrDocAutoriz.setCregimen(codRegimen);
//		     detMrDocAutoriz.setFecEmis(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
		     detMrDocAutoriz.setCsecdoc(docAutoriza.getNroitemdocum().toString());

		     if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
		    	 detMrDocAutoriz.setAnoPrese(" ");
			     detMrDocAutoriz.setNumeCorre(" ");
			     detMrDocAutoriz.setCodiRegi(" ");
			     detMrDocAutoriz.setNumeSerie(" "); 	 
		     } else if (Constants.EST_DOCAUT_DESTINADA.equals(estadoDoc) || Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){
		    	 if(annPrese.length() == 4)
		    	 detMrDocAutoriz.setAnoPrese(annPrese.substring(2,4));
			     //detMrDocAutoriz.setNumeCorre(numeCorre);
		    	 //detMrDocAutoriz.setNumeCorre(cabDeclara.get("NUM_DECLARACION").toString());
		    	 //detMrDocAutoriz.setNumeCorre(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0')); //PAS20155E220000487
		    	 detMrDocAutoriz.setNumeCorre(SunatStringUtils.lpad(numDeclaracion, 6, '0'));  //PAS20155E220000487
			     detMrDocAutoriz.setCodiRegi(codRegimen);
			     detMrDocAutoriz.setNumeSerie(numeSerie);
		     } 

		     if (Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){
 				 detMrDocAutoriz.setCodUniMedc(codUniComer);	   
			     detMrDocAutoriz.setCntQuniCom(cntUniComer);	   
			     detMrDocAutoriz.setCntPesoNeto(cntPesoNeto);
		     }

    		detMrDocAutorizBatchDAO.updateByPrimaryKeySelective(detMrDocAutoriz);
    	}
    }*/		 

	//PAS20155E220000487 - se modifico para que no consulte al cab_declara
	@Deprecated
	public void actualizarDocAutorizanteIQBFBatch(String indRegistro, String estadoDoc, DatoDocAutorizante docAutoriza, String codAduana,
			String codRegimen, String numCorreDoc, String annPrese, String numeSerie, String codModalidad,String codUniComer, BigDecimal cntUniComer,BigDecimal cntPesoNeto){

		if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
			this.actualizarDocAutorizanteIQBFBatch(indRegistro, estadoDoc, docAutoriza, codAduana, null, null);

		}else{
			//Obtener el num_declara
			Map<String, Object> cabDeclara = new HashMap<String,Object>();
			if (numCorreDoc != null){
				if (!SunatStringUtils.isEmptyTrim(numCorreDoc)){
					Map<String,Object> mapKey = new HashMap<String,Object>();
					mapKey.put("NUM_CORREDOC", numCorreDoc);
					CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
					cabDeclara = cabDeclaraDAO.findMapDUAByPk(mapKey); 	
				}
			}	 

			Declaracion declaracion = new Declaracion();
			declaracion.setDua(new DUA());
			declaracion.setNumeroDeclaracion(new Long(cabDeclara.get("NUM_DECLARACION").toString()));
			declaracion.getDua().setAnnpresen(new Integer(annPrese));
			//declaracion.getDua().setCodaduanaorden(codAduana);
			declaracion.getDua().setCodregimen(codRegimen);
			declaracion.getDua().setCodmodalidad(codModalidad);

			DatoSerie serie = new DatoSerie();
			serie.setNumserie(new Integer(numeSerie));
			serie.setCodunicomer(codUniComer);
			serie.setCntunicomer(cntUniComer);
			serie.setCntpesoneto(cntPesoNeto);

			this.actualizarDocAutorizanteIQBFBatch(indRegistro, estadoDoc, docAutoriza, codAduana, declaracion, serie);
		}
	}

	//PAS20155E220000487 - se modifico para que no consulte al cab_declara
	public void actualizarDocAutorizanteIQBFBatch(String indRegistro, String estadoDoc, DatoDocAutorizante docAutoriza, String codAduana, Declaracion declaracion, DatoSerie serie){	
		/*//Obtener el num_declara
    	Map<String, Object> cabDeclara = new HashMap<String,Object>();
    	if (numeCorre != null){
    		if (!SunatStringUtils.isEmptyTrim(numeCorre)){
            	Map<String,Object> mapKey = new HashMap<String,Object>();
            	mapKey.put("NUM_CORREDOC", numeCorre);
        		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
        		cabDeclara = cabDeclaraDAO.findMapDUAByPk(mapKey); 	
    		}
    	}*/	   	
		CabMrDocAutorizBatchDAO cabMrDocAutorizBatchDAO = (CabMrDocAutorizBatchDAO) fabricaDeServicios.getService("cabMrDocAutorizBatchDAO");
		DetMrDocAutorizBatchDAO detMrDocAutorizBatchDAO = (DetMrDocAutorizBatchDAO) fabricaDeServicios.getService("detMrDocAutorizBatchDAO");

		if ( Constants.IND_REGISTRO_DOCAUTORIZANTE.equals(indRegistro) || Constants.IND_REGISTRO_CAB_DOCAUTORIZANTE.equals(indRegistro) ){

			CabMrDocAutoriz cabMrDocAutoriz = new CabMrDocAutoriz();
			cabMrDocAutoriz.setAnodoc(docAutoriza.getAnndocum().substring(0,4));
			cabMrDocAutoriz.setCcoddoc(docAutoriza.getCodtipodocum());
			cabMrDocAutoriz.setCcordoc(docAutoriza.getNumdocum());
			cabMrDocAutoriz.setCodiAduan(codAduana);
			cabMrDocAutoriz.setCodiEntidad(docAutoriza.getCodentidad());
			//			cabMrDocAutoriz.setCregimen(codRegimen);
			//			cabMrDocAutoriz.setFecEmis(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));

			cabMrDocAutoriz.setCodEstAut(estadoDoc);
			if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
				cabMrDocAutoriz.setAnnPrese(" ");
				cabMrDocAutoriz.setCodTipoDesp(" ");
				cabMrDocAutoriz.setNumCorre(" ");
				cabMrDocAutoriz.setFecIngDcl(SunatDateUtils.getDefaultDate());
				cabMrDocAutoriz.setCodRegDcl(" ");

			} else if (Constants.EST_DOCAUT_DESTINADA.equals(estadoDoc)|| Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){ 
				cabMrDocAutoriz.setAnnPrese(declaracion.getDua().getAnnpresen().toString());
				cabMrDocAutoriz.setCodTipoDesp(declaracion.getDua().getCodmodalidad());
				//cabMrDocAutoriz.setNumCorre(numeCorre);
				//cabMrDocAutoriz.setNumCorre(cabDeclara.get("NUM_DECLARACION").toString());
				//cabMrDocAutoriz.setNumCorre(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0'));  //PAS20155E220000487
				cabMrDocAutoriz.setNumCorre(SunatStringUtils.lpad(declaracion.getNumeroDeclaracion().toString(), 6, '0'));  //PAS20155E220000487
				cabMrDocAutoriz.setFecIngDcl(SunatDateUtils.getCurrentDate());
				cabMrDocAutoriz.setCodRegDcl(declaracion.getDua().getCodregimen());
			}

			cabMrDocAutorizBatchDAO.updateByPrimaryKeySelective(cabMrDocAutoriz);
		}

		if ( Constants.IND_REGISTRO_DOCAUTORIZANTE.equals(indRegistro) || Constants.IND_REGISTRO_DET_DOCAUTORIZANTE.equals(indRegistro) ){
			DetMrDocAutoriz detMrDocAutoriz = new DetMrDocAutoriz();
			detMrDocAutoriz.setAnodoc(docAutoriza.getAnndocum().substring(0,4));
			detMrDocAutoriz.setCcoddoc(docAutoriza.getCodtipodocum());
			detMrDocAutoriz.setCcordoc(docAutoriza.getNumdocum());
			detMrDocAutoriz.setCodiAduan(codAduana);
			detMrDocAutoriz.setCodiEntidad(docAutoriza.getCodentidad());
			//		     detMrDocAutoriz.setCregimen(codRegimen);
			//		     detMrDocAutoriz.setFecEmis(SunatDateUtils.getIntegerFromDate(docAutoriza.getFecemision()));
			detMrDocAutoriz.setCsecdoc(docAutoriza.getNroitemdocum().toString());

			if (Constants.EST_DOCAUT_OTORGADA.equals(estadoDoc)){
				detMrDocAutoriz.setAnoPrese(" ");
				detMrDocAutoriz.setNumeCorre(" ");
				detMrDocAutoriz.setCodiRegi(" ");
				detMrDocAutoriz.setNumeSerie(" "); 	 

			} else if (Constants.EST_DOCAUT_DESTINADA.equals(estadoDoc) || Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){
				if(declaracion.getDua().getAnnpresen().toString().length() == 4)
					detMrDocAutoriz.setAnoPrese(declaracion.getDua().getAnnpresen().toString().substring(2,4));
				//detMrDocAutoriz.setNumeCorre(numeCorre);
				//detMrDocAutoriz.setNumeCorre(cabDeclara.get("NUM_DECLARACION").toString());
				//detMrDocAutoriz.setNumeCorre(SunatStringUtils.lpad(cabDeclara.get("NUM_DECLARACION").toString(), 6, '0')); //PAS20155E220000487
				detMrDocAutoriz.setNumeCorre(SunatStringUtils.lpad(declaracion.getNumeroDeclaracion().toString(), 6, '0'));  //PAS20155E220000487
				detMrDocAutoriz.setCodiRegi(declaracion.getDua().getCodregimen());
				detMrDocAutoriz.setNumeSerie(serie.getNumserie().toString());
			} 

			if (Constants.EST_DOCAUT_CONCLUIDA.equals(estadoDoc)){
				detMrDocAutoriz.setCodUniMedc(serie.getCodunicomer());	   
				detMrDocAutoriz.setCntQuniCom(serie.getCntunicomer());	   
				detMrDocAutoriz.setCntPesoNeto(serie.getCntpesoneto());
			}

			detMrDocAutorizBatchDAO.updateByPrimaryKeySelective(detMrDocAutoriz);
		}

	}

	@SuppressWarnings("unchecked")
	public String validarLevanteNoAutorizadoIQBF(Long numCorreDoc,String codAduana,String codRegi,Integer annPrese,Integer numDeclara,String codModalidad){
		String msjLevanteNoAutorizado = "LEVANTE NO AUTORIZADO";
		String indTipoError = "ErrorGeneral";
		Map<String,Object> mapValidaDocAutoriza = validarDocAutorizaLevanteDUA(numCorreDoc, codAduana, codRegi, annPrese, numDeclara);

		if((Boolean)mapValidaDocAutoriza.get("indDocAutorizaIQBF")){
			List<Map<String,String>> lstErrores = (List<Map<String,String>>)mapValidaDocAutoriza.get("lstErrores");

			List<String> lstCantidadPesoConGranel = new ArrayList<String>();
			lstCantidadPesoConGranel.add("35369");
			lstCantidadPesoConGranel.add("35370");

			List<String> lstCantidadPesoSinGranel  = new ArrayList<String>();
			lstCantidadPesoSinGranel.add("35371");
			lstCantidadPesoSinGranel.add("35372");

			if(!lstErrores.isEmpty()){
				for(Map<String,String> error: lstErrores){
					if(lstCantidadPesoConGranel.contains(error.get("codError"))){
						indTipoError = "ErrorConGranel";
						break;
					}
					if(lstCantidadPesoSinGranel.contains(error.get("codError"))){
						indTipoError = "ErrorSinGranel";
						break;
					}
				}

				if(indTipoError.equals("ErrorGeneral")){
					msjLevanteNoAutorizado = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35390",new String[]{""}).get("desError");
				}else{
					if(indTipoError.equals("ErrorConGranel") && ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL.equals(codModalidad)){
						msjLevanteNoAutorizado = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35388",new String[]{""}).get("desError");
					}

					if(indTipoError.equals("ErrorConGranel") && (ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO.equals(codModalidad) || ConstantesDataCatalogo.COD_MODALIDAD_URGENTE.equals(codModalidad))){
						msjLevanteNoAutorizado = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35389",new String[]{""}).get("desError");
					}

					if(indTipoError.equals("ErrorSinGranel")){
						msjLevanteNoAutorizado = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35388",new String[]{""}).get("desError");
					}
				}
			}
		}
		return msjLevanteNoAutorizado;
	}

	public void actualizarDocAutRectificacion(String codTabla,Map<String,Object> key,Map<String,Object> datos,String tipoMod){

		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");

		Map<String,Object> params = new HashMap<String,Object>();
		params.put("numCorreDoc", key.get("NUM_CORREDOC"));
		params.put("numSecDoc", key.get("NUM_SECDOC"));
		params.put("codTipOper", key.get("COD_TIPOPER"));
		//params.put("indDocAutUsado",Constants.IND_DOCAUT_PERTENECE_DECLARACION); //PAS20155E220000487
		params.put("indDocAutoUsado",Constants.IND_DOCAUT_PERTENECE_DECLARACION); //PAS20155E220000487 - se corrige variable
		//DatoDocAutorizante docAutoriza = docAutAsociadoDAO.listDocAutorizante(params).get(0);
		List<DatoDocAutorizante> lstdocAutoriza =  docAutAsociadoDAO.listDocAutorizante(params);
		//mol por bug 
		if(!lstdocAutoriza.isEmpty()){
			DatoDocAutorizante docAutoriza =lstdocAutoriza.get(0);
			if(Constants.IND_REGISTRO_ANULADO.equals(tipoMod) ){
				if(ConstantesDataCatalogo.TABLA_DOCASOCIADO.equals(codTabla) ){

					if(Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodentidad()) && 
							Constants.COD_TIPO_DOCAUT_IQBF.equals(docAutoriza.getCodtipodocum()) &&
							(Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodsubentidad()) ||
									Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA.equals(docAutoriza.getCodsubentidad()))){ //PAS20155E220000487 - Se agrega IQBF Mineria

						//PAS20155E220000487 - se comenta
						/*CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
    					Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(key); 


        				actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DOCAUTORIZANTE,Constants.EST_DOCAUT_OTORGADA,docAutoriza,
        						cabDeclara.get("COD_ADUANA").toString(), cabDeclara.get("COD_REGIMEN").toString(), cabDeclara.get("NUM_CORREDOC").toString(),
        						cabDeclara.get("ANN_PRESEN").toString(), "", cabDeclara.get("COD_MODALIDAD").toString(), "", null, null);*/
						//PAS20155E220000487
						this.actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DOCAUTORIZANTE, Constants.EST_DOCAUT_OTORGADA, docAutoriza, docAutoriza.getCodigoAduanaAut(), null, null);

					}
				}
			}

			if(Constants.IND_REGISTRO_NUEVO.equals(tipoMod) ){ //|| tipoMod.equals("R")
				if(ConstantesDataCatalogo.TABLA_DOCASOCIADO.equals(codTabla) ){

					if(Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodentidad()) && 
							Constants.COD_TIPO_DOCAUT_IQBF.equals(docAutoriza.getCodtipodocum()) &&
							(Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodsubentidad()) ||
									Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA.equals(docAutoriza.getCodsubentidad()))){ //PAS20155E220000487 - Se agrega IQBF Mineria                   

						CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
						Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(key); 

						String estadoDocu = Constants.EST_DOCAUT_DESTINADA;
						/*if (indRegu.equals("Regu")){
    						estadoDocu = Constants.EST_DOCAUT_CONCLUIDA;
    					}*/

						//Inicio PAS20155E220000487 - se necesita los datos de la serie - BUG 24441
						if (!key.containsKey("NUM_SECSERIE")) {
							params = new HashMap<String,Object>();
							params.put("numCorreDoc", key.get("NUM_CORREDOC"));
							params.put("numSecDoc", key.get("NUM_SECDOC"));
							params.put("codTipOper", key.get("COD_TIPOPER"));
							params.put("indDel", "0");
							Map<String,Object> docAutorizaMap = docAutAsociadoDAO.listDocAutorizaSerie(params).get(0);
							key.put("NUM_SECSERIE", docAutorizaMap.get("numSecSerie"));
						}
						//Final PAS20155E220000487 - BUG 24441

						//PAS20155E220000487 - se comento
						/*actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_CAB_DOCAUTORIZANTE,estadoDocu,docAutoriza,
        						cabDeclara.get("COD_ADUANA").toString(), cabDeclara.get("COD_REGIMEN").toString(), cabDeclara.get("NUM_CORREDOC").toString(),
        						cabDeclara.get("ANN_PRESEN").toString(), "", cabDeclara.get("COD_MODALIDAD").toString(), "", null, null);*/
						//PAS20155E220000487
						Declaracion declaracion = new Declaracion();
						declaracion.setDua(new DUA());
						declaracion.setNumeroDeclaracion(new Long(cabDeclara.get("NUM_DECLARACION").toString()));
						declaracion.getDua().setAnnpresen(new Integer(cabDeclara.get("ANN_PRESEN").toString()));
						//declaracion.getDua().setCodaduanaorden(codAduana);
						declaracion.getDua().setCodregimen(cabDeclara.get("COD_REGIMEN").toString());
						declaracion.getDua().setCodmodalidad(cabDeclara.get("COD_MODALIDAD").toString());

						//PAS20155E220000487 - se necesita los datos de la serie - BUG 24441
						DatoSerie serie = new DatoSerie();
						serie.setNumserie(new Integer(key.get("NUM_SECSERIE").toString()));

						//this.actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_CAB_DOCAUTORIZANTE, estadoDocu, docAutoriza, cabDeclara.get("COD_ADUANA").toString(), declaracion, null); //PAS20155E220000487 - BUG 24441
						this.actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DOCAUTORIZANTE, estadoDocu, docAutoriza, cabDeclara.get("COD_ADUANA").toString(), declaracion, serie); //PAS20155E220000487 - BUG 24441 (cuando se cambia de numero de documento no cambiaba el detalle)
					}
				}else{ 
					if(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION.equals(codTabla) ){

						if(Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodentidad()) && 
								Constants.COD_TIPO_DOCAUT_IQBF.equals(docAutoriza.getCodtipodocum()) &&
								(Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(docAutoriza.getCodsubentidad()) ||
										Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA.equals(docAutoriza.getCodsubentidad()))){ //PAS20155E220000487 - Se agrega IQBF Mineria     

							CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
							Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(key); 

							String estadoDocu = Constants.EST_DOCAUT_DESTINADA;
							//Inicio PAS20155E220000487 - se comento no se utiliza estos campos cuando es destinada
							//String codUniComer = "";
							//BigDecimal cntUniComer = new BigDecimal("0");
							//BigDecimal cntPesoNeto = new BigDecimal("0");
							//Final PAS20155E220000487 - se comento

							//if (indRegu.equals("Regu")){

							//params = new HashMap<String,Object>();
							//params.put("numCorreDoc", key.get("NUM_CORREDOC"));
							//params.put("numSecDoc", key.get("NUM_SECDOC"));
							//params.put("codTipOper", key.get("COD_TIPOPER"));
							//params.put("numSecSerie", key.get("NUM_SECSERIE"));
							//params.put("indDel", "0");
							//Map<String,Object> docAutorizaMap = docAutAsociadoDAO.listDocAutorizaSerie(params).get(0);

							//codUniComer = (String) docAutorizaMap.get("codUniComer");
							//cntUniComer = (BigDecimal) docAutorizaMap.get("cntComer");
							//cntPesoNeto = (BigDecimal) docAutorizaMap.get("cntPesoNeto");

							//estadoDocu = Constants.EST_DOCAUT_CONCLUIDA;
							//}

							if (!key.containsKey("NUM_SECSERIE")) {
								params = new HashMap<String,Object>();
								params.put("numCorreDoc", key.get("NUM_CORREDOC"));
								params.put("numSecDoc", key.get("NUM_SECDOC"));
								params.put("codTipOper", key.get("COD_TIPOPER"));
								params.put("indDel", "0");
								Map<String,Object> docAutorizaMap = docAutAsociadoDAO.listDocAutorizaSerie(params).get(0);
								key.put("NUM_SECSERIE", docAutorizaMap.get("numSecSerie"));
							}

							//PAS20155E220000487 - se comento
							/*actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DET_DOCAUTORIZANTE, estadoDocu, docAutoriza,
    	        						cabDeclara.get("COD_ADUANA").toString(), cabDeclara.get("COD_REGIMEN").toString(), cabDeclara.get("NUM_CORREDOC").toString(),
    	        						cabDeclara.get("ANN_PRESEN").toString(), key.get("NUM_SECSERIE").toString(), cabDeclara.get("COD_MODALIDAD").toString(), codUniComer, cntUniComer, cntPesoNeto);*/
							//PAS20155E220000487
							Declaracion declaracion = new Declaracion();
							declaracion.setDua(new DUA());
							declaracion.setNumeroDeclaracion(new Long(cabDeclara.get("NUM_DECLARACION").toString()));
							declaracion.getDua().setAnnpresen(new Integer(cabDeclara.get("ANN_PRESEN").toString()));
							//declaracion.getDua().setCodaduanaorden(codAduana);
							declaracion.getDua().setCodregimen(cabDeclara.get("COD_REGIMEN").toString());
							declaracion.getDua().setCodmodalidad(cabDeclara.get("COD_MODALIDAD").toString());

							DatoSerie serie = new DatoSerie();
							serie.setNumserie(new Integer(key.get("NUM_SECSERIE").toString()));
							//PAS20155E220000487 - se comento no se utiliza estos campos cuando es destinada
							//serie.setCodunicomer(codUniComer);
							//serie.setCntunicomer(cntUniComer);
							//serie.setCntpesoneto(cntPesoNeto);

							this.actualizarDocAutorizanteIQBF(Constants.IND_REGISTRO_DET_DOCAUTORIZANTE, estadoDocu, docAutoriza, cabDeclara.get("COD_ADUANA").toString(), declaracion, serie);

						}
					}
				}
			}
		}    
	}    

	//RIN14 CUR14.04.01
	@SuppressWarnings("unchecked")
	public String validaRucDocAutorizaIQBF(Map declaracionActual){
		String retornoError ="";
		DatoDocAutorizante datoDocAutorizante = null;
		List<Map<String, Object>> lstDocAutAsociado = new ArrayList<Map<String,Object>>();

		if(declaracionActual.get("lstDocAutAsociado") == null){
			Map<String, String> mapPk = new HashMap<String, String>();
			mapPk.put("NUM_CORREDOC", declaracionActual.get("NUM_CORREDOC").toString());
			mapPk.put("IND_DEL", "0");

			DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
			List<Map<String, Object>> listaDocAsoc = docAutAsociadoDAO.select(mapPk);
			if (!CollectionUtils.isEmpty(listaDocAsoc))
			{
				declaracionActual.put("lstDocAutAsociado", listaDocAsoc);
			}
		}

		lstDocAutAsociado = (List<Map<String, Object>>) declaracionActual.get("lstDocAutAsociado");
		List<Map<String, Object>> lstDetAutorizacion = (List<Map<String, Object>>) declaracionActual.get("lstDetAutorizacion");
		String numSerie="";

		if(!CollectionUtils.isEmpty(lstDocAutAsociado) && !CollectionUtils.isEmpty(lstDetAutorizacion) ){

			String codigoEntidad;
			String codigoTipoDocAsociado;
			String codigoSubEntidad;

			for(Map<String, Object> docAutAsociado :lstDocAutAsociado){
				codigoEntidad = (String)docAutAsociado.get("COD_ENTI");
				codigoTipoDocAsociado = (String)docAutAsociado.get("COD_TIPDOCASO");
				codigoSubEntidad = (String)docAutAsociado.get("COD_SUBENTI");

				/*if(Constants.COD_ENTIDAD_DOCAUT_IQBF.equals((String)docAutAsociado.get("COD_ENTI")) &&
  				  Constants.COD_TIPO_DOCAUT_IQBF.equals((String)docAutAsociado.get("COD_TIPDOCASO")) &&
	  				     (Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals((String)docAutAsociado.get("COD_SUBENTI"))){*/
				if(Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(codigoEntidad) &&
						Constants.COD_TIPO_DOCAUT_IQBF.equals(codigoTipoDocAsociado) &&
						(Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(codigoSubEntidad) ||
								Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA.equals(codigoSubEntidad))){ //PAS20155E220000487 - Se agrega IQBF Mineria
					datoDocAutorizante = new DatoDocAutorizante();
					datoDocAutorizante.setAnndocum(((BigDecimal) docAutAsociado.get("ANN_DOC")).toString());
					//datoDocAutorizante.setCodtipodocum((String) docAutAsociado.get("COD_TIPDOCASO"));
					datoDocAutorizante.setCodtipodocum(codigoTipoDocAsociado);
					datoDocAutorizante.setNumdocum((String) docAutAsociado.get("NUM_DOC"));
					//datoDocAutorizante.setCodentidad((String) docAutAsociado.get("COD_ENTI"));
					datoDocAutorizante.setCodentidad(codigoEntidad);
					//amancilla P_SNADE046-2069 datoDocAutorizante.setNroitemdocum((Integer) docAutAsociado.get("NRO_ITEMDOCUM"));
					datoDocAutorizante.setNroitemdocum(SunatNumberUtils.toInteger(docAutAsociado.get("NRO_ITEMDOCUM")));
					datoDocAutorizante.setFecemision((Date)docAutAsociado.get("FEC_EMIS"));
					//datoDocAutorizante.setCodsubtipodocum((String) docAutAsociado.get("COD_SUBTIPO_DOCUM"));
					datoDocAutorizante.setCodsubtipodocum((String) docAutAsociado.get("COD_SUBTIPODOC")); //PAS20155E220000487 no existe COD_SUBTIPO_DOCUM en el query
					//datoDocAutorizante.setCodsubentidad((String) docAutAsociado.get("COD_SUBENTI"));
					datoDocAutorizante.setCodsubentidad(codigoSubEntidad);

					for (Map<String, Object> detAutoriza : lstDetAutorizacion){
						//amancilla parche
						//if (((BigDecimal)docAutAsociado.get("NUM_SECDOC")).equals((BigDecimal)detAutoriza.get("NUM_SECDOC")) &&
						if ((docAutAsociado.get("NUM_SECDOC").toString()).equals(detAutoriza.get("NUM_SECDOC").toString()) &&
								((String)docAutAsociado.get("COD_TIPOPER")).equals((String)detAutoriza.get("COD_TIPOPER")) &&  
								((String) detAutoriza.get("COD_TIPOPER")).equals("P")){
							numSerie = String.valueOf((BigDecimal) detAutoriza.get("NUM_SECSERIE"));
						}
					}

					break;
				}


			}
			if(datoDocAutorizante!=null){
				List<Map<String,String>> listaErrores = validarRucDocAutoriza(datoDocAutorizante, (String)declaracionActual.get("COD_ADUANA"),
						(String)declaracionActual.get("COD_REGIMEN"), null, (String)declaracionActual.get("NUM_DOCIDENT_PIM"), numSerie); 
				retornoError =listaErrores.isEmpty()?"":(String)listaErrores.get(0).get("desError");
			}  

		}
		return retornoError;
	}

	private List<Map<String,String>> validarSubEntidadesDocAutorizaPrecedente(DatoSerie serie, 
			Map<String, Object> variablesIngreso) {

		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		variablesIngreso.remove("indExcluyeDIQBF");
		variablesIngreso.remove("indExcluyeSENASA01");
		List<MRestri> lstMrestri = obtenerListaMercRestringida(serie, SunatDateUtils.getCurrentDate(), variablesIngreso);
		if (lstMrestri == null) return lstErrores; 
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<DatoRegPrecedencia> lstPreceDua = serie.getListRegPrecedencia();
		if (lstPreceDua==null) return lstErrores;
		String codModalidad = ((DUA) serie.getPadre()).getCodmodalidad();

		//PAS20155E220000371
		List<String> listaEntidad = new ArrayList<String>();

		DatoDocAutorizante docAutorizante = null;//PAS20171U220200011 PAS201930001100005
		List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, (DUA) serie.getPadre(), variablesIngreso, false); //BUG 24309-24326 - PAS20155E220000487//PAS20171U220200011


		for (MRestri mRestri : lstMrestri){
			//PAS20155E220300013 - se ordena c�digo de lineas abajo
			if (mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_SENASA01)){
				for(DatoRegPrecedencia preceDua : lstPreceDua){
					if (preceDua.getCodregipre().equals(Constants.REGIMEN_DEPOSITO.toString())){ //gmontoya Pase 469 - 2015
						List<Map<String,Object>> lstDocAutorizPrece = this.getListDocAutorizPrece(preceDua, mRestri.getEntidad()); 
						if (!lstDocAutorizPrece.isEmpty()){
							variablesIngreso.put("indExcluyeSENASA01", true);
							break; //PAS20155E220300013 - se corta para que ya no continue evaluando
						}
					}
				}
			}else if (mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF03) || mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF04)){
				boolean indExcluyeDIQBF = false; //PAS20155E220300013

				for(DatoRegPrecedencia preceDua : lstPreceDua){
					if (preceDua.getCodregipre().equals(Constants.REGIMEN_DEPOSITO.toString())){//gmontoya Pase 469 - 2015
						//PAS20155E220000507
						CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
						Map<String,Object> params = new HashMap<String,Object>();
						params.put("NUM_DECLARACION",Long.parseLong(preceDua.getNumdeclpre()));
						params.put("COD_ADUANA",preceDua.getCodaduapre());
						params.put("ANN_PRESEN", Integer.parseInt(preceDua.getAnndeclpre().substring(0, 4)) );
						params.put("COD_REGIMEN",preceDua.getCodregipre());

						Map<String, Object> cabDeclaraPrece = cabDeclaraDAO.findMapDUAByPk(params);

						if (cabDeclaraPrece == null){
							PolizadDAO polizadDAO = fabricaDeServicios.getService("polizadDAO");

							Map<String,Object> paramsPolizad=new HashMap<String,Object>();
							paramsPolizad.put("anoPrese", preceDua.getAnndeclpre().substring(2, 4));
							paramsPolizad.put("codiAduan", preceDua.getCodaduapre());
							paramsPolizad.put("numeCorre", SunatStringUtils.lpad(preceDua.getNumdeclpre(),6,'0'));
							List<Polizad> lstPolizad = polizadDAO.selectByMap(paramsPolizad);

							if(lstPolizad.isEmpty()){
								lstErrores.add(catalogoAyudaService.getError("00124", new String[]{serie.getNumserie().toString(),params.get("COD_ADUANA").toString()+"-"+
										params.get("ANN_PRESEN").toString()+"-"+params.get("COD_REGIMEN").toString()+"-"+params.get("NUM_DECLARACION").toString() }));
								continue;
							}
						}

						if(!indExcluyeDIQBF){  //PAS20155E220300013 - se corta para que ya no continue evaluando
							List<Map<String,Object>> lstDocAutorizPrece = this.getListDocAutorizPrece(preceDua, mRestri.getEntidad());
							if (!lstDocAutorizPrece.isEmpty()){	
								variablesIngreso.put("indExcluyeDIQBF",true);
								indExcluyeDIQBF = true;
							}
						}
					}
				}
			}else if (codModalidad.equals(Constants.DESPACHO_EXCEPCIONAL) &&
					(mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF) ||
							mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA))){  //PAS20155E220000487 - Se agrega IQBF Mineria
				//Validaci�n r�gimen precedente Deposito [RN 1179]
				boolean indDocuPrece = false;
				//DatoDocAutorizante docAutorizante = null;//PAS20171U220200011
				for(DatoRegPrecedencia preceDua : lstPreceDua){
					if (preceDua.getCodregipre().equals(Constants.REGIMEN_DEPOSITO.toString())){//gmontoya Pase 469 - 2015
						indDocuPrece = true;

						CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
						Map<String,Object> params = new HashMap<String,Object>();
						params.put("NUM_DECLARACION",Long.parseLong(preceDua.getNumdeclpre()));
						params.put("COD_ADUANA",preceDua.getCodaduapre());
						params.put("ANN_PRESEN", Integer.parseInt(preceDua.getAnndeclpre().substring(0, 4)) );
						params.put("COD_REGIMEN",preceDua.getCodregipre());
						Map<String, Object> cabDeclaraPrece = cabDeclaraDAO.findMapDUAByPk(params);

						if (cabDeclaraPrece == null){
							PolizadDAO polizadDAO = fabricaDeServicios.getService("polizadDAO");

							Map<String,Object> paramsPolizad=new HashMap<String,Object>();
							paramsPolizad.put("anoPrese", preceDua.getAnndeclpre().substring(2, 4));
							paramsPolizad.put("codiAduan", preceDua.getCodaduapre());
							paramsPolizad.put("numeCorre", SunatStringUtils.lpad(preceDua.getNumdeclpre(),6,'0'));
							List<Polizad> lstPolizad = polizadDAO.selectByMap(paramsPolizad);

							if(lstPolizad.isEmpty()){
								lstErrores.add(catalogoAyudaService.getError("00124", new String[]{serie.getNumserie().toString(),params.get("COD_ADUANA").toString()+"-"+
										params.get("ANN_PRESEN").toString()+"-"+params.get("COD_REGIMEN").toString()+"-"+params.get("NUM_DECLARACION").toString() }));
								continue;
							}
						}


						//if(docAutorizante == null){
						//List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, (DUA) serie.getPadre(), variablesIngreso); //BUG 24309-24326 - PAS20155E220000487
						//List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, (DUA) serie.getPadre(), variablesIngreso, false); //BUG 24309-24326 - PAS20155E220000487//PAS20171U220200011
						for(DatoDocAutorizante docAutoriza : lstDocAutoriza){
							if (mRestri.getRegistro().equals(docAutoriza.getCodsubentidad())){
								docAutorizante = docAutoriza;
								break;
							}
						}
						//}

						if(docAutorizante != null && !Constants.COD_EXONERACION.equals(docAutorizante.getCodtipodocum()) || docAutorizante == null){//gmontoya P29 Pase 15 2015 PAS20175E220200088 //PAS20171U220200011
							//if(docAutorizante == null || !Constants.COD_EXONERACION.equals(docAutorizante.getCodtipodocum())){ //BUG 24348 - PAS20155E220000487
							List<Map<String,Object>> lstDocAutorizPrece = this.getListDocAutorizPrece(preceDua, mRestri.getEntidad());
							if (lstDocAutorizPrece.isEmpty()){	
								lstErrores.add(catalogoAyudaService.getError("35373", new String[]{serie.getNumserie().toString()}));
								continue;
							}

							CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");

							for (Map<String,Object> docAutorizPrece :lstDocAutorizPrece){
								params = new HashMap<String,Object>();
								params.put("codientidad", docAutorizPrece.get("CODI_ENTI"));
								params.put("ccoddoc", docAutorizPrece.get("CODI_DOCUM"));
								params.put("ccordoc", docAutorizPrece.get("NUMAUT"));
								params.put("anodoc", "20"+docAutorizPrece.get("ANOAUT"));
								//params.put("codiAduana", docAutorizPrece.get("CODLUG"));

								if (Constants.COD_TIPO_DOCAUT_IQBF.equals(docAutorizPrece.get("CODI_DOCUM"))){//PAS20171U220200011

									CabMrDocAutoriz docAutoPreceDuaBD = cabMrDocAutorizDao.getCabMrDocAutoriz(params);
									if (docAutoPreceDuaBD == null){
										lstErrores.add(catalogoAyudaService.getError("35357", new String[]{serie.getNumserie().toString()}));
										continue;
									}

									if (!docAutoPreceDuaBD.getCodEstAut().equals(Constants.EST_DOCAUT_CONCLUIDA) && !verificarExisteError(lstErrores,"35374")){
										lstErrores.add(catalogoAyudaService.getError("35374", new String[]{serie.getNumserie().toString()}));
									} 	
								}	else {//PAS20171U220200011
									lstErrores.add(catalogoAyudaService.getError("35301", new String []{serie.getNumserie().toString(),mRestri.getEntidad()}));
								}
							}
						} else {

							List<Map<String,Object>> lstDocAutorizPrece = this.getListDocAutorizPrece(preceDua, mRestri.getEntidad());
							if (!lstDocAutorizPrece.isEmpty()){	
								for (Map<String,Object> docAutorizPrece :lstDocAutorizPrece){
									if (Constants.COD_TIPO_DOCAUT_IQBF.equals(docAutorizPrece.get("CODI_DOCUM"))){
										lstErrores.add(catalogoAyudaService.getError("30409", new String []{serie.getNumserie().toString()}));
									}
								}
							}//PAS20171U220200011
						}
					}
				}
				if (indDocuPrece){
					variablesIngreso.put("indExcluyeIQBF", true);
				} else {
					variablesIngreso.remove("indExcluyeIQBF");
				}
			}
			/*//C�digo Anterior
	 		for (MRestri mRestri : lstMrestri){
	 			if (mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF03) || mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF04) || 
	 				mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_SENASA01) || mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF)){

	 				boolean indDocuPrece = false;
	 		 		for(DatoRegPrecedencia preceDua : lstPreceDua){
	 		 			if ((preceDua.getCodregipre().equals(Constants.REGIMEN_DEPOSITO.toString()) && 
	 		 			        codModalidad.equals(Constants.DESPACHO_EXCEPCIONAL) && mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF))||
	 		 			      mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF03) || mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_SENASA01) || 
	 		 			      mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF04)){
	 		 				indDocuPrece = true;

					  //Validaci�n r�gimen precedente Deposito [RN 1179]
					  CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
					  Map<String,Object> params = new HashMap<String,Object>();
					  params.put("NUM_DECLARACION",Long.parseLong(preceDua.getNumdeclpre()));
					  params.put("COD_ADUANA",preceDua.getCodaduapre());
					  params.put("ANN_PRESEN", Integer.parseInt(preceDua.getAnndeclpre().substring(0, 4)) );
					  params.put("COD_REGIMEN",preceDua.getCodregipre());

					  Map<String, Object> cabDeclaraPrece = cabDeclaraDAO.findMapDUAByPk(params);

					  if (cabDeclaraPrece == null){

						PolizadDAO polizadDAO = fabricaDeServicios.getService("polizadDAO");

						Map<String,Object> paramsPolizad=new HashMap<String,Object>();
						paramsPolizad.put("anoPrese", preceDua.getAnndeclpre().substring(2, 4));
						paramsPolizad.put("codiAduan", preceDua.getCodaduapre());
						paramsPolizad.put("numeCorre", SunatStringUtils.lpad(preceDua.getNumdeclpre(),6,'0'));
						List<Polizad> lstPolizad = polizadDAO.selectByMap(paramsPolizad);

						if(lstPolizad.isEmpty()){
							lstErrores.add(catalogoAyudaService.getError("00124", new String[]{serie.getNumserie().toString(),params.get("COD_ADUANA").toString()+"-"+
									  params.get("ANN_PRESEN").toString()+"-"+params.get("COD_REGIMEN").toString()+"-"+params.get("NUM_DECLARACION").toString() }));
							  continue;
							}
					  }

						ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");
					params=new HashMap<String,Object>();
					params.put("codi_aduan",preceDua.getCodaduapre());
					params.put("ano_prese",preceDua.getAnndeclpre().substring(0, 4));
					params.put("nume_corre",SunatStringUtils.lpad(preceDua.getNumdeclpre(),6,'0'));
					params.put("codi_regi",preceDua.getCodregipre());		
					params.put("nume_serie",preceDua.getNumserpre());
					params.put("codi_enti", mRestri.getEntidad());

						List<Map<String,Object>> lstDocAutorizPrece = (List<Map<String,Object>>) consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(params);

						if (lstDocAutorizPrece.isEmpty() && mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF)){
						lstErrores.add(catalogoAyudaService.getError("35373", new String[]{serie.getNumserie().toString()}));
						continue;
						} 

						if (!lstDocAutorizPrece.isEmpty() && mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_SENASA01)){
						variablesIngreso.put("indExcluyeSENASA01",true);
					}

					if (!lstDocAutorizPrece.isEmpty() && (mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF03) || 
							mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DIQPF04))){	
						variablesIngreso.put("indExcluyeDIQBF",true);
						}

						if (mRestri.getRegistro().equals(Constants.COD_SUBENTIDAD_DOCAUT_IQBF)){

					CabMrDocAutorizDAO cabMrDocAutorizDao = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAO");

					for (Map<String,Object> docAutorizPrece :lstDocAutorizPrece){

						params = new HashMap<String,Object>();
						params.put("codientidad", docAutorizPrece.get("CODI_ENTI"));
						params.put("ccoddoc", docAutorizPrece.get("CODI_DOCUM"));
						params.put("ccordoc", docAutorizPrece.get("NUMAUT"));
						params.put("anodoc", "20"+docAutorizPrece.get("ANOAUT"));
						//params.put("codiAduana", docAutorizPrece.get("CODLUG"));

						CabMrDocAutoriz docAutoPreceDuaBD = cabMrDocAutorizDao.getCabMrDocAutoriz(params);
							if (docAutoPreceDuaBD == null){
							//lstErrores.add(catalogoAyudaService.getError("35357",new String[] {serie.getNumserie().toString()}));
							lstErrores.add(catalogoAyudaService.getError("35374", new String[]{serie.getNumserie().toString()}));
							continue;
						}

							if ( !docAutoPreceDuaBD.getCodEstAut().equals(Constants.EST_DOCAUT_CONCLUIDA) && !verificarExisteError(lstErrores,"35374")){
							  lstErrores.add(catalogoAyudaService.getError("35374", new String[]{serie.getNumserie().toString()}));
						} 	
				  }
			   }
	 		}


	 		}
 		 	if (mRestri.getRegistro().equals("3001")){
 		 		if (indDocuPrece){
 		 			variablesIngreso.put("indExcluyeIQBF",true);
 		 		} else {
 		 			variablesIngreso.remove("indExcluyeIQBF");
 		 		}
 		 	} 				
 		  }
	 		}
			 */
			//Inicio - PAS20155E220000371
			boolean hasEntidad = false; 
			for(String entidad : listaEntidad){
				if(mRestri.getEntidad().equals(entidad)){
					hasEntidad = true;
					break;
				}
			}
			if(!hasEntidad){
				listaEntidad.add(mRestri.getEntidad());
			}
			//Fin - PAS20155E220000371
		}

		//Inicio - PAS20155E220000371 - se setea restring deposito x serie
		List<Map<String,Object>> lstDocAutorizPreceDeposito = this.getListDocAutorizPreceDeposito(serie, listaEntidad);

		Map<String, Object> mapDocAutorizPreceDeposito = new HashMap<String, Object>();
		mapDocAutorizPreceDeposito.put("numeroSerie", serie.getNumserie());
		mapDocAutorizPreceDeposito.put("lstDocAutorizPreceDeposito", lstDocAutorizPreceDeposito);
		variablesIngreso.put("mapDocAutorizPreceDeposito", mapDocAutorizPreceDeposito);
		//Fin PAS20155E220000371

		return lstErrores;
	}

	/*@SuppressWarnings("unchecked")
 	private List<Map<String,Object>> getListDocAutorizPreceDepositoCache(DatoSerie serie, String entidad, Map<String, Object> variablesIngreso){
    	//La variable se va seteando x serie y en el metodo validarMercancia
		Map<String,Object> mapDocAutorizPreceDeposito = (Map<String, Object>) variablesIngreso.get("mapDocAutorizPreceDeposito");
		List<Map<String,Object>> lstDocAutorizPreceDeposito = null;

		if(mapDocAutorizPreceDeposito != null && serie.getNumserie().toString().equals(mapDocAutorizPreceDeposito.get("numeroSerie").toString().trim())){
			lstDocAutorizPreceDeposito = (List<Map<String, Object>>) mapDocAutorizPreceDeposito.get("lstDocAutorizPreceDeposito");
		}

		if(lstDocAutorizPreceDeposito != null){
			return lstDocAutorizPreceDeposito;
		}else{
			return this.getListDocAutorizPreceDeposito(serie, entidad);
		}
 	}*/

	@SuppressWarnings("unchecked")
	private List<Map<String,Object>> getListDocAutorizPrece(DatoRegPrecedencia preceDua, String entidad){
		ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");
		Map<String, Object> params = new HashMap<String,Object>();
		params.put("codi_aduan",preceDua.getCodaduapre());
		params.put("ano_prese",preceDua.getAnndeclpre().substring(0, 4));
		params.put("nume_corre",SunatStringUtils.lpad(preceDua.getNumdeclpre(),6,'0'));
		params.put("codi_regi",preceDua.getCodregipre());		
		params.put("nume_serie",preceDua.getNumserpre());
		params.put("codi_enti", entidad);

		return (List<Map<String,Object>>) consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(params);
	}

	private Declaracion obtenerDeclaracionReguAnticipado(Declaracion declaracion, Map<String, Object> variablesIngreso){

		if (variablesIngreso.get("codTransaccion") == null){
			return declaracion;
		}

		if (SunatStringUtils.include(variablesIngreso.get("codTransaccion").toString().substring(2,4), new String[] { "04" })) {
			declaracion = (Declaracion)variablesIngreso.get("declaracion");
		}

		return declaracion;
	}

	private DatoSerie obtenerSerieReguAnticipado(DatoSerie serie, Map<String, Object> variablesIngreso){

		if (variablesIngreso.get("codTransaccion") == null){
			return serie;
		}

		if (SunatStringUtils.include(variablesIngreso.get("codTransaccion").toString().substring(2,4), new String[] { "04" })) {
			Declaracion declaracion = (Declaracion)variablesIngreso.get("declaracion");
			for (DatoSerie itemSerie : declaracion.getDua().getListSeries()){
				if (itemSerie.getNumserie().toString().equals(serie.getNumserie().toString())){
					serie = itemSerie;
					serie.getPadre().setPadre(declaracion);
					break;
				}
			}
		}

		return serie;
	}    

	//VUCE


	private String obtenerTipoValidacionDocumentoAutorizante(DatoDocAutorizante docAutorizante, Date fechaReferencia,Map<String, Object> variablesIngreso, String codRegimen){
		String tipoValidacion=" ";
		String codSubEntidad="";
		String codtipDocControl="";
		String numDocControl=" ";
		String codigoEntidadVuce="";
		String codigoSubEntidadVuce="";
		String cutVuce =" ";
		String indtipoValidacionVuce="";
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		//   		String codRegimen = ((DUA)docAutorizante.getPadre()).getCodregimen();
		Map<String, Object> atributoVigenciaRegimenVuce=catalogoAyudaService.getDataAtributo(
				ConstantesTipoCatalogo.CATALOGO_DE_FECHA_VIGENCIA_VUCE_REGIMEN,
				ConstantesTipoCatalogo.CATALOGO_GRUPO_REGIMENES_VUCE, 
				ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO,
				codRegimen);

		Date fechaVigenciaPorRegimen = SunatDateUtils.getDateFromUnknownFormat(
				atributoVigenciaRegimenVuce.get("val_atributo") == null ? "31/12/9999" : atributoVigenciaRegimenVuce.get("val_atributo").toString());

		//si el regimen a�n no esta vigencia, mandar las validaciones de rin14
		if(SunatDateUtils.esFecha1MenorQueFecha2(fechaReferencia, fechaVigenciaPorRegimen, SunatDateUtils.COMPARA_SOLO_FECHA)){
			tipoValidacion="rin14";
			return tipoValidacion;
		}

		//   		Map<String, Object> fechaHabilitacion= catalogoAyudaService.getElementoCat("380","0009","01",new Date());
		//   		Date fechaHabilVuce=SunatDateUtils.getDateFromUnknownFormat(MapUtils.getString(fechaHabilitacion, "fec_inidatcat", "31/12/9999"));//ajuste fecha
		codtipDocControl=docAutorizante.getCodtipodocum()!=null?docAutorizante.getCodtipodocum().toString():"";
		numDocControl=docAutorizante.getNumdocum()!=null?docAutorizante.getNumdocum().toString():"";
		codSubEntidad=docAutorizante.getCodsubentidad()==null ? "" : docAutorizante.getCodsubentidad().toString();

		//P_SNADE046-2245 resetear el valor de esta variable, ya que se debe evaluar por cada documento
		variablesIngreso.put("indtipoValidacionVuce", indtipoValidacionVuce);

		if (codtipDocControl.equals(DOC_RESOLUTIVO) || codtipDocControl.equals(SOLICITUD_SUCE)) {
			DocControlMercRestringidaVuce docControlMercRestringidaVuce;
			try{
				docControlMercRestringidaVuce = obtenerDocumentoVuce(SunatNumberUtils.toLong(numDocControl), codtipDocControl);
			} catch (Exception e){
				tipoValidacion = "vuce";
				return tipoValidacion;
			}

			if(docControlMercRestringidaVuce!=null){
				codigoEntidadVuce= docControlMercRestringidaVuce.getEntidad()==null?"":docControlMercRestringidaVuce.getEntidad().toString();
				codigoSubEntidadVuce=docControlMercRestringidaVuce.getSubEntidad()==null?"":docControlMercRestringidaVuce.getSubEntidad().toString();
				cutVuce = docControlMercRestringidaVuce.getNumeroCUT()==null?"":docControlMercRestringidaVuce.getNumeroCUT().toString();//adicionado VUCE RECTI
			}
		}
		variablesIngreso.put("codigoEntidadVuce", codigoEntidadVuce); //variable usado en la numeracion 
		variablesIngreso.put("codigoSubEntidadVuce", codigoSubEntidadVuce); // variable usado en la numeracion 

		if(SunatStringUtils.isEmptyTrim(codSubEntidad)){
			codSubEntidad=codigoSubEntidadVuce;
		}

		List<MRestri> lstMrestri = variablesIngreso.get("listMercRestringida") != null ? (List<MRestri>) variablesIngreso.get("listMercRestringida") : null;

		if(SunatStringUtils.isEmptyTrim(codSubEntidad)){
			List<String> listSuEntidadesCut= obtenerSubentidadesPorCut(cutVuce, fechaReferencia);
			codSubEntidad = obtenerRegistroPorCut( listSuEntidadesCut, obtenerRegistrosMrestri(lstMrestri));//ajuste por bug P_SNADE046-1917
		}

		log.info("obtenerTipoValidacionDocumentoAutorizante codtipDocControl:" + codtipDocControl + ", numDocControl:" + numDocControl + ", codSubEntidad:" + codSubEntidad
				+ ", cutVuce:" + cutVuce + ", lstMrestri:" + lstMrestri);

		DataGrupoCat catalogo = catalogoAyudaService.getDataGrupoCat("942", codSubEntidad, fechaReferencia);
		String valAtributoFecha=" ";   

		if(catalogo != null){
			Map<String, Object> atributosEntidadesVuce=catalogoAyudaService.getDataAtributo(
					ConstantesTipoCatalogo.CATALOGO_DE_DATOS_SUBENTIDAD,
					ConstantesTipoCatalogo.CATALOGO_DE_FECHA_VIGENCIA_VUCE, 
					ConstantesTipoCatalogo.CATALOGO_SUBENTIDADES_DOCAUTORIZA,
					codSubEntidad);
			valAtributoFecha = atributosEntidadesVuce.get("val_atributo") == null ? null:atributosEntidadesVuce.get("val_atributo").toString();
		}

		if ((codtipDocControl.equals(DOC_RESOLUTIVO)||codtipDocControl.equals(SOLICITUD_SUCE)) &&  "".equals(codSubEntidad)){
			tipoValidacion="vuce";
			//			variablesIngreso.put("indtipoValidacionVuce", indtipoValidacionVuce);
		} else if ((codtipDocControl.equals(DOC_RESOLUTIVO) || codtipDocControl.equals(SOLICITUD_SUCE)) && catalogo != null){
			tipoValidacion="vuce";
			//            variablesIngreso.put("indtipoValidacionVuce", indtipoValidacionVuce);
		} else {
			//falta considerar si no hay resultado en el rest
			//        	if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fechaVigenciaPorRegimen, SunatDateUtils.COMPARA_SOLO_FECHA)){
			Date fechaExigibilidadVuce= valAtributoFecha!=null && valAtributoFecha!=" "?SunatDateUtils.getDateFromUnknownFormat(valAtributoFecha):null;//marciano PASE137
			if(fechaExigibilidadVuce != null && SunatDateUtils.esFecha1MayorIgualQueFecha2(docAutorizante.getFecemision(),fechaExigibilidadVuce, SunatDateUtils.COMPARA_SOLO_FECHA)){
				boolean codTipoTratamientoDonacion=variablesIngreso.get("esTratamDonacion")!=null?(Boolean)variablesIngreso.get("esTratamDonacion"):false;
				if(codTipoTratamientoDonacion && (catalogoAyudaService.getDataGrupoCat("946", codSubEntidad)!=null)){
					tipoValidacion="vuce";
					//                    	variablesIngreso.put("indtipoValidacionVuce", indtipoValidacionVuce);//P_SNADE046-2088
				} else {
					if((catalogoAyudaService.getDataGrupoCat("947", codSubEntidad)!=null) &&  (SunatStringUtils.isStringInList(codSubEntidad, "0401"))){
						tipoValidacion="vuce";
						indtipoValidacionVuce="MostrarExcepcio86";
					} else {
						tipoValidacion="vuce";
						//gg vuce control de cambio
						String codTransaccion = MapUtils.getString(variablesIngreso, "codTransaccion", "");
						//if(!SunatStringUtils.isStringInList(codSubEntidad, "0801")){//control de cambios
						if (!esSubentidadVuceExonerada(codTransaccion, codSubEntidad, fechaReferencia)){
							indtipoValidacionVuce="MostrarExcepcio92";
						}
					}  
					variablesIngreso.put("indtipoValidacionVuce", indtipoValidacionVuce);
				} 
			} else {
				tipoValidacion="rin14";
			}
			//        	} else {
			//        		tipoValidacion="rin14";
			//            }
		}

		log.info("obtenerTipoValidacionDocumentoAutorizante codtipDocControl:" + codtipDocControl + ", numDocControl:" + numDocControl + ", codSubEntidad:" + codSubEntidad +
				", indtipoValidacionVuce:" + indtipoValidacionVuce + ", tipoValidacion:" + tipoValidacion);
		return tipoValidacion;
	}  

	//gg vuce control de cambio
	private boolean esSubentidadVuceExonerada(String codTransaccion, String codSubEntidad, Date fechaReferencia) {
		List<Map<String, String>> listSubentidadExonerada =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
				.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_TRANSACCION_SUBENTIDAD_EXONERADA, "C", codTransaccion, fechaReferencia);
		if(!CollectionUtils.isEmpty(listSubentidadExonerada)){
			for (Map<String, String> subentidad : listSubentidadExonerada) {
				if (codSubEntidad.equals(MapUtils.getString(subentidad, "cod_datacat", ""))){
					return true;
				}
			}
		}
		return false;
	}

	/**Inicio Cambios VUCE 
	 ** es para obtener cuando no hay la lista de restringidas en sesion, de lo contrario solo busca la lista de las subentidades el mrestri  
	 **/
	public List<String> obtenerRegistrosPorBusquedaMrestri(String numeroPartida , Date fechaReferencia, String regimen, List<MRestri> lstMrestri){
		if(lstMrestri==null || CollectionUtils.isEmpty(lstMrestri)){//si no hay en sesion se busca:				
			MrestriDAO mrestriDAO = ((MrestriDAO)fabricaDeServicios.getService("mrestriDAO"));
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cnan", numeroPartida);
			params.put("fechaVigencia", SunatDateUtils.getIntegerFromDate(fechaReferencia));
			params.put("codiRegi", regimen);
			lstMrestri = mrestriDAO.listadoMercRestringida(params);
		}
		return obtenerRegistrosMrestri(lstMrestri);
	}


	/**Inicio Cambios VUCE RECTI
	 ** es para obtener solamente los registros no repetidos   
	 *Se usa unicamente en la validacion de tipificacion de vuce y 
	 *se reusa en obtenerRegistrosPorBusquedaMrestri en casos que recien consulta el mrestri.
	 **/
	public List<String> obtenerRegistrosMrestri(List<MRestri> lstMrestri){
		List<String> lstRegistros = new ArrayList<String>();
		//obtener las subentidades solamente del mrestri (distinct):
		if (lstMrestri!=null && !CollectionUtils.isEmpty(lstMrestri)) {			
			for (MRestri mrestri : lstMrestri) {		
				String registroMrestri = mrestri.getRegistro().toString();
				if(!lstRegistros.contains(registroMrestri)){
					lstRegistros.add(registroMrestri);
				}
			}
		}
		return lstRegistros;
	}

	public List<String> obtenerSubentidadesPorCut(String cutVuce, Date fechaReferencia){
		Map<String, Object> params = new HashMap<String, Object>();		
		params.put("codAsociacion", COD_ASOCIA_SUBENTIDAD_VS_CUT_PARA_DR);
		params.put("codSelElemento", "A");
		params.put("codElemento", cutVuce);
		params.put("fecha", fechaReferencia);
		AyudaServiceDataCatAsoc ayudaServiceDataCatAsoc = fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatAsoc");

		List<Map<String, Object>> lstSubEntidades =  ayudaServiceDataCatAsoc.buscar(params);	
		List<String> listSuEntidadesCut = new ArrayList<String>();
		//String listSuEntidadesCut = "";
		if(lstSubEntidades!=null && !CollectionUtils.isEmpty(lstSubEntidades)){
			for(Map<String, Object> mapEntidadesCut : lstSubEntidades){
				listSuEntidadesCut.add(mapEntidadesCut.get("cod_datacat").toString());
				//listSuEntidadesCut = listSuEntidadesCut + mapEntidadesCut.get("cod_datacat").toString() + ",";
			}
			//listSuEntidadesCut = listSuEntidadesCut.substring(0,listSuEntidadesCut.length()-1 );
		}

		return listSuEntidadesCut;
	}
	/**Inicio Cambios VUCE RECTI
	 ** Se busca con el cut en la asociacion de subentidades por CUT.
	 ** de tener una subentidad se devuelve para su seteo,
	 ** de lo contrario cruza la lista con la lista de registros del mrestri.
	 **/
	public String obtenerRegistroPorCut(List<String> listSuEntidadesCut,  List<String> lstRegistrosMrestri){
		String registro="";	   

		if(!CollectionUtils.isEmpty(listSuEntidadesCut)){
			if(!CollectionUtils.isEmpty(lstRegistrosMrestri)){//sino obtener de Mrestri		 
				for(String registroMrestri: lstRegistrosMrestri){
					for (String  registroVuce : listSuEntidadesCut){
						if(registroVuce.equals(registroMrestri)){
							registro=registroVuce;
							continue;
						}
					}
				}
			}
		}
		return registro;
	}

	//Metodo para concluir un Documento IQBF 
	public void actualizarConclusionDocAutorizaIQBF(Declaracion declaracion){
		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");

		Map<String,Object> params = new HashMap<String,Object>();
		params.put("numCorreDoc", declaracion.getDua().getNumcorredoc());
		params.put("codTipOper", Constants.COD_TIPOPER_DOCAUT);
		params.put("codTipoDocu",Constants.COD_TIPO_DOCAUT_IQBF);
		params.put("codEntidad",Constants.COD_ENTIDAD_DOCAUT_IQBF);
		//params.put("codSubEntidad",Constants.COD_SUBENTIDAD_DOCAUT_IQBF); //PAS20155E220000487
		//params.put("codsubtipodocum",Constants.COD_SUBTIPO_DOCAUT_IQBF);	//PAS20155E220000487	
		params.put("indDel",Constants.INDICADOR_NO_ELIMINADO);
		//Inicio - PAS20155E220000487 - se agrega IQBF Mineria
		params.put("listaSubEntidad", new String[]{Constants.COD_SUBENTIDAD_DOCAUT_IQBF, Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA});
		//Fin - PAS20155E220000487
		List<Map<String, Object>> listDocAutAsociadoSerie = docAutAsociadoDAO.listDocAutorizaSerie(params);

		if (!CollectionUtils.isEmpty(listDocAutAsociadoSerie)){
			CabMrDocAutorizDAO cabMrDocAutorizDAO = (CabMrDocAutorizDAO) fabricaDeServicios.getService("cabMrDocAutorizDAOTx");
			DetMrDocAutorizDAO detMrDocAutorizDAO = (DetMrDocAutorizDAO) fabricaDeServicios.getService("detMrDocAutorizDAOTx");

			for(Map<String, Object> docAutoriza : listDocAutAsociadoSerie){

				CabMrDocAutoriz cabMrDocAutoriz = new CabMrDocAutoriz();
				cabMrDocAutoriz.setAnodoc(docAutoriza.get("annDoc").toString());
				cabMrDocAutoriz.setCcoddoc(docAutoriza.get("codTipDoc").toString());
				cabMrDocAutoriz.setCcordoc(docAutoriza.get("numDoc").toString());
				cabMrDocAutoriz.setCodiAduan(declaracion.getNumdeclRef().getCodaduana());
				cabMrDocAutoriz.setCodiEntidad(docAutoriza.get("codEntidad").toString());
				cabMrDocAutoriz.setCodEstAut(Constants.EST_DOCAUT_CONCLUIDA);				

				cabMrDocAutorizDAO.updateByPrimaryKeySelective(cabMrDocAutoriz);

				DetMrDocAutoriz detMrDocAutoriz = new DetMrDocAutoriz();
				detMrDocAutoriz.setAnodoc(docAutoriza.get("annDoc").toString());
				detMrDocAutoriz.setCcoddoc(docAutoriza.get("codTipDoc").toString());
				detMrDocAutoriz.setCcordoc(docAutoriza.get("numDoc").toString());
				detMrDocAutoriz.setCodiAduan(declaracion.getNumdeclRef().getCodaduana());
				detMrDocAutoriz.setCodiEntidad(docAutoriza.get("codEntidad").toString());
				detMrDocAutoriz.setCsecdoc(docAutoriza.get("nroitemdocum").toString());
				//detMrDocAutoriz.setCodUniMedc(docAutoriza.get("codUniComer").toString());  
				detMrDocAutoriz.setCntQuniCom((BigDecimal) docAutoriza.get("cntComer"));	   
				detMrDocAutoriz.setCntPesoNeto((BigDecimal) docAutoriza.get("cntPesoNeto"));

				detMrDocAutorizDAO.updateByPrimaryKeySelective(detMrDocAutoriz);

			}
		}
	}

	public String obtenerCodigoServicioAnotacion(Object o){
		return SunatStringUtils.toStringObj(GeneralUtils.getCurrentMethod(o).getAnnotation(ServicioAnnot.class).codServicio());
	}

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}


	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}


	public CabMrDocAutorizBatchDAO getCabMrDocAutorizBatchDAO() {
		return cabMrDocAutorizBatchDAO;
	}


	public void setCabMrDocAutorizBatchDAO(CabMrDocAutorizBatchDAO cabMrDocAutorizBatchDAO) {
		this.cabMrDocAutorizBatchDAO = cabMrDocAutorizBatchDAO;
	}


	public DetMrDocAutorizBatchDAO getDetMrDocAutorizBatchDAO() {
		return detMrDocAutorizBatchDAO;
	}


	public void setDetMrDocAutorizBatchDAO(DetMrDocAutorizBatchDAO detMrDocAutorizBatchDAO) {
		this.detMrDocAutorizBatchDAO = detMrDocAutorizBatchDAO;
	}
*/

	@Override
	public List<Map<String, Object>> copiarRestanteDetDeclaraActual(List<Map<String, Object>> lstDetDeclara, List<Map<String, Object>> lstDetDeclaraActual) {

		if (CollectionUtils.isEmpty(lstDetDeclaraActual)) return lstDetDeclaraActual;

		for (Map<String, Object> map : lstDetDeclara) {
			if (map.containsKey("MERCANCIA_RESTRINGIDA")) {
				for (Map<String, Object> mapActual : lstDetDeclaraActual) {
					if (map.get("NUM_SECSERIE").toString().equals(mapActual.get("NUM_SECSERIE").toString())) {
						mapActual.put("MERCANCIA_RESTRINGIDA", map.get("MERCANCIA_RESTRINGIDA"));
					}
				}
			}
		}
		return lstDetDeclaraActual;
	}

	//PAS20155E220000371 - <KAH RIN14>
	@SuppressWarnings("unchecked")
	public boolean validarDocControlAutorizanteTieneRegimenPrecedente(List<DatoDocAutorizante> lstDatoDocAutorizante,DatoSerie serie,DatoDocAutorizante docAutorizante){
		boolean indDocAutoTieneRegimenPrecedente = false;
		List<Map<String, Object>> lstDocAutorizPrece = null;
		ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");
		List<DatoRegPrecedencia> listaRegimenesPrecedencia =  serie.getListRegPrecedencia();

		if ( !CollectionUtils.isEmpty(listaRegimenesPrecedencia) & !CollectionUtils.isEmpty(lstDatoDocAutorizante)) {
			for (DatoDocAutorizante datoDocAutorizanteUsado : lstDatoDocAutorizante) {
				for (DatoRegPrecedencia regPrecedente : listaRegimenesPrecedencia) {
					Map<String, Object> parametroConsultarRestring = new HashMap<String, Object>();
					parametroConsultarRestring.put("codi_aduan",regPrecedente.getCodaduapre());
					parametroConsultarRestring.put("ano_prese",regPrecedente.getAnndeclpre().substring(0, 4));
					parametroConsultarRestring.put("nume_corre",SunatStringUtils.lpad(regPrecedente.getNumdeclpre(),6,'0'));
					parametroConsultarRestring.put("codi_regi",regPrecedente.getCodregipre());							
					parametroConsultarRestring.put("codi_enti",datoDocAutorizanteUsado.getCodentidad());
					parametroConsultarRestring.put("codi_docum",datoDocAutorizanteUsado.getCodtipodocum());
					parametroConsultarRestring.put("numaut", datoDocAutorizanteUsado.getNumdocum());
					parametroConsultarRestring.put("codlug",regPrecedente.getCodaduapre());
					parametroConsultarRestring.put("feemiaut",SunatDateUtils.getIntegerFromDate(datoDocAutorizanteUsado.getFecemision()));							

					lstDocAutorizPrece = (List<Map<String,Object>>) consultaDeclaracionComunService.obtenerListaDocAutMercanciasRestringidas(parametroConsultarRestring);
					if (!CollectionUtils.isEmpty(lstDocAutorizPrece)){
						indDocAutoTieneRegimenPrecedente = true;								
						break;
					}
				}
			}
		}

		return indDocAutoTieneRegimenPrecedente;
	}
	//PAS20155E220000371 - </KAH RIN14>

	public List<Map<String, String>> validarVigenciaVuce(DatoSerie serie, Map<String, Object> variablesIngreso) {
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		DUA dua = (DUA)serie.getPadre();
		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();
		String numeroSerie=serie.getNumserie()==null? " ":serie.getNumserie().toString();
		String mercanciaSpn=serie.getNumpartnandi()==null? " ":serie.getNumpartnandi().toString();
		Date fechaReferencia ;
		String codtipDocControl="";
		List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, dua, variablesIngreso, false);
		String codTransaccion = declaracion.getCodtipotrans();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(SunatStringUtils.isStringInList(codTransaccion, "1001,2001,2101,7001")){
			fechaReferencia = SunatDateUtils.getCurrentDate();
		}else{
			fechaReferencia = declaracion.getDua().getFecdeclaracion();
		}

		if(!CollectionUtils.isEmpty(lstDocAutoriza)){

			for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {

				//				String codRegimen = ((DUA)docAutorizante.getPadre()).getCodregimen();
				String numeroDocumentoVuce = docAutorizante.getNumdocum() == null ? "" : docAutorizante.getNumdocum().toString();
				Map<String, Object> atributoVigenciaRegimenVuce=catalogoAyudaService.getDataAtributo(
						ConstantesTipoCatalogo.CATALOGO_DE_FECHA_VIGENCIA_VUCE_REGIMEN,
						ConstantesTipoCatalogo.CATALOGO_GRUPO_REGIMENES_VUCE, 
						ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO,
						dua.getCodregimen());
				codtipDocControl = docAutorizante.getCodtipodocum();
				Date fechaVigenciaPorRegimen = SunatDateUtils.getDateFromUnknownFormat(
						atributoVigenciaRegimenVuce.get("val_atributo") == null ? "31/12/9999" : atributoVigenciaRegimenVuce.get("val_atributo").toString());

				//si el regimen a�n no esta vigencia VUCE, mandar un error
				if(SunatDateUtils.esFecha1MenorQueFecha2(fechaReferencia, fechaVigenciaPorRegimen, SunatDateUtils.COMPARA_SOLO_FECHA)){
					if(codtipDocControl.equals(DOC_RESOLUTIVO) || codtipDocControl.equals(SOLICITUD_SUCE)){
						listErrores.add(catalogoAyudaService.getError("35768", new String []{numeroSerie,mercanciaSpn,numeroDocumentoVuce,codtipDocControl}));
					}

				}

			}




		}

		return listErrores;

	}


	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Realizara validaciones generales aplicada a Mercancias Restringidas 
	 * para que aplica a VUCE segun sea.
	 * para aplicar a RIN14 inscribir el servicio 9155 - validarMercanciaRestringidaRIN14
	 * PROPIO DE PASE PAS20165E220200079 VUCE RECTI
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 */
	@ServicioAnnot(tipo="V",codServicio=9153, descServicio="valida reglas generales de Mercancia Restringida para RIN14 y VUCE")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie", "variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=9154,numSecEjec=03,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida")	

	public List<Map<String, String>> validarMercanciaRestringidaPorSerie(DatoSerie serie, Map<String, Object> variablesIngreso) {
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		String tipoValidacion= "";
		String codtipDocControl=" ";
		String regPrecedente70="";
		String codigoEntidad=" ";
		String codigoSubEntidad=" ";
		String numeroDocumentoVuce = "";

		DUA dua = (DUA)serie.getPadre();
		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();
		Date fechaReferencia ;
		String codTransaccion = declaracion.getCodtipotrans();
		// se considera la fecha de referencia de la fecha de declaracion 
		if(SunatStringUtils.isStringInList(codTransaccion, "1001,2001,2101,7001")){
			fechaReferencia = SunatDateUtils.getCurrentDate();
		}else{
			fechaReferencia = declaracion.getDua().getFecdeclaracion();
		}

		List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie, dua, variablesIngreso, false);
		String numeroSerie=serie.getNumserie()==null? " ":serie.getNumserie().toString();

		String codTipoTratamiento = dua.getCodtipotratamiento()==null ? "" : dua.getCodtipotratamiento();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		boolean tieneTratamientoDonacion=false; 
		if(codTipoTratamiento.equals(Constants.COD_TIPO_TRATAMIENTO)){
			tieneTratamientoDonacion=true;			
		}
		if(variablesIngreso.get("esTratamDonacion") == null){
			variablesIngreso.put("esTratamDonacion",tieneTratamientoDonacion);
		}
/*		CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		boolean esVigenteRIN05 = catalogoVigenciaService!=null?catalogoVigenciaService.esVigenteRIN05(fechaReferencia):false;
		

		CatalogoVigenciaService catalogoVigenciaService2 = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		boolean esVigenteRIN05SegundaParte = catalogoVigenciaService2!=null?catalogoVigenciaService2.esVigenteRIN05SegundaParte(fechaReferencia):false;*/
		
//		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
//		boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaReferencia):false;
//		boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaReferencia):false;
		boolean isDAMDiferidaSinIca = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;

		String mercanciaSpn=serie.getNumpartnandi()==null? " ":serie.getNumpartnandi().toString();

		MrestriDAO mrestriDAO = ((MrestriDAO)fabricaDeServicios.getService("mrestriDAO"));
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("cnan", serie.getNumpartnandi());
		params.put("fechaVigencia", SunatDateUtils.getIntegerFromDate(fechaReferencia));
		params.put("codiRegi", dua.getCodregimen());
		List<MRestri> lstMrestri = mrestriDAO.listadoMercRestringida(params);
		variablesIngreso.put("listMercRestringida",lstMrestri);

		if(codTransaccion.equals("1016")){
			//SE ADICIONA LA VALIDACION DE RIN 14 PARA QUE SE EJECUTE EN EL GRABADO DE LA DILIGENCIA DE DESPACHO
			Map<String,Object> mapValoresSerie = new HashMap<String,Object>();
			mapValoresSerie.put("tipoDiligencia",Constantes.COD_TIPO_DILIGENCIA_DESPACHO);
			mapValoresSerie.put("codRegimen",dua.getCodregimen());
			mapValoresSerie.put("partNandi",serie.getNumpartnandi());
			mapValoresSerie.put("numCorreDoc",dua.getNumcorredoc());
			mapValoresSerie.put("numSerie",numeroSerie);
			Map<String,Object> mapErrores = validarMRestriSPNDiligencia(lstDocAutoriza,mapValoresSerie);

			if (!mapErrores.isEmpty()){
				listErrores.addAll( ((ArrayList<Map<String,String>>)mapErrores.get("lstErrores")).isEmpty()?new ArrayList<Map<String,String>>():((ArrayList<Map<String,String>>)mapErrores.get("lstErrores")));
			}
		}

		if(!CollectionUtils.isEmpty(lstDocAutoriza)){
			//sin esto cuando la serie no ha trasmitido o tiene docs autorizantes se cae
			for (DatoDocAutorizante docAutorizante : lstDocAutoriza) {
				codtipDocControl = docAutorizante.getCodtipodocum() == null ? "" : docAutorizante.getCodtipodocum().toString();
				log.info("validarMercanciaRestringidaPorSerie codtipDocControl: " + codtipDocControl + ", numeroDcumento:" + docAutorizante.getNumdocum() + ", fechaReferencia:" + fechaReferencia);
				tipoValidacion = obtenerTipoValidacionDocumentoAutorizante(docAutorizante, fechaReferencia,variablesIngreso, dua.getCodregimen());

				if("vuce".equalsIgnoreCase(tipoValidacion)){
					codigoEntidad = docAutorizante.getCodentidad()!=null?docAutorizante.getCodentidad():"";//ajustes VUCE RECTI
					codigoSubEntidad = docAutorizante.getCodsubentidad()!=null?docAutorizante.getCodsubentidad():"";//ajustes VUCE RECTI
					numeroDocumentoVuce = docAutorizante.getNumdocum() == null ? "" : docAutorizante.getNumdocum().toString();
					// en diligencia de despacho se valida al adicionar y editar por el interfaz
					if(codtipDocControl.equals("21") || codtipDocControl.equals("20")){
						Map<String, Object> mapa = new HashMap<String, Object>();
						for(DatoRegPrecedencia regimenes: serie.getListRegPrecedencia()){//verificar
							if(regimenes.getCodregipre().equals("70")){
								regPrecedente70=regimenes.getCodregipre()==null?" ":regimenes.getCodregipre().toString();
								break;
							}
						}		 
						///PAS201830001100009
						if (!docAutorizante.getNumdocum().isEmpty()) {
							List<Map<String, String>> listaError = validacionCaracteresNumeroDocControl(docAutorizante.getNumdocum(),serie.getNumserie().toString()) ;
							if(listaError!=null && listaError.size()>0){
								listErrores.addAll(listaError);
								break;
							}
						}
						//PAS201830001100009
						mapa.put("regPrecedente70", regPrecedente70);
						mapa.put("mercanciaSpn", mercanciaSpn);
						mapa.put("numeroDocumentoVuce", numeroDocumentoVuce);
						mapa.put("codigoEntidad", codigoEntidad);
						mapa.put("codigoSubEntidad", codigoSubEntidad);
						mapa.put("tipoParticipante",  dua.getDeclarante().getTipoParticipante().getCodDatacat()==null?" ":dua.getDeclarante().getTipoParticipante().getCodDatacat().toString());//ajuste
						mapa.put("tipoDocumConsigNumeracion", dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat()==null?" ":dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().toString());
						mapa.put("numeDocumConsigNumeracion", dua.getDeclarante().getNumeroDocumentoIdentidad()==null?"": dua.getDeclarante().getNumeroDocumentoIdentidad().toString());
						mapa.put("mercanciaTPN21", serie.getCodtratprefe()!=null?serie.getCodtratprefe().toString():" ");//ajuste
						mapa.put("codAduana", dua.getCodaduanaorden());
						mapa.put("numeroDeclaracion", declaracion.getNumeroDeclaracion()==null?" ":declaracion.getNumeroDeclaracion().toString());
						mapa.put("fechaReferencia", fechaReferencia);
						mapa.put("listaMrestri", lstMrestri);//del mrestri VUCE RECTI
						mapa.put("codRegimen", dua.getCodregimen());//adicionado por bug P_SNADE046-1917
						mapa.put("tieneTratamientoDonacion", tieneTratamientoDonacion);//adicionado por P_SNADE046-2085 si mandan SUCE
						mapa.put("codTransaccion", codTransaccion); // para restringir validar al grabar diligencia de despacho
						mapa.put("numCorredocDAM",dua.getNumcorredoc());//P_SNADE046-2133
			//pase PAS20181U220200004 
	// SE ADICIONA REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN

				//if (esVigenteRIN05SegundaParte){
					    mapa.put("isDAMDiferidaSinIca",isDAMDiferidaSinIca); // PAS20181U220200004
					    // SE COMENTA POR QUE YA VIENE 
//						List<DatoIndicadores> lista=new ArrayList<DatoIndicadores>(); 
//						
//						if(!CollectionUtils.isEmpty(dua.getListIndicadores())){
//							for(DatoIndicadores indicador:dua.getListIndicadores()){
//								if(indicador.getCodtipoindica() != null   //CSANTILLAN PAS20181U220200004
//										&& indicador.getCodtipoindica().equals("54") ){
//									//P46  inicio EJHM
//									if(indicador.getIndicadorActivo()!=null && indicador.getIndicadorActivo().equals("01")){
//										mapa.put("isDAMDiferidaSinIca","true");
//									}
//								}
//							}
//						} 
				//}
	//fin pase PAS20181U220200004
						listErrores.addAll(validarGeneralVuce(codtipDocControl,numeroSerie, mapa));

						/**Inicio ajuste para setear el objeto serie VUCE RECTI**/
						if(mapa.get("seteoEntidad")!=null){
							docAutorizante.setCodentidad(mapa.get("seteoEntidad").toString().substring(0,2));
							docAutorizante.setCodsubentidad(mapa.get("seteoEntidad").toString());
							setearSubTipoDeDocumentoDeControl(docAutorizante, fechaReferencia);
						}
						/**Fin**/
						/** r2bz  Para todos los casos de VUCE se debe cargar las fechas de los documentos de Mercancias Restringidas*/
						DocControlMercRestringidaVuce docControlMercRestringidaVuce= (DocControlMercRestringidaVuce) mapa.get("docControlMercRestringidaVuce");
						if (mapa.get("docControlMercRestringidaVuce")!= null){
							Calendar calendar = Calendar.getInstance();
							docAutorizante.setFecemision(SunatDateUtils.sonIguales(docControlMercRestringidaVuce.getFechaDocumento(),SunatDateUtils.getDefaultDate(),SunatDateUtils.COMPARA_SOLO_FECHA)?docControlMercRestringidaVuce.getFechaInicioVigencia() :docControlMercRestringidaVuce.getFechaDocumento());
							docAutorizante.setFecvencimiento(docControlMercRestringidaVuce.getFechaFinVigencia());
							calendar.setTime(docAutorizante.getFecemision());
							docAutorizante.setAnndocum(SunatStringUtils.toStringObj(calendar.get(Calendar.YEAR)));							
						}
						// LAS TRANSACCIONES SE MANEJAN POR SERVICIOS, NO HARDCODE
						if(!codTransaccion.equals("1016")){
							if(codtipDocControl.equals("20")){
								// adicionalmente obliga enviar  21 para las siguientes entidades en caso que envio 20
								//excepcion 75
								if((SunatStringUtils.isStringInList(codigoSubEntidad, "0502,0302,2501,2801,1702,0201,0202,2301,2703,2501") )){
									//excepcion 75 new
									listErrores.add(catalogoAyudaService.getError("35719", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));
								}
								if(!tieneTratamientoDonacion && (SunatStringUtils.isStringInList(codigoSubEntidad, "0501,0503,0504,0301,0404,0406,0403,0407,2301") )){
									//excepcion 75 new								
									listErrores.add(catalogoAyudaService.getError("35719", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));
								}
							}
						}
					}

					if(SunatStringUtils.isEmptyTrim(docAutorizante.getCodigoAduanaAut())){//P_SNADE046-2094
						docAutorizante.setCodigoAduanaAut(dua.getCodaduanaorden());
					}
					if(!codTransaccion.equals("1016")){
						if(esSPNRestringida(lstMrestri, mercanciaSpn)){//estos docs solo se validan cuando la SPN es restringida
							if(variablesIngreso.get("indtipoValidacionVuce") != null &&
									!tieneExcepcionesValidacionVuce(codtipDocControl, codigoSubEntidad)){ //P_SNADE046-2053 y P_SNADE046-2040
								if(variablesIngreso.get("indtipoValidacionVuce").toString().equals("MostrarExcepcio86")){
									listErrores.add(catalogoAyudaService.getError("35730", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));
								} else if(variablesIngreso.get("indtipoValidacionVuce").toString().equals("MostrarExcepcio92")){
									listErrores.add(catalogoAyudaService.getError("35753", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));
								}
							}                    

							String codDocAutorizante= docAutorizante.getCodtipodocum()==null? "":docAutorizante.getCodtipodocum().toString();
							listErrores.addAll(validarMercanciaRestringidaVuceProduce(serie,codDocAutorizante,numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce));
							listErrores.addAll(validarParticularVuce(codTransaccion, serie, tieneTratamientoDonacion,codigoEntidad, codigoSubEntidad,codDocAutorizante, fechaReferencia));
						}
					} 
				}//inicio Pase 152 p24
				if(SunatStringUtils.isEmptyTrim(docAutorizante.getCodigoAduanaAut())){//P_SNADE046-2094
					docAutorizante.setCodigoAduanaAut(dua.getCodaduanaorden());
				}//fin Pase 152 p24
			}

			/***Inicio P_SNADE046-2127 validaciones de alertas para diligencia en casos especificos ***/
			if(codTransaccion.equals("1016") || codTransaccion.equals("1008")){
				listErrores.addAll(validarDiligenciaConVigenciaVuceConDoc(lstDocAutoriza, numeroSerie, mercanciaSpn,codigoSubEntidad));
			}
			/***Fin***/
		} else {
			boolean esVigenteVucePorFecha = esVigenteVucePorFecha(dua.getCodregimen(), SunatDateUtils.getCurrentDate());

			if(esVigenteVucePorFecha && lstMrestri!=null && !lstMrestri.isEmpty()){
				List<String> listaSubEntidadesMrestri = obtenerRegistrosMrestri(lstMrestri);
				List<String> listaSubEntidadesExigibles  = new ArrayList<String>();
				for(String subEntidadMrestri: listaSubEntidadesMrestri){
					if(esExigibleSubentidadPorVuce(esVigenteVucePorFecha,subEntidadMrestri, SunatDateUtils.getCurrentDate())){
						listaSubEntidadesExigibles.add(subEntidadMrestri);
					}					 	
				}

				if(!CollectionUtils.isEmpty(listaSubEntidadesExigibles)){//reduce el universo
					for(String subEntidadMrestri: listaSubEntidadesExigibles){
						codigoEntidad = subEntidadMrestri.substring(0,2);
						codigoSubEntidad=subEntidadMrestri;
						String codDocAutorizante= "";
						if(!codTransaccion.equals("1016")){
							listErrores.addAll(validarParticularVuce(codTransaccion, serie, tieneTratamientoDonacion,codigoEntidad, codigoSubEntidad,codDocAutorizante, fechaReferencia));
						}

						if(codTransaccion.equals("1016") || codTransaccion.equals("1008")){/***P_SNADE046-2127 validaciones de alertas para diligencia en casos especificos ***/
							listErrores.addAll(validarDiligenciaConVigenciaVuceSinDoc(numeroSerie, mercanciaSpn, subEntidadMrestri));
						}
					}
				}
			}
		}		
		return listErrores;
	}

	private boolean tieneExcepcionesValidacionVuce(String codtipDocControl, String codigoSubEntidad) {
		if (codtipDocControl.equals(DOC_EXONERACION)){
			return true;
		}

		if(SunatStringUtils.isStringInList(codigoSubEntidad, "0501,0503") && codtipDocControl.equals(DOC_EXONERACION80)){
			return true;
		}

		return false;
	}

	/**Adicionado para validar si la SPN corresponde a restringida
	 * para los docs que no sean 20 ni 21
	 * */
	public boolean esSPNRestringida(List<MRestri> lstMrestri,String mercanciaSpn){
		boolean esRestringida = false;

		if (lstMrestri!=null && !CollectionUtils.isEmpty(lstMrestri)) {			
			for (MRestri mrestri : lstMrestri) {		
				String partidaMrestri = mrestri.getCnan().toString();
				if(partidaMrestri.equals(mercanciaSpn)){
					esRestringida = true;
					continue;
				}
			}
		}

		return esRestringida;
	}

	public List<Map<String,String>> validarParticularVuce(String codTransaccion, DatoSerie serie,
			Boolean tieneTratamientoDonacion, String codigoEntidad,
			String codigoSubEntidad,String codDocAutorizante,
			Date fechaReferencia){

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		DUA dua = (DUA)serie.getPadre(); 
		String mercanciaSpn=serie.getNumpartnandi()==null? " ":serie.getNumpartnandi().toString();
		String numeroSerie=serie.getNumserie()==null? " ":serie.getNumserie().toString();
		String codAduana= dua.getCodaduanaorden();
		//		listErrores.addAll(validarMercanciaRestringidaVuceProduce(serie,codDocAutorizante,numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad));
		if(!codDocAutorizante.equalsIgnoreCase("98")){
			listErrores.addAll(validarMercanciaRestringidaVuceDonacion(tieneTratamientoDonacion, codDocAutorizante, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad));			
			//Control de cambios me reubica solo para 21
			//listErrores.addAll(validarMercanciaRestringidaVuceMtc(docControlMercRestringidaVuce, codTransaccion, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad));
			//listErrores.addAll(validarMercanciaRestringidaVuceMtcOtrosDocs(codDocAutorizante, mercanciaSpn, numeroSerie,codigoEntidad, codigoSubEntidad));//control de cambios VUCE
			if(esSubentidadVuceExonerada(codTransaccion, codigoSubEntidad, fechaReferencia)) {
				listErrores.addAll(validarMercanciaRestringidaVuceOtrosDocs(codDocAutorizante, mercanciaSpn, numeroSerie, codigoEntidad, codigoSubEntidad, fechaReferencia));//gg control de cambios VUCE
			}
			// esta validacion ya se hace anteriormente en obtenerTipoValidacionDocumentoAutorizante es la excepcion86
			//listErrores.addAll(validarMercanciaRestringidaVuceDigesa(tieneTratamientoDonacion, docAutorizante, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad));
			listErrores.addAll(validarMercanciaRestringidaVuceDigemid(codAduana, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad));		 
		}
		return listErrores;
	}

	public List<Map<String, String>> validarExistenciaSunatVuce(String isDAMDiferidaSinIca, String codtipDocControl,String numeroSerie, String mercanciaSpn,String codigoEntidad, String codigoSubEntidad, 
			String numerodocumentoVuce,DocControlMercRestringidaVuce docControlMercRestringidaVuce, Date fechaReferencia){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
//PAS20181U220200004
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		//docControlMercRestringidaVuce=  obtenerDatosVuce(numerodocumentoVuce, codtipDocControl);
		//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		//ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		//boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
		//DOCUMENTOS DE RESOLUCION  - 21
		if(codtipDocControl.equals("21")){
			//String flagisDAMDiferidaSinIca=isDAMDiferidaSinIca;
			//Boolean isDAMDiferida = false;
			//if(variablesIngreso!=null){
			//if(!isDAMDiferida){
			// se realizo en el metodo validarIQFDespachoDiferidoSinPesosBultosRecibidos
//			if(esVigenteRIN05PrimeraParte && !SunatStringUtils.isEmptyTrim(codigoEntidad) && "30".equals(codigoEntidad)&& "true".equals(flagisDAMDiferidaSinIca)){
//			//isDAMDiferida = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
//			listErrores.add(catalogoAyudaService.getError("40427", new String []{numeroSerie,mercanciaSpn}));
//			}
			//}
			
			if(docControlMercRestringidaVuce==null){			   
				//excepci?n 11
				listErrores.add(catalogoAyudaService.getError("35736", new String []{numeroSerie,mercanciaSpn,numerodocumentoVuce}));
				//break;				 

			}else{
				String estadoDocumentoVuce=docControlMercRestringidaVuce.getEstadoDocumento()==null?"":docControlMercRestringidaVuce.getEstadoDocumento().toString();
				if( !SunatStringUtils.isEmptyTrim(estadoDocumentoVuce) && ((SunatStringUtils.isStringInList(estadoDocumentoVuce, "05"))) ){
					String entidadVuce=docControlMercRestringidaVuce.getEntidad()==null?"":docControlMercRestringidaVuce.getEntidad();
					String subentidadVuce=docControlMercRestringidaVuce.getSubEntidad()==null?"":docControlMercRestringidaVuce.getSubEntidad();
					//excepcion 94 (13 del F2) new
					listErrores.add(catalogoAyudaService.getError("35738", new String []{numeroSerie,mercanciaSpn,entidadVuce,subentidadVuce, numerodocumentoVuce}));//decia 35760 y dicho error no existe mas que en desarrollo

				}	

			}

		}
		//documentos SUCE - 20
		if(codtipDocControl.equals("20")){
			if(docControlMercRestringidaVuce==null){
				if(SunatStringUtils.isEmptyTrim(codigoEntidad) && SunatStringUtils.isEmptyTrim(codigoSubEntidad)){
					listErrores.add(catalogoAyudaService.getError("35767", new String []{numeroSerie,mercanciaSpn, numerodocumentoVuce})); 
				}else{
					listErrores.add(catalogoAyudaService.getError("35741", new String []{numeroSerie,mercanciaSpn, codigoEntidad, codigoSubEntidad, numerodocumentoVuce}));
				}
				// break;

			}
		}


		return listErrores;
	}

	public List<Map<String, String>> validarEstadoSUCE(String estadoDocumentoVuce,String numeroSerie, String mercanciaSpn, String codigoEntidad, String codigoSubEntidad, String numerodocumentoVuce , String descEstadoDocumentoVuce){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		/* String descEstadoDocumentoVuce;

	     if(estadoDocumentoVuce.equals("02")){
	    	 descEstadoDocumentoVuce = "APROBADO";
	        }
	     else if(estadoDocumentoVuce.equals("03")){
	    	 descEstadoDocumentoVuce = "DENEGADO";
	        }
	     else if(estadoDocumentoVuce.equals("04")){
	    	 descEstadoDocumentoVuce = "DESISTIDO";
	        }
	     else{
	    	 descEstadoDocumentoVuce=estadoDocumentoVuce;
	     }*/

		if(SunatStringUtils.isStringInList(estadoDocumentoVuce, "02")){
			//excepcion 97 (13 del F2) new 
			listErrores.add(catalogoAyudaService.getError("35743", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numerodocumentoVuce}));
			//break;
		}else if(SunatStringUtils.isStringInList(estadoDocumentoVuce, "03,04")){
			//excepcion 98 new
			listErrores.add(catalogoAyudaService.getError("35744", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numerodocumentoVuce,descEstadoDocumentoVuce}));
			//break;
		}

		return listErrores;
	}



	public List<Map<String,String>> validarTitularDR( String regPrecedente70, String codigoEntidad, String codigoSubEntidad, String numeroSerie,String TipoParticipante, String tipoDocumConsigNumeracion, String numeDocumConsigNumeracion, String tipoDocumTitularVuce, String numeroDocumTitularVuce, String numerodocumentoVuce, String cutVuce){

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		boolean validarTitular = true;//ajustes por bug P_SNADE046-1918
		if(!SunatStringUtils.isEmptyTrim(numeroDocumTitularVuce) && (SunatStringUtils.isStringInList(cutVuce, "132,141,142") && numeDocumConsigNumeracion.equals("20131373237"))){
			validarTitular=false;
		}
		//if((SunatStringUtils.isEmptyTrim(numeroDocumTitularVuce) && !(SunatStringUtils.isStringInList(cutVuce, "132,141,142") && numeDocumConsigNumeracion.equals("20131373237")))  ||////ajustes por bug P_SNADE046-1918
		if((!SunatStringUtils.isEmptyTrim(numeroDocumTitularVuce) &&
				regPrecedente70.equals("70") && 
				(SunatStringUtils.isStringInList(cutVuce, "230,199,191") && SunatStringUtils.isStringInList(codigoEntidad, "23") ||
						//SunatStringUtils.isStringInList(cutVuce, "442") && SunatStringUtils.isStringInList(codigoEntidad, "27") ||control de cambios
						SunatStringUtils.isStringInList(cutVuce, "442") && SunatStringUtils.isStringInList(codigoSubEntidad,"2701,2702") ||//ajuste
						SunatStringUtils.isStringInList(cutVuce, "70") && SunatStringUtils.isStringInList(codigoEntidad, "28") ||
						SunatStringUtils.isStringInList(cutVuce, "184,33,29,35") && SunatStringUtils.isStringInList(codigoEntidad, "05") ||
						SunatStringUtils.isStringInList(cutVuce, "189") && SunatStringUtils.isStringInList(codigoEntidad, "06") ||
						SunatStringUtils.isStringInList(cutVuce, "80,79") && SunatStringUtils.isStringInList(codigoEntidad, "08")
						)
				)
				){
			validarTitular=false;
		}
		if (validarTitular && SunatStringUtils.isEqualTo(TipoParticipante, ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){	

			if(!(tipoDocumTitularVuce.equals(tipoDocumConsigNumeracion) && numeDocumConsigNumeracion.equals(numeroDocumTitularVuce))){
				//excepcion 95 new 
				listErrores.add(catalogoAyudaService.getError("35739", new String []{numeroSerie,numeroDocumTitularVuce,numerodocumentoVuce,numeDocumConsigNumeracion}));//R1597

			}
		}
		//}//ajustes por bug P_SNADE046-1918
		return listErrores;
	}

	public List<Map<String,String>> validarEntidadSubEntidadDR(String nroEntidadDocAutorizante, String nrosubentidadDocAutorizante, String codigoEntidadVuce, String codigoSubEntidadVuce,String numeroSerie,String mercanciaSpn, String numerodocumentoVuce,
			String codSubEntidadMrestri, List<String>listSubEntidadesMrestri, int nroEntidadesByCutmayoraUno){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		String listaEntidadesMrestri="";
		String listaSubentidadesMrestri="";
		//String [] subEntidadesMrestri= null;
		if(!CollectionUtils.isEmpty(listSubEntidadesMrestri)){				 
			for(String subEntidadMrestri : listSubEntidadesMrestri){
				listaEntidadesMrestri+=subEntidadMrestri.substring(0,2)+",";
				listaSubentidadesMrestri+=subEntidadMrestri+",";
			}


			//subEntidadesMrestri = listaSubentidadesMrestri.split(",");
			if(!SunatStringUtils.isEmptyTrim(listaEntidadesMrestri) && !SunatStringUtils.isEmptyTrim(listaEntidadesMrestri)){
				listaEntidadesMrestri = listaEntidadesMrestri.substring(0,listaEntidadesMrestri.length()-1);
				//listaEntidadesMrestri = "[" + listaEntidadesMrestri + "]";
				listaSubentidadesMrestri = listaSubentidadesMrestri.substring(0,listaSubentidadesMrestri.length()-1);
				//listaSubentidadesMrestri = "[" + listaSubentidadesMrestri +  "]";
			}
		}


		if(!SunatStringUtils.isEmptyTrim(nroEntidadDocAutorizante) && !SunatStringUtils.isEmptyTrim(nrosubentidadDocAutorizante)){//Ajuste VUCE RECTI,dilig siempre hay estos datos 
			String descnroEntidadDocAutorizante  =  catalogoAyudaService.getDescripcionDataCatalogo("49",nroEntidadDocAutorizante);
			String descnrosubentidadDocAutorizante  =  catalogoAyudaService.getDescripcionDataCatalogo("930",nrosubentidadDocAutorizante);
			String desccodigoEntidadVuce  =  catalogoAyudaService.getDescripcionDataCatalogo("49",codigoEntidadVuce);
			String desccodigoSubEntidadVuce  =  catalogoAyudaService.getDescripcionDataCatalogo("930",codigoSubEntidadVuce);
			String entidadDocAutorizante =   descnroEntidadDocAutorizante!=""?nroEntidadDocAutorizante.concat("-").concat(descnroEntidadDocAutorizante):nroEntidadDocAutorizante;
			String subentidadDocAutorizante =  descnrosubentidadDocAutorizante!=""?nrosubentidadDocAutorizante.concat("-").concat(descnrosubentidadDocAutorizante):nrosubentidadDocAutorizante;
			String entidadVuce = desccodigoEntidadVuce!=""?codigoEntidadVuce.concat("-").concat(desccodigoEntidadVuce):codigoEntidadVuce;
			String subEntidadVuce = desccodigoSubEntidadVuce!=""?codigoSubEntidadVuce.concat("-").concat(desccodigoSubEntidadVuce):codigoSubEntidadVuce;


			if(nroEntidadesByCutmayoraUno==1 && !(nroEntidadDocAutorizante.equals(codigoEntidadVuce) && nrosubentidadDocAutorizante.equals(codigoSubEntidadVuce))){
				//excepcion 93 (12 DEL F2) new				
				listErrores.add(catalogoAyudaService.getError("35737", new String []{numeroSerie,mercanciaSpn,entidadDocAutorizante,subentidadDocAutorizante,numerodocumentoVuce,entidadVuce,subEntidadVuce}));
			}

			if(nroEntidadesByCutmayoraUno>1 && !(SunatStringUtils.isStringInList(nroEntidadDocAutorizante,codigoEntidadVuce) && SunatStringUtils.isStringInList(nrosubentidadDocAutorizante,codigoSubEntidadVuce))){
				//excepcion 93 (12 DEL F2) new		
				String listaEntidadVuce = "[" + codigoEntidadVuce + "]";
				String listaSubEntidadVuce =  "[" + codigoSubEntidadVuce + "]";
				listErrores.add(catalogoAyudaService.getError("35737", new String []{numeroSerie,mercanciaSpn,entidadDocAutorizante,subentidadDocAutorizante,numerodocumentoVuce,listaEntidadVuce,listaSubEntidadVuce}));
			}

			/**Inicio de ajustes por  P_SNADE046-1917**/
			if(nroEntidadesByCutmayoraUno>1 &&  !(SunatStringUtils.isStringInList(nroEntidadDocAutorizante, listaEntidadesMrestri) && listSubEntidadesMrestri.contains(nrosubentidadDocAutorizante))){
				listaEntidadesMrestri = "[" + listaEntidadesMrestri + "]";
				listaSubentidadesMrestri = "[" + listaSubentidadesMrestri +  "]";
				listErrores.add(catalogoAyudaService.getError("35751", new String []{numeroSerie,mercanciaSpn,listaEntidadesMrestri,listaSubentidadesMrestri,numerodocumentoVuce, entidadDocAutorizante,subentidadDocAutorizante}));
			}
			/**Fin de ajustes por  P_SNADE046-1917**/

		}else{//Ajuste VUCE RECTI: puede ser que no haya entidad, subentidad transmitida por usuario			
			//String [] subEntidadesMrestri = listaSubentidadesMrestri.split(",");
			if(nroEntidadesByCutmayoraUno==1 && !codSubEntidadMrestri.equals(codigoSubEntidadVuce) && (!CollectionUtils.isEmpty(listSubEntidadesMrestri) && listSubEntidadesMrestri.size()==1)){//aplicacion de R1599
				String desentidadesMrestri=catalogoAyudaService.getDescripcionDataCatalogo("49",listSubEntidadesMrestri.get(0).substring(0,2));
				String dessubentidadesMrestri  =  catalogoAyudaService.getDescripcionDataCatalogo("930",listSubEntidadesMrestri.get(0));
				String desccodigoEntidadVuce  =  catalogoAyudaService.getDescripcionDataCatalogo("49",codigoEntidadVuce);
				String desccodigoSubEntidadVuce  =  catalogoAyudaService.getDescripcionDataCatalogo("930",codigoSubEntidadVuce);
				String entidadesMrestri =  desentidadesMrestri!=""?listSubEntidadesMrestri.get(0).substring(0,2).concat("-").concat(desentidadesMrestri):listSubEntidadesMrestri.get(0).substring(0,2);
				String subentidadesMrestri = dessubentidadesMrestri!=""?listSubEntidadesMrestri.get(0).concat("-").concat(dessubentidadesMrestri):listSubEntidadesMrestri.get(0);
				String entidadVuce = desccodigoEntidadVuce!=""?codigoEntidadVuce.concat("-").concat(desccodigoEntidadVuce):codigoEntidadVuce;
				String subEntidadVuce = desccodigoSubEntidadVuce!=""?codigoSubEntidadVuce.concat("-").concat(desccodigoSubEntidadVuce):codigoSubEntidadVuce;
				listErrores.add(catalogoAyudaService.getError("35751", new String []{numeroSerie,mercanciaSpn,entidadesMrestri, subentidadesMrestri,numerodocumentoVuce,entidadVuce,subEntidadVuce}));
			}else 
				if( "".equals(codSubEntidadMrestri)){//ajustes por P_SNADE046-1917
					String listaEntidadVuce = "[" + codigoEntidadVuce + "]";
					String listaSubEntidadVuce =  "[" + codigoSubEntidadVuce + "]";
					listaEntidadesMrestri = "[" + listaEntidadesMrestri + "]";
					listaSubentidadesMrestri = "[" + listaSubentidadesMrestri +  "]";
					listErrores.add(catalogoAyudaService.getError("35751", new String []{numeroSerie,mercanciaSpn,listaEntidadesMrestri, listaSubentidadesMrestri,numerodocumentoVuce,listaEntidadVuce,listaSubEntidadVuce}));
				}

			//			if(nroEntidadesByCutmayoraUno>1 && !listSubEntidadesMrestri.contains(codigoSubEntidadVuce)){//ajustes 
			//				
			//				
			//				listErrores.add(catalogoAyudaService.getError("35751", new String []{numeroSerie,mercanciaSpn,
			//						nroEntidadDocAutorizante,nrosubentidadDocAutorizante,numerodocumentoVuce,codSubEntidadMrestri.substring(0,2),codSubEntidadMrestri}));
			//			}
			//			if( "".equals(codSubEntidadMrestri)){//ajustes por P_SNADE046-1917
			//				String listaEntidadVuce = "[" + codigoEntidadVuce + "]";
			//				String listaSubEntidadVuce =  "[" + codigoSubEntidadVuce + "]";
			//				listErrores.add(catalogoAyudaService.getError("35751", new String []{numeroSerie,mercanciaSpn,ListaEntidadesMrestri, listaSubentidadesMrestri,numerodocumentoVuce,listaEntidadVuce,listaSubEntidadVuce}));
			//			}


		}		

		return listErrores;
	}


	public List<Map<String,String>> validarVigenciaDRVuce(String regPrecedente70, String mercanciaTPN21, Date fecha, Date fechaInicioDR, Date fechaFinDR , String numeroSerie, String mercanciaSpn, 
			String numeroDocumentoVuce, String codigoEntidad, String codigoSubEntidad){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		if(fechaInicioDR!=null && fechaFinDR!=null && !SunatDateUtils.isDefaultDate(fechaInicioDR) && !SunatDateUtils.isDefaultDate(fechaFinDR)){//adicionado por control de cambios VUCE
			if(SunatDateUtils.esFecha1MayorQueFecha2(fecha,fechaFinDR,SunatDateUtils.COMPARA_SOLO_FECHA)){
				if((codigoSubEntidad.equals("0501") || codigoSubEntidad.equals("0503")) && (regPrecedente70.equals("70")|| mercanciaTPN21.equals("21"))){
					//excepcion 77 new  es warnig no error
					listErrores.add(catalogoAyudaService.getError("35721", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));//ajuste
				}else{
					// genera rechazo
					listErrores.add(catalogoAyudaService.getError("35720", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));
				}
			}		
		}
		return listErrores;	
	}

	public List<Map<String,String>> validarAduanaDRVuce(String nrosubentidadDocAutorizante, String  codigoAduanaVuce , String codAduana,String numeroSerie, String mercanciaSpn, String codigoEntidad, String codigoSubEntidad, String numerodocumentoVuce){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(nrosubentidadDocAutorizante.equals("0302")){//R1618
			if(!SunatStringUtils.isEmptyTrim(codigoAduanaVuce) && !codigoAduanaVuce.equals(codAduana) ){
				//excepcion 83 new
				listErrores.add(catalogoAyudaService.getError("35727", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numerodocumentoVuce}));

			}
		}

		return listErrores;	
	}

	public List<Map<String,String>> validarDRDeclaradoEnOtraDam(String codtipDocControl, String numeroSerie, String mercanciaSpn, String codigoEntidad, String codigoSubEntidad, String numeroDocumentoVuce, String numCorredocDAM, String codTransaccion){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");

		if(codigoSubEntidad.equals("0302") || (codTransaccion.endsWith("01") && SunatStringUtils.isStringInList(codigoSubEntidad, "0501,0503"))){
			//acorde a la aplicacion de la R1621 PAS20165E220200072		
			//verificamos si es que los documentos autorizantes ya fueron cargadas anteriormente
			List<DatoDocAutorizante>  listDocAutAsociadoSerie= null; 
			Map<String,Object> params = new HashMap<String,Object>();
			params.put("codTipoDocum", codtipDocControl);
			params.put("numDocum",numeroDocumentoVuce);
			params.put("codentidad",codigoEntidad);
			params.put("codSubEntidad",codigoSubEntidad);	
			listDocAutAsociadoSerie = docAutAsociadoDAO.listDocAutorizante(params);
			String numeroDAM="";
			if(listDocAutAsociadoSerie!=null && !listDocAutAsociadoSerie.isEmpty()){
				String numcorredoc;
				Map<String, Object> paramDua = new HashMap<String, Object>();
				CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
				for(DatoDocAutorizante datoDocAutorizante : listDocAutAsociadoSerie){
					numcorredoc=datoDocAutorizante.getNumcorredoc().toString();
					if(!numcorredoc.equals(numCorredocDAM)){//P_SNADE046-2133 no debe tomar el de la numeracion
						paramDua.put("numeroCorrelativo", numcorredoc);
						DUA duaAux = cabDeclaraDAO.selectByNumCorredoc(paramDua);
						if(!ConstantesDataCatalogo.COD_DUA_LEGAJADA.equalsIgnoreCase(duaAux.getCodEstdua().toString())){//no considerar a las legajadas
							numeroDAM = duaAux.getCodaduanaorden().toString() + "-" + duaAux.getAnnpresen().toString() + "-" + duaAux.getCodregimen().toString() + "-" +  duaAux.getNumdocumento().toString();
							break;//la primera que encuentre no legajada sale
						}
					}
				}
				if(!numeroDAM.isEmpty()){
					if(codigoSubEntidad.equals("0302")){
						listErrores.add(catalogoAyudaService.getError("35728", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce,numeroDAM}));
					} else {
						listErrores.add(catalogoAyudaService.getError("35722", new String []{numeroDocumentoVuce}));
					}
				}
			}
		}//adicionado por PAS20165E220200072

		return listErrores;	
	}

	public List<Map<String,String>> validarTitularSUCE( String numeroDeclaracion, String numeroSerie,String TipoParticipante, String tipoDocumConsigNumeracion, String numeDocumConsigNumeracion, String tipoDocumTitularVuce, String numeroDocumTitularVuce, String numerodocumentoVuce){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		// TipoParticipante = dua.getDeclarante().getTipoParticipante().getCodDatacat()
		if (SunatStringUtils.isEqualTo(TipoParticipante, ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
			//tipoDocumConsigNumeracion = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat()==null?" ":dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().toString();
			//numeDocumConsigNumeracion = dua.getDeclarante().getNumeroDocumentoIdentidad()==null?"": dua.getDeclarante().getNumeroDocumentoIdentidad().toString();
			if((!(tipoDocumTitularVuce.equals(tipoDocumConsigNumeracion) && numeDocumConsigNumeracion.equals(numeroDocumTitularVuce))) ){
				//excepcion 95
				listErrores.add(catalogoAyudaService.getError("35745", new String []{numeroSerie,numeroDocumTitularVuce,numerodocumentoVuce,numeDocumConsigNumeracion}));//ajustado P_SNADE046-1985
				//break;
			}
		}

		return listErrores;	
	}

	public List<Map<String,String>> validarEntidadSubEntidadSUCE(String codigoEntidad, String codigoSubEntidad, String codigoEntidadVuce, String codigoSubEntidadVuce,String numeroSerie,String mercanciaSpn, String numerodocumentoVuce,
			String codSubEntidadMrestri, List<String>listSubEntidadesMrestri, int nroEntidadesByCutmayoraUno){
		String ListaEntidadesMrestri="";
		String listaSubentidadesMrestri="";
		//String [] subEntidadesMrestri = null;
		if(!CollectionUtils.isEmpty(listSubEntidadesMrestri)){				 
			for(String subEntidadMrestri : listSubEntidadesMrestri){
				ListaEntidadesMrestri+=subEntidadMrestri.substring(0,2)+",";
				listaSubentidadesMrestri+=subEntidadMrestri+",";
			}	
			listaSubentidadesMrestri = listaSubentidadesMrestri.substring(0,listaSubentidadesMrestri.length()-1);
			ListaEntidadesMrestri = ListaEntidadesMrestri.substring(0,ListaEntidadesMrestri.length()-1);
			// subEntidadesMrestri = listaSubentidadesMrestri.split(",");
			if(!SunatStringUtils.isEmptyTrim(ListaEntidadesMrestri) && !SunatStringUtils.isEmptyTrim(ListaEntidadesMrestri)){
				//ListaEntidadesMrestri = ListaEntidadesMrestri.substring(0,ListaEntidadesMrestri.length()-2);
				ListaEntidadesMrestri = "[" + ListaEntidadesMrestri + "]";
				//listaSubentidadesMrestri = listaSubentidadesMrestri.substring(0,listaSubentidadesMrestri.length()-2);
				listaSubentidadesMrestri = "[" + listaSubentidadesMrestri +  "]";
			}
		}

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		if(!SunatStringUtils.isEmptyTrim(codigoEntidad) && !SunatStringUtils.isEmptyTrim(codigoSubEntidad)){//Ajuste VUCE RECTI,dilig siempre hay estos datos

			if(( nroEntidadesByCutmayoraUno <= 1 && !(codigoEntidad.equals(codigoEntidadVuce) && codigoSubEntidad.equals(codigoSubEntidadVuce))) ){
				//excepcion 96 (12 DEL F2) new 
				listErrores.add(catalogoAyudaService.getError("35746", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numerodocumentoVuce,codigoEntidadVuce,codigoSubEntidadVuce}));
				//break;
			}

			if((nroEntidadesByCutmayoraUno > 1 && !(SunatStringUtils.isStringInList(codigoEntidad,codigoEntidadVuce) && SunatStringUtils.isStringInList(codigoSubEntidad,codigoSubEntidadVuce))) ){
				//excepcion 96 (12 DEL F2) new 
				String listaEntidadVuce = "[" + codigoEntidadVuce + "]";
				String listaSubEntidadVuce =  "[" + codigoSubEntidadVuce + "]";
				listErrores.add(catalogoAyudaService.getError("35746", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numerodocumentoVuce,listaEntidadVuce,listaSubEntidadVuce}));
				//break;
			}


			if(nroEntidadesByCutmayoraUno>1 &&  !(SunatStringUtils.isStringInList(codigoEntidad, codigoEntidadVuce) && listSubEntidadesMrestri.contains(codigoSubEntidad))){
				listErrores.add(catalogoAyudaService.getError("35742", new String []{numeroSerie,mercanciaSpn,ListaEntidadesMrestri,listaSubentidadesMrestri,numerodocumentoVuce, codigoEntidad,codigoSubEntidad}));
			}


		}else{//Ajuste VUCE RECTI: puede ser que no haya entidad, subentidad transmitida por usuario			
			//if(!listSubEntidadesMrestri.contains(codigoSubEntidadVuce)){//aplicacion de R1599
			//String [] subEntidadesMrestri = listaSubentidadesMrestri.split(",");
			if(nroEntidadesByCutmayoraUno==1 && !codSubEntidadMrestri.equals(codigoSubEntidadVuce) && (!CollectionUtils.isEmpty(listSubEntidadesMrestri) && listSubEntidadesMrestri.size()==1)){//aplicacion de R1599
				String desentidadesMrestri=catalogoAyudaService.getDescripcionDataCatalogo("49",listSubEntidadesMrestri.get(0).substring(0,2));
				String dessubentidadesMrestri  =  catalogoAyudaService.getDescripcionDataCatalogo("930",listSubEntidadesMrestri.get(0));
				String desccodigoEntidadVuce  =  catalogoAyudaService.getDescripcionDataCatalogo("49",codigoEntidadVuce);
				String desccodigoSubEntidadVuce  =  catalogoAyudaService.getDescripcionDataCatalogo("930",codigoSubEntidadVuce);
				String entidadesMrestri =  desentidadesMrestri!=""?listSubEntidadesMrestri.get(0).substring(0,2).concat("-").concat(desentidadesMrestri):listSubEntidadesMrestri.get(0).substring(0,2);
				String subentidadesMrestri = dessubentidadesMrestri!=""?listSubEntidadesMrestri.get(0).concat("-").concat(dessubentidadesMrestri):listSubEntidadesMrestri.get(0);
				String entidadVuce = desccodigoEntidadVuce!=""?codigoEntidadVuce.concat("-").concat(desccodigoEntidadVuce):codigoEntidadVuce;
				String subEntidadVuce = desccodigoSubEntidadVuce!=""?codigoSubEntidadVuce.concat("-").concat(desccodigoSubEntidadVuce):codigoSubEntidadVuce;
				listErrores.add(catalogoAyudaService.getError("35742", new String []{numeroSerie,mercanciaSpn,entidadesMrestri, subentidadesMrestri,numerodocumentoVuce,entidadVuce,subEntidadVuce}));
			}else 
				if( "".equals(codSubEntidadMrestri)){
					String listaEntidadVuce = "[" + codigoEntidadVuce + "]";
					String listaSubEntidadVuce =  "[" + codigoSubEntidadVuce + "]";
					//listErrores.add(catalogoAyudaService.getError("35751", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoEntidad,numerodocumentoVuce,codSubEntidadMrestri.substring(0,2),codSubEntidadMrestri}));
					listErrores.add(catalogoAyudaService.getError("35742", new String []{numeroSerie,mercanciaSpn,ListaEntidadesMrestri, listaSubentidadesMrestri,numerodocumentoVuce,listaEntidadVuce,listaSubEntidadVuce}));
				}
		}		


		return listErrores;	
	}

	public List<Map<String,String>> validarVigenciaSUCEVuce( String codAduana , Date fechaReferencia, Date fechaNumerVuceDate,  String numeroSerie, String mercanciaSpn,String codigoEntidad, String codigoSubEntidad,String numeroDocumentoVuce){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(SunatStringUtils.isStringInList(codigoSubEntidad, "0401") ){
			boolean fechaHabilParaNumerar=validardiferenciaFechas(fechaReferencia,fechaNumerVuceDate,codAduana);
			if(!fechaHabilParaNumerar){
				listErrores.add(catalogoAyudaService.getError("35731", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));
				//break;
			}
		}
		return listErrores;	
	}

	public List<Map<String,String>> validarGeneralVuce(String codtipDocControl,String numeroSerie, Map<String, Object> map){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		String regPrecedente70 = map.get("regPrecedente70").toString();
		String mercanciaSpn = map.get("mercanciaSpn").toString();
		String numeroDocumentoVuce = map.get("numeroDocumentoVuce").toString();
		String codigoEntidad = map.get("codigoEntidad").toString();
		String codigoSubEntidad = map.get("codigoSubEntidad").toString();
		String tipoParticipante = map.get("tipoParticipante").toString();
		String tipoDocumConsigNumeracion = map.get("tipoDocumConsigNumeracion").toString();
		String numeDocumConsigNumeracion = map.get("numeDocumConsigNumeracion").toString();
		String mercanciaTPN21 = map.get("mercanciaTPN21").toString();
		String codAduana = map.get("codAduana").toString();
		String numeroDeclaracion = map.get("numeroDeclaracion").toString();
		Date fechaReferencia =   (Date) map.get("fechaReferencia");
		Long numDocControlLong = SunatNumberUtils.toLong(numeroDocumentoVuce);
		String isDAMDiferidaSinIca= map.get("isDAMDiferidaSinIca")!=null?map.get("isDAMDiferidaSinIca").toString():"false"; //CSANTILLAN control de null PAS20181U220200004
		//Boolean tieneTratamientoDonacion = (Boolean) (map.get("tieneTratamientoDonacion")!=null?map.get("tieneTratamientoDonacion"):false);//P_SNADE046-2085
		String codTransaccion =  map.get("codTransaccion")!=null?map.get("codTransaccion").toString():"";
		String numCorredocDAM = map.get("numCorredocDAM")!=null?map.get("numCorredocDAM").toString():"";//P_SNADE046-2133
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		/**inicio ajustes para entidad - subentidad**/
		String codRegimen = map.get("codRegimen").toString();
		List<MRestri> lstMrestri = map.get("listaMrestri")!=null ? (List<MRestri>) map.get("listaMrestri"):null;
		List<String> listSubEntidadesMrestri = obtenerRegistrosPorBusquedaMrestri( mercanciaSpn , fechaReferencia, codRegimen, lstMrestri);
		/**fin ajustes para entidad - subentidad**/
		// List<String> listSubEntidadesMrestri = map.get("subEntidadesMrestri")!=null? obtenerRegistrosMrestri((ArrayList<MRestri>) map.get("subEntidadesMrestri")):null;//adicionado por RECTI VUCE

		if(codtipDocControl.equals(DOC_RESOLUTIVO) || codtipDocControl.equals(SOLICITUD_SUCE)){
			DocControlMercRestringidaVuce docControlMercRestringidaVuce= null;
			//validar existencia SUNAT VUCE

			try {
				docControlMercRestringidaVuce =  obtenerDocumentoVuce(numDocControlLong, codtipDocControl);
				listErrores.addAll(validarExistenciaSunatVuce(isDAMDiferidaSinIca,codtipDocControl, numeroSerie, mercanciaSpn,codigoEntidad,codigoSubEntidad, numeroDocumentoVuce, docControlMercRestringidaVuce, fechaReferencia));//PAS20181U220200004
			} catch (HttpClientErrorException e) {
				listErrores.add(catalogoAyudaService.getError("37020", new String[]{numeroSerie, codtipDocControl, numDocControlLong.toString()}));
				return listErrores;
			} catch (ServiceException e) {
				docControlMercRestringidaVuce = null;
				listErrores.addAll(validarExistenciaSunatVuce(isDAMDiferidaSinIca,codtipDocControl, numeroSerie, mercanciaSpn,codigoEntidad,codigoSubEntidad, numeroDocumentoVuce, docControlMercRestringidaVuce, fechaReferencia));//PAS20181U220200004
				return listErrores;
			}
			//si existe VUCE
			if(CollectionUtils.isEmpty(listErrores) && docControlMercRestringidaVuce!=null){
				String numeroDocumTitularVuce="";
				String tipoDocumTitularVuce ="";
				String codSubEntidadMrestri ="";//adicionado por RECTI VUCE
				if(docControlMercRestringidaVuce.getTitularDRVuce()!=null){
					numeroDocumTitularVuce=docControlMercRestringidaVuce.getTitularDRVuce().getNumeroDocumento()==null?"":docControlMercRestringidaVuce.getTitularDRVuce().getNumeroDocumento().toString();
					tipoDocumTitularVuce=docControlMercRestringidaVuce.getTitularDRVuce().getTipoDocumento()==null?"":docControlMercRestringidaVuce.getTitularDRVuce().getTipoDocumento().toString();
				}
				String cutVuce= docControlMercRestringidaVuce.getNumeroCUT()==null?" ":docControlMercRestringidaVuce.getNumeroCUT()==null?"":docControlMercRestringidaVuce.getNumeroCUT().toString();
				String codigoEntidadVuce= docControlMercRestringidaVuce.getEntidad()==null?"":docControlMercRestringidaVuce.getEntidad();
				String codigoSubEntidadVuce=docControlMercRestringidaVuce.getSubEntidad()==null?"":docControlMercRestringidaVuce.getSubEntidad();
				String codigoAduanaVuce=docControlMercRestringidaVuce.getcodAduanaDocumento()==null? " ":docControlMercRestringidaVuce.getcodAduanaDocumento().toString();
				String estadoDocumentoVuce=docControlMercRestringidaVuce.getEstadoDocumento()==null?"":docControlMercRestringidaVuce.getEstadoDocumento();
				String descEstadoDocumentoVuce = docControlMercRestringidaVuce.getEstadoDocumentoDesc()==null?"":docControlMercRestringidaVuce.getEstadoDocumentoDesc();//ajustado
				int nroEntidadesByCutmayoraUno = docControlMercRestringidaVuce.getNroEntidadesByCutmayoraUno()==null || (docControlMercRestringidaVuce.getNroEntidadesByCutmayoraUno()!=null &&
						SunatStringUtils.isEmptyTrim(docControlMercRestringidaVuce.getNroEntidadesByCutmayoraUno()))?0:new Integer((docControlMercRestringidaVuce.getNroEntidadesByCutmayoraUno()).toString());//ajuste bug P_SNADE046-1917
				Date fechaNumerVuceDate=(Date) docControlMercRestringidaVuce.getFechaDocumento();
				Date fechaInicioVuce=null;
				Date fechaFinVuce= null;
				fechaInicioVuce= docControlMercRestringidaVuce.getFechaInicioVigencia();
				fechaFinVuce= docControlMercRestringidaVuce.getFechaFinVigencia();
				map.put("docControlMercRestringidaVuce", docControlMercRestringidaVuce);//esto se usa en la diligencia y regu por la portal web

				/***Inicio ajustes RECTI VUCE**/
				if(SunatStringUtils.isEmptyTrim(codigoEntidad) || SunatStringUtils.isEmptyTrim(codigoSubEntidad) || nroEntidadesByCutmayoraUno>1){//solo sucedera para las transmisiones sin Subentidad ajuste RECTI VUCE
					codigoEntidadVuce = "";
					codigoSubEntidadVuce = "";
					List<String> listSuEntidadesCut= obtenerSubentidadesPorCut(cutVuce, fechaReferencia);
					codSubEntidadMrestri = obtenerRegistroPorCut(listSuEntidadesCut, listSubEntidadesMrestri);
					for(String subentidadCut : listSuEntidadesCut){
						codigoSubEntidadVuce=codigoSubEntidadVuce + subentidadCut + ",";
						codigoEntidadVuce= codigoEntidadVuce + subentidadCut.substring(0,2) + ",";
					}
					if (codigoSubEntidadVuce != "") {			   			
						codigoSubEntidadVuce = codigoSubEntidadVuce.substring(0,codigoSubEntidadVuce.length()-1);
					}
					if (codigoEntidadVuce != "") {
						codigoEntidadVuce = codigoEntidadVuce.substring(0,codigoEntidadVuce.length()-1);
					}
				}
				/***FIN ajustes RECTI VUCE**/
				//validaciones de la DR
				if(!codTransaccion.equals("1016")){
					if(codtipDocControl.equals("21")){
						listErrores.addAll(validarEntidadSubEntidadDR(codigoEntidad, codigoSubEntidad, codigoEntidadVuce, codigoSubEntidadVuce, numeroSerie, mercanciaSpn, numeroDocumentoVuce, codSubEntidadMrestri,listSubEntidadesMrestri, nroEntidadesByCutmayoraUno));//reubicacion
						//setearEntidadSubEntidad(codigoEntidad, codigoSubEntidad,codigoSubEntidadVuce,codSubEntidadMrestri,listSubEntidadesMrestri, map);//VUCE RECTI: solo sucede en transmisiones sin subentidad
						if((SunatStringUtils.isEmptyTrim(codigoEntidad) || SunatStringUtils.isEmptyTrim(codigoSubEntidad)) && !SunatStringUtils.isEmptyTrim(codSubEntidadMrestri)){ 
							if(listSubEntidadesMrestri!=null && nroEntidadesByCutmayoraUno == 1 && listSubEntidadesMrestri.contains(codigoSubEntidadVuce)){
								codigoSubEntidad = codSubEntidadMrestri;
								codigoEntidad = codSubEntidadMrestri.substring(0,2);
								map.put("seteoEntidad",codigoSubEntidad);
							} else if (listSubEntidadesMrestri!=null && nroEntidadesByCutmayoraUno > 1){
								String [] subEntidadesVuce = codigoSubEntidadVuce.split(",");
								for (int i = 0; i < subEntidadesVuce.length; i++){
									if(listSubEntidadesMrestri.contains(subEntidadesVuce[i])){
										codigoSubEntidad = codSubEntidadMrestri;
										codigoEntidad = codSubEntidadMrestri.substring(0,2);
										map.put("seteoEntidad",codigoSubEntidad);
										break;
									}
								}
							}
						}

						//if(CollectionUtils.isEmpty(listErrores) ){// igual que se ejecute la validacion coordinado con jose
						listErrores.addAll(validarVigenciaDRVuce(regPrecedente70, mercanciaTPN21, fechaReferencia, fechaInicioVuce, fechaFinVuce, numeroSerie, mercanciaSpn, numeroDocumentoVuce, codigoEntidad, codigoSubEntidad));
						listErrores.addAll(validarAduanaDRVuce(codigoSubEntidad, codigoAduanaVuce, codAduana, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad, numeroDocumentoVuce));
						listErrores.addAll(validarDRDeclaradoEnOtraDam(codtipDocControl, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad, numeroDocumentoVuce,numCorredocDAM, codTransaccion));
						//se reposiciona aqui por control de cambios solo para 21:
						listErrores.addAll(validarMercanciaRestringidaVuceMtc(docControlMercRestringidaVuce, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad,numeroDocumentoVuce, codRegimen));//ajuste
						//}
						listErrores.addAll(validarTitularDR(regPrecedente70, codigoEntidad, codigoSubEntidad, numeroSerie, tipoParticipante, tipoDocumConsigNumeracion, numeDocumConsigNumeracion, tipoDocumTitularVuce, numeroDocumTitularVuce, numeroDocumentoVuce, cutVuce));
					}
				}
				// validaciones de la SUCE
				if(codtipDocControl.equals("20")){
					listErrores.addAll(validarEntidadSubEntidadSUCE(codigoEntidad, codigoSubEntidad, codigoEntidadVuce, codigoSubEntidadVuce, numeroSerie, mercanciaSpn, numeroDocumentoVuce, codSubEntidadMrestri,listSubEntidadesMrestri, nroEntidadesByCutmayoraUno));//ajustes Pablito
					if((SunatStringUtils.isEmptyTrim(codigoEntidad) || SunatStringUtils.isEmptyTrim(codigoSubEntidad)) && !SunatStringUtils.isEmptyTrim(codSubEntidadMrestri)){
						if(listSubEntidadesMrestri!=null && listSubEntidadesMrestri.contains(codigoSubEntidadVuce)){
							codigoSubEntidad = codSubEntidadMrestri;
							codigoEntidad = codSubEntidadMrestri.substring(0,2);
							map.put("seteoEntidad",codigoSubEntidad);
						}
					}		
					//if(CollectionUtils.isEmpty(listErrores) ){  //igual que se ejecute  la validacion coordinado con jose
					listErrores.addAll(validarEstadoSUCE(estadoDocumentoVuce, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad, numeroDocumentoVuce, descEstadoDocumentoVuce));
					//si no cumple la validacion de estados de la SUCE, no ejecutar la validacion de vigenca SUCE P_SNADE046-2232
					if(CollectionUtils.isEmpty(listErrores) ){
						if( fechaNumerVuceDate!=null && !SunatDateUtils.isDefaultDate(fechaNumerVuceDate)){
							listErrores.addAll(validarVigenciaSUCEVuce(codAduana, fechaReferencia, fechaNumerVuceDate, numeroSerie, mercanciaSpn, codigoEntidad, codigoSubEntidad, numeroDocumentoVuce));
						}
					}
					//}
					listErrores.addAll(validarTitularSUCE(numeroDeclaracion, numeroSerie, tipoParticipante, tipoDocumConsigNumeracion, numeDocumConsigNumeracion, tipoDocumTitularVuce, numeroDocumTitularVuce, numeroDocumentoVuce));
					//no va no es una regla general de vuce es una particular ya se ejecuta en validarParticularVuce
					//listErrores.addAll(validarMercanciaRestringidaVuceMtcOtrosDocs(codtipDocControl, mercanciaSpn, numeroSerie,codigoEntidad, codigoSubEntidad));//P_SNADE046-2085 por si mandan 20
				}
			}
		}
		return listErrores;
	}

	//PROPIO DE PASE PAS20165E220200079 VUCE RECTI
	public void setearEntidadSubEntidad(String codigoEntidad, String codigoSubEntidad, String codigoSubEntidadVuce, String codSubEntidadMrestri, List<String> listSubEntidadesMrestri,Map<String, Object> map){
		if((SunatStringUtils.isEmptyTrim(codigoEntidad) || SunatStringUtils.isEmptyTrim(codigoSubEntidad)) && !SunatStringUtils.isEmptyTrim(codSubEntidadMrestri)){ 
			if(listSubEntidadesMrestri.contains(codigoSubEntidadVuce)){
				codigoSubEntidad = codSubEntidadMrestri;
				codigoEntidad = codSubEntidadMrestri.substring(0,2);
				map.put("seteoEntidad",codigoSubEntidad);
			}
		}
	}


	//PROPIO DE PASE PAS20165E220200079
	public List<Map<String,String>> validarMercanciaRestringidaVuceDonacion( Boolean tieneTratamientoDonacion,String codDocAutorizante,  String numeroSerie, String mercanciaSpn, String codigoEntidad, String codigoSubEntidad){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		//String codDocAutorizante= docAutorizante.getCodtipodocum()==null? " ":docAutorizante.getCodtipodocum().toString();

		if(tieneTratamientoDonacion){
			if((codigoSubEntidad.equals("0504") && !SunatStringUtils.isStringInList(codDocAutorizante, "01,03,07,21,99"))){
				listErrores.add(catalogoAyudaService.getError("35754", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad}));//R1613
			}
			if((codigoSubEntidad.equals("0301") && !(SunatStringUtils.isStringInList(codDocAutorizante, "01,03,08,12,16,21,99")))){
				//listErrores.add(catalogoAyudaService.getError("35724", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad}));//R1615
				listErrores.add(catalogoAyudaService.getError("37013", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,catalogoAyudaService.getDescripcionDataCatalogo("F09","35724")}));//P_SNADE046-2065
			}
			if((codigoSubEntidad.equals("0401") && !(SunatStringUtils.isStringInList(codDocAutorizante, "03,08,12,20,21,99")))){
				listErrores.add(catalogoAyudaService.getError("35729", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad}));//R1623
			}			
			if(SunatStringUtils.isStringInList(codigoSubEntidad, "0403,0406,0407") && !SunatStringUtils.isStringInList(codDocAutorizante, "02,16,17,21,99")){
				listErrores.add(catalogoAyudaService.getError("35732", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad}));//R1628
			}		
			if(SunatStringUtils.isStringInList(codigoSubEntidad, "0501,0503") && !SunatStringUtils.isStringInList(codDocAutorizante, "07,09,21,99")){
				listErrores.add(catalogoAyudaService.getError("35755", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad}));//R1608
			}	
		}
		return listErrores;	
	}		

	//PROPIO DE PASE PAS20165E220200079
	public List<Map<String,String>> validarMercanciaRestringidaVuceProduce(DatoSerie serie,String codDocAutorizante, String numeroSerie, String mercanciaSpn, String codigoEntidad, String codigoSubEntidad, String numeroDocumentoVuce){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		// String codDocAutorizante= docAutorizante.getCodtipodocum()==null? " ":docAutorizante.getCodtipodocum().toString();
		if(SunatStringUtils.isStringInList(codigoSubEntidad, "2701,2702") && !codDocAutorizante.equals("98")){
			if(!SunatStringUtils.isStringInList(codDocAutorizante, "21")){
				listErrores.add(catalogoAyudaService.getError("35734", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));//R1632
			}
		}
		if(codigoSubEntidad.equals("2701") && codDocAutorizante.equals("98")){//P_SNADE046-2134 se emocionaron
			List<DatoItem>  lstDatoItem = obtenerListDatoSerieItem(serie);
			String strDesignacion = "I012,I013,I014,I015,I065,J012,J013,J014,J015,J065,A012,A013,A014,A015,A065";
			boolean indTipo, indForma, indDescrMinima;
			for (DatoItem datoItem : lstDatoItem) {
				List<DatoDescrMinima> lstDecrMinima = datoItem.getListDecrMinima();
				indTipo =  false;
				indForma = false;
				indDescrMinima = false;
				for (DatoDescrMinima datoDescrMinima : lstDecrMinima) {
					if (datoDescrMinima.getCodtipdescr().equals(Constants.COD_EVALUAR_TIPO)) {
						//Si el item es del tipo MNR : Pilas y Baterias de Pilas
						if ( datoDescrMinima.getValtipdescri().equals("MNR") ) {
							indTipo = true;
						}
					}
					if (datoDescrMinima.getCodtipdescr().equals(Constants.COD_EVALUAR_FORMATO)) {
						//Si la forma es: CIL : Cilindrica o CUR : Cuadrada o Rectangular
						if ( SunatStringUtils.isStringInList(datoDescrMinima.getValtipdescri(), "CIL,CUR") ) {
							indForma = true;
						}
					}
					if ( SunatStringUtils.isStringInList(datoDescrMinima.getValtipdescri(), strDesignacion) ) {
						//Si la designacion esta en la lista
						if ( indTipo && indForma && SunatStringUtils.isStringInList(datoDescrMinima.getValtipdescri(), strDesignacion) ) {
							indDescrMinima = true;
						}
					}
				}
				if (indTipo && indForma && indDescrMinima ) {
					listErrores.add(catalogoAyudaService.getError("35756", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad}));//R1634
				}
			}			
		}
		return listErrores;	
	}

	//Control de cambios VUCE ahora es para los DR21:
	public List<Map<String,String>> validarMercanciaRestringidaVuceMtc(DocControlMercRestringidaVuce docControlMercRestringidaVuce, String numeroSerie, String mercanciaSpn, String codigoEntidad, String codigoSubEntidad, String numeroDocumentoVuce, String codRegimen){

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		if(codigoSubEntidad.equals("0801") && docControlMercRestringidaVuce!=null){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String cutVuce= docControlMercRestringidaVuce.getNumeroCUT()==null?" ":docControlMercRestringidaVuce.getNumeroCUT()==null?"":docControlMercRestringidaVuce.getNumeroCUT().toString();
			if(!SunatStringUtils.isEmptyTrim(cutVuce)){
				if(codRegimen.equals(Constants.REGIMEN_10) && !cutVuce.equals("79")){//aplicaci�n de la R1631 
					listErrores.add(catalogoAyudaService.getError("35733", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numeroDocumentoVuce}));//R1631 ajuste
				}
			}
		}
		return listErrores;
	}		

	public List<Map<String,String>> validarMercanciaRestringidaVuceOtrosDocs(String codDocAutorizante, String mercanciaSpn,
			String numeroSerie, String codigoEntidad,
			String codigoSubEntidad, Date fechaReferencia){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		List<Map<String, String>> listDocumentosPermitidos =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_DOCUMENTO_EXONERADA, "C", codigoSubEntidad, fechaReferencia);

		boolean tieneDocumentoPermitido = false;

		if (!CollectionUtils.isEmpty(listDocumentosPermitidos)){
			for (Map<String, String> documentoPermitido : listDocumentosPermitidos){
				if(codDocAutorizante.equals(MapUtils.getString(documentoPermitido, "cod_datacat", ""))){
					tieneDocumentoPermitido = true;
					break;
				}
			}
		}

		if(!tieneDocumentoPermitido){
			List<Map<String, String>> mensajeDeError =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
					.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_SUBENTIDAD_CODIGOERROR_EXONERADA, "C", codigoSubEntidad, fechaReferencia);
			if (!CollectionUtils.isEmpty(mensajeDeError)){
				//dependiendo de la subentidad se muestra mensaje de error
				listErrores.add(catalogoAyudaService.getError(MapUtils.getString(mensajeDeError.get(0), "cod_datacat", ""), new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,codDocAutorizante}));
			}
		}
		return listErrores;
	}

	//Control de cambios VUCE
	public List<Map<String,String>> validarMercanciaRestringidaVuceMtcOtrosDocs(String codDocAutorizante,  String mercanciaSpn, String numeroSerie, String codigoEntidad,String codigoSubEntidad){

		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		if( codigoSubEntidad.equals("0801") && (!codDocAutorizante.equals("03") && !codDocAutorizante.equals("21")) ){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			listErrores.add(catalogoAyudaService.getError("37012", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,codDocAutorizante}));
		}
		return listErrores;
	}		

	//PROPIO DE PASE PAS20165E2202000794
	public List<Map<String,String>> validarMercanciaRestringidaVuceDigesa (Boolean tieneTratamientoDonacion, DatoDocAutorizante docAutorizante, String numeroSerie, String mercanciaSpn, String codigoEntidad, String codigoSubEntidad){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();

		if(SunatStringUtils.isStringInList(codigoSubEntidad, "0401") && !tieneTratamientoDonacion){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String codDocAutorizante= docAutorizante.getCodtipodocum()==null? " ":docAutorizante.getCodtipodocum().toString();
			if(!SunatStringUtils.isStringInList(codDocAutorizante, "20,21")){
				String numDocControl=docAutorizante.getNumdocum()==null?"":docAutorizante.getNumdocum().toString();
				listErrores.add(catalogoAyudaService.getError("35730", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad,numDocControl}));//R1622
			}
		}
		return listErrores;
	}



	//PROPIO DE PASE PAS20165E220200079
	public List<Map<String,String>> validarMercanciaRestringidaVuceDigemid(String codAduana, String numeroSerie, String mercanciaSpn, String codigoEntidad, String codigoSubEntidad){
		List<Map<String,String>> listErrores = new ArrayList<Map<String,String>>();
		if(SunatStringUtils.isStringInList(codigoSubEntidad, "0302")){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			if(!SunatStringUtils.isStringInList(codAduana, "118,235")){
				listErrores.add(catalogoAyudaService.getError("35726", new String []{numeroSerie,mercanciaSpn,codigoEntidad,codigoSubEntidad}));//R1618
			}
		}
		return listErrores;
	}		


	//Vuce Rectificacion - PAS20165E220200079 - Fin	
	
	//PAS20181U220200049
	/**
	 * SE DEJA EL CODIGO PERO NO SE ESTA REGISTRANDO EL SERVICIO EN EL ORQUESTADOR - VER ESTO EN EL PASE QUE VALIDAR DIFERIDOS
	 * @param declaracion
	 * @param fechaReferencia
	 * @param variablesIngreso
	 */
	@Override
	@ServicioAnnot(tipo="V",codServicio=2549, descServicio="Valida IQBF sin Ica y Diferida")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=2549,numSecEjec=31,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public Map<String, String> validaSinICAIqbfDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso){
		DUA dua = declaracion.getDua();
		Boolean isDAMDiferidaSinIca = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
		Manifiesto manifiesto = variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca")!=null?(Manifiesto)variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca"):null;
		String viaTransporte = variablesIngreso.get("viaTransp")!=null?variablesIngreso.get("viaTransp").toString():"0";
		boolean flag= false;
		Date fechaReferencia = SunatDateUtils.getCurrentDate();
		String documentoTransporte=" ";
		if(ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equalsIgnoreCase(viaTransporte)) {
			if(isDAMDiferidaSinIca && manifiesto != null){
				Elementos<DatoDocTransporte> listaDocumentos = dua.getListDocTransporte();
				for (DatoSerie serie:dua.getListSeries()){
					List<MRestri> lstMrestri = obtenerListaMercRestringida(serie, fechaReferencia, variablesIngreso); 
					List<DatoDocAutorizante> lstDocAutoriza = obtenerListaDocAutorizaSerie(serie,(DUA) serie.getPadre(),variablesIngreso,false);  
					for (MRestri itemMRestri : lstMrestri){
						for (DatoDocAutorizante docAutoriza : lstDocAutoriza){
							//si corresponde iqbf y se transmite iqbf
							if (docAutoriza.getCodsubentidad().equals(itemMRestri.getRegistro())){
								if(itemMRestri.getEntidad().equalsIgnoreCase(Constants.COD_ENTIDAD_DOCAUT_IQBF) && 
								  (itemMRestri.getRegistro().equalsIgnoreCase(Constants.COD_SUBENTIDAD_DOCAUT_IQBF)|| 
										  itemMRestri.getRegistro().equalsIgnoreCase(Constants.COD_SUBENTIDAD_DOCAUT_IQBF_MINERIA))) {
									for(DatoDocTransporte documento:listaDocumentos){
										Elementos<DatoSerieDocSoporte> listaDocumentosSerie = serie.getListSerieDocSoporte();
										for(DatoSerieDocSoporte documentoSerie:listaDocumentosSerie){
											if(documentoSerie.getCodtipodocsoporte().equalsIgnoreCase("2")) {
												if(documentoSerie.getNumiddocsoporte().equals(documento.getNumsecdoctrans())) {
													documentoTransporte = documento.getNumdoctransporte().toString();
													break;
												}								
											}
										}
									}
									flag=true;
									break;
								}
							}
						}
					}				
				}
			}
		}
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(flag) {
			return catalogoAyudaService.getError("70152", new String []{documentoTransporte});
			//Declaraci�n presenta IQBF, Documento de Transporte {0} debe contar con ICA 
		}
		return new HashMap<String,String>();
	}	
}

