package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.pilas;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.pilas.model.Pila;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValidadorPila extends ValidadorAbstract{

	private static final String CATALOGO_UNID_COMER_PILAS = "567";
	public static final String COD_ASOC_CATA = "023";
	public static final String TIPO_VALOR_ZZZ = "1";
	public static final String COD_OTR = "OTR";
	
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception{

	List<ErrorDescrMinima> lstErrores =validarEstructura(objeto);
      if (CollectionUtils.isEmpty(lstErrores)){
          lstErrores.addAll(validarUnidadComercial(objeto, dua));
          lstErrores.addAll(validarNombreComercial(objeto));
          lstErrores.addAll(validarMarcaComercial(objeto));
          lstErrores.addAll(validarModelo(objeto));
          lstErrores.addAll(validarTipo(objeto));
          lstErrores.addAll(validarFormato(objeto));
          lstErrores.addAll(validarDesignacion(objeto));
          lstErrores.addAll(validarVoltaje(objeto));
          lstErrores.addAll(validarCorrelacionTipoYFormaConSubPartida(objeto,dua));
      }

 	return lstErrores;
  }
  
  public List<ErrorDescrMinima>  validarUnidadComercial(ModelAbstract objeto, Declaracion dua){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  Pila pila = (Pila) objeto;
	  String datoAValidar = obtenerItem(objeto,dua).getCodunidcomer().trim();
	  //rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
	  Map<String,Object> variablesIngreso = objeto.getMapCatalogos();
	  if(noestaEnSubGrupoCatalogo(CATALOGO_UNID_COMER_PILAS,datoAValidar,variablesIngreso)){
		  Object[] demasArgumentosMSJError = new Object[] { pila.getNumsecprove(),pila.getNumsecfact(),
		  pila.getNumsecitem(),"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
		  ErrorDescrMinima error = obtenerError("31787",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);	   	  
		  lstErroresDescrMin.add(error); 	   	  
	  }
	  return lstErroresDescrMin;		  
	}
  
  public List<ErrorDescrMinima>  validarNombreComercial(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  Pila pila = (Pila) objeto;
	  String datoAValidar;
	  if(pila.getNombreComercial() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = pila.getNombreComercial().getValtipdescri().trim();  
	  //RIN13 SWF INICIO
	  if(!("PILAS".equalsIgnoreCase(datoAValidar) || "BATERIA DE PILAS".equalsIgnoreCase(datoAValidar) || "BATERIAS DE PILAS".equalsIgnoreCase(datoAValidar) || "BATER�A DE PILAS".equalsIgnoreCase(datoAValidar)  || "BATER�AS DE PILAS".equalsIgnoreCase(datoAValidar))){
	  //RIN13 SWF FIN 
	   	  ErrorDescrMinima error = obtenerError("31788", pila.getNombreComercial());
	   	  lstErroresDescrMin.add(error);		  
	  }
	  return lstErroresDescrMin;
  	}
  public List<ErrorDescrMinima>  validarMarcaComercial(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
  	}
  public List<ErrorDescrMinima>  validarModelo(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
  	}
  public List<ErrorDescrMinima>  validarTipo(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
  	}  
  public List<ErrorDescrMinima>  validarFormato(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
  	}
  public List<ErrorDescrMinima>  validarDesignacion(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
  	}
  public List<ErrorDescrMinima>  validarVoltaje(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
  	}

  public List<ErrorDescrMinima>  validarCorrelacionTipoYFormaConSubPartida(ModelAbstract objeto, Declaracion dua){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  DatoItem item = obtenerItem(objeto, dua);
	  Pila pila = (Pila) objeto;
	  String forma,tipo,forma1,tipo1;
	  if(pila.getTipo() == null)
		  tipo1 = "";
	  else
		  tipo1 = pila.getTipo().getValtipdescri().trim();	  
	  if(pila.getFormato() == null)
		  forma1 = "";
	  else
		  forma1 = pila.getFormato().getValtipdescri().trim();
	  tipo = tipo1;
	  forma = forma1;
      if (TIPO_VALOR_ZZZ.equals(pila.getTipo().getCodtipvalor()) && !SunatStringUtils.isEmpty(tipo1)){
    	  tipo1 = COD_OTR;
      }	  
      if (TIPO_VALOR_ZZZ.equals(pila.getFormato().getCodtipvalor()) && !SunatStringUtils.isEmpty(forma1)){
    	  forma1 = COD_OTR;
      }	  
      String datoAValidar = tipo1.concat(forma1);
      String subPartida = item.getNumpartnandi().toString();
      if(noEstaCorrelacionado(datoAValidar, subPartida, COD_ASOC_CATA,  dua.getDua().getFecdeclaracion())){
    	  Object[] argumentosMSJError = new Object[] {subPartida,tipo,forma};
    	  ErrorDescrMinima error = obtenerError("31789", pila.getNombreComercial(), argumentosMSJError);
    	  lstErroresDescrMin.add(error);
      	}
	  return lstErroresDescrMin;
  }  
}