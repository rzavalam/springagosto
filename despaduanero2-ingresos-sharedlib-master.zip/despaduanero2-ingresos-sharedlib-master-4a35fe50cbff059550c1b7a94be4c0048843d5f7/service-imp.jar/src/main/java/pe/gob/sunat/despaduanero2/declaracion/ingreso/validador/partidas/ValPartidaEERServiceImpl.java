package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.partidas;

import java.math.BigDecimal;
import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;

public class ValPartidaEERServiceImpl  extends IngresoAbstractServiceImpl implements ValPartidaEERService {
	
	protected final Log logPartidaEER = LogFactory.getLog(getClass());
	
	//private ValPrecedenteEERServiceImpl valPrecedenteEER;
	
	public List<Map<String,String>> valPartidasCategoria02(DatoSerie datoSerie, String codCategoria) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		if (ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_02.equals(codCategoria)) {
			Long partida = datoSerie.getNumpartnandi();
			Long partida20 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_20);
			// hsaenz PAS20181U220400008: Se cambia porque partida ya no es obligatorio
			if (!partida20.equals(partida)) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70117",
						new String[] { datoSerie.getNumserie().toString() }));
			}
		}
		
		   /*
		      Si codCategoria es igual a '02' 
		      obtener la partida  partida = datoSerie.getNumpartnandi();
		      validad que la partida sea igual a '9809000020' (este valor debe ser una constante) caso contrario emitir el mensaje E25
		      Para el mensaje del error enviar el numero de serie: datoSerie.getNumserie()
		   */
		return listError;
	}
	
	public List<Map<String,String>> valPartidasCategoria03(Declaracion declaracion, String codCategoria, String tipoRegimenPrecendeteSeries) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		if (ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(codCategoria)) {
			Boolean esReimportacion = false;
			
			if(tipoRegimenPrecendeteSeries != null  && Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenPrecendeteSeries))
				esReimportacion = true;
			
			Long partida30 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_30);
			Long partida40 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_40);
			if (!esReimportacion) {
				Boolean esPartida30 = false;
				Boolean esPartida40 = false;				
				for(DatoSerie serieTmp : declaracion.getDua().getListSeries()){
					// hsaenz PAS20181U220400008: Se cambia porque partida ya no es obligatorio
					if(!( partida30.equals(serieTmp.getNumpartnandi()) || partida40.equals(serieTmp.getNumpartnandi()) )) {
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70118"));
						break;
					}
					
					//i: lfloresr : se cambia valida que en todos sus series solo tenga 9809000030 O SOLO SPN 9809000040.
					//BUG P_SNAA0004-9635
					if(partida30.equals(serieTmp.getNumpartnandi()))
						esPartida30 = true;
					
					if(partida40.equals(serieTmp.getNumpartnandi()))						
						esPartida40 = true;					
					
					if (esPartida30 && esPartida40){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70118"));
						break;
					}
					//f: lfloresr
				}
			} 
			//else {
				// hsaenz PAS20181U220400008 - P_SNAA0004-9424: Se corrige bug para las DS de reimportacion cuando son SPN 30 o 40
				//for(DatoSerie serieTmp : declaracion.getDua().getListSeries()){
					//if((partida30.equals(serieTmp.getNumpartnandi()) || partida40.equals(serieTmp.getNumpartnandi()))) {
						//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70182"));
					//}
					// hsaenz PAS20181U220400008 - P_SNAA0004-9559 - P_SNAA0004-9540: Se corrige bug para que se muestre mensaje de error cuando se transmite SPN
					//																	para reimportacion
					//if (serieTmp.getNumpartnandi()) {
						
					//}
			//	}
			//}
		}
		      /*
		      Si codCategoria="03" entonces
		         listaSeries = declaracion.getListSeries()
		         obtenemos la primera serie
		         Serie = listaSeries.get(0);
		         listRegPrecedencia = Serie.listRegPrecedencia()
		         Obtenemos solo la primera dam de precedencia, en EER solo tiene una
		         damPrecedencia = listRegPrecedencia.get(0)
		         codRegimen = damPrecedencia.getCodregipre()
		         codiAduan = damPrecedencia.getCodaduapre()
		         anoPrese = damPrecedencia.getAnndeclpre()
		         numeCorre = damPrecedencia.getNumdeclpre()
		         numeSerie = damPrecedencia.getNumserie()
		         
		         Si pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes.ValPrecedenteEERServiceImpl.esReimportacion(codRegimen,codiAduan,anoPrese,numeCorre,numeSerie) no es verdadero
		            si Serie.getNumpartnandi() no es igual a  9809000030  o no es igual a 9809000040 
		               emitir el mensaje E30
		      */
		return listError;
	}
	
	public List<Map<String,String>> valPartidas30Categoria03(Declaracion declaracion, String codCategoria, String tipoRegimenPrecendeteSeries) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		Boolean todosSonPartidas30 = false;
		
		if (ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(codCategoria)) {
			
			Elementos<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
			
			Boolean esReimportacion = false;
			
			if(!lstSeries.get(0).getListRegPrecedencia().isEmpty()){
				
				if(tipoRegimenPrecendeteSeries != null  && Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenPrecendeteSeries))
					esReimportacion = true;
			}
			
			if (!CollectionUtils.isEmpty(lstSeries) && !esReimportacion) {
				for (DatoSerie serie : lstSeries) {
					Long partida30 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_30);
					if (partida30.equals(serie.getNumpartnandi())) {
						todosSonPartidas30 = true;
					} else {
						todosSonPartidas30 = false;
						break;
					}
				}
				
				if (todosSonPartidas30) {
					BigDecimal fob = declaracion.getDua().getMtotfobclvta();
					BigDecimal dolares2000 = new BigDecimal("2000.00");
					if (!(fob.compareTo(BigDecimal.ZERO) > 0 && (fob.compareTo(dolares2000) < 0 || fob.compareTo(dolares2000)==0))){
						//E27
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70119"));
					}
				}
			}
		}
		
		      /*
		      declaramos un flag todosSonPartidas30 en falso
		      si codCategoria = "03"
		         listSeries = declaracion.detDUA.getListSeries();
		         recorrer listSeries
		            Por cada Serie obtenemos sus precedentes listPrecedentes = Serie.getListRegPrecedencia()
		            obtenemos un solo precedente precedente = listPrecedentes.get(0)
		            Si Serie.getPartNandi() es igual a 9809000030  y no es esReimportacion(codRegimen,codiAduan,anoPrese,numeCorre,numeSerie) los parametros son obtenidos del precedente
		               todosSonPartidas30 es verdadero
		            Sino
		               todosSonPartidas30 es falso
		               salimos del bucle
		               
		         Si todosSonPartidas30 es verdadero
		            fob = declaracion.getDUA().getMtotfobclvta()
		            validar que fob se mayor a 0 y menor o igual a 200 dolares, en caso contrario emitir el mensaje E27      
		            
		      */
		return listError;
	}
	
	public List<Map<String,String>> valPartidas40Categoria03(Declaracion declaracion, String codCategoria, String tipoRegimenPrecendeteSeries) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		Boolean todosSonPartidas40 = false;
		
		if (ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_03.equals(codCategoria)) {
			Elementos<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
			Boolean esReimportacion = false;
			if(!lstSeries.get(0).getListRegPrecedencia().isEmpty()){
				if(tipoRegimenPrecendeteSeries != null && Constantes.COD_REGIMEN_PRECEDENTE_EXPORTACION.equals(tipoRegimenPrecendeteSeries))
					esReimportacion = true;
			}
			if (!CollectionUtils.isEmpty(lstSeries) && !esReimportacion) {
				for (DatoSerie serie : lstSeries) {
					Long partida40 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_40);
					if (partida40.equals(serie.getNumpartnandi())) {
						todosSonPartidas40 = true;
					} else {
						todosSonPartidas40 = false;
						break;
					}
				}
				
				if (todosSonPartidas40) {
					BigDecimal fob = declaracion.getDua().getMtotfobclvta();
					BigDecimal dolares10000 = new BigDecimal("10000.00");
					if (!(fob.compareTo(BigDecimal.ZERO) > 0 && fob.compareTo(dolares10000) < 1)){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70120"));
					}
				}
			}
		}
		
	      /*
	      declaramos un flag todosSonPartidas40 en falso
	      si codCategoria = "03"
	         listSeries = declaracion.detDUA.getListSeries();
	         recorrer listSeries
	            Por cada Serie obtenemos sus precedentes listPrecedentes = Serie.getListRegPrecedencia()
	            obtenemos un solo precedente precedente = listPrecedentes.get(0)
	            Si Serie.getPartNandi() es igual a 9809000040  y no es esReimportacion(codRegimen,codiAduan,anoPrese,numeCorre,numeSerie) los parametros son obtenidos del precedente
	               todosSonPartidas40 es verdadero
	            Sino
	               todosSonPartidas40 es falso
	               salimos del bucle
	               
	         Si todosSonPartidas40 es verdadero
	            fob = declaracion.getDUA().getMtotfobclvta()
	            validar que fob se mayor a 0 y menor o igual a 1000 dolares, en caso contrario emitir el mensaje E28      
	            
	      */
		return listError;
	}
	
	public List<Map<String,String>> valTipoDocumentoPartidas40(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		// hsaenz PAS20181U220400008 - P_SNAA0004-9387: Se corrige bug para que busque para todas las series. Se comenta codigo anterior
		//DatoSerie serie = declaracion.getDua().getListSeries().get(0);
		Elementos<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
		Long partida40 = Long.parseLong(ConstantesAtributo.PARTIDA_EER_40);
		
		// hsaenz PAS20181U220400008 - P_SNAA0004-9387: Se recorren las series 
		if (!CollectionUtils.isEmpty(lstSeries)) {
			for (DatoSerie serie : lstSeries) {
				if (partida40.equals(serie.getNumpartnandi())) {
					if(!SunatStringUtils.include(declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat(), 
							new String[]{ ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI,
										  ConstantesDataCatalogo.TIPO_DOCUMENTO_PASAPORTE,
										  ConstantesDataCatalogo.TIPO_DOCUMENTO_CARNET_EXTRANJERIA,
										  ConstantesDataCatalogo.TIPO_DOCUMENTO_SALVOCONDUCTO
							})) {
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70121"));
					}
				}
			}
		}
				
		   /*
		      obtener la serie
		      serie = declaracion.getDUA().getListSeries().get(0)
		      Obtenemos la partida de la serie
		      partida = serie.getNumpartnandi()
		      si partida es igual 9809000040  entonces
		         Verificamos el valor del tipo de documento sea DNI, Pasaporte, carnet de extranjeria o Salvoconducto
		         tipoDocumento = 
		         declarante.tipoDocumentoIdentidad.codDatacat es diferente a 3,6,7,9 (cod_catalogo:27)
		            Emitir mensaje E33
		   */
		return listError;
	}
}
