/*
 * Clase que define el servicio de validaciones complejas de las series de la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.dao.OperadorComexDAO;
import pe.gob.sunat.despaduanero.catalogo.tg.service.CodiLibeDAOService;
import pe.gob.sunat.despaduanero2.ayudas.model.Cambio1;
import pe.gob.sunat.despaduanero2.ayudas.model.NandUni;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageGeneral;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageTD;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCertificadoOrigen;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ExpodumpDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IscfactoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IscvalorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PrupersoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TasadumpDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;

/**
 * The Class ValNegocAduadet1FormA. Clase que define el servicio de validaciones complejas de las series de la DUA.
 */
public class ValNegocAduadet1FormAServiceImpl extends ValDuaAbstract implements ValNegocAduadet1FormA{

	//private AyudaService ayudaService;
	//private FabricaDeServicios fabricaDeServicios;
	//private CodiLibeDAOService codiLibeDAOService;
	//private PackageTD packageTD;
	// rpumacayo pase70
	//private CatalogoAyudaService catalogoAyudaService;

	//glazaror... optimizacion
	private Map<String, Object> cargarInformacionParaValidaciones(DUA dua, Declaracion declaracion, List<DatoSerie> series, Integer fechaIngreso, boolean vigenciaISC) {
		//glazaror... inicio carga info de puertos por documento de transporte... en una sola llamada...
		//glazaror... se adiciona tambien las partidas distintas en la dua
		//glazaror... se adiciona tambien las partidas y tasas a aplicar distintas en la dua

		//Integer fechaActualAsInteger = new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")); //PAS20165E220200103
		Integer fechaActualAsInteger = fechaIngreso; //PAS20165E220200103
		List<String> puertos = new ArrayList<String>();
		List<Long> partidas = new ArrayList<Long>();
		List<String> partidasTasas = new ArrayList<String>();
		List<String> partidasPaisOrigen = new ArrayList<String>();
		List<String> partidasPaisOrigenTasaDump = new ArrayList<String>();
		StringBuilder partidasBuilder = new StringBuilder();
		StringBuilder partidasTasasBuilder = new StringBuilder();
		StringBuilder partidasPaisOrigenBuilder = new StringBuilder();
		StringBuilder partidasPaisOrigenTasaDumpBuilder = new StringBuilder();

		for(DatoSerie serie : series) {
			//logica para concatenar puertos distintos
			DatoDocTransporte docTransp = getDocTransporte(dua, serie);
			if (docTransp != null){
				String puer_embar = docTransp.getCodpuerto();
				if (!puertos.contains(puer_embar)) {
					puertos.add(puer_embar);
				}
			}
			//logica para cargar partidas distintas
			Long partida = serie.getNumpartnandi();
			if (!partidas.contains(partida)) {
				partidas.add(partida);
				partidasBuilder.append(partida).append(",");
			}
			//logica para cargar partidas y tasas distintas
			String tnan = (serie.getCodtnan() != null) ? serie.getCodtnan() : "";
			String partidaTasa = StringUtils.leftPad(tnan, 2) + StringUtils.leftPad(serie.getNumpartnandi().toString(), 10);
			if (!partidasTasas.contains(partidaTasa)) {
				partidasTasasBuilder.append(partidaTasa).append(",");
				partidasTasas.add(partidaTasa);
			}

			//logica para cargar partidas y pais origen
			String partidaYPaisOrigen = StringUtils.leftPad(partida.toString(), 10, " ") + StringUtils.leftPad(serie.getCodpaisorige(), 2, " ");
			if (!partidasPaisOrigen.contains(partidaYPaisOrigen)) {
				partidasPaisOrigenBuilder.append(partidaYPaisOrigen).append(",");
				partidasPaisOrigen.add(partidaYPaisOrigen);
			}

			//logica para cargar informacion de tasadump
			if (!partidasPaisOrigenTasaDump.contains(partidaYPaisOrigen)) {
				DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
				if (documentoTransporte != null) {
					Date fechaEmbarque = documentoTransporte.getFecembarque();
					if (!partida.equals(8708701000L) || (fechaEmbarque.compareTo((new FechaBean("08/02/2001")).getCalendar().getTime())>0 && partida.equals(8708701000L))) {
						partidasPaisOrigenTasaDumpBuilder.append(partidaYPaisOrigen).append(",");
						partidasPaisOrigenTasaDump.add(partidaYPaisOrigen);
					}
				}
			}
		}
		//ejecutamos una unica invocacion rest para obtener la informacion de puertos
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		Map<String, Integer> resultadoCountInPuertos = packageTD.getCountInPuertos(puertos);
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		//ejecutamos una unica consulta para obtener informacion de las partidas
		Map<Long, List<NandUni>> nanduniMap = new HashMap<Long, List<NandUni>>();
		if (partidasBuilder.length() > 0) {
			//rtineo mejoras PAS20155E220000396
			List<String> listCadenaPartidas = GeneralUtils.obtenerListCadenas(partidasBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
			List<NandUni> listNanduni = new ArrayList<NandUni>();
			for(String cadenaPartidas:listCadenaPartidas){
				HashMap<String, Object> params=new HashMap<String, Object>();
				params.put("PARTIDAS_LIST", cadenaPartidas);
				params.put("finivig", fechaActualAsInteger);
				params.put("ffinvig", fechaActualAsInteger);
				listNanduni.addAll(ayudaService.findNanduniByParams(params));
			}

			//agrupamos por partida
			for (NandUni nandUni : listNanduni) {
				List<NandUni> nanduniByPartida = nanduniMap.get(nandUni.getCnan());
				if (nanduniByPartida == null) {
					nanduniByPartida = new ArrayList<NandUni>();
					nanduniMap.put(nandUni.getCnan(), nanduniByPartida);
				}
				nanduniByPartida.add(nandUni);
			}
		}
		//glazaror... fin carga info de puertos por documento de transporte... en una sola llamada

		//glazaror... ejecutamos una unica consulta sobre tabla nandtasa
		Map<String, Map<String, Object>> tasaPartidasMap = new HashMap<String, Map<String, Object>>();
		if (partidasTasasBuilder.length() > 0) {
			partidasTasasBuilder.deleteCharAt(partidasTasasBuilder.length() - 1);
			HashMap<String,Object> paramsNandtasa = new HashMap<String,Object>();
			paramsNandtasa.put("PARTIDA_TASA_LIST", partidasTasasBuilder.toString());
			paramsNandtasa.put("finitas", fechaIngreso);
			paramsNandtasa.put("ffintas", fechaIngreso);
			tasaPartidasMap = ((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).countByTnanCnan(paramsNandtasa);
		}
		//glazaror consulta unica sobre tabla nandtasa

		//glazaror inicio prueba CatRefpartidas tipo uso LIC
		Map<String, Map<String, Object>> catalogoReferenciaPartidaLIC = new HashMap<String, Map<String, Object>>();
		if(vigenciaISC && declaracion.getDua().getCodregimen().equals("10")) {
			//rtineo mejoras PAS20155E220000396
			List<String> listPartidasBuilder = GeneralUtils.obtenerListCadenas(partidasBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
			for(String cadenaPartidasTmp: listPartidasBuilder){
				// vemos si esta vigente en la tabla CAT_REFPARTIDAS
				Map<String,Object> paramsCatRef = new HashMap<String,Object>();
				paramsCatRef.put("tipo_uso", "LIC");
				paramsCatRef.put("NUM_PARTIDA_LIST", cadenaPartidasTmp);
				paramsCatRef.put("fechaVigencia", fechaActualAsInteger); 				
				paramsCatRef.put("ayudaID", "CatRefpartidas");
				catalogoReferenciaPartidaLIC.putAll((Map<String, Map<String, Object>>) ayudaService.groupCatRefParidas(paramsCatRef));
			}
		}
		//glazaror fin prueba CatRefpartidas tipo uso LIC


		//glazaror inicio unico query sobre CatRefpartidas tipo uso SAV
		Map<String, Map<String, Object>> catalogoReferenciaPartidaSAV = new HashMap<String, Map<String, Object>>();
		if (partidasPaisOrigenBuilder.length() > 0) {
			//rtineo mejoras PAS20155E220000396
			List<String> listCadenaPartidasPaisOrigen = GeneralUtils.obtenerListCadenas(partidasPaisOrigenBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
			for(String tmpPartidasPaisOrigenString:listCadenaPartidasPaisOrigen){
				Map<String,Object> paramsCatRef = new HashMap<String,Object>();
				paramsCatRef.put("tipo_uso", "SAV");
				paramsCatRef.put("NUM_PARTIDA_PAIS_LIST", tmpPartidasPaisOrigenString);
				paramsCatRef.put("fechaVigencia", fechaActualAsInteger);
				paramsCatRef.put("ayudaID", "CatRefpartidas");
				catalogoReferenciaPartidaSAV.putAll((Map<String, Map<String, Object>>)ayudaService.groupCatRefParidas(paramsCatRef));
			}
		}
		//glazaror fin unico query sobre CatRefpartidas tipo uso SAV


		//glazaror.... inicio unico query sobre nandtasa 2do caso
		//NandTasa998
		Map<String, Map<String, Object>> nandTasa998Map = new HashMap<String, Map<String, Object>>();
		//rtineo mejoras PAS20155E220000396
		if(partidasTasasBuilder.length()>0){
			List<String> listCadenaPartidasTasasBuilder1 = GeneralUtils.obtenerListCadenas(partidasTasasBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
			for(String cadenaPartidasTasas1 : listCadenaPartidasTasasBuilder1){
				HashMap<String,Object> paramsNandTasa998 = new HashMap<String,Object>();
				paramsNandTasa998.put("PARTIDA_TASA_LIST", cadenaPartidasTasas1);
				paramsNandTasa998.put("finitas", fechaIngreso);
				paramsNandTasa998.put("ffintas", fechaIngreso);
				paramsNandTasa998.put("visc", 998);
				nandTasa998Map = ((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).countByTnanCnan(paramsNandTasa998);
			}
		}
		//glazaror.... fin unico query sobre nandtasa 2do caso


		//glazaror... inicio ejecutamos un solo query en tasadump
		Map<String, Map<String, Object>> tasaDumpMap = new HashMap<String, Map<String, Object>>();
		if (partidasPaisOrigenTasaDumpBuilder.length() > 0) {
			//rtineo mejoras PAS20155E220000396
			List<String> listCadenaPaisOrigenTasaDump = GeneralUtils.obtenerListCadenas(partidasPaisOrigenBuilder.toString(), 4000); //tama�o maximo que soporta el oracle() varchar2
			for(String cadenaPaisOrigenTasaDump:listCadenaPaisOrigenTasaDump){
				Map<String,Object> parametrosTasadump = new HashMap<String,Object>();
				parametrosTasadump.put("NUM_PARTIDA_PAIS_LIST", cadenaPaisOrigenTasaDump);
				parametrosTasadump.put("fechavigencia", fechaActualAsInteger);
				TasadumpDAO tasadumpDAO=((TasadumpDAO)fabricaDeServicios.getService("tasadumpDAO"));
				tasaDumpMap.putAll(tasadumpDAO.group(parametrosTasadump));
			}
		}
		//glazaror... fin ejecutamos un solo query en tasadump


		//por ultimo salvamos en un mapa la informacion
		Map<String, Object> informacion = new HashMap<String, Object>();
		informacion.put("resultadoCountInPuertos", resultadoCountInPuertos);
		informacion.put("nanduniMap", nanduniMap);
		informacion.put("tasaPartidasMap", tasaPartidasMap);
		informacion.put("catalogoReferenciaPartidaLIC", catalogoReferenciaPartidaLIC);
		informacion.put("catalogoReferenciaPartidaSAV", catalogoReferenciaPartidaSAV);
		informacion.put("nandTasa998Map", nandTasa998Map);
		informacion.put("tasaDumpMap", tasaDumpMap);

		return informacion;
	}

	// rpumacayo pase70
	/**
	 * Valida las series de la DUA.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de mapas de error.
	 */
	public List<Map<String,String>> valAduadet(Declaracion declaracion){
		DUA dua=declaracion.getDua();
		String pcdurge=dua.getCodprodurgente();
		Participante declarante=dua.getDeclarante();
		Elementos<DatoSerie> series=dua.getListSeries();
		DatoCertificadoOrigen datoCertOrig=dua.getDatoCertificadoOrigen();
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		String vaduana=declaracion.getCodaduana();

		String cert_orige=null;
		//Date fcert_ori=null;
		String nume_ffco=null;
		//DZC ISC INI: Valida la vigencia de cambio para ISC Licores
		
		List<DatoIndicadores> lista=new ArrayList<DatoIndicadores>(); 
		boolean isDAMDiferidaSinIca=false;

		/*Inicio PAS20181U220200064 se debe traer de aca*/
		ValCabdua valCabduaService =  (ValCabdua)fabricaDeServicios.getService("ValCabdua");
	    Map<String,Object> mapResultado = valCabduaService.isDAMDiferidaSinICA(dua);
	    if((Boolean)mapResultado.get("flag")){
	    	isDAMDiferidaSinIca = true;
	    }
	    /*Fin PAS20181U220200064*/
	    
		//se coordin� con Eduardo que este indicador no corresponde, actualmente no se maneja en producci�n este indicador
		//PAS20181U220200064
		/*if(!CollectionUtils.isEmpty(dua.getListIndicadores())){
			for(DatoIndicadores indicador:dua.getListIndicadores()){
				if(indicador.getCodtipoindica() != null   //CSANTILLAN PAS20181U220200004
						&& indicador.getCodtipoindica().equals("54") ){
					//P46  inicio EJHM
					if(indicador.getIndicadorActivo()!=null && indicador.getIndicadorActivo().equals("01")){
						isDAMDiferidaSinIca=true;	
					}
				}
			}
		}*/
		
		
		boolean VigenciaISC=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000413", SunatDateUtils.getCurrentDate())>0;
		//DZC ISC FIN
		//ESM: 24/04/2012
		//La fecha de validacion de la partida debe ser el de la numeraci�n
		Integer fechaIngreso=null;
		//Si fec declaraci�n es null es numeraci�n
		if(declaracion.getDua().getFecdeclaracion()==null){
			fechaIngreso = SunatDateUtils.getCurrentIntegerDate();
		} else {
			fechaIngreso = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
		}
		if( ! CollectionUtils.isEmpty( datoCertOrig.getListAutocertificacion() ) )
		{
			List<DatoAutocertificacion> listAutocertificacion=datoCertOrig.getListAutocertificacion();
			DatoAutocertificacion autocert=listAutocertificacion.get(0);
			cert_orige=autocert.getNumdocumento();
			//fcert_ori=autocert.getFecemision();
			nume_ffco=autocert.getCodffco();			
		}
		//SPTD_ADUADET1 20-23
		//		if (!SunatStringUtils.isEmptyTrim(cert_orige) && fcert_ori!=null){
		//			FechaBean fbCertOri=new FechaBean();
		//			fbCertOri.setFecha(fcert_ori);
		//			listError.add(getDUAError("5041","Series. FCERT_ORI - ENVIADO: "+(fcert_ori==null?fcert_ori:fbCertOri.getFormatDate("dd/MM/yyyy"))));
		//		}

		//INICIO PAS20144E620000100 - cpuente
		//vigencia de PSF para regimen 10
		boolean estaVigentePSF10= PackageGeneral.getVigenciaCambio("983", "10", "PSF10", "001078", SunatDateUtils.getCurrentDate())>0;
		//FIN 

		//glazaror... cargamos la informacion de forma optimizada para realizar las validaciones posteriores... la logica de carga de informacion fue separada para mejorar la mantenibilidad
		Map<String, Object> informacionParaValidaciones = cargarInformacionParaValidaciones(dua, declaracion, series, fechaIngreso, VigenciaISC);
		//glazaror... obtenemos los datos
		Map<String, Integer> resultadoCountInPuertos = (Map<String, Integer>) informacionParaValidaciones.get("resultadoCountInPuertos");  
		Map<Long, List<NandUni>> nanduniMap = (Map<Long, List<NandUni>>) informacionParaValidaciones.get("nanduniMap");
		Map<String, Map<String, Object>> tasaPartidasMap = (Map<String, Map<String, Object>>) informacionParaValidaciones.get("tasaPartidasMap");
		Map<String, Map<String, Object>> catalogoReferenciaPartidaLIC = (Map<String, Map<String, Object>>) informacionParaValidaciones.get("catalogoReferenciaPartidaLIC");
		Map<String, Map<String, Object>> catalogoReferenciaPartidaSAV = (Map<String, Map<String, Object>>) informacionParaValidaciones.get("catalogoReferenciaPartidaSAV");
		Map<String, Map<String, Object>> nandTasa998Map = (Map<String, Map<String, Object>>) informacionParaValidaciones.get("nandTasa998Map");
		Map<String, Map<String, Object>> tasaDumpMap = (Map<String, Map<String, Object>>) informacionParaValidaciones.get("tasaDumpMap");

		//glazaror... salvamos en una variable la fecha actual como numero... con esto evitamos la ejecucion continua del metodo getCurrentFormatDate
		Integer currentDateAsInteger = new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd"));

		for(DatoSerie serie:series){
			String tnan=serie.getCodtnan();
			Long part_nandi=serie.getNumpartnandi();
			String pais_orige=serie.getCodpaisorige();
			BigDecimal quniisc=serie.getCntunicomisc();
			String tuniisc=serie.getCodunicomisc();
			//String tipo_marge=serie.getCodtipomarge();
			Integer conv_inter=serie.getCodconvinter();
			Integer trat_prefe=serie.getCodtratprefe();
			Integer codi_liber=serie.getCodliberatorio();
			String pais_adqui=serie.getCodpaisadqui();
			String cod_moneda=serie.getCodmoneda();
			BigDecimal val_aduana=serie.getMtovaladuana();
			BigDecimal ajuste=serie.getMtoajuste()!=null?serie.getMtoajuste():BigDecimal.ZERO;
			BigDecimal fob_divfac=serie.getMtofobmon()!=null?serie.getMtofobmon():BigDecimal.ZERO;
			BigDecimal fob_dolpol=serie.getMtofobdol()!=null?serie.getMtofobdol():BigDecimal.ZERO;
			BigDecimal flete=serie.getMtofledol()!=null?serie.getMtofledol():BigDecimal.ZERO;
			String cseg=serie.getCodtiposeg();
			BigDecimal seguro=serie.getMtosegdol()!=null?serie.getMtosegdol():BigDecimal.ZERO;
			String sest_merca=serie.getCodestamerca();
			BigDecimal precio_vta=serie.getValpreciovta();
			String cproh=serie.getCodvalajuste();
			String cexcnan=serie.getValindcodlib();
			String czonfra=serie.getIndzonafranca();
			String dzonfra=serie.getDeszonafranca();
			String pcorre=serie.getNumpartcorre();
			String desc_comer=serie.getDescomercial();
			String desc_fopre=serie.getDesformapres();
			String desc_matco=serie.getDesmatecomp();
			String desc_usoap=serie.getDesusoaplica();

			// DZC ISC INI  Valida en CAT_REFPARTIDAS LICORES  que exista para tipo LIC	
			boolean VigenciaLicores=false;  //Vigencia en CAT_REFPARTIDAS
			boolean tieneNandTasa998=false;  //Tiene nandtasa 998

			//glazaror... pendiente optimizar aqui
			if(VigenciaISC && declaracion.getDua().getCodregimen().equals("10"))
			{   // vemos si esta vigente en la tabla CAT_REFPARTIDAS

				//glazaror... evitamos ejecutar otro query sobre cat_refpartida
				/*Map<String,Object> paramsCatRef=new HashMap<String,Object>();
				paramsCatRef.put("tipo_uso", "LIC");
				paramsCatRef.put("cnan", part_nandi);
				paramsCatRef.put("fechaVigencia", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));*/
				//	         	CatRefPartidasDAO catrefpartidasDAO=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO();
				//				int contCatRef=catrefpartidasDAO.count(paramsCatRef); 				
				/*paramsCatRef.put("ayudaID", "CatRefpartidas");
				Integer contCatRef = (Integer)ayudaService.countCatRefParidas(paramsCatRef);*/

				//glazaror... consultamos del map catalgoReferenciaPartidaLIC
				Integer contCatRef = 0;
				//ECANA - glazaror 20150601 Correcci�n new BigDecima en metodo catalogoReferenciaPartidaLIC
				//Map<String, Object> catRef = catalogoReferenciaPartidaLIC.get(part_nandi.toString());
				Map<String, Object> catRef = catalogoReferenciaPartidaLIC.get(part_nandi.toString()!=null?part_nandi.toString():" ");//PAS20155E220400060
				if (catRef != null) {
					contCatRef = ((BigDecimal) catRef.get("CANTIDAD")).intValue();
				}

				if (contCatRef>0)VigenciaLicores=true;
				// vemos si esta vigente en el nandatasa para VISC = 998
				HashMap<String,Object> paramsNandtasaLic=new HashMap<String,Object>();
				//paramsNandtasaLic.put("tnan", tnan);
				paramsNandtasaLic.put("cnan", part_nandi);
				paramsNandtasaLic.put("finitas", fechaIngreso);
				paramsNandtasaLic.put("ffintas", fechaIngreso);
				paramsNandtasaLic.put("visc", 998);
				//				NandTasaDAO nandtasaDAO=FormatoAServiceImpl.getInstance().getNandtasaDAO();
				//				int contNandTasa998=nandtasaDAO.count2(paramsNandtasaLic);  
				//int contNandTasa998=((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).count2(paramsNandtasaLic);

				//glazaror... obtenemos la tasa del map
				int contNandTasa998 = 0;
				//ECANA - glazaror 20150601 Si no envian la tasa se le asigna un espacio en blanco
				if(tnan == null) {
					tnan = " ";
				}
				//glazaror... se envia " -" por que el primer parametro tnan debe ser vacio en este caso 
				//ECANA - glazaror 20150601 Correcci�n , se concatena tnan a part_nandi
				Map<String, Object> tasa998 = nandTasa998Map.get(tnan + "-" + part_nandi);
				if (tasa998 != null) {
					contNandTasa998 = ((BigDecimal) tasa998.get("CANTIDAD")).intValue();
				}

				if (contNandTasa998>0)tieneNandTasa998=true;

				//ECANA No se debe validar aqui, ya que eso implicaria que la tnan existe para la partida de licores --> tieneNandTasa998
				if (VigenciaLicores) // && tieneNandTasa998)         
				{  
					//PAS20181U220200039 ISC LICORES DS093_2018EF AREY, el mensaje indicar� a que tnan puede enviar:
					HashMap<String,Object> paramsNandTasaLicores = new HashMap<String,Object>();
					paramsNandTasaLicores.put("cnan", part_nandi);
					paramsNandTasaLicores.put("fechavigencia", fechaIngreso); 
					paramsNandTasaLicores.put("visc", 998);
					List<String> lisTnanAceptadas  =  ((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).findTnanAceptadas(paramsNandTasaLicores);
										
					// Si no declara TNAN
					if(SunatStringUtils.isEmptyTrim(tnan)|| tnan==null) 
					{
						//ECANA - RBEGAZO Se hace ajuste a mensaje de validaci�n
						//Map<String,String> maperror = new HashMap<String, String>();
						//maperror.put(ResponseMapManager.KEY_CODIGO,"50021" );
						//maperror.put(ResponseMapManager.KEY_DESCRIPCION," Partida "+part_nandi+ " corresponde a licores. Debe declarar el  Tipo de Tasa a Aplicar (TNAN) 01, 02 � 03 ") ;
						//listError.add(maperror);
						if(!CollectionUtils.isEmpty(lisTnanAceptadas)){//PAS20181U220200039
							String listadoTnan = lisTnanAceptadas.toString();							 
							listError.add(getDUAError("50021",new Object[]{serie.getNumserie(),part_nandi.toString(),(listadoTnan.replace("[","")).replace("]", "") }));
						}
					}
					else
					{   //Partida NNNNNNNNNN corresponde a licores. Debe declarar el Tipo de Tasa a Aplicar (TNAN) 01, 02 � 03. Valor declarado <tnan>
						
						//PAS20181U220200039 ISC LICORES DS093_2018EF AREY, el mensaje indicar� a que tnan puede enviar:
						if(!CollectionUtils.isEmpty(lisTnanAceptadas)){
						 
						if(!lisTnanAceptadas.contains(tnan)){//aqui verifica que sea una tnan valida
							String listadoTnan = lisTnanAceptadas.toString();							
							listError.add(getDUAError("50022",new Object[]{serie.getNumserie(),part_nandi.toString(),tnan,(listadoTnan.replace("[","")).replace("]", "") }));
						}
						 						
						/*if (!SunatStringUtils.include(tnan,new String[]{"01","02","03"}))
						{	
							//ECANA - RBEGAZO Se hace ajuste a mensaje de validaci�n
							//Map<String,String> maperror = new HashMap<String, String>();
							//maperror.put(ResponseMapManager.KEY_CODIGO,"50022" );
							//maperror.put(ResponseMapManager.KEY_DESCRIPCION," Partida "+part_nandi+" corresponde a licores. Debe declarar el Tipo de Tasa a Aplicar (TNAN) 01, 02 � 03. Valor declarado: (TNAN): "+tnan) ;
							//listError.add(maperror);
							
							
							listError.add(getDUAError("50022",new Object[]{serie.getNumserie(),part_nandi.toString(),tnan}));
						}*/
						else// si tiene tnan 01,02,03 // o cuales sean validas:
						{
							//ECANA Se debe validar aqui que la tnan pertenezca a la lista de licor y que si es 01 se envie el precio de venta --> && tieneNandTasa998)
							if(SunatStringUtils.include(tnan,new String[]{"01"}) && tieneNandTasa998) //si tiene tnan 01
							{
								if (SunatNumberUtils.isEqual(precio_vta, BigDecimal.ZERO)){// tienen tnan 1 y valor de venta 0
									//ECANA - RBEGAZO Se hace ajuste a mensaje de validaci�n
									//Partida NNNNNNNNNN corresponde a licores. Para Tipo de Tasa a Aplicar (TNAN) 01 debe declarar el Precio de Venta al P�blico mayor a cero
									//Map<String,String> maperror = new HashMap<String, String>();
									//maperror.put(ResponseMapManager.KEY_CODIGO,"50023" );
									//maperror.put(ResponseMapManager.KEY_DESCRIPCION, " Partida "+part_nandi+" corresponde a licores. Para Tipo de Tasa a Aplicar (TNAN) 01 debe declarar el Precio de Venta al P�blico mayor a cero");
									//listError.add(maperror);
									listError.add(getDUAError("50023",new Object[]{serie.getNumserie(),part_nandi.toString()}));
								}      

							}
						}
							
						}//fin del search de TNANs

					}   


				}

			}   // tieneNandTasa998 VigenciaLicores
			// DZC ISC FIN

			//INICIO PAS20144E620000100 - cpuente
			//es r�gimen de importaci�n y est� vigente PSF para dicho r�gimen
			//obtener el tipo de transaccion para numeracion: 1001 
			String tipoTx;
			if ( (Mensaje) declaracion.getPadre()== null)
				tipoTx= "";
			else 
				tipoTx= ((Mensaje) declaracion.getPadre()).getControl().getTipoDeTransaccion().toString();


			//amancilla
			String transaccion = declaracion.getCodtipotrans()!=null?declaracion.getCodtipotrans().toString():"";

			//glazaror... pendiente la optimizacion para la numeracion de dua (transaccion 1001)... se deben evitar querys por cada serie...
			if ( estaVigentePSF10 && declaracion.getDua().getCodregimen().equals("10")  && tipoTx.equals("1001") )
			{
				// Traemos el objeto para el tipo de uso PSF de la tabla catrefpartidas
				AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
				Map<String,Object> paramsCatRef=new HashMap<String,Object>();
				paramsCatRef.put("tipo_uso", "PSF");
				paramsCatRef.put("cnan", part_nandi);
				//glazaror... evitamos por cada serie ejecutar el metodo SunatDateUtils.getCurrentFormatDate
				//paramsCatRef.put("fechaVigencia", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
				//glazaror... y le pasamos la variable calculada una sola vez currentDateAsInteger
				paramsCatRef.put("fechaVigencia", currentDateAsInteger);

				//				CatRefPartidasDAO catrefpartidasDAO=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO();
				// Se cuenta si el objeto se encuentra en cat_refpartidas
				//				int contCatRef=catrefpartidasDAO.count(paramsCatRef);
				paramsCatRef.put("ayudaID", "CatRefpartidas");
				Integer contCatRef = (Integer)ayudaService.countCatRefParidas(paramsCatRef);

				// Valida que se encuentre en Cafrepartidas y que sea para DUA con garantia 160
				if ((contCatRef>0) && !SunatStringUtils.isEmptyTrim(dua.getPago().getPagoDeclaracion().getCodgarantia()))
				{
					// Inicializamos El DAO del operador de comercio exterior
					//OperadorComexDAO operadorComexDAO= FormatoAServiceImpl.getInstance().getOperadorComexDAO();
					//pase42 pruiz
					OperadorComexDAO operadorComexDAO= ((OperadorComexDAO)fabricaDeServicios.getService("tg.model.OperadorComexDAO"));

					String rucImportador=declarante.getNumeroDocumentoIdentidad();

					// Obtenemos documento si es Importador Frecuente u Operador Autorizado
					String docImportadorFrecuente= operadorComexDAO.getImportadorFrecuenteRuc(rucImportador);
					String docOperadorEconAutorizado= operadorComexDAO.getOperadorEcoAutorizadoRuc(rucImportador);
					//Validamos si es un importador autorizado
					boolean importadorAutorizado= false;
					if (docImportadorFrecuente!=null || docOperadorEconAutorizado!= null )
						importadorAutorizado= true;

					if (!importadorAutorizado)
					{
						//ECANA - RBEGAZO Se hace ajuste a mensaje de validaci�n
						//Map<String,String> maperror = new HashMap<String, String>();
						//maperror.put(ResponseMapManager.KEY_CODIGO,"50024" );
						//maperror.put(ResponseMapManager.KEY_DESCRIPCION," SPN  "+part_nandi+" SENSIBLE AL FRAUDE NO PUEDE ACOGERSE A GARANTIA 160") ;
						//listError.add(maperror);
						listError.add(getDUAError("50024",new Object[]{serie.getNumserie(),part_nandi.toString()}));
					}
				}

			}
			//FIN

			//SPTD_ADUADET1 8-11
			/*	if (!SunatStringUtils.isEmptyTrim(serie.getCodaplultra()))
				veriError(listError, "I1", serie.getCodaplultra(),"5040"," ","APL_ULTRA");*/
			//SPTD_ADUADET1 12-15
			DatoDocTransporte docTransp=getDocTransporte(dua,serie);
			if (docTransp!=null){
				String puer_embar=docTransp.getCodpuerto();
				//glazaror... evitamos llamada rest... y obtenemos el count desde el mapa cargado anterior
				//if (packageTD.getCountInPuertos(puer_embar)==0)
				if (resultadoCountInPuertos.get(puer_embar) == 0)
					listError.add(getDUAError("0063","PUER_EMBAR-ENVIADO "+puer_embar+" - CONSULTE LA PAG WEB DE ADUANAS"));
				//SPTD_ADUADET1 16-19
				Date fec_embarque=docTransp.getFecembarque();
				if (fec_embarque==null){
					FechaBean fbFecembarque=new FechaBean();
					fbFecembarque.setFecha(fec_embarque);
					listError.add(getDUAError("0065","Series. FECH_EMBAR - ENVIADO: "+(fec_embarque==null?null:fbFecembarque.getFormatDate("dd/MM/yyyy"))));
				}
			}
			//SPTD_ADUADET 24-27
			if (SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"5209420000","5513310000","5513410000","5515110000","5515120000"}) && !"CN".equals(pais_orige) && SunatStringUtils.isEmptyTrim(cert_orige)){
				listError.add(getDUAError("9203","No ha transmitido el Certificado de Origen, envio :"+cert_orige));
			}
			//SPTD_ADUADET 28-30
			if (!SunatStringUtils.isEmptyTrim(serie.getCodunicomer())){
				veriError(listError,"29",serie.getCodunicomer(),"0062","","TUNICOM");
			}
			//SPTD_ADUADET 31-33
			if (!SunatNumberUtils.isGreaterThanZero(serie.getCntunicomer())){
				listError.add(getDUAError("0038","QUNICOM - ENVIADO:"+(serie.getCntunicomer()==null?serie.getCntunicomer():serie.getCntunicomer().doubleValue())));
			}
			//SPTD_ADUADET 50-52
			if (!SunatNumberUtils.isGreaterOrEqualsThanZero(serie.getCntbultos())){
				listError.add(getDUAError("0043","CANT_BULTO - ENVIADO:"+(serie.getCntbultos()==null?null:serie.getCntbultos().doubleValue())));
			}
			//SPTD_ADUADET 53-54
			veriError(listError,"16",serie.getCodclasbul(),"0044","","CLASE");
			//SPTD_ADUADET1 71-81
			String unid_fides=serie.getCodunifis();
			BigDecimal unid_fiqty=serie.getCntunifis();
			BigDecimal peso_neto=serie.getCntpesoneto();
			//glazaror... invocamos al metodo optimizado			
			String vlsOkv=valUnid(nanduniMap, part_nandi,unid_fides,unid_fiqty,peso_neto);
			//vigencia   inicio PAS20181U220200004 pruizcr
			//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
			Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
		    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false;
			if (!"0".equals(vlsOkv)){
				CatalogoAyudaService  catalogoAyudaService  =(CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				if (SunatStringUtils.include(vlsOkv,new String[]{"0051","0117"})){
					//listError.add(getDUAError(vlsOkv,"PART_NANDI - ENVIADO:"+part_nandi));
					if(vlsOkv.length()<5)	vlsOkv=SunatStringUtils.lpad(vlsOkv, 5, '0');//mejorado 2016
					listError.add(catalogoAyudaService.getError(vlsOkv,new String[] {"PART_NANDI - ENVIADO:"+part_nandi.toString() + " EN LA SERIE" + serie.getNumserie()}));//mejorado 2016
				}else{
					//esto segun PAS20181U220200064 ya no va
					if(esVigenteRIN05SegundaParte && ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(dua.getCodregimen()) && SunatStringUtils.include(vlsOkv,new String[]{"40428"}) && isDAMDiferidaSinIca){ // Se agrega validacion de regimen CSANTILLAN
						//listError.add(catalogoAyudaService.getError(vlsOkv,new String[] {"PART_NANDI - ENVIADO:"+part_nandi.toString()}));//mejorado 2016
						listError.add(getDUAError("40428",new Object[]{serie.getNumserie(),part_nandi.toString()}));
					}else{
						
						if (!esVigenteRIN05SegundaParte){ 
						//listError.add(getDUAError(vlsOkv,"PESO NETO  - ENVIADO::"));
						if(vlsOkv.length()<5)	vlsOkv=SunatStringUtils.lpad(vlsOkv, 5, '0');//mejorado 2016
						listError.add(catalogoAyudaService.getError(vlsOkv,new String[] {"PESO NETO  - ENVIADO:"+peso_neto}));//mejorado 2016
						//listError.add(getDUAError(vlsOkv,"UNID_FIQTY - ENVIADO:")); //jreynoso se comenta pq se duplica el mismo error. bug 18573
					   }
				}
			}

			}
	//vigencia   fin  PAS20181U220200004 pruizcr

			HashMap<String,Object> paramsNandtasa=new HashMap<String,Object>();
			if (tnan==null || tnan.isEmpty()) {
				//tnan="";
				//glazaror... si es que la serie no tiene tnan entonces espacio en blanco
				tnan=" ";
			}
			paramsNandtasa.put("tnan", tnan);
			paramsNandtasa.put("cnan", part_nandi);
			paramsNandtasa.put("finitas", fechaIngreso);
			paramsNandtasa.put("ffintas", fechaIngreso);
			//NandTasaDAO nandtasaDAO=FormatoAServiceImpl.getInstance().getNandtasaDAO();
			//			if (nandtasaDAO.count(paramsNandtasa)==0 || ((VigenciaLicores==true && tieneNandTasa998==false)) )

			//glazaror... evitamos consulta en base datos la tasa
			//int contNandTasa=((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).count(paramsNandtasa);
			int contNandTasa = 0;
			//glazaror... obtenemos la tasa del map tasaPartidasMap
			Map<String, Object> tasa = tasaPartidasMap.get(tnan + "-" + part_nandi);
			if (tasa != null) {
				contNandTasa = ((BigDecimal) tasa.get("CANTIDAD")).intValue();
			}

			// DZC ISC Licores si tiene vigencia de Licores se valida que no exista o no este vigente en la tabla Nandtasa  
			if (contNandTasa==0){
				listError.add(getDUAError("35178",new Object[]{serie.getNumserie(),part_nandi.toString(),tnan}));
			}
			//ECANA - RBEGAZO Se hace ajuste a mensaje de validaci�n
			if((VigenciaLicores==true && tieneNandTasa998==false)){
				//result=catalogoHelper.getErrorMap("05038",new Object[]{serie.getNumserie(),item.getNumpartnandi().toString()});
				//listError.add(getDUAError("5038","PART_NANDI - ENVIADO: ES AQUI"+part_nandi));
				listError.add(getDUAError("05038",new Object[]{serie.getNumserie(),part_nandi.toString()}));
			}

			//if( !SunatStringUtils.isEqualTo(tnan, " ") &&  !SunatStringUtils.isEmpty(tnan) )
			//{				
			//SPTD_ADUADET1 82-86
			// DZC ISC Licores para que no interfiera en la validacion ya establecida
			//if (!SunatStringUtils.include(tnan,new String[]{"01","02","03","04","05","06","07","08","09"}) && (VigenciaLicores==false && tieneNandTasa998==false))

			if (!SunatStringUtils.isEmpty(SunatStringUtils.trimNotNull(tnan)) && !SunatStringUtils.include(tnan,new String[]{"01","02","03","04","05","06","07","08","09"})){                    
				listError.add(getDUAError("0083","TNAN - ENVIADO:"+tnan));
			}
			//SPTD_ADUADET1 87-100
			Map<String,Object>paramsIscfacto=new HashMap<String,Object>();
			paramsIscfacto.put("cnan", part_nandi);
			// resolucion bug 1607
			//paramsIscfacto.put("finifac", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
			//20160606->MNA->Se reemplaza fecha actual por fecha de numeracion de la DAM->PAS20165E220500162
			//paramsIscfacto.put("fecvigencia", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
			paramsIscfacto.put("fecvigencia", fechaIngreso);
			// resolucion bug 1607

			//IscfactoDAO iscfactoDAO=FormatoAServiceImpl.getInstance().getIscfactoDAO();
			IscfactoDAO iscfactoDAO=((IscfactoDAO)fabricaDeServicios.getService("iscfactoDAO"));
			if (iscfactoDAO.count(paramsIscfacto)>0){
				//ECANA 2015060 Se agregan dos parametros mas para verificar si las partidas son de licores - VigenciaLicores, tieneNandTasa998
				camposSelectivo(listError, quniisc, tuniisc, part_nandi, unid_fides, unid_fiqty, VigenciaLicores, tieneNandTasa998);
			}else{
				Map<String,Object> paramsIscvalor=new HashMap<String,Object>();
				paramsIscvalor.put("cnan", part_nandi);
				// resolucion bug 1607
				//paramsIscvalor.put("finivig", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
				//20160606->MNA->Se reemplaza fecha actual por fecha de numeracion de la DAM->PAS20165E220500162
				//paramsIscvalor.put("fecvigencia", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
				paramsIscvalor.put("fecvigencia", fechaIngreso);
				paramsIscvalor.put("tnan", tnan);//PAS20155E220400060
				// resolucion bug 1607
				//IscvalorDAO iscvalorDAO=FormatoAServiceImpl.getInstance().getIscvalorDAO();
				IscvalorDAO iscvalorDAO=((IscvalorDAO)fabricaDeServicios.getService("iscvalorDAO"));
				if (iscvalorDAO.count(paramsIscvalor)>0){
					//ECANA 2015060 Se agregan dos parametros mas para verificar si las partidas son de licores - VigenciaLicores, tieneNandTasa998
					camposSelectivo(listError, quniisc, tuniisc, part_nandi, unid_fides, unid_fiqty, VigenciaLicores, tieneNandTasa998);
				}else{

					// DZC ISC: Validamos si tiene Nandtasa con VISC 998 y que este vigente:
					if (SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2402201000","2402202000","2203000000"}) || (tieneNandTasa998 && VigenciaLicores) ){
						//ECANA 2015060 Se agregan dos parametros mas para verificar si las partidas son de licores - VigenciaLicores, tieneNandTasa998
						camposSelectivo(listError, quniisc, tuniisc, part_nandi, unid_fides, unid_fiqty, VigenciaLicores, tieneNandTasa998);
					}else{
						if (quniisc!=null && ! SunatNumberUtils.isEqual(BigDecimal.ZERO, quniisc) ){
							listError.add(getDUAError("1085","QUNIISC - ENVIADO:"+quniisc));
						}
						if (!SunatStringUtils.isEmptyTrim(tuniisc)){
							listError.add(getDUAError("1086","TUNIISC - ENVIADO:"+tuniisc));
						}
					}
				}
			}

			//}
			//SPTD_ADUADET1 106-119
			// rpumacayo pase70
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService( "Ayuda.catalogoAyudaServicePrincipal");
			// rpumacayo pase70
			if (conv_inter!=0){
				// Con el nuevo esquema de TPIS esta validacion no debe realizarse para los TPI del pase 2013-337.
				if (SunatStringUtils.include(String.valueOf(conv_inter.intValue()),new String[]{"10", "11", "13","110", "111", "113", "114", "348", "339", "120","130", "308", "430"}) 
						&& !SunatStringUtils.isEmptyTrim(cert_orige)){
					if (SunatStringUtils.isEmptyTrim(nume_ffco)){
						listError.add(getDUAError("1125","NUME_FFCO - ENVIADO:"+nume_ffco+"INVALIDO"));
					}else{

						/*
						 * 	SELECT a.regis,a.codpais INTO vRegis,vCodpais FROM pruperso a ,entidades b 
							WHERE a.codent=b.codent AND a.codpais=b.codpais AND a.cestado='00' 
							AND NVL(a.cdel,' ')=' ' AND b.cestado= '00' AND NVL(b.cdel,' ')=' ' 
							AND a.regis=LPAD(NUME_FFCO,5,' ') AND ROWNUM = 1 
						 */
						Map<String,Object> paramsPruperso=new HashMap<String,Object>();
						if (!datoCertOrig.getListAutocertificacion().isEmpty()){
							paramsPruperso.put("codffco", datoCertOrig.getListAutocertificacion().get(0).getCodffco());
						}
						//Map<String,Object> mapPrupersoEntidades=FormatoAServiceImpl.getInstance().getPrupersoDAO().joinPrupersoAndEntidadesFindByMap(paramsPruperso);
						Map<String,Object> mapPrupersoEntidades=((PrupersoDAO)fabricaDeServicios.getService("prupersoDAO")).joinPrupersoAndEntidadesFindByMap(paramsPruperso);

						if (mapPrupersoEntidades==null){
							listError.add(getDUAError("1126","NUME_FFCO - ENVIADO:"+nume_ffco));
						}else{
							String vcod_pais=(String)mapPrupersoEntidades.get("codpais");
							if (!pais_orige.equals(vcod_pais))
								listError.add(getDUAError("1127","NUME_FFCO - ENVIADO:"+nume_ffco+" NO CORRESPONDE AL PAIS_ORIGE ENVIADO: "+pais_orige));
						}
					}
				}
			}else if (trat_prefe!=0){
				PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
				if (packageTD.getCountInTabLibe("T", SunatStringUtils.lpad(String.valueOf(trat_prefe), 4, ' '))==0)
					listError.add(catalogoAyudaService.getError("00053", new String[]{serie.getNumserie().toString(), trat_prefe.toString()}));
				//listError.add(getDUAError("0053","TRAT_PREFE - ENVIADO:"+trat_prefe));
			}
			/*Se retira por duplicidad con  ValNegocNumeracFormAServiceImpl.valCodigoLiberatorio Bug 17983 arey
			 else if (codi_liber!=0){
				// rpumacayo pase70
				if (packageTD.getCountInTabLibe("C", SunatStringUtils.lpad(String.valueOf(codi_liber), 4, ' '))==0)
					listError.add(catalogoAyudaService.getError("00052", new String[]{serie.getNumserie().toString(), codi_liber.toString()}));
					//listError.add(getDUAError("0052","CODI_LIBER - ENVIADO:"+codi_liber));
			}*/
			//SPTD_ADUADET1 120-121
			veriError(listError, "J2", pais_orige, "0049", "", "PAIS_ORIGE");
			//SPTD_ADUADET1 122-123
			veriError(listError, "J2", pais_adqui, "0050", "", "PAIS_ADQUI");
			//SPTD_ADUADET1 124-127
			if ("PE".equalsIgnoreCase(pais_orige) && "PE".equalsIgnoreCase(pais_adqui)){
				DatoDocTransporte docTransporte=getDocTransporte(dua,serie);
				if (docTransporte!=null){
					if (docTransporte.getCodpuerto().substring(0, 2).equals("PE"))
						listError.add(getDUAError("0050","PUER_EMBAR - ENVIADO:"+docTransporte.getCodpuerto()+" DEBE SER DE PROCEDENCIA DIFERENTE A PERU"));
				}
			}
			//SPTD_ADUADET1 128-129
			veriError(listError, "J1",cod_moneda,"0021","","COD_MONEDA");
			//SPTD_ADUADET1 130-138
			if (!cod_moneda.equalsIgnoreCase("USD")){
				if (SunatNumberUtils.isLessOrEqualsThanZero(fob_divfac)){
					//amancilla
					if(!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION) && !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION) 
							&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION)){
						listError.add(getDUAError("0032","FOB_DIVFAC - ENVIADO:"+fob_divfac+"-MONEDA:"+cod_moneda));
					}
				}else{
					Map<String,Object> params=new HashMap<String,Object>();
					//NSR: 19/05/2011
					//La fecha de cambio debe ser el de la numeraci�n
					Integer fechaCambio=null;
					//Si fec declaraci�n es null es numeraci�n
					if(declaracion.getDua().getFecdeclaracion()==null){
						fechaCambio = SunatDateUtils.getCurrentIntegerDate();
					} else {
						fechaCambio = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
					}
					AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
					params.put("fingreso", fechaCambio);
					//params.put("fingreso", SunatDateUtils.getCurrentIntegerDate());
					//END NSR
					params.put("cmoneda", cod_moneda);
					/*
					 * SELECT pventa INTO vpventa FROM cambio1 WHERE fingreso=vFechIngsi AND cmoneda=cod_moneda 
					 */					
					//					Cambio1 cambio1 = FormatoAServiceImpl.getInstance().getCambio1DAO().findByPK(params);
					params.put("ayudaID", "Cambio1");
					Cambio1 cambio1 = (Cambio1)ayudaService.buscarObject(params);

					if (cambio1==null){
						listError.add(getDUAError("30391",new Object []{cod_moneda}));

					}else{
						//BigDecimal dolarVenta=(BigDecimal)mapCambio1.get("pventa");
						BigDecimal dolarVenta=cambio1.getPventa();
						BigDecimal dolares=SunatNumberUtils.multiply(fob_divfac, dolarVenta);

						double val= SunatNumberUtils.diference(dolares, fob_dolpol).setScale(3,BigDecimal.ROUND_HALF_UP).doubleValue();
						if (Math.abs(val)>0.001){
							//amancilla
							if(!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION) &&  !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION) 
									&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION))//PAS20165E220200033 
							{
								listError.add(getDUAError("0033",new Object[]{serie.getNumserie(), fob_dolpol,dolares}));
								//listError.add(getDUAError("0033","FOB_DOLPOL - ENVIADO:"+fob_dolpol+"-FOB_DIVFAC * COD_MONEDA - CALCULADO:"+dolares));PAS201830001100008
							}
						}
					}
				}
			}else{
				if ( SunatNumberUtils.isGreaterThanZero(fob_divfac) 
						&& !SunatNumberUtils.isEqual(fob_divfac, fob_dolpol))
				{
					//amancilla no se va ejecutar para la diligencia coordinado con nramirez y Angelica Rojas
					if(!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION) 
							&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)
							&& !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION)){
						listError.add( ResponseMapManager.getErrorResponseMap("00032", "MONTO FOB EN MONEDA TRANSACCION INVALIDO: ENVIADO:"+fob_divfac+"-MONEDA:"+cod_moneda+" FOB DOLLAR:"+fob_dolpol) );
					}
				}
			}
			//SPTD_ADUADET1 139-152
			if (!SunatNumberUtils.isGreaterThanZero(fob_dolpol))
				//amancilla
				if(!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION) && !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION) ){
					listError.add(getDUAError("0033",new Object[]{serie.getNumserie()}));
					//listError.add(getDUAError("0033","FOB_DOLPOL - ENVIADO:"+fob_dolpol));PAS201830001100008
				}
			if (!SunatNumberUtils.isGreaterThanZero(flete))
				listError.add(getDUAError("0034","FLETE - ENVIADO:"+flete));
			veriError(listError,"62",cseg,"0082","","CSEG");
			if (SunatStringUtils.include(cseg,new String[]{"2","3","4","9"})){
				if (!SunatNumberUtils.isGreaterOrEqualsThanZero(seguro))
					listError.add(getDUAError("0035","SEGURO:"+seguro));
			}
			if ("9".equals(cseg) && !SunatStringUtils.include(vaduana,new String[]{"163", "145", "172","046" })){
				listError.add(getDUAError("0082","SOLO CETICOS CSEG"+cseg));
			}
			//			if (val_aduana.subtract((ajuste.add(fob_dolpol.add(flete.add(seguro))))).abs().doubleValue()>0.003){
			if(SunatNumberUtils.absoluteDiference(val_aduana,SunatNumberUtils.sum(ajuste, SunatNumberUtils.sum(fob_dolpol, SunatNumberUtils.sum(flete, seguro)))).doubleValue()>0.003){	
				listError.add(getDUAError("5003", new Object[]{serie.getNumserie(),val_aduana, fob_dolpol, flete, seguro, ajuste}));
			}
			//SPTD_ADUADET1 153-157
			String capitulo=SunatStringUtils.lpad(String.valueOf(part_nandi),10,'0').substring(0, 4);
			if (SunatStringUtils.include(capitulo, new String[]{"6401", "6402", "6403", "6404", "6405"})){
				if (SunatStringUtils.length(desc_comer)<4 || SunatStringUtils.length(desc_fopre)<4 || SunatStringUtils.length(desc_matco)<4 || SunatStringUtils.length(desc_usoap)<4){
					listError.add(getDUAError("1000",""));
				}
			}

			//SPTD_ADUADET1 160-167
			//glazaror... se debe evitar la llamada ayudaService.countCatRefParidas por cada serie... invocar al groupCatRefParidas implementado para los otros tipo de uso... PENDIENTE
			//glazaror... evitamos la llamada ayudaService.countCatRefParidas a BD por cada serie
			String xpais_orige=pais_orige;
			Map<String,Object> paramsCatRef=new HashMap<String,Object>();


			//glazaror... obtenemos la cantidad del mapa catalogoReferenciaPartidaSAV
			Integer contCatRef = 0;
			Map<String, Object> catRef = catalogoReferenciaPartidaSAV.get(part_nandi + "-" + xpais_orige);
			if (catRef != null) {
				contCatRef = ((BigDecimal) catRef.get("CANTIDAD")).intValue();
			}

			DatoProducto producto=serie.getProducto();
			BigDecimal fob_factu=producto.getMtofobfactu();
			String xcprod=producto.getCodpantidum();
			String cexpodump=producto.getCodexpantidum();
			if (contCatRef>0 && !SunatNumberUtils.isGreaterThanZero(fob_factu)){
				listError.add(getDUAError("1037","SALV:FOB_FACTU - ENVIADO: OK"+fob_factu.doubleValue()));
			}
			//SPTD_ADUADET1 168-178
			DatoDocTransporte docTransporte=getDocTransporte(dua,serie);
			if  (docTransporte!=null){
				Date fech_embar=docTransporte.getFecembarque();

				if (!"8708701000".equals(part_nandi) || (fech_embar.compareTo((new FechaBean("08/02/2001")).getCalendar().getTime())>0 && "8708701000".equals(part_nandi))){
					//glazaror... evitamos llamada a BD tabla tasadump
					/*Map<String,Object> paramsTasadump=new HashMap<String,Object>();
					paramsTasadump.put("cnan", part_nandi);
					paramsTasadump.put("cpaiorige", pais_orige);*/

					//glazaror... evitamos por cada serie ejecutar el metodo SunatDateUtils.getCurrentFormatDate
					//paramsTasadump.put("fechavigencia", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
					//glazaror... y le pasamos la variable calculada una sola vez currentDateAsInteger
					//paramsTasadump.put("fechavigencia", currentDateAsInteger);
					//TasadumpDAO tasadumpDAO=FormatoAServiceImpl.getInstance().getTasadumpDAO();
					//TasadumpDAO tasadumpDAO=((TasadumpDAO)fabricaDeServicios.getService("tasadumpDAO"));
					//int contTasadump=tasadumpDAO.count(paramsTasadump);

					int contTasadump = 0;
					//glazaror... obtenemos la cantidad del mapa tasaDumpMap... la primera busqueda es por partida y pais origen
					Map<String, Object> tasaDump = tasaDumpMap.get(part_nandi + "-" + pais_orige);
					if (tasaDump != null) {
						contTasadump = ((BigDecimal) tasaDump.get("CANTIDAD")).intValue();
					}

					if (contTasadump>0){
						if (SunatStringUtils.isEmptyTrim(xcprod) || "0".equals(xcprod)){
							listError.add(getDUAError("9030","CPROD - ENVIADO:"+xcprod));
						}else{
							//glazaror... evitamos otra llamada a la BD
							//paramsTasadump.put("cprod", xcprod);

							//glazaror... obtenemos la cantidad del mapa tasaDumpMap... esta vez la busqueda es por partida, pais origen y codigo de producto
							Map<String, Object> tasaDump2 = tasaDumpMap.get(part_nandi + "-" + pais_orige + "-" + xcprod);
							int cantidadTasaDumpPorProducto = 0;
							if (tasaDump2 != null) {
								cantidadTasaDumpPorProducto = ((BigDecimal) tasaDump2.get("CANTIDAD")).intValue();
							}

							//glazaror... evitamos otra llamada a BD
							//if (tasadumpDAO.count(paramsTasadump)<=0){
							//glazaror... comparamos con la variable cantidadTasaDumpPorProducto
							if (cantidadTasaDumpPorProducto <= 0) {
								listError.add(getDUAError("0086","CPROD - ENVIADO:"+xcprod));
							}else{
								if (!SunatNumberUtils.isGreaterThanZero(fob_factu)){
									listError.add(getDUAError("1037","DUMP:FOB_FACTU - ENVIADO:"+fob_factu));
								}
								if (!SunatStringUtils.isEmptyTrim(cexpodump)){
									Map<String,Object> paramsExpodump=new HashMap<String,Object>();
									paramsExpodump.put("cprod", xcprod);
									paramsExpodump.put("cnan", part_nandi);
									paramsExpodump.put("capiorige", pais_orige);
									paramsExpodump.put("cexport", cexpodump);
									//glazaror... evitamos por cada serie ejecutar el metodo SunatDateUtils.getCurrentFormatDate
									//paramsExpodump.put("finivig", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
									//glazaror... y le pasamos la variable calculada una sola vez currentDateAsInteger
									paramsExpodump.put("finivig", currentDateAsInteger);

									//ExpodumpDAO expodumpDAO=FormatoAServiceImpl.getInstance().getExpodumpDAO();
									ExpodumpDAO expodumpDAO=((ExpodumpDAO)fabricaDeServicios.getService("expodumpDAO"));
									if (expodumpDAO.count(paramsExpodump)<=0)
										listError.add(getDUAError("0085","CEXPODUMP - ENVIADO:"+cexpodump));
								}
							}
						}
					}
					// DZC ISC Licores se valida para que no interfiera en la validacion existente
					boolean VigenciaISC_Soles_cigarrillos=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000048", SunatDateUtils.getCurrentDate())>0;//Pase 436 - 2015 

					if ((SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2402201000", "2402202000", "2203000000"}) && (VigenciaISC_Soles_cigarrillos==false)) 
							|| (VigenciaLicores && tieneNandTasa998)){//Pase 436 - 2015 
						if ( tnan.equals("01")  && (precio_vta == null || SunatNumberUtils.isEqual(precio_vta, BigDecimal.ZERO))){//PAS20165E220500104 
							listError.add(getDUAError("1924","NO ENVIO PRECIO DE VTA SUGERIDO"));  
						} 
					}
				}
			}
			//SPTD_ADUADET1 180-181
			veriError(listError,"79",cproh,"1033","","CPROH");
			//SPTD_ADUADET1 182-186
			if (SunatStringUtils.include(String.valueOf(codi_liber),new String[]{"4201","4202"})){
				if (!SunatStringUtils.include(cexcnan,new String[]{"S","N"}))
					listError.add(getDUAError("1038","CEXCNAN - 4201 o 4202 Acoge a Doc. CANCEL: ENVIADO"+cexcnan));
			}
			//SPTD_ADUADET1 187-197
			if (conv_inter!=0){
				if ("1".equals(czonfra)||!SunatStringUtils.isEmptyTrim(dzonfra)){
					listError.add(getDUAError("0195","CZONFRA - ENVIADO:"+czonfra));
				}else if(!"0".equals(czonfra)){
					listError.add(getDUAError("0193","CZONFRA - ENVIADO:"+czonfra));
				}
			}else{
				if (!SunatStringUtils.include(czonfra,new String[]{"1","0",""}))
					listError.add(getDUAError("0193","CZONFRA - ENVIADO:"+czonfra));
				if ("1".equals(czonfra) && SunatStringUtils.isEmptyTrim(dzonfra))
					listError.add(getDUAError("0194","DZONFRA - ENVIADO:"+dzonfra));
			}
			//SPTD_ADUADET1 198-203
			if (trat_prefe!=0){
				if (!"0".equals(pcorre)){

				}else{
					CodiLibeDAOService codiLibeDAOService = (CodiLibeDAOService)fabricaDeServicios.getService("Ayuda.codiLibeService");
					Map<String,Object> paramsCodilibe=new HashMap<String,Object>();
					paramsCodilibe.put("tlib", "T");
					paramsCodilibe.put("clib", trat_prefe);
					paramsCodilibe.put("ctralib", "C");
					//					CodilibeDAO codilibeDAO=FormatoAServiceImpl.getInstance().getCodilibeDAO();
					//					int contCodilibe=codilibeDAO.count(paramsCodilibe);
					int contCodilibe=codiLibeDAOService.count(paramsCodilibe);
					paramsCodilibe.put("ctralib", "D");
					//					contCodilibe+=codilibeDAO.count(paramsCodilibe);
					contCodilibe+=codiLibeDAOService.count(paramsCodilibe);
					if (contCodilibe>0)
						listError.add(getDUAError("0199","PART.CORRE - ENVIADO:"+pcorre+"-"+tnan));
				}
			}
			//SPTD_ADUADET1 204-210

			if (declaracion.getDua().getCodregimen().equals("10")){
				if (SunatStringUtils.include(pcdurge,new String[]{"01","A","08"})){
					AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
					paramsCatRef=new HashMap<String,Object>();
					paramsCatRef.put("tipo_uso", "URG");
					paramsCatRef.put("cnan", part_nandi);
					paramsCatRef.put("ref", pcdurge);
					paramsCatRef.put("finivig", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));

					paramsCatRef.put("ayudaID", "CatRefpartidas");
					Integer contCat = (Integer)ayudaService.countCatRefParidas(paramsCatRef);



					//if (catrefpartidasDAO.count(paramsCatRef)<=0)
					if (contCat<=0)
						listError.add(getDUAError("0198","PARTIDA:"+part_nandi+", NO ES UN PRODUCTO DEL TIPO "+pcdurge));
				}
			}
		}
		return listError;
	}

	/**
	 * Campos selectivo.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param quniisc BigDecimal
	 * @param tuniisc String
	 * @param part_nandi Long
	 * @param unid_fides String
	 * @param unid_fiqty BigDecimal
	 */
	private void camposSelectivo(List<Map<String,String>>listError, BigDecimal quniisc, String tuniisc, Long part_nandi, String unid_fides, BigDecimal unid_fiqty, boolean vigLic, boolean tieneT998){
		//ECANA 20150601 Se agregan dos parametros para verificar si las partidas son de licores boolean vigLic, boolean tieneT998
		int vswisc=0;
		if (quniisc==null || SunatNumberUtils.isEqualToZero(quniisc)  )
			listError.add(getDUAError("1087",new String[] {"QUNIISC - ENVIADO:"+(quniisc==null?null:0)}));
		if (tuniisc==null || SunatStringUtils.isEmptyTrim(tuniisc)){
			listError.add(getDUAError("1088",new String[] {"TUNIISC - ENVIADO:"+tuniisc}));
		}else{
			if (SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2701110000","2701120000","2701190000"}) && !SunatStringUtils.include(tuniisc,new String[]{"TM","KG3"})){
				listError.add(getDUAError("1089",new String[] {"PART_NANDI - ENVIADO:"+part_nandi.longValue()+" TUNIISC - ENVIADO:"+tuniisc}));
			}else if(SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2701110000","2701120000","2701190000"})){
				BigDecimal vconversion=PackageGeneral.getFactor(unid_fides, tuniisc, unid_fiqty);
				//if ( !SunatNumberUtils.isEqual(quniisc, vconversion) )
				if (SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(quniisc, vconversion), SunatNumberUtils.toBigDecimal(0.1)))
					listError.add(getDUAError("1090",new String[] {"QUNIISC - ENVIADO:"+quniisc+ " CALCULADO:"+vconversion}));
				if ( SunatNumberUtils.isEqualToZero(vconversion))
					listError.add(getDUAError("1091",new String[] {"UNID_FIDES - ENVIADO:"+unid_fides+" TUNIISC - ENVIADO:"+tuniisc}));
				vswisc=1;
			}
		}
		if (SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2711110000","2711120000","2711130000","2711140000","22711190000"}) && !"KG".equals(tuniisc)){
			listError.add(getDUAError("1089",new String[] {"PART_NANDI - ENVIADO: "+part_nandi}));
		}else if (SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2711110000", "2711120000", "2711130000", "2711140000", "2711190000"})){
			vswisc=1;
		}
		//ECANA 20150601 Se agrega validaci�n desde USAMTG00.SPTD_ADUADET1
		// || (!SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2203000000"}) && vigLic && tieneT998 && !SunatStringUtils.include(tuniisc,new String[]{"L","L 6"}) )
		// || tieneT998 )
		if (vswisc==0){
			if ((part_nandi==2203000000L && !"L".equals(tuniisc)) || (!SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2203000000"}) && vigLic && tieneT998 && !SunatStringUtils.include(tuniisc,new String[]{"L","L 6"}) ))
				listError.add(getDUAError("1089",new String[] {"PART_NANDI - ENVIADO:"+part_nandi}));
			else if (part_nandi==2203000000L || tieneT998)
				vswisc=1;
		}
		if (vswisc==0){
			if (SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2402201000","2402202000"}) && !"UNI".equals(tuniisc))
				listError.add(getDUAError("1089",new String[] {"PART_NANDI - ENVIADO:"+part_nandi+" TUNIISC - ENVIADO:"+tuniisc+ " ENVIE UNI"}));
			else if (SunatStringUtils.include(String.valueOf(part_nandi),new String[]{"2402201000","2402202000"}))
				vswisc=1;
		}
		if (vswisc==0){
			if (!"GAL".equals(tuniisc)){
				listError.add(getDUAError("1089",new String[] {"PART_NANDI - ENVIADO: "+part_nandi+ " TUNIISC - ENVIADO:"+tuniisc}));
			}else{
				BigDecimal vConversion=PackageGeneral.getFactor(unid_fides, tuniisc, unid_fiqty);
				//if ( !SunatNumberUtils.isEqual(quniisc, vConversion))
				if (SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.absoluteDiference(quniisc, vConversion), SunatNumberUtils.toBigDecimal(0.1)))
					listError.add(getDUAError("1090",new String[] {"QUNIISC - ENVIADO:"+quniisc+"CALCULADO:"+vConversion}));
				if (SunatNumberUtils.isEqualToZero(vConversion))
					listError.add(getDUAError("1091",new String[] {"UNID_FIDES - ENVIADO:"+unid_fides+" TUNIISC - ENVIADO:"+tuniisc}));
			}
		}
	}

	/**
	 * Valida la unidad de medida.
	 * 
	 * @param mcnan Long
	 * @param mtunifis String
	 * @param mquni BigDecimal
	 * @param mpesoneto BigDecimal
	 * @return codigo de error
	 */
	private String valUnid(Long mcnan, String mtunifis, BigDecimal mquni, BigDecimal mpesoneto){
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		String error="0";
		boolean ok=true;
		HashMap<String, Object> params=new HashMap<String, Object>();
		params.put("cnan", mcnan);
		params.put("finivig", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
		params.put("ffinvig", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
		//		NandUniDAO nanduniDAO=FormatoAServiceImpl.getInstance().getNanduniDAO();
		//		List<NandUni> listNanduni=nanduniDAO.findNanduniByParams(params);
		List<NandUni> listNanduni=ayudaService.findNanduniByParams(params);
		if (listNanduni==null || listNanduni.isEmpty()){
			if (!SunatStringUtils.include(mtunifis,new String[]{"KG","KG6"}))
				ok=false;
		}else{
			for(NandUni nanduni:listNanduni){
				ok= (mtunifis==null?"":mtunifis).equals(nanduni.getUni())?true:false;
				if (ok)	break;
			}
			if (!ok)
				error="0117";
		}
		if (ok){
			BigDecimal mpesokg3=mpesoneto!=null?mpesoneto.divide(new BigDecimal(1000), 3, BigDecimal.ROUND_HALF_EVEN):null;
			BigDecimal mpesokg6=mpesoneto!=null?mpesoneto.divide(new BigDecimal(1000000), 3, BigDecimal.ROUND_HALF_EVEN):null;
			ok=!(("KG".equalsIgnoreCase(mtunifis) && !SunatNumberUtils.isEqual(mquni, mpesoneto) )|| 
					("KG3".equals(mtunifis) && !SunatNumberUtils.isEqual(mquni, mpesokg3)) || 
					("KG6".equals(mtunifis) && !SunatNumberUtils.isEqual(mquni, mpesokg6)));
			error=!ok?"0129":error;
		}//pruizcr pase 4
			if (esUnidadPesoVolumen(mtunifis) || esUnidadPesoVolumen(mtunifis)) {
				error = "40428";
			}

		return error;
	}
//pruizcr pase inicio PAS20181U220200004
	private boolean esUnidadPesoVolumen (String codigoUnidad){
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (catalogoAyudaService.getDataGrupoCat(ConstantesGrupoCatalogo.GRUPO_CATALOGO_PESOS_VOLUMEN, codigoUnidad) != null)
			return true;
		else
			return false;
	}
//pruizcr pase fin 4
	//glazaror... metodo optimizado... se evitan querys por cada serie
	private String valUnid(Map<Long, List<NandUni>> nanduniMap, Long mcnan, String mtunifis, BigDecimal mquni, BigDecimal mpesoneto){
		String error="0";
		boolean ok=true;
		/*HashMap<String, Object> params=new HashMap<String, Object>();
		params.put("cnan", mcnan);
		params.put("finivig", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
		params.put("ffinvig", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
		List<NandUni> listNanduni=ayudaService.findNanduniByParams(params);*/

		List<NandUni> listNanduni = nanduniMap.get(mcnan);

		if (listNanduni==null || listNanduni.isEmpty()){
			if (!SunatStringUtils.include(mtunifis,new String[]{"KG","KG6"}))
				ok=false;
		}else{
			for(NandUni nanduni:listNanduni){
				ok= (mtunifis==null?"":mtunifis).equals(nanduni.getUni())?true:false;
				if (ok)	break;
			}
			if (!ok)
				error="0117";
		}
		if (ok){
			BigDecimal mpesokg3=mpesoneto!=null?mpesoneto.divide(new BigDecimal(1000), 3, BigDecimal.ROUND_HALF_EVEN):null;
			BigDecimal mpesokg6=mpesoneto!=null?mpesoneto.divide(new BigDecimal(1000000), 3, BigDecimal.ROUND_HALF_EVEN):null;
			ok=!(("KG".equalsIgnoreCase(mtunifis) && !SunatNumberUtils.isEqual(mquni, mpesoneto) )|| 
					("KG3".equals(mtunifis) && !SunatNumberUtils.isEqual(mquni, mpesokg3)) || 
					("KG6".equals(mtunifis) && !SunatNumberUtils.isEqual(mquni, mpesokg6)));
			error=!ok?"0129":error;			
			//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(new Date()):false;
		    if(esVigenteRIN05SegundaParte && ok){
				if (esUnidadPesoVolumen(mtunifis)) {
					error = "40428";
				}
		    }
		}
		
	
		return error;
	}
/*
	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}

	public CodiLibeDAOService getCodiLibeDAOService() {
		return codiLibeDAOService;
	}

	public void setCodiLibeDAOService(CodiLibeDAOService codiLibeDAOService) {
		this.codiLibeDAOService = codiLibeDAOService;
	}

	public PackageTD getPackageTD() {
		return packageTD;
	}

	public void setPackageTD(PackageTD packageTD) {
		this.packageTD = packageTD;
	}	

	
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
