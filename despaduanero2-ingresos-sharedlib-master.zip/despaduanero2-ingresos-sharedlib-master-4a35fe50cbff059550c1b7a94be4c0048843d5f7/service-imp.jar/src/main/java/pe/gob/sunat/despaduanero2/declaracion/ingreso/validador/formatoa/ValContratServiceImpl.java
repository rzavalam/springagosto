package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FormatoAServiceImpl;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValContrat.
 * Clase sin funcion relacionada.
 * @deprecated Clase sin funcion relacionada.
 */
public class ValContratServiceImpl extends ValDuaAbstract implements  ValContrat{

	//private FabricaDeServicios fabricaDeServicios;
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

	/**
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numfactu String
	 * @return Map
	 */
	public Map<String, String> numfactu(String numfactu){
		return !SunatStringUtils.isEmptyTrim(numfactu)?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("00275","Error Contrato");
	}

	/**
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fecfactu Date
	 * @return Map
	 */
	public Map<String, String> fecfactu(Date fecfactu){
		return fecfactu!=null?new HashMap<String,String>():getDUAError("01047","Error Contrato");
	}

	/**
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtofobfact BigDecimal
	 * @return Map
	 */
	public Map<String, String> mtotfobfact(BigDecimal mtofobfact){
		return SunatNumberUtils.isGreaterThanZero(mtofobfact)?new HashMap<String,String>():getDUAError("30066","Error Contrato");
	}

	/**
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipodocexpo String
	 * @return Map
	 */
	public Map<String, String> codtipodocexpo(String codtipodocexpo){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("27", codtipodocexpo))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", codtipodocexpo,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30067","Error catalogo codtipodocexpo");	
	}

	/**
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numrucdocexpo String
	 * @return Map
	 */
	public Map<String, String> numrucdocexpo(String numrucdocexpo){
		return !SunatStringUtils.isEmptyTrim(numrucdocexpo)?new HashMap<String,String>():getDUAError("00290","Error Contrato");
	}

	/**
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param porparti BigDecimal
	 * @return Map
	 */
	public Map<String, String> porparti(BigDecimal porparti){
		return SunatNumberUtils.isGreaterThanZero(porparti)?new HashMap<String,String>():getDUAError("30068","Error Contrato");
	}

}
