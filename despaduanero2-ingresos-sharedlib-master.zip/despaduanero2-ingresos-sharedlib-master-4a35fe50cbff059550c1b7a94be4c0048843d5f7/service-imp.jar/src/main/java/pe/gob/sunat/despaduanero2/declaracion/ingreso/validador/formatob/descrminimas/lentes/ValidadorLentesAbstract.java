package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.lentes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
/**
 * 
 * @author lalberti
 *
 */
public class ValidadorLentesAbstract extends ValidadorAbstract
{
  protected static final String LENT_CONT_CORREC = "LCC";
  protected static final String LENT_CON_COSMET  = "LCM";
  protected static final String MONTURAS         = "MNT";
  protected static final String LEN_CORRECT      = "LCR";
  protected static final String GAFAS_SOL        = "GFS";
  protected static final String GAFAS_CORRECT    = "GCC";
  protected static final String TITANIO          = "TTN";
  protected static final String METAL            = "MET";
  protected static final String PLASTICO         = "PLA";
  protected static final String CRISTAL          = "CRT";
  protected static final String RESINA           = "RSN";
  protected static final String POLICARBONATO    = "PCB";
  protected static final String COD_ZZZ = "1";
  private static final String ASOC_PART_NOMBRE   = "022";
  private static final String TIPO_BLANDO        = "BLD";
  private static final String ESFERICOS          = "ESF";
  private static final String CILINDRICOS        = "CIL";
  private static final String COMBINADOS         = "COM";
  private static final String LEN_MONOFOCAL      = "MFC";
  private static final String ACAB_TERM          = "TRM";
  private static final String CONVENCIONAL       = "CON";
  private static final String DESECHABLE         = "DES";
//  private static final String CATALOGO_MEDIDA    = "T0";
  
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    // TODO Auto-generated method stub
    return null;
  }

  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract object, DatoItem item, Date fechaVigente){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesAbstract lentes = (LentesAbstract) object;
    String datoAValidar = lentes.getNombreComercial().getValtipdescri();
    String partida = item.getNumpartnandi().toString();
    //if(noEstaCorrelacionado( partida,datoAValidar, ASOC_PART_NOMBRE)){
    if(noEstaCorrelacionado( partida,datoAValidar, ASOC_PART_NOMBRE, fechaVigente)){
    	String[] args = new String[]{partida};
    	lst.add(obtenerError("31445",lentes.getNombreComercial(),args));
    }
    return lst;
  }
  
  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarModelo(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarMaterial(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarMedida(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarTipoLente(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesAbstract lente = (LentesAbstract) object;
    String nombreComercial = lente.getNombreComercial().getValtipdescri();
    String datoAValidar = lente.getTipoLente().getValtipdescri();
    if(Arrays.asList(LENT_CONT_CORREC, LENT_CON_COSMET).contains(nombreComercial)){
        if(SunatStringUtils.isEmpty(datoAValidar)){
        	lst.add(obtenerError("31453", lente.getTipoLente()));
        }else{ 
        	String uso = lente.getUsoLenteContacto().getValtipdescri();
        	if(SunatStringUtils.isEqualTo(TIPO_BLANDO,datoAValidar)){        	
	        	if(SunatStringUtils.isEmpty(uso)){
	        		lst.add(obtenerError("31456", lente.getUsoLenteContacto()));
	        	}else if(!Arrays.asList(CONVENCIONAL,DESECHABLE).contains(uso)){
	        		lst.add(obtenerError("31457", lente.getUsoLenteContacto()));
	        	}
        	}else if(!SunatStringUtils.isEmpty(uso)){
        		lst.add(obtenerError("31458", lente.getUsoLenteContacto()));
        	}
        }
    }else if(!SunatStringUtils.isEmpty(datoAValidar)){
    	String[] args = new String[]{nombreComercial};
    	lst.add(obtenerError("31455", lente.getTipoLente(),args));
    }
    return lst;
  }
  
  public List<ErrorDescrMinima> validarNroFocos(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesAbstract lentes = (LentesAbstract) object;
    String nombreComercial = lentes.getNombreComercial().getValtipdescri();
    String nroFocos = lentes.getNumeroFocos().getValtipdescri();    
    if(SunatStringUtils.isEqualTo(LEN_CORRECT,nombreComercial) || 
       SunatStringUtils.isEqualTo(GAFAS_CORRECT,nombreComercial)){
       if(!Arrays.asList(LEN_MONOFOCAL,"BFC","BFE","BFF","BFU","PRG").contains(nroFocos)){
    	   String[] args = new String[]{nombreComercial};
    	   lst.add(obtenerError("31459",lentes.getNumeroFocos(),args));
       }else {
         String tipoNroFoco = lentes.getTipoNumeroFocos().getValtipdescri();
         if(SunatStringUtils.isEqualTo(LEN_MONOFOCAL,nroFocos) && 
        	!Arrays.asList(ESFERICOS,CILINDRICOS,COMBINADOS).contains(tipoNroFoco)){
        	 String[] args = new String[]{nombreComercial};
           lst.add(obtenerError("31461",lentes.getNumeroFocos(),args));
         }         
       }
    }else if(!(SunatStringUtils.isEqualTo(LEN_CORRECT,nombreComercial) || 
    	       SunatStringUtils.isEqualTo(GAFAS_CORRECT,nombreComercial)) &&
    		!SunatStringUtils.isEmptyTrim(nroFocos)){
    	String[] args = new String[]{nombreComercial};
      lst.add(obtenerError("31460",lentes.getNumeroFocos(),args));
    }
    
    return lst;
  }
  
  public List<ErrorDescrMinima> validarColor(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesAbstract lentes = (LentesAbstract) object;
    String nombreComercial = lentes.getNombreComercial().getValtipdescri();
    String datoAValidar = lentes.getColor().getValtipdescri();
    Boolean esObligatorio = Arrays.asList(LEN_CORRECT, GAFAS_CORRECT, 
    						LENT_CONT_CORREC,LENT_CON_COSMET).contains(nombreComercial);
    
    if(esObligatorio){
    	if(SunatStringUtils.isEmptyTrim(datoAValidar)){
    		String[] args =  new String[]{nombreComercial};
    		lst.add(obtenerError("31462",lentes.getColor(),args));
    	}
    }else{
    	if(!SunatStringUtils.isEmpty(datoAValidar)){
    		String[] args =  new String[]{nombreComercial};
    		lst.add(obtenerError("31463",lentes.getColor(),args));
    	}
    }
    return lst;
    
  }
  
  public List<ErrorDescrMinima> validarTratamiento(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();

    Date fechaVigencia = object.getFechaIniVigenciaValidador();//AREY-MIN PASE137
    LentesAbstract lentes = (LentesAbstract) object;
    String nombreComercial = lentes.getNombreComercial().getValtipdescri();
    String tratamiento = lentes.getTratamiento().getValtipdescri();
    String[] args =  new String[]{nombreComercial};
    if(SunatStringUtils.isEqualTo(LEN_CORRECT,nombreComercial) || 
         SunatStringUtils.isEqualTo(GAFAS_CORRECT,nombreComercial)){ 
    	if(noEstaEnCatalogo(tratamiento, "T1",fechaVigencia))
    		lst.add(obtenerError("31464",lentes.getTratamiento(),args));
    }else if(!SunatStringUtils.isEmpty(tratamiento)){
    	lst.add(obtenerError("31465",lentes.getTratamiento(),args));
    }
    return lst;
  }
  
  public List<ErrorDescrMinima> validarAcabado(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesAbstract lentes = (LentesAbstract) object;
    String nombreComercial = lentes.getNombreComercial().getValtipdescri();
    String acabado = lentes.getAcabado().getValtipdescri();
    String[] args =  new String[]{nombreComercial};
    if(SunatStringUtils.isEqualTo(LEN_CORRECT,nombreComercial)){
        if(SunatStringUtils.isEmpty(acabado)){
        	lst.add(obtenerError("31466",lentes.getAcabado(),args));
        }
    }else{
    	if(!SunatStringUtils.isEmpty(acabado)){
    		lst.add(obtenerError("31467",lentes.getAcabado(),args));
        }
    }
    return lst;
  }
  
  public List<ErrorDescrMinima> validarSeriesDeMedida(ModelAbstract object){
	  List<ErrorDescrMinima> lst =  new ArrayList<ErrorDescrMinima>();
	  LentesAbstract lentes = (LentesAbstract) object;
	  String datoAValidar = lentes.getSeriesDeMedida().getValtipdescri();
	  String nombreComercial =  lentes.getNombreComercial().getValtipdescri();
	  String acabado =  lentes.getAcabado().getValtipdescri();
	  String[]args = new String[]{nombreComercial};
	  if(SunatStringUtils.isEqualTo(nombreComercial, GAFAS_CORRECT)){
		  if(SunatStringUtils.isEmptyTrim(datoAValidar)){
			  lst.add(obtenerError("31446",lentes.getSeriesDeMedida(),args));
		  }		  
	  }else if(SunatStringUtils.isEqualTo(nombreComercial, LEN_CORRECT)){
		  if(SunatStringUtils.isEqualTo(acabado, ACAB_TERM) &&
			 SunatStringUtils.isEmptyTrim(datoAValidar)){
			  lst.add(obtenerError("31446",lentes.getSeriesDeMedida(),args));
		  }
	  }else{
		  if(!SunatStringUtils.isEmpty(datoAValidar)){
			  lst.add(obtenerError("31452",lentes.getSeriesDeMedida(),args));
		  }
	  }
	  return lst;  
  }
} 
