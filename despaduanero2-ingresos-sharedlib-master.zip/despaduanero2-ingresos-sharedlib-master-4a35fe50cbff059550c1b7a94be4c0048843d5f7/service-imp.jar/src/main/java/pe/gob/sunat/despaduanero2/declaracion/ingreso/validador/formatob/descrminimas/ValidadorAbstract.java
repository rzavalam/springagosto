package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas;


import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.*;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima.tipoHEAD;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima.tipoValidacion;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValItemFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValidacionFormatoB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;


/**
 * Esta clase contiene la l�gica de infraestructura que da acceso a servicios de
 * validaciones de catalogos de uso general para todas las implementaciones de
 * Validador que extienden de esta.
 *
 * @author amancillaa
 * @version 1.0
 * @since 13/12/2013
 */
public abstract class ValidadorAbstract extends ValidacionFormatoB
{


	private static final String TIPO_VALOR_CATALOGO = "0";
	private static final String TIPO_VALOR_TEXTO_ZZZ = "1";
	public static final int CAMPO_ACEPTA_CATALOGO_Y_ZZZ = 2;
	/* private String[] lstCodigosValidosdIndicadorSNTT1 = new String[] { "VE0000", "VE0001", "VE0002", "VE0029", "VE0012", "VE0013", "VE0014", "VE0003", "VE0004", "VE0005", "VE0010", "VE0017", "VE0018", "VE0019", "VE0020", "VE0007","VE0011"};
	private static final String CATALOGO_ERRORES = "F09";//PAS20155E220000407
	private String[] lstCodigosAutoExcluyentesSNTT1 = new String[] { "VE0012", "VE0013","VE0011"};//PAS20155E220000407, se retir� VE0008 ya que es opcional para SNTT1
	private String[] lstExoneradosChasisMotorizadoSNTT1 = new String[] {"VE0004","VE0060","VE0017","VE0021","VE0070","VE0071"};//PAS20155E220000407 exonerados por CHASIS MOTORIZADO

	private String[] lstExoneradosProvisionalSNTT1 = new String[] {"VE0005","VE0010","VE0017","VE0018","VE0019","VE0020","VE0014"};//PAS20155E220000425 exonerados por revisar validaci�n individual
	 *///se puso en el validadorVehiculo correspondiente PAS20165E220200137
	public static final String CHASIS_MOTORIZADO = "CHM";
	public static final String CAMPO_CARROCERIA = "VE0003";
	/**
	 * Ejecutar validaciones.
	 *
	 * @param objeto
	 *          [DescrMinimaAbstract] objeto
	 * @param dua
	 *          [Declaracion] dua
	 * @return [List<ErrorDescrMinima>] list
	 * @author amancillaa
	 * @version 1.0
	 */
	public abstract List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception;

	/**
	 * Validar estructura.
	 *
	 * @param objeto
	 *          [DescrMinimaAbstract] objeto
	 * @return [List<ErrorDescrMinima>] list
	 * @author amancillaa
	 * @version 1.0
	 * @throws Exception
	 */
	public List<ErrorDescrMinima> validarEstructura(ModelAbstract objeto) throws Exception
	{


		List<ErrorDescrMinima> lstErrores = new ArrayList<ErrorDescrMinima>();
		ErrorDescrMinima error = null;

		//rtineo mejoras, metodo mejorado
		Map<String,Object> variablesIngreso = objeto.getMapCatalogos();

		Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PAS20165E220200137

		lstErrores.addAll(validarTAGcodtipdescri(objeto,variablesIngreso)); //tiene catalogo
		//rtineo fin

		// es considerado error fatal ya no continua con las demas
		if (CollectionUtils.isEmpty(lstErrores))
		{
			for (DatoDescrMinima dato : objeto.getLstDatos())
			{
				//rtineo mejoras
				error = validarTAGcodtipvalor(dato,fechaVigencia, variablesIngreso);//consulta catalogo
				if (error != null)
				{
					lstErrores.add(error);
					objeto.agregarErrror(error);
				}
				/*
				 * error = validarTAGcodtipdescri(dato); if(error!=null){
				 * lstErrores.add(error); objeto.agregarErrror(error); }
				 */
				error = validarTAGvaltipdescr(dato);
				if (error != null)
				{
					lstErrores.add(error);
					objeto.agregarErrror(error);
				}

				error = validarTAGcodtipvalorVSDescrPosicion(dato);
				if (error != null)
				{
					lstErrores.add(error);
					objeto.agregarErrror(error);
				}

				//rtineo mejoras
				error = validarPertenezcaCodigoAlCatalogo(dato,fechaVigencia,variablesIngreso); //consulta catalogo
				if (error != null)
				{
					lstErrores.add(error);
					objeto.agregarErrror(error);
				}

				error = validarExpresionRegular(dato, fechaVigencia);//se incorpora la vigencia
				if (error != null)
				{
					lstErrores.add(error);
					objeto.agregarErrror(error);
				}

				//rtineo mejoras
				List<ErrorDescrMinima> lista = validarZZZ(dato,fechaVigencia,variablesIngreso);
				lstErrores.addAll(lista);

				for (ErrorDescrMinima error1 : lista)
				{
					objeto.agregarErrror(error1);
				}

			}

			//		Se coloc� en el validadorVehiculo correspondiente PAS20165E220200137
			//        if(objeto instanceof Vehiculo){
			//            Vehiculo vehiculo = (Vehiculo) objeto;
			//            String IndicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri().trim();
			//            if("1".equalsIgnoreCase(IndicadorSNTT)){ //Caso especial SNTT "1" R641
			//                lstErrores.addAll(validarMandatoriedadSNTT1(vehiculo));
			//                lstErrores.addAll(validarMandatoriedad(objeto));
			//            }else{
			//                lstErrores.addAll(validarMandatoriedad(objeto));
			//            }
			//        }else{
			lstErrores.addAll(validarMandatoriedad(objeto));
			//        }

		}


		return lstErrores;
	}

	//    private List<ErrorDescrMinima> validarMandatoriedadSNTT1(Vehiculo objeto)
	//   {
	//       List<ErrorDescrMinima> lstErrores = new ArrayList<ErrorDescrMinima>();
	//
	//       //amancilla se debe evaluar que se envien los objetos obligatorios
	//       int codigosAutoExclSNTT1 = 0;
	//       boolean esChasisMotorizado = false;
	//       for(String codigoSNTT1QueDebeEnviar: lstCodigosValidosdIndicadorSNTT1){
	//
	//           boolean seEncontroCodigoObligatorio = false;
	//           String numSecProveedor = "";
	//           String numSecFactura = "";
	//           String numSecItem = "";
	//         
	//           for (DatoDescrMinima dato : objeto.getLstDatos()){
	//               String codigoSNTT1QueHaEnviado =dato.getCodtipdescr();
	//
	//               numSecProveedor = dato.getNumsecprove().toString();
	//               numSecFactura = dato.getNumsecfact().toString();
	//               numSecItem = dato.getNumsecitem().toString();
	//
	//               if(codigoSNTT1QueHaEnviado.equals(CAMPO_CARROCERIA)){
	//            	   esChasisMotorizado = dato.getValtipdescri().trim().equals(CHASIS_MOTORIZADO)?true:false;
	//               }
	//
	//               if(codigoSNTT1QueDebeEnviar.equals(codigoSNTT1QueHaEnviado)){
	//                   seEncontroCodigoObligatorio = true;
	//                   break;
	//               }
	//               
	////             inicio gmontoya Pase PAS20155E220000425
	//                   /*Inicio ajustes PAS20155E220000407*/
	//                   if(SunatStringUtils.isStringInList(codigoSNTT1QueHaEnviado,lstCodigosAutoExcluyentesSNTT1)){
	//                	   codigosAutoExclSNTT1=codigosAutoExclSNTT1+1;
	//                   }
	//                   /*Fin ajustes PAS20155E220000407*/
	////               fin gmontoya Pase PAS20155E220000425
	//               
	//               /*Inicio ajustes PAS20155E220000407
	//                *En relaci�n a las descripciones m�nimas de veh�culos, se requiere adecuar las validaciones a efectos que cuando se consigne 
	//                *como carrocer�a tipo Chasis Motorizado (c�digo CHM), sea que haya declarado como indicador SNTT el c�digo 0 o 1., no se exija
	//                * la transmisi�n de los siguientes datos:N�mero de puertas, N�mero de asientos,N�mero de pasajeros,Marca de carrocer�a,
	//                * N�mero de carrocer�a,	Color principal*/
	//               if(esChasisMotorizado && SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, lstExoneradosChasisMotorizadoSNTT1)){
	//            	   seEncontroCodigoObligatorio = true;
	//                   break;
	//               }
	//               /*Fin ajustes PAS20155E220000407*/               
	//               /*inicio ajustes PAS20155E220000425*/
	//               if(SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, lstExoneradosProvisionalSNTT1)){
	//            	   seEncontroCodigoObligatorio = true;
	//                   break;
	//               }
	//               /*Fin ajustes PAS20155E220000425*/
	//           }
	//
	//           if(!seEncontroCodigoObligatorio){
	//
	//               StringBuilder campo = new StringBuilder(codigoSNTT1QueDebeEnviar);
	//               campo.append("-");
	//               campo.append(obtenerDescripcionDelCalogo("500", codigoSNTT1QueDebeEnviar));
	//
	//               Object[] parametros = new Object[]{numSecProveedor,numSecFactura, numSecItem,campo};
	//               //ErrorDescrMinima error = new ErrorDescrMinima("35600","Secuencia de Proveedor:({0}),Secuencia de Factura:({1}),Secuencia del Item:({2}), Mensaje: debe consigar ({3}) cuando el indicador de SNTT se transmita el codigo 1.");
	//               //error.setParametros(parametros);		
	//               ErrorDescrMinima error = new ErrorDescrMinima("", "35600", catalogoAyudaService.getDataCatalogo(CATALOGO_ERRORES, "35600").getDesDatacat(), 
	//						ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,parametros); //mostrar msj completo PAS20155E220000407
	//
	//               if(!SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, lstCodigosAutoExcluyentesSNTT1)){
	//            	   lstErrores.add(error);
	//            	   objeto.agregarErrror(error);
	//               }else if(SunatStringUtils.isStringInList(codigoSNTT1QueDebeEnviar, lstCodigosAutoExcluyentesSNTT1) && codigosAutoExclSNTT1<1){ 
	//               lstErrores.add(error);
	//               objeto.agregarErrror(error);
	//           }
	//		       //lstErrores.add(error);
	//               //objeto.agregarErrror(error);
	//        	   }
	//       }
	//
	//
	//       /* se comenta codigo amancilla  SAU201510002000065
	//       for (DatoDescrMinima dato : objeto.getLstDatos())
	//       {
	//           if (!ArrayUtils.contains(lstCodigosValidosdIndicadorSNTT1,dato.getCodtipdescr())){
	//
	//               StringBuilder campo = new StringBuilder(dato.getCodtipdescr());
	//               campo.append("-");
	//               campo.append(obtenerDescripcionDelCalogo("500", dato.getCodtipdescr()));
	//
	//               Object[] argumentos = new Object[] { campo };
	//               ErrorDescrMinima error = obtenerError("30896",dato, argumentos);
	//               lstErrores.add(error);
	//               objeto.agregarErrror(error);
	//           }
	//       }*/
	//
	//       return lstErrores;
	//    }


	/**
	 * ******************* METODOS COMUNES A LOS HIJOS **************************.
	 *
	 * @param dato
	 *          [String] dato
	 * @param min
	 *          [int] min
	 * @param Max
	 *          [int] max
	 * @return true, if successful
	 */

	protected boolean noCumpleRango(String dato, int min, int Max)
	{
		Integer dato_int = Integer.parseInt(dato);

		return (dato_int >= min && dato_int <= Max) ? false : true;
	}

	/**
	 * Quitar errror.
	 *
	 * @param origen
	 *          [String] origen
	 * @return [List<ErrorDescrMinima>] list
	 * @author amancillaa
	 * @version 1.0
	 */
	protected List<ErrorDescrMinima> quitarErrror(String origen, ModelAbstract objeto)
	{

		objeto.eliminarError(origen);

		return objeto.getLstErrores();
	}

	protected List<ErrorDescrMinima> reemplazarErrror(String origen,
			ModelAbstract objeto,
			ErrorDescrMinima errorReemplazar)
	{

		objeto.reemplazarError(origen, errorReemplazar);

		return objeto.getLstErrores();
	}

	protected List<DatoDescrMinima>
	obtenerCodigodEnviadosNOCorrespondenTipoDescrMinima(ModelAbstract objeto) throws Exception
	{

		return objeto.obtenerCodigodEnviadosNOCorrespondenTipoDescrMinima();
	}


	protected boolean rucVigenteEnCatalogoConveniosCodigosLiberatorio(String[] tipoUso,
			String clib,
			String tipoDoc,
			String numDoc,
			String aduana)
	{
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		return funcionesService.existsInCatRefRuc(tipoUso, clib, tipoDoc, numDoc, aduana);
	}


	/**
	 * Tiene errror.
	 *
	 * @param origen
	 *          [String] origen
	 * @return true, if successful
	 */
	protected boolean tieneErrror(String origen, ModelAbstract objeto)
	{
		return objeto.tieneErrror(origen);
	}

	/**
	 * Cumple expresion regular.
	 *
	 * @param cadena
	 *          [String] cadena
	 * @param expresionRegular
	 *          [String] expresion regular
	 * @return true, if successful
	 */
	protected boolean cumpleExpresionRegular(String cadena, String expresionRegular)
	{
		boolean result = false;
		// Aqui va la expresion regular
		Pattern p = Pattern.compile(expresionRegular, Pattern.MULTILINE);
		// aqui el valor que quieren probar
		Matcher matcher = p.matcher(cadena);
		// true si es correcto, false si es incorreto
		result = matcher.matches();
		return result;

	}

	protected boolean noCumpleExpresionRegular(String cadena, String expresionRegular)
	{

		return !cumpleExpresionRegular(cadena, expresionRegular);

	}
	/**
	 * No esta correlacionado.
	 *
	 * @param datoAValidar
	 *          [String] dato a validar
	 * @param partida
	 *          [String] sub partida
	 * @param codigoAsociacionCatalogo
	 *          [String] codigo asociacion catalogo
	 * @return true, if successful
	 */
	protected boolean estaCorrelacionado(String datoAValidar, String partida, String codigoAsociacionCatalogo, Date fechaVigencia)
	{

		/*    List<Map<String, String>> lista =
        getCatalogoHelper().getCatalogoAyudaService()
        .getListaElementosAsoc(codigoAsociacionCatalogo,
                               "C", datoAValidar, fechaVigencia!=null?fechaVigencia:new Date());//considerar la fecha
		 */
		//actualizacion que tome la vigencia PAS20165E220200137
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> lista = catalogoAyudaService.getListaElementosAsoc(codigoAsociacionCatalogo, "C", datoAValidar, fechaVigencia!=null?fechaVigencia:new Date());


		// debe retornar 1 solo 1 partida pertence a un tipo de descr minima en
		// teoria se ha encontrado que para casos donde el nombre comercial esta
		// relacionado a varias partidas
		// por eso la relacion es de 1 a muchos se pone for

		if (!CollectionUtils.isEmpty(lista))
		{
			for (Map<String, String> mapa : lista)
			{
				String partidaRelacionada = mapa.get("cod_datacat");
				if (partida.equals(partidaRelacionada))
				{
					return true;
				}
			}
		}

		return false;
	}

	protected boolean noEstaCorrelacionado(String datoAValidar, String partida, String codigoAsociacionCatalogo, Date fechaVigencia)
	{
		return !estaCorrelacionado(datoAValidar, partida, codigoAsociacionCatalogo, fechaVigencia);
	}

	/**
	 * Convertir errores.
	 *
	 * @param lstErroresDescrMin
	 *          [List<ErrorDescrMinima>] lst errores descr min
	 * @return [List<Map<String,String>>] list
	 * @author amancillaa
	 * @version 1.0
	 */
	public List<Map<String, String>> convertirErrores(List<ErrorDescrMinima> lstErroresDescrMin)
	{

		List<Map<String, String>> lstErrores = new ArrayList<Map<String, String>>();

		for (ErrorDescrMinima errorDescrMinima : lstErroresDescrMin)
		{
			Map<String, String> error = new HashMap<String, String>();
			error.put(ResponseMapManager.KEY_CODIGO, errorDescrMinima.getCodigo());
			error.put(ResponseMapManager.KEY_DESCRIPCION, errorDescrMinima.getDetalle());
			lstErrores.add(error);
		}


		return lstErrores;
	}

	public DatoSerie obtenerSerie(ModelAbstract objeto, Declaracion dua)
	{
		ValItemFB valItemFB =   fabricaDeServicios.getService("ValItemFB");
		DatoItem item = obtenerItem(objeto, dua);

		return valItemFB.getSerieCorrespondiente(item, dua);
	}

	public DatoItem obtenerItem(ModelAbstract objeto, Declaracion dua)
	{

		Integer numSecItem = objeto.getNumsecitem();
		for (DAV dav : dua.getListDAVs())
		{
			for (DatoFactura factura : dav.getListFacturas())
			{
				for (DatoItem item : factura.getListItems())
				{
					if (SunatNumberUtils.isEqual(numSecItem, item.getNumsecitem()))
					{
						return item;
					}
				}
			}
		}

		return null;

	}


	public String obtenerTipoUso(String numPartida, ModelAbstract objeto)
	{
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Integer fechaIngSi = SunatNumberUtils.getTodayAsInteger();

		String tipoUso = funcionesService.fnTipo(numPartida, objeto.getNombreComercial().getValtipdescri(), "", fechaIngSi);

		return tipoUso;
	}

	protected List<DatoDocTransporte> obtenerDocTransporte(ModelAbstract objeto, Declaracion dua)
	{

		List<DatoDocTransporte> lstDocTransDeLaSerie = new ArrayList<DatoDocTransporte>();

		Integer serieFiltrar = obtenerSerie(objeto, dua).getNumserie();
		for (DatoDocTransporte docTrans : dua.getDua().getListDocTransporte())
		{
			if (docTrans.getNumserie().compareTo(serieFiltrar) == 0)
			{
				lstDocTransDeLaSerie.add(docTrans);
			}
		}

		return lstDocTransDeLaSerie;

	}

	public boolean noEstaEnCatalogo(String codigoABuscar,String codigoCatalogo,Date fechaVigencia)
	{

		return !estaEnCatalogo(codigoABuscar, codigoCatalogo,fechaVigencia, null);

	}

	//rtineo mejoras, metodo sobrecargado
	public boolean noEstaEnCatalogo(String codigoABuscar,String codigoCatalogo,Date fechaVigencia, Map<String,Object> variablesIngreso)
	{

		return !estaEnCatalogo(codigoABuscar, codigoCatalogo,fechaVigencia, variablesIngreso);

	}

	public boolean estaEnCatalogo(String codigoABuscar, String codigoCatalogo, Date fechaVigencia)
	{
		return estaEnCatalogo(codigoABuscar,codigoCatalogo,fechaVigencia, null);
	}

	//rtineo mejoras, metodo sobrecargado 
	public boolean estaEnCatalogo(String codigoABuscar, String codigoCatalogo, Date fechaVigencia,  Map<String,Object> variablesIngreso)
	{
		boolean existe = false;
		//amancilla error fix REQ 2016-090199 error de null al rectificar
		if(SunatStringUtils.isEmpty(codigoABuscar)){
			return false;
		}

		codigoABuscar = codigoABuscar.trim();
		//no debe de validar un codigo ZZ o ZZZ
		if (!ArrayUtils.contains(new String[] { "ZZ", "ZZZ" },codigoABuscar)){

			/* por alguna razon la libreria de catalogo convierte el codigo enviado a MAYUSCULAS por eso no se usa*/
			//Map descCatalogo = getCatalogoHelper().getCatalogoAyudaService().getElementoCat(codigoCatalogo, codigoABuscar);
			//rtineo mejoras,
			DataCatalogo dataCatalogo =null;
			//rtineo pase PAS20155E220400025 
			if(variablesIngreso != null){
				dataCatalogo = IngresoVariablesUtil.obtenerCatalogo(fabricaDeServicios, codigoCatalogo, codigoABuscar, variablesIngreso, fechaVigencia);
			}else{
				//rtineo se continua con metodo antiguo
    		  //dataCatalogo = getCatalogoHelper().getCatalogoAyudaService().getDataCatalogo(codigoCatalogo, codigoABuscar, fechaVigencia);
    		  //se actualiza con la busqueda de catalogoAyuda: PAS20171U220200016
    		  //codigoABuscar = IngresoVariablesUtil.convertirParaRest(codigoABuscar);//atencion REQ 2016-117779//consulta no es REST es bd: INC 2018-059088 
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				dataCatalogo = catalogoAyudaService.getDataCatalogo(codigoCatalogo, codigoABuscar, fechaVigencia);
			}
			//rtineo fin mejoras

			/*if(dataCatalogo==null)
          {
              if (getFuncionesService().existsInTabDescMinByTipoAndCodigo(codigoCatalogo, codigoABuscar,SunatNumberUtils.getTodayAsInteger())){
                  existe=true;
              }
          }
          else*///ahora buscara unicamente de datacatalogo PAS20165E220200137
			if(dataCatalogo!=null)
			{
				existe = true;
			}
		}

		return existe;
	}

	// permite verificar que se encuentre la descripcion de una DM ya sea en los catalogos del Nsigas o del Asigad
	public String obtenerDescripcionCatalogo(String codigoABuscar, String codigoCatalogo) {
		String descripcion="";
		codigoABuscar = codigoABuscar.trim();
		if (!ArrayUtils.contains(new String[] { "ZZ", "ZZZ" },codigoABuscar)){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			DataCatalogo dataCatalogo = catalogoAyudaService.getDataCatalogo(codigoCatalogo, codigoABuscar);
			if(dataCatalogo==null) {
				ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
				descripcion=funcionesService.getDescripcionTabDescMin(codigoABuscar, codigoCatalogo).get(0).getValtipdescri();
			} else
				descripcion=dataCatalogo.getDesDatacat();
		}
		return descripcion;
	}

	private boolean estaEnDescripcionDelCatalogo(String cadenaBuscar, String codigoCatalogo,Map<String,Object> variablesIngreso)
	{
		return   estaEnDescripcionDelCatalogo( cadenaBuscar,  codigoCatalogo, variablesIngreso,  new Date());
	}
	private boolean estaEnDescripcionDelCatalogo(String cadenaBuscar, String codigoCatalogo,Map<String,Object> variablesIngreso, Date fechaVigencia)
	{
		boolean existe = false;
		cadenaBuscar = cadenaBuscar.trim();
		cadenaBuscar = cadenaBuscar.toUpperCase();
		//rtineo mejoras
		if(variablesIngreso != null){
			existe = IngresoVariablesUtil.estaEnDescripcionCatalogo(fabricaDeServicios, codigoCatalogo, cadenaBuscar, variablesIngreso, fechaVigencia);
		}else{
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			List<Map<String,String>> lstCatalogos = catalogoAyudaService.getElementosCat(codigoCatalogo,fechaVigencia);
			for ( Map mapCatalogo: lstCatalogos){
				String desc = obtenerDescripcionDelCalogo(codigoCatalogo,mapCatalogo.get("cod_datacat").toString());
				if( cadenaBuscar.equals(desc.toUpperCase())){
					existe = true;
				}
			}
		}
		return existe;
	}
	//rtineo mejoras, sobrecargamos el metodo
	public boolean estaEnSubGrupoCatalogo(String codigoGrupo, String codigoABuscar){
		return estaEnSubGrupoCatalogo(codigoGrupo, codigoABuscar, null);
	}
	public boolean estaEnSubGrupoCatalogo(String codigoGrupo, String codigoABuscar, Map<String,Object> variablesIngreso)
	{
		//rtineo mejoras
		DataGrupoCat grupo=null;
		if(variablesIngreso != null){
			grupo = IngresoVariablesUtil.estaEnSubGrupoCatalogo(fabricaDeServicios, codigoGrupo, codigoABuscar, variablesIngreso);
		}else{
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			grupo = catalogoAyudaService.getDataGrupoCat(codigoGrupo, codigoABuscar);
		}
		return grupo != null && !SunatStringUtils.isEmpty(grupo.getCodDatacat()) ? true : false;
	}

	//rtineo mejoras, sobrecargamos el metodo
	public boolean noestaEnSubGrupoCatalogo(String codigoGrupo, String codigoABuscar){
		return noestaEnSubGrupoCatalogo(codigoGrupo, codigoABuscar, null);
	}
	public boolean noestaEnSubGrupoCatalogo(String codigoGrupo, String codigoABuscar, Map<String, Object> variablesIngreso)
	{
		return !estaEnSubGrupoCatalogo(codigoGrupo, codigoABuscar, variablesIngreso);
	}

	protected ErrorDescrMinima crearError(String codigoError, DescrPosicion
			posicion,   ModelAbstract objeto)
	{

		String origen = posicion.getCodigoCampo();
		String detalle = obtenerMsjErrorCatalogo(codigoError);
		Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//vigencia PAS20165E220200137
		StringBuilder campo = new StringBuilder(origen);
		campo.append("-");
		campo.append(obtenerDescripcionDelCalogo("500", origen, fechaVigencia));

		String nombreDescrMinima = obtenerDescripcionDelCalogo("393", posicion.getCodigoTipoDescrMinima());
		Object[] argumentos = new Object[] { objeto.getNumsecprove(), objeto.getNumsecfact(), objeto.getNumsecitem(), campo, campo, nombreDescrMinima };
		return new ErrorDescrMinima(origen, codigoError, detalle, ErrorDescrMinima.tipoHEAD.HEAD_CODTIPDESCRI, argumentos);

	}

	protected ErrorDescrMinima obtenerError(String codigoError, DatoDescrMinima dato)
	{

		return crearError(codigoError, dato, ErrorDescrMinima.tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR, new Object[] {});

	}

	protected ErrorDescrMinima obtenerError(String codigoError, DatoDescrMinima dato, Object[] argumentos)
	{

		return crearError(codigoError, dato, ErrorDescrMinima.tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR, argumentos);

	}

	protected ErrorDescrMinima crearError(String codigoError, DatoDescrMinima
			dato, ErrorDescrMinima.tipoHEAD tipo, ErrorDescrMinima.tipoValidacion tipoV, Date fechaVigencia)
	{

		return crearError(codigoError, dato, tipo, new Object[] {}, tipoV, fechaVigencia);//se incorpora la vigencia

	}

	protected ErrorDescrMinima crearError(String codigoError, DatoDescrMinima
			dato, ErrorDescrMinima.tipoHEAD tipo)
	{

		return crearError(codigoError, dato, tipo, new Object[] {});//se incorpora la vigencia

	}

	protected ErrorDescrMinima crearError(String codigoError, DatoDescrMinima
			dato,
			ErrorDescrMinima.tipoHEAD tipo,
			Object[] otrosArgumentos)
	{
		return crearError(codigoError, dato, tipo, otrosArgumentos, null, null);//se incorpora la vigencia
	}

	/*
    mensaje de errror para codigos que no pertence a descr minimas pero que se valida dentro
	 */
	protected ErrorDescrMinima obtenerError(String codigoError,
			ErrorDescrMinima.tipoHEAD tipo,
			Object[] otrosArgumentos)
	{

		String detalle = obtenerMsjErrorCatalogo(codigoError);

		return new ErrorDescrMinima("", codigoError, detalle, tipo,otrosArgumentos);
	}

	protected ErrorDescrMinima crearError(String codigoError, DatoDescrMinima
			dato,
			ErrorDescrMinima.tipoHEAD tipo,
			Object[] otrosArgumentos,
			ErrorDescrMinima.tipoValidacion tipoV, Date fechaVigencia)
	{

		String origen  = "";
		if (tipoV != null)
		{
			origen = dato.getCodtipdescr() + tipoV.getCodigo();
		}
		else
		{
			origen = dato.getCodtipdescr();
		}

		String detalle = obtenerMsjErrorCatalogo(codigoError);

		Object[] argumentos = new Object[] {};

		StringBuilder nemonico = new StringBuilder();

		switch (tipo)
		{
		case HEAD_CODTIPDESCRI_VALTIPDESCR:

			nemonico.append(dato.getCodtipdescr());
			nemonico.append("-");
			nemonico.append(obtenerDescripcionDelCalogo("500", dato.getCodtipdescr(),fechaVigencia));//se incorpora la vigencia

			argumentos =
					new Object[] { dato.getNumsecprove(), dato.getNumsecfact(), dato.getNumsecitem(), nemonico,
							dato.getValtipdescri() };

			break;
		case HEAD_CODTIPDESCRI:

			nemonico.append(dato.getCodtipdescr());
			nemonico.append("-");
			nemonico.append(obtenerDescripcionDelCalogo("500", dato.getCodtipdescr(), fechaVigencia));//se incorpora la vigencia

			argumentos = new Object[] { dato.getNumsecprove(), dato.getNumsecfact(), dato.getNumsecitem(), nemonico };

		}


		return new ErrorDescrMinima(origen, codigoError, detalle, tipo,
				(otrosArgumentos.length > 0) ? union(argumentos, otrosArgumentos) : argumentos);

	}

	protected String obtenerMsjErrorCatalogo(String codigoError)
	{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> result = new HashMap<String, String>();
		result = catalogoAyudaService.getError(codigoError);

		return result.get(ResponseMapManager.KEY_DESCRIPCION);

	}

	protected String obtenerDescripcionDelCalogo(String codCatalogo, String codDataCat)
	{
		return obtenerDescripcionDelCalogo(codCatalogo, codDataCat,null, null);//PAS20165E220200137
	}

	//PAS20165E220200137
	protected String obtenerDescripcionDelCalogo(String codCatalogo, String codDataCat, Date fechaVigencia)
	{
		return obtenerDescripcionDelCalogo(codCatalogo, codDataCat, null, fechaVigencia);
	}
	protected String obtenerDescripcionDelCalogo(String codCatalogo, String codDataCat, Map<String, Object> variablesIngreso)
	{
		return obtenerDescripcionDelCalogo(codCatalogo, codDataCat, variablesIngreso, null);
	}
	//rtineo mejoras sobrecargamos el metodo
	protected String obtenerDescripcionDelCalogo(String codCatalogo, String codDataCat, Map<String, Object> variablesIngreso, Date fechaVigencia)
	{
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(variablesIngreso != null){
			Map<String,String> mapCatalogo = (Map<String,String>)variablesIngreso.get("mapCatalogoCache"+codCatalogo);
			if(mapCatalogo != null){
				return mapCatalogo.get(codDataCat);
			}else{
				/*Tomando las vigencias AREY PAS20165E220200137*/
				if(fechaVigencia!=null){
					DataCatalogo datacatalogo = catalogoAyudaService.getDataCatalogo(codCatalogo, codDataCat, fechaVigencia);
					return (datacatalogo!=null && datacatalogo.getDesDatacat()!=null)?datacatalogo.getDesDatacat():"";				  
				}else{
					return catalogoAyudaService.getDescripcionDataCatalogo(codCatalogo, codDataCat);
				}/*Tomando las vigencias AREY PAS20165E220200137*/
			}
		}else{
			/*Tomando las vigencias AREY PAS20165E220200137*/
			if(fechaVigencia!=null){
				DataCatalogo datacatalogo = catalogoAyudaService.getDataCatalogo(codCatalogo, codDataCat, fechaVigencia);
				return (datacatalogo!=null && datacatalogo.getDesDatacat()!=null)?datacatalogo.getDesDatacat():"";	
				/*Tomando las vigencias AREY PAS20165E220200137*/
			}else{
				//metodo anterior
				return catalogoAyudaService.getDescripcionDataCatalogo(codCatalogo, codDataCat);
			}
		}
	}
	//rtineo mejoras, fin

	protected Object[] union(Object[] set1, Object[] set2)
	{

		Object union[] = new Object[set1.length + set2.length];

		int i = 0;
		int cnt = 0;

		for (int n = 0; n < set1.length; n++)
		{
			union[i] = set1[i];
			i++;
			cnt++;
		}

		for (int m = 0; m < set2.length; m++)
		{
			union[i] = set2[m];
			i++;

		}

		return union;
	}



	/**
	 * ******************* METODOS PRIVADOS **************************.
	 *
	 */
	private List<ErrorDescrMinima> validarZZZ(DatoDescrMinima dato,Date fechaVigencia, Map<String, Object> variablesIngreso)
	{

		List<ErrorDescrMinima> lstErrores = new ArrayList<ErrorDescrMinima>();

		String valorCampoZZZ = dato.getValtipdescri().trim();
		if (cumpleRequisitosParaValidarEnvioZZZ(dato))
		{
			String codCatalogoRegistrado = dato.getPosicion().getCodigoCatalogoParaValidar();
			if (!SunatStringUtils.isEmpty(valorCampoZZZ))
			{
				if(Integer.parseInt(dato.getPosicion().getIndicadorTipoValor()) == CAMPO_ACEPTA_CATALOGO_Y_ZZZ){
					if (SunatStringUtils.isEmpty(valorCampoZZZ) || valorCampoZZZ.trim().length() < 2)//actualizado por generar error en al validar version de vehiculo minimas
					{//la version se controlaba aqui por el cod_tipvalor 2 - M_SNADE257-598
						ErrorDescrMinima error = crearError("30789", dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR, new Object[] {});
						lstErrores.add(error);
					}else{

						if (ArrayUtils.contains(new String[]
								{ "OTRO", "OTROS", "N.A", "NA","ZZ","ZZZ","N.A." }, valorCampoZZZ.toUpperCase()))
						{
							ErrorDescrMinima error = crearError("30788", dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR, new Object[] {});
							lstErrores.add(error);
						}
						else
						{
							//no debe enviar un valor del catalogo como otros
							if(valorCampoZZZ.length()>=2 ){//SI NO LLEGA NI A DOS CARACTERES NO ES VALOR SUCEPTIBLE DE CATALOGO!!! (POR EL . QUE NOS MANDARON)
                      if ((estaEnCatalogo(valorCampoZZZ, codCatalogoRegistrado, fechaVigencia)) || estaEnDescripcionDelCatalogo(valorCampoZZZ,codCatalogoRegistrado,variablesIngreso, fechaVigencia) )//PAS20171U220200016
								{
									ErrorDescrMinima error =
											crearError("30787", dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR,
													new Object[] { codCatalogoRegistrado });

									lstErrores.add(error);
								}

							}


						}
					}        	  
				}
			}
			else{
				ErrorDescrMinima error = crearError("30895", dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR, new Object[] {});
				lstErrores.add(error);    	  
			}
		}

		return lstErrores;
	}

	private boolean cumpleRequisitosParaValidarEnvioZZZ(DatoDescrMinima dato) {
		return envioXMLtipoZZZ(dato) && correspondeEnviarZZZ(dato);
	}

	private boolean envioXMLtipoZZZ(DatoDescrMinima dato) {

		return TIPO_VALOR_TEXTO_ZZZ.equals(dato.getCodtipvalor())?true:false;
	}

	/**
	 * Validar expresion regular.
	 */
	private ErrorDescrMinima validarExpresionRegular(DatoDescrMinima dato, Date fechaVigencia)
	{

		ErrorDescrMinima error = null;

		String valorCampo = dato.getValtipdescri();
		if (TIPO_VALOR_TEXTO_ZZZ.equals(dato.getCodtipvalor()) && !SunatStringUtils.isEmptyTrim(valorCampo))
		{
			String expresionRegularRegistrada = dato.getPosicion().getExpresionRegular();

			if (expresionRegularRegistrada != null)
			{
				if (!SunatStringUtils.isEmptyTrim(expresionRegularRegistrada))

					if (noCumpleExpresionRegular(valorCampo, expresionRegularRegistrada.trim()))
					{

						String codigoMsjError = dato.getPosicion().getCodigoMsjError().trim();
						if (!SunatStringUtils.isEmpty(codigoMsjError))
						{
							error = crearError(codigoMsjError, dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR,
									new Object[] {expresionRegularRegistrada}, tipoValidacion.EXPRESION_REGULAR, fechaVigencia);
						}
						else
						{
							error =
									crearError("30786", dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR,
											new Object[] { expresionRegularRegistrada }, tipoValidacion.EXPRESION_REGULAR, fechaVigencia);
						}

					}

			}
		}

		return error;
	}

	/**
	 * Validar pertenezca codigo al catalogo.
	 * considerar la vigencia del datacatalogo - AREY-MIN PAS20165E220200137
	 */
	private ErrorDescrMinima validarPertenezcaCodigoAlCatalogo(DatoDescrMinima dato, Date fechaVigencia)
	{
		return validarPertenezcaCodigoAlCatalogo(dato,fechaVigencia, null);
	}
	private ErrorDescrMinima validarPertenezcaCodigoAlCatalogo(DatoDescrMinima dato,Date fechaVigencia, Map<String,Object> variablesIngreso)
	{

		ErrorDescrMinima error = null;

		if (cumpleRequisitosParaValidarCatalogo(dato))
		{

			String codDataCatEnviado = dato.getValtipdescri();
			String codCatalogoRegistrado = dato.getPosicion().getCodigoCatalogoParaValidar();


			if (noEsExcepcion(dato) && noEstaEnCatalogo(codDataCatEnviado, codCatalogoRegistrado,fechaVigencia, variablesIngreso))
			{
				/*M_SNADE257-709, se reviso la bd de produccion todos los msjes del descr_posicion mostraban un mensaje gral que el valor de texto es
				 * invalido, esto genera confusion ya que el valor enviado es cat�logo y aqui verifica si esta o no en el catalogo lo transmitido.
				 * String codigoMsjError = dato.getPosicion().getCodigoMsjError()!=null?dato.getPosicion().getCodigoMsjError().trim():"";
          if (!SunatStringUtils.isEmpty(codigoMsjError))
          {		       
              error = crearError(codigoMsjError, dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR,
                      new Object[] {codCatalogoRegistrado}, tipoValidacion.CATALOGO, fechaVigencia);
          }
          else
          {*/
				String descDelCampo = obtenerDescripcionDelCalogo("500",dato.getCodtipdescr(), variablesIngreso, fechaVigencia);
				String nombreDescrMinima = obtenerDescripcionDelCalogo("393",dato.getCodmercancia(),variablesIngreso);
				error =crearError("30785", dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR,
						new Object[] { descDelCampo,codCatalogoRegistrado,nombreDescrMinima }, tipoValidacion.CATALOGO, fechaVigencia);

				//}

			}
		}

		return error;
	}

	private boolean cumpleRequisitosParaValidarCatalogo(DatoDescrMinima dato) {
		return envioXMLtipoCATALOGO(dato) && correspondeEnviarCatalogo(dato);
	}

	private boolean envioXMLtipoCATALOGO(DatoDescrMinima dato) {
		return TIPO_VALOR_CATALOGO.equals(dato.getCodtipvalor());
	}

	private boolean noEsExcepcion(DatoDescrMinima dato) {

		boolean esUnaExpcecion = false;

		if("VE0000".equals(dato.getCodtipdescr()) && (ArrayUtils.contains(new String[]{ "M2", "M3"}, dato.getValtipdescri())))
		{
			esUnaExpcecion = true;
		}

		return esUnaExpcecion?false:true;
	}

	/**
	 * Validar mandatoriedad.
	 * @throws Exception
	 *
	 */
	private List<ErrorDescrMinima> validarMandatoriedad(ModelAbstract objeto) throws Exception
	{
		List<ErrorDescrMinima> lstErrores = new ArrayList<ErrorDescrMinima>();

		for (DescrPosicion posicion : objeto.obtenerCodigodNoEnviados())
		{
			ErrorDescrMinima error = crearError("30784", posicion, objeto);
			lstErrores.add(error);
			objeto.agregarErrror(error);
		}

		return lstErrores;
	}

	/**
	 * Validar ta gcodtipvalor vs descr posicion.
	 *
	 */
	private ErrorDescrMinima validarTAGcodtipvalorVSDescrPosicion(DatoDescrMinima dato)
	{
		ErrorDescrMinima error = null;
		int codtipvalorXML = Integer.parseInt(dato.getCodtipvalor());
		int codtipvalorCatalogo= Integer.parseInt(dato.getPosicion().getIndicadorTipoValor());
		switch (codtipvalorXML)
		{
		case 1://puede ser en BD 1 o 2
			if (codtipvalorCatalogo == 0)
			{
				error = crearError("30783", dato, tipoHEAD.HEAD_CODTIPDESCRI,  new Object[] { dato.getCodtipvalor(), "" ,codtipvalorCatalogo });
			}
			break;
		case 0:// en catalogo va estar regisrado como 0 o 2
			if (codtipvalorCatalogo == 1)
			{
				error = crearError("30783", dato, tipoHEAD.HEAD_CODTIPDESCRI,  new Object[] { dato.getCodtipvalor(), "no" ,codtipvalorCatalogo });
			}
		default:
			break;
		}

		return error;
	}

	private boolean correspondeEnviarZZZ(DatoDescrMinima dato){
		return  ArrayUtils.contains(new Integer[]{CAMPO_ACEPTA_CATALOGO_Y_ZZZ, Integer.parseInt(TIPO_VALOR_TEXTO_ZZZ)},Integer.parseInt(dato.getPosicion().getIndicadorTipoValor()))?true:false;
	}


	private boolean correspondeEnviarCatalogo(DatoDescrMinima dato){

		return  ArrayUtils.contains(new Integer[]{CAMPO_ACEPTA_CATALOGO_Y_ZZZ, Integer.parseInt(TIPO_VALOR_CATALOGO)}, Integer.parseInt(dato.getPosicion().getIndicadorTipoValor()))?true:false;
	}

	private ErrorDescrMinima validarTAGvaltipdescr(DatoDescrMinima dato)
	{
		ErrorDescrMinima error = null;

		if (SunatStringUtils.isEmpty(dato.getValtipdescri()))
		{
			error = crearError("30782", dato, tipoHEAD.HEAD_CODTIPDESCRI);
		}

		return error;
	}

	/**
	 * codtipdescri pertenesca al catalogo que le corrresponde de la tabla
	 * descr_posicion
	 *
	 */
	private List<ErrorDescrMinima> validarTAGcodtipdescri(ModelAbstract objeto )
	{
		return validarTAGcodtipdescri(objeto,null);
	}
	//rtineo sobrecargamos el metodo
	private List<ErrorDescrMinima> validarTAGcodtipdescri(ModelAbstract objeto,Map<String,Object> variablesIngreso)
	{
		List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();

		ErrorDescrMinima error =null;
		List<DatoDescrMinima> lstCodigosInvalidos;
		List<DatoDescrMinima> lstCodigosDuplicados;
		try
		{
			lstCodigosInvalidos = objeto.obtenerCodigodEnviadosNOCorrespondenTipoDescrMinima();
			//rtineo mejoras, rectificacion electronica
			String nombreDescrMinima=null;
			if(variablesIngreso != null){
				nombreDescrMinima = obtenerDescripcionDelCalogo("393",objeto.getTipoDescrMnima(),variablesIngreso);
			}else{
				nombreDescrMinima =  obtenerDescripcionDelCalogo("393",objeto.getTipoDescrMnima());
			}
			//rtineo fin
			Object[] demasArgumentosMSJError = new Object[]{nombreDescrMinima};

			for (DatoDescrMinima dato : lstCodigosInvalidos)
			{
				error =  crearError("30781", dato, tipoHEAD.HEAD_CODTIPDESCRI,demasArgumentosMSJError);
				errorLst.add(error);
				// agrega al objeto
				objeto.agregarErrror(error);
			}

			lstCodigosDuplicados = objeto.obtenerCodigodEnviadosDuplicados();
			//verficar si hay codigos duplicados
			for (DatoDescrMinima dato : lstCodigosDuplicados)
			{
				error =  crearError("30806", dato, tipoHEAD.HEAD_CODTIPDESCRI_VALTIPDESCR,demasArgumentosMSJError);
				errorLst.add(error);
				// agrega al objeto
				objeto.agregarErrror(error);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return errorLst;
	}

	/**
	 * Validar XML codtipvalor pertenesca al catalogo 501.
	 *
	 */
	private ErrorDescrMinima validarTAGcodtipvalor(DatoDescrMinima dato, Date fechaVigencia)
	{
		return validarTAGcodtipvalor(dato,fechaVigencia, null);
	}
	//sobrecargamos el metodo
	private ErrorDescrMinima validarTAGcodtipvalor(DatoDescrMinima dato, Date fechaVigencia, Map<String,Object> variablesIngreso)
	{
		ErrorDescrMinima error =null;
		boolean noEstaEnCatalogo =false;
		if(variablesIngreso != null){
			noEstaEnCatalogo = noEstaEnCatalogo(dato.getCodtipvalor(), "501",fechaVigencia, variablesIngreso);
		}else{
			noEstaEnCatalogo = noEstaEnCatalogo(dato.getCodtipvalor(), "501",fechaVigencia);
		}
		if (noEstaEnCatalogo)
		{
			error = crearError("30780", dato, tipoHEAD.HEAD_CODTIPDESCRI);
		}

		return error;
	}





}
