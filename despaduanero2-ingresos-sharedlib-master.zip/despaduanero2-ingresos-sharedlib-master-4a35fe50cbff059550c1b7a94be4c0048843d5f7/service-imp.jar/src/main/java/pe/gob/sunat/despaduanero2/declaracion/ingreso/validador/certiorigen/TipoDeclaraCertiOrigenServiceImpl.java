package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.RegimenesPrecedentesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValAutocer;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.ControlVigenciaTPIService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.TratoPreferencialInternacionalService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
//Pase548
import pe.gob.sunat.despaduanero2.declaracion.model.DetPagodua;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCertiOrigenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetPagoDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.estrategico2.aduanero.vuce.util.Constantes; //PAS20181U220200056
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Clase de validacion por tipo de certificado de origen, las cuales var�an de acuerdo al tipo de TLC.
 * @author rbegazo
 *
 */
public class TipoDeclaraCertiOrigenServiceImpl extends ValDuaAbstract implements TipoDeclaraCertiOrigenService {

	//private FabricaDeServicios	fabricaDeServicios;
	//private CabCertiOrigenDAO cabCertiOrigenDAO; //PAS20165E220200059 - INC 2016-053022
	

	@ServicioAnnot(tipo="V",codServicio=3343, descServicio="validacion de tipo de certificado de origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3343,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public  Map<String, String> valTipoCertificadoOrigenGrupo(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		Map<String, String> listError=new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
//		DUA dua = (DUA) serie.getPadre();
//		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
//		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen)? null:listCertificadoOrigen.get(0).getCodtipoCO();
//		Integer codConvenio = serie.getCodconvinter();
		//rtineo optimizacion, se agrega variableIngreso
		
		//msnade236_1 verificamos si es que el tpi y tipo de certificado tienen el nuevo control de vigencias entonces validamos el tipo de certificado de acuerdo al nuevo control de vigencias
		ControlVigenciaTPIService controlVigenciaService = ((ControlVigenciaTPIService) fabricaDeServicios.getService("controlVigenciaTPIService"));
		if (controlVigenciaService.hasConfiguracionControlVigencia(serie, variablesIngreso)) {
			return listError;
		}
		
		//glazaror se adiciona fechaReferencia... la validacion de tipo certificado debe ser con la fecha de numeracion
		listError = valTipoCertificadoOrigen(serie,variablesIngreso);
		return listError;
	}

	//JENCISO REGISTRAR SERVICIO
	@ServicioAnnot(tipo="V",codServicio=3412, descServicio="validacion de tipo de certificado de origen cuando no tiene indicador 15 (LC para TPI) ")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3412,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public  Map<String, String> valTipoCertificadoOrigenGrupoSinIndLC(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		Map<String, String> listError=new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		if(indicador15== null){
			listError = valTipoCertificadoOrigen(serie);
		}
		return listError;
	}
	
	//rtineo sobrecargamos el metodo
	private Map<String, String> valTipoCertificadoOrigen(DatoSerie serie){
		return valTipoCertificadoOrigen(serie,null);
	}
	//SE FACTORIZA EL CODIGO
	//rtineo optimizacion, se agrega vriablesIngreso par almacenar algunas variables comunes
	private Map<String, String> valTipoCertificadoOrigen(DatoSerie serie, Map<String,Object> variablesIngreso){
		
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		Map<String, String> listError=new HashMap<String, String>();
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen)? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		Integer codConvenio = serie.getCodconvinter();	
		String indTipElectro = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getIndElectronico():"";
		if(!Constantes.INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(indTipElectro)) {//Se adiciona por pase PAS20181U220200056
		if (codTipoCO == null){
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30686",new String[] {serie.getNumserie().toString(),SunatStringUtils.toNotNull(codTipoCO), codConvenio.toString()});
		}else{	
			//rtineo optimizacion, agreamos variableIngreso, y utilizamos el nuevo metodo de validacion de criterio valido
			String codGrupoTipoCertificado  = tpiService.obtenerAtributo(ConstantesAtributo.GRUPO_TIPO_CERTIFICADO, 
				ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
				ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso);
			boolean isCriterioValido = isCriterioValido(ConstantesAtributo.GRUPO_TIPO_CERTIFICADO,codGrupoTipoCertificado,SunatStringUtils.toNotNull(codTipoCO), variablesIngreso);
			if(!isCriterioValido || codTipoCO == null){
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30686",new String[] {serie.getNumserie().toString(),SunatStringUtils.toNotNull(codTipoCO), codConvenio.toString()});
			}
			//fin optimizacion
		}			
		}		
		
		return listError;
	}
	//fin optimizacion

	
	//incio TLC Corea	
	private List<Map<String, String>> valEnvioNumSNFecha(DatoSerie serie, String[] arrayTipoCertificado){
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numdocumento = listCertificadoOrigen.get(0).getNumdocumento();
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Map<String, String> listErrDocumento = valAutocer.numdocumento(numdocumento, serie.getNumserie().toString(), codTipoCO);
			if (!listErrDocumento.isEmpty()){
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30688",new String[] {serie.getNumserie().toString()}));
			} else{
				listError.add(listErrDocumento);
			}
			listError.add(valAutocer.fecemision(fecemision , serie.getNumserie().toString(), codTipoCO));
		}
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3463, descServicio="Para tipo de certificado de origen igual a 2 debe enviar Numero de Certificado y Fecha del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3463,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioNumFechaParaMultiplesEmbarques(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valEnvioNumSNFecha(serie, arrayTipoCertificado);
		return listError;		
	}
	
	/*private List<Map<String, String>> validaVigenciaFechas(Integer numeroSerie, Date fechaCertificadoOrigen, Date fechaReferencia, String error){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		//Adapatr a los grupos creados por glazaror, inicialmente se prueba con fechas en duro
		Date fechaFinCetificado =  DateUtil.stringToDateSilent("31/07/2016", "dd/MM/yyyy");
		Date fechaFinReferencia = DateUtil.stringToDateSilent("01/01/2017", "dd/MM/yyyy");
		Date fechafinReferenciaError = SunatDateUtils.addDay(fechaFinReferencia, -1);
		
		if( SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaCertificadoOrigen, fechaFinCetificado, "COMPARA_SOLO_FECHA") && 
				SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fechaFinReferencia, "COMPARA_SOLO_FECHA")	){
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).
					getError(error,new String[] {numeroSerie.toString(), SunatDateUtils.getFormatDate(fechaFinCetificado, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fechafinReferenciaError, "dd/MM/yyyy") }));
		}
		return listError;
	}*/
	
	private List<Map<String, String>> validaVigenciaFechas(DatoSerie serie, Map<String, Object> variablesIngreso, String codigoTipoCertificadoOrigen, Date fechaCertificadoOrigen, Date fechaReferencia, String error){
		List<Map<String, String>> erroresValidacion = new ArrayList<Map<String, String>>();
		
		//Adapatr a los grupos creados por glazaror, inicialmente se prueba con fechas en duro
		/*Date fechaFinCetificado =  DateUtil.stringToDateSilent("31/07/2016", "dd/MM/yyyy");
		Date fechaFinReferencia = DateUtil.stringToDateSilent("01/01/2017", "dd/MM/yyyy");
		Date fechafinReferenciaError = SunatDateUtils.addDay(fechaFinReferencia, -1);*/
		
		DatoAutocertificacion certificadoOrigen = getCertificadoOrigen(serie);
		if (certificadoOrigen == null) {
			return erroresValidacion;
		}
		
		//TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		//TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ControlVigenciaTPIService controlVigenciaService = ((ControlVigenciaTPIService) fabricaDeServicios.getService("controlVigenciaTPIService"));
		
		String codigoConvenio = serie.getCodconvinter().toString();
		String numeroSerie = serie.getNumserie().toString();

		Date fechaLimiteCertificado = controlVigenciaService.getVariableDate(codigoConvenio, codigoTipoCertificadoOrigen, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE, variablesIngreso);
		Date fechaLimiteExcepcional = controlVigenciaService.getVariableDate(codigoConvenio, codigoTipoCertificadoOrigen, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL, variablesIngreso);
		
		if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaCertificadoOrigen, fechaLimiteCertificado, "COMPARA_SOLO_FECHA") && 
				SunatDateUtils.esFecha1MayorQueFecha2(fechaReferencia, fechaLimiteExcepcional, "COMPARA_SOLO_FECHA")) {
			erroresValidacion.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).
					getError(error,new String[] {numeroSerie, SunatDateUtils.getFormatDate(fechaLimiteCertificado, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fechaLimiteExcepcional, "dd/MM/yyyy") }));
		}
		return erroresValidacion;
	}
	
	/**
	 * Se valida la vigencia del tipo de certificado de origen. Se aplica solo a los tipos de certificado 1, 2 y 5.
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	@ServicioAnnot(tipo="V",codServicio=3464, descServicio="Valida la vigencia del tipo de certificado de origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3464,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	@Override
	public List<Map<String, String>> valVigenciaTipoCertificado(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) throws Exception {
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");	
		List<Map<String, String>> erroresValidacion = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)) {
			return erroresValidacion;
		}
		
		DUA dua = (DUA) serie.getPadre();			
		List<DatoAutocertificacion> listCertificadoOrigen = getCertiOrigen(dua, serie);
		String codigoTipoCertificado = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		
		if (SunatStringUtils.include(codigoTipoCertificado, arrayTipoCertificado)) {
			ControlVigenciaTPIService controlVigenciaService = ((ControlVigenciaTPIService) fabricaDeServicios.getService("controlVigenciaTPIService"));
			
			//solo ejecutamos esta validacion si es que el tpi y tipo de certificado tienen el control de vigencias
			if (!controlVigenciaService.hasConfiguracionControlVigencia(serie, variablesIngreso)) {
				return erroresValidacion;
			}
			//si es que no se esta modificando un dato critico (tpi, tipo certificado, fecha certificado) entonces no se debe realizar la validacion de tipo de certificado
			if (!controlVigenciaService.isValidacionVigenciaAplicable(serie, variablesIngreso)) {
				return erroresValidacion;
			}
			
			//glazaror determinamos la fecha de referencia... que puede ser la fecha de numeracion (en caso de no haber modificacion) o la fecha actual (en caso de tratarse de nueva serie, o haberse rectificado tpi otipo certificado o  fecha certificado)
			fechaReferencia = controlVigenciaService.getFechaReferenciaControl(serie.getCodconvinter().toString(), serie, fechaReferencia, variablesIngreso);
			String codigoConvenio = serie.getCodconvinter().toString();
			
			if (ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES.equals(codigoTipoCertificado)) {
				CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
				//si es que el tipo de certificado es 2 entonces
				//obtenemos la fecha inicio de vigencia del tipo certificado 2
				Date fechaInicioVigencia = controlVigenciaService.getVariableDate(codigoConvenio, codigoTipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL, variablesIngreso);
				if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fechaInicioVigencia, "COMPARA_SOLO_FECHA")) {
					//si la fecha actual es mayor al inicio de vigencia entonces rechazamos
					Map<String, String> errorValidacion = catalogoAyudaService.getError("30686",new String[] {serie.getNumserie().toString(),SunatStringUtils.toNotNull(codigoTipoCertificado), codigoConvenio});
					erroresValidacion.add(errorValidacion);
				} else {
					//si es que se tiene configurado fecha de inicio de vigencia de certificado
					Date fechaInicioVigenciaCertificado = controlVigenciaService.getVariableDate(codigoConvenio, codigoTipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE, variablesIngreso);
					if (fechaInicioVigenciaCertificado != null) {
						//entonces hacemos validacion adicional
						Date fechaEmisionCertificado = listCertificadoOrigen.get(0).getFecemision();
						if (SunatDateUtils.esFecha1MayorQueFecha2(fechaReferencia, fechaInicioVigencia, "COMPARA_SOLO_FECHA") && SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaEmisionCertificado, fechaInicioVigenciaCertificado, "COMPARA_SOLO_FECHA")) {
							Date fechaInicioVigenciaCertificadoPresentacion = SunatDateUtils.addDay(fechaInicioVigenciaCertificado, 1);
							//si la fecha actual es mayor a la fecha de inicio de vigencia y la fecha de certificado es menor o igual a la fecha de inicio de vigencia del certificado
							Map<String, String> errorValidacion = catalogoAyudaService.getError("37011",new String[] {serie.getNumserie().toString(),SunatStringUtils.toNotNull(codigoTipoCertificado), SunatDateUtils.getFormatDate(fechaInicioVigenciaCertificadoPresentacion, "dd/MM/yyyy")});
							erroresValidacion.add(errorValidacion);
						}
					}
				}
				
			} else {
				//si es que el tipo de certificado es 1 o 5	
				String codigoError = "37004"; 
				Date fechaEmisionCertificado = listCertificadoOrigen.get(0).getFecemision();
				if (ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN.equals(codigoTipoCertificado)) {
					codigoError = "37006";
				}
				erroresValidacion = validaVigenciaFechas(serie, variablesIngreso, codigoTipoCertificado, fechaEmisionCertificado, fechaReferencia, codigoError);
				
				//si es que el tipo certificado es 5 entonces ejecutamos una validacion adicional
				if (ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN.equals(codigoTipoCertificado)) {
					//obtenemos la fecha limite del certificado del catalogo de variables de control de vigencia
					Date fechaLimiteCertificado = controlVigenciaService.getVariableDate(codigoConvenio, codigoTipoCertificado, ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE, variablesIngreso);
					
					if (SunatDateUtils.esFecha1MayorQueFecha2(fechaEmisionCertificado, fechaLimiteCertificado, "COMPARA_SOLO_FECHA")) {
						Date fechaLimiteCertificadoPresentacion = SunatDateUtils.addDay(fechaLimiteCertificado, 1);
						erroresValidacion.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).
								getError("37005", new String[] {serie.getNumserie().toString(), SunatDateUtils.getFormatDate(fechaLimiteCertificadoPresentacion, "dd/MM/yyyy")}));
					}
				}
			}
		}
		return erroresValidacion;
	}
	
	private List<Map<String, String>> validaPeriodoEmbarque(DatoSerie serie, String[] arrayTipoCertificado,Map<String, Object> variablesIngreso, String[] codError){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			Date feciniembarque = listCertificadoOrigen.get(0).getFeciniembarque();
			Date fecfinembarque = listCertificadoOrigen.get(0).getFecfinembarque();
			// Si no envio la fecha de inicio o fin, se controla con el servicio 3361
			if (CollectionUtils.isEmpty(valAutocer.fecinifinembarque(fecfinembarque, feciniembarque,serie.getNumserie().toString()))) {			
				Date fecemision = listCertificadoOrigen.get(0).getFecemision();
				Integer codConvenio = serie.getCodconvinter();
				/*Plazo de validacion para periodo de embarque */
				//rtineo optimizacion; se agrega variableIngreso
				String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_PERIODO_EMBARQUE, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso);
				Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_PERIODO_EMBARQUE, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso));
				//fin optimizacion
				if (fecemision != null){
					if (codTipoPlazo.equals("Y") ){
						listError.add(valAutocer.valfecemisionPlazoAniosSinRestriccion(fecemision, feciniembarque, numTipoPlazo, serie.getNumserie().toString(),codError[0]));
						listError.add(valAutocer.valfecemisionPlazoAnios(fecemision, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(),codError[1], codError[3]));	
					} 
					if (codTipoPlazo.equals("M") ){
						listError.add(valAutocer.valfecemisionPlazoMesesSinRestriccion(fecemision, feciniembarque, numTipoPlazo, serie.getNumserie().toString(),codError[0]));
						listError.add(valAutocer.valfecemisionPlazoMeses(fecemision, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(),codError[1], codError[3]));
					} 		
					if (codTipoPlazo.equals("D") ){
						listError.add(valAutocer.valfecemisionPlazoDiasSinRestriccion(fecemision, feciniembarque, numTipoPlazo, serie.getNumserie().toString(), codError[0]));
						listError.add(valAutocer.valfecemisionPlazoDias(fecemision, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(), codError[1], codError[3]));
					}
				}
			} 
		}
		return listError;
	}
	
	/**
	 * Se validan las fechas de periodos de embarques con respecto a la fecha de emision del CO, se aplica solo al tipo de certificado 2
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	@ServicioAnnot(tipo="V",codServicio=3468, descServicio="Para tipo de certificado de origen igual a 2 valida que las fecha de periodos de embarques con respecto a la fecha de emision del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3468,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	@Override
	public List<Map<String, String>> valPeriodoEmbarques(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		
		List<Map<String, String>> erroresValidacion = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return erroresValidacion;
		}
		String[] codError = {"37007","37008","37009","37010"};
		//lalberti: TLC Corea Sigesi: En metodo se elimina la validacion de la fecha de inicio de periodo de embarque mayor a fecha CO.
		erroresValidacion = validaPeriodoEmbarque(serie,arrayTipoCertificado,variablesIngreso,codError);
		return erroresValidacion;
	}
	
	
	
	//Fin TLC Corea
	
	
	
	
	@ServicioAnnot(tipo="V",codServicio=3349, descServicio="Para tipo de certificado de origen igual a 1,2 o 3 debe enviar Numero de Certificado y Fecha del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3349,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioNumFechaParaTipoEmbarquesTextiles (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES, ConstantesDataCatalogo.TIPO_TEXTILES_ARTESANALES};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numdocumento = listCertificadoOrigen.get(0).getNumdocumento();
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Map<String, String> listErrDocumento = valAutocer.numdocumento(numdocumento, serie.getNumserie().toString(), codTipoCO);
			if (!listErrDocumento.isEmpty()){
//				listError.add(catalogoHelper.getErrorMap("30688", new String[] {serie.getNumserie().toString()}));
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30688",new String[] {serie.getNumserie().toString()}));
			} else{
				listError.add(listErrDocumento);
			}
			listError.add(valAutocer.fecemision(fecemision , serie.getNumserie().toString(), codTipoCO));
		}
		return listError;		
	}
	
	@ServicioAnnot(tipo="V",codServicio=3350, descServicio="Para tipo de certificado de origen igual a 1 o 2 debe enviar Numero de Certificado y Fecha del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3350,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioNumFechaParaTipoEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numdocumento = listCertificadoOrigen.get(0).getNumdocumento();
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Map<String, String> listErrDocumento = valAutocer.numdocumento(numdocumento, serie.getNumserie().toString(), codTipoCO);
			if (!listErrDocumento.isEmpty()){
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30688",new String[] {serie.getNumserie().toString()}));
			} else{
				listError.add(listErrDocumento);
			}
			listError.add(valAutocer.fecemision(fecemision , serie.getNumserie().toString(), codTipoCO));
		}
		return listError;		
	}
	
	@ServicioAnnot(tipo="V",codServicio=3351, descServicio="Para tipo de certificado de origen igual a 1 debe enviar Numero de Certificado pero no S/N y Fecha del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3351,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioNumSinSNFechaParaTipoUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String indTipElectro = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getIndElectronico():"";
		if(!Constantes.INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(indTipElectro)) {//Se adiciona por pase PAS20181U220200056
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valEnvioNumSinSNFecha(serie, arrayTipoCertificado);
		}
		
		return listError;		
	}
	
	//JENCISO REGISTRAR SERVICIO
	@ServicioAnnot(tipo="V",codServicio=3413, descServicio="Para tipo de certificado de origen igual a 1 debe enviar Numero de Certificado pero no S/N y Fecha del CO, cuando no tiene indicador 15 (LC para TPI)")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3413,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioNumSinSNFechaParaTipoUnEmbarqueSinIndLC(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();		
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		if(indicador15== null){
			listError = valEnvioNumSinSNFecha(serie, arrayTipoCertificado);
		}
		return listError;		
	}
	
	private List<Map<String, String>> valEnvioNumSinSNFecha(DatoSerie serie, String[] arrayTipoCertificado){
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numdocumento = listCertificadoOrigen.get(0).getNumdocumento();
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			listError.add(valAutocer.numdocumentoSN(numdocumento, serie.getNumserie().toString()));
			listError.add(valAutocer.fecemision(fecemision , serie.getNumserie().toString(), codTipoCO));
		}
		return listError;		
	}
	
	@ServicioAnnot(tipo="V",codServicio=3352, descServicio="Para tipo de certificado de origen igual a 1 debe enviar Numero de Certificado y Fecha del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3352,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioNumFechaParaTipoUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numdocumento = listCertificadoOrigen.get(0).getNumdocumento();
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Map<String, String> listErrDocumento = valAutocer.numdocumento(numdocumento, serie.getNumserie().toString(), codTipoCO);
			if (!listErrDocumento.isEmpty()){
                /*INICIO-P34 PAS20165E220200126 AFMA*/
                String codTransaccion = variablesIngreso.get("codTransaccion").toString();
                if("1019".equals(codTransaccion)){
                    listError.add(listErrDocumento);
                }else{
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30688",new String[] {serie.getNumserie().toString()}));
                }
                /*FIN-P34 PAS20165E220200126 AFMA*/
			} else{
				listError.add(listErrDocumento);
			}
			listError.add(valAutocer.fecemision(fecemision , serie.getNumserie().toString(), codTipoCO));
		}
		return listError;		
	}
	
	@ServicioAnnot(tipo="V",codServicio=3353, descServicio="Para tipo de certificado de origen igual a 1 debe enviar Numero de Certificado, Fecha del CO y Registro de Funcionario que emite el CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3353,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioNumFechaFuncionarioParaTipoUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {	
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String indTipElectro = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getIndElectronico():"";
		if(!Constantes.INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(indTipElectro)) {//Se adiciona por pase PAS20181U220200056
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valEnvioNumFechaFuncionario(serie,arrayTipoCertificado);
		}
		
		return listError;		
	}
	
	//JENCISO REGISTRAR SERVICIO
	@Override
	@ServicioAnnot(tipo="V",codServicio=3414, descServicio="Para tipo de certificado de origen igual a 1 debe enviar Numero de Certificado, Fecha del CO y Registro de Funcionario que emite el CO, cuando no tiene Ind. LC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3414,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioNumFechaFuncionarioParaTipoUnEmbSinIndLC (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {	
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		if(indicador15== null){
			listError = valEnvioNumFechaFuncionario(serie,arrayTipoCertificado);
		}

		return listError;		
	}
	
	private List<Map<String, String>> valEnvioNumFechaFuncionario(DatoSerie serie, String[] arrayTipoCertificado){
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numdocumento = listCertificadoOrigen.get(0).getNumdocumento()!=null?listCertificadoOrigen.get(0).getNumdocumento():"";
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			String codffco = listCertificadoOrigen.get(0).getCodffco()!=null?listCertificadoOrigen.get(0).getCodffco():"";
			Map<String, String> listErrorEnviocon = new HashMap<String, String>();
			listErrorEnviocon = valAutocer.combinarNumCOFechaFuncionario(numdocumento, fecemision, codffco, serie.getNumserie().toString(),codTipoCO);
			if (!listErrorEnviocon.isEmpty() ){
					listError.add(listErrorEnviocon);
			}			
		}
		return listError;		
	}


	@ServicioAnnot(tipo="V",codServicio=3354, descServicio="Para tipo de certificado de origen igual a 5 debe enviar Numero de Certificado y Fecha del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3354,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public  List<Map<String, String>> valEnvioNumFechaParaTipoDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numdocumento = listCertificadoOrigen.get(0).getNumdocumento();
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Map<String, String> listErrDocumento = valAutocer.numdocumento(numdocumento, serie.getNumserie().toString(), codTipoCO);
			if (!listErrDocumento.isEmpty()){
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30688",new String[] {serie.getNumserie().toString()}));
			} else{
				listError.add(listErrDocumento);
			}
			listError.add(valAutocer.fecemision(fecemision , serie.getNumserie().toString(), codTipoCO));		
		}
		return listError;		
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3344, descServicio="Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3344,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Integer codConvenio = serie.getCodconvinter();
			//glazaror... invocamos al metodo nuevo pasandole como ultimo parametro variablesIngreso
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso);

			//glazaror... invocamos al metodo nuevo pasandole como ultimo parametro variablesIngreso
			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			
			//glazaror... invocamos al metodo nuevo pasandole como ultimo parametro variablesIngreso
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, true,codTransaccion,false, variablesIngreso);	//Pase 548					

		}
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3415, descServicio="Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen, cuando no tiene Ind. LC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3415,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaUnEmbarqueSinIndLC (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		if(indicador15== null){
			if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
				Date fecemision = listCertificadoOrigen.get(0).getFecemision();
				Integer codConvenio = serie.getCodconvinter();
				String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());

				Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
				String codTransaccion = variablesIngreso.get("codTransaccion").toString();
				listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, true,codTransaccion,false);			//Pase548				
			}

		}
				return listError;
	}
	

	/**Servicio Adicionado para el Pase 548 bugs 19710,19713,19714,19719 **/

	@ServicioAnnot(tipo="V",codServicio=3444, descServicio="TRX03:Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia", "declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3444,numSecEjec=178,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaUnEmbarqueRecti (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		 
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, new Date(),variablesIngreso)){//bug 17303 Pase 548
			return listError;
			}	
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
		  //pase548
			boolean esRectificacionTPI = tpiService.esRectificacionTPI(serie, declaracionBD);		 
			if(esRectificacionTPI){			
				//TLC Corea 2016-66
				//Se crea la condicional para el caso que haya una transmision previa, 
				//la fecha de referencia en este caso no es el dia en que la diligencia se acepta 
				//por el funcionario aduanero, si no el dia que se transmiti� los cambios.	
				//Para que la variable cabSolicitudParaValidacionTLC se llene debe inscribirse el servicio 3480
				fechaReferencia = tpiService.obtenerFechaReferenciaCOEnEvaluacion(listCertificadoOrigen.get(0),variablesIngreso);
			}
            else{ //PAS20165E220200059 - INC 2016-053022
                Map<String, String> paramsCerti = new HashMap();
                paramsCerti.put("numcorredoc", dua.getNumcorredoc().toString());
                paramsCerti.put("numsecdoc", listCertificadoOrigen.get(0).getNumsecCO().toString()) ; 
                List<Map<String, Object>> listCertRegis=  ((CabCertiOrigenDAO)fabricaDeServicios.getService("cabCertiOrigenDAO")).select(paramsCerti);
                if(!CollectionUtils.isEmpty(listCertRegis)){
                       //fechaReferencia = (Date) listCertRegis.get(0).get("FEC_REGIS"); No considera aquellas que cambian de nro o fecha de emision en una rectificaci�n 
                       fechaReferencia = (Date) listCertRegis.get(0).get("FEC_MODIF");                      
                }
            } 

			
			Integer codConvenio = serie.getCodconvinter();
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());

			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, true,codTransaccion,esRectificacionTPI);						
		}
				return listError;
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3404, descServicio="Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen sin regimen de precedencia")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3404,numSecEjec=226,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaUnEmbarqueSinPrecedencia (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Integer codConvenio = serie.getCodconvinter();
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, false, codTransaccion, false);//Pase 548						
		}
		return listError;
			}	
		 
	/**Servicio Adicionado para el Pase 548 bugs 19710,19713,19714,19719 **/
	@ServicioAnnot(tipo="V",codServicio=3449, descServicio="TRX03:Para tipo de certificado de origen igual a 1 se valida los plazos para el acogimiento del Certificado de Origen sin regimen de precedencia")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3449,numSecEjec=226,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaUnEmbarqueSinPrecedenciaRecti(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, new Date(),variablesIngreso)){//bug 17303 Pase 548
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			
			boolean esRectificacionTPI = tpiService.esRectificacionTPI(serie, declaracionBD);	 
			if(esRectificacionTPI){			
				//TLC Corea 2016-66
				//Se crea la condicional para el caso que haya una transmision previa, 
				//la fecha de referencia en este caso no es el dia en que la diligencia se acepta 
				//por el funcionario aduanero, si no el dia que se transmiti� los cambios.	
				//Para que la variable cabSolicitudParaValidacionTLC se llene debe inscribirse el servicio 3480
				fechaReferencia = tpiService.obtenerFechaReferenciaCOEnEvaluacion(listCertificadoOrigen.get(0),variablesIngreso);
			}
			
			Integer codConvenio = serie.getCodconvinter();
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, false, codTransaccion, esRectificacionTPI);						
		}
		return listError;
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3345, descServicio="Para tipo de certificado de origen igual a 1,2 o 3 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3345,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaEmbarquesTextiles (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES, ConstantesDataCatalogo.TIPO_TEXTILES_ARTESANALES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Integer codConvenio = serie.getCodconvinter();
			
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso);
				//Pase548
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, false,codTransaccion, false, variablesIngreso);//Pase 548					
		}
		return listError;
			}	
		 
	/**Servicio Adicionado para el Pase 548 bugs 19710,19713,19714,19719 **/
	@ServicioAnnot(tipo="V",codServicio=3445, descServicio="TRX03:Para tipo de certificado de origen igual a 1,2 o 3 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia", "declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3445,numSecEjec=179,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaEmbarquesTextilesRecti (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES, ConstantesDataCatalogo.TIPO_TEXTILES_ARTESANALES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, new Date(),variablesIngreso)){//bug 17303 Pase 548
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
	
			boolean esRectificacionTPI =  tpiService.esRectificacionTPI(serie, declaracionBD);
			if(esRectificacionTPI){			
				fechaReferencia = new Date();
			}
			
			Integer codConvenio = serie.getCodconvinter();
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());

			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, false,codTransaccion, esRectificacionTPI);					
		}
		return listError;
	}
	

	@ServicioAnnot(tipo="V",codServicio=3346, descServicio="Para tipo de certificado de origen igual a 1 o 2, se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3346,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Integer codConvenio = serie.getCodconvinter();
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso);
				//Pase548
			
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, false,codTransaccion, false, variablesIngreso);//Pase 548					
		}
		return listError;
			}	
		 
	/**Servicio Adicionado para el Pase 548 bugs 19710,19713,19714,19719 **/
	@ServicioAnnot(tipo="V",codServicio=3446, descServicio="TRX03:Para tipo de certificado de origen igual a 1 o 2, se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia", "declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3446,numSecEjec=180,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaEmbarquesRecti(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, new Date(),variablesIngreso)){//bug 17303 Pase 548
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			 
			boolean esRectificacionTPI =  tpiService.esRectificacionTPI(serie, declaracionBD);  
			if(esRectificacionTPI){			
				fechaReferencia = new Date();
			}
			
			Integer codConvenio = serie.getCodconvinter();
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());

			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, false,codTransaccion, esRectificacionTPI);					
		}
		return listError;
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3347, descServicio="Para tipo de certificado de origen igual a 5 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3347,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Integer codConvenio = serie.getCodconvinter();
			//glazaror... se adiciona variablesIngreso para cachear consultas a catalogo....
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_DECLARACION , 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso);
				//Pase548
			//glazaror... se adiciona variablesIngreso para cachear consultas a catalogo...
			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_DECLARACION, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			
			//glazaror... se adiciona variablesIngreso para cachear consultas a catalogo...
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, true,codTransaccion, false, variablesIngreso);//Pase 548	
		}
		return listError;
			}	
		 
	/**Servicio Adicionado para el Pase 548 bugs 19710,19713,19714,19719 **/
	@ServicioAnnot(tipo="V",codServicio=3447, descServicio="TRX03:Para tipo de certificado de origen igual a 5 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia", "declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3447,numSecEjec=181,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaDeclaracionRecti (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, new Date(),variablesIngreso)){//bug 17303 Pase 548
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			 
			boolean esRectificacionTPI =  tpiService.esRectificacionTPI(serie, declaracionBD);
			if(esRectificacionTPI){			
				fechaReferencia = new Date();
			}
			
			Integer codConvenio = serie.getCodconvinter();
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_DECLARACION , 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());

			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_DECLARACION, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, true,codTransaccion, esRectificacionTPI);	
		}
		return listError;
	}
	

	@ServicioAnnot(tipo="V",codServicio=3348, descServicio="Para tipo de certificado de origen igual a 1 o 5 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3348,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaUnEmbarqueDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Integer codConvenio = serie.getCodconvinter();
			
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO , 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso);
			
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			
			//glazaror... adicionamos como parametro variablesIngreso para cachear resultados de consultas a catalogo...
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, true,codTransaccion, false, variablesIngreso);//Pase 548	
		}
		return listError;
	}

	/**Servicio Adicionado para el Pase 548 bugs 19710,19713,19714,19719 **/
	@ServicioAnnot(tipo="V",codServicio=3448, descServicio="TRX03:Para tipo de certificado de origen igual a 1 o 5 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3448,numSecEjec=182,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valPlazoParaUnEmbarqueDeclaracionRecti (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, new Date(),variablesIngreso)){//bug 17303 Pase 548
			return listError;
			}	
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
		 
			boolean esRectificacionTPI = tpiService.esRectificacionTPI(serie,  declaracionBD);	 
			if(esRectificacionTPI){			
				fechaReferencia = new Date();
			}
			/*Fin Pase105 II*/
			
			Integer codConvenio = serie.getCodconvinter();
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO , 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());

			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			String codTransaccion = variablesIngreso.get("codTransaccion").toString();
			listError = valPlazoConSinPrecedencia(serie, listCertificadoOrigen.get(0), fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, true,codTransaccion, esRectificacionTPI);	
		}
		return listError;
	}

	
	@ServicioAnnot(tipo="V",codServicio=3355, descServicio="Para tipo de certificado de origen igual a 1 se valida el criterio de origen asociado")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3355,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valCriterioOrigenParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String indTipElectro = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getIndElectronico():"";
		if(!Constantes.INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(indTipElectro)) {//Se adiciona por pase PAS20181U220200056
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//rtineo optimizacion, se agrega variablesIngreso
		listError = valCriterioOrigen(serie, arrayTipoCertificado,variablesIngreso);
		//fin optimizacion
		}
		return listError;		
	}
	
	@ServicioAnnot(tipo="V",codServicio=3416, descServicio="Para tipo de certificado de origen igual a 1 se valida el criterio de origen asociado, cuando no tiene Ind. LC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3416,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valCriterioOrigenParaUnEmbarqueSinIndLC (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		if(indicador15== null){
			listError = valCriterioOrigen(serie, arrayTipoCertificado);
		}
		
		return listError;		
	}
	

	@ServicioAnnot(tipo="V",codServicio=3356, descServicio="Para tipo de certificado de origen igual a 1 y 2 se valida el criterio de origen asociado")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3356,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valCriterioOrigenParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//rtineo optimizacion
		listError = valCriterioOrigen(serie, arrayTipoCertificado,variablesIngreso);
		//fin optimizacion
		return listError;		
	}
	
	/**
	 * Se valida el criterio de origen para el tipo de certificado de origen igual a 2. Este servicio esta basado en el 3358.
	 * Proyecto msnade236_1
	 * @author glazaror
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	@ServicioAnnot(tipo="V",codServicio=3466, descServicio="Para tipo de certificado de origen igual a 2 se valida el criterio de origen asociado")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3466,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	@Override
	public Map<String, String> valCriterioOrigenParaMultiplesEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> erroresValidacion = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)){
			return erroresValidacion;
		}
		erroresValidacion = valCriterioOrigen(serie, arrayTipoCertificado, variablesIngreso);
		return erroresValidacion;		
	}
	
	/**
	 * Se validan los plazos para el acogimiento del certificado de origen. Se aplica solo a los tipos de certificado 1 y 5.
	 * Basado en el servicio 3448.
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @param declaracionBD declaracion de base datos
	 * @return errores de validacion
	 */
	@ServicioAnnot(tipo="V",codServicio=3470, descServicio="TRX03:Para tipo de certificado de origen igual a 1 o 5 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1}, nomAtr={"serie","variablesIngreso","fechaReferencia","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3470, numSecEjec=182, nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	@Override
	public Map<String, String> validarPlazoParaUnEmbarqueDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> erroresValidacion = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)) {
			return erroresValidacion;
		}
		return validarPlazosGeneral(serie, arrayTipoCertificado, tpiService, variablesIngreso, fechaReferencia);
	}
	
	/**
	 * Se validan los plazos para el acogimiento del certificado de origen. Se aplica solo al tipo de certificado 2.
	 * Basado en el servicio 3348.
	 * Proyecto msnade236_1
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	@ServicioAnnot(tipo="V",codServicio=3467, descServicio="Para tipo de certificado de origen igual a 2 se valida los plazos para el acogimiento del Certificado de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3467,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	@Override
	public Map<String, String> valPlazoParaMultiplesEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> erroresValidacion = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)) {
			return erroresValidacion;
		}
		return validarPlazosGeneral(serie, arrayTipoCertificado, tpiService, variablesIngreso, fechaReferencia);
	}
	
	//glazaror msnade236_1 se refactoriza codigo con logica de validacion de plazos con sin precedencia
	private Map<String, String> validarPlazosGeneral(DatoSerie serie, String[] arrayTipoCertificado, TratoPreferencialInternacionalService tpiService, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		
		Map<String, String> erroresValidacion = new HashMap<String, String>();
		//glazaror... segun lo indicado por normativo y de acuerdo a lo conversado con rbegazo la fecha para validar los plazos puede ser:
		//1. Fecha de numeracion de la DAM: si es que es una serie existente en base datos y no se ha modificado tpi ni fecha de certificado ni tipo certificado de la serie 
		//2. Fecha actual: si es que se trata de una serie recien declarada (nueva) o si es que se esta modificando el tpi o la fecha de certificacion o tipo certificado de la serie grabada en alguna transaccion anterior.

		ControlVigenciaTPIService controlVigenciaService = ((ControlVigenciaTPIService) fabricaDeServicios.getService("controlVigenciaTPIService"));
		//verificamos si es que se esta modificando un dato critico (tpi, fecha certificado, tipo certificado), de ser el caso entonces seteamos la fecha de referencia con la fecha actual 
		if (controlVigenciaService.isRectificacionTPI(serie, variablesIngreso)) {
			fechaReferencia = SunatDateUtils.getCurrentDate();
		}
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> certificadosOrigen = getCertiOrigen(dua, serie);
		String codigoTipoCertificado = CollectionUtils.isEmpty(certificadosOrigen) ? null : certificadosOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codigoTipoCertificado, arrayTipoCertificado)) {
			DatoAutocertificacion certificadoOrigen = certificadosOrigen.get(0);
			Date fechaEmision = certificadoOrigen.getFecemision();
			Integer codigoConvenio = serie.getCodconvinter();
			
			String codigoTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO , 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codigoConvenio.toString(), variablesIngreso);
			
			Integer cantidadPorTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codigoConvenio.toString(), variablesIngreso));
			String codigoTransaccion = variablesIngreso.get("codTransaccion").toString();
			
			erroresValidacion = valPlazoConSinPrecedencia(serie, certificadoOrigen, fechaReferencia, fechaEmision, codigoTipoPlazo, cantidadPorTipoPlazo, true, codigoTransaccion, false, variablesIngreso);	
		}
		return erroresValidacion;
	}
	
	/**
	 * Se valida que la fecha de inicio y fin de periodo de embarque sean validos, solo se aplica cuando el tipo de certificado es igual a 2. Este servicio esta basado en el 3358.
	 * Proyecto msnade236_1
	 * @author glazaror
	 * @param serie Serie que se esta adicionando o rectificando
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @param fechaReferencia fechaReferencia utilizada en los servicios de validacion TLC
	 * @return errores de validacion
	 */
	@ServicioAnnot(tipo="V",codServicio=3469, descServicio="Para tipo de certificado de origen igual a 2 valida que la Fecha de Inicio y Fin de Per�odo de Embarque sean validos")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3469,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	@Override
	public List<Map<String, String>> validarFechasPeriodoEmbarquesParaMultipleEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		List<Map<String, String>> erroresValidacion = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return erroresValidacion;
		}
		DatoAutocertificacion certificadoOrigen = getCertificadoOrigen(serie);
		if (certificadoOrigen != null) {
			String codigoTipoCertificado = certificadoOrigen.getCodtipoCO();
			if (SunatStringUtils.include(codigoTipoCertificado, arrayTipoCertificado)) {			
				Date feciniembarque = certificadoOrigen.getFeciniembarque();
				Date fecfinembarque = certificadoOrigen.getFecfinembarque();
				erroresValidacion = valAutocer.validarFechaInicioFinEmbarque(fecfinembarque, feciniembarque, serie.getNumserie().toString());
			}
		}
		return erroresValidacion;
	}


	@ServicioAnnot(tipo="V",codServicio=3357, descServicio="Para tipo de certificado de origen igual a 5 se valida el criterio de origen asociado")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3357,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valCriterioOrigenParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//rtineo optimizacion
		listError = valCriterioOrigen(serie, arrayTipoCertificado,variablesIngreso);
		//fin optimizacion
		return listError;		
	}


	@ServicioAnnot(tipo="V",codServicio=3358, descServicio="Para tipo de certificado de origen igual a 1 y 5 se valida el criterio de origen asociado")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3358,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valCriterioOrigenParaUnEmbarqueDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//rtineo optimizacion, se agrega variablesIngreso
		listError = valCriterioOrigen(serie, arrayTipoCertificado,variablesIngreso);
		//fin optimizacion
		return listError;		
	}

	@ServicioAnnot(tipo="V",codServicio=3359, descServicio="Para tipo de certificado de origen igual a 2 valida que la fecha de embarque est� comprendido entre la fecha de inicio de embarque y fin de embarque del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3359,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")	
	public Map<String, String> valFechaEmbarqueParaMultiplesEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);		
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String indTrans = listCertificadoOrigen.get(0).getIndtrans();					
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			Date fechaEmbarqueRef = documentoTransporte.getFecembarque();
			if ((!SunatStringUtils.isEmptyTrim(indTrans)) && (indTrans.equals(ConstantesDataCatalogo.CON_TRANSITO_TERCER_PAIS) || indTrans.equals(ConstantesDataCatalogo.CON_ALMACENAMIENTO_TEMPORAL))){// control de nulo
				fechaEmbarqueRef = documentoTransporte.getFecembarqueorg();
			}
			Date feciniembarque = listCertificadoOrigen.get(0).getFeciniembarque();
			Date fecfinembarque = listCertificadoOrigen.get(0).getFecfinembarque();
			if (feciniembarque != null && fecfinembarque!= null) {
				listError = valAutocer.fecembarque(feciniembarque, fecfinembarque, fechaEmbarqueRef, serie.getNumserie().toString());
			}
		}
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3371, descServicio="Para tipo de certificado de origen igual a 5, valida que la  Fecha de Emisi�n de la Declaraci�n sea menor o igual a la fecha de embarque")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3371,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")	
	public Map<String, String> valFechaEmbarqueParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {				
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			Date fechaEmbarque = documentoTransporte==null? null: documentoTransporte.getFecembarque();
			Date fecEmision = listCertificadoOrigen.get(0).getFecemision();	
			listError = valAutocer.fecembarque(fechaEmbarque, fecEmision, serie.getNumserie().toString());
		}
		return listError;
	}

	@ServicioAnnot(tipo="V",codServicio=3360, descServicio="Para tipo de certificado de origen igual a 2 valida que las fecha de periodos de embarques con respecto a la fecha de emision del CO")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3360,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")	
	public List<Map<String, String>> valPeriodoEmbarquesParaMultiplesEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			Date feciniembarque = listCertificadoOrigen.get(0).getFeciniembarque();
			Date fecfinembarque = listCertificadoOrigen.get(0).getFecfinembarque();
			// Si no envio la fecha de inicio o fin, se controla con el servicio 3361
			if (CollectionUtils.isEmpty(valAutocer.fecinifinembarque(fecfinembarque, feciniembarque,serie.getNumserie().toString()))) {			
				Date fecemision = listCertificadoOrigen.get(0).getFecemision();
				Integer codConvenio = serie.getCodconvinter();
				/*Plazo de validacion para periodo de embarque */
				//rtineo optimizacion; se agrega variableIngreso
				String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_PERIODO_EMBARQUE, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso);
				Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_PERIODO_EMBARQUE, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso));
				//fin optimizacion
				if (fecemision != null){
					if (codTipoPlazo.equals("Y") ){
						listError.add(valAutocer.valfecemisionPlazoAnios(fecemision, feciniembarque, numTipoPlazo, serie.getNumserie().toString(),"30701", "30700"));
						listError.add(valAutocer.valfecemisionPlazoAnios(fecemision, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(),"30701", "30700"));	
					} 
					if (codTipoPlazo.equals("M") ){
						listError.add(valAutocer.valfecemisionPlazoMeses(fecemision, feciniembarque, numTipoPlazo, serie.getNumserie().toString(),"30701", "30700"));
						listError.add(valAutocer.valfecemisionPlazoMeses(fecemision, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(),"30701", "30700"));
					} 		
					if (codTipoPlazo.equals("D") ){
						listError.add(valAutocer.valfecemisionPlazoDias(fecemision, feciniembarque, numTipoPlazo, serie.getNumserie().toString(), "30701", "30700"));
						listError.add(valAutocer.valfecemisionPlazoDias(fecemision, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(), "30701", "30700"));
					}
				}
			} 
		}
		return listError;
	}
	
	


	@ServicioAnnot(tipo="V",codServicio=3361, descServicio="Para tipo de certificado de origen igual a 2 valida que la diferencia entre las fechas de periodos de embarques esten dentro del plazo")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3361,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")	
	public List<Map<String, String>> valDiferenciaPeriodoEmbarquesParaMultipleEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			Date feciniembarque = listCertificadoOrigen.get(0).getFeciniembarque();
			Date fecfinembarque = listCertificadoOrigen.get(0).getFecfinembarque();
			if (feciniembarque != null && fecfinembarque!= null) {
				Integer codConvenio = serie.getCodconvinter();
				String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_PERIODO_EMBARQUE, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso);
				Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_PERIODO_EMBARQUE, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso));
				//fin optimizacion
				if (codTipoPlazo.equals("Y") ){
					listError.add(valAutocer.valfecemisionPlazoAnios(feciniembarque, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(), "30703","30702"));
				} 
				if (codTipoPlazo.equals("M") ){
					listError.add(valAutocer.valfecemisionPlazoMeses(feciniembarque, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(), "30703","30702"));
				} 		
				if (codTipoPlazo.equals("D") ){
					listError.add(valAutocer.valfecemisionPlazoDias(feciniembarque, fecfinembarque, numTipoPlazo, serie.getNumserie().toString(), "30703","30702"));
				}
			}
			//}
		}
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3398, descServicio="Para tipo de certificado de origen igual a 2 valida que la Fecha de Inicio de Per�odo de Embarque debe ser menor a la Fecha Fin de Per�odo de Embarque")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3398,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")	
	public List<Map<String, String>>  valFechasPeriodoEmbarquesParaMultipleEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		List<Map<String, String>>  listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			Date feciniembarque = listCertificadoOrigen.get(0).getFeciniembarque();
			Date fecfinembarque = listCertificadoOrigen.get(0).getFecfinembarque();
			listError = valAutocer.fecinifinembarque(fecfinembarque, feciniembarque, serie.getNumserie().toString());
		}
		return listError;
	}

	@ServicioAnnot(tipo="V",codServicio=3362, descServicio="Para tipo de certificado de origen igual a 1 valida que se consigne el nombre del productor")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3362,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public Map<String, String> valNombreProductorParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String indTipElectro = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getIndElectronico():"";
		if(!Constantes.INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(indTipElectro)) {//Se adiciona por pase PAS20181U220200056
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valNombreProductor(serie, arrayTipoCertificado);
		}
		return listError;
	}


	@ServicioAnnot(tipo="V",codServicio=3363, descServicio="Para tipo de certificado de origen igual a 1,2 o 6 valida que se consigne el nombre del productor")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3363,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public Map<String, String> valNombreProductorParaEmbarquesConocimiento (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES, ConstantesDataCatalogo.TIPO_CONOCIMIENTO_IMPOR};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valNombreProductor(serie, arrayTipoCertificado);
		return listError;
	}
	

	@ServicioAnnot(tipo="V",codServicio=3364, descServicio="Para tipo de certificado de origen igual a 1 y 2 valida que se consigne el nombre del productor")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3364,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public Map<String, String> valNombreProductorParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valNombreProductor(serie, arrayTipoCertificado);
		return listError;
	}


	@ServicioAnnot(tipo="V",codServicio=3365, descServicio="Para tipo de certificado de origen igual a 1 es necesario que se haya transmitido el N�mero de registro del funcionario autorizado")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3365,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public List<Map<String, String>> valRegistroFuncionarioParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String indTipElectro = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getIndElectronico():"";
		if(!Constantes.INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(indTipElectro)) {//Se adiciona por pase PAS20181U220200056
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valRegistroFuncionarioParaUnEmbarque(serie, arrayTipoCertificado);
		}
		
		return listError;
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3417, descServicio="Para tipo de certificado de origen igual a 1 es necesario que se haya transmitido el N�mero de registro del funcionario autorizado")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3417,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public List<Map<String, String>> valRegistroFuncionarioParaUnEmbarqueSinIndLC(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		if(indicador15== null){
			listError = valRegistroFuncionarioParaUnEmbarque(serie, arrayTipoCertificado);
		}
		
				
		return listError;
	}
	//SE FACTORIZA LA VALIDACION 
	private List<Map<String, String>> valRegistroFuncionarioParaUnEmbarque(DatoSerie serie,String[] arrayTipoCertificado){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			String codffco = listCertificadoOrigen.get(0).getCodffco();
			Map<String, String> maperror = valAutocer.numdocumentoSN(codffco, serie.getNumserie().toString());
			if (!maperror.isEmpty()){

				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30705",new String[] {serie.getNumserie().toString()}));
			} else {
				listError.add(valAutocer.valcodffco(serie.getNumserie().toString(), codffco));
			}
		}		
		return listError;
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3366, descServicio="Para tipo de certificado de origen igual a 1, el N�mero de registro del funcionario autorizado debe existir en modulo de registro de firmas")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3366,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public Map<String, String> valExisteRegistroFuncionarioParaUnEmbarque (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String indTipElectro = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getIndElectronico():"";		
		if(!Constantes.INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(indTipElectro)) {//Se adiciona por pase PAS20181U220200056
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valExisteRegistroFuncionarioParaUnEmbarque(serie, arrayTipoCertificado);
		}
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3418, descServicio="Para tipo de certificado de origen igual a 1, el N�mero de registro del funcionario autorizado debe existir en modulo de registro de firmas, cuando no tiene Ind. LC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3418,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public Map<String, String> valExisteRegistroFuncionarioParaUnEmbarqueSinIndLC (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		
		DUA dua = (DUA) serie.getPadre();
		Declaracion d = new Declaracion();
		
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		if(indicador15== null){
			listError = valExisteRegistroFuncionarioParaUnEmbarque(serie, arrayTipoCertificado); 
		}
				
		return listError;
	}
	
	//SE FACTORIZA EL CODIGO
	private Map<String, String> valExisteRegistroFuncionarioParaUnEmbarque (DatoSerie serie, String[] arrayTipoCertificado){
		Map<String, String> listError = new HashMap<String, String>();
		CertiOrigenService certiOrigenService = fabricaDeServicios.getService("certiOrigenService");
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			String codffco = listCertificadoOrigen.get(0).getCodffco();
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			String codpais = serie.getCodpaisorige();
			if (fecemision != null && !SunatStringUtils.isEmptyTrim(codffco)) {
				//Solo entra a validar si el servicio 3365 no dio error- usamos el numdocumentoSN ambos servicios amarrados
				ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
				Map<String, String> maperror = valAutocer.numdocumentoSN(codffco, serie.getNumserie().toString());
				if (maperror.isEmpty()){
			List<Map<String,Object>> listJoinPruperso = certiOrigenService.consultarRegistroFuncionario(codffco, codpais, fecemision);	
			if (CollectionUtils.isEmpty(listJoinPruperso)) {
						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30706",new String[] {serie.getNumserie().toString(), codffco, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
					}
				}
			}
		}		
		return listError;
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3401, descServicio="Para tipo de certificado de origen igual a 1, Si se envia el N�mero de registro del funcionario autorizado debe existir en modulo de registro de firmas")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3401,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public Map<String, String> valExisteRegistroFuncionarioCondUnEmbar (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		CertiOrigenService certiOrigenService = fabricaDeServicios.getService("certiOrigenService");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			String codffco = listCertificadoOrigen.get(0).getCodffco();
			if (!SunatStringUtils.isEmptyTrim(codffco)) {
				Date fecemision = listCertificadoOrigen.get(0).getFecemision();
				String codpais = serie.getCodpaisorige();
				List<Map<String,Object>> listJoinPruperso = certiOrigenService.consultarRegistroFuncionario(codffco, codpais, fecemision);	
				if (CollectionUtils.isEmpty(listJoinPruperso)) {

					/*INICIO-P34 PAS20165E220200126 AFMA*/
					String codTransaccion = variablesIngreso.get("codTransaccion").toString();
					if("1019".equals(codTransaccion)){
						listError = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("37030", new String[]{serie.getNumserie().toString()});
					}else {
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30706",new String[] {serie.getNumserie().toString(), codffco, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
				}
			}
		}		
		}		
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3367, descServicio="Para tipo de certificado de origen igual a 1 y 2 se valida que se envie correctamente el Tipo de emisor del certificado de origen asociado al TLC respectivo")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3367,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valTipoEmisorParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//rtineo optimizacion, se agrega variableIngreso
		listError = valTipoEmisorCertiOrigen(serie, arrayTipoCertificado, ConstantesAtributo.GRUPO_EMISOR_CERTIORIGEN,variablesIngreso);
		//fin optimizacion
		return listError;		
	}

	@ServicioAnnot(tipo="V",codServicio=3368, descServicio="Para tipo de certificado de origen igual a 5 se valida que se envie correctamente el Tipo de emisor del certificado de origen asociado al TLC respectivo")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3368,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valTipoEmisorParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//rtineo optimziacion, se agrega variablesIngreso
		listError = valTipoEmisorCertiOrigen(serie, arrayTipoCertificado, ConstantesAtributo.GRUPO_EMISOR_DECLAORIGEN,variablesIngreso);
		//fin optimizacion
		return listError;		
	}

	
	@ServicioAnnot(tipo="V",codServicio=3369, descServicio="Para tipo de certificado de origen igual a 1 y 2 valida que se consigne el nombre del emisor del certificado")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3369,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public Map<String, String> valNombreEmisorParaEmbarques (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_UN_SOLO_EMBARQUE, ConstantesDataCatalogo.TIPO_MULTIPLES_EMBARQUES};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valNombreEmisor(serie, arrayTipoCertificado,"30708");
		return listError;
	}
	

	@ServicioAnnot(tipo="V",codServicio=3370, descServicio="Para tipo de certificado de origen igual a 5 valida que se consigne el nombre del emisor de la Declaracion de Origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3370,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")		
	public Map<String, String> valNombreEmisorParaDeclaracion (DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		listError = valNombreEmisor(serie, arrayTipoCertificado,"30708");
		return listError;
	}
	

	
	@ServicioAnnot(tipo="V",codServicio=3374, descServicio="Para tipo de certificado de origen igual a 6, se verifica que no se envie los datos del certificado de origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3374,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valEnvioCertificadoParaConocimientoImportador(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_CONOCIMIENTO_IMPOR};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen) ? null:listCertificadoOrigen.get(0).getCodtipoCO();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String numdocumento = listCertificadoOrigen.get(0).getNumdocumento();
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			String codtipoemisorCO = listCertificadoOrigen.get(0).getCodtipoemisorCO();
			String nomemisorCO = listCertificadoOrigen.get(0).getNomemisorCO();
			listError = valAutocer.sinEnviarNumCOEmisorFecha(numdocumento, fecemision, codtipoemisorCO, nomemisorCO, serie.getNumserie().toString(), codTipoCO);	
		}
		return listError;
	}
	

	//glazaror... optimizacion... se invoca al nuevo metodo para evitar llamadas REST a nivel de series
	private Map<String, String> valPlazoConSinPrecedencia(DatoSerie serie, DatoAutocertificacion certificadoOrigen, Date fechaReferencia, Date fecemision, 
            String codTipoPlazo, Integer numTipoPlazo, boolean flagPrecedencia,String codTransaccion, boolean esTPIRectificado){//Pase 548
		return valPlazoConSinPrecedencia(serie, certificadoOrigen, fechaReferencia, fecemision, codTipoPlazo, numTipoPlazo, flagPrecedencia, codTransaccion, esTPIRectificado, null);
	}
	
	/**
	 * Valida los plazos cuando tiene o no regimen de precedencia
	 * Modificado para trabajar con variablesIngreso y evitar llamadas REST a nivel de series
	 * @param dua
	 * @param serie
	 * @param codConvenio
	 * @param fechaReferencia
	 * @param fecemision
	 * @return
	 */
	private Map<String, String> valPlazoConSinPrecedencia(DatoSerie serie, DatoAutocertificacion certificadoOrigen, Date fechaReferencia, Date fecemision, 
			                                              String codTipoPlazo, Integer numTipoPlazo, boolean flagPrecedencia,String codTransaccion, boolean esTPIRectificado, Map<String, Object> variablesIngreso){//Pase 548
		Map<String, String> listError = new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		RegimenesPrecedentesService regimenesPrecedentesService = fabricaDeServicios.getService("regimenesPrecedentesService");
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");		
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		
		Integer codConvenio = serie.getCodconvinter();
		
		//Fecha de emision tiene que ser menor a la fecha de numeracion de la dua
		if (SunatDateUtils.esFecha1MenorQueFecha2(fechaReferencia, fecemision, SunatDateUtils.COMPARA_SOLO_FECHA)){//Ajuste Pase105 II
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30893",new String[] {serie.getNumserie().toString(), SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"), SunatDateUtils.getFormatDate(fechaReferencia, "dd/MM/yyyy")});
			return listError;//actualizar 30893: SERIE ({0}):  FECHA DE EMISION DEL CERTIFICADO O DECLARACION DE ORIGEN ({1}) ES POSTERIOR A LA FECHA DE REFERENCIA ({2})
		}

		//glazaror... invocamos al nuevo metodo para trabajar con variablesIngreso y asi evitar continuas llamadas REST
		String codTipoPlazoTransito = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_CERTIFICADO_TRANSITO, 
				ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
				ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso);
		
		/* Si existe el atributo de calculo por indicador de transito se obtiene el valor correspondiente y el indicador de transito es igual 3-ALMACENAMIENTO TEMPORAL*/
		if (codTipoPlazoTransito!= null){
			String indTrans = certificadoOrigen.getIndtrans();
			if (ConstantesDataCatalogo.CON_ALMACENAMIENTO_TEMPORAL.equals(indTrans)){//ajuste por nullpointer
				codTipoPlazo = codTipoPlazoTransito;
				//glazaror... invocamos al nuevo metodo para trabajar con variablesIngreso y asi evitar continuas llamadas REST
				numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo(ConstantesAtributo.NUM_PLAZO_CERTIFICADO_TRANSITO, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso));
			}
		}
		
		   Date fechaComputoPlazo = fechaReferencia; //Pase548 II: en el metodo anterior se sete� si era primera vez la fecha de recti sino por defecto la numeraci�n
		
		//EGH_PAS20165E220100028   
		//if (flagPrecedencia /* && !esTPIRectificado  */){//Pase548 II:   no varia fecha de plazo
			if (flagPrecedencia && tpiExcluirPrecedencia(codConvenio.toString())){//valida exclusi�n de la precedencia pase 66 jreynoso
			DUA dua = (DUA) serie.getPadre(); 
			List<Object> listObject = regimenesPrecedentesService.obtenerDeclaracionPrecedenteDeposito(dua);
			if (CollectionUtils.isNotEmpty(listObject)){
				//Si la fecha de emisi�n del certificado de origen es igual o mayor a la fecha de numeraci�n de la DUA 70 (Dep�sito Aduanero), 
				//el sistema acepta la trasmisi�n de la fecha del certificado de origen
				Date fecemisionPrecedente = regimenesPrecedentesService.fecemisionPrecedencia(listObject);
				//EGH_PAS20165E220100028
				if(fecemisionPrecedente!=null){
				if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fecemision, fecemisionPrecedente, SunatDateUtils.COMPARA_SOLO_FECHA)){
					//fechaComputoPlazo = fecemision;
					return listError;
				} else {
					fechaComputoPlazo = fecemisionPrecedente; 
				}
			}
		}
		}
		if (fecemision != null) {
			if (codTipoPlazo.equals("Y") ){
				listError = valAutocer.valfecemisionPlazoAnios(fecemision, fechaComputoPlazo, numTipoPlazo, serie.getNumserie().toString(),"30694","30693");				
			} 
			if (codTipoPlazo.equals("M") ){
				listError = valAutocer.valfecemisionPlazoMeses(fecemision, fechaComputoPlazo, numTipoPlazo, serie.getNumserie().toString(), "30694","30693");
			} 		
			if (codTipoPlazo.equals("D") ){
				listError = valAutocer.valfecemisionPlazoDias(fecemision, fechaComputoPlazo, numTipoPlazo, serie.getNumserie().toString(), "30694","30693");
			}
		}
		return listError;
	}

	//rtineo optimizacion
	/**
	 * Sobrecargamos el metodo
	 * @param serie
	 * @param arrayTipoCertificado
	 * @return
	 */
	private Map<String, String> valCriterioOrigen(DatoSerie serie, String[] arrayTipoCertificado){
		return valCriterioOrigen(serie, arrayTipoCertificado,null);
	}
	//fin optimizacion
	
	/**
	 * Valida el criterio de origen de acuerdo al tipo de certificado y valor de criterio enviado
	 * @param serie
	 * @param arrayTipoCertificado
	 * @return
	 */
	//rtineo optimizacion
	private Map<String, String> valCriterioOrigen(DatoSerie serie, String[] arrayTipoCertificado, Map<String,Object> variablesIngreso){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		Map<String, String> listError = new HashMap<String, String>();
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO 	= listCertificadoOrigen.get(0).getCodtipoCO();
		String codCriterioO = listCertificadoOrigen.get(0).getCodcriterioO();
		Integer codConvenio = serie.getCodconvinter();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			if (codCriterioO == null){
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30889", new String[] {serie.getNumserie().toString(), codConvenio.toString()});
			} else {
				//rtineo optimizacion
				String codGrupoTipoCriterioOrigen  = tpiService.obtenerAtributo(ConstantesAtributo.GRUPO_CRITERIO_ORIGEN, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso);
				//fin optimizacion
				boolean isCriterioValido = isCriterioValido(ConstantesAtributo.GRUPO_CRITERIO_ORIGEN,codGrupoTipoCriterioOrigen,SunatStringUtils.toNotNull(codCriterioO),variablesIngreso);
				if(!isCriterioValido || codCriterioO == null){
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30698", new String[] {serie.getNumserie().toString(), codCriterioO, codConvenio.toString()});
				}							
			}			
		}
		return listError;	
	}
	
	//rtineo optimziacion
	/**
	 * validacion si es criterio valido
	 * @param identificadorGrupo
	 * @param codigoGrupoTipoCriterioOrigen
	 * @param codigoCriterio
	 * @param variablesIngreso
	 * @return
	 */
	private boolean isCriterioValido(String identificadorGrupo, String codigoGrupoTipoCriterioOrigen, String codigoCriterio, Map<String, Object> variablesIngreso) {
		//msnade236_1 se comenta codigo para reutilizar el nuevo isCriterioValido
		return isCriterioValido(identificadorGrupo, codigoGrupoTipoCriterioOrigen, codigoCriterio, variablesIngreso, new Date());
		/*if (variablesIngreso != null) {
			String identificador = identificadorGrupo + "_" + codigoGrupoTipoCriterioOrigen;
			Map<String, String> grupoTipoCriterioOrigen = (Map<String, String>) variablesIngreso.get(identificador);
			if (grupoTipoCriterioOrigen == null) {
				grupoTipoCriterioOrigen = new HashMap<String, String>();
				List<Map<String, String>> elementosGrupo = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getListaElementosGrupo(codigoGrupoTipoCriterioOrigen);
				for (Map<String, String> elemento : elementosGrupo) {
					grupoTipoCriterioOrigen.put(elemento.get("cod_datacat"), elemento.get("cod_datacat"));
				}
				variablesIngreso.put(identificador, grupoTipoCriterioOrigen);
			}
			return grupoTipoCriterioOrigen.containsKey(codigoCriterio);
		} else {
			//logica antigua... sin usar variablesIngreso
			return CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoGrupo(codigoGrupoTipoCriterioOrigen, SunatStringUtils.toNotNull(codigoCriterio)));
		}*/
	}
	//fin optimizacion
	
	/**
	 * validacion si es criterio valido
	 * proyecto msnade236_1
	 * @param identificadorGrupo
	 * @param codigoGrupoTipoCriterioOrigen
	 * @param codigoCriterio
	 * @param variablesIngreso
	 * @return
	 */
	private boolean isCriterioValido(String identificadorGrupo, String codigoGrupoTipoCriterioOrigen, String codigoCriterio, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		if (variablesIngreso != null) {
			String identificador = identificadorGrupo + "_" + codigoGrupoTipoCriterioOrigen;
			Map<String, String> grupoTipoCriterioOrigen = (Map<String, String>) variablesIngreso.get(identificador);
			if (grupoTipoCriterioOrigen == null) {
				grupoTipoCriterioOrigen = new HashMap<String, String>();
				List<Map<String, String>> elementosGrupo = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getListaElementosGrupo(codigoGrupoTipoCriterioOrigen, fechaReferencia);
				for (Map<String, String> elemento : elementosGrupo) {
					grupoTipoCriterioOrigen.put(elemento.get("cod_datacat"), elemento.get("cod_datacat"));
				}
				variablesIngreso.put(identificador, grupoTipoCriterioOrigen);
			}
			return grupoTipoCriterioOrigen.containsKey(codigoCriterio);
		} else {
			//logica antigua... sin usar variablesIngreso
			return CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoGrupo(codigoGrupoTipoCriterioOrigen, SunatStringUtils.toNotNull(codigoCriterio)));
		}
	}
	
	/**
	 * Valida que se envie el nombre del productor
	 * @param serie
	 * @param arrayTipoCertificado
	 * @return
	 */
	private Map<String, String> valNombreProductor(DatoSerie serie, String[] arrayTipoCertificado){
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		Map<String, String> listError = new HashMap<String, String>();
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String nomproduc = listCertificadoOrigen.get(0).getNomproduc();
			listError = valAutocer.nomproduc(nomproduc, codTipoCO, serie.getNumserie().toString());
		}
		return listError;
	}

	/**
	 *  Valida que el tipo de emisor del certificado de origen coincida con el tipo de TLC y tipo de certificado
	 * @param serie
	 * @param arrayTipoCertificado
	 * @param codAtributo
	 * @return
	 */
	//rtineo optimizacion, sobrecargamos el metodo
	private Map<String, String> valTipoEmisorCertiOrigen(DatoSerie serie, String[] arrayTipoCertificado, String codAtributo){
		return valTipoEmisorCertiOrigen(serie, arrayTipoCertificado, codAtributo,null);
	}
	//fin optimizacion
	/**
	 * Valida que el tipo de emisor del certificado de origen coincida con el tipo de TLC y tipo de certificado
	 * @param serie
	 * @param arrayTipoCertificado
	 * @return
	 */
	//rtineo optimizacion se agrega variablesIngreso para guardar valores comunes
	private Map<String, String> valTipoEmisorCertiOrigen(DatoSerie serie, String[] arrayTipoCertificado, String codAtributo,Map<String,Object> variablesIngreso){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		Map<String, String> listError = new HashMap<String, String>();
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO 	   = listCertificadoOrigen.get(0).getCodtipoCO();
		String codTipoEmisorCO = listCertificadoOrigen.get(0).getCodtipoemisorCO();
		Integer codConvenio = serie.getCodconvinter();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			//rtineo optimizacion, se agrega vriablesIngreso y se utiliza nuevo metodo de validacion de criterio
			String codGrupoTipoEmisor  = tpiService.obtenerAtributo(codAtributo, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(),variablesIngreso);				
			boolean isCriterioValido = isCriterioValido(codAtributo,codGrupoTipoEmisor,SunatStringUtils.toNotNull(codTipoEmisorCO),variablesIngreso);
			if (!isCriterioValido || codTipoEmisorCO == null){
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30707", new String[] {serie.getNumserie().toString(),codTipoEmisorCO, codConvenio.toString()});
			}
			//fin optimizacion
		}
		return listError;	
	}
	//fin optimi<zacion
	/**
	 * Valida que se evie el nombre del emisor del Certificado de origen
	 * @param serie
	 * @param arrayTipoCertificado
	 * @return
	 */
	public Map<String, String> valNombreEmisor(DatoSerie serie, String[] arrayTipoCertificado, String codError){
		ValAutocer valAutocer = fabricaDeServicios.getService("ValAutocer");
		Map<String, String> listError = new HashMap<String, String>();
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String nomemisorCO = listCertificadoOrigen.get(0).getNomemisorCO();
			listError = valAutocer.nomemisorCO(nomemisorCO, serie.getNumserie().toString(),codTipoCO, codError);
		}
		return listError;
	}
	
		

	
	/**Pase548 II 
	 * Permite realizar la validacion del plazo de la rectificacion del TPI acorde a si es primera vez o no
	 * @param serie
	 * @param variablesIngreso
	 * @param fechaReferencia
	 * @param declaracionBD
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=3394, descServicio="validacion del plazo de la rectificacion del TPI ")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia", "declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3394,numSecEjec=171,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarPlazoRectificacionTPI (DatoSerie serie, Map<String, Object> variablesIngreso, 
			Date fechaReferencia, Declaracion declaracionBD ){

		Map<String, String> listError = new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		Date fechaRectificacion = new Date();

		if (!tpiService.validarServicioTLC (this, serie, new Date(), variablesIngreso)){//bug 17303 Pase 548
			return listError;
		}

		//determinar si es rectificaci�n o primera vez	
		boolean esRectificacionTPI = tpiService.esRectificacionTPI(serie, declaracionBD);	 
		if(esRectificacionTPI){			

		//obtener el tiempo limite-plazo:
			Integer codConvenio = serie.getCodconvinter();
			String codTipoPlazo = tpiService.obtenerAtributo(ConstantesAtributo.TIPO_PLAZO_RECTIFICACION, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString());
	
			Integer numTipoPlazo = SunatNumberUtils.toInteger(tpiService.obtenerAtributo( ConstantesAtributo.NUM_PLAZO_RECTIFICACION,
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
	
			if (fechaReferencia != null) {
				listError =  valfecemisionPlazosRecti(fechaReferencia, fechaRectificacion, codTipoPlazo, numTipoPlazo, codConvenio, serie.getNumserie().toString(),"30772");
			}
		}
		return listError;
	}		

	/**Pase548 II
	 * M�todo que permite validar la fecha de emision vs la Rectifiaci�n acorde cat�logos de TPI
	 * @param fecemision
	 * @param fecReferencia
	 * @param codTipoPlazo
	 * @param numTipoPlazo
	 * @param codConvenio
	 * @param numserie
	 * @param codError
	 * @return
	 */
	public Map<String, String> valfecemisionPlazosRecti (Date fecemision, Date fecReferencia, String codTipoPlazo, Integer numTipoPlazo, 
			Integer codConvenio, String numserie, String codErr){
		
		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fecReferencia, fecemision, "COMPARA_SOLO_FECHA")){			
		
			Date fechaCalculada = null;
			String descrPlazo = " ";
			if (codTipoPlazo.equals("Y") ){
				fechaCalculada = SunatDateUtils.addYear(fecemision, numTipoPlazo);
				descrPlazo="ANO(S)";
			} 
			if (codTipoPlazo.equals("M") ){
				fechaCalculada = SunatDateUtils.addDay(fecemision, numTipoPlazo);		
				descrPlazo="MES(ES)"; 
			} 		
			if (codTipoPlazo.equals("D") ){
				fechaCalculada = SunatDateUtils.addMonth(fecemision, numTipoPlazo);
				descrPlazo="DIA(S)";
			}
			if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecReferencia, fechaCalculada, "COMPARA_SOLO_FECHA")){
				return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr, new String[] {numserie,codConvenio.toString(),
					numTipoPlazo.toString(), descrPlazo , SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
			}
		}
		return new HashMap<String, String>();
	}
	

	
	/**Pase548 II
	 * Permite validar que el TPI no sea posterior a la fecha de pago de tributos
	 * @param serie
	 * @param variablesIngreso
	 * @param declaracionBD
	 * @return
	 * Bugs  17783 y 17889 arey (habilitar para TPI 229 - TPI 100)
	 */ 
	@ServicioAnnot(tipo="V",codServicio=3435, descServicio="Valida que el TPI no sea posterior a la fecha de pago de tributos")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia", "declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3435,numSecEjec=171,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarTPIPosteriorPagoTributos(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD )throws Exception{
		
		Map<String, String> listError = new HashMap<String, String>();
		Date fechaRectificacion = new Date();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
	
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)){//pase 399
			return listError;
		}
		
		//Adicionado por errores en rectis que no tienen cambios de TPI: arey PASE436
        boolean esRectificacionTPI = tpiService.esRectificacionTPI(serie, declaracionBD);      
        if(esRectificacionTPI){//Adicionado por errores en rectis que no tienen cambios de TPI: arey PASE436
	
	
			if(declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia().toString().equals(null) 
							|| declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia().toString().equals("")
							|| declaracionBD.getDua().getPago().getPagoDeclaracion().getCodgarantia().toString().equals(" ")){
						 
				 	DeudaDocum tmpDeudaDocum = new DeudaDocum();
					tmpDeudaDocum.setNumCorredoc(declaracionBD.getDua().getNumcorredoc());
					tmpDeudaDocum.setCodTipdeuda("01");// Tipo De Deuda 
					tmpDeudaDocum.setCodEstpago("P");
					List<DeudaDocum> lstDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
					Date dtFechaPagoDeuda=null;
					
					for (DeudaDocum deudaDocum:lstDeudaDocum) {
						DetPagodua tmpDetPagodua = new DetPagodua();
						tmpDetPagodua.setNumCorredoc(deudaDocum.getNumCorredoc());
						tmpDetPagodua.setNumIdentdeuda(deudaDocum.getNumIdentdeuda());							
						List<DetPagodua> lstPagos =((DetPagoDuaDAO)fabricaDeServicios.getService("detPagoDuaDAO")).selectByDocumento(tmpDetPagodua);
						
						if(!CollectionUtils.isEmpty(lstPagos)){
							DetPagodua detPago=lstPagos.get(0);
							dtFechaPagoDeuda=detPago.getFecPago();								
						}
					}
					 if(dtFechaPagoDeuda!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaRectificacion, dtFechaPagoDeuda, SunatDateUtils.COMPARA_SOLO_FECHA)){ //se cambia por bug 17783
						 return((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35256", new String[] {serie.getNumserie().toString(),serie.getCodconvinter().toString()});
						// listError.add(catalogoAyudaService.getError("35256", new String[]{serie.getNumserie().toString(),serie.getCodconvinter().toString()}));
					 }					
						
			}else{//tiene Garantia (compara con levante)
					//TLC Peru Corea se adiciona primera condicion, esta validando la default date como fecha de levante valida
					Date fecha_default   = DateUtil.getDefaultDate();
					if(!(declaracionBD.getDua().getFecAutlevante().compareTo(fecha_default)==0) && SunatDateUtils.esFecha1MayorQueFecha2(fechaRectificacion, declaracionBD.getDua().getFecAutlevante(), SunatDateUtils.COMPARA_SOLO_FECHA)){
						 return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30900", new String[] {serie.getNumserie().toString(),serie.getCodconvinter().toString()});
						//listError.add(catalogoAyudaService.getError("30900", new String[]{serie.getNumserie().toString(),serie.getCodconvinter().toString()}));
					}
			}
        }//Adicionado por errores en rectis que no tienen cambios de TPI: arey PASE436
		return listError;
	}
	

	 
	/**Pase548 II
	 * Permite validar que el TPI no sea posterior a la fecha de levante
	 * @param serie
	 * @param variablesIngreso
	 * @param declaracionBD
	 * @return
	 * Bug  17745 arey (habilitar para TPI 808)
	 */ 
	@ServicioAnnot(tipo="V",codServicio=3436, descServicio="Valida que el TPI no sea posterior a la fecha de levante")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia", "declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3436,numSecEjec=171,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarTPIPosteriorLevante(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracionBD) throws Exception{
			Map<String, String> listError = new HashMap<String, String>();
			 
			TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");	
			Date fecha_default   = DateUtil.getDefaultDate();
				
			if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)){//pase399

				return listError;
			}
			
			//Adicionado por errores en rectis que no tienen cambios de TPI: arey PASE436
            boolean esRectificacionTPI = tpiService.esRectificacionTPI(serie, declaracionBD);       
            if(esRectificacionTPI){//Adicionado por errores en rectis que no tienen cambios de TPI: arey PASE436
				Date fechaRectificacion = new Date();
				if (!(declaracionBD.getDua().getFecAutlevante().compareTo(fecha_default)==0) && fechaRectificacion.compareTo(declaracionBD.getDua().getFecAutlevante())>0){
					//No puede rectificar el TPI 808 despu�s de la fecha del levante
					return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30900", new String[] {serie.getNumserie().toString(),serie.getCodconvinter().toString()});
					//listError.add(catalogoAyudaService.getError("30900", new String[]{serie.getNumserie().toString(),serie.getCodconvinter().toString()}));
				}
            }//Adicionado por errores en rectis que no tienen cambios de TPI: arey PASE436
			return listError;
	}	
	
	
	/**
	 * Se verifica para los tpi que no valide regimen de precedencia 70  si estan el grupo 951
	 * @param codConvenio
	 * @return
	 */
	private boolean tpiExcluirPrecedencia(String codConvenio) {
		boolean tpiExcluyePrecedencia = true;
		String codTPI = codConvenio;
		DataGrupoCat valTpi = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataGrupoCat(ConstantesGrupoCatalogo.COD_GRUPO_TPI_EXCLUYE_PRECEDENCIA, codTPI);
		if (valTpi != null){
				// No valida regimen de precedencia  70
			tpiExcluyePrecedencia = false;
			}
		return tpiExcluyePrecedencia;
	}
	
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}



	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}

