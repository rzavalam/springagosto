package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

/*import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValAdidua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValAutocer;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValCabdua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValContrat;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDeclaran;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDetdua;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDocSop;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDoctrans;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValEmptrans;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValEquipa;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValIndicad;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValMGastos;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValMTrans;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValManifc;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValMcia;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocDuaregapFormA;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocNumeracFormA;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValObserv;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValPrecinto;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValProduct;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValRegprec;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValRucAnexoUbic;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValTribauto;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValCabdav;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValConTransFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValDeclaranteFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValDescMin;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValFactSuc;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValFactura;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValIntermediarioFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValItemFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValLibFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValObsFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValProveFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValProveLocFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValSerieItemFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValmontoFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif.ValRectifServiceImpl;*/

@Deprecated
public class GetValidacionesServiceImpl implements GetValidacionesService{

/*	private ValCabdua valCabdua;
	private ValAdidua valAdidua;
	private ValAutocer valAutocer;
	private ValContrat valContrat;
	private ValDeclaran valDeclaran; 
	private ValDetdua valDetdua;
	private ValDocSop valDocSop;
	private ValDoctrans valDoctrans;
	private ValEmptrans valEmptrans;
	private ValEquipa valEquipa;
	private ValFacturaref valFacturaref;
	private ValIndicad valIndicad;
	private ValManifc valManifc;
	private ValMcia valMcia;
	private ValMGastos valMGastos;
	private ValMTrans valMTrans;
	private ValObserv valObserv;
	private ValPrecinto valPrecinto;
	private ValProduct valProduct;
	private ValRucAnexoUbic valRucAnexoUbic;
	private ValRegprec valRegprec;
	private ValTribauto valTribauto;
	private ValVehiculo valVehiculo;
	private ValNegocNumeracFormA valNegocNumeracFormA;

	private ValCabdav valCabdav;
	private ValConTransFB valConTransFB;
	private ValDeclaranteFB valDeclaranteFB;
	private ValLibFB valLibFB;
	private ValDescMin valDescMin;
	private ValFactSuc valFactSuc;
	private ValFactura valFactura;
	private ValIntermediarioFB valIntermediarioFB;
	private ValItemFB valItemFB;
	private ValmontoFB valMontoFB;
	private ValObsFB valObsFB;
	private ValProveFB valProveFB;
	private ValProveLocFB valProveLocFB;
	private ValSerieItemFB valSerieItem;
	private ValidaAnexoDeclaracionServiceImpl validaAnexoDeclaracion;
	//private ValidacionGeneralService validaciongeneralservice;
	private ValRectifServiceImpl valRectif;
	//private ValidacionGeneralService validacionGeneralService;
	private AdmisionTemporalValidacionService admisionTemporalValidacioneService;
	private ValNegocDuaregapFormA valNegocDuaregapFormA;
	
	public ValCabdua getValCabdua() {
		return valCabdua;
	}
	public void setValCabdua(ValCabdua valCabdua) {
		this.valCabdua = valCabdua;
	}
	public ValAdidua getValAdidua() {
		return valAdidua;
	}
	public void setValAdidua(ValAdidua valAdidua) {
		this.valAdidua = valAdidua;
	}
	public ValAutocer getValAutocer() {
		return valAutocer;
	}
	public void setValAutocer(ValAutocer valAutocer) {
		this.valAutocer = valAutocer;
	}
	public ValContrat getValContrat() {
		return valContrat;
	}
	public void setValContrat(ValContrat valContrat) {
		this.valContrat = valContrat;
	}
	public ValDeclaran getValDeclaran() {
		return valDeclaran;
	}
	public void setValDeclaran(ValDeclaran valDeclaran) {
		this.valDeclaran = valDeclaran;
	}
	public ValDetdua getValDetdua() {
		return valDetdua;
	}
	public void setValDetdua(ValDetdua valDetdua) {
		this.valDetdua = valDetdua;
	}
	public ValDocSop getValDocSop() {
		return valDocSop;
	}
	public void setValDocSop(ValDocSop valDocSop) {
		this.valDocSop = valDocSop;
	}
	public ValDoctrans getValDoctrans() {
		return valDoctrans;
	}
	public void setValDoctrans(ValDoctrans valDoctrans) {
		this.valDoctrans = valDoctrans;
	}
	public ValEmptrans getValEmptrans() {
		return valEmptrans;
	}
	public void setValEmptrans(ValEmptrans valEmptrans) {
		this.valEmptrans = valEmptrans;
	}
	public ValEquipa getValEquipa() {
		return valEquipa;
	}
	public void setValEquipa(ValEquipa valEquipa) {
		this.valEquipa = valEquipa;
	}
	public ValFacturaref getValFacturaref() {
		return valFacturaref;
	}
	public void setValFacturaref(ValFacturaref valFacturaref) {
		this.valFacturaref = valFacturaref;
	}
	public ValIndicad getValIndicad() {
		return valIndicad;
	}
	public void setValIndicad(ValIndicad valIndicad) {
		this.valIndicad = valIndicad;
	}
	public ValManifc getValManifc() {
		return valManifc;
	}
	public void setValManifc(ValManifc valManifc) {
		this.valManifc = valManifc;
	}
	public ValMcia getValMcia() {
		return valMcia;
	}
	public void setValMcia(ValMcia valMcia) {
		this.valMcia = valMcia;
	}
	public ValMGastos getValMGastos() {
		return valMGastos;
	}
	public void setValMGastos(ValMGastos valMGastos) {
		this.valMGastos = valMGastos;
	}
	public ValMTrans getValMTrans() {
		return valMTrans;
	}
	public void setValMTrans(ValMTrans valMTrans) {
		this.valMTrans = valMTrans;
	}
	public ValObserv getValObserv() {
		return valObserv;
	}
	public void setValObserv(ValObserv valObserv) {
		this.valObserv = valObserv;
	}
	public ValPrecinto getValPrecinto() {
		return valPrecinto;
	}
	public void setValPrecinto(ValPrecinto valPrecinto) {
		this.valPrecinto = valPrecinto;
	}
	public ValProduct getValProduct() {
		return valProduct;
	}
	public void setValProduct(ValProduct valProduct) {
		this.valProduct = valProduct;
	}
	public ValRucAnexoUbic getValRucAnexoUbic() {
		return valRucAnexoUbic;
	}
	public void setValRucAnexoUbic(ValRucAnexoUbic valRucAnexoUbic) {
		this.valRucAnexoUbic = valRucAnexoUbic;
	}
	public ValRegprec getValRegprec() {
		return valRegprec;
	}
	public void setValRegprec(ValRegprec valRegprec) {
		this.valRegprec = valRegprec;
	}
	public ValTribauto getValTribauto() {
		return valTribauto;
	}
	public void setValTribauto(ValTribauto valTribauto) {
		this.valTribauto = valTribauto;
	}
	public ValVehiculo getValVehiculo() {
		return valVehiculo;
	}
	public void setValVehiculo(ValVehiculo valVehiculo) {
		this.valVehiculo = valVehiculo;
	}
	public ValNegocNumeracFormA getValNegocNumeracFormA() {
		return valNegocNumeracFormA;
	}
	public void setValNegocNumeracFormA(ValNegocNumeracFormA valNegocNumeracFormA) {
		this.valNegocNumeracFormA = valNegocNumeracFormA;
	}
	public ValCabdav getValCabdav() {
		return valCabdav;
	}
	public void setValCabdav(ValCabdav valCabdav) {
		this.valCabdav = valCabdav;
	}
	public ValConTransFB getValConTransFB() {
		return valConTransFB;
	}
	public void setValConTransFB(ValConTransFB valConTransFB) {
		this.valConTransFB = valConTransFB;
	}
	public ValDeclaranteFB getValDeclaranteFB() {
		return valDeclaranteFB;
	}
	public void setValDeclaranteFB(ValDeclaranteFB valDeclaranteFB) {
		this.valDeclaranteFB = valDeclaranteFB;
	}
	public ValLibFB getValLibFB() {
		return valLibFB;
	}
	public void setValLibFB(ValLibFB valLibFB) {
		this.valLibFB = valLibFB;
	}
	public ValDescMin getValDescMin() {
		return valDescMin;
	}
	public void setValDescMin(ValDescMin valDescMin) {
		this.valDescMin = valDescMin;
	}
	public ValFactSuc getValFactSuc() {
		return valFactSuc;
	}
	public void setValFactSuc(ValFactSuc valFactSuc) {
		this.valFactSuc = valFactSuc;
	}
	public ValFactura getValFactura() {
		return valFactura;
	}
	public void setValFactura(ValFactura valFactura) {
		this.valFactura = valFactura;
	}
	public ValIntermediarioFB getValIntermediarioFB() {
		return valIntermediarioFB;
	}
	public void setValIntermediarioFB(ValIntermediarioFB valIntermediarioFB) {
		this.valIntermediarioFB = valIntermediarioFB;
	}
	public ValItemFB getValItemFB() {
		return valItemFB;
	}
	public void setValItemFB(ValItemFB valItemFB) {
		this.valItemFB = valItemFB;
	}
	public ValmontoFB getValMontoFB() {
		return valMontoFB;
	}
	public void setValMontoFB(ValmontoFB valMontoFB) {
		this.valMontoFB = valMontoFB;
	}
	public ValObsFB getValObsFB() {
		return valObsFB;
	}
	public void setValObsFB(ValObsFB valObsFB) {
		this.valObsFB = valObsFB;
	}
	public ValProveFB getValProveFB() {
		return valProveFB;
	}
	public void setValProveFB(ValProveFB valProveFB) {
		this.valProveFB = valProveFB;
	}
	public ValProveLocFB getValProveLocFB() {
		return valProveLocFB;
	}
	public void setValProveLocFB(ValProveLocFB valProveLocFB) {
		this.valProveLocFB = valProveLocFB;
	}
	public ValSerieItemFB getValSerieItem() {
		return valSerieItem;
	}
	public void setValSerieItem(ValSerieItemFB valSerieItem) {
		this.valSerieItem = valSerieItem;
	}
	public ValidaAnexoDeclaracionServiceImpl getValidaAnexoDeclaracion() {
		return validaAnexoDeclaracion;
	}
	public void setValidaAnexoDeclaracion(
			ValidaAnexoDeclaracionServiceImpl validaAnexoDeclaracion) {
		this.validaAnexoDeclaracion = validaAnexoDeclaracion;
	}
	public ValidacionGeneralService getValidaciongeneralservice() {
		return validaciongeneralservice;
	}
	public void setValidaciongeneralservice(
			ValidacionGeneralService validaciongeneralservice) {
		this.validaciongeneralservice = validaciongeneralservice;
	}
	public ValRectifServiceImpl getValRectif() {
		return valRectif;
	}
	public void setValRectif(ValRectifServiceImpl valRectif) {
		this.valRectif = valRectif;
	}
	public ValidacionGeneralService getValidacionGeneralService() {
		return validacionGeneralService;
	}
	public void setValidacionGeneralService(
			ValidacionGeneralService validacionGeneralService) {
		this.validacionGeneralService = validacionGeneralService;
	}
	public AdmisionTemporalValidacionService getAdmisionTemporalValidacioneService() {
		return admisionTemporalValidacioneService;
	}
	public void setAdmisionTemporalValidacioneService(
			AdmisionTemporalValidacionService admisionTemporalValidacioneService) {
		this.admisionTemporalValidacioneService = admisionTemporalValidacioneService;
	}	
	public ValNegocDuaregapFormA getValNegocDuaregapFormA() {
		return valNegocDuaregapFormA;
	}
	public void setValNegocDuaregapFormA(ValNegocDuaregapFormA valNegocDuaregapFormA) {
		this.valNegocDuaregapFormA = valNegocDuaregapFormA;
	}	*/
}
