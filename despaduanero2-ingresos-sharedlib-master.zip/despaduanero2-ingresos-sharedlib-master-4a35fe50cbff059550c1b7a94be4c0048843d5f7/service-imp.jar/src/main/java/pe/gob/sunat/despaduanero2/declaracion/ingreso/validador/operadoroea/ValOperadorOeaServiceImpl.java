package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.operadoroea;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.operadoroea.ValOperadorOeaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;

import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.DataCatalogoDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.OperadorOeaDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.declaracion.model.OperadorOea;

/**
 * The Class ValNegocNumeracFormA. Clase que define el servicio de validaciones
 * de complejas para el formato A de la declaracion. PAS20171U220200005 -
 * mtorralba 20170808
 */
public class ValOperadorOeaServiceImpl extends ValDuaAbstract implements ValOperadorOeaService {

	/**
	 * Servicio de Validaci�n que verifica que se cumplan con los criterios
	 * minimos para consignar Operadores OEA ARM Pase: PAS20181U220200016
	 * 
	 * @param declaracion
	 * @return
	 */

	@ServicioAnnot(tipo = "V", codServicio = 3508)
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion" })
	@OrquestaDespaAnnot(codServInstancia = 3508, numSecEjec = 504, nomClase = "pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.operadoroea")

	public List<Map<String, String>> validarEnviodeProveedorOeayPaisOea(Declaracion declaracion) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		// INICIO CONTROL DE VIGENCIA OEA-ARM
		declaracion.getDua().setCodRiesgoOea("00");


//		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
//		DataCatalogo catVigenciaValidacion = catalogoAyudaService
//				.getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,"0039");
//
//		Date fechaControlVersionInicio = catVigenciaValidacion.getFecInidatcat();
//		Date fechaControlVersionFin = catVigenciaValidacion.getFecFindatcat();
		Date fechaHoy = SunatDateUtils.getCurrentDate();
//		if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaControlVersionInicio, fechaHoy, SunatDateUtils.COMPARA_SOLO_FECHA) 
//				&& SunatDateUtils.esFecha1MenorIgualQueFecha2(SunatDateUtils.addDay(fechaHoy, -1), fechaControlVersionFin, SunatDateUtils.COMPARA_SOLO_FECHA)) {
			// FIN CONTROL DE VIGENCIA OEA-ARM

			for (DAV dav : declaracion.getListDAVs()) {
				String codigoArm = dav.getProveedor().getCodigoOea()!=null?dav.getProveedor().getCodigoOea().toString():"";
				String pais = dav.getProveedor().getPaisOea()!=null?dav.getProveedor().getPaisOea().toString():"";

				OperadorOeaDAO operadorOeaDAO = fabricaDeServicios.getService("operadorOeaDAO");
				Map<String, Object> filtro = new HashMap<String, Object>();
				filtro.put("codigo", codigoArm);
				List<Map<String, Object>> OperadorOea = operadorOeaDAO.consultarArm(filtro);

						if ((!SunatStringUtils.isEmptyTrim(codigoArm) && codigoArm != null)
								|| (pais != null && !SunatStringUtils.isEmptyTrim(pais))) {
							if (SunatStringUtils.isEmptyTrim(codigoArm)) {
								listError.add(((CatalogoAyudaService) fabricaDeServicios
										.getService("Ayuda.catalogoAyudaService")).getError("37150",
												new String[] { pais }));
							} else if (SunatStringUtils.isEmptyTrim(pais)) {
								listError.add(((CatalogoAyudaService) fabricaDeServicios
										.getService("Ayuda.catalogoAyudaService")).getError("37151",
												new String[] { codigoArm }));
							}
						}												
							
						if (OperadorOea != null && OperadorOea.size() > 0) {
							
							Date fecIniVigencia = (Date) OperadorOea.get(0).get("fecIniVig");
							Date fecFinVigencia = (Date) OperadorOea.get(0).get("fecFinVig");
							String empresaOea = OperadorOea.get(0).get("nomEmpresa")!=null?OperadorOea.get(0).get("nomEmpresa").toString():" ";
							
							if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaHoy, fecIniVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)
									&& !SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaHoy, fecFinVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
							
							String codPais = (String) OperadorOea.get(0).get("paisArm").toString();
							String codEstado = (String) OperadorOea.get(0).get("codEstado");

							DataCatalogoDAO dataCatalogoDAO = fabricaDeServicios.getService("Ayuda.dataCatalogoDef");
							Map<String, Object> filtro2 = new HashMap<String, Object>();
							filtro2.put("codCatalogo", "J2");
							filtro2.put("codDatacat", pais);
							List<Map<String, Object>> DataCatalogo = dataCatalogoDAO.listDataCatalogo(filtro2);
							String paisXml="";
							if(DataCatalogo.size()>0){
								for (Map<String, Object> map : DataCatalogo) {
								paisXml = map.get("desDatacat").toString();
								}
							}
							DataCatalogoDAO dataCatalogo2DAO = fabricaDeServicios.getService("Ayuda.dataCatalogoDef");
							Map<String, Object> filtro3 = new HashMap<String, Object>();
							filtro3.put("codCatalogo", "J2");
							filtro3.put("codDatacat", codPais);
							List<Map<String, Object>> DataCatalogo2 = dataCatalogo2DAO.listDataCatalogo(filtro3);
							String paisArm="";
							if(DataCatalogo.size()>0){
								for (Map<String, Object> map2 : DataCatalogo2) {
									paisArm = map2.get("desDatacat").toString();
								}
							}
							if (!SunatStringUtils.isEmptyTrim(codigoArm) && !SunatStringUtils.isEmptyTrim(pais)) {
									if (!SunatStringUtils.isEqualTo(codEstado, "1")) {
										listError.add(((CatalogoAyudaService) fabricaDeServicios
												.getService("Ayuda.catalogoAyudaService")).getError("37147",
														new String[] { empresaOea }));
									}
									if (!SunatStringUtils.isEqualTo(pais, codPais)) {
										listError.add(((CatalogoAyudaService) fabricaDeServicios
												.getService("Ayuda.catalogoAyudaService")).getError("37148",
														new String[] { pais, paisXml, codPais, paisArm }));
									}
								}
							
							} else {
								listError.add(((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
										.getError("37154", new String[]{dav.getProveedor().getNombreRazonSocial()} ));
									}

						} else if (!SunatStringUtils.isEmptyTrim(codigoArm)) {
							listError.add(
									((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
											.getError("37146", new String[] { codigoArm }));
						}

						evaluacionCodriesgoOea(codigoArm, declaracion);

			}

		//}
		return listError;
	}

	public void evaluacionCodriesgoOea(String codigoArm, Declaracion declaracion) {

		Map<String, Object> estadoProveedorOea = new HashMap<String, Object>();
		estadoProveedorOea = validarOperadorOeaArm(codigoArm, declaracion);
		String flagOperadorOea = estadoProveedorOea.get("operadorOea") != null
				? estadoProveedorOea.get("operadorOea").toString() : "0";
		actualizarDatosRiesgoOea(flagOperadorOea, declaracion, codigoArm);

	}

	public void actualizarDatosRiesgoOea(String flagOperadorOea, Declaracion declaracion, String codigoArm) {
		String codigoRiesgoOea = "";
		DUA dua = declaracion.getDua();
		Map<String, Object> estadoProveedorOea = new HashMap<String, Object>();
		Map<String, Object> estadoImportadorOea = new HashMap<String, Object>();
		// estadoProveedorOea=validarOperadorOeaArm(codigoArm, declaracion);
		// flagOperadorOea=estadoProveedorOea.get("operadorOea")
		// !=null?estadoProveedorOea.get("ConsignatarioRuc").toString():"";

		estadoImportadorOea = validarImportadorOea(declaracion);
		String flagImportadorOea = estadoImportadorOea.get("importadorOea") != null
				? estadoImportadorOea.get("importadorOea").toString() : "0";

		if (flagOperadorOea.equals("1") && flagImportadorOea.equals("1")) {
			codigoRiesgoOea = "11";
		} else if (flagOperadorOea.equals("1") && flagImportadorOea.equals("0")) {
			codigoRiesgoOea = "10";
		} else if (flagOperadorOea.equals("0") && flagImportadorOea.equals("1")) {
			codigoRiesgoOea = "01";
		} else if (flagOperadorOea.equals("0") && flagImportadorOea.equals("0")) {
			codigoRiesgoOea = "00";
		} else {
			codigoRiesgoOea = "00";
		}
		dua.setCodRiesgoOea(codigoRiesgoOea);
		// Metodo solo para la REcti

	}

	public Map<String, Object> validarOperadorOeaArm(String codigoArm, Declaracion declaracion) {
		Map<String, Object> proveedorOea = new HashMap<String, Object>();
		for (DAV dav : declaracion.getListDAVs()) {
			codigoArm = dav.getProveedor().getCodigoOea() != null ? dav.getProveedor().getCodigoOea().toString() : " ";
			OperadorOeaDAO operadorOeaDAO = fabricaDeServicios.getService("operadorOeaDAO");
			Map<String, Object> filtro = new HashMap<String, Object>();
			filtro.put("codigo", codigoArm);
			List<Map<String, Object>> OperadorOea = operadorOeaDAO.consultarArm(filtro);
			
			if (!CollectionUtils.isEmpty(OperadorOea)&& OperadorOea.size()> 0) {
				proveedorOea.put("operadorOea", "1");
			} else {
				proveedorOea.put("operadorOea", "0");
				break;
			}
		}
		return proveedorOea;
	}

	public Map<String, Object> validarImportadorOea(Declaracion declaracion) {
		Map<String, Object> operadorOea = new HashMap<String, Object>();
		// Valida al Importador OEA
		String nume_docum = "";
		boolean esimportadorOEA = false;
		DUA dua = declaracion.getDua();
		if (SunatStringUtils.isEqualTo(dua.getDeclarante().getTipoParticipante().getCodDatacat(),
				ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)) {

			nume_docum = dua.getDeclarante().getNumeroDocumentoIdentidad();
			if ( !esimportadorOEA) {
				//Valida si existe registrado el Importador OEA
				
				
					Map<String, Object>  MapOperadoroea = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperadoroea(nume_docum, ConstantesDataCatalogo.IMPORTADOR_OEA);
					 if (!CollectionUtils.isEmpty(MapOperadoroea)){
						esimportadorOEA = true;
						operadorOea.put("importadorOea", "1");
					 }
					 else{
							operadorOea.put("importadorOea", "0");
			
					}
				
			
			}

		}
		return operadorOea;
	}
	// @ServicioAnnot(tipo = "V", codServicio = 3509)
	// @ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion",
	// "declaracionBD" })
	// @OrquestaDespaAnnot(codServInstancia = 3509, numSecEjec = 505, nomClase =
	// "pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.operadoroea")
	// public List<Map<String, String>> validarCodEmpresaOea(Declaracion
	// declaracion, Declaracion declaracionBD) {
	// Map<String, String> operadorOea = new HashMap<String, String>();
	// return operadorOea;
	// }

} 
