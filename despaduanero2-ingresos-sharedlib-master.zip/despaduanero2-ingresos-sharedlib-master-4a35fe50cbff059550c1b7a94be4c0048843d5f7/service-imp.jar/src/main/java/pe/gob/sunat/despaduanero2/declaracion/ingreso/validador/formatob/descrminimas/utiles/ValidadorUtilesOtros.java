package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.utiles;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.utiles.model.UtilesOtros;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */

public class ValidadorUtilesOtros extends ValidadorUtilesAbstract{

  private static final String BOLIGRAFO        = "005";
  private static final String LAPIZ            = "026";
  private static final String LAPIZ_BICOLOR    = "027";
  private static final String LAPIZ_CARPINTERO = "028";
  private static final String LAPIZ_COLOR      = "029";
  private static final String PORTAMINA        = "015";
  private static final String MARCADOR         = "030";
  private static final String CORRECTOR        = "041";
  private static final String RESALTADOR       = "042";
  private static final String ROTULADOR        = "043";
  private static final String MINA             = "032";
  private static final String PLUMON           = "030";

  private static final String TABLA_NRO7  = "484";
  private static final String TABLA_NRO8  = "485";
  private static final String TABLA_NRO9  = "486";
  private static final String TABLA_NRO10 = "487";
  private static final String TABLA_NRO11 = "488";
  private static final String TABLA_NRO12 = "489";

  public ValidadorUtilesOtros() {
  }
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto,
                                                     Declaracion dua) throws Exception{

    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

    //lstErrores.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores))  {
          DatoItem item =  obtenerItem(objeto, dua);
          lstErrores.addAll(super.validarUnidadComercial(objeto, item));
         // lstErrores.addAll(validarComposicionMercancia(objeto, item));//esto ya no va acorde normativa
          lstErrores.addAll(super.validarDimensiones(objeto, item));
          lstErrores.addAll(super.validarPesoVolumen(objeto));
          lstErrores.addAll(validarTipoMaterial(objeto));
          lstErrores.addAll(validarTipoDureza(objeto));
          lstErrores.addAll(validarDispositivos(objeto));
      }

    return lstErrores;
  }
/**
 * 
 * @param objeto
 * @param item
 * @return Lista de Errores
 * Sustentada en reglas de negocio: (R-920)
 *//****Se contradice con la R920, si deberia permitir ingresar 2do componente confirmado por wilmer.
  public List<ErrorDescrMinima> validarComposicionMercancia(ModelAbstract objeto,
                                                            DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    UtilesOtros util = (UtilesOtros) objeto;
    if(util.getSegundoComponente() != null &&
       !SunatStringUtils.isEmptyTrim(util.getSegundoComponente().getValtipdescri())){ 
      lst.add(obtenerError("31197", util.getSegundoComponente()));
    }
    return lst;
  }***/

  /**
   * 
   * @param objeto
   * @return Lista de Errores
   */
  public List<ErrorDescrMinima> validarTipoMaterial(ModelAbstract objeto){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();

    Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
    UtilesOtros utiles = (UtilesOtros) objeto;
    if( utiles.getTipoMaterialInterior() != null){
      String datoAValidar = utiles.getTipoMaterialInterior().getValtipdescri();
      String nombreComercial = objeto.getNombreComercial().getValtipdescri();
      List<String> boligrafo = Arrays.asList(BOLIGRAFO);
      List<String> lapices = Arrays.asList(LAPIZ,LAPIZ_BICOLOR,LAPIZ_CARPINTERO,LAPIZ_COLOR);
      List<String> marcadores = Arrays.asList(MARCADOR,ROTULADOR,RESALTADOR);
      if(boligrafo.contains(nombreComercial)){
        lst = validarMaterial(datoAValidar, 
                                "31272", "31275", 
                                TABLA_NRO7, utiles.getTipoMaterialInterior(),fechaVigencia);
      }else if(lapices.contains(nombreComercial)){
        lst = validarMaterial(datoAValidar, 
                                "31273", "31276", 
                                TABLA_NRO8, utiles.getTipoMaterialInterior(),fechaVigencia);
      }else if(marcadores.contains(nombreComercial)){
        lst = validarMaterial(datoAValidar, 
                                "31277", "31274", 
                                TABLA_NRO9, utiles.getTipoMaterialInterior(),fechaVigencia);
      }
    }
    return lst;
  }
  
  /**
   * 
   * @param objeto
   * @return Lista de Errores
   */
  public List<ErrorDescrMinima> validarTipoDureza(ModelAbstract objeto){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PAS20165E220200137
    UtilesOtros utiles  = (UtilesOtros) objeto;
    if(utiles.getTipoDureza() != null){
      String datoAValidar = utiles.getTipoDureza().getValtipdescri();
      String nombreComercial = utiles.getNombreComercial().getValtipdescri();
      List<String> boligrafos = Arrays.asList(BOLIGRAFO,PORTAMINA,CORRECTOR);
      List<String> lapices = Arrays.asList(LAPIZ,LAPIZ_BICOLOR,LAPIZ_CARPINTERO,LAPIZ_COLOR,MINA);
      List<String> marcador = Arrays.asList(PLUMON,RESALTADOR,MARCADOR);
      if(boligrafos.contains(nombreComercial)){
          lst = validarMaterial(datoAValidar,
                                  "31278", "31279", TABLA_NRO10, 
                                  utiles.getTipoDureza(),fechaVigencia);
      }else if(lapices.contains(nombreComercial)){
          lst = validarMaterial(datoAValidar,
                                  "31280", "31281", TABLA_NRO11, 
                                  utiles.getTipoDureza(),fechaVigencia);
      } else if(marcador.contains(nombreComercial)){
          lst = validarMaterial(datoAValidar,
                                "31282", "31283", TABLA_NRO12, 
                                utiles.getTipoDureza(),fechaVigencia);
      }
    }
    return lst;
  }

  public List<ErrorDescrMinima> validarDispositivos(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarAccesorios(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  private List<ErrorDescrMinima> validarMaterial( String datoAValidar,
                                            String vacio,
                                            String noCatalogo,String tabla,
                                            DatoDescrMinima dato,
                                            Date fechaVigencia){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();

   if(SunatStringUtils.isEmpty(datoAValidar)){
     lst.add(obtenerError(vacio, dato));
   }else if(noEstaEnCatalogo(datoAValidar, tabla, fechaVigencia)){
     lst.add(obtenerError(noCatalogo, dato));
   }
    return lst;
  }
}
