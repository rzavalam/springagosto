package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.service.TabLibeDAOService;
import pe.gob.sunat.despaduanero2.ayudas.model.Declaran;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PublicasDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TabRucDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.Declaran;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public class PackageTDServiceImpl extends IngresoAbstractServiceImpl implements PackageTD{

	//private static AyudaService ayudaService;
	//private static TabLibeDAOService tabLibeDAOService;
	//private CatalogoValidaService catalogoValidaService;
	//private static FabricaDeServicios fabricaDeServicios;
	
	
	

	/**
	 * Ref PKTD_TD.cambiovigente
	 * Se verifica en la tabla TABLNEW si el proceso se encuentra vigente,
	 * para ello se realiza la consulta con el Tipo=�AJ� y Codigo= PCodigo y
	 * PFecha entre Finicio y Ffin. Si se cumple esta condici�n significa
	 * que el proceso est� vigente y retorna 1 sino es as� significa que no
	 * est� vigente y retorna 0.
	 */
	public Integer getCambioVigente(String codigoProceso, Integer fecha){
		
		//boolean existe = FormatoBServiceImpl.getInstance().getCatalogoHelper().isValid(codigoProceso,"AJ");
		boolean existe =CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("AJ",codigoProceso,SunatDateUtils.getCurrentDate()));
		
		return existe ? 1 : 0;
	}

	/**
	 * Ref PKTD_TD.fnAgemar
	 * @param codAgenciaNaviera
	 * @param codAduana
	 * @param fecValidacion
	 * @return
	 */
	public Integer getCountInAgeMar(String codAgenciaNaviera, String codAduana, Date fecValidacion){
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String codJurisdiccion = PackageGeneral.getJurisdicc(codAduana);
//		return FormatoBServiceImpl.getInstance().getOpeComExtDAO().getCountInAgeMar(codAgenciaNaviera, codJurisdiccion, codAduana, fecValidacion);
		return ayudaService.getCountInAgeMar(codAgenciaNaviera, codJurisdiccion, codAduana, fecValidacion);
	}
	
	/**
	 * @param codAgenciaNaviera
	 * @param codAduana
	 * @return
	 */
	public Integer getCountInEmpreDTN(String codAgenciaNaviera, String codAduana){
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");		
		Integer cont = (Integer)ayudaService.getCountInEmpreDTN(codAgenciaNaviera, codAduana);
		return cont;
	}
	
	/**
	 * @param codAgenciaNaviera
	 * @param codJurisdiccion
	 * @param codAduana
	 * @return
	 */
	public Integer getTipoRecFromRaDirec(String codAgenciaNaviera, String codJurisdiccion , String codAduana )
	{
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String result = ayudaService.getTipoRecFromRaDirec(codAgenciaNaviera, codJurisdiccion, codAduana);
		if(! SunatStringUtils.isEmpty(result) )
			return new Integer ( result );
		
		return null;
	}
	
	/**
	 * PUERTOS/Catalogo 
	 * Ref PKTD_TD.fnPuertos
	 * SELECT COUNT(*) INTO xCOUNT
		 FROM PUERTOS
		 WHERE CPAIS= SUBSTR(pCodigo,1,2) AND CPUERTO = SUBSTR(pCodigo,3,3)
		RETORNA xCOUNT
	 * @return
	 */
	public Integer getCountInPuertos(String codPuerto)
	{
	
		//List<Map<String, String>> resp = FormatoBServiceImpl.getInstance().getCatalogoHelper().getCatalogoValidacionService().validarPuerto(codPuerto);
		List<Map<String, String>> resp = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarPuerto(codPuerto);
		
		if(resp.size() == 1)
		{
			Map<String, String> map = resp.get(0);
			if("10000".equals(map.get(ResponseMapManager.KEY_CODIGO)) )
			{
				return 0;
			}
		}		
		return 1;
		/*.validarPuertoEnCatalogo( SunatStringUtils.substring(codPuerto, 1, 2) , SunatStringUtils.substring(codPuerto, 3, 3));
		
		if(resp != null )
			return 1;
			
		return 0;*/
	}
	
	public Map<String, Integer> getCountInPuertos(List<String> codigosPuerto) {
		Map<String, Integer> resultado = new HashMap<String, Integer>();
	
		//List<Map<String, String>> resp = FormatoBServiceImpl.getInstance().getCatalogoHelper().getCatalogoValidacionService().validarPuerto(codPuerto);
		//List<Map<String, String>> resp = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarPuerto(codPuerto);
		Map<String, List<Map<String, String>>> resultadoValidaciones = ((CatalogoValidaService) fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarPuertos(codigosPuerto);
		
		//for (List<Map<String, String>> resp : resultadoValidaciones.entrySet()) {
		for (Map.Entry<String, List<Map<String, String>>> resultadoValidacion : resultadoValidaciones.entrySet()) {
			String codigoPuerto = resultadoValidacion.getKey();
			List<Map<String, String>> resp = resultadoValidacion.getValue();
			int codigoResultado = -1;
			if(resp.size() == 1) {
				Map<String, String> map = resp.get(0);
				if("10000".equals(map.get(ResponseMapManager.KEY_CODIGO)) ) {
					//return 0;
					codigoResultado = 0;
				}
			} else {
				codigoResultado = 1;
			}
			resultado.put(codigoPuerto, codigoResultado);
		}
		return resultado;
		/*.validarPuertoEnCatalogo( SunatStringUtils.substring(codPuerto, 1, 2) , SunatStringUtils.substring(codPuerto, 3, 3));
		
		if(resp != null )
			return 1;
			
		return 0;*/
	}
	
	/**
	 * @param tipoDocumento
	 * @param numeroDocumento
	 * @param codExoneracion
	 * @return
	 */
	public boolean isEntidadPublic(String tipoDocumento, String numeroDocumento, String codExoneracion)
	{
		if( SunatStringUtils.isEmpty(codExoneracion) )
			return true;
		
		//Map result = FormatoBServiceImpl.getInstance().getPublicasDAO().findEmpresaByTipoDocAndNumDoc(tipoDocumento, numeroDocumento);
		Map result = ((PublicasDAO)fabricaDeServicios.getService("publicasDAO")).findEmpresaByTipoDocAndNumDoc(tipoDocumento, numeroDocumento);
		
		return SunatStringUtils.isEqualTo(codExoneracion, (String)result.get("cexocer") );
	}
	
	/**
	 * 
	 * @param tipoPrefArancelaria
	 * @param codPrefArancelaria
	 * @return
	 */
	public Integer getCountInTabLibe(String tipoPrefArancelaria, String codPrefArancelaria){
		TabLibeDAOService tabLibeDAOService = (TabLibeDAOService)fabricaDeServicios.getService("Ayuda.tabLibeService");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tlib", tipoPrefArancelaria);
		params.put("clib", codPrefArancelaria);
//		return FormatoBServiceImpl.getInstance().getTablibeDAO().count(params);
		return tabLibeDAOService.count(params);
	}
	
	/**
	 * @param codCondicionDomicilio
	 * @return
	 */
	public String getCondiFromTabRuc(String codCondicionDomicilio)
	{
		//return FormatoBServiceImpl.getInstance().getTabRucDAO().getCondiFromTabRuc(codCondicionDomicilio);
		return ((TabRucDAO)fabricaDeServicios.getService("tabRucDAO")).getCondiFromTabRuc(codCondicionDomicilio);
	}
	
	/**
	 * '0': RUC (estado). 
	 * '1': Declaran (vigencia). 
	 * '2': RUC (estado y condici�n). 
	 * '3': Declaran (vigencia y condici�n).
	 */
	public String functionDeclaVig(String codigo, String tipoBusq, String tipoDocumento){
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		String xFFin = "0";
		String xestado = "01";
		String xflag22 = "01";
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipodoc",tipoDocumento);
		params.put("codigo",codigo);
		
		if( SunatStringUtils.isEqualTo(tipoBusq, "3") ){
			//Declaran declaran = FormatoBServiceImpl.getInstance().getDeclaranDAO().selectByPrimaryKey(codigo, tipoDocumento);
			
			Declaran declaran= (Declaran)ayudaService.selectByPrimaryKeyDeclaran(codigo, tipoDocumento);
			
			if( declaran.getFfin() != null && ! SunatStringUtils.isEmpty( declaran.getFfin().toString() ) )
			{
				return declaran.getFfin().toString();
			}		
			
				
		}else{ 
			
			if(SunatStringUtils.isStringInList(tipoBusq, "0,2") ){
				xestado = PackageRucDni.getEstadoRuc(codigo);
				xflag22 = PackageRucDni.getFlag22(codigo);			
				
				if( SunatStringUtils.isEqualTo(tipoBusq, "0") )
					return xestado;
				else
					return xestado+xflag22;
			}else{
				params.put("tipodoc", "4");
				//Declaran declaran = FormatoBServiceImpl.getInstance().getDeclaranDAO().selectByPrimaryKey(codigo, "4");		
				
				Declaran declaran= (Declaran)ayudaService.selectByPrimaryKeyDeclaran(codigo, "4");
				
				
				if( declaran.getFfin() != null && ! SunatStringUtils.isEmpty( declaran.getFfin().toString() ) )
				{
					if( SunatStringUtils.isEqualTo(tipoBusq, "1") )
						return declaran.getFfin().toString();
					else
						return " ";
				}
			}
		}
		
		return "";
	}
	public boolean validaNumLetCar(String arg) {

		boolean containsDigit=false;
		for(int i=0;i<arg.length();i++){
			if (!SunatStringUtils.isStringInList(arg.substring(i,i+1).toUpperCase(), "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,W,X,Y,Z,0,1,2,3,4,5,6,7,8,9,/,.,-, ")){//PAS20165E220200101
				containsDigit=true;
				break;
			}
		}
		
		
		return containsDigit;
	}
	
	/*
	public static AyudaService getAyudaService() {
		return ayudaService;
	}

	public static void setAyudaService(AyudaService ayudaService) {
		PackageTDServiceImpl.ayudaService = ayudaService;
	}

	public TabLibeDAOService getTabLibeDAOService() {
		return tabLibeDAOService;
	}

	public void setTabLibeDAOService(TabLibeDAOService tabLibeDAOService) {
		this.tabLibeDAOService = tabLibeDAOService;
	}
	
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
*/	
}

