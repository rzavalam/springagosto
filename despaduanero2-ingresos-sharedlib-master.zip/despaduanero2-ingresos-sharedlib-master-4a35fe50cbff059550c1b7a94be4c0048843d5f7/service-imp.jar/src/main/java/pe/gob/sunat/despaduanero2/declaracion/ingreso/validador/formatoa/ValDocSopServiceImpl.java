/*
/*
 * Clase que define el servicio de validaciones de Documentos de soporte
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
/**
 * The Class ValDocSop. Clase que define el servicio de validaciones de Documentos de soporte.
 */
public class ValDocSopServiceImpl extends ValDuaAbstract implements ValDocSop{
	
	//private FabricaDeServicios fabricaDeServicios;
	
	/**
	 * Valida el numero de secuencia de los documentos.<br>
	 * Valida que el campo numsecdocum de los elementos de la lista sean secuenciales de 1 a n.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param listDocSoporte Elementos<DatoOtroDocSoporte>
	 * @return Map
	 */
	public Map<String, String> numsecdocum(Elementos<DatoOtroDocSoporte> listDocSoporte){
		/*branch ingreso 2011-009 hosorio inicio 26/07/2011*/
		/*
		int i=1;
		boolean secuencial=false;
		for(DatoOtroDocSoporte docSoporte:listDocSoporte){
			secuencial= (i==docSoporte.getNumsecdocum());
			i++;
			if (!secuencial)
				break;
		}
		return secuencial?new HashMap<String,String>():getDUAError("30300","");
		*/
		if(!CollectionUtils.isEmpty(listDocSoporte)){
			Map<Integer,DatoOtroDocSoporte> mp=new HashMap<Integer, DatoOtroDocSoporte>(); 
			for(DatoOtroDocSoporte docSoporte:listDocSoporte){
				if(mp.get(docSoporte.getNumsecdocum())==null)
					mp.put(docSoporte.getNumsecdocum(), docSoporte);
				else
					return getDUAError("30300","");
			}			
		}
		return new HashMap<String,String>();
		/*branch ingreso 2011-009 hosorio fin 26/07/2011*/
	}
	
/*	*//*
	public Map<String, String> numsecdocum(Elementos<Elemento> listDoc){
		int i=1;
		boolean secuencial=false;
		if (listDoc!=null && !listDoc.isEmpty()){
				for(Elemento doc:listDoc){
					if (doc instanceof DatoOtroDocSoporte){
						DatoOtroDocSoporte docSoporte=(DatoOtroDocSoporte)listDoc.get(0);
						secuencial= (i==docSoporte.getNumsecdocum());
					}else{
						DatoDocAutorizante docAutorizante=(DatoDocAutorizante)listDoc.get(0);
						secuencial= (i==docAutorizante.getNumsecdocum());
					}
					i++;
					if (!secuencial)
						break;
				}
				return secuencial?new HashMap<String,String>():FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getErrorMap("","");
		}else
			return new HashMap<String,String>();
	}*/

	/**
	 * Valida el C�digo del tipo de proceso.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * @param codtipoproceso String. C�digo del tipo de proceso.
	 * @return Map<String, String>
	 * 
	 */
	public Map<String, String> codtipoproceso(String codtipoproceso){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("327", codtipoproceso))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("327", codtipoproceso,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo){
			if (codtipoproceso.equals("C")){
				return getDUAError("30037","Error catalogo codtipoproceso");
			}

			if (codtipoproceso.equals("P")){ 
				 return getDUAError("32023","Error catalogo codtipoproceso"); 
			} 

			return new HashMap<String,String>();
		}
                else
			return getDUAError("30037","Error catalogo codtipoproceso");
	}

	/**
	 * Valida el C�digo del tipo de documento.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipodocasoc String
	 * @return Map
	 */
	public Map<String, String> codtipodocasoc(String codtipodocasoc){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("75", codtipodocasoc) )
			//|| FormatoAServiceImpl.getInstance().isValidCatalogo("EI", codtipodocasoc))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("75", codtipodocasoc,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30038","Error catalogo codtipodocasoc");
	}

	/**
	 * Valida el A�o del documento.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param anndocasoc String. A�o del documento.
	 * @return Map
	 */
	public Map<String, String> anndocasoc(String anndocasoc){
		
		if(! SunatStringUtils.isEmpty(anndocasoc) )
		{
			String anio = SunatStringUtils.substringFox(anndocasoc, 1, 4);
			if( SunatStringUtils.length(anio) != 4 )
				return getDUAError("30039","");
			
			if( ! SunatStringUtils.isNumeric(anio) )
				return getDUAError("30039","");
			
			return new HashMap<String, String>();
		}
		
		return getDUAError("30039","");
		
	}

	/**
	 * Valida el N�mero del documento.<br>
	 * Valida que el par&aacute;metro sea una cadena de 15 d&iacute;gitos.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numdocasoc String. N�mero del documento.
	 * @return Map
	 */
	public Map<String, String> numdocasoc(String numdocasoc){
		return (/*SunatStringUtils.isNumeric(numdocasoc) && */numdocasoc.trim().length()<=15)?new HashMap<String,String>():getDUAError("30040","");
	}

	/**
	 * Valida la Fecha de Emision del documento.<br>
	 * Valida que el par&aacute;metro siempre tenga valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fecdocasoc Date. Fecha de Emision del documento / A�o del documento.
	 * @return Map
	 */
	 //INICIO P46 INSI
	public Map<String, String> fecdocasoc(Date fecdocasoc, Date fechaReferencia, String codtipoproceso){
//		return fecdocasoc!=null?new HashMap<String,String>():getDUAError("30041","");  P46 - INSI
//PAS20181U220200004
		boolean validarfechaemision =false;
		if((codtipoproceso).equals("1")){
			validarfechaemision =true;
		}
		if((codtipoproceso).equals("7")){
			validarfechaemision =true;
		}
		if(!validarfechaemision)
					return new HashMap<String,String>();
		
		if ( fecdocasoc!=null){
			
			SimpleDateFormat formato = new 	SimpleDateFormat("dd/MM/yyyy");  
			
			String resultado = formato.format(SunatDateUtils.getCurrentDate());  
			Date fechaReferenciaNew = SunatDateUtils.getDate(resultado, "dd/MM/yyyy")   ;
			
			
			// se debe de verificar que la fecha sea mayor a al fecha de referencia
			Integer fechReferencia=SunatDateUtils.getIntegerFromDate(fechaReferenciaNew);
			Integer fechEmision=SunatDateUtils.getIntegerFromDate(fecdocasoc);
			if (fechEmision>fechReferencia)
				return getDUAError("35446","");
			else
				return new HashMap<String,String>();
		}else
			return getDUAError("35446","");
		
	}
//FIN P46 INSI
	/**
	 * Valida la Fecha de vencimiento de plazo.<br>
	 * Valida que el par&aacute;metro siempre tenga valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fecvencimiento Date. Fecha de vencimiento de plazo.
	 * @param fechaReferencia Date. Fecha de referencia de numeracion de la DUA.
	 * @return Map
	 */
	public Map<String, String> fecvencimiento(Date fecvencimiento, Date fechaReferencia, String codtipoproceso){
		
		if("9".equals(codtipoproceso) ||
		   "6".equals(codtipoproceso)
				   || "1".equals(codtipoproceso) || "7".equals(codtipoproceso) ) // P46 - 3006
			return new HashMap<String,String>();
		
		if ( fecvencimiento!=null){
			
			SimpleDateFormat formato = new 	SimpleDateFormat("dd/MM/yyyy");  
			String resultado = formato.format(fechaReferencia);  
			Date fechaReferenciaNew = SunatDateUtils.getDate(resultado, "dd/MM/yyyy")   ;
			
			
			// se debe de verificar que la fecha sea mayor a al fecha de referencia
			Integer fechReferencia=SunatDateUtils.getIntegerFromDate(fechaReferenciaNew);
			Integer fechVencimiento=SunatDateUtils.getIntegerFromDate(fecvencimiento);
			if (fechVencimiento<fechReferencia)
				return getDUAError("30042","");
			else
				return new HashMap<String,String>();
		}else
			return getDUAError("30042","");
		
	}

	/**
	 * Valida el C�digo del tipo de entidad emisora (aduana, entidad externa).<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipoentidad String. C�digo del tipo de entidad emisora (aduana, entidad externa).
	 * @return Map
	 */
	public Map<String, String> codtipoentidad(String codtipoentidad){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("334", codtipoentidad))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("334", codtipoentidad,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30301","Error catalogo codtipoentidad");
	}

	/**
	 * 
	 * Valida el C�digo de tipo de documento de entidad emisora.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipodocentidad String. C�digo de tipo de documento de entidad emisora.
	 * @return Map
	 */
	public Map<String, String> codtipodocentidad(String codtipodocentidad){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("27", codtipodocentidad))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", codtipodocentidad,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30043","Error catalogo codtipodocentidad");
	}

	/**
	 * Valida el Documento de identidad de la entidad emisora / Codigo de aduana.<br>
	 * Valida que el par&aacute;metro tenga valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codentidademisora Long. Codigo de Documento de identidad de la entidad emisora / Codigo de aduana
	 * @return Map
	 */
	public Map<String, String> codentidademisora(Long codentidademisora){
		
		if( codentidademisora == null )
			return new HashMap<String, String>();
		
		return SunatNumberUtils.isGreaterThanZero(codentidademisora)?new HashMap<String,String>():getDUAError("30044","");
	}

	/**
	 * Valida la descripcion de entidad, identificaci�n de area dentro de entidad u otros, tipo doc identidad.<br>
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param desentidad String. Descripcion de entidad, identificaci�n de area dentro de entidad u otros, tipo doc identidad.
	 * @return Map
	 */
	public Map<String, String> desentidad(String desentidad, String codtipoproceso){
		
		if("9".equals(codtipoproceso) ||
		   "6".equals(codtipoproceso) )
			return new HashMap<String,String>();
		
		return !SunatStringUtils.isEmptyTrim(desentidad)?new HashMap<String,String>():getDUAError("30045","");
	}

	//PAS20165E220200025
	public Map<String, String> desentidad(String desentidad,String codtipodocum, String codtipoproceso){
		
		if(!codtipodocum.equals("20") && !codtipodocum.equals("21")){
			if("9".equals(codtipoproceso) ||
					"6".equals(codtipoproceso) )
				return new HashMap<String,String>();
			
			return !SunatStringUtils.isEmptyTrim(desentidad)?new HashMap<String,String>():getDUAError("30045","");
		}		
		return new HashMap<String,String>();
	}

	/**
	 * Valida el codigo de entidad, banco u otros.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codentidad String. Codigo de entidad, banco u otros.
	 * @return Map
	 */
	public Map<String, String> codentidad(String codentidad){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("49", codentidad))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("49", codentidad,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30302","Error catalogo codentidad");
	}

	/**
	 * Valida el Indicador de servicio de custodia de SENASA.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param indcustodia String. Indicador de servicio de custodia de SENASA
	 * @return Map
	 */
	public Map<String, String> indcustodia(String indcustodia){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("326", indcustodia))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("326", indcustodia,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30303","Error catalogo indcustodia");
	}
	
	//DatoDocAutorizante
	
	/**
	 * Valida el Tipo de documento de soporte.
	 * 
	 * @param codtipodocum String. Tipo de documento de soporte
	 * @return el mapa de errores
	 */
	public Map<String,String> codtipodocum(String codtipodocum){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("75", codtipodocum)){
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("75", codtipodocum,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo){
			return new HashMap<String,String>();
		}else
			return getDUAError("30304","Error codtipodocum - ValDocSop");
	}
	
	/**
	 * Valida el N�mero o identificaci�n del documento
	 * 
	 * @param numdocum String. N�mero o identificaci�n del documento
	 * @return el mapa de errores
	 */
	public Map<String,String> numdocum(String numdocum){
		if (!SunatStringUtils.isEmptyTrim(numdocum)){
			if (numdocum.length()>15)
				return getDUAError("30305",new Object[]{numdocum,"Error numdocum longitud distinta 15 - ValDocSop"});
			else{
				/*Bug 1068
				 * for(int i=0;i<numdocum.length();i++){
					String c=numdocum.substring(i, i+1);
					if (!SunatStringUtils.isAlphanumeric(c) && !SunatStringUtils.include(c, new String[]{" ","-","(",")"}))
						return getDUAError("30305",new Object[]{numdocum,"Error numdocum no todos los caracteres son digitos - ValDocSop"});
				}*/
				return new HashMap<String,String>();
			}
		}else
			return getDUAError("30305",new Object[]{numdocum,"Error numdocum blanco - ValDocSop"});
	}
	
	/**
	 * Valida la fecha de emision del documento de soporte.
	 * 
	 * @param fecemision Date. Fecha de emision
	 * @return el mapa de errores
	 */
	public Map<String,String> fecemision(Date fecemision){
		if (fecemision!=null)
			return new HashMap<String,String>();
		else
			return getDUAError("30306","Error fecemision null");
	}	
	
	
	String numdocum;
	
	public Map<String,String> fecemision(String numdocum,Date fecemision,String codtipodocum){
		
		if(!codtipodocum.equals("20") && !codtipodocum.equals("21")){
			if (fecemision!=null)
				return new HashMap<String,String>();
			else
				return getDUAError("37028",new Object[]{numdocum}) ;
		}		
		return new HashMap<String,String>();
		
	}	
	
	
	
	//lmvr RN 173
	/*public Map<String, String> valCantFacturas(DAV dav,Declaracion declaracion){
		DUA dua=declaracion.getDua();
		java.util.Map<String, String> result = new HashMap<String, String>();
		//int cantidadFactA = listDocSoporte.size();
		
		if(!CollectionUtils.isEmpty(declaracion.getListDAVs()) ){
			//int cantidadFactA  = getCantFacturas(dua).size();
			int cantidadFactA = dua.getListFacturaRef().size();
			int cantidadFactB = dav.getListFacturas().size();
			if( cantidadFactA>0 && cantidadFactB>0){ 
				if(cantidadFactA != cantidadFactB ) {
					//result = catalogoHelper.getErrorMap("30581");
				result = getDUAError("30581","Error cantidad Facturas");
				}
			}	
		}
		return result;
	}*/

	
    public Map<String, String> valCantFacturas(Declaracion declaracion){
        DUA dua=declaracion.getDua();
        
        Map<String, String> result = new HashMap<String, String>();
        
        if(!CollectionUtils.isEmpty(declaracion.getListDAVs()) ){
               
               int cantidadFactB = 0;
               
               for (DAV davProve : declaracion.getListDAVs()) {
                      cantidadFactB += davProve.getListFacturas().size();
               }
               
               /*ajuste SAU20143N002000509*/
               List<String> facturasA = new ArrayList<String>();
               for (DatoFacturaref datoFactura : dua.getListFacturaRef()) {
            	   if(!SunatStringUtils.include(datoFactura.getNumfactura().toString(), facturasA.toArray(new String[facturasA.size()]))){
            		   facturasA.add(datoFactura.getNumfactura().toString()); 
            	   }                   
               }
               if(facturasA.size() != cantidadFactB ) {
               //if(dua.getListFacturaRef().size() != cantidadFactB ) {
                      result = getDUAError("30581","Error cantidad Facturas");
               }
               /*fin de ajuste para SAU20143N002000509*/
        }
        return result;
  }
    //inicio gmontoya Pase 153
    @Override
    public List<Map<String,String>> correlacionResolIMSerie(Declaracion declaracion){
    	List<Map<String, String>> result = new ArrayList<Map<String,String>>();
    	List<DatoSerie> series=declaracion.getDua().getListSeries();
    	boolean serieRelacionada = false;
    	Integer numsecdocum=0;
    	boolean enviaResolucionIM = false;
    	boolean enviaSerieConIM = false;
//PAS20181U220200004
        //csantillan 4
    	//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
    	ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
    	Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
        boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaDeclaracion):false;

		boolean enviaResolucionIMParaDiligencia = false;
    	for(DatoOtroDocSoporte docSoporte:declaracion.getDua().getListOtrosDocSoporte()){
			//amancilla apoyo a Chiste Gilmar
			String inddel = docSoporte.getIndicadorEliminado()!=null?docSoporte.getIndicadorEliminado().toString():"0";
			boolean  noEsRegistroEliminado = "0".equals(inddel)?true:false;
			if (docSoporte.getCodtipoproceso().equals("I") && noEsRegistroEliminado){
				enviaResolucionIM = true;
				break;
			}
		}

//	INICIO	\PAS20181U220200004\ CSANTILLAN
    	if(!esVigenteRIN05PrimeraParte) {
    	for (DatoSerie serie : series) {
    		serieRelacionada = false;
    		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
    		numsecdocum=0;
    		if (serie.getCodliberatorio() != null) {
    			if (SunatStringUtils.include(String.valueOf(serie.getCodliberatorio()),new String[] { "4442", "4443", "4444" })) {
    				enviaSerieConIM = true;
    				if(enviaResolucionIM){
			    		for(DatoSerieDocSoporte serieDoc:serieDocs){
			    			if (DOC_SOPORTE.equals(serieDoc.getCodtipodocsoporte()))
			    				numsecdocum=serieDoc.getNumiddocsoporte();
			    			if (numsecdocum!=null && numsecdocum!=0){
			    				for(DatoOtroDocSoporte docSoporte:declaracion.getDua().getListOtrosDocSoporte()){
			    					if (numsecdocum.intValue()==docSoporte.getNumsecdocum() && docSoporte.getCodtipoproceso().equals("I")){
			    						serieRelacionada = true;
			    						break;
			    					}
			    				}		    				
			    			}
			    			if(serieRelacionada){
			    				break;
			    			}
			    		}
			    		if(!serieRelacionada){
			    			result.add(getDUAError("35531",new Object[]{serie.getNumserie(),String.valueOf(serie.getCodliberatorio())}));
			    		}
    				}else{
    					result.add(getDUAError("35532",new Object[]{serie.getNumserie(),String.valueOf(serie.getCodliberatorio())}));
    				}
    			}
    		}



    	}
		
    	if(!enviaSerieConIM && enviaResolucionIM){
    		result.add(getDUAError("35533",new Object[]{""}));
    	}
    }
//  FIN \PAS20181U220200004\    
		return result;
	}		
    //fin gmontoya Pase 135


    //inicio arey Pase 23
    public List<Map<String,String>> valAsociacionDocSoporte(Declaracion declaracion){
    	List<Map<String,String>> result = new ArrayList<Map<String,String>>();
        DUA dua=declaracion.getDua();
        int cantDocSoporteTrans = dua.getListOtrosDocSoporte()!=null?dua.getListOtrosDocSoporte().size():0;
     
        //int codDocAsocLiq = 9;//corregido error ticket 2016-699230 - PAS20165E220200054
        String codDocAsocLiq = "9";//corregido error ticket 2016-699230 - PAS20165E220200054
  
        if(!CollectionUtils.isEmpty(dua.getListSeries())){
        	for(DatoSerie datosSerie : dua.getListSeries()){
        		if(!CollectionUtils.isEmpty(datosSerie.getListSerieDocSoporte())){
	        		for(DatoSerieDocSoporte datosSerieDocSop : datosSerie.getListSerieDocSoporte()){
	        			if(datosSerieDocSop.getCodtipodocsoporte().equals("1")){//es doc de soporte
	        				if(cantDocSoporteTrans>0){
	        					if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
	        						boolean docAsociado = false;
		        					for(DatoOtroDocSoporte datoDocSoporte : dua.getListOtrosDocSoporte()){
		        						if(SunatNumberUtils.isEqual(datoDocSoporte.getNumsecdocum()!=null?datoDocSoporte.getNumsecdocum():0,
		        								datosSerieDocSop.getNumiddocsoporte()!=null?datosSerieDocSop.getNumiddocsoporte():0)){
		        							docAsociado = true;
		        						}else{
		        							//if(codDocAsocLiq==new Integer(datoDocSoporte.getCodtipoproceso())){//corregido error ticket 2016-699230 - PAS20165E220200054 no se por que hiso asi la logica el pase 54 se agrega para 7 que no valida dicha asociacion ya esta en otro metodo
		        							if(datoDocSoporte.getCodtipoproceso()!=null && (codDocAsocLiq.equals(datoDocSoporte.getCodtipoproceso())||"7".equals(datoDocSoporte.getCodtipoproceso()))){//corregido error ticket 2016-699230 - PAS20165E220200054	
		        								docAsociado=true;
		        							}else{
		        								docAsociado = false;
		        							}
		        						}
		        						//reubicado error ticket 2016-699230 - PAS20165E220200054
		        						/*if (!docAsociado){
		        						result.add(getDUAError("35614",new Object[]{datosSerieDocSop.getNumiddocsoporte(),datosSerie.getNumserie()}));
		        						}*/                                                   
		        					}
		        					if (!docAsociado){
		        					result.add(getDUAError("35614",new Object[]{datosSerieDocSop.getNumiddocsoporte(),datosSerie.getNumserie()}));
		        					}                                                   
	        					}
	        				}else{
	        					result.add(getDUAError("35614",new Object[]{datosSerieDocSop.getNumiddocsoporte(),datosSerie.getNumserie()})); 
	        					//DOCUMENTO DE SOPORTE CON NUMERO DE SECUENCIA {0} ASOCIADO A LA SERIE {1}, NO HA SIDO TRANSMITIDO
	        				} 
	        			}
	        		}   
        		}
        	}        	
        }  
        // inicio PAS201830001100009
        int cantDocAutorizTrans = dua.getListDocAutorizantes()!=null?dua.getListDocAutorizantes().size():0;
        
        if(!CollectionUtils.isEmpty(dua.getListSeries())){    
        	for(DatoSerie datosSerie : dua.getListSeries()){
        		if(!CollectionUtils.isEmpty(datosSerie.getListSerieDocSoporte())){
	        		for(DatoSerieDocSoporte datosSerieDocSop : datosSerie.getListSerieDocSoporte()){
	        			if(DOC_AUTORIZANTE.equals(datosSerieDocSop.getCodtipodocsoporte())){
	        				if(cantDocAutorizTrans>0){
	        					if(!CollectionUtils.isEmpty(dua.getListDocAutorizantes())){
	        						boolean docAsociado = false;
	        						for (DatoDocAutorizante docAutoriza : dua.getListDocAutorizantes() ) {
		        						if(SunatNumberUtils.isEqual(docAutoriza.getNumsecdocum()!=null?docAutoriza.getNumsecdocum():0,
		        								datosSerieDocSop.getNumiddocsoporte()!=null?datosSerieDocSop.getNumiddocsoporte():0)){
		        								docAsociado = true;
		        						}                                                  
		        					}
		        					if (!docAsociado){
		        					result.add(getDUAError("35629",new Object[]{datosSerieDocSop.getNumiddocsoporte(),datosSerie.getNumserie()}));
		        					}                                                   
	        					}
	        				}else{
	        					result.add(getDUAError("35629",new Object[]{datosSerieDocSop.getNumiddocsoporte(),datosSerie.getNumserie()})); 
	        				} 
	        			}
	        		}   
        		}
        	}        	
        }
        return result;
    }//fin arey Pase 23

    /*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}
	
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
	
//	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
//		this.catalogoHelper = catalogoHelper;
//	}
		
		
}

