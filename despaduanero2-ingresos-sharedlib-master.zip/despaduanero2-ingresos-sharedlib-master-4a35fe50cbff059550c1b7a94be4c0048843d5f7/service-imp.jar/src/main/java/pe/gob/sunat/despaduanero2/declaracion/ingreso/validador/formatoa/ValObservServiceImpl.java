/*
 * Clase que define el servicio de validaciones de las observaciones de la DUA del formato A
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoObserv;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;

/**
 * The Class ValObserv. Clase que define el servicio de validaciones de las observaciones de la DUA del formato A.
 */
public class ValObservServiceImpl extends ValDuaAbstract implements ValObserv{
	
	//private FabricaDeServicios fabricaDeServicios;
	
	/**
	 * Valida que el campo numsecuencia de los elementos de la lista sean secuenciales de 1 a n.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param listObservaciones Elementos<DatoObserv>
	 * @return Map
	 */
	public Map<String, String> numsecuencia(Elementos<DatoObserv> listObservaciones){
		int i=1;
		boolean secuencial=listObservaciones==null || listObservaciones.isEmpty();
		for(DatoObserv observ:listObservaciones){
			String s=observ.getNumsecuencia();
			try{
				secuencial= (i==Integer.parseInt(s));
			}catch(Exception e){
				secuencial=false;
			}
			i++;
			if (!secuencial)
				break;
		}
		//glazaror... evitamos el uso de getDUAError
		//RIN10 PAS20145E220000373 Se cambia de mensaje de error
		//return secuencial?new HashMap<String,String>():getDUAError("30084","");
		if (secuencial) {
			//glazaror... seria preferible adicionar constante MAPA_VACIO y retornar...
			return new HashMap<String,String>();
		} else {
			//glazaror... hacemos uso de catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			return catalogoAyudaService.getError("35542");
		}
	}

	/**
	 * Valida el codigo de tipo de observacion. El tipo 01 no puede repetirse<br>
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param listObservaciones Elementos<DatoObserv>
	 * @return Map
	 */
	public List<Map<String, String>> codtipobserva(Elementos<DatoObserv> listObservaciones){
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		List<String> listIdObserva=new ArrayList<String>();

		for(DatoObserv observ:listObservaciones){
			String codTipoObserva=observ.getCodtipobserva();
			//if (!FormatoAServiceImpl.getInstance().isValidCatalogo("369", codTipoObserva))
			boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("369", codTipoObserva, SunatDateUtils.getCurrentDate()));
			if (!validaCatalogo)
				//listError.add(getDUAError("30085",new Object[]{codTipoObserva}));
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30085",new String[]{codTipoObserva}));
			// El tipo de observacion 03 esta reservado para observaciones en los items del formato B
			if (codTipoObserva.equals(Constants.COD_TIP_OBSERV_ITEMSFORMB)){
				//listError.add(getDUAError("30523",new Object[]{codTipoObserva}));
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30523",new String[]{codTipoObserva}));
			}
		}		
		
		if(!CollectionUtils.isEmpty(listError))
			return listError;
		
        // nro de secuencia y tipo no debe repetirse 
		for(DatoObserv observ:listObservaciones){
			String codTipoObserva=observ.getCodtipobserva();
			String numSecuencia=observ.getNumsecuencia();
			
			String idObservacion=numSecuencia+"-"+codTipoObserva;
			
			if (Collections.frequency(listIdObserva, idObservacion)==0){
				listIdObserva.add(codTipoObserva);
			}else{
				listError.add(getDUAError("30398",new Object[]{idObservacion}));
				break;
			}
		}
		
		List<String> listTipObserva=new ArrayList<String>();
        // Tipo 01 no puede repetirse
		for(DatoObserv observ:listObservaciones){
			//String codTipoObserva=observ.getCodtipobserva();
			//String codTipoObserva="01";
			
			listTipObserva.add(observ.getCodtipobserva());
			
			if (Collections.frequency(listTipObserva, Constants.COD_TIP_OBSERV_FORMATOA)>1){
				listError.add(getDUAError("30398",new Object[]{Constants.COD_TIP_OBSERV_FORMATOA}));
				break;
			}
		}
		

		return listError;
	}
	
	/**
	 * Valida el codigo de tipo de observacion.<br>
	 * 
	 * @param codtipobserva String
	 * @return Map
	 */
	public Map<String, String> codtipobserva(String codtipobserva){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("369", codtipobserva))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("369", codtipobserva,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30085","Error catalogo codtipobserva");
	}

	/**
	 * Valida la descripcion de la observacion.
	 * @param obsdeclaracion String
	 * @return Map
	 */
	public Map<String, String> obsdeclaracion(String obsdeclaracion){
		//glazaror... evitamos el uso de getDUAError
		//return !SunatStringUtils.isEmptyTrim(obsdeclaracion)?new HashMap<String,String>():getDUAError("01150","");
		if (!SunatStringUtils.isEmptyTrim(obsdeclaracion)) {
			//glazaror... evaluar pasar a una constante
			return new HashMap<String,String>();
		} else {
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			return catalogoAyudaService.getError("01150");
		}
		
	}
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
