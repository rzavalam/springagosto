package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;


import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilOtros;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
/**
 * 
 * @author lalberti
 *
 */

public class ValidadorTextilOtros extends ValidadorTextilAbstract
{
  
  
  public ValidadorTextilOtros() {
    super();
  }


  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    List<ErrorDescrMinima> lstErrores  = validarEstructura(objeto);
   // lstErrores .addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores))  {
      lstErrores .addAll(this.validarFOBVsPesoObs(objeto, dua));
      lstErrores .addAll(ValidarSumaPorcenComp(objeto));
    }
    return lstErrores ;
  }
  
  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarModelo(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialTextil1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialTextilPorcen1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialTextil2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialTextilPorcen2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialTextil3erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialTextilPorcen3erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarOtrasCaracteristicaMaterialTextil(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarDimencionesMaterialTextil(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarUsoMaterialTextil(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialTextil4toComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialTextilPorcen4toComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> ValidarSumaPorcenComp(ModelAbstract object){
    List<ErrorDescrMinima> lst =  new ArrayList<ErrorDescrMinima>();
    TextilOtros otros = (TextilOtros) object;
    Integer p1 = 0;
    Integer p2 = 0;
    Integer p3 = 0;
    Integer p4 = 0;
    try{
      p1 = !SunatStringUtils.isEmptyTrim(otros.getCompoMaterialTextilPorcen1erComp().getValtipdescri())?
    	 Integer.parseInt(otros.getCompoMaterialTextilPorcen1erComp().getValtipdescri()):0;
      p2 = otros.getCompoMaterialTextil2doComp()!=null &&
    	!SunatStringUtils.isEmptyTrim(otros.getCompoMaterialTextilPorcen2doComp().getValtipdescri())?
          Integer.parseInt(otros.getCompoMaterialTextilPorcen2doComp().getValtipdescri()):0;
      p3 = otros.getCompoMaterialTextil3erComp()!=null &&
    	!SunatStringUtils.isEmptyTrim(otros.getCompoMaterialTextilPorcen3erComp().getValtipdescri())?
          Integer.parseInt(otros.getCompoMaterialTextilPorcen3erComp().getValtipdescri()):0;
      p4 = otros.getCompoMaterialTextil4toComp()!=null &&
        !SunatStringUtils.isEmptyTrim(otros.getCompoMaterialTextilPorcen4toComp().getValtipdescri())?
          Integer.parseInt(otros.getCompoMaterialTextilPorcen4toComp().getValtipdescri()):0;
    }catch(NumberFormatException e){}
    Integer s = p1 + p2 + p3 + p4;
    if(s != 100){
      DatoDescrMinima suma =  otros.getCompoMaterialTextilPorcen1erComp();
      suma.setValtipdescri(s.toString());      
      lst.add(obtenerError("31845", suma));
    }
    return lst;
  }
}
