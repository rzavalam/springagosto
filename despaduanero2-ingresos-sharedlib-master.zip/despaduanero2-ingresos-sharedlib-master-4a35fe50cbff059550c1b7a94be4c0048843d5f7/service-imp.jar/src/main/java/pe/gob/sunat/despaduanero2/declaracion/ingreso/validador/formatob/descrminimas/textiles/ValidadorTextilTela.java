package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilTela;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * @author lalberti
 */

public class ValidadorTextilTela extends ValidadorTextilAbstract
{
    private static final String CAPITULO_50     = "50";
    private static final String CAPITULO_51     = "51";
    private static final String CAPITULO_52     = "52";
    private static final String CAPITULO_53     = "53";
    private static final String CAPITULO_54     = "54";
    private static final String CAPITULO_55     = "55";
    private static final String CAPITULO_60     = "60";
    private static final String CAPITULO_59     = "59";
    private static final String MAT_PLAS_PART_1 = "5903";
    private static final String MAT_PLAS_PART_2 = "5907";
    private static final String MAT_PLAS_PART_3 = "6001";
    private static final String UNIDAD_MERCANCIA      = "99";

    private static List<String> unComSet                = new ArrayList<String>(Arrays.asList("M", "M2", "YD", "YD2"));
    private static String       codErrorUnidadComercial = "31302";

    public ValidadorTextilTela()
    {
        super();
        // TODO Auto-generated constructor stub
        /*
        unComSet.add("M");
        unComSet.add("M2");
        ValidadorTextilAbstract.getErrors().put("codUnComErr", "31302");*/
    }

    @Override
    public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
    {
        List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);
        //lstErrores.addAll(validarEstructura(objeto));
        if (CollectionUtils.isEmpty(lstErrores))
        {

            DatoItem item = obtenerItem(objeto, dua);           
            lstErrores.addAll(super.validarFOBVsPesoObs(objeto, dua));
            lstErrores.addAll(super.validarUnidadComercial(objeto, item, unComSet,codErrorUnidadComercial));
            lstErrores.addAll(validadorNumeroCertificado2daCalidad(objeto, dua));
            lstErrores.addAll(validarTipoTela(objeto, dua));
            lstErrores.addAll(validarEspesorMateriaPlastica(objeto, dua));
		    lstErrores.addAll(validarComposicionMateriaPlastica(objeto,dua));
		    lstErrores.addAll(ValidarSumaPorcenComp(objeto));
    }
    return lstErrores;
  }

  public List<ErrorDescrMinima> validadorNumeroCertificado2daCalidad(ModelAbstract object,
            														 Declaracion dua){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		DatoItem item = obtenerItem(object, dua);
		String estadoMercancia = item.getCodestamer();
		TextilTela textil = (TextilTela) object;
		String datoAValidar = textil.getNumeroCertificado2daCalidad()
							  .getValtipdescri();
		Boolean esObligatorio = UNIDAD_MERCANCIA.equals(estadoMercancia)?true:false;

		if (esObligatorio) {
			if (SunatStringUtils.isEmptyTrim(datoAValidar)) {
				lst.add(obtenerError("31367",
						textil.getNumeroCertificado2daCalidad()));
			}
		}
        else if (!SunatStringUtils.isEmpty(datoAValidar))
        {
            String regla="el estado de la mercancia es diferente de 99";
            String campo= obtenerDescripcionDelCalogo("500", textil.getNumeroCertificado2daCalidad().getCodtipdescr());
            Object[] argumentos = new Object[] { regla,campo };
            ErrorDescrMinima error = obtenerError("30897",textil.getNumeroCertificado2daCalidad(), argumentos);
            lst.add(error);
        }
      return lst;

	}   
    
  public List<ErrorDescrMinima> validarTipoTela(ModelAbstract object,
                                                Declaracion dua){
    TextilTela tela      = (TextilTela) object;
    String datoAValidar  = tela.getTipoTela().getValtipdescri();
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    DatoItem item        = obtenerItem(object, dua);
    String capitulo      = item.getNumpartnandi().toString().substring(0, 2);
    String[] args        = new String[]{item.getNumpartnandi().toString()};

    //Verifiacion por partida
    if(SunatStringUtils.isEqualTo(CAPITULO_60, capitulo)){
    	if(!"PTO".equalsIgnoreCase(datoAValidar)){
    		lst.add( obtenerError("31305", tela.getTipoTela(), args));
    	}
    }
    if(ArrayUtils.contains(new String[]{CAPITULO_50,CAPITULO_51,CAPITULO_52,
            CAPITULO_53,CAPITULO_54,CAPITULO_55}, capitulo)){
    	if(!"TRA".equalsIgnoreCase(datoAValidar)){
    		lst.add( obtenerError("31306", tela.getTipoTela(), args));
    	}
    }
    if(CAPITULO_59.equals(capitulo)){
    	if(!("TRA".equals(datoAValidar) || "PTO".equals(datoAValidar))){
    		lst.add( obtenerError("31306", tela.getTipoTela(), args));
    	}
    }   
    return lst;
  }

  public List<ErrorDescrMinima> validarCompoTela1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoTelaPorcen1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoTela2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoTelaPorcen2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarGradoElaboracion(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarPrimerAcabado(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarSegundoAcabado(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarComposicionMateriaPlastica(
                                                                  ModelAbstract object, Declaracion dua) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    DatoItem item              = obtenerItem(object, dua);
    TextilTela tela            = (TextilTela) object;
    String partida         = item.getNumpartnandi().toString().substring(0, 4);
    String datoAValidar    = tela.getComposicionMateriaPlastica().getValtipdescri();

    if (ArrayUtils.contains(new String[]{MAT_PLAS_PART_1 ,MAT_PLAS_PART_2},partida)){
      if(SunatStringUtils.isEmptyTrim(datoAValidar))
        lst.add(obtenerError("31370", tela.getComposicionMateriaPlastica()));
    } else if(partida.equals(MAT_PLAS_PART_3)){}
    else{
      if(!SunatStringUtils.isEmptyTrim(datoAValidar))
        lst.add(obtenerError("31371", tela.getComposicionMateriaPlastica()));
    }
    return lst;
  }

  public List<ErrorDescrMinima> validarEspesorMateriaPlastica(ModelAbstract object,
                                                              Declaracion dua){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    TextilTela tela = (TextilTela) object;
    DatoItem item = obtenerItem(tela, dua);
    String partida = item.getNumpartnandi().toString().substring(0, 4);
    String datoAValidar = tela.getEspesorMateriaPlastica().getValtipdescri();

    if (ArrayUtils.contains(new String[]{MAT_PLAS_PART_1 ,MAT_PLAS_PART_2},partida)){
      if(SunatStringUtils.isEmptyTrim(datoAValidar))
        lst.add(obtenerError("31327", tela.getEspesorMateriaPlastica()));
    }else if(partida.equals(MAT_PLAS_PART_3)){}
    else{
      if(!SunatStringUtils.isEmptyTrim(datoAValidar))
        lst.add(obtenerError("31328", tela.getEspesorMateriaPlastica()));
    }
    return lst;

  }

  public List<ErrorDescrMinima> validarGramaje(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarAnchoTela(ModelAbstract object)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarUsoTela(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoTela3erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoTelaPorcen3erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoTela4toComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoTelaPorcen4toComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> ValidarSumaPorcenComp(ModelAbstract object){
    List<ErrorDescrMinima> lst =  new ArrayList<ErrorDescrMinima>();
    TextilTela tela = (TextilTela) object;
    Integer p1 = 0;
    Integer p2 = 0;
    Integer p3 = 0;
    Integer p4 = 0 ;
    p1 = Integer.parseInt(tela.getCompoTelaPorcen1erComp().getValtipdescri());
    p2 = !SunatStringUtils.isEmptyTrim(tela.getCompoTelaPorcen2doComp().getValtipdescri())?
    	Integer.parseInt(tela.getCompoTelaPorcen2doComp().getValtipdescri()):0;
    p3 = !SunatStringUtils.isEmptyTrim(tela.getCompoTelaPorcen3erComp().getValtipdescri())?
          Integer.parseInt(tela.getCompoTelaPorcen3erComp().getValtipdescri()) : 0;
	p4 = !SunatStringUtils.isEmptyTrim(tela.getCompoTelaPorcen4toComp().getValtipdescri()) ? 
		Integer.parseInt(tela.getCompoTelaPorcen4toComp().getValtipdescri()) : 0;
	
	if ((p1 + p2 + p3 + p4) != 100) {
		Integer s = p1 + p2 + p3 + p4;
		DatoDescrMinima suma = tela.getCompoTelaPorcen1erComp();
		suma.setValtipdescri(s.toString());
		lst.add(obtenerError("31373", suma));
	}
	return lst;
  }
  public List<ErrorDescrMinima> validarConstruccionTela(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarTituloHilado(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
}