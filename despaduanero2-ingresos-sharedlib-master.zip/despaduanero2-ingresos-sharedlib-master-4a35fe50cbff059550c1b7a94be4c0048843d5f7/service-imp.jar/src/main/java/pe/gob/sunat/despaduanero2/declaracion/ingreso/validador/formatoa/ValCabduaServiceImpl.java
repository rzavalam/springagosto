/*
 * Clase que define el servicio de validaciones generales de la declaracion
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.administracion2.tramite.model.ResCab;
import pe.gob.sunat.administracion2.tramite.service.ResolucionService;
import pe.gob.sunat.despaduanero.despacho.comun.impo.model.TabImpDU;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Polizad;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.CircunoceDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.OpecomextDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorValidaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
//import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo; //PAS20181U220200049
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo; //PAS20181U220200049
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionSIGADService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.localanexo.ValidadorLocalAnexo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.localanexo.ValidadorLocalAnexoException;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.PuntoLLegadaValidadorException;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidadorPuntoLlegadaMercancia;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidadorPuntoLlegadaMercanciaModalidadDespachoAnticipado;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidadorPuntoLlegadaMercanciaModalidadDespachoUrgente;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidadorPuntoLlegadaMercanciaModalidadExcepcional;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes.ValPrecedenteEERService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoContrato;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactSuce;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPrecinto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoTributosAutocalc;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DocumentoSoporteFormatoB;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MercanciaDispuestaDAO; //P427
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.AutorizacionZonaPrimariaService;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionConvertirFormatoService;
import pe.gob.sunat.despaduanero2.declaracion.service.DisposicionMercanciaService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoOABL;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdeta;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DocuTransDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.McdetaDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.OperasocmanifDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.eer.ManifiestoDesconsolidadoEER;
import pe.gob.sunat.despaduanero2.manifiesto.service.Datado2ValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
//import pe.gob.sunat.despaduanero2.manifiesto.util.Constantes;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.SolicitudAutorizacionZonaPrimaria;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.genadeudo.service.ConsultaLiquidacionService;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.servicio2.registro.service.SprDAOService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionDepositoAduaneroService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoConsumoService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImportacionAdmisionPerfecService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImportacionAdmisionReexpService;
import pe.gob.sunat.tecnologia.receptor.bean.EnvioBean;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioDAO;
import pe.gob.sunat.administracion2.tramite.model.ResCab;
import pe.gob.sunat.administracion2.tramite.service.ResolucionService;
import pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.lang.ArrayUtils;
import pe.gob.sunat.despaduanero2.declaracion.service.DisposicionMercanciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;

import pe.gob.sunat.despaduanero2.manifiesto.util.ManifiestoUtil; //PAS20181U220200049

/**
 * The Class ValCabdua. Clase que define el servicio de validaciones generales de la declaracion
 */
public class ValCabduaServiceImpl extends ValDuaAbstract implements ValCabdua{

	protected final Log log = LogFactory.getLog(getClass()); 
	//private FabricaDeServicios fabricaDeServicios;
	//HotSwappableTargetSource swapperDatasourceLectura;
	HotSwappableTargetSource swapperDatasourceEscritura;
	protected boolean enableSwapperDataSource = true;
	//private EnvioDAO envioDAO;
	//private DdpDAOService ddpDAOService;	
	//private SprDAOService sprDAOService;	
	//private ValParticipante valParticipante;
	//private ValidadorLocalAnexo validadorLocalAnexo;	
	//private CatalogoHelperImpl catalogoHelper;
	//private HotSwappableTargetSource swapperDatasource;	
	//private DisposicionMercanciaService disposicionMercanciaService; //P427

	//private ResolucionService			 resolucionService;
	
	/**
	 * Obtiene la fecha de numeracion de la declaracion.
	 * 
	 * @param declaracion Declaracion
	 * @return el hash map con la fecha de declaracion
	 * @return Mapa de errores
	 */
	public HashMap<String, Date> obtfecvalidacion(Declaracion declaracion) {		

		HashMap<String, Date> response = new HashMap<String, Date>();
		//String transaccion = declaracion.getCodtipotrans();
		Date fechaValidacion = DateUtil.getToday();		  

		response.put("fechaReferencia", fechaValidacion);
		return response;
	}


	/**
	 * Establece la dua como variable global de las validaciones.
	 * 
	 * @param declaracion Declaracion
	 * @param numOrden String
	 * @param codUsuario String
	 * @param annEnvio Integer
	 * @param numEnvio Long
	 * @param tipoSender String
	 * @param numeroDocumentoIdentidadSender String
	 * @param tipoDocumentoIdentidadSender String
	 * @param codTransaccion String
	 * @return el mapa de errrores
	 */
	public Map<String, ?> setupDeclaracion(
			Declaracion declaracion, 
			String numOrden,
			String codUsuario, 
			Integer annEnvio, 
			Long numEnvio,
			String tipoSender,
			String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender,
			String codTransaccion) {

		Map<String, Object> response = new HashMap<String, Object>();
	
		// r2bz nueva validaci�n  vigencia de la oma por transaccion y aduana
		//List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043", new Date());
        String codAduana = "";
        if( declaracion.getPadre() != null )
        	codAduana = ((Mensaje) declaracion.getPadre()).getControl().getCodigoAduanaOrden()!=null?((Mensaje) declaracion.getPadre()).getControl().getCodigoAduanaOrden().toString():declaracion.getCodaduana().toString();
        else
        	codAduana = declaracion.getCodaduana();
		List<Map<String, String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarAsociacion("135", codAduana, codTransaccion, SunatDateUtils.getCurrentDate());

		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			seteoFormatoA(declaracion);
			seteoFormatoB(declaracion);
		}
	
		//FIN OMA
		
		//PAS20181U220200049 - Inicio
		//Se setea cod_empdoctra y cod_tipdocempdoctra de la BD para la 1001, ya no debe enviarlo en la transmision
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", new Date());
		Boolean seEnvioEmpTransporteEnXML  = true;
		log.debug("PAS20181U220200049 - Inicio");
		if(declaracion.getDua() == null) {
			log.debug("PAS20181U220200049 - declaracion.getDua()");
			seEnvioEmpTransporteEnXML  = false;
		}
		else if(declaracion.getDua().getManifiesto() == null) {
			log.debug("PAS20181U220200049 - declaracion.getDua().getManifiesto()");
			seEnvioEmpTransporteEnXML  = false;
		}
		else if(declaracion.getDua().getManifiesto().getEmpTransporte() == null) {
			log.debug("PAS20181U220200049 - declaracion.getDua().getManifiesto().getEmpTransporte()");
			seEnvioEmpTransporteEnXML  = false;
		}
		else if(declaracion.getDua().getManifiesto().getEmpTransporte().getNumeroDocumentoIdentidad() == null) {
			log.debug("PAS20181U220200049 - declaracion.getDua().getManifiesto().getEmpTransporte().getNumeroDocumentoIdentidad()");
			seEnvioEmpTransporteEnXML  = false;
		}
		log.debug("PAS20181U220200049 - Fin");
		/*	
		if(declaracion.getDua().getManifiesto().getEmpTransporte().getNumeroDocumentoIdentidad() == null && declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().getCodDatacat() == null) {
			seEnvioEmpTransporteEnXML  = false;
		}
		*/
		
		if (!CollectionUtils.isEmpty(MapaValManNum)){
			if(ConstantesDataCatalogo.TRANS_NUMERACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) || ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)) {//CAMBIO PARA RECTIFICACION RIN 05 MOL
				String codtipmanif = declaracion.getDua().getManifiesto().getCodtipomanif();
				String codmodtransp = declaracion.getDua().getManifiesto().getCodmodtransp() !=null ? declaracion.getDua().getManifiesto().getCodmodtransp() : null;
				String codaduamanif = declaracion.getDua().getManifiesto().getCodaduamanif() !=null ? declaracion.getDua().getManifiesto().getCodaduamanif() : null;
				String nummanif = declaracion.getDua().getManifiesto().getNummanif() !=null ? declaracion.getDua().getManifiesto().getNummanif() : null;
				String annmanif = declaracion.getDua().getManifiesto().getAnnmanif() !=null ? declaracion.getDua().getManifiesto().getAnnmanif() : null;
				if(annmanif != null) {
					annmanif = SunatStringUtils.length(annmanif) > 3 ? annmanif.substring(0, 4) : null;
				}
				if(codmodtransp != null && codaduamanif != null && nummanif != null && annmanif != null) {
					Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion();
					if(fechaDeclaracion==null){
						fechaDeclaracion = new Date();
					}
					Manifiesto manifiesto = null;
					boolean evaluarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
		    		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
	    			manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif,codmodtransp, codaduamanif,SunatNumberUtils.toInteger(annmanif), nummanif,true, fechaDeclaracion,evaluarEER);		    		
	    			if(manifiesto != null ) {//esto es solo para sda
		    			if(!manifiesto.isEsSigad()){
	    				if(manifiesto.getTransportista()!=null && manifiesto.getTransportista().getSecuenciaDeParticipantes()!=null) {
	    					declaracion.getDua().getManifiesto().getEmpTransporte().setNumeroDocumentoIdentidad(manifiesto.getTransportista().getNumeroDocumentoIdentidad());
							declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().setCodDatacat(manifiesto.getTransportista().getTipoDocumentoIdentidad().getCodDatacat());
			    		}//cuando es del sda, el sistema ya lo carga al buscar el manif. corregido en PAS20181U220200064
	    					    				
	    				boolean esExcepcional = "00".equals(declaracion.getDua().getCodmodalidad())?true:false;
	    				if(esExcepcional){
	    					boolean esSinPesosYBultosRecibidos =false;
	    					Map mapErrores = validaExistenciaPesoyBustosRecibidosParaDAMDiferida(declaracion.getDua(),manifiesto);
	    					if(!mapErrores.isEmpty()){
	    						esSinPesosYBultosRecibidos= true;
	    					}
	    					if(esSinPesosYBultosRecibidos){
		    					if( SunatDateUtils.sonIguales(manifiesto.getFechaTerminoDeDescarga(), SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
		    						 declaracion.getDua().getManifiesto().setFectermino(manifiesto.getFechaEfectivaDeLlegada());
								}	
	    					}
	    				    					
	    				  
	    				   
	    				}
	    				
	    				/*Map parametroParticip = new HashMap();
				 		parametroParticip.put("numeroCorrelativo", manifiesto.getNumeroCorrelativo().toString());
	    				
				 		if(ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equalsIgnoreCase(codmodtransp)) {
				 			parametroParticip.put("codTippartic", new String [] {"11","13","14"});
				 		}
				 		else if (ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL_UNECE.equalsIgnoreCase(codmodtransp) || ConstantesDataCatalogo.VIA_TRANSPORTE_MARITIMA.equalsIgnoreCase(codmodtransp)) {
				 			parametroParticip.put("codTippartic", new String [] {"12"});
				 		}
				 		else if (ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE.equalsIgnoreCase(codmodtransp)) {
				 			parametroParticip.put("codTippartic", new String [] {"15"});
				 		}			 		
			    		ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
			    		List<Participante> listadoParticipante = participanteService.obtenerTipoParticipanteAutorizadoByCriterios(parametroParticip);
			    		if (!CollectionUtils.isEmpty(listadoParticipante)) {
			    			declaracion.getDua().getManifiesto().getEmpTransporte().setNumeroDocumentoIdentidad(listadoParticipante.get(0).getNumeroDocumentoIdentidad());
							declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().setCodDatacat(listadoParticipante.get(0).getTipoDocumentoIdentidad().getCodDatacat());
			    		}*/
		    			}else{
		    				if(manifiesto.getTransportista()!=null && manifiesto.getTransportista().getNumeroDocumentoIdentidad()!=null) {
		    					String rucTransportista = null;
		    					OpecomextDAO opecomextDao = fabricaDeServicios.getService("Ayuda.opecomextDef");
		    					Map<String, Object> parametros = new HashMap<String, Object>();
		    					parametros = new HashMap<String, Object>();
		    					parametros.put("codTipOpera",ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA);
		    					parametros.put("codAduanero", manifiesto.getTransportista().getNumeroDocumentoIdentidad()); // es el parametro para buscar opecomext.cod.andadu
		    					Date fechaHoy = SunatDateUtils.getCurrentDate();
		    					SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
		    					String resultadoHoy = formato.format(fechaHoy);
		    					Date fechaReferenciaNew = SunatDateUtils.getDate(resultadoHoy, "dd/MM/yyyy");
		    					//parametros.put("fechaVigencia", fechaReferenciaNew);
		    					List<Map<String, Object>> listaOperador = opecomextDao.findByMap(parametros);
		    					if (!CollectionUtils.isEmpty(listaOperador)) {
		    						Map<String, Object> operador = listaOperador.get(0);
		    						rucTransportista = (String) operador.get("num_ruc");
		    						manifiesto.getTransportista().setNumeroDocumentoIdentidad(rucTransportista);
		    						manifiesto.getTransportista().getTipoDocumentoIdentidad().setCodDatacat("4");
		    						declaracion.getDua().getManifiesto().getEmpTransporte().setNumeroDocumentoIdentidad(manifiesto.getTransportista().getNumeroDocumentoIdentidad());
									declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().setCodDatacat(manifiesto.getTransportista().getTipoDocumentoIdentidad().getCodDatacat());
		    					}

				    		}

		    				boolean esExcepcional = "00".equals(declaracion.getDua().getCodmodalidad())?true:false;
		    				if(esExcepcional){
		    					boolean esSinPesosYBultosRecibidos =false;
		    					Map mapErrores = validaExistenciaPesoyBustosRecibidosParaDAMDiferida(declaracion.getDua(),manifiesto);
		    					if(!mapErrores.isEmpty()){
		    						esSinPesosYBultosRecibidos= true;
		    					}
		    					if(esSinPesosYBultosRecibidos){
			    					if( SunatDateUtils.sonIguales(manifiesto.getFechaTerminoDeDescarga(), SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
			    						 declaracion.getDua().getManifiesto().setFectermino(manifiesto.getFechaEfectivaDeLlegada());
									}	
		    					}
		    				    					
		    				  
		    				   
		    				}
		    				
		    			}
	    			}
		    	}
			}
		}
		
		//PAS20181U220200049 - Fin
		
		Declaracion declaracionXML = declaracion;

		boolean contieneFA = true;

		if(declaracion.getDua()==null) declaracion.setDua(new DUA());
		String codigoAduana = declaracion.getDua().getCodaduanaorden();
		if( SunatStringUtils.isEmpty( codigoAduana ) )
		{
			String codaduanaref=declaracion.getNumdeclRef()!=null?declaracion.getNumdeclRef().getCodaduana():null;
			codigoAduana = codaduanaref;
			contieneFA = false;
		}
		//Si contiene formato A se establecen valores vacios a los atributos de la DUA.
		if(contieneFA)
		{
			DUA dua=declaracionXML.getDua();
			if (dua.getListDocTransporte()==null)
				dua.setListDocTransporte(new Elementos<DatoDocTransporte>());
			if (dua.getListDocAutorizantes()==null)
				dua.setListDocAutorizantes(new Elementos<DatoDocAutorizante>());
			if (dua.getListSeries()==null)
				dua.setListSeries(new Elementos<DatoSerie>());
			else{
				for(DatoSerie serie:dua.getListSeries()){
					if (serie.getListContrato()==null)
						serie.setListContrato(new Elementos<DatoContrato>());
					if (serie.getListRegPrecedencia()==null)
						serie.setListRegPrecedencia(new Elementos<DatoRegPrecedencia>());
					if (serie.getListSerieDocSoporte()==null)
						serie.setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
					if (serie.getListVehiculos()==null)
						serie.setListVehiculos(new Elementos<DatoVehiculo>());
					else{
						for(DatoVehiculo vehiculo:serie.getListVehiculos()){
							if (vehiculo.getListMontoGastos()==null)
								vehiculo.setListMontoGastos(new Elementos<DatoMontoGasto>());
						}
					}
				}
			}
			if (dua.getListOtrosDocSoporte()==null)
				dua.setListOtrosDocSoporte(new Elementos<DatoOtroDocSoporte>());
			//r2bz
			if (dua.getListOtrosDocSoporteCO()==null)
				dua.setListOtrosDocSoporteCO(new Elementos<DatoOtroDocSoporte>());
			if (dua.getListFacturaRef()==null)
				dua.setListFacturaRef(new Elementos<DatoFacturaref>());
			if (dua.getListIndicadores()==null)
				dua.setListIndicadores(new Elementos<DatoIndicadores>());
			if (dua.getListObservaciones()==null)
				dua.setListObservaciones(new Elementos<Observacion>());
			if (dua.getListTributosAutocalculados()==null)
				dua.setListTributosAutocalculados(new Elementos<DatoTributosAutocalc>());
			if (dua.getManifiesto().getListEquipamientos()==null)
				dua.getManifiesto().setListEquipamientos(new Elementos<DatoEquipamiento>());
			else{
				for(DatoEquipamiento equipamiento:dua.getManifiesto().getListEquipamientos()){
					if (equipamiento.getListPrecintos()==null)
						equipamiento.setListPrecintos(new Elementos<DatoPrecinto>());
				}
			}
			if (dua.getDatoCertificadoOrigen()!=null)
				if (dua.getDatoCertificadoOrigen().getListAutocertificacion()==null)
					dua.getDatoCertificadoOrigen().setListAutocertificacion(new Elementos<DatoAutocertificacion>());			 
		}
		Map<String, Object> argumentoGrabacion = new HashMap<String, Object>();
		declaracionXML.setCodtipotrans(codTransaccion);//faltaba seteo de trx a nivel declaracion pase PAS20155E220200192
		declaracionXML.setNumorden(numOrden);
		argumentoGrabacion.put("declaracion", declaracionXML);
		argumentoGrabacion.put("tipoSender", tipoSender);
		argumentoGrabacion.put("numeroDocumentoIdentidadSender",  numeroDocumentoIdentidadSender );
		argumentoGrabacion.put("tipoDocumentoIdentidadSender",  tipoDocumentoIdentidadSender );	
		argumentoGrabacion.put("codTransaccion",  codTransaccion );		 
		argumentoGrabacion.put("numOrden", numOrden);
		argumentoGrabacion.put("codUsuario", codUsuario);
		argumentoGrabacion.put("annEnvio", annEnvio);
		argumentoGrabacion.put("numEnvio", numEnvio);
		Date fechaConclusion=new Date();
		String resultadoDias="";
		fechaConclusion=SunatDateUtils.addMonth(SunatDateUtils.getCurrentDate(),3);
		if(log.isDebugEnabled()){
			log.debug("Inicio - Calculo de DiasUtiles en valCabduaService");
			log.debug("========================================================");
		}
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(fechaConclusion));
		params.put("FECHAHASTA", 1);
		params.put("TIPO", 2);
		params.put("INCLUYE", "S");
		params.put("SUSPENDE", "S");
		log.info("Parametros DiasUtiles:  Inicio - Calculo de DiasUtiles en valCabduaService " + params);
		//resultadoDias=(String)NumeracionServiceImpl.getInstance().getDiasUtilesDAO().getSPDiasUtiles(params);		 
		//resultadoDias=(String)((DiasUtilesDAO)fabricaDeServicios.getService("diasUtilesDAO")).getSPDiasUtiles(params);
		DiasUtilesDAO diasUtilesDAO = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
		DataSourceContextHolder.setKeyDataSource(codigoAduana);
		resultadoDias= SunatStringUtils.toStringObj(diasUtilesDAO.getSPDiasUtiles(params));
		//resultadoDias="20100520";
		log.info("resultadoDias DiasUtiles:  Inicio - Calculo de DiasUtiles en valCabduaService " + resultadoDias);
		if(log.isDebugEnabled()){
			log.debug("Fin - Calculo de DiasUtiles en valCabduaService");
			log.debug("========================================================");
		}
		fechaConclusion=SunatDateUtils.getDateFromInteger(SunatNumberUtils.toInteger(resultadoDias));
		argumentoGrabacion.put("fechaConclusionDespa", fechaConclusion);
		//NSR 20110111: Esto esta de mas, ya no existe este concepto, esto se determina en el Servicio validarManifiestoCarga 
		argumentoGrabacion.put("tipoDesp",generarTipoDespacho(declaracion));
		//variablesIngreso.put("fechaConclusionDespa",fechaConclusion);
		//NSR 20110111: Esto tambin esta de mas, esto se determina en el Servicio validarManifiestoCarga 
		//		 if(contieneFA)
		//			 verificarSiValidaManif(declaracionXML,argumentoGrabacion);
		if (declaracion.getDua().getManifiesto()!=null){
			argumentoGrabacion.put("viaTransp",declaracion.getDua().getManifiesto().getCodmodtransp());
			argumentoGrabacion.put("fechallegadaXML",declaracion.getDua().getManifiesto().getFectermino());
		}
		if (declaracion.getDua().getCodmodalidad()!=null){
			argumentoGrabacion.put("codModalidad", declaracion.getDua().getCodmodalidad()); 
		}
		log.debug("PAS20181U220200049 - Inicio 2");
		argumentoGrabacion.put("seEnvioEmpTransporteEnXML", seEnvioEmpTransporteEnXML);//PAS20181U220200049
		log.debug("PAS20181U220200049 - Fin 2");
		response.put("variablesIngreso", argumentoGrabacion);
		response.put("declaracion", declaracionXML);
		
		//r2bz si esta vigente el catalogo se genera el XML de UNECE 
//PAS20181U220200004
		if (CollectionUtils.isEmpty(((CatalogoValidaService) fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("380", "0048",SunatDateUtils.getCurrentDate()))) {			
			try {
				DeclaracionConvertirFormatoService declaracionConvertirFormatoService = (DeclaracionConvertirFormatoService) fabricaDeServicios.getService("declaracion.DeclaracionConvertService");
				declaracionConvertirFormatoService.convertUNECEtoOMA(declaracionXML, argumentoGrabacion);
			} catch (Exception e) {
				e.printStackTrace();
				log.debug("DeclaracionConvertirFormatoService - convertUNECEtoOMA:ERROR!!!:"+e.toString());
			}
		}
		return response;
	}
	/**
	 * Valida si la orden de envio se encuentra en proceso.
	 * 
	 * @param declaracion Declaracion, declaracion a evaluar
	 * @param codTransaccion String, codigo de la transaccion
	 * @param numeroDocumentoIdentidadSender String, numero de ruc del agente
	 * @param numOrden String, numero de la orden de envio
	 * @param numEnvio String, numero de envio generado
	 * @return el mapa de errrores
	 * @throws Exception 
	 */
	public Map<String,String> validarEnProceso(Declaracion declaracion, String codTransaccion, String numeroDocumentoIdentidadSender, String numOrden, String numEnvio) throws Exception{
		EnvioDAO envioDAO = fabricaDeServicios.getService("manifiesto.envioDAO");
		String annRefemisor=numOrden.substring(0, 4);
		String numRefemisor=numOrden.substring(4);
		List<EnvioBean> listEnvio;
		Map<String,Object> paramsMap=new HashMap<String,Object>();
		paramsMap.put("codTransaccion", codTransaccion);
		paramsMap.put("idEmisor", numeroDocumentoIdentidadSender);
		paramsMap.put("annRefemisor", annRefemisor);
		paramsMap.put("numRefemisor", numRefemisor);
		paramsMap.put("numeroTicket", numEnvio);
		paramsMap.put("codEstado", "22");
		listEnvio=envioDAO.listByParameterMap(paramsMap);
		if (listEnvio!=null && !listEnvio.isEmpty()){
			return getDUAError("00132","Orden de envio en Proceso");
		}else{
			paramsMap.put("codEstado", "23");
			listEnvio=envioDAO.listByParameterMap(paramsMap);
			if (listEnvio!=null && !listEnvio.isEmpty())
				return getDUAError("00132","Orden de envio se encuentra procesando por el orquestador");
		}
		return new HashMap<String,String>();
	}
	/**
	 * Verifica que la orden interna del operador no se encuentre numerada
	 * 
	 * <pre>
	 * Query sugerido:
	 * select * from cab_declara a,participante_doc b
	 * where a.cod_aduana=&lt;cdigo de aduana&gt; and a.cod_regimen=&lt;cdigo de rgimen&gt; and a.ann_orden=&lt;ao de la orden&gt; and a.num_orden=&lt;nro. de la orden&gt;
	 * and b.num_corredoc=a.num_corredoc and b.cod_tippartic='41'and b.cod_tipdoc='4' and
	 * b.num_docident=&lt;RUC del agente
	 * 
	 * </pre>
	 * 
	 * @param declaracion Declaracion, declaracion a evaluar
	 * @param tipoDocumentoIdentidadSender String, tipo de documento del sender
	 * @param numeroDocumentoIdentidadSender String, numero de documento del sender
	 * @param numOrden String, numero de la orden
	 * @return el mapa de errores de validacion
	 */
	public Map<String,String> validarOrdenDuplicada(Declaracion declaracion, String tipoDocumentoIdentidadSender ,String numeroDocumentoIdentidadSender, String numOrden,String codTransaccion)  throws Exception{
		EnvioDAO envioDAO = fabricaDeServicios.getService("manifiesto.envioDAO");
		Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();
		paramsCabDeclara.put("codRegimen", declaracion.getDua().getCodregimen());
		paramsCabDeclara.put("codAduana", declaracion.getDua().getCodaduanaorden());
		paramsCabDeclara.put("annOrden", numOrden.substring(0, 4));
		paramsCabDeclara.put("numOrden", numOrden.substring(4,10));
		paramsCabDeclara.put("rucAgente", numeroDocumentoIdentidadSender);
		//RC: Se realiza cambio en la validacion por contingentes.
		//ES: Se realiza cambio para agregar numero de Declaracion en el mensaje de respuesta.
		//DUA dua = FormatoAServiceImpl.getInstance().getCabDeclaraDAO().selectDuaNumeradabyNumOrden(paramsCabDeclara);
		DUA dua;
		if(ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER.equals(codTransaccion) || ConstantesDataCatalogo.TRANSACCION_NUMERACION_DSEER_DESDE_MDEER.equals(codTransaccion)) {
			paramsCabDeclara.put("tipOperador", ConstantesDataCatalogo.COD_OPERADOR_ESER);
			paramsCabDeclara.put("numDocuOperador", numeroDocumentoIdentidadSender);
			dua = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).selectDuaNumeradabyNumOrdenDinamico(paramsCabDeclara);
			if ( dua != null) {
				return getDUAError("70198",new Object[]{(declaracion.getDua().getCodaduanaorden().toString() + "-" + numOrden.substring(0, 4) + "-" + declaracion.getDua().getCodregimen() + "-" + SunatStringUtils.lpad(dua.getNumdocumento(),6,'0'))});
			}
		}else
			dua = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).selectDuaNumeradabyNumOrden(paramsCabDeclara);
		//LMVR: RN 130  Orden Duplicada
		if ( dua != null){ //Si encuentra registro: "Orden de envio se encuentra numerada"						
			Map<String,Object> paramsMap=new HashMap<String,Object>(); 
			//paramsMap.put("codTransaccion", codTransaccion); 
			paramsMap.put("idEmisor", numeroDocumentoIdentidadSender);
			paramsMap.put("annRefemisor", numOrden.substring(0, 4));
			paramsMap.put("numRefemisor", numOrden.substring(4,10));
			paramsMap.put("codLugarEnvio",  declaracion.getDua().getCodaduanaorden());
			paramsMap.put("codTransaccion",  codTransaccion);
			paramsMap.put("codEstado", "1");
			List<EnvioBean> listEnvio;
			Long numCorredoc = declaracion.getNumeroCorrelativo();
			listEnvio=envioDAO.listByParameterMap(paramsMap);
			if (listEnvio!=null && !listEnvio.isEmpty()){
				Long numEnvio = listEnvio.get(0).getNumeroEnvio();
				return getDUAError("00001",new Object[]{(declaracion.getDua().getCodaduanaorden().toString() + "-" + numOrden.substring(0, 4) + "-" + declaracion.getDua().getCodregimen() + "-" + SunatStringUtils.lpad(dua.getNumdocumento(),6,'0')),numEnvio.toString()});
			}
			return getDUAError("00001",new Object[]{declaracion.getDua().getCodaduanaorden() + "-" + numOrden.substring(0, 4) + "-" + declaracion.getDua().getCodregimen() + "-" + SunatStringUtils.lpad(dua.getNumdocumento(),6,'0')});
		}
		return new HashMap<String,String>();
	}
	/**
	 * Valida el codigo del regimen de la DUA
	 * Valida en funcin del catlogo. Regla 17.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codregimen String, codigo de regimen
	 * @param codTransaccion String, codigo de transaccion
	 * @return Map<String, String>, mapa de errores
	 */
	/*@ServicioAnnot(tipo="V",codServicio=2901,descServicio="validacion del regimen")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codregimen"})
	@OrquestaDespaAnnot(codServInstancia=2901,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")*/
	public Map<String, String> codregimen(String codregimen, String codTransaccion){
		List<Map<String,String>> resultado=new ArrayList<Map<String,String>>();
		boolean siHayData=false;
		//resultado =FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService().getListaElementosGrupo("100");
		resultado =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getListaElementosGrupo("100");
		if (!resultado.isEmpty()){
			for (Map<String,String> tmp : resultado) {
				if (tmp.get("cod_datacat").toString().equals(codregimen)){
					siHayData=true;
				}
			}
		}
		if (siHayData){
			if (!SunatStringUtils.isEmptyTrim(codregimen))
				if (!codTransaccion.substring(0, 2).equals(codregimen.trim()))
					siHayData=false;
		}
		if (siHayData)
			return new HashMap<String,String>();
		else	
			return getDUAError("30284","Error catalogo codregimen");
	}
	/**
	 * Valida el codigo de la aduana
	 * Valida en funcin del catlogo. Regla 00.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param declaracion Declaracion, declaracion a evaluar
	 * @param codTransaccion String, codigo de la transaccion
	 * @return Map<String, String>, mapa de errores
	 */
	/*@ServicioAnnot(tipo="V",codServicio=2902,descServicio="Validacion del codigo de aduana enviado en la orden")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codaduanaorden"})
	@OrquestaDespaAnnot(codServInstancia=2902,numSecEjec=2,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")*/
	public List<Map<String, String>> codaduanaorden(Declaracion declaracion, String codTransaccion){		
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		//boolean contieneFA = true;
		String codaduanaorden = declaracion.getDua().getCodaduanaorden();
		if( SunatStringUtils.isEmpty( codaduanaorden ) )
		{
			String codaduana=declaracion.getNumdeclRef()!=null?declaracion.getNumdeclRef().getCodaduana():null;
			codaduanaorden = codaduana;
		}
		boolean esAduanaValida = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("00", codaduanaorden, SunatDateUtils.getCurrentDate()));
		if(! esAduanaValida )
		{
			listErr.add( getDUAError("00005","Error catalogo codaduanaorden") );
			listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
		}else if(enableSwapperDataSource){
			HotSwappableTargetSource swapperDatasourceLectura = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
			swapperDatasourceLectura.swap(fabricaDeServicios.getService("despaduanero2.ds."+ codaduanaorden ) );
			HotSwappableTargetSource swapperDatasourceEscritura = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.dx.prp1");
			swapperDatasourceEscritura.swap(fabricaDeServicios.getService("despaduanero2.dxdaen."+codaduanaorden ));
		}
		return listErr;
	}
	/**
	 * Para la via de transporte Postal solo se puede numerar con la aduana Postal 244
	 * @param codmodalidad
	 * @param manifiesto
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=2541)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codaduanaorden","manifiesto"})
	@OrquestaDespaAnnot(codServInstancia=2541,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> valModalidadAduana(String codaduanaorden, DatoManifiesto manifiesto){
		String codModTransporte = manifiesto.getCodmodtransp(); 
		if (SunatStringUtils.isEqualTo(codModTransporte, ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL) && 
				!SunatStringUtils.isEqualTo(codaduanaorden, ConstantesDataCatalogo.ADUANA_MANIFIESTO_POSTAL_NACIONAL)){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			return catalogoAyudaService.getError("37053", new String[] {codModTransporte, codaduanaorden});			
		}
		return new HashMap<String,String>();		
	}
	@ServicioAnnot(tipo="V",codServicio=3411)
	@ServInstDetAnnot(tipoRpta={1},nomAtr={"declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3411,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.Valcabdua") 
	public Map<String,String> validarDisposicionTotal(Declaracion declaracionBD){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(declaracionBD.getDua().getCodEstdua().equals("18")){
			return getDUAError("31881",new Object[]{declaracionBD.getDua().getCodEstdua().toString()});//Error cuanto esta dispuesto totalmente 
		}else{//Error cuanto esta dispuesto parcialmente no valida el codigo de estado de la dua. 
			List<Map<String,Object>> lstMercDispuestas = null;
			//String numCorreDocRecti=declaracionBD.getDua().getNumcorredoc().toString(); 
			List<Map<String, Object>> lstResultadoMercancia = new ArrayList<Map<String,Object>>();
			String mensajeBloqueo = "";
			for (DatoSerie datoSerieBDXML : declaracionBD.getDua().getListSeries()) {
				String serieBD= datoSerieBDXML.getNumserie().toString();
				Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();
				String numCorreDoc= declaracionBD.getDua().getNumcorredoc().toString();          
				paramsCabDeclara.put("NUM_CORREDOC",numCorreDoc);
				paramsCabDeclara.put("NUM_SECSERIE",serieBD);
				MercanciaDispuestaDAO mercanciaDispuestaDAO = (MercanciaDispuestaDAO)this.fabricaDeServicios.getService("mercanciaDispuestaDAO");
				lstMercDispuestas= mercanciaDispuestaDAO.findMercanciasDispuestaByParams(paramsCabDeclara);
				int varMerDis=lstMercDispuestas.size();
				for(int i=0; i<=varMerDis-1;i++){
					lstResultadoMercancia.addAll(lstMercDispuestas);
					String item= (String) lstMercDispuestas.get(i).get("NUM_SECITEM").toString();
					String seriemd= (String) lstMercDispuestas.get(i).get("NUM_SECSERIE").toString();
					String docDispo= (String) lstMercDispuestas.get(i).get("NUM_DOCDISPOSICION").toString();
					String fecDocDispo= (String) lstMercDispuestas.get(i).get("FEC_DOCDISPOSICION").toString();
					String fecDoc1= SunatStringUtils.substring(fecDocDispo, 0, 10);
					mensajeBloqueo="�tem ["+item+"] de la serie ["+seriemd+"] cuenta con disposici�n de mercanc�as autorizada mediante ["
							+docDispo+"] de fecha ["+fecDoc1+"]";
					//return getDUAError("31883",new Object[]{item,seriemd,docDispo,fecDoc1});//se debe mostrar como warning 
					Map<String, String> result = catalogoAyudaService.getError("31883", new String[] {item,seriemd,docDispo,fecDoc1});
					return result;
				}	
			}
		}
		return new HashMap<String,String>();
	}
	public Map<String, String> validarDisposicionParcial (Declaracion declaracionBD){
		DisposicionMercanciaService disposicionMercanciaService = (DisposicionMercanciaService) fabricaDeServicios.getService("disposicionMercanciaService");
		Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();
		String numCorreDoc1= declaracionBD.getNumeroCorrelativo().toString();
		//corregir            
		paramsCabDeclara.put("NUM_CORREDOC",numCorreDoc1);
		if(!SunatStringUtils.isEmptyTrim(declaracionBD.getDua().getCodCanal())){
			if(declaracionBD.getDua().getCodEstdua().equals("19")){
				List<Map<String,Object>> lstMercDispuestas = null;
				String numCorreDocRecti=declaracionBD.getDua().getNumcorredoc().toString(); 
				List<Map<String, Object>> lstResultadoMercancia = new ArrayList<Map<String,Object>>();
				String mensajeBloqueo = "";
				for (DatoSerie datoSerieBDXML : declaracionBD.getDua().getListSeries()) {
					String serieBD= datoSerieBDXML.getNumserie().toString();
					String numSerieRecti=serieBD;
					lstMercDispuestas= disposicionMercanciaService.consultarDatosMercanciaDispuestaBySerie(numCorreDocRecti,numSerieRecti);
					int varMerDis=lstMercDispuestas.size();
					for(int i=0; i<=varMerDis-1;i++){
						lstResultadoMercancia.addAll(lstMercDispuestas);
						String item= (String) lstMercDispuestas.get(i).get("NUM_SECITEM").toString();
						String seriemd= (String) lstMercDispuestas.get(i).get("NUM_SECSERIE").toString();
						String docDispo= (String) lstMercDispuestas.get(i).get("NUM_DOCDISPOSICION").toString();
						String fecDocDispo= (String) lstMercDispuestas.get(i).get("FEC_DOCDISPOSICION").toString();
						String fecDoc1= SunatStringUtils.substring(fecDocDispo, 0, 10);
						mensajeBloqueo="�tem ["+item+"] de la serie ["+seriemd+"] cuenta con disposici�n de mercanc�as autorizada mediante ["
								+docDispo+"] de fecha ["+fecDoc1+"]";
						return getDUAError("31883",new Object[]{item,seriemd,docDispo,fecDoc1});//se debe mostrar como warning 
					}	
				}
				//falta terminar el codigo
				return getDUAError("31883",new Object[]{declaracionBD.getDua().getCodEstdua().toString()});
			}
		}
		return getDUAError("31883",new Object[]{declaracionBD.getDua().getCodEstdua().toString()});
	}
	public Map<String, String> validarDisposicionTotalRegul(
			Declaracion declaracionBD) {
		if(!SunatStringUtils.isEmptyTrim(declaracionBD.getDua().getCodCanal())){
			if(declaracionBD.getDua().getCodEstdua().equals(18)){
				return getDUAError("31884",new Object[]{declaracionBD.getNumeroDeclaracion().toString()});
			}
		}
		return new HashMap<String,String>();
	}
	public Map<String, String>  validarDisposicionParcialRegul(Declaracion declaracionBD) {
		List<Map<String, Object>> lstResultadoMercancia = new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> listError=new ArrayList<Map<String,Object>>();
		if(!SunatStringUtils.isEmptyTrim(declaracionBD.getDua().getCodCanal())){
			DisposicionMercanciaService disposicionMercanciaService = (DisposicionMercanciaService) fabricaDeServicios.getService("disposicionMercanciaService");
			if(declaracionBD.getDua().getCodEstdua().equals("19")){
				//El sistema obtiene el tem o serie que se encuentra dispuesto.
				Map<String, Object> mapRegDispMerc = new HashMap<String, Object>();
				Declaracion declaracion = new Declaracion();
				mapRegDispMerc.put("NUM_CORREDOC",declaracion.getNumeroCorrelativo().toString());
				List<Map<String, Object>> lstResultadoMercancia1 = new ArrayList<Map<String,Object>>();
				String mensajeBloqueo ="" ;
				List<Map<String,Object>> lstMercDispuestas1 = null;
				String numCorreDocRegu=declaracionBD.getDua().getNumcorredoc().toString();
				// para verificar y modificar
				for (DatoSerie datoSerieBDXML: declaracionBD.getDua().getListSeries()) {
					String serieBD= datoSerieBDXML.getNumserie().toString();
					String numSerieRegu=serieBD;
					lstMercDispuestas1= disposicionMercanciaService.consultarDatosMercanciaDispuestaBySerie(numCorreDocRegu,numSerieRegu);
					lstResultadoMercancia.addAll(lstMercDispuestas1);
					//return lstResultadoMercancia;
				}
				int varMerDis=lstMercDispuestas1.size();
				for(int i=0;i<=varMerDis-1;i++){
					lstResultadoMercancia1.addAll(lstMercDispuestas1);
					String item= (String) lstMercDispuestas1.get(i).get("NUM_SECITEM").toString();
					String seriemd= (String) lstMercDispuestas1.get(i).get("NUM_SECSERIE").toString();
					String docDispo= (String) lstMercDispuestas1.get(i).get("NUM_DOCDISPOSICION").toString();
					String fecDocDispo= (String) lstMercDispuestas1.get(i).get("FEC_DOCDISPOSICION").toString();
					String fecDoc1= SunatStringUtils.substring(fecDocDispo, 0, 10);
					mensajeBloqueo="�tem ["+item+"] de la serie ["+seriemd+"] cuenta con disposici�n de mercanc�as autorizada mediante ["
							+docDispo+"] de fecha ["+fecDoc1+"]";
					//validar esta parte
					//return getDUAError("31885",mensajeBloqueo);//se debe mostrar como warning 
					return getDUAError("31885",new Object[]{item,seriemd,docDispo,fecDoc1});
				}	
			}  
		}
		return new HashMap<String,String>();
	}
	/**
	 * valida el numero de documento de identidad del agente de aduana
	 * 
	 * @param dua DUA
	 * @param tipoDocumentoIdentidadSender String, Tipo de documento de identidad del agente de aduana
	 * @param numeroDocumentoIdentidadSender String, Numero de documento de identidad del agente de aduana
	 * @param tipoSender String, Tipo de agente
	 * @return Map<String, String>, mapa de errores
	 * Valida en funcin del catlogo.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 */
	/*@ServicioAnnot(tipo="V",codServicio=2003)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"numdocumento"})
	@OrquestaDespaAnnot(codServInstancia=2003,numSecEjec=3,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	 */
	public Map<String, String> numdocumento( DUA dua, String tipoDocumentoIdentidadSender ,String numeroDocumentoIdentidadSender, String tipoSender ){
		String numdocumento = dua.getNumdocumento();
		String codtipooper = dua.getCodtipooper();
		if(!SunatStringUtils.isEmptyTrim(numdocumento))
		{
			if( SunatStringUtils.isEqualTo(tipoDocumentoIdentidadSender, "4") )
			{	
				String codigoTipoSender = ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA;
				//				if( ! FormatoAServiceImpl.getInstance().getCatalogoValidacionService().esOperadorValido(numdocumento, tipoSender) )
				boolean validaOperador= CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numdocumento, codigoTipoSender));
				if(!validaOperador){
					codigoTipoSender = ConstantesDataCatalogo.TIPO_OPERADOR_DESPACHADOR_OFICIAL; 
					validaOperador= CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numdocumento, codigoTipoSender));
				}else if(!validaOperador){
					codigoTipoSender = ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO;
					validaOperador= CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numdocumento, codigoTipoSender));
				}/*else{
					return getDUAError("30429",new Object[]{numdocumento,codigoTipoSender});
				}
				 */
				if(validaOperador){
					List<Map<String, String>> resultOpe= ((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numdocumento
							, codigoTipoSender,  dua.getCodaduanaorden(), SunatDateUtils.getCurrentDate());
					if (!CollectionUtils.isEmpty(resultOpe)){
						if(codigoTipoSender.equals(ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA)){
							return getDUAError("30914",new Object[]{numdocumento,dua.getCodaduanaorden()});
						}else{
							return getDUAError("30408",new Object[]{numdocumento,dua.getCodaduanaorden()});
						}
					}
				}	
			}
			if (!"45".equals(tipoSender)){
				if (!numeroDocumentoIdentidadSender.equals(numdocumento) || !tipoDocumentoIdentidadSender.equals(codtipooper))
					return getDUAError("30363",new Object[]{tipoDocumentoIdentidadSender,numeroDocumentoIdentidadSender,codtipooper,numdocumento});
			}
			return new HashMap<String,String>();
		}
		return getDUAError("00010",new Object[]{numdocumento});
	}	
	/**
	 * Valida el codigo del Tipo de emisor - Tipo de operador<br>
	 * Valida en funcin del catlogo. Regla 27<br>
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipooper String, Codigo del Tipo de emisor - Tipo de operador
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2004)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codtipooper"})
	@OrquestaDespaAnnot(codServInstancia=2004,numSecEjec=4,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codtipooper(String codtipooper){
		boolean validaCatalogo= CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", codtipooper, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30010","C�DIGO DE TIPO DE OPERADOR INVALIDA INVALIDO");
	}
	/**
	 * Valida el codigo de modalidad.
	 * Valida en funcin del catlogo. Regla 306.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param codmodalidad String, Codigo de modalidad.
	 * @return Map<String, String>, mapa de errores
	 */	
	@ServicioAnnot(tipo="V",codServicio=2005)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codmodalidad"})
	@OrquestaDespaAnnot(codServInstancia=2005,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codmodalidad(String codmodalidad){
		//boolean validaCatalogo= CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("306", codmodalidad, SunatDateUtils.getCurrentDate()));
		DataCatalogo data = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo("306", codmodalidad, SunatDateUtils.getCurrentDate());
		if (data != null)
			return new HashMap<String,String>();
		else
			return getDUAError("30320","Error catalogo codmodalidad");
	}
	/**
	 * Para la via de transporte Postal solo se puede numerar con la modalidad de despacho DIFERIDO ex-Excepcional
	 * @param codmodalidad
	 * @param manifiesto
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=2540)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codmodalidad","manifiesto"})
	@OrquestaDespaAnnot(codServInstancia=2540,numSecEjec=5,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> valModalidadManifiesto(String codmodalidad, DatoManifiesto manifiesto){
		
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaReferencia = new Date();		
	    boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
		if(esVigenteRIN05PrimeraParte){
		String codModTransporte = manifiesto.getCodmodtransp(); 
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");//PAS20181U220200049
		if (SunatStringUtils.isEqualTo(codModTransporte, ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL) && 
				!SunatStringUtils.isEqualTo(codmodalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)){
			return catalogoAyudaService.getError("37052", new String[] {codModTransporte, codmodalidad});			
		}
		
		//PAS20181U220200049 - Inicio
		Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", new Date());
		if (!CollectionUtils.isEmpty(MapaValManNum)){
			boolean eerSigad = false;
			boolean eerSda = false;
			if(SunatStringUtils.isEqualTo(codModTransporte,ConstantesDataCatalogo.VIA_TRANSPORTE_EER)){
				eerSigad = true;
			}
			if(SunatStringUtils.isEqualTo(codModTransporte,ConstantesDataCatalogo.VIA_TRANSPORTE_EER_UNECE)){
				eerSda = true;
			}
			if( (eerSigad || eerSda ) && (!ArrayUtils.contains(new String[] {ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO,
			ConstantesDataCatalogo.COD_MODALIDAD_URGENTE,ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL}, codmodalidad))){			
				return catalogoAyudaService.getError("70149", new String[] {codModTransporte, codmodalidad});		
			}
		}
		//PAS20181U220200049 - Fin
		}
		
		return new HashMap<String,String>();		
	}
	/**
	 * Codtipoperacion.
	 * 
	 * @param codtipoperacion String
	 * @param declaracion Declaracion
	 * @return Map<String, String>, mapa de errores
	 * Valida en funcin del cat&aacute;logo. Regla 310.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 */
	@ServicioAnnot(tipo="V",codServicio=2006)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codtipoperacion"})
	@OrquestaDespaAnnot(codServInstancia=2006,numSecEjec=6,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codtipoperacion(String codtipoperacion,Declaracion declaracion){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("310", codtipoperacion) && declaracion.getDua().getCodregimen().equals(SunatStringUtils.substring(codtipoperacion, 0, 2)))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("310", codtipoperacion,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo && declaracion.getDua().getCodregimen().equals(SunatStringUtils.substring(codtipoperacion, 0, 2)))
			return new HashMap<String,String>();
		else
			//return getDUAError("00272","Error catalogo codtipoperacion");
			return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("00272");	
	}
	/**
	 * valida el cdigo del lugar de recepcin de la mercanca.<br>
	 * Valida en funcin del cat&aacute;logo. Regla 311.<br>
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codlugarecepcion String, cdigo del lugar de recepcin de la mercanca
	 * @param variablesIngreso Map<String,Object>
	 * @return Map<String, String>, mapa de errores
	 */
	/*@ServicioAnnot(tipo="V",codServicio=2007)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codlugarecepcion"})
	@OrquestaDespaAnnot(codServInstancia=2007,numSecEjec=7,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	 */
	public Map<String, String> codlugarecepcion(String codlugarecepcion, Map<String,Object> variablesIngreso){
		String codModalidad=(String)variablesIngreso.get("codModalidad");
		Declaracion declaracion = (Declaracion)variablesIngreso.get("declaracion");
		String codRegimen = declaracion.getDua().getCodregimen();
		if (!SunatStringUtils.isEmptyTrim(codlugarecepcion)){
			if (MODALIDAD_ANTICIPADA.equals(codModalidad)){			
				//if (FormatoAServiceImpl.getInstance().isValidCatalogo("UG", codlugarecepcion))
				boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("UG", codlugarecepcion,SunatDateUtils.getCurrentDate()));
				if (validaCatalogo)
					if (codRegimen.equals(ConstantesDataCatalogo.REG_DEPOSITO) && codlugarecepcion.equals(ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION)){
						return getDUAError("30011","C�DIGO DEL LUGAR DE RECEPCI�N INVALIDO");
					}else return new HashMap<String,String>();
				else
					return getDUAError("30011","C�DIGO DEL LUGAR DE RECEPCI�N INVALIDO");
			}else{
				if ("03".equals(codlugarecepcion))
					return new HashMap<String,String>();
				else
					return getDUAError("30011","C�DIGO DEL LUGAR DE RECEPCI�N INVALIDO");
			}
		}
		return new HashMap<String,String>();
	}
	/**
	 * Valida el nmero del Ruc del lugar del punto de llegada.<br>
	 * Se valida que el ruc tenga una longitud de 11 caracteres y que exista en la tabla Ddp de la base de datos recauda.<br>
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param numruclugarecep String, nmero del Ruc del lugar del punto de llegada
	 * @param codlugarecepcion String, Cdigo del lugar de recepcin de la mercanca
	 * @return Map<String, String>, mapa de errores
	 */
	@SuppressWarnings("unchecked")
	@ServicioAnnot(tipo="V",codServicio=2008)
	@ServInstDetAnnot(tipoRpta={0,0},nomAtr={"numruclugarecep","codlugarecepcion"})
	@OrquestaDespaAnnot(codServInstancia=2008,numSecEjec=8,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> numruclugarecep(String numruclugarecep,String codlugarecepcion){
		DdpDAOService ddpDAOService = fabricaDeServicios.getService("Ayuda.ddpService");
		// Esta validacion (regla )solo aplica cuando el c�digo de punto de llegada  es  = �03�

		if(ConstantesDataCatalogo.DESCARGA_AL_PUNTO_LLEGADA.equals(codlugarecepcion)){
			if (!SunatStringUtils.isEmptyTrim(numruclugarecep)){
				if (numruclugarecep.trim().length()==11){
					//							Map mapDdp=(HashMap)FormatoAServiceImpl.getInstance().getDdpDAO().findByPK(numruclugarecep);
					Map mapDdp=(HashMap)ddpDAOService.findByPK(numruclugarecep);
					if (mapDdp==null)
						return getDUAError("30012","NUMERO DE RUC DEL LUGAR DE RECEPCION INVALIDO");
					//							boolean esOperador = 
					//FormatoAServiceImpl.getInstance().getCatalogoValidacionService().esOperadorValido(numruclugarecep, "31");
					boolean esOperador = CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numruclugarecep, "31"));
					if(! esOperador )
						//esOperador = FormatoAServiceImpl.getInstance().getCatalogoValidacionService().esOperadorValido(numruclugarecep, "32");
						esOperador =CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numruclugarecep, "32"));		
					if( ! esOperador )
						return getDUAError("30361","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
				}else{ 
					return getDUAError("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
				}
			}else{
				return getDUAError("30012","NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
			}
		}
		if (ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION.equals(codlugarecepcion)) {
			if (numruclugarecep.trim().length() == 11) {
				//				Map mapDdp = (HashMap) FormatoAServiceImpl.getInstance().getDdpDAO().findByPK(numruclugarecep);
				Map mapDdp = (HashMap) ddpDAOService.findByPK(numruclugarecep);
				if (mapDdp == null)
					return getDUAError("30012", "NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
			} else {
				return getDUAError("30012", "LONGITUD DEL NUMERO DE RUC DEL LUGAR DE RECEPCI�N INVALIDO");
			}
		}
		return new HashMap<String,String>();
	}
	/**
	 * Valida el cdigo del anexo del lugar del punto de llegada.
	 * 
	 * @param codanexo String, cdigo del anexo del lugar del punto de llegada
	 * @return el mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2009)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codanexo"})
	@OrquestaDespaAnnot(codServInstancia=2009,numSecEjec=9,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codanexo(String codanexo, String codlugarecepcion){
		//		return !SunatStringUtils.isEmptyTrim(codanexo)?new HashMap<String,String>():getDUAError("30013", "CDIGO DEL LOCAL ANEXO DEL LUGAR DE RECEPCIN INVALIDO");//getDUAError("111","Error codanexo");
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
	    boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(new Date()):false;
	    Date fechaHoy = SunatDateUtils.getCurrentDate();
	    boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false; //csantillan PAS20181U220200054
	    
	    if (esVigenteRIN05||esVigenteRIN31){ //csantillan PAS20181U220200054 se agrega condicion de vingencia rin31
				if(!codlugarecepcion.equals("14")){
				if (!SunatStringUtils.isEmptyTrim(codanexo) && codanexo.length()<=4) //antes estaba por 6
				{  return new HashMap<String,String>();
				}else{
					if(SunatStringUtils.isEmptyTrim(codanexo)){
						 return getDUAError("37066","");
					}else{
				   return getDUAError("30013","");
				   }
				}
				}else{
					return new HashMap<String,String>();
				}
	    }else{
	    	if (!SunatStringUtils.isEmptyTrim(codanexo) && codanexo.length()<=4) //antes estaba por 6
			    return new HashMap<String,String>();
			return getDUAError("30013","");
			
	    }
	}
	/**
	 * Valida el Ruc del deposito aduanero.<br>
	 * Se valida que el ruc tenga una longitud de 11 caracteres y que exista en la tabla Ddp de la base de datos recauda.<br>
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param numrucdeposito String, Ruc del deposito aduanero
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2010)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"numrucdeposito"})
	@OrquestaDespaAnnot(codServInstancia=2010,numSecEjec=10,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> numrucdeposito(String numrucdeposito){
		if (!SunatStringUtils.isEmptyTrim(numrucdeposito)){
			if (numrucdeposito.trim().length()==11){
				//if( ! FormatoAServiceImpl.getInstance().getCatalogoValidacionService().esOperadorValido(numrucdeposito, "32") )
				boolean validaOperador=CollectionUtils.isEmpty(((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(numrucdeposito, "32"));
				if(!validaOperador)		
					getDUAError("00027","Error numrucdeposito. Envio:"+numrucdeposito);
			}else{
				return getDUAError("00027", "Error numrucdeposito longitud menor 11");
				//return getDUAError("111","Error numrucdeposito longitud menor 11");
			}
		}else{
			getDUAError("00027","Error numrucdeposito. Envio:"+numrucdeposito);
		}
		return new HashMap<String,String>();
	}
	/**
	 * Valida el Monto total de valor FOB en dolares.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtotfobclvta BigDecimal, Monto total de valor FOB en dolares
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2011)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"mtotfobclvta"})
	@OrquestaDespaAnnot(codServInstancia=2011,numSecEjec=11,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> mtotfobclvta(BigDecimal mtotfobclvta){
		if (mtotfobclvta!=null)
			return mtotfobclvta.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00033","TFOB_CLTVTA - VALOR FOB INCORRECTO "+mtotfobclvta);
			else
				return getDUAError("00033","TFOB_CLTVTA - VALOR FOB INCORRECTO "+mtotfobclvta);
	}
	/**
	 * Valida el Monto total de Flete en dolares.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param mtotflecomex BigDecimal, Monto total de Flete en dolares
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2012)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"mtotflecomex"})
	@OrquestaDespaAnnot(codServInstancia=2012,numSecEjec=12,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> mtotflecomex(BigDecimal mtotflecomex){
		if (mtotflecomex!=null)
			return mtotflecomex.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00034","TFLE_COMEX - "+mtotflecomex);
			else
				return getDUAError("00034","TFLE_COMEX - null");
	}
	/**
	 * Valida Monto total de Seguro en dolares<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param mtotsegotros BigDecimal, Monto total de Seguro en dolares
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2013)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"mtotsegotros"})
	@OrquestaDespaAnnot(codServInstancia=2013,numSecEjec=13,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> mtotsegotros(BigDecimal mtotsegotros){
		if (mtotsegotros!=null)
			return mtotsegotros.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00035","TSEG_OTROS - "+mtotsegotros);
			else
				return getDUAError("00035","TSEG_OTROS - "+mtotsegotros);
	}
	/**
	 * Valida Monto Total de Ajustes.<br>
	 * Se valida que el parametro sea mayor o igual a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param mtotajustes BigDecimal, Monto Total de Ajustes
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2014)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"mtotajustes"})
	@OrquestaDespaAnnot(codServInstancia=2014,numSecEjec=14,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> mtotajustes(BigDecimal mtotajustes){
		if (mtotajustes!=null)
			return mtotajustes.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("30014","MONTO DE AJUSTE INVALIDO "+mtotajustes);
			else
				return new HashMap<String,String>();//getDUAError("30014","MONTO DE AJUSTE INVALIDO "+mtotajustes);
	}
	/**
	 * Valida el Monto de Valor en Aduanas.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtovaladuana BigDecimal, Monto de Valor en Aduanas
	 * @param mtotajustes BigDecimal, Monto Total de Ajustes
	 * @param mtotfobclvta BigDecimal, Monto total de valor FOB en dolares 
	 * @param mtotsegotros BigDecimal, Monto total de Seguro en dolares
	 * @param mtotflecomex BigDecimal, Monto total de Flete en dolares
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2015)
	@ServInstDetAnnot(tipoRpta={0,0,0,0,0},nomAtr={"mtovaladuana","mtotajustes","mtotfobclvta","mtotsegotros","mtotflecomex"})
	@OrquestaDespaAnnot(codServInstancia=2015,numSecEjec=15,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> mtovaladuana(BigDecimal mtovaladuana, BigDecimal mtotajustes, BigDecimal mtotfobclvta,BigDecimal mtotsegotros, BigDecimal mtotflecomex){
		if (mtovaladuana!=null){
			mtotajustes=mtotajustes==null?BigDecimal.ZERO:mtotajustes;
			mtotfobclvta=mtotfobclvta==null?BigDecimal.ZERO:mtotfobclvta;
			mtotsegotros=mtotsegotros==null?BigDecimal.ZERO:mtotsegotros;
			mtotflecomex=mtotflecomex==null?BigDecimal.ZERO:mtotflecomex;
			if (SunatNumberUtils.isLessOrEqualsThanZero(mtovaladuana))
				return getDUAError("30050","VAL_ADUANA menor a cero");
			BigDecimal dif=SunatNumberUtils.diference(mtovaladuana,SunatNumberUtils.sum(mtotajustes, SunatNumberUtils.sum(mtotsegotros,SunatNumberUtils.sum(mtotfobclvta, mtotflecomex))));
			//			BigDecimal dif=mtovaladuana.subtract(mtotajustes.add(mtotfobclvta.add(mtotsegotros.add(mtotflecomex))));
			if (dif!=null && Math.abs(dif.doubleValue())>0.02)
				return getDUAError("30050","VAL_ADUANA - "+ mtovaladuana+ "-CALCULADO=("+ mtotajustes+mtotsegotros+ mtotflecomex+ mtotfobclvta+")");
			return new HashMap<String,String>();
		}else
			return new HashMap<String,String>();
	}
	/**
	 * Valida la cantidad total peso Bruto<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param cnttpesobruto BigDecimal, cantidad total peso Bruto
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2016)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"cnttpesobruto"})
	@OrquestaDespaAnnot(codServInstancia=2016,numSecEjec=16,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> cnttpesobruto(BigDecimal cnttpesobruto){
		//SPTD_ADUAHDR1 66-67
		if (cnttpesobruto!=null){
			if (cnttpesobruto.scale()>3)
				return getDUAError("00029","TPESO_BRUT - "+cnttpesobruto);
			if (cnttpesobruto.precision()>15)
				return getDUAError("00029","TPESO_BRUT - "+cnttpesobruto);
			return cnttpesobruto.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00029","TPESO_BRUT - "+cnttpesobruto);
		}else
			return getDUAError("00029","TPESO_BRUT - "+cnttpesobruto);
	}
	/**
	 * Valida la cantidad total peso neto.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param cnttpesoneto BigDecimal, cantidad total peso neto
	 * @param cnttpesobruto BigDecimal, cantidad total peso bruto
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2017)
	@ServInstDetAnnot(tipoRpta={0,0},nomAtr={"cnttpesoneto","cnttpesobruto"})
	@OrquestaDespaAnnot(codServInstancia=2017,numSecEjec=17,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> cnttpesoneto(BigDecimal cnttpesoneto, BigDecimal cnttpesobruto){
		//SPTD_ADUAHDR1 64-65
		if (cnttpesoneto!=null){
			if (cnttpesoneto.compareTo(BigDecimal.ZERO)<=0)
				return getDUAError("00028","TPESO_NETO - "+cnttpesobruto);
			if (cnttpesoneto.scale()>3)
				return getDUAError("00028","TPESO_NETO - "+cnttpesobruto);
			if (cnttpesoneto.precision()>15)
				return getDUAError("00028","TPESO_NETO - "+cnttpesobruto);
			if (this.cnttpesobruto(cnttpesobruto)==null){
				if (cnttpesoneto.compareTo(cnttpesobruto)>0)
					return getDUAError("00028","TPESO_NETO, TPESO_BRUT - PESO NETO NO DEBE SER MAYOR A PESO BRUTO "+cnttpesoneto+","+cnttpesobruto);
			}
			return new HashMap<String,String>();
		}else
			return getDUAError("00028","TPESO_NETO - "+cnttpesobruto);
	}
	/**
	 * Valida la cantida de bultos.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param cnttcantbulto BigDecimal, cantidad de bultos
	 * @return Map<String, String>, mapa de errores
	 */	
	@ServicioAnnot(tipo="V",codServicio=2018)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"cnttcantbulto"})
	@OrquestaDespaAnnot(codServInstancia=2018,numSecEjec=18,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> cnttcantbulto(BigDecimal cnttcantbulto){
		if (cnttcantbulto!=null)
			//jenciso, RIN05 debe permitir numerar con bulto 0 
			//return cnttcantbulto.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00030","TCANT_BULT - "+cnttcantbulto);
			return new HashMap<String,String>();
		else
			return getDUAError("00030","TCANT_BULT - "+cnttcantbulto);
	}
	/**
	 * Valida la cantidad total de unidades fisicas.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param cnttqunifis BigDecimal, cantidad total de unidades fisicas
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2019)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"cnttqunifis"})
	@OrquestaDespaAnnot(codServInstancia=2019,numSecEjec=19,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> cnttqunifis(BigDecimal cnttqunifis){
		//SPTD_ADUAHDR1 68-69
		if (cnttqunifis!=null)
			return cnttqunifis.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00031","TQUNIFIS - "+cnttqunifis);
			else
				return getDUAError("00031","TQUNIFIS - "+cnttqunifis);
	}
	/**
	 * Valida la cantidad de series.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 *  
	 * @param cntnumseries Integer, cantidad de series
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2020)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"cntnumseries"})
	@OrquestaDespaAnnot(codServInstancia=2020,numSecEjec=20,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> cntnumseries(Integer cntnumseries){
		//SPTD_ADUAHDR1 70-71
		if (cntnumseries!=null)
			return cntnumseries.intValue()>0?new HashMap<String,String>():getDUAError("0039","CANT_SERIE - "+cntnumseries);
			else
				return getDUAError("0039","CANT_SERIE - "+cntnumseries);
	}
	/**
	 * Valida la Cantidad Total de unidades comerciales.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param cnttqunicom BigDecimal, Cantidad Total de unidades comerciales
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2021)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"cnttqunicom"})
	@OrquestaDespaAnnot(codServInstancia=2021,numSecEjec=21,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> cnttqunicom(BigDecimal cnttqunicom){
		if (cnttqunicom!=null)
			return cnttqunicom.compareTo(BigDecimal.ZERO)>0?new HashMap<String,String>():getDUAError("00038","TQUNICOM - "+cnttqunicom);
			else
				return getDUAError("00038","TQUNICOM - "+cnttqunicom);
	}
	/**
	 * Valida el Monto Autoliquidado
	 * Se valida que el parametro sea mayor o igual a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtototautoliq BigDecimal, Monto Autoliquidado
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2022)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"mtototautoliq"})
	@OrquestaDespaAnnot(codServInstancia=2022,numSecEjec=22,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> mtototautoliq(BigDecimal mtototautoliq){
		//SPTD_ADUAHDR1 72-73
		if (mtototautoliq!=null)
			return mtototautoliq.compareTo(BigDecimal.ZERO)>=0?new HashMap<String,String>():getDUAError("00040","MAUTOLIQUI - "+mtototautoliq);
			else
				return getDUAError("00040","MAUTOLIQUI - "+mtototautoliq);
	}
	/**
	 * Valida el Cdigo de endose en importacin.<br>
	 * Valida que el par&aacute;metro tenga valor.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codpropiedad String, Cdigo de endose en importacin
	 * @return Map<String, String>, mapa de errores
	 */	
	@ServicioAnnot(tipo="V",codServicio=2023)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codpropiedad"})
	@OrquestaDespaAnnot(codServInstancia=2023,numSecEjec=23,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codpropiedad(String codpropiedad){
		if (!SunatStringUtils.isEmptyTrim(codpropiedad)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("63", codpropiedad))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("63", codpropiedad, SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)	
				return new HashMap<String,String>();
			else
				return getDUAError("30015","C�DIGO DE PROPIEDAD INVALIDO");
		}else
			return getDUAError("30015","C�DIGO DE PROPIEDAD INVALIDO");
	}
	/**
	 * Valida el cdigo tipo de plazo solicitado del regimen, das  meses.<br>
	 * Valida en funcin del cat&aacute;logo. Regla 312.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipoplazo String, Cdigo tipo de plazo solicitado del regimen, das  meses
	 * @return Map<String, String>, mapa de errores
	 */	
	@ServicioAnnot(tipo="V",codServicio=2024)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codtipoplazo"})
	@OrquestaDespaAnnot(codServInstancia=2024,numSecEjec=24,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codtipoplazo(String codtipoplazo){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("312", codtipoplazo))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("312", codtipoplazo, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00301","Error catalogo codtipoplazo");
	}
	/**
	 * Valida el Nmero de das o meses solicitado.<br>
	 * Se valida que el parametro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param numplazosol Integer, Nmero de das o meses solicitado
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2025)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"numplazosol"})
	@OrquestaDespaAnnot(codServInstancia=2025,numSecEjec=25,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> numplazosol(Integer numplazosol){
		if (numplazosol!=null)
			return numplazosol.intValue()>0?new HashMap<String,String>():getDUAError("00300","Error numplazosol. Envio:"+numplazosol);//getDUAError("","Error numplazosol. Envio:"+numplazosol);
			else
				return getDUAError("00300","Error numplazosol null");
		//return getDUAError("","Error numplazosol null");
	}
	/**
	 * Valida el Tipo de tratamiento de la mercancia.
	 * Valida en funcin del cat&aacute;logo. Regla 313.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipotratamiento String, Tipo de tratamiento de la mercancia
	 * @return Map<String, String>, mapa de errores
	 */	
	@ServicioAnnot(tipo="V",codServicio=2026)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codtipotratamiento"})
	@OrquestaDespaAnnot(codServInstancia=2026,numSecEjec=26,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codtipotratamiento(String codtipotratamiento){
		//PAS20112A600000721 se cambia catalogo de 14 a 313 
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("313", codtipotratamiento))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("313", codtipotratamiento,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00008","Error catalogo codtipotratamiento");
		//return getDUAError("","Error catalogo codtipotratamiento");
	}
	/**
	 * Valida el Cdigo de feria para admisin temporal en el mismo estado.<br>
	 * Valida en funcin del cat&aacute;logo. Regla 314.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param codferia String, Cdigo de feria para admisin temporal en el mismo estado
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2027)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codferia"})
	@OrquestaDespaAnnot(codServInstancia=2027,numSecEjec=27,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")	
	public Map<String, String> codferia(String codferia){
		if(SunatStringUtils.isEmptyTrim(codferia))
			return new HashMap<String,String>();
		else{ 
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("314", codferia))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("314", codferia,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				return getDUAError("00501","Error catalogo codferia");
		}
	}
	/**
	 * 
	 * Valida el cdigo del tipo de empaque exterior (Trnsito).<br>
	 * Valida en funcin del cat&aacute;logo. Regla 314.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 *  
	 * @deprecated Validar el metodo, no realiza validacion alguna. 
	 * @param codtipempaque String
	 * @return Map<String, String>, mapa de errores
	 */	
	@ServicioAnnot(tipo="V",codServicio=2028)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codtipempaque"})
	@OrquestaDespaAnnot(codServInstancia=2028,numSecEjec=28,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codtipempaque(String codtipempaque){
		//TODO falta codigo catalogo
		/*CatalogoHelperImpl catalogo=FormatoAServiceImpl.getInstance().getValidadorCatalogo();
		return catalogo.isValid(codtipempaque)?new HashMap<String,String>():catalogo.getDUAError("");*/
		return new HashMap<String,String>();
	}
	/*@ServicioAnnot(tipo="V",codServicio=2029)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codprodurgente"})
	@OrquestaDespaAnnot(codServInstancia=2029,numSecEjec=29,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	 */
	/**
	 * Valida el cdigo del producto urgente(tabla N1 y N2).
	 * 
	 * El cdigo de producto urgente solo aplica para la modalidad urgente, en las
	 * otras modalidades debe rechazar, cuando es un urgente sin socorro se valida
	 * contra el catlogo N1 y si es socorro contra el catlogo N2	 *
	 * *.
	 * 
	 * @param dua DUA
	 * @return Map<String, String>, mapa de errores
	 */
	public Map<String, String> codprodurgente(DUA dua){
		// modalidad urgente
		if(SunatStringUtils.isEqualTo(dua.getCodmodalidad(), "01")){
			if( SunatStringUtils.isEmpty( dua.getCodprodurgente() ) ){
				// error por que es obligatorio
				//CODIGO DE PRODUCTO URGENTE ES MANDATORIO PARA LA MODALIDAD URGENTE
				return getDUAError("30392","CODIGO DE PRODUCTO URGENTE ES MANDATORIO PARA LA MODALIDAD URGENTE");
			}
			else{
				if( "S".equals(dua.getIndSocorro())){
					//if(! FormatoAServiceImpl.getInstance().isValidCatalogo("N2",  dua.getCodprodurgente() ) )
					boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("N2", dua.getCodprodurgente(),SunatDateUtils.getCurrentDate()));
					if (!validaCatalogo)
						// CODIGO DE PRODUCTO URGENTE {0} INVALIDO PARA ENVIO DE SOCORRO
						return getDUAError("30393",new Object[]{dua.getCodprodurgente()});
				}
				else{
					//if(! FormatoAServiceImpl.getInstance().isValidCatalogo("N1",  dua.getCodprodurgente() )){
					boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("N1", dua.getCodprodurgente(),SunatDateUtils.getCurrentDate()));
					if (!validaCatalogo){
						//CODIGO DE PRODUCTO URGENTE {0} INVALIDO
						return getDUAError("30394",new Object[]{dua.getCodprodurgente()});
					}
				}
			}
		}
		else if(! SunatStringUtils.isEmpty( dua.getCodprodurgente() ) ){
			// error porque no debe ser enviado si no es urgente
			return getDUAError("30352",new Object[]{"'COD PROD URGENTE'"});
		}
		return new HashMap<String, String>();
	}
	/**
	 * Fecfinprovsional.
	 * @deprecated
	 * @param fecfinprovsional Date
	 * @return el mapa de errrores
	 */
	@ServicioAnnot(tipo="V",codServicio=2030)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"fecfinprovsional"})
	@OrquestaDespaAnnot(codServInstancia=2030,numSecEjec=30,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> fecfinprovsional(Date fecfinprovsional){
		//		return fecfinprovsional!=null?new HashMap<String,String>():getDUAError("05793", "");
		return new HashMap<String,String>();
	}
	/**
	 * Valida la Fecha de vencimiento de acogimiento al regimen
	 * 
	 * @param fecfinacoregimen Date, Fecha de vencimiento de acogimiento al regimen
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2030)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"fecfinacoregimen"})
	@OrquestaDespaAnnot(codServInstancia=2030,numSecEjec=30,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> fecfinacoregimen(Date fecfinacoregimen){
		return fecfinacoregimen!=null?new HashMap<String,String>():getDUAError("30318", "");		
	}
	/**
	 * Valida la Descripcin de la finalidad de la mercanca para el rgimen admisin temporal para reexportacin en el mismo estado
	 * Se valida que si el parametro tiene un valor, este debe tener una longitud mayor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param desfinalidad String, Descripcin de la finalidad de la mercanca para el rgimen admisin temporal para reexportacin en el mismo estado
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2031)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"desfinalidad"})
	@OrquestaDespaAnnot(codServInstancia=2031,numSecEjec=31,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> desfinalidad(String desfinalidad){
		if (!SunatStringUtils.isEmptyTrim(desfinalidad))
			return desfinalidad.trim().length()>5?new HashMap<String,String>():getDUAError("30016","VALOR DE LA DESCRIPCI�N DE LA FINALIDAD DEL PRODUCTO INVALIDO");
			else
				return new HashMap<String,String>();
	}
	/**
	 * Valida el cdigo del local anexo del establecimiento donde estar la mercanca. 
	 * 
	 * @param codlocalanexo String, Cdigo del local anexo del establecimiento donde estar la mercanca 
	 * @return el mapa de errrores
	 */
	@ServicioAnnot(tipo="V",codServicio=2032)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codlocalanexo"})
	@OrquestaDespaAnnot(codServInstancia=2032,numSecEjec=32,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codlocalanexo(String codlocalanexo){
		if (!SunatStringUtils.isEmptyTrim(codlocalanexo)){
			if (codlocalanexo.length()<=6)
				return new HashMap<String,String>();
			return getDUAError("30017","");
		}
		return new HashMap<String,String>();
	}
	/**
	 * Valida el codoperacion.
	 * 
	 * @param codoperacion String
	 * @return Map, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2033)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codoperacion"})
	@OrquestaDespaAnnot(codServInstancia=2033,numSecEjec=33,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codoperacion(String codoperacion){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("322", codoperacion))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("322", codoperacion,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30285","Error catalogo codoperacion");		
	}
	/**
	 * Valida el codopaduana.
	 * 
	 * @param codopaduana String
	 * @return Map<String, String>, mapa de errores
	 * Valida que el par&aacute;metro tenga valor.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 */	
	@ServicioAnnot(tipo="V",codServicio=2034)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codopaduana"})
	@OrquestaDespaAnnot(codServInstancia=2034,numSecEjec=34,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codopaduana(String codopaduana){
		if (!SunatStringUtils.isEmptyTrim(codopaduana)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("00", codopaduana))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("00", codopaduana,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				return getDUAError("zz","Error catalogo codopaduana");	
		}else{
			return getDUAError("zz","Error codopaduana");
		}
	}
	/**
	 * Valida el codoppuerto.
	 * 
	 * @param codoppuerto String
	 * @return el mapa de errrores
	 */
	@ServicioAnnot(tipo="V",codServicio=2035)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codoppuerto"})
	@OrquestaDespaAnnot(codServInstancia=2035,numSecEjec=35,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codoppuerto(String codoppuerto){
		return new HashMap<String,String>();
	}
	/**
	 * Valida el codigo Va de transporte de salida, usado en el reg. Trnsito.
	 * 
	 * @param codviatrades String, codigo Va de transporte de salida, usado en el reg. Trnsito.
	 * @return el map
	 */
	@ServicioAnnot(tipo="V",codServicio=2036)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codviatrades"})
	@OrquestaDespaAnnot(codServInstancia=2036,numSecEjec=36,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codviatrades(String codviatrades){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("10", codviatrades))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("10", codviatrades,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("zz","Error catalogo codviatrades");	
	}
	/**
	 * Valida el Cdigo de modalidad de pago de mercancia importada.<br>
	 * Valida que el par&aacute;metro tenga valor.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param codmodpago String
	 * @return Map<String, String>, mapa de errores
	 */	
	@ServicioAnnot(tipo="V",codServicio=2037)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codmodpago"})
	@OrquestaDespaAnnot(codServInstancia=2037,numSecEjec=37,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codmodpago(String codmodpago){
		if (!SunatStringUtils.isEmptyTrim(codmodpago)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("11", codmodpago))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("11", codmodpago,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				return getDUAError("30286","Error catalogo codmodpago");			
		}else{
			return getDUAError("30286","Error codmodpago");
		}
	}
	
	@ServicioAnnot(tipo = "V", codServicio = 3501, descServicio = "Valida el codigo de la modalidad de pago, cuando se declare como otros")
	@Override
	public Map<String, String> codModPagoOtros(String codModPago, String desModoPago){
		Map<String, String> result = new HashMap<String, String>();
		if (!SunatStringUtils.isEmptyTrim(codModPago) && codModPago.equals("7") && SunatStringUtils.isEmptyTrim(desModoPago)){
			result =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("37098");
		}
		return result;
	}
	/**
	 * Valida el cdigo de entidad que otorga la facilidad de pago.<br>
	 * Valida que el par&aacute;metro tenga valor.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param codentipago String
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2038)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codentipago"})
	@OrquestaDespaAnnot(codServInstancia=2038,numSecEjec=38,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codentipago(String codentipago){
		if (!SunatStringUtils.isEmptyTrim(codentipago)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("15", codentipago))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("15", codentipago,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				return getDUAError("30287","Error catalogo codentipago");			
		}else{
			return new HashMap<String,String>();
		}
	}
	/**
	 * Valida el plazo de la carta de credito.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param numplazcredito Integer, Plazo de la carta de credito
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2039)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"numplazcredito"})
	@OrquestaDespaAnnot(codServInstancia=2039,numSecEjec=39,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> numplazcredito(Integer numplazcredito){
		if (numplazcredito!=null)
			return numplazcredito.intValue()<0?getDUAError("30288","Error numplazcredito"):new HashMap<String,String>();
			else
				return new HashMap<String,String>();
	}
	/**
	 * Valida la fecha de carta de credito.<br>
	 * Valida que el par&aacute;metro sea mayor a 1990.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param feccarcr Date, Fecha de carta de credito
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2040)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"feccarcr"})
	@OrquestaDespaAnnot(codServInstancia=2040,numSecEjec=40,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> feccarcr(Date feccarcr){
		if (feccarcr!=null)
			return  feccarcr!=null?new HashMap<String,String>():getDUAError("30289","Error feccarcr");
			else
				return new HashMap<String,String>();
	}
	/**
	 * Valida el cdigo del banco para el pago electrnico.
	 * 
	 * @param codbcopagoelec String, Cdigo del banco para el pago electrnico
	 * @return el mapa de errrores
	 */
	@ServicioAnnot(tipo="V",codServicio=2041)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codbcopagoelec"})
	@OrquestaDespaAnnot(codServInstancia=2041,numSecEjec=41,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codbcopagoelec(String codbcopagoelec){
		/*if (FormatoAServiceImpl.getInstance().isValidCatalogo("15", codbcopagoelec))
			return new HashMap<String,String>();
		else
			return getDUAError("30290","Error catalogo codbcopagoelec");*/
		//		if ( !SunatStringUtils.isEmpty(codbcopagoelec)  && 
		//		!FormatoAServiceImpl.getInstance().isValidCatalogo("15", codbcopagoelec))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("15", codbcopagoelec,SunatDateUtils.getCurrentDate()));
		if ( !SunatStringUtils.isEmpty(codbcopagoelec)  && !validaCatalogo)
			return getDUAError("30290","Error catalogo codbcopagoelec");
		else
			return new HashMap<String,String>();		
	}
	/**
	 * Valida el Nmero de cuenta para el pago electrnico.
	 * Valida que el par&aacute;metro sea una cadena de d&iacute;gitos y que exista el numero de cuenta.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numctapagoelec String
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2042)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"numctapagoelec"})
	@OrquestaDespaAnnot(codServInstancia=2042,numSecEjec=42,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> numctapagoelec(String numctapagoelec){
		if ( !SunatStringUtils.isEmpty(numctapagoelec)  && !SunatStringUtils.isNumeric(numctapagoelec))
			return getDUAError("30291","Error numctapagoelec");
		//TODO Validar existencia de cuenta
		return new HashMap<String,String>();
	}
	/**
	 * Valida el Numero de Cta Cte  de acogimiento a la garantia  art. 160.<br>
	 * Valida que el par&aacute;metro sea una cadena de 18 d&iacute;gitos.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param codgarantia String, Numero de Cta Cte  de acogimiento a la garantia  art. 160
	 * @return Map<String, String>, mapa de errores
	 */
	@ServicioAnnot(tipo="V",codServicio=2043)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codgarantia"})
	@OrquestaDespaAnnot(codServInstancia=2043,numSecEjec=43,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> codgarantia(String codgarantia){
		if (!SunatStringUtils.isEmptyTrim(codgarantia))
			return (SunatStringUtils.isNumeric(codgarantia) && codgarantia.trim().length()==18)?new HashMap<String,String>():getDUAError("30292","Error codgarantia");
			return new HashMap<String,String>();
	}
	/*@ServicioAnnot(tipo="V",codServicio=2033)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declarante"})
	@OrquestaDespaAnnot(codServInstancia=2033,numSecEjec=33,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	 */
	/**
	 * Valida los datos del declarante
	 * 
	 * @param declarante Participante, Datos del declarante
	 * @param codTransaccion String
	 * @return el list
	 */
	public List<Map<String,String>> declarante(Participante declarante, String codTransaccion){
		ValParticipante valParticipante = fabricaDeServicios.getService("ValParticipante");
		String modalidad=codTransaccion.substring(2,4);
		String regimen=codTransaccion.substring(0, 2);
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		if(declarante!=null){
			if (!SunatStringUtils.include(regimen, new String[]{"10","20","21"}) || !"02".equals(modalidad)){
				//			ValParticipante val=new ValParticipante();
				//listError.add(valParticipante.tipoDocumentoIdentidad(declarante.getTipoDocumentoIdentidad(),"30221"));
				listError.add(valParticipante.tipoDocumentoIdentidad(declarante.getTipoDocumentoIdentidad(),"00009"));
				//listError.add(valParticipante.numeroDocumentoIdentidad(declarante.getNumeroDocumentoIdentidad(),"00009",declarante.getTipoDocumentoIdentidad()));
				if (SunatStringUtils.isEmptyTrim(declarante.getTipoParticipante().getCodDatacat()) || !"45".equals(declarante.getTipoParticipante().getCodDatacat())){
					listError.add(getDUAError("30116",""));
				}
			}
			//		listError.add(val.ciudad(declarante.getCiudad()));
			//		listError.add(val.direccion(declarante.getDireccion()));
			//		listError.add(val.email(declarante.getEmail()));
			//		listError.add(val.fax(declarante.getFax()));
			//		listError.add(val.nombreRazonSocial(declarante.getNombreRazonSocial()));
			//		listError.add(val.paginaWeb(declarante.getPaginaWeb()));
			//		listError.add(val.pais(declarante.getPais()));
			//		listError.add(val.telefono(declarante.getTelefono()));
		}
		return listError;
	}
	/*@ServicioAnnot(tipo="V",codServicio=2034)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"rucAnexoUbicacion"})
	@OrquestaDespaAnnot(codServInstancia=2034,numSecEjec=34,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	 */
	/**
	 * Valida los Datos de ubicacin de la mercanca.<br>
	 * Valida el segmento ruc anexo , el cual es obligatorio para el regimen 20 ,on la Excepcion si se
	 * envia los codigos 2002  2008 en el campo	codtipoperacion         ,
	 * valida que el tipo de documento sea Ruc y que este Ruc este asociado a el anexo
	 * Valida que el participante sea 94 EMPRESA DONDE PERMANECE LA MERCANCIA 
	 * 
	 * @param rucAnexoUbicacion Participante, Datos de ubicacin de la mercanca
	 * @param codTransaccion String
	 * @param codtipoperacion String
	 * @param codlocalanexo String
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,String>> rucAnexoUbicacion(Participante rucAnexoUbicacion, String codTransaccion
			,String codtipoperacion,String codlocalanexo){
		SprDAOService sprDAOService = fabricaDeServicios.getService("Ayuda.sprService");
		ValParticipante valParticipante = fabricaDeServicios.getService("ValParticipante");
		
		String modalidad=codTransaccion.substring(2,4);
		String regimen=codTransaccion.substring(0, 2);
		/*
		1.- Verificar que estos campos solo sehan exigidos para las transacciones 2001
		2003 2004 con la Excepcion si  si envia los codigos 2002  2008 en el campo
		codtipoperacion           
		2 . el campo codtipdocparticipante solo puede ser 4 Ruc 
		en consecuencia el numdocparticipante debe ser un ruc
		3.- Validar contra las tablas del ruc que el   local anexo enviado Exista y
		este asociado a ese ruc (tablas de informix)
		4.- Adicionalmente, validar Que el tipo de participante a enviar sea el 94 que
		corresponde a Empresa donde permanece la mercanca.*/		
		Participante partic=rucAnexoUbicacion;
		DataCatalogo  tipoDocumentoIdentidad= partic!=null?partic.getTipoDocumentoIdentidad():null;
		String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
		String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
		DataCatalogo tipoParticipante=partic!=null?partic.getTipoParticipante():null;
		String codParticipante=tipoParticipante!=null?tipoParticipante.getCodDatacat():null;
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		/*if (rucAnexoUbicacion!=null){
			if (!SunatStringUtils.include(modalidad, new String[]{"01","03","04"}) && "20".equals(regimen)){
				ValParticipante val=new ValParticipante();
				listError.add(val.tipoDocumentoIdentidad(rucAnexoUbicacion.getTipoDocumentoIdentidad(),"30224"));
				listError.add(val.numeroDocumentoIdentidad(rucAnexoUbicacion.getNumeroDocumentoIdentidad(),"30223",rucAnexoUbicacion.getTipoDocumentoIdentidad()));
				if (SunatStringUtils.isEmptyTrim(rucAnexoUbicacion.getTipoParticipante().getCodDatacat()) || !"94".equals(rucAnexoUbicacion.getTipoParticipante().getCodDatacat())){
					listError.add(getDUAError("30225",""));
				}
			}
		}*/
		if(SunatStringUtils.include(modalidad, new String[]{"01","03","04"})){
			if ("20".equals(regimen) &&
					!SunatStringUtils.include(codtipoperacion, new String[]{"2002","2008"})) {
				//			ValParticipante val=new ValParticipante();
				listError.add(valParticipante.tipoDocumentoIdentidad(tipoDocumentoIdentidad,"4","30388"));
				listError.add(valParticipante.numeroDocumentoIdentidad(numeroDocumentoIdentidad,"30220",tipoDocumentoIdentidad));
				listError.add(valParticipante.tipoParticipante(tipoParticipante,ConstantesDataCatalogo.TIPO_OPERADOR_ANEXO_UBICACION, "30387"));
				if(SunatStringUtils.isEmptyTrim(codlocalanexo) )
					listError.add(getDUAError("30017", "ANEXO ES OBLIGATORIO"));
			}
			else{
				if(!SunatStringUtils.isEmptyTrim(codlocalanexo)){
					if ("20".equals(regimen) && SunatStringUtils.include(codtipoperacion, new String[]{"2002","2008"}))
						listError.add(getDUAError("30390", "NO SE DEBE DE ENVIAR EL CODIGO DEL LOCAL ANEXO PARA REGIMEN 20 Y TIPO DE OPERACION 02 o 08"));
				}
				//				ValParticipante val=new ValParticipante();	
				if(codTipoDocumento!=null)
					listError.add(valParticipante.tipoDocumentoIdentidad(tipoDocumentoIdentidad,"4","30388"));
				if(!SunatStringUtils.isEmptyTrim(numeroDocumentoIdentidad))
					listError.add(valParticipante.numeroDocumentoIdentidad(numeroDocumentoIdentidad,"30220",tipoDocumentoIdentidad));
				if(codParticipante!=null)
					listError.add(valParticipante.tipoParticipante(tipoParticipante,ConstantesDataCatalogo.TIPO_OPERADOR_ANEXO_UBICACION, "30387"));
			}
			if(!SunatStringUtils.isEmptyTrim(codlocalanexo) && 
					!SunatStringUtils.isEmptyTrim(numeroDocumentoIdentidad) ){
				if(!"0000".equals(codlocalanexo)){
					boolean ruc_anexo_asociado =false;
					// 				List<Map<String,Object>> anexos= NumeracionServiceImpl.getInstance().getSprDAO().getEstablecimientosAnexos(numeroDocumentoIdentidad);
					List<Map<String,Object>> anexos= sprDAOService.getEstablecimientosAnexos(numeroDocumentoIdentidad);
					if(!CollectionUtils.isEmpty(anexos)){
						for(Map<String,Object> mpAnexo:anexos){
							String correl = Cadena.padLeft(String.valueOf(((Short)mpAnexo.get("spr_correl")).intValue()),4,'0');
							codlocalanexo=Cadena.padLeft(codlocalanexo, 4, '0');
							if (correl.equals(codlocalanexo)){
								ruc_anexo_asociado=true;		
								break;
							}						   	
						}
					}
					if(!ruc_anexo_asociado)
						listError.add(getDUAError("30389", new Object[]{codlocalanexo,numeroDocumentoIdentidad}));
				}
			}
		}
		//		listError.add(val.ciudad(rucAnexoUbicacion.getCiudad()));
		//		listError.add(val.direccion(rucAnexoUbicacion.getDireccion()));
		//		listError.add(val.email(rucAnexoUbicacion.getEmail()));
		//		listError.add(val.fax(rucAnexoUbicacion.getFax()));
		//		listError.add(val.nombreRazonSocial(rucAnexoUbicacion.getNombreRazonSocial()));
		//		listError.add(val.paginaWeb(rucAnexoUbicacion.getPaginaWeb()));
		//		listError.add(val.pais(rucAnexoUbicacion.getPais()));
		//		listError.add(val.telefono(rucAnexoUbicacion.getTelefono()));
		return listError;
	}
	/**
	 * Fecha de vencimiento de acogimiento al regimen.
	 * @deprecated Usar fecfinacoregimen 
	 * @param fecvenregimen Date
	 * @return el mapa de errrores
	 */
	public Map<String,String> fecvenregimen(Date fecvenregimen){
		return new HashMap<String,String>();
	}
	/**
	 * Valida el Indicador de envios de socorro
	 * 
	 * @param dua DUA
	 * @return el mapa de errrores
	 */
	public Map<String,String> indSocorro(DUA dua){
		if( SunatStringUtils.isEmpty( dua.getIndSocorro() ) ){
			return new HashMap<String,String>();
		}
		else{
			if( ! SunatStringUtils.isEqualTo( dua.getCodmodalidad() , "01")
					&& SunatStringUtils.isEqualTo(dua.getIndSocorro(), "S"))
				//return getDUAError("30294", "Error indsocorro - DUA");
				return getDUAError("30566", "Error indsocorro - DUA");
			//lmvr : RN 158  Envio de socorro
			if( SunatStringUtils.isEqualTo( dua.getCodmodalidad() , "10")
					&& (!SunatStringUtils.isEqualTo(dua.getIndSocorro(), " ") 
							|| SunatStringUtils.length(dua.getIndSocorro())>0 ))
				return getDUAError("30566", new Object[]{dua.getIndSocorro() });
		}
		return  new HashMap<String,String>();
	}
	/**
	 * Valida el codigo de tipo de pago
	 * 
	 * @param codtipopago String, codigo de tipo de pago, indica si es garantia o pago electronico
	 * @return el mapa de errrores
	 */
	public Map<String, String> codtipopago(String codtipopago){
		if (!SunatStringUtils.isEmpty(codtipopago)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("366", codtipopago))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("366", codtipopago,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
			{return new HashMap<String,String>();}
			else{
				return getDUAError("30080",new Object[]{codtipopago}); // valores validos G o P
			}
		}else
			return new HashMap<String,String>();
	}
	/**
	 * Valida el cdigo de la aduana de ingreso para trnsito
	 * 
	 * @param codopaduing String, Cdigo de la aduana de ingreso para trnsito
	 * @return el mapa de errrores
	 */
	public Map<String, String> codopaduing(String codopaduing){
		if (!SunatStringUtils.isEmptyTrim(codopaduing)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("00", codopaduing))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("00", codopaduing,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				return getDUAError("30295","Error catalogo codopaduing");	
		}else{
			return new HashMap<String,String>();
		}
	}
	/**
	 * Valida que el CODIGO DE LA ADUANA DE DESTINO POR LEY / ADUANA DE SALIDA tenga valor.
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codopadusal String, CODIGO DE LA ADUANA DE DESTINO POR LEY / ADUANA DE SALIDA
	 * @return el mapa de errores
	 */	
	public Map<String, String> codopadusal(String codopadusal){
		if (!SunatStringUtils.isEmptyTrim(codopadusal)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("00", codopadusal))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("00", codopadusal,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				return getDUAError("30296","Error catalogo codopadusal");	
		}else{
			return new HashMap<String,String>();
		}
	}
	/**
	 * Valida el codigo de la aduana de destino.
	 * 
	 * @param codopadutra String, codigo de la aduana de destino
	 * @return el mapa vacio.
	 */
	public Map<String, String> codopadutra(String codopadutra){
		//		if (!SunatStringUtils.isEmptyTrim(codopadutra)){
		//			if (FormatoAServiceImpl.getInstance().isValidCatalogo("00", codopadutra))
		//				return new HashMap<String,String>();
		//			else
		//				return getDUAError("30297","Error catalogo codopadutra");	
		//		}else{
		//			return getDUAError("30297","Error codopadutra");
		//		}
		return new HashMap<String,String>();
	}
	/**
	 * Valida en la tabla anexos  de informix que el local anexo este asociado al ruc
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numruclugarecep String
	 * @param codlugarecepcion String
	 * @param codanexo String
	 * @param codTransaccion String
	 * @return Map<String, String>, mapa de errores
	 */		
	@SuppressWarnings("unchecked")
	@ServicioAnnot(tipo="V",codServicio=2471,descServicio="Valida que el cod anexo esta asociado al Ruc")
	@ServInstDetAnnot(tipoRpta={0,0,0,1},
	nomAtr={"numruclugarecep","codlugarecepcion","codanexo","codTransaccion"})
	@OrquestaDespaAnnot(codServInstancia=2471,numSecEjec=35,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String,String> valPuntoLlegadaImportador(String numruclugarecep,
			String codlugarecepcion,String codanexo,String codTransaccion){
		SprDAOService sprDAOService = fabricaDeServicios.getService("Ayuda.sprService");
		/*cuando seha un punto de llegada 04 local del importador 
		verificar en la tabla de locales anexos 
		que el local anexo este asociado al ruc*/ 
		// 04 , Descarga en Zona Primaria con Autorizacin Especial
		if( ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION.equals(codlugarecepcion) ){
			//			List<Map<String,Object>> anexos= NumeracionServiceImpl.getInstance().getSprDAO().getEstablecimientosAnexos(numruclugarecep);
			List<Map<String,Object>> anexos= sprDAOService.getEstablecimientosAnexos(numruclugarecep);
			if(!CollectionUtils.isEmpty(anexos)){
				for(Map<String,Object> mpAnexo:anexos){
					String correl = Cadena.padLeft(String.valueOf(((Short)mpAnexo.get("spr_correl")).intValue()),4,'0');
					codanexo=Cadena.padLeft(codanexo, 4, '0');
					if (correl.equals(codanexo)){
						return new HashMap<String,String>();				  
					}						   	
				}
			}
			//"ANEXO: "+codanexo+" NO ASOCIADO AL RUC: "+numruclugarecep); //"ANEXO: "+codanexo+" NO ASOCIADO AL RUC: "+numruclugarecep
			return getDUAError("30369",new Object[]{codanexo,numruclugarecep}); 			
		}
		return new HashMap<String,String>();
	}
	/**
	 * M_SNADE278-1, metodo sobrecargado
	 * @author rtineo
	 */
	@ServicioAnnot(tipo="V",codServicio=2484,descServicio="Valida punto de llegada")
	@ServInstDetAnnot(tipoRpta={1,1,1},	nomAtr={"declaracion","codTransaccion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=2484,numSecEjec=35,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	@Override
	public Map<String, String> validarPuntoLLegada(Declaracion declaracion, String codTransaccion, Date fechaReferencia) {
		return validarPuntoLLegada(declaracion,codTransaccion,fechaReferencia,null);
	}
	
	/**
	 * metodo que valida el punto de llegada
	 * @param codigoModalidadDespacho
	 * @param codigoRegimen
	 * @param codigoAduanaTransmision
	 * @param numeroRUCdeposito
	 * @param numeroRUCpuntoLlegada
	 * @param codigoLugarDescarga
	 * @param codigoPuntoLLegadaMercancia
	 * @param numeroRUCduenioConsignatario
	 * @return mensaje con los errores ocurridos caso contrario un mapa vacio
	 */
	@ServicioAnnot(tipo="V",codServicio=3489,descServicio="Valida punto de llegada")
	@ServInstDetAnnot(tipoRpta={1,1,1},	nomAtr={"declaracion","codTransaccion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3489,numSecEjec=35,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> validarPuntoLLegada(Declaracion declaracion, String codTransaccion, Date fechaReferencia, Map<String,Object> variablesIngreso) {
		/*@ServicioAnnot(tipo="V",codServicio=2484,descServicio="Valida punto de llegada")
	@ServInstDetAnnot(tipoRpta={0,0,0,0,0,0,0,0,0,1,1},
			nomAtr={"codmodalidad","codregimen", "codaduanaorden", "numrucdeposito", "numruclugarecep", "codtiplugarrecep", "codlugarecepcion", "declarante.numeroDocumentoIdentidad", "listSeries","codTransaccion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=2471,numSecEjec=35,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> validarPuntoLLegada(String codigoModalidadDespacho, String codigoRegimen, String codigoAduanaTransmision,
			String numeroRUCdeposito, String numeroRUCpuntoLlegada, String codigoLugarDescarga,
			String codigoPuntoLLegadaMercancia, String numeroRUCduenioConsignatario, Elementos<DatoSerie> listSeries, String codTransaccion, Date fechaReferencia) {*/
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		DUA dua=declaracion.getDua();
		Elementos<DatoSerie> listSeries=dua.getListSeries();
		String codigoModalidadDespacho = dua.getCodmodalidad();
		String codigoRegimen = dua.getCodregimen();
		String codigoAduanaTransmision = dua.getCodaduanaorden();
		String numeroRUCdeposito = dua.getNumrucdeposito();
		String numeroRUCpuntoLlegada = dua.getNumruclugarecep()!=null?dua.getNumruclugarecep().toString():" ";
		String codigoLugarDescarga = dua.getCodtiplugarrecep();
		String codigoPuntoLLegadaMercancia =dua.getCodlugarecepcion()!=null?dua.getCodlugarecepcion().toString():"";
		String numeroRUCduenioConsignatario = dua.getDeclarante().getNumeroDocumentoIdentidad();
		String annManifiesto = SunatStringUtils.substringFox(dua.getManifiesto().getAnnmanif(), 1, 4);
		String codModTranspo= dua.getManifiesto().getCodmodtransp()!=null?dua.getManifiesto().getCodmodtransp().toString():" ";
		String numManifiesto = dua.getManifiesto().getNummanif();
		List<DatoDocTransporte> lstdocumentostrans = dua.getListDocTransporte();
		String codigoTransaccion = codTransaccion;
		List<Map<String,String>> listError=new ArrayList<Map<String,String>>();
		String codLocalAnexo = dua.getCodanexo()!=null?dua.getCodanexo().toString():" ";
		String codTipoDocIdent = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		BigDecimal montoFobDolares = dua.getMtotfobclvta();

		Date fechaHoy = SunatDateUtils.getCurrentDate();
		boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;

		ValidadorPuntoLlegadaMercancia validadorPuntoLlegadaMercancia;
		OpecomextDAO opecomextDao = fabricaDeServicios.getService("Ayuda.opecomextDef");		
		CircunoceDAO circunoceDAO = fabricaDeServicios.getService("Ayuda.circunoceDef"); //RIN 13 619
		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
		DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService  =   fabricaDeServicios.getService("manifiesto.documentoOAManifiestoValidacionService");
		McdetaDAO  mcdetaDAO = fabricaDeServicios.getService("manifiesto.mcdetaDAO");
		AutorizacionZonaPrimariaService autorizacionZonaPrimariaService = (AutorizacionZonaPrimariaService)fabricaDeServicios.getService("autorizacionZonaPrimariaService");
		ConsultaLiquidacionService consultaLiquidacionService = (ConsultaLiquidacionService)fabricaDeServicios.getService("declaracion.ingreso.consultaLiquidacionService");
		GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
		ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService  = (ConsultaDeclaracionImpoConsumoService)fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
		ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService  = (ConsultaDeclaracionDepositoAduaneroService) fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
		ConsultaDeclaracionImportacionAdmisionReexpService consultaDeclaracionImportacionAdmisionReexpService  = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImportacionAdmisionReexpService");
		ConsultaDeclaracionImportacionAdmisionPerfecService consultaDeclaracionImportacionAdmisionPerfecService  = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImportacionAdmisionPerfecService");
		HotSwappableTargetSource swapperDatasource = fabricaDeServicios.getService("declaracion.swapper.dx.prp1");
		ManifiestoSigadService manifiestoSigadService = fabricaDeServicios.getService("manifiesto.manifiestoSigadService");
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		//rtineo M_SNADE278_1: retorna si la declaracion aplica para una dam Diferida SIN ICA, se vuelve a validar porque esta validacion no trae variablesIngreso
		Boolean isDAMDiferida = false;
		Boolean isRectiDiferidaNormal = false;
		if(variablesIngreso!=null){
			isDAMDiferida = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
			isRectiDiferidaNormal = variablesIngreso.get("isRectiDiferidaNormal")!=null?(Boolean)variablesIngreso.get("isRectiDiferidaNormal"):false;
		}
		//rtineo M_SNADE278-1
		/* inicio PAS20181U220200049*/
		Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", fechaReferencia);
		boolean esManifiestoEerSda = false;
		boolean esManifiestoEerSigad = false;
		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
		if (!CollectionUtils.isEmpty(MapaValManNum)){
			esManifiestoEerSda = funcionesService.esManifiestoEerSda(declaracion);
			esManifiestoEerSigad = funcionesService.esManifiestoEerSigad(declaracion);//pase64
		}
		/* fin PAS20181U220200049*/
		
		//tipo despacho excepcional
		if("00".equals(codigoModalidadDespacho)){
			//rtineo M_SNADE278
			if(isDAMDiferida && !isRectiDiferidaNormal){
				validadorPuntoLlegadaMercancia = new ValidadorPuntoLlegadaMercanciaModalidadExcepcional(codigoAduanaTransmision, codigoRegimen, listSeries,
					codigoLugarDescarga, codigoPuntoLLegadaMercancia, numeroRUCpuntoLlegada, numeroRUCdeposito,
					fechaReferencia,opecomextDao,annManifiesto,codModTranspo,numManifiesto,manifiestoService,documentoOAManifiestoValidacionService,
					lstdocumentostrans,mcdetaDAO,fabricaDeServicios,swapperDatasource,manifiestoSigadService,circunoceDAO,codigoTransaccion,codLocalAnexo,isDAMDiferida,esManifiestoEerSda,esManifiestoEerSigad);
			}else{
				if(esVigenteRIN31){
                String puntoDeLlegada=declaracion.getDua().getCodlugarecepcion()!=null?declaracion.getDua().getCodlugarecepcion():"";
                if(SunatStringUtils.isEmptyTrim(puntoDeLlegada)){
                    Map<String,Object> params=new HashMap<String,Object>();
                    params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
                    //CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
                    Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(params);
                    puntoDeLlegada= cabDeclara.get("COD_LUGARRECEP")!=null?cabDeclara.get("COD_LUGARRECEP").toString():"";
                    if(puntoDeLlegada.equals("11")) {
                        declaracion.getDua().setCodlugarecepcion(puntoDeLlegada);
                    	}
                	}
                codigoPuntoLLegadaMercancia=puntoDeLlegada;
				}
			    validadorPuntoLlegadaMercancia = new ValidadorPuntoLlegadaMercanciaModalidadExcepcional(codigoAduanaTransmision, codigoRegimen, listSeries,
						codigoLugarDescarga, codigoPuntoLLegadaMercancia, numeroRUCpuntoLlegada, numeroRUCdeposito,
						fechaReferencia,opecomextDao,annManifiesto,codModTranspo,numManifiesto,manifiestoService,documentoOAManifiestoValidacionService,

						lstdocumentostrans,mcdetaDAO,fabricaDeServicios,swapperDatasource,manifiestoSigadService,circunoceDAO,codigoTransaccion,codLocalAnexo,esManifiestoEerSda,esManifiestoEerSigad);
			}
		}else
			//tipo despacho urgente
			if("01".equals(codigoModalidadDespacho)){
				if (!CollectionUtils.isEmpty(MapaValManNum)){ //PAS20181U220200049
					validadorPuntoLlegadaMercancia = new ValidadorPuntoLlegadaMercanciaModalidadDespachoUrgente(
							codigoAduanaTransmision, codigoRegimen, listSeries, codigoLugarDescarga, codigoPuntoLLegadaMercancia,
							numeroRUCpuntoLlegada, numeroRUCdeposito, fechaReferencia,opecomextDao,annManifiesto,codModTranspo,numManifiesto,

							manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans,mcdetaDAO,fabricaDeServicios,swapperDatasource,manifiestoSigadService,circunoceDAO,codigoTransaccion,esManifiestoEerSda,esManifiestoEerSigad);

				}
				else {
				validadorPuntoLlegadaMercancia = new ValidadorPuntoLlegadaMercanciaModalidadDespachoUrgente(
						codigoAduanaTransmision, codigoRegimen, listSeries, codigoLugarDescarga, codigoPuntoLLegadaMercancia,
						numeroRUCpuntoLlegada, numeroRUCdeposito, fechaReferencia,opecomextDao,annManifiesto,codModTranspo,numManifiesto,
						manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans,mcdetaDAO,fabricaDeServicios,swapperDatasource,manifiestoSigadService,circunoceDAO,codigoTransaccion);
				}
			}else
				//tipo despacho anticipado
				if("10".equals(codigoModalidadDespacho)){
					if (!CollectionUtils.isEmpty(MapaValManNum)){ //PAS20181U220200049
							validadorPuntoLlegadaMercancia = new ValidadorPuntoLlegadaMercanciaModalidadDespachoAnticipado(
									codigoAduanaTransmision, codigoRegimen, listSeries, codigoLugarDescarga, codigoPuntoLLegadaMercancia,
									numeroRUCpuntoLlegada, numeroRUCdeposito, numeroRUCduenioConsignatario, fechaReferencia,opecomextDao,
									annManifiesto,codModTranspo,numManifiesto,manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans,
									mcdetaDAO,									
									codLocalAnexo,
									codTipoDocIdent,montoFobDolares,autorizacionZonaPrimariaService,consultaLiquidacionService,getDeclaracionService,
									consultaDeclaracionImpoConsumoService,consultaDeclaracionDepositoAduaneroService,consultaDeclaracionImportacionAdmisionReexpService,
									consultaDeclaracionImportacionAdmisionPerfecService,fabricaDeServicios,swapperDatasource,cabDeclaraDAO,manifiestoSigadService,codigoTransaccion,circunoceDAO,esManifiestoEerSda, esManifiestoEerSigad);
						
					}
					else {
					validadorPuntoLlegadaMercancia = new ValidadorPuntoLlegadaMercanciaModalidadDespachoAnticipado(
							codigoAduanaTransmision, codigoRegimen, listSeries, codigoLugarDescarga, codigoPuntoLLegadaMercancia,
							numeroRUCpuntoLlegada, numeroRUCdeposito, numeroRUCduenioConsignatario, fechaReferencia,opecomextDao,
							annManifiesto,codModTranspo,numManifiesto,manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans,
							mcdetaDAO,									
							codLocalAnexo,
							codTipoDocIdent,montoFobDolares,autorizacionZonaPrimariaService,consultaLiquidacionService,getDeclaracionService,
							consultaDeclaracionImpoConsumoService,consultaDeclaracionDepositoAduaneroService,consultaDeclaracionImportacionAdmisionReexpService,
							consultaDeclaracionImportacionAdmisionPerfecService,fabricaDeServicios,swapperDatasource,cabDeclaraDAO,manifiestoSigadService,codigoTransaccion,circunoceDAO); 
				} 
				} 
				else{
					return getDUAError("00041",new Object[]{codigoModalidadDespacho});
				}
		try {
			//Inicio M_SNADE255-2 - PercyHM 2016/07/14 - Adecuacin a la destinacin con punto de llegada deposito aduanero sin transmitir regimen precedente
			boolean flagVigencia_0023 = false;
			boolean esEnvioDepositoAduaneroSinPrecendencia = false;
			DataCatalogo catVigenciaValidacion_0023 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN, "0023", new java.util.Date());
			if ( catVigenciaValidacion_0023 != null ) {
				esEnvioDepositoAduaneroSinPrecendencia = GeneralUtils.esEnvioDepositoAduaneroSinPrecendencia(declaracion, dua, listSeries);
				flagVigencia_0023 = true;
			}
			if(flagVigencia_0023 && codigoPuntoLLegadaMercancia.equals(Constants.CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO) && esEnvioDepositoAduaneroSinPrecendencia){				
				boolean validaDocTransporteAsociadoDuaDepositoDesdatadaLegajada = this.validaDocTransporteAsociadoDuaDepositoDesdatadaLegajada(declaracion, dua, lstdocumentostrans);
				if(!validaDocTransporteAsociadoDuaDepositoDesdatadaLegajada){
					validadorPuntoLlegadaMercancia.validar(fechaReferencia, codigoAduanaTransmision);//Invoca al proceso de validacion actual
				}
			}else{
				//Fin M_SNADE255-2	
				validadorPuntoLlegadaMercancia.validar(fechaReferencia, codigoAduanaTransmision);
				//Inicio M_SNADE255-2 - PercyHM 2016/07/14 - Adecuacin a la destinacin con punto de llegada deposito aduanero sin transmitir regimen precedente 70
			}
			//Inicio M_SNADE255-2 
		} catch (PuntoLLegadaValidadorException e) {
			if(e.getCodigoError().length()>5){//Inicio bug 18428
				Map mapError = new HashMap();
				mapError.put(ResponseMapManager.KEY_CODIGO, e.getCodigoError().substring(0,5) );
				mapError.put(ResponseMapManager.KEY_DESCRIPCION, e.getMessage().substring(7,e.getMessage().length()));
				mapError.put(ResponseMapManager.KEY_TIPO_ALERTA,  e.getCodigoError().substring(5,6));	
				return mapError;
			}else{//fin bug 18428
				return getDUAError(e.getCodigoError(), e.getArgumentos());
			}
		}
		return new HashMap<String,String>();
	}
	/*RIN13INSI-INICIO*/	
	/*
	 * lmvr
	 * Valida el tipo de punto de llegada 9, solo para modalidad urgente y anticipada, debe enviar
	 * Una resolucion de aduanas autorizando el despacho a dicho punto de llegada
	 */
	@ServicioAnnot(tipo="V",codServicio=2533,descServicio="validaciones Punto de llegada duas excepcionales y urgentes")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","codTransaccion"})
	@OrquestaDespaAnnot(codServInstancia=2533,numSecEjec=35,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String,String>>  validarPuntoLLegadaUrgenteExcepcional(Declaracion declaracion , String codigoTransaccion	) {		
		List<Map<String,String>> listerror = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
//PAS20181U220200004
		Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion();
		if(fechaDeclaracion==null){
			fechaDeclaracion = new Date();
		}
		String codigoModalidadDespacho = dua.getCodmodalidad();
		String codtiplugrecepcion = dua.getCodtiplugarrecep();
		String numeroRUCduenioConsignatario = dua.getDeclarante().getNumeroDocumentoIdentidad();
		//String codAduana = dua.getCodaduanaorden();
		//String annPresen=  SunatStringUtils.substringFox(declaracion.getNumorden(), 1, 4);
		String codigoPuntoLLegadaMercancia =dua.getCodlugarecepcion();
		DatoManifiesto datoManif= new DatoManifiesto();
		datoManif= declaracion.getDua().getManifiesto();
		//boolean buscarManifiestoSigadActual = false;
		boolean buscarManifiestiPorSusPropiosMedios = false;
		//boolean existeManifiestoAsigad = false;
		boolean existeResolucionZPAE = false;
		boolean existeExpedienteZpae = false;
		//boolean noExisteManifiestoAsigad = false;
		//boolean noExisteManifiestoSigad = false;
		if (!ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO.equals(codigoModalidadDespacho)
				&& ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS.equals(codigoPuntoLLegadaMercancia)) {
			
			Manifiesto manifiesto = null;//PAS20181U220200049
		
			if (datoManif != null) {
				DatoManifiesto manif = dua.getManifiesto();
				//PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:
				/*buscarManifiestoSigadActual = (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(dua.getManifiesto().getCodmodtransp()) || 
						"7".equals(dua.getManifiesto().getCodmodtransp()));*/
				
				Map<String, Object> dataManif = new HashMap<String, Object>();
				String codaduamanif = manif.getCodaduamanif();
				String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
				String nummanif = manif.getNummanif();
				String codmodtransp = manif.getCodmodtransp();
				String codtipmanif = manif.getCodtipomanif();
				dataManif.put("numeroManifiesto",	SunatStringUtils.lpad(nummanif, 6, ' '));
				dataManif.put("anioManifiesto", annmanif);
				dataManif.put("codigoAduana", codaduamanif);
				dataManif.put("codigoTipoManifiesto", codtipmanif);
				dataManif.put("codigoViaTransporte", codmodtransp);
				ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
				//Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif,codmodtransp, codaduamanif,SunatNumberUtils.toInteger(annmanif), nummanif,buscarManifiestoSigadActual);
				/** inicio PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:**/
				
				List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaDeclaracion);
				boolean evaluarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
				
				if(!ResponseListManager.responseListHasErrors(listaOMA)){
					manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif,codmodtransp, codaduamanif,SunatNumberUtils.toInteger(annmanif), nummanif,true, fechaDeclaracion,evaluarEER);
				}else{
					manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif,codmodtransp, codaduamanif,SunatNumberUtils.toInteger(annmanif), nummanif,true);					
				}
				/***fin PAS20181U220200049***/
				 
				if (manifiesto != null) {
					if (!manifiesto.isEsSigad()) {//esto se est seteando x dentro a cualquier consulta
					//	existeManifiestoAsigad = true;
					//} else {
						Map<String, Object> parametroParticip = new HashMap<String, Object>();
						parametroParticip.put("numeroCorrelativo",	manifiesto.getNumeroCorrelativo());
						parametroParticip.put("codTippartic", new String[] { ConstantesDataCatalogo.TIPO_OPERADOR_POR_SUS_PROPIOS_MEDIOS });
						ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
						List<Participante> listadoParticipante = participanteService.obtenerTipoParticipanteAutorizadoByCriterios(parametroParticip);
						if (!CollectionUtils.isEmpty(listadoParticipante)) {
							buscarManifiestiPorSusPropiosMedios = true;
						}
					}
				/*}else{
					//if(buscarManifiestoSigadActual){PAS20181U220200049 no se tiene manifiesto ni en bdsigad ni en sigad
					noExisteManifiestoSigad= true;
					noExisteManifiestoAsigad= true;
					//}else{
					//}
				 */					 
				}
			}
			
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
		    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false;
			//PAS20181U220200004
			// Verifica que se enve como documento de soporte la resolucin de aduanas autorizando (Cata 75 tipo 18 -Resol Aduanas )
			List<DatoOtroDocSoporte> resolAsociadas = getListDocSoporteByTipoDocAsociado(declaracion.getDua(),
					ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_EXPEDIENTE_ADUANAS,ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS);
			String aduanaZPAE= "";
			String anoZPAE ="";
			String numZPAE="";
			String rucZPAE=numeroRUCduenioConsignatario;
			if (!CollectionUtils.isEmpty(resolAsociadas)) {
				for (DatoOtroDocSoporte resolSoporte : resolAsociadas) {					
					//PAS201830001100018 - mtorralba 20181115 - Para controlar valor nulo de Entidad Emisora 
					String AduanaDocumento = resolSoporte.getCodentidademisora()==null?"<null>":SunatStringUtils.lpad(resolSoporte.getCodentidademisora().toString(),3,'0');
					if( !declaracion.getDua().getCodaduanaorden().equals(AduanaDocumento)){
						listerror.add(getDUAError("35581",new String[]{AduanaDocumento, resolSoporte.getNumdocasoc()}));
						break;    
					}
					
					ResolucionService resolucionService = fabricaDeServicios.getService("tramite.ResolucionService");
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("codiAdua", SunatStringUtils.lpad(SunatStringUtils.toStringObj(resolSoporte.getCodentidademisora()), 3, '0'));
					params.put("dresAnno", resolSoporte.getAnndocasoc().substring(0, 4));
					params.put("dresNro", resolSoporte.getNumdocasoc());
					List<ResCab> listResolucionConDUA = resolucionService.find(params);
					if (!CollectionUtils.isEmpty(listResolucionConDUA)){
						if(listResolucionConDUA.size()>0){
							existeExpedienteZpae=true;
							aduanaZPAE = SunatStringUtils.lpad(SunatStringUtils.toStringObj(resolSoporte.getCodentidademisora()), 3, '0');
							anoZPAE = resolSoporte.getAnndocasoc().substring(0, 4);
							numZPAE =  resolSoporte.getNumdocasoc();
							break;
						}
					}
					
				}
			
			
				AutorizacionZonaPrimariaService autorizacionZonaPrimariaService=fabricaDeServicios.getService("autorizacionZonaPrimariaService");

				if (esVigenteRIN05SegundaParte) {
					List<DatoOtroDocSoporte> resolAsociadasZpae = getListDocSoporteByTipoDocAsociado(declaracion.getDua(),
							ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS);
					if(!CollectionUtils.isEmpty(resolAsociadasZpae)){
					for (DatoOtroDocSoporte resolSoporte : resolAsociadasZpae) {
						aduanaZPAE = SunatStringUtils.lpad(SunatStringUtils.toStringObj(resolSoporte.getCodentidademisora()), 3, '0');
						anoZPAE = resolSoporte.getAnndocasoc().substring(0, 4);
						numZPAE =  resolSoporte.getNumdocasoc();
						
					    List<SolicitudAutorizacionZonaPrimaria>  solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,aduanaZPAE, anoZPAE, numZPAE, null, null);
						if (!CollectionUtils.isEmpty(solicitudAutorizacionZonaPrimaria)){
							existeResolucionZPAE=true;							
							break;
							
						}
					}
				  }  
				}
			}
//PAS20181U220200004
			
			if(esVigenteRIN05SegundaParte && existeResolucionZPAE){
				String fechaSinHora = SunatDateUtils.getFormatDate(fechaDeclaracion, "dd/MM/yyyy");	
			    Date fecha = SunatDateUtils.getDate(fechaSinHora);
				AutorizacionZonaPrimariaService autorizacionZonaPrimariaService=fabricaDeServicios.getService("autorizacionZonaPrimariaService");

				List<SolicitudAutorizacionZonaPrimaria>  solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,aduanaZPAE, anoZPAE, numZPAE, null, fecha);

				if (CollectionUtils.isEmpty(solicitudAutorizacionZonaPrimaria)){
					listerror.add(getDUAError("30671", new Object[] {}));
					
				}
			}
			
			if(manifiesto!=null){
				if(manifiesto.isEsSigad()) return listerror;
			}


			if (!esVigenteRIN05SegundaParte && (existeExpedienteZpae || buscarManifiestiPorSusPropiosMedios)) {
				return listerror;
			//}else{
				//if(!existeResolucionZPAE  && !buscarManifiestiPorSusPropiosMedios  &&   (!noExisteManifiestoAsigad || !noExisteManifiestoSigad) ){
			}else if(!existeExpedienteZpae && !existeResolucionZPAE  && !buscarManifiestiPorSusPropiosMedios  ){
					listerror.add(getDUAError("32004", new Object[] {}));
				//}
				//return listerror;
			}
			
	//validar importador de zpae
			SolicitudAutorizacionZonaPrimaria conRuc = new SolicitudAutorizacionZonaPrimaria();
			String codLocalAnexo = dua.getCodanexo()!=null?dua.getCodanexo().toString():" ";
			String codigoAduanaTransmision = dua.getCodaduanaorden();
			String codTipoOper = dua.getCodtipooper();
			String codTipoDocIdent = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
			conRuc.setParticipante(new Participante());
			conRuc.setDatoOtroDocSoporte(new DatoOtroDocSoporte());
			conRuc.getParticipante().setCiudad(codLocalAnexo);
			conRuc.getParticipante().setNumeroDocumentoIdentidad(numeroRUCduenioConsignatario);
			conRuc.getDatoOtroDocSoporte().setCodigoAduanaAutoriza(codigoAduanaTransmision);
			conRuc.getDatoOtroDocSoporte().setCodtipodocasoc(ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_EXPEDIENTE_ADUANAS); // PAS20181U220200004
			AutorizacionZonaPrimariaService autorizacionZonaPrimariaService=fabricaDeServicios.getService("autorizacionZonaPrimariaService");
			List<SolicitudAutorizacionZonaPrimaria> listRUc = autorizacionZonaPrimariaService.consultarAutorizacionZonaPrimaria(conRuc);
			
			if(listRUc == null || listRUc.isEmpty()){
				if(!esVigenteRIN05SegundaParte && existeExpedienteZpae){
					listerror.add(getDUAError("30670", new Object[] {codTipoOper,numeroRUCduenioConsignatario,codLocalAnexo,codTipoDocIdent}));
					
				}else{
					 if(existeResolucionZPAE){
						//List<SolicitudAutorizacionZonaPrimaria>  solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,null, null, null, numeroRUCduenioConsignatario, null);
						List<SolicitudAutorizacionZonaPrimaria>  solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,aduanaZPAE, anoZPAE, numZPAE, numeroRUCduenioConsignatario, null);
							if (CollectionUtils.isEmpty(solicitudAutorizacionZonaPrimaria)){
								
								listerror.add(getDUAError("30670", new Object[] {codTipoOper,numeroRUCduenioConsignatario,codLocalAnexo,codTipoDocIdent}));
								
								
							}
					 }
				}			
					
			}
			
			
		}else{
			//PAS20181U220200004
			if (ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO.equals(codigoModalidadDespacho) && ConstantesDataCatalogo.DESCARGA_ZONA_PRIMARIA_CON_AUTORIZACION.equals(codtiplugrecepcion)){
				ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
			    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false;
			    AutorizacionZonaPrimariaService autorizacionZonaPrimariaService=fabricaDeServicios.getService("autorizacionZonaPrimariaService");
				List<DatoOtroDocSoporte> resolAsociadas = getListDocSoporteByTipoDocAsociado(declaracion.getDua(),
						ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS);		
				
				if (!esVigenteRIN05SegundaParte && !CollectionUtils.isEmpty(resolAsociadas)) {
					listerror.add(getDUAError("50126", new Object[] {ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_EXPEDIENTE_ADUANAS}));
				}else{
					
					// Verifica que se env�e como documento de soporte la resoluci�n de aduanas autorizando (Cata 75 tipo 18 -Resol Aduanas )
					List<DatoOtroDocSoporte> expedienteAsociadas = getListDocSoporteByTipoDocAsociado(declaracion.getDua(),
							ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_EXPEDIENTE_ADUANAS);
					String aduanaZPAE= "";
					String anoZPAE ="";
					String numZPAE="";
					String rucZPAE=numeroRUCduenioConsignatario;
					boolean existeExpedienteZPAE = false;
					if (!CollectionUtils.isEmpty(expedienteAsociadas)) {
						for (DatoOtroDocSoporte resolSoporte : expedienteAsociadas) {					
											
									existeExpedienteZPAE=true;									
									aduanaZPAE = resolSoporte.getCodentidademisora() != null?SunatStringUtils.lpad(SunatStringUtils.toStringObj(resolSoporte.getCodentidademisora()), 3, '0'):" ";
									anoZPAE = resolSoporte.getAnndocasoc().substring(0, 4);
									numZPAE =  resolSoporte.getNumdocasoc();
									break;
								
							
						}
					}

				    boolean existeResolucion = false;
				    boolean existeExpediente =  false;	
					List<SolicitudAutorizacionZonaPrimaria> listRUc = new ArrayList<SolicitudAutorizacionZonaPrimaria>();;
				        if(existeExpedienteZPAE){
						//String expediente = aduanaZPAE + "-" + anoZPAE + "-" + numZPAE;
						SolicitudAutorizacionZonaPrimaria conRuc = new SolicitudAutorizacionZonaPrimaria();
						
						conRuc.setParticipante(new Participante());
						conRuc.setDatoOtroDocSoporte(new DatoOtroDocSoporte());
						conRuc.getParticipante().setNumeroDocumentoIdentidad(numeroRUCduenioConsignatario);
						conRuc.getDatoOtroDocSoporte().setNumdocasoc(numZPAE);
						conRuc.getDatoOtroDocSoporte().setAnndocasoc(anoZPAE);
						conRuc.getDatoOtroDocSoporte().setCodigoAduanaAutoriza(aduanaZPAE);
						conRuc.getDatoOtroDocSoporte().setCodtipodocasoc(ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_EXPEDIENTE_ADUANAS);
						
						 listRUc = autorizacionZonaPrimariaService.consultarAutorizacionZonaPrimaria(conRuc);
				        }
						if (!CollectionUtils.isEmpty(listRUc)){
							
							existeExpediente= true;
						}else{
							if(esVigenteRIN05SegundaParte){
							// Verifica que se env�e como documento de soporte la resoluci�n de aduanas autorizando (Cata 75 tipo 18 -Resol Aduanas )
							List<DatoOtroDocSoporte> resolucionAsociadas = getListDocSoporteByTipoDocAsociado(declaracion.getDua(),
									ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS);
							 rucZPAE=numeroRUCduenioConsignatario;
							 boolean existeresolZPAE = false;
							if (!CollectionUtils.isEmpty(resolucionAsociadas)) {
								for (DatoOtroDocSoporte resolSoporte : resolucionAsociadas) {					
													
									existeresolZPAE=true;									
											aduanaZPAE = resolSoporte.getCodentidademisora() != null?SunatStringUtils.lpad(SunatStringUtils.toStringObj(resolSoporte.getCodentidademisora()), 3, '0'):" ";
											anoZPAE = resolSoporte.getAnndocasoc().substring(0, 4);
											numZPAE =  resolSoporte.getNumdocasoc();
											break;
										
									
								}

							}
							if(existeresolZPAE){
								
								List<SolicitudAutorizacionZonaPrimaria>  solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,aduanaZPAE, anoZPAE, numZPAE, rucZPAE, null);
								if (!CollectionUtils.isEmpty(solicitudAutorizacionZonaPrimaria)){
									existeExpediente =true;
									existeResolucion= true;
								}
							}
						  }
						}
						
						
						
						if(!existeExpediente && !existeResolucion){
							listerror.add(getDUAError("50132", new Object[] {}));
						}
						
						if(esVigenteRIN05SegundaParte && existeResolucion ){
							String fechaSinHora = SunatDateUtils.getFormatDate(fechaDeclaracion, "dd/MM/yyyy");	
						    Date fecha = SunatDateUtils.getDate(fechaSinHora);	
						    
							List<SolicitudAutorizacionZonaPrimaria>  solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,aduanaZPAE, anoZPAE, numZPAE, rucZPAE, fecha);
							if (CollectionUtils.isEmpty(solicitudAutorizacionZonaPrimaria)){
								
								listerror.add(getDUAError("30671", new Object[] {}));
							}
							// validdar importador
							String codLocalAnexo = dua.getCodanexo()!=null?dua.getCodanexo().toString():" ";							
							String codTipoOper = dua.getCodtipooper();
							String codTipoDocIdent = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
						    solicitudAutorizacionZonaPrimaria = autorizacionZonaPrimariaService.buscarResolucionAutorizacionZPAE(ConstantesDataCatalogo.CODIGO_PROCESO_ZPAE, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_RESOL_ADUANAS,aduanaZPAE, anoZPAE, numZPAE, numeroRUCduenioConsignatario, null);
							if (CollectionUtils.isEmpty(solicitudAutorizacionZonaPrimaria)){
								listerror.add(getDUAError("30670", new Object[] {codTipoOper,numeroRUCduenioConsignatario,codLocalAnexo,codTipoDocIdent}));
     						}
							 
							
							
						}
					
					
				}
				
				
			}
		}
		//fin PAS20181U220200004
		return listerror;
	}
	/*RIN13INSI-FIN*/
	@ServicioAnnot(tipo="V",codServicio=2485,descServicio="validaciones del local anexo del Punto de Llegada")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","codTransaccion"})
	@OrquestaDespaAnnot(codServInstancia=2485,numSecEjec=35,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public Map<String, String> validarLocalAnexoPuntoLLegada(Declaracion declaracion , String codigoTransaccion	) {
		ValidadorLocalAnexo validadorLocalAnexo = fabricaDeServicios.getService("ValidadorLocalAnexo");
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		//LMVR - Complemento de la Dua Parte II
		DUA dua = declaracion.getDua();
		String codigoRegimen= dua.getCodregimen();
		String rucPuntoLLegada = dua.getNumruclugarecep();
		String rucDepositoAduanero = dua.getNumrucdeposito();
		String codigoLocalAnexoPuntoLLegada = dua.getCodanexo();
		String codigoLocalAnexoDepositoAduanero = dua.getCodlocalanexo();
		String codigoModalidad = dua.getCodmodalidad();
		String codAduana = dua.getCodaduanaorden();
		String codLugarRecep = dua.getCodlugarecepcion();
		Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();
		boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaDeclaracion):false;

		boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaDeclaracion):false;

		validadorLocalAnexo.fijarValidadorLocalAnexo(codigoRegimen, rucPuntoLLegada,
				rucDepositoAduanero, codigoLocalAnexoPuntoLLegada, codigoLocalAnexoDepositoAduanero,codigoModalidad,codLugarRecep,codAduana);
		try {
			if(((esVigenteRIN05||esVigenteRIN31) && "14".equals(codLugarRecep)) && codigoLocalAnexoPuntoLLegada!=null && !codigoLocalAnexoPuntoLLegada.equals("")  ){
				validadorLocalAnexo.validarLocalAnexoPuntoLLegadaOMA2();
			}
			if(((esVigenteRIN05||esVigenteRIN31) && !"14".equals(codLugarRecep))){ //no valida local anexo del punto de llegada para lugar de recepcion 14
				validadorLocalAnexo.validarLocalAnexoPuntoLLegada();	
				validadorLocalAnexo.validarLocalAnexoDepositoAduanero();
			}
			
		} catch (ValidadorLocalAnexoException e) {
			return getDUAError(e.getCodigoError(), e.getArgumentos());
		}
		return new HashMap<String,String>();
	}
	/**
         * Para acogerse a despacho urgente no debe tener declaraciones pendientes de regularizar
         * salvo aquellas que corresponden a medicinas o vacunas o en su defecto tengan un expediente de
         * suspension de plazo.
         * Este servicio se activa para regimen 10, pero para otros regimenes considerar la atencin
         * de la  Solicitud Electronica Siged N 01531 - 2012 - 4E6000
         * @param codmodalidad
         * @param fechareferencia
         * @param declaracion
         * @return
         */
	@ServicioAnnot(tipo="V",codServicio=3392,descServicio="Bloqueo de despachos urgentes")
	@ServInstDetAnnot(tipoRpta={0,0,0,0,1},
	nomAtr={"codmodalidad", "fechareferencia", "declaracion"})
	@OrquestaDespaAnnot(codServInstancia=3392,numSecEjec=35,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String,String>>  bloqueoDespachosUrgentes(String codmodalidad, Date fechareferencia, Declaracion declaracion){
		List<Map<String,String>> listerror = new ArrayList<Map<String,String>>();
		if (SunatStringUtils.isEqualTo(codmodalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)){
			String codprodurgente = declaracion.getDua().getCodprodurgente();
			if (SunatStringUtils.include(codprodurgente, new String[]{ConstantesDataCatalogo.DESP_URG_ORGANOSYSANGRE, ConstantesDataCatalogo.DESP_URG_MEDICAYVACUNAS})){
				return listerror;
			}
			GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
			ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
			// Se  Obtiene las declaraciones urgentes pendientes de regularizar 		
			List<Declaracion> listdeclaracionPendiente = getDeclaracionService.getDeclaracionPendienteRegularizar(declaracion.getDua().getDeclarante(), Constants.PLAZO_REGULARIZACION_REGIMEN, 
					declaracion.getDua().getCodmodalidad(),"false");
			String indsocorro = SunatStringUtils.toNotNull(declaracion.getDua().getIndSocorro());
			if (!indsocorro.equals("S") ){
				for(Declaracion declaracionPendiente:listdeclaracionPendiente){				
					// aseguramos que sea despachos de urgencia y no de socorro
					Long numCorredoc = declaracionPendiente.getDua().getNumcorredoc();
					String codaduana = declaracionPendiente.getCodaduana();
					String annpresen = declaracionPendiente.getDua().getAnnpresen().toString();
					String codregimen= declaracionPendiente.getCodregimen();
					String numdeclaracion = SunatStringUtils.toStringObj(declaracionPendiente.getNumeroDeclaracion());
					Date fechaVencimiento = declaracionPendiente.getDua().getFecvencregula();
					String CDApendiente = codaduana.concat("-").concat(annpresen).concat("-").concat(codregimen).concat("-").concat(numdeclaracion);
					List<Map<String, Object>> expedienteSuspension = funcionesService.buscarExpedienteSuspension(codaduana, annpresen, codregimen, numdeclaracion, fechaVencimiento);
					if (CollectionUtils.isEmpty(expedienteSuspension) ) {
						List<DatoIndicadores> listIndicadorAbandonoVol = 
								funcionesService.getIndicadorDUA(numCorredoc, ConstantesDataCatalogo.INDICADOR_ABANDONO_VOLUNTARIO, null, ConstantesDataCatalogo.IND_ACTIVO);
						if (CollectionUtils.isEmpty(listIndicadorAbandonoVol)){
							//No ha presentado expediente de suspensin de plazo
							listerror.add(getDUAError("30764",new Object[]{CDApendiente}));
							//Importador tiene DUAs Urgentes no transmitidas para su regularizacin
							//	listerror.add(getDUAError("30762",new Object[]{CDApendiente})); comentado por bug de 18630 arey
						} 
					} 
				}
				listdeclaracionPendiente = getDeclaracionService.getDeclaracionPendienteRegularizar(declaracion.getDua().getDeclarante(), Constants.PLAZO_REGULARIZACION_REGIMEN, 
						declaracion.getDua().getCodmodalidad(),"true");
				for(Declaracion declaracionPendiente:listdeclaracionPendiente){
					//String indsocorro = SunatStringUtils.toNotNull(declaracionPendiente.getDua().getIndSocorro());
					// aseguramos que sea despachos de urgencia y no de socorro
					Long numCorredoc = declaracionPendiente.getDua().getNumcorredoc();
					String codaduana = declaracionPendiente.getCodaduana();
					String annpresen = declaracionPendiente.getDua().getAnnpresen().toString();
					String codregimen= declaracionPendiente.getCodregimen();
					String numdeclaracion = SunatStringUtils.toStringObj(declaracionPendiente.getNumeroDeclaracion());
					Date fechaVencimiento = declaracionPendiente.getDua().getFecvencregula();
					Date fechaSegundaGED =  declaracionPendiente.getDua().getFecSegundaRecepcion();
					String CDApendiente = codaduana.concat("-").concat(annpresen).concat("-").concat(codregimen).concat("-").concat(numdeclaracion); 
					List<Map<String, Object>> expedienteSuspension = funcionesService.buscarExpedienteSuspension(codaduana, annpresen, codregimen, numdeclaracion, fechaVencimiento);
					if (CollectionUtils.isEmpty(expedienteSuspension)  ) {
						List<DatoIndicadores> listIndicadorAbandonoVol = 
								funcionesService.getIndicadorDUA(numCorredoc, ConstantesDataCatalogo.INDICADOR_ABANDONO_VOLUNTARIO, null, ConstantesDataCatalogo.IND_ACTIVO);
						if (CollectionUtils.isEmpty(listIndicadorAbandonoVol)){
							if (fechaSegundaGED == null || SunatDateUtils.isDefaultDate(fechaSegundaGED )){
								//DUAs Urgente transmitidas para su regularizacin no cuentan con GED de 2da Recepcin
								listerror.add(getDUAError("30763",new Object[]{CDApendiente}));
								//No ha presentado expediente de suspensin de plazo
								if (!listerror.contains(getDUAError("30764",new Object[]{CDApendiente}))){
									listerror.add(getDUAError("30764",new Object[]{CDApendiente}));
								}
							}
						}
					}					
				}			
				// ahora nos vamos a obtener las declaraciones pendientes del SIGAD
				//List<TabImpDU> listDeclaracionSIGAD = 
				GetDeclaracionSIGADService getDeclaracionSIGADService = fabricaDeServicios.getService("declaracionSIGADService");	
				List<TabImpDU> listdeclaracionPendienteSIGAD = getDeclaracionSIGADService.getDeclaracionPendienteRegularizarSIGAD(declaracion.getDua().getDeclarante(), declaracion.getCodaduana(),fechareferencia, ConstantesDataCatalogo.TIPO_DESPACHO_URGENTE);
				for(TabImpDU declaracionPendiente:listdeclaracionPendienteSIGAD){
					String codaduana = declaracionPendiente.getCodiAduan();
					String annpresen = declaracionPendiente.getAnoPrese();
					String codregimen= declaracionPendiente.getCodiRegi();
					String numdeclaracion = declaracionPendiente.getNumeCorre();
					Date fechaVencimiento = SunatDateUtils.getDateFromInteger(declaracionPendiente.getFechVenci());
					Date fechaSegundaGED = getDeclaracionSIGADService.getFechaSegundaRecepcionSIGAD(codaduana, annpresen, codregimen, numdeclaracion);
					String CDApendiente = codaduana.concat("-").concat(annpresen).concat("-").concat(codregimen).concat("-").concat(numdeclaracion);
					List<Map<String, Object>> expedienteSuspension = funcionesService.buscarExpedienteSuspension(codaduana, annpresen, codregimen, numdeclaracion,fechaVencimiento);					
					if (CollectionUtils.isEmpty(expedienteSuspension)  ) {
						if (fechaSegundaGED == null || SunatDateUtils.isDefaultDate(fechaSegundaGED )){
							if (!listerror.contains(getDUAError("30764",new Object[]{CDApendiente}))){
								listerror.add(getDUAError("30764",new Object[]{CDApendiente}));
							}
							listerror.add(getDUAError("30763",new Object[]{CDApendiente}));
						} else { //puede estar observada
							if (SunatStringUtils.include(declaracionPendiente.getFlagAnul(), 
									new String[]{ConstantesDataCatalogo.ESTADO_OBSERVADO_PLAZO_VENCIDO, ConstantesDataCatalogo.ESTADO_OBSERVADO_NOTIFICADO, ConstantesDataCatalogo.ESTADO_OBSERVADO_NOREGULARIZADA_FIE})) {								
								listerror.add(getDUAError("30762",new Object[]{CDApendiente}));
							}
						}
					}
				}
			}			
		}
		return listerror;
	}
	/*	private List<Map<String, Object>> buscarExpedienteSuspension(String codaduana, String annpresen, String codregimen, String numdeclaracion){
		ExpedienteService expedienteService = fabricaDeServicios.getService("tramite.ExpedienteService");
		Map<String, Object> paramsExpedi = new HashMap<String, Object>();
		paramsExpedi.put("PROCEDIM", Constants.CODIGO_TUPA_SUSPENSION_PLAZO);
		paramsExpedi.put("ANN_PRESEN", annpresen);
		paramsExpedi.put("NUM_DECLARACION", numdeclaracion);
		paramsExpedi.put("COD_ADUANA", codaduana);
		paramsExpedi.put("COD_REGIMEN", codregimen);
		paramsExpedi.put("TIPO_CONC", Constants.CODIGO_EXPEDIENTE_CONCLUIDO);
		List<Map<String,Object>> listExpedi =  expedienteService.findByDocumentoOrigen(paramsExpedi);
		return listExpedi;
	}
	 */	
	/**
	 * Generar tipo despacho.
	 * 
	 * @param declaracion Declaracion
	 * @return String, el codigo de tipo de despacho 
	 */
	private String generarTipoDespacho(Declaracion declaracion) {		
		String tipoDesp="";
		DatoManifiesto manif=declaracion.getDua().getManifiesto();
		Date fectermino=manif!=null?manif.getFectermino():null;
		//PAS20145E220000090 - MATC 20140617  INICIO
		if( fectermino!=null && SunatDateUtils.sonIguales(fectermino, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
			fectermino = declaracion.getDua().getFecLlegada();
		}
		//PAS20145E220000090 - MATC 20140617  FINAL
		if ( "10".equals( declaracion.getDua().getCodmodalidad() ) || 
				("01".equals(declaracion.getDua().getCodmodalidad()) 
						&& SunatDateUtils.getIntegerFromDate(fectermino)>SunatDateUtils.getCurrentIntegerDate() )){
			tipoDesp="TA";
		}else if ("00".equals(declaracion.getDua().getCodmodalidad()) || ("01".equals(declaracion.getDua().getCodmodalidad()) && SunatDateUtils.getIntegerFromDate(fectermino)<=SunatDateUtils.getCurrentIntegerDate() )){
			tipoDesp="TE";
		}
		return tipoDesp;
	}
	/**
	 * Establece un valor a fabricaDeServicios.
	 * 
	 * @param fabricaDeServicios FabricaDeServicios
	 */
	/*
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	 */
	/**
	 * Establece un valor a enableSwapperDataSource.
	 * 
	 * @param enableSwapperDataSource boolean
	 */
	public void setEnableSwapperDataSource(boolean enableSwapperDataSource) {
		this.enableSwapperDataSource = enableSwapperDataSource;
	}
	/**
	 * Establece un valor a swapperDatasourceLectura.
	 * 
	 * @param swapperDatasourceLectura HotSwappableTargetSource
	 */
	
	/*
	public void setSwapperDatasourceLectura(
			HotSwappableTargetSource swapperDatasourceLectura) {
		this.swapperDatasourceLectura = swapperDatasourceLectura;
	}
	 */
	/**
	 * Establece un valor a swapperDatasourceEscritura.
	 * 
	 * @param swapperDatasourceEscritura HotSwappableTargetSource
	 */
	public void setSwapperDatasourceEscritura(
			HotSwappableTargetSource swapperDatasourceEscritura) {
		this.swapperDatasourceEscritura = swapperDatasourceEscritura;
	}
	/**
	 * Establece un valor a envioDAO.
	 * 
	 * @param envioDAO EnvioDAO
	 */
	/*
	public void setEnvioDAO(EnvioDAO envioDAO) {
		this.envioDAO = envioDAO;
	}
	 */
	//lmvr RN 175 - Parte I
	public int obtenerDocTransporte(List<DatoDocTransporte> docutransSerie, String numDocTransporte){
		int indice = 0;
		for(DatoDocTransporte docTransp : docutransSerie) {
			if (numDocTransporte.equals(String.valueOf(docTransp.getNumdoctransporte()))) {
				return indice;
			}
			indice++;
		}
		return -1;
	}
	public int obtenerDocTransporteAll(List<DatoDocTransporte> docutransSerie, Integer numeroDetalle){
		int indice = 0;
		for(DatoDocTransporte docTransp : docutransSerie) {
			if (numeroDetalle.equals(docTransp.getNumdetalle())) {
				return indice;
			}
			indice++;
		}
		return -1;
	}
	//Inicio M_SNADE255-2 - PercyHM 2016/07/14 - Adecuacin a la destinacin con punto de llegada deposito aduanero sin transmitir regimen precedente 70
	private boolean validaDocTransporteAsociadoDuaDepositoDesdatadaLegajada(Declaracion declaracion, DUA dua, List<DatoDocTransporte> lstdocumentostrans){
		//Busca si los documentos de transporte asociado a una serie se encuentra en una dua 70 desdatada y legajada
		boolean rpta = false;
		Datado2ValidacionService datado2ValidacionService = fabricaDeServicios.getService("manifiesto.datado2ValidacionService");
		ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduanero = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		String annManifiesto = SunatStringUtils.substringFox(dua.getManifiesto().getAnnmanif(), 1, 4);
		String numManifiesto = dua.getManifiesto().getNummanif();
		int cnt_doctransporte = 0;
		int cnt_doctransporte_legajadas_reg70 = 0;
		cnt_doctransporte = lstdocumentostrans!=null?lstdocumentostrans.size():0; 
		for(DatoDocTransporte datoDocTransporte:lstdocumentostrans){
			Map<String, Object> paramDatado = new HashMap<String, Object>();
			//Busca destinaciones del documento de transporte al regimen 70 que se encuentren desdatadas
			paramDatado.put("codigoAduana", dua.getManifiesto().getCodaduamanif());
			paramDatado.put("anioManifiesto", SunatStringUtils.length( annManifiesto)>3?Integer.parseInt( annManifiesto.substring(2,4)):"0");  //PAS20175E220200059
			paramDatado.put("numeroManifiesto", SunatStringUtils.lpad(numManifiesto, 5, ' '));
			paramDatado.put("codigoTipoManifiesto", dua.getManifiesto().getCodtipomanif());
			paramDatado.put("numeroDocumentoTransporte", datoDocTransporte.getNumdoctransporte());
			paramDatado.put("codregimen", "70");
			paramDatado.put("sregul", "A");					
			List<Map<String,Object>> listDatado = datado2ValidacionService.consultarDatado(paramDatado);	
			//Recorre las declaraciones encontradas para verificar si encuentran legajadas
			if(listDatado != null && listDatado.size() > 0){
				int cnt_registros_datado = listDatado.size();
				int cnt_registros_datado_legajado = 0;
				for(Map<String,Object> mapDatado:listDatado){
					//Busca la Declaracion en N
					Map<String, Object> parametrosDeclaracion = new HashMap<String, Object>();
					parametrosDeclaracion.put("codigoAduana", mapDatado.get("ADU_DESTI"));
					parametrosDeclaracion.put("numeroDeclaracion", mapDatado.get("NUME_REG"));
					parametrosDeclaracion.put("annoPresentacion", "20" + mapDatado.get("ANNO_REG"));
					parametrosDeclaracion.put("codigoRegimen", mapDatado.get("REG_DESTI"));
					DUA duaDeposito = cabDeclaraDAO.findDUAByKeyMap(parametrosDeclaracion);
					if(duaDeposito == null){
						//Busca la Declaracin en A
						parametrosDeclaracion = new HashMap<String, Object>();
						parametrosDeclaracion.put("codiAduan", mapDatado.get("ADU_DESTI"));
						parametrosDeclaracion.put("numeCorre", mapDatado.get("NUME_REG"));
						parametrosDeclaracion.put("anoPrese", mapDatado.get("ANNO_REG"));
						parametrosDeclaracion.put("codiRegi", mapDatado.get("REGI_DESTI"));
						List<Polizad> listaDeposito = consultaDeclaracionDepositoAduanero.consultarDeclaracionDeposito(parametrosDeclaracion, mapDatado.get("ADU_DESTI").toString());
						if(listaDeposito != null && listaDeposito.size() > 0){
							Polizad polizad = listaDeposito.get(0);
							if(polizad.getFechLega() != null && polizad.getFechLega().doubleValue() > 0){
								//Declaracin de deposito se encuentra legajado
								cnt_registros_datado_legajado++;	
							}
						}
					}else{
						if(duaDeposito.getCodEstdua().equals(ConstantesDataCatalogo.COD_DUA_LEGAJADA)){
							//Declaracin de deposito se encuentra legajado
							cnt_registros_datado_legajado++;
						}
					}
				}
				if(cnt_registros_datado == cnt_registros_datado_legajado){
					cnt_doctransporte_legajadas_reg70++;
				}
			}
		}
		if(cnt_doctransporte_legajadas_reg70 == cnt_doctransporte){
			//Se encontraron en todos los documentos de transporte asociados a una serie, que se encuentra en una dua desdatada y legajada
			rpta = true;
		}
		return rpta;
	}
	//Fin M_SNADE255-2 
	//lmvr RN 175 - Parte II
	@ServicioAnnot(tipo="V",codServicio=2498, descServicio="valida prorrateoFlete")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2498,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> prorrateoFlete(Declaracion declaracion) {
		List<DatoDocTransporte> docutransSerieFOB = new ArrayList<DatoDocTransporte>(); 
		List<DatoDocTransporte> docutransSeriePeso = new ArrayList<DatoDocTransporte>();	
		List<DatoDocTransporte> docutransSeriePesoAux = new ArrayList<DatoDocTransporte>(); 
		List<DatoDocTransporte> docutransSeriePesoAuxTipo = new ArrayList<DatoDocTransporte>(); 
		List<DatoSerie> serieFlete2 = new ArrayList<DatoSerie>();
		List<DatoSerie> serieFlete3 = new ArrayList<DatoSerie>(); 
		DUA dua=declaracion.getDua();
		Elementos<DatoSerie> series=dua.getListSeries();
		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;	 
		BigDecimal mflete= new BigDecimal(0); //jreynoso bug18651
		for(DatoSerie serie : series) {
			if(!serie.getCodtipoflete().equals("1")){
				DatoDocTransporte docutransSerie = getDocTransporte(dua, serie);
				if(docutransSerie==null){
					return  lstErrores;
				}
				int indicePeso = obtenerDocTransporte(docutransSeriePeso, docutransSerie.getNumdoctransporte().toString());
				if (indicePeso != -1) {//existe
					//obtienes el existente
					DatoDocTransporte datoDocumentoTransportePeso = docutransSeriePeso.get(indicePeso);
					DatoDocTransporte datoDocumentoTransportePesoTipo = docutransSeriePesoAuxTipo.get(indicePeso);
					//acumular al existente
					datoDocumentoTransportePeso.setCntpesobruto(serie.getCntpesobruto().add(datoDocumentoTransportePeso.getCntpesobruto()));
					datoDocumentoTransportePeso.setMtofledol(serie.getMtofledol().add(datoDocumentoTransportePeso.getMtofledol()));
					datoDocumentoTransportePesoTipo.setCntpesobruto(serie.getCntpesobruto().add(datoDocumentoTransportePesoTipo.getCntpesobruto()));
					datoDocumentoTransportePesoTipo.setMtofledol(serie.getMtofledol().add(datoDocumentoTransportePesoTipo.getMtofledol()));
				} else {//no existe							
					DatoDocTransporte datoDocumentoTransportePeso = new DatoDocTransporte();
					DatoDocTransporte datoDocumentoTransportePesoTipo = new DatoDocTransporte();
					datoDocumentoTransportePeso.setCntpesobruto(serie.getCntpesobruto());				
					datoDocumentoTransportePeso.setMtofledol(serie.getMtofledol());
					datoDocumentoTransportePeso.setNumdoctransporte(docutransSerie.getNumdoctransporte());
					docutransSeriePeso.add(datoDocumentoTransportePeso);
					datoDocumentoTransportePesoTipo.setCntpesobruto(serie.getCntpesobruto());				
					datoDocumentoTransportePesoTipo.setMtofledol(serie.getMtofledol());
					datoDocumentoTransportePesoTipo.setNumdoctransporte(docutransSerie.getNumdoctransporte());
					docutransSeriePesoAuxTipo.add(datoDocumentoTransportePesoTipo);
				}
				//Acumular Docutrans por FOB y de no ser tipo 2 se inicializa
				int indiceFob = obtenerDocTransporte(docutransSerieFOB, docutransSerie.getNumdoctransporte().toString());
				if (indiceFob != -1) {
					if(serie.getCodtipoflete().equals("2") && serie.getMtofobdol()!=null){
						DatoDocTransporte datoDocumentoTransporteFob = docutransSerieFOB.get(indiceFob);
						datoDocumentoTransporteFob.setMtofobdol(serie.getMtofobdol().add(datoDocumentoTransporteFob.getMtofobdol()));
					}
				} else{
					if(serie.getCodtipoflete().equals("2") && serie.getMtofobdol()!=null){
						DatoDocTransporte datoDocumentoTransporteFob = new DatoDocTransporte();
						datoDocumentoTransporteFob.setMtofobdol(serie.getMtofobdol());
						datoDocumentoTransporteFob.setNumdoctransporte(docutransSerie.getNumdoctransporte());
						docutransSerieFOB.add(datoDocumentoTransporteFob);
					}else{
						DatoDocTransporte datoDocumentoTransporteFob = new DatoDocTransporte();
						datoDocumentoTransporteFob.setMtofobdol(BigDecimal.valueOf(0));
					}
				}
			}
			//Agrupar por tipo de Flete 2 y 3
			if(serie.getCodtipoflete().equals("3")){
				DatoSerie serieAgruparFlete3 = new DatoSerie();
				serieAgruparFlete3.setNumserie(serie.getNumserie());
				serieAgruparFlete3.setCodtipoflete(serie.getCodtipoflete());
				serieFlete3.add(serieAgruparFlete3);
			}else if(serie.getCodtipoflete().equals("2")){
				DatoSerie serieAgruparFlete2 = new DatoSerie();
				serieAgruparFlete2.setNumserie(serie.getNumserie());
				serieAgruparFlete2.setCodtipoflete(serie.getCodtipoflete());
				serieFlete2.add(serieAgruparFlete2);
			}
			mflete=SunatNumberUtils.sum(mflete,serie.getMtofledol()); //jreynoso bug18651
		}
		// Se empieza un auxiliar para ir descontando el peso con tipo 3
		docutransSeriePesoAux =  new ArrayList<DatoDocTransporte>(docutransSeriePeso); 
		//docutransSeriePesoAuxTipo =  new ArrayList<DatoDocTransporte>(docutransSeriePeso); 
		for(DatoSerie serie : series) {
			BigDecimal fleteSerieCalculado = BigDecimal.ZERO;
			DatoDocTransporte docutransSerie = getDocTransporte(dua, serie);
			if(serie.getCodtipoflete().equals("1")) {
				fleteSerieCalculado=serie.getMtofledol();
			}
		}
		boolean errorPorEnvioTotalFlete= false;
		for(DatoSerie serieTipoFlete3 : serieFlete3) {
			for(DatoSerie serie : series) {
				BigDecimal fleteSerieCalculado = BigDecimal.ZERO;
				BigDecimal fleteSerieCalculadoTipo = BigDecimal.ZERO;
				BigDecimal mtoMultiplicaPeso       = BigDecimal.ZERO;
				BigDecimal mtoMultiplicaPesoTipo       = BigDecimal.ZERO;
				BigDecimal mtoMultiplicaFob       = BigDecimal.ZERO;
				BigDecimal mtoDiferenciaFlete       = BigDecimal.ZERO;
				DatoDocTransporte docutransSerie = getDocTransporte(dua, serie);	
				boolean verificarDiferenciaPeso = true; //gmontoya Pase 443 - 2015
				if ((serie.getNumserie().equals(serieTipoFlete3.getNumserie()))) {		
					if(serie.getCodtipoflete().equals("3")){
						for(DatoDocTransporte docTransp : docutransSeriePeso) {
							if ((docutransSerie.getNumdoctransporte().equals(docTransp.getNumdoctransporte()))) {
								for(DatoDocTransporte docTranspTipo : docutransSeriePesoAuxTipo) {
									if ((docutransSerie.getNumdoctransporte().equals(docTranspTipo.getNumdoctransporte()))) {
										if(SunatNumberUtils.isGreaterThanZero(docTranspTipo.getCntpesobruto())){	//gmontoya Pase 443 - 2015					
											mtoMultiplicaPeso = docTranspTipo.getMtofledol().setScale(3).multiply(Utilidades.toBigDecimal(serie.getCntpesobruto()));
											fleteSerieCalculado = mtoMultiplicaPeso.divide(docTranspTipo.getCntpesobruto(), 3, BigDecimal.ROUND_HALF_DOWN);
											int indicePeso = obtenerDocTransporte(docutransSeriePesoAux, docutransSerie.getNumdoctransporte().toString());
											if (indicePeso != -1){
												DatoDocTransporte datoDocumentoTransportePesoAux = docutransSeriePesoAux.get(indicePeso);
												mtoDiferenciaFlete = datoDocumentoTransportePesoAux.getMtofledol().setScale(3).subtract(fleteSerieCalculado.setScale(3));
												datoDocumentoTransportePesoAux.setMtofledol(mtoDiferenciaFlete);
											}
										}else{//gmontoya Pase 443 - 2015	
											verificarDiferenciaPeso = false;
											lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35575",new String[]{"PESO BRUTO",String.valueOf(serie.getNumserie()),"PESO"}));//gmontoya Pase 443 - 2015	
										}//gmontoya Pase 443 - 2015	
									}
								}
							}
						} 
					}
					//Se evalua flete declarado
					if(verificarDiferenciaPeso){//gmontoya Pase 443 - 2015		
						BigDecimal diferencia = SunatNumberUtils.diference(fleteSerieCalculado, serie.getMtofledol());
						//pase139
						if ( SunatNumberUtils.absoluteDiference(dua.getMtotflecomex(), mflete).doubleValue() <= 1D){	 //jreynoso 	bug18651
							// BigDecimal totalflete = dua.getMtotflecomex();
							// if ( mflete.compareTo(totalflete) == 0){					 
							if(Math.abs(diferencia.doubleValue())>ConstantesTipoCatalogo.DIFERENCIA_MINIMA){
								//					 lstErrores.add(catalogoHelper.getErrorMap("30590",new Object[]{serie.getNumserie(),serie.getMtofledol(),fleteSerieCalculado}));
								lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30590",new String[]{String.valueOf(serie.getNumserie()),String.valueOf(serie.getMtofledol()),String.valueOf(fleteSerieCalculado)}));
							}
						}
						//else{
						//   errorPorEnvioTotalFlete=true;
						//}
					}//gmontoya Pase 443 - 2015		
				}
			}
		}
		//  if (errorPorEnvioTotalFlete){
		//	   lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("37003",new String[]{String.valueOf(dua.getMtotflecomex()),String.valueOf(mflete)}));
		//  }
		for(DatoSerie serieTipoFlete2 : serieFlete2) {
			for(DatoSerie serie : series) {
				BigDecimal fleteSerieCalculado = BigDecimal.ZERO;
				BigDecimal mtoMultiplicaFob       = BigDecimal.ZERO;
				DatoDocTransporte docutransSerie = getDocTransporte(dua, serie);
				//for(DatoSerie serieTipoFlete2 : serieFlete2) {
				if ((serie.getNumserie().equals(serieTipoFlete2.getNumserie()))) {		
					if(serie.getCodtipoflete().equals("2")){
						for(DatoDocTransporte docTransp : docutransSerieFOB) {
							if ((docutransSerie.getNumdoctransporte().equals(docTransp.getNumdoctransporte()))) {
								int indiceFOBAux = obtenerDocTransporte(docutransSeriePesoAux, docutransSerie.getNumdoctransporte().toString());
								if (indiceFOBAux != -1){
									if(SunatNumberUtils.isGreaterThanZero(docTransp.getMtofobdol())){//gmontoya Pase 443 - 2015
										DatoDocTransporte datoDocumentoTransportePesoAux = docutransSeriePesoAux.get(indiceFOBAux);
										mtoMultiplicaFob = datoDocumentoTransportePesoAux.getMtofledol().setScale(3).multiply(Utilidades.toBigDecimal(serie.getMtofobdol())); ;
										fleteSerieCalculado = mtoMultiplicaFob.divide(docTransp.getMtofobdol(), 3, BigDecimal.ROUND_HALF_DOWN);
									}else{//gmontoya Pase 443 - 2015	
										lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35575",new String[]{"FOB",String.valueOf(serie.getNumserie()),"FOB"}));//gmontoya Pase 443 - 2015	
									}//gmontoya Pase 443 - 2015
								}
								//break;
							}
						}
					}
					//Se evalua flete declarado
					BigDecimal diferencia = SunatNumberUtils.diference(fleteSerieCalculado, serie.getMtofledol());
					//valida el prorrateo siempre y cuando el valor del flete de la cabecera sea igual a la sumatoria de fletes de las series
					if ( SunatNumberUtils.absoluteDiference(dua.getMtotflecomex(), mflete).doubleValue() <= 1D){	 //jreynoso bug18651		 
						if(Math.abs(diferencia.doubleValue())>ConstantesTipoCatalogo.DIFERENCIA_MINIMA){
							//SERIE[{0}]: FLETE[{1}] NO COINCIDE CON EL CALCULADO POR EL SISTEMA [{2}] 
							//					 lstErrores.add(catalogoHelper.getErrorMap("30590",new Object[]{serie.getNumserie(),serie.getMtofledol(),fleteSerieCalculado}));
							lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30590",new String[]{String.valueOf(serie.getNumserie()),String.valueOf(serie.getMtofledol()),String.valueOf(fleteSerieCalculado)}));
						}
					}
				} 		
			}
		}
		return  lstErrores;
	}
	public void prorrateoFleteEER(Declaracion declaracion){
		DUA dua = declaracion.getDua();
		BigDecimal fleteTotal = dua.getMtotflecomex();
		BigDecimal pesoBrutoTotal = dua.getCnttpesobruto();
		for(DatoSerie serie:dua.getListSeries()){
		    //Antes de del prorrateo se setea una variable temporal para validar luego que tengas valores mayor a cero
            serie.setMtofledoltmp(serie.getMtofledol());
            //Inicio srodriguez
            if(pesoBrutoTotal.compareTo(new BigDecimal("0.00"))==0){
            	pesoBrutoTotal=new BigDecimal("1.00");
            }
            //Fin srodeiguez
			BigDecimal fleteSerie = fleteTotal.multiply(serie.getCntpesobruto()).divide(pesoBrutoTotal, 3, BigDecimal.ROUND_HALF_DOWN);
			serie.setMtofledol(fleteSerie);
			serie.setCodtipoflete(ConstantesDataCatalogo.COD_TIPO_PRORRATEO_PORPESO);
		}
	}
	
	public void calculoSeguro(Declaracion declaracion){
		DUA dua = declaracion.getDua();
		BigDecimal mtoSeguro0 = BigDecimal.ZERO;
		BigDecimal fobSeguro = BigDecimal.ZERO;//mlaura PAS20181U220400008-IZV-120
		HashMap<String,Object> mapNandtasa=new HashMap<String,Object>();
		List<Map<String,Object>> listNandTasa = new ArrayList<Map<String,Object>>();
		Map<String,Object> nandtasa = new HashMap<String,Object>();
		for(DatoSerie serie : dua.getListSeries()){
			if(serie.getMtosegdol().compareTo(mtoSeguro0)==1){
				serie.setCodtiposeg(ConstantesDataCatalogo.SEGURO_INDIVIDUAL);
			}else{
				//se obtiene de nandtasa de acuerdo a la partida.
				NandTasaDAO nandTasaDao = (NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO");
				mapNandtasa.put("cnan", serie.getNumpartnandi());
				mapNandtasa.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
				listNandTasa = nandTasaDao.findByMap(mapNandtasa);
				if(!CollectionUtils.isEmpty(listNandTasa)){
					nandtasa = listNandTasa.get(0);
					fobSeguro = serie.getMtofobdol();//mlaura PAS20181U220400008-IZV-120
					//serie.setMtosegdol((BigDecimal) nandtasa.get("tseguro"));
					//serie.setMtosegdol(fobSeguro.multiply((BigDecimal) nandtasa.get("tseguro")));//mlaura PAS20181U220400008-IZV-120
					serie.setMtosegdol(fobSeguro.multiply((BigDecimal) nandtasa.get("tseguro")).divide(new BigDecimal(100)));//mlaura PAS20181U220400008-IZV-120
					serie.setCodtiposeg(ConstantesDataCatalogo.SEGURO_ARANCEL);
				}
			}
		}
	}
	/*
	 * Pase308
	 * Vigencia para la aduana  maritima
	 * 
	 * 
	 */
	public List<Map<String,String>>  validarAduanaMaritimaExcepcional(Declaracion declaracion 	){ 
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String,String>> listerror = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		String codigoModalidadDespacho = dua.getCodmodalidad();
		//String numeroRUCduenioConsignatario = dua.getDeclarante().getNumeroDocumentoIdentidad();
		String codAduana = dua.getCodaduanaorden();
		Date fecIniVigencia =	 SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.INICIO_VIGENCIA_ADUANA_MARITIMA, "FEC_INIVIG").get("des_datacat").toString());
		Date fecFinVigencia =	 SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.INICIO_VIGENCIA_ADUANA_MARITIMA, "FEC_FINVIG").get("des_datacat").toString());
		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecIniVigencia, SunatDateUtils.COMPARA_SOLO_FECHA) && 
				SunatDateUtils.esFecha1MenorQueFecha2(new Date(), fecFinVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			if ((!ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL.equals(codigoModalidadDespacho) && ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(codAduana)) || 
					(!Constants.REGIMEN_IMPORTACION_CONSUMO.toString().equals(dua.getCodregimen()) && (ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(codAduana)) )) { 
				listerror.add(getDUAError("35571", new Object[] {}));
				return listerror;
			}		
		} 
		if(ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(codAduana) && SunatDateUtils.esFecha1MenorQueFecha2(new Date(), fecIniVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			listerror.add(getDUAError("35573", new Object[] {DateUtil.dateToStringSilent(fecIniVigencia, "dd/MM/yyyy")}));
			return listerror;
		}		
		//Validaciones por regimen en Maritima
		Date fecIniVigenciaRegimen =	 SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.INICIO_VIGENCIA_ADUANA_MARITIMA, "FECINIVIG"+dua.getCodregimen()).get("des_datacat").toString());
		Date fecFinVigenciaRegimen =	 SunatDateUtils.getDate(catalogoAyudaService.getElementoCat(ConstantesDataCatalogo.INICIO_VIGENCIA_ADUANA_MARITIMA, "FECFINVIG"+dua.getCodregimen()).get("des_datacat").toString());
		if (!(SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecIniVigenciaRegimen, SunatDateUtils.COMPARA_SOLO_FECHA) && 
				SunatDateUtils.esFecha1MenorQueFecha2(new Date(), fecFinVigenciaRegimen, SunatDateUtils.COMPARA_SOLO_FECHA)) && 
				ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(codAduana) ){
			listerror.add(getDUAError("35613", new Object[] {}));
			return listerror;
		}		
		return listerror; 
	}
    		
		
	/**
	 * Verifica que la orden interna del operador no se encuentre numerada
	 * 
	 * <pre>
	 * Query sugerido:
	 * select * from cab_declara a,participante_doc b
	 * where a.cod_aduana=&lt;cdigo de aduana&gt; and a.cod_regimen=&lt;cdigo de rgimen&gt; and a.ann_orden=&lt;ao de la orden&gt; and a.num_orden=&lt;nro. de la orden&gt;
	 * and b.num_corredoc=a.num_corredoc and b.cod_tippartic=&lt;Tipo Operador&gt;and b.cod_tipdoc=&lt;tipo Documento&gt; and
	 * b.num_docident=&lt;RUC del agente
	 * 
	 * </pre>
	 * @author hacostar 
	 * @param declaracion Declaracion, declaracion a evaluar
	 * @param tipOperadorSender String, tipo de Operador del sender
	 * @param tipoDocumentoIdentidadSender String, tipo de documento del sender
	 * @param numeroDocumentoIdentidadSender String, numero de documento del sender
	 * @param numOrden String, numero de la orden
	 * @return el mapa de errores de validacion
	 */
	public Map<String,String> validarOrdenDuplicada(Declaracion declaracion, String tipOperadorSender, String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender, String numOrden, String codTransaccion)  throws Exception{
		Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();
		paramsCabDeclara.put("codAduana", declaracion.getDua().getCodaduanaorden());
		paramsCabDeclara.put("codRegimen", declaracion.getDua().getCodregimen());
		paramsCabDeclara.put("annOrden", numOrden.substring(0, 4));
		paramsCabDeclara.put("numOrden", numOrden.substring(4,10));
		paramsCabDeclara.put("tipOperador", tipOperadorSender);
		paramsCabDeclara.put("tipDocuOperador", ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC);
		paramsCabDeclara.put("numDocuOperador", numeroDocumentoIdentidadSender);
		
		//RC: Se realiza cambio en la validacion por contingentes.
		//ES: Se realiza cambio para agregar numero de Declaracion en el mensaje de respuesta.
		//DUA dua = FormatoAServiceImpl.getInstance().getCabDeclaraDAO().selectDuaNumeradabyNumOrden(paramsCabDeclara);
		DUA dua = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).selectDuaNumeradabyNumOrden(paramsCabDeclara);
		
		//LMVR: RN 130  Orden Duplicada
		if ( dua != null){ //Si encuentra registro: "Orden de envio se encuentra numerada"						
			Map<String,Object> paramsMap=new HashMap<String,Object>(); 
			//paramsMap.put("codTransaccion", codTransaccion); 
			paramsMap.put("idEmisor", numeroDocumentoIdentidadSender);
			paramsMap.put("annRefemisor", numOrden.substring(0, 4));
			paramsMap.put("numRefemisor", numOrden.substring(4,10));
			paramsMap.put("codLugarEnvio",  declaracion.getDua().getCodaduanaorden());
			paramsMap.put("codTransaccion",  codTransaccion);
			paramsMap.put("codEstado", "1");
			
			List<EnvioBean> listEnvio;
			//Long numCorredoc = declaracion.getNumeroCorrelativo();
			EnvioDAO envioDAO = fabricaDeServicios.getService("manifiesto.envioDAO");
			listEnvio=envioDAO.listByParameterMap(paramsMap);
			if (listEnvio!=null && !listEnvio.isEmpty()){
				Long numEnvio = listEnvio.get(0).getNumeroEnvio();
				return getDUAError("00001",new Object[]{(declaracion.getDua().getCodaduanaorden() + "-" + numOrden.substring(0, 4) + "-" + declaracion.getDua().getCodregimen() + "-" + SunatStringUtils.lpad(dua.getNumdocumento(),6,'0')),numEnvio.toString()});
			}				
			
			return getDUAError("00001",new Object[]{declaracion.getDua().getCodaduanaorden() + "-" + numOrden.substring(0, 4) + "-" + declaracion.getDua().getCodregimen() + "-" + SunatStringUtils.lpad(dua.getNumdocumento(),6,'0')});
		}
		return new HashMap<String,String>();
	}
	
		/**
	     * rtineo M_SNADE278_1: retorna si la declaracion aplica para una dam Diferida SIN ICA
	     * @param declaracion declaracion transmitida
	     * @param variablesIngreso Variables de validacion de un determinado proceso
	     * @return errores de validacion
	     **/
		@ServicioAnnot(tipo = "V", codServicio = 3481, descServicio = "Almacena si la variable es DAM Diferida")
		@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
		@OrquestaDespaAnnot(codServInstancia = 3481, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
		@Override
        public Map<String, String> validarDAMDiferidaSinICA(Declaracion declaracion, Map<String,Object> variablesIngreso){
	        Map<String,String> mapErrores  = new HashMap<String,String>();
	        variablesIngreso.put("isDAMDiferidaSinIca", false);
	        variablesIngreso.put("manifiestoForValidationDAMDiferidaSinIca", null);
	        DUA dua = declaracion.getDua();
		    Map<String,Object> mapResultado = isDAMDiferidaSinICA(dua); //esto valida por SDA solamente
	        
        	//guardamos en variablesIngreso PAS20181U220200004
		    ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
		    Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();
		    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false;
	        if((Boolean)mapResultado.get("flag")){
	        	      	
	        	variablesIngreso.put("isDAMDiferidaSinIca", true);
	        	variablesIngreso.put("manifiestoForValidationDAMDiferidaSinIca", (Manifiesto)mapResultado.get("manifiesto"));
	        	/*EDU coordinar� con Paul PAS20181U220200064*/
				if(esVigenteRIN05SegundaParte) {//inicio pase 04 pruizcr
					//Elementos<DatoIndicadores> listIndicadores = new Elementos<DatoIndicadores>();
					DatoIndicadores indicadoresRef = new DatoIndicadores();
					indicadoresRef.setCodigoIndicador("54");
					indicadoresRef.setIndicadorActivo("01");
					indicadoresRef.setCodtipoindica("54");
					indicadoresRef.setCodigoTipoRegistro("T");
					//listIndicadores.add(indicadoresRef);
					declaracion.getDua().getListIndicadores().add(indicadoresRef);
					//declaracion.getDua().setListIndicadores(listIndicadores);
				}//fin pase 04 pruizcr
	        }
	        
	        //validar IQF
	        boolean esExcepcional = "00".equals(dua.getCodmodalidad())?true:false;						
			if(esExcepcional ){   
				mapErrores  = validarIQFDespachoDiferidoSinPesosBultosRecibidos(declaracion,variablesIngreso)	;
			}

	        return mapErrores;
	    }
		//RIN DE MPN Declaraciones Diferidas Sin ICA sup 5-Nico
		@Override
		public Map<String,Object> isDAMDiferidaSinICA(DUA dua){
			Map<String,Object> mapReturn = new HashMap<String,Object>();
			mapReturn.put("flag", false);
			
		    Date fechaHoy = SunatDateUtils.getCurrentDate();
		    ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		    boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false; //csantillan PAS20181U220200054


			/**PAS20181U220200004 inicio***/
			Date fechaDeclaracion = dua.getFecdeclaracion()!=null?dua.getFecdeclaracion():new Date();
			boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false;
			/**PAS20181U220200004 fin***/
			//Validamos que el regimen sea importacion para el consumo
			String regimen = dua.getCodregimen();
			if(!ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(regimen)){
				return mapReturn;
			}
	        
	        //validamos la modalidad que sea excepcional.
	        String codModalidad = dua.getCodmodalidad();
	        if(!ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL.equals(codModalidad)){
	        	return mapReturn;
	        }
	        
	        //validamos si como punto de llegada esta poniendo 2:TP y no 1:DP.
	        if(!esVigenteRIN05SegundaParte){//R1828  y R1829
	        	if(!ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO.equals(dua.getCodlugarecepcion())){
			       	return mapReturn;
			    }
	        }
	        //consultamos si la DAM tiene manifiesto, si no tiene ya no realiza ninguna validacion.
	        DatoManifiesto datoManifiesto = dua.getManifiesto();
	        if(datoManifiesto == null || datoManifiesto.getCodtipomanif() == null  || datoManifiesto.getCodmodtransp() == null 
	        	|| datoManifiesto.getCodaduamanif() == null || datoManifiesto.getAnnmanif() == null ||datoManifiesto.getNummanif() == null){
	        	return mapReturn;
	        }
	        if(esVigenteRIN31){
	        	if (datoManifiesto != null ){//bug cs
	        		String numManif = datoManifiesto.getNummanif()!=null?datoManifiesto.getNummanif().trim():"0";
	        		if (numManif.equals("0")){
	        	return mapReturn;
	        		}
	        	}
			}
	        //consultamos el manifiesto para validar la vigencia.
	        ManifiestoService manifiestoService = (ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService");
	        String annmanif = SunatStringUtils.length(datoManifiesto.getAnnmanif()) > 3 ? datoManifiesto.getAnnmanif().substring(0, 4) : null;
	        
	        /** inicio PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:**/
			Manifiesto manifiesto = null;
			List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaDeclaracion);
			boolean considerarEER = dua.getCodlugarecepcion()!=null && dua.getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
			
			if(!ResponseListManager.responseListHasErrors(listaOMA)){
				manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(datoManifiesto.getCodtipomanif(),datoManifiesto.getCodmodtransp(),
		        		datoManifiesto.getCodaduamanif(),SunatNumberUtils.toInteger(annmanif),datoManifiesto.getNummanif(),true,fechaDeclaracion,considerarEER);					
			}else{
				manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(datoManifiesto.getCodtipomanif(),datoManifiesto.getCodmodtransp(),
		        		datoManifiesto.getCodaduamanif(),SunatNumberUtils.toInteger(annmanif),datoManifiesto.getNummanif());					
			}
			/***fin PAS20181U220200049***/
	        
	        //Manifiesto manifiesto = manifiestoService.findManifiestoByClaveDeNegocio(datoManifiesto.getCodtipomanif(),datoManifiesto.getCodmodtransp(),
	        //		datoManifiesto.getCodaduamanif(),SunatNumberUtils.toInteger(annmanif),datoManifiesto.getNummanif());
	        
	        if(manifiesto==null){ //ya existe una validacion que arroja el mensaje de error
	        	return mapReturn;
	        }
	        
	        if(manifiesto.getFechaEfectivaDeLlegada() == null){ //ya existe una validacion que arroja el mensaje de error
	        	return mapReturn;
	        }
			if(!esVigenteRIN05SegundaParte) {
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				DataCatalogo datacatalogo = catalogoAyudaService.getDataCatalogo("992", "FEC_INIVIG", manifiesto.getFechaEfectivaDeLlegada());
				if (datacatalogo == null) //vigencia cerrada
					return mapReturn;
			}
			// validad si no tiene pesos y bultos recibidos
			if(esVigenteRIN05SegundaParte) {
			Map mapErrores = validaExistenciaPesoyBustosRecibidosParaDAMDiferida(dua,manifiesto);
			if(mapErrores.isEmpty()){
				return mapReturn;//esto retornara el false
			}
			}
	        mapReturn.put("flag", true);
	        mapReturn.put("manifiesto", manifiesto);
	        return mapReturn;
		}
        
		@ServicioAnnot(tipo = "V", codServicio = 3482, descServicio = "valida si la Nota de tarja de la DAM diferida no existe para todos los documentos")
		@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
		@OrquestaDespaAnnot(codServInstancia = 3482, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
		@Override
		public Map<String, String> validaNoExistenciaNotaTarjaParaDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso){
			Map mapErrores = new HashMap<String, Object>();
			Boolean isDAMDiferida = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
			Manifiesto manifiesto = variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca")!=null?(Manifiesto)variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca"):null;
			Boolean isRectiDiferidaNormal = variablesIngreso.get("isRectiDiferidaNormal")!=null?(Boolean)variablesIngreso.get("isRectiDiferidaNormal"):false;
			/* inicio PAS20181U220200004*/
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
			Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();
			boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaDeclaracion):false;
			boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false; //PAS20181U220200064
			/* fin PAS20181U220200004*/
			DUA dua = declaracion.getDua();
			if(isDAMDiferida && manifiesto != null && !isRectiDiferidaNormal){
				if(!esVigenteRIN05SegundaParte){
		        //validamos si el documento de transporte no tiene nota de tarja para todos los documentos de transporte.
	        	Map<String,Object> params = new HashMap<String,Object>();
	        	params.put("numeroCorrelativo", manifiesto.getNumeroCorrelativo());
	        	params.put("tipoEnvio",2);
	        	OperasocmanifDAO operasocmanifDAO = (OperasocmanifDAO) fabricaDeServicios.getService("manifiesto.operasocmanifDAO");
	        	Elementos<DatoDocTransporte> listaDocumentos = dua.getListDocTransporte();
	        	boolean flag= false;
	        	for(DatoDocTransporte documento : listaDocumentos){
	        		//Numero de detalle de documento de transporte opcional
	        		if(documento.getNumdetalle()!=null && documento.getNumdetalle()>0){
	        			params.put("numeroDeDetalle", documento.getNumdetalle());
	        		}else{ 
	        			      		
	        				DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService = fabricaDeServicios.getService("manifiesto.documentoOAManifiestoValidacionService");
		        			List<DocumentoDeTransporte> documentoTransporteLst = documentoOAManifiestoValidacionService.obtenerDocumentoDeTransporte(manifiesto.getNumeroCorrelativo(),documento.getNumdoctransporte());
		        			params.put("numeroDeDetalle", documentoTransporteLst.get(0).getNumeroDeDetalle());
	        			
	        		}
	        		
	        		DocumentoOABL documentoOABL = operasocmanifDAO.getByPrimaryKey(params);
	        		if(documentoOABL!=null){	        			
	        			flag=true;
	        			break;
	        		} 
	        	}
	        	if(flag){
	        		//enviamos mensaje de error
	        		return getDUAError("37032","DAM DIFERIDA SIN ICA, EL DOCUMENTO DE TRANSPORTE YA CUENTA CON NOTA DE TARJA.");
	        	}
			}
			}

			return mapErrores;
		}
		
		public  Map<String,String> validarIQFDespachoDiferidoSinPesosBultosRecibidos(Declaracion declaracion,Map<String,Object> variablesIngreso){
			Map mapErrores = new HashMap<String, Object>();
			Boolean isDAMDiferidaSinIca = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
			DUA dua = declaracion.getDua();
			boolean existeIQFSinPBR = false;
			List<DatoDocAutorizante> listDocAutorizanteDUA=dua.getListDocAutorizantes();
			Date fechaReferencia = SunatDateUtils.getCurrentDate();	
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
			boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
				if(!CollectionUtils.isEmpty(listDocAutorizanteDUA)){					
						for (DatoDocAutorizante docAutorizante : listDocAutorizanteDUA) {
				         String codigoEntidad = docAutorizante.getCodentidad()!=null?docAutorizante.getCodentidad():"";
				         String codigoSubEntidad = docAutorizante.getCodsubentidad()!=null?docAutorizante.getCodsubentidad():"";
		
				         if(esVigenteRIN05PrimeraParte && !SunatStringUtils.isEmptyTrim(codigoEntidad) && Constants.COD_ENTIDAD_DOCAUT_IQBF.equals(codigoEntidad) && Constants.COD_SUBENTIDAD_DOCAUT_IQBF.equals(codigoSubEntidad)  && isDAMDiferidaSinIca){
				        	 existeIQFSinPBR = true;
						}
		
						}
					if(existeIQFSinPBR){
					
						return getDUAError("37067","DECLARACION MODALIDAD DIFERIDA CORRESPONDE A MERCANCIAS IQBF, POR LO QUE REQUIERE CONTAR CON PESOS Y BULTOS RECIBIDOS");
					 }
				}
				return mapErrores;
		}
         
		//valida si los codigos de documento de transporte son directa o consolidado 1 a 1
		@ServicioAnnot(tipo = "V", codServicio = 3483, descServicio = "valida si los tipo de documento transmitido son los permitidos para la DAM diferida")
		@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
		@OrquestaDespaAnnot(codServInstancia = 3483, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
		@Override
        public Map<String, String> validaTipoDocumentoPermitidoParaDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso){
			Map mapErrores = new HashMap<String, Object>();
			boolean isDAMDiferida = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
			Boolean isRectiDiferidaNormal = variablesIngreso.get("isRectiDiferidaNormal")!=null?(Boolean)variablesIngreso.get("isRectiDiferidaNormal"):false;
			
                       //pruizcr pase 4 
            //CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
			Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();
			boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaDeclaracion):false;
			if(isDAMDiferida && !isRectiDiferidaNormal){
				DUA dua = declaracion.getDua();
				
				Elementos<DatoDocTransporte> listaDocumentos = dua.getListDocTransporte();
	        	boolean flag=false;
	        	for(DatoDocTransporte documento:listaDocumentos){
	        		if(!(ConstantesDataCatalogo.COD_TIPOCARGA__DIRECTO.equals(documento.getCodtipodoctrans()) || ConstantesDataCatalogo.COD_TIPOCARGA_CONSOLIDADO_1_A_1.equals(documento.getCodtipodoctrans()))){
	        			flag = true; 
	        			break;
	        		}
	        	}
	        	if(flag && !esVigenteRIN05){ //pruizcr pase 4 
	        		//enviamos mensaje de error
	        		return getDUAError("37033","DAM DIFERIDA SIN ICA, EL CODIGO DE TIPO DE DOCUMENTO DEBE SER DIRECTO O CONSOLIDADO 1 A 1.");
	        	}
			}
			return mapErrores;
        }
		
		
        public Map<String, String> validaExistenciaPesoyBustosRecibidosParaDAMDiferida(DUA dua,Manifiesto manifiesto){
        	Map mapErrores = new HashMap<String, Object>();
        	 			       //validamos si el documento de transporte no tiene ICA para todos los documentos de transporte.
        	if(!manifiesto.isEsSigad()){
	        	Map<String,Object> params = new HashMap<String,Object>();
	        	params.put("numeroCorrelativo", manifiesto.getNumeroCorrelativo());
	        	params.put("listaIncluirTipoEnvio",	new String[] {
				ConstantesDataCatalogo.TIPO_ENVIO_INGRESO_DE_MERCANCIA.toString(),
				ConstantesDataCatalogo.TIPO_ENVIO_TARJA_AL_DETALLE.toString()});
	        	params.put("indicadorEliminacion", ConstantesDataCatalogo.IND_REGISTRO_ACTIVO);
	        	DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService = fabricaDeServicios.getService("manifiesto.documentoOAManifiestoValidacionService");
	        	Elementos<DatoDocTransporte> listaDocumentos = dua.getListDocTransporte();
	        	boolean flag= false;
	        	for(DatoDocTransporte documento : listaDocumentos){
	        		//Numero d documento de transporte es opcional
	        		if(documento.getNumdetalle()!=null &&documento.getNumdetalle()>0){
	        			params.put("numeroDeDetalle", documento.getNumdetalle());
	        		}else{
		        			List<DocumentoDeTransporte> documentoTransporteLst = documentoOAManifiestoValidacionService.obtenerDocumentoDeTransporte(manifiesto.getNumeroCorrelativo(),documento.getNumdoctransporte());
		        			if(!CollectionUtils.isEmpty(documentoTransporteLst)){
		        			params.put("numeroDeDetalle", documentoTransporteLst.get(0).getNumeroDeDetalle());
	        			}
	        			
	        			
	        		}
	        		
	        		if(params.containsKey("numeroDeDetalle") && params.get("numeroDeDetalle")!=null && !"".equals(params.get("numeroDeDetalle")) ){
	        		List<DocumentoOABL> tieneTarjaDetallaOICA = documentoOAManifiestoValidacionService.obtenerOperacionAsociadaManifiestoByParameterMap(params);
	        		if (!CollectionUtils.isEmpty(tieneTarjaDetallaOICA)){
	        			flag=true;
	        			break;
	        		}else{
	        			params.put("listaIncluirTipoEnvio",	new String[] {ConstantesDataCatalogo.TIPO_ENVIO_IRM.toString()});
	        			List<DocumentoOABL> tieneIRM = documentoOAManifiestoValidacionService.obtenerOperacionAsociadaManifiestoByParameterMap(params);
		        		if (!CollectionUtils.isEmpty(tieneIRM)){
		        			flag=true;
		        			break;
		        		}
	        			
	        		}
	        	}
	        	}
	        	if(!flag){
	        			return getDUAError("37200","DAM DIFERIDA SIN PESOS Y BULTOS RECIBIDOS.");		        		
	        	}//nose que se fumaron
			
        	}else{
        		
				String codigoViaTransporte = manifiesto.getViaTransporte().getCodDatacat();
				//if(ConstantesDataCatalogo.VIA_TRANSPORTE_EER.equals(codigoViaTransporte)){
				Integer anioManifiesto = manifiesto.getAnioManifiesto();
				String numeroManifiesto = manifiesto.getNumeroManifiesto();
				String codigoAduana = manifiesto.getAduana().getCodDatacat();
				 
				int contador = 0;
				//boolean tieneTarja = false;
				String mcdetabase = ""; 
				ManifiestoSigadService manifiestoSigadService = fabricaDeServicios.getService("manifiesto.manifiestoSigadService");
				List<Mcdeta> listMcdeta = new ArrayList<Mcdeta>();
				Elementos<DatoDocTransporte> docsTransp  = dua.getListDocTransporte();
				if(docsTransp!=null) {					
					
					for(DatoDocTransporte docTransp: docsTransp ) {
						boolean tienePesosYBultosRecibidos = false;
						String puertoEmbarque = docTransp.getCodpuerto();
						listMcdeta =  manifiestoSigadService.getListMcdetaByClaveDeNegocio(
								codigoViaTransporte, codigoAduana, anioManifiesto, numeroManifiesto, docTransp.getNumdoctransporte(), puertoEmbarque,"A");
						
						if (listMcdeta!=null && listMcdeta.size() > 0) {
							for( Mcdeta mcdeta :listMcdeta) {
								if(!"0".equals(mcdeta.getDocumentoDeTransporte().getFechTarja())) {
									tienePesosYBultosRecibidos = true;
								} 
							}
						}
						if(!tienePesosYBultosRecibidos) {
							return getDUAError("37200","DAM DIFERIDA SIN PESOS Y BULTOS RECIBIDOS.");	
							
						}
					}
					
				}
				  
			//}
        		
        	}
			return mapErrores;
		}
        
		//validad que el documento de transporte no tenga ICA
		@ServicioAnnot(tipo = "V", codServicio = 3484, descServicio = "valida si los documentos transmitido de transporte no tengan transmision de ICA")
		@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
		@OrquestaDespaAnnot(codServInstancia = 3484, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
		@Override
        public Map<String, String> validaNoExistenciaICAParaDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso){
			Map mapErrores = new HashMap<String, Object>();
			boolean isDAMDiferida = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
			Manifiesto manifiesto = variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca")!=null?(Manifiesto)variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca"):null;
			Boolean isRectiDiferidaNormal = variablesIngreso.get("isRectiDiferidaNormal")!=null?(Boolean)variablesIngreso.get("isRectiDiferidaNormal"):false;
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
			Date fechaReferencia = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();		
		    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaReferencia):false;
		    // se ha revertido los cambios que hicieron para este como antes esta regla no va funcionar cuando entra en diciembre
			if(!esVigenteRIN05SegundaParte && isDAMDiferida && manifiesto != null && !isRectiDiferidaNormal){
				DUA dua = declaracion.getDua();
		        //validamos si el documento de transporte no tiene ICA para todos los documentos de transporte.
	        	Map<String,Object> params = new HashMap<String,Object>();
	        	params.put("numeroCorrelativo", manifiesto.getNumeroCorrelativo());
	        	params.put("listaIncluirTipoEnvio",	new String[] {
				ConstantesDataCatalogo.TIPO_ENVIO_INGRESO_DE_MERCANCIA.toString(),
				ConstantesDataCatalogo.TIPO_ENVIO_TARJA_AL_DETALLE.toString()});
	        	params.put("indicadorEliminacion", ConstantesDataCatalogo.IND_REGISTRO_ACTIVO);
	        	DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService = fabricaDeServicios.getService("manifiesto.documentoOAManifiestoValidacionService");
	        	Elementos<DatoDocTransporte> listaDocumentos = dua.getListDocTransporte();
	        	boolean flag= false;
	        	for(DatoDocTransporte documento : listaDocumentos){
	        		//Numero d documento de transporte es opcional
	        		if(documento.getNumdetalle()!=null &&documento.getNumdetalle()>0){
	        			params.put("numeroDeDetalle", documento.getNumdetalle());
	        		}else{	        			
	        			List<DocumentoDeTransporte> documentoTransporteLst = documentoOAManifiestoValidacionService.obtenerDocumentoDeTransporte(manifiesto.getNumeroCorrelativo(),documento.getNumdoctransporte());
	        			params.put("numeroDeDetalle", documentoTransporteLst.get(0).getNumeroDeDetalle());
	        			
	        		}
	        		
	        		List<DocumentoOABL> tieneTarjaDetallaOICA = documentoOAManifiestoValidacionService.obtenerOperacionAsociadaManifiestoByParameterMap(params);
	        		if (!CollectionUtils.isEmpty(tieneTarjaDetallaOICA)){
	        			flag=true;
	        			break;
	        		}else{
	        			// PAS20191U220200019
	        			params.put("listaIncluirTipoEnvio",	new String[] {ConstantesDataCatalogo.TIPO_ENVIO_IRM.toString()});
	        			List<DocumentoOABL> tieneIRM = documentoOAManifiestoValidacionService.obtenerOperacionAsociadaManifiestoByParameterMap(params);
		        		if (!CollectionUtils.isEmpty(tieneIRM)){
		        			flag=true;
		        			break;
		        		}
	        		}
	        	}
	        	if(flag){
	        		//enviamos mensaje de error
	        		return getDUAError("37034","DAM DIFERIDA SIN ICA, EL DOCUMENTO DE TRANSPORTE YA CUENTA CON ICA.");
	        		}
	        	}

			return mapErrores;
		}
		
		//validar que la transmision de numeracion contenga contenedor
		@ServicioAnnot(tipo = "V", codServicio = 3490, descServicio = "validar que la transmision de numeracion contenga contenedor")
		@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
		@OrquestaDespaAnnot(codServInstancia = 3490, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
		@Override
        public Map<String, String> validaExistenciaContenedoresDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso){
			Map mapErrores = new HashMap<String, Object>();
			Boolean isDAMDiferida = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
			Boolean isRectiDiferidaNormal = variablesIngreso.get("isRectiDiferidaNormal")!=null?(Boolean)variablesIngreso.get("isRectiDiferidaNormal"):false;
			Manifiesto manifiesto = variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca")!=null?(Manifiesto)variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca"):null;
			Boolean flag=false;
                      // pruizcr pase PAS20181U220200004
			//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
			ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");		
			Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();
			boolean esVigenteRIN05 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05(fechaDeclaracion):false;
			if(!esVigenteRIN05 && isDAMDiferida && manifiesto != null && !isRectiDiferidaNormal){
				Elementos<DatoEquipamiento> listContenedores =  declaracion.getDua().getManifiesto().getListEquipamientos();
				if(CollectionUtils.isEmpty(listContenedores)){
					return getDUAError("37035","DAM DIFERIDA SIN ICA, ES OBLIGATORIO LA TRANSMISION DEL/LOS CONTENEDOR(ES).");
				}
			}

			return mapErrores;
		}
		
		//validar que la fecha de numeracion sea posterior a la fecha de llegada
		@ServicioAnnot(tipo = "V", codServicio = 3491, descServicio = "valida si los documentos transmitido de transporte no tengan transmision de ICA")
		@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
		@OrquestaDespaAnnot(codServInstancia = 3491, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
		@Override
        public Map<String, String> validaFechaNumeMayorFechaLlegada(Declaracion declaracion, Map<String,Object> variablesIngreso){
			Map mapErrores = new HashMap<String, Object>();
			Boolean isDAMDiferida = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
			Boolean isRectiDiferidaNormal = variablesIngreso.get("isRectiDiferidaNormal")!=null?(Boolean)variablesIngreso.get("isRectiDiferidaNormal"):false;
			Manifiesto manifiesto = variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca")!=null?(Manifiesto)variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca"):null;
			Boolean flag=false;
			if(isDAMDiferida && manifiesto!= null && !isRectiDiferidaNormal){
				Date fechaNumeracion = new Date();
				if(!SunatDateUtils.esFecha1MayorQueFecha2(fechaNumeracion,manifiesto.getFechaEfectivaDeLlegada(),"COMPARA_TODO")){
					flag=true;
				}
	        	if(flag){
	        		//enviamos mensaje de error
	        		return getDUAError("37042","DAM DIFERIDA SIN ICA, LA FECHA DE NUMERACION TIENE QUE SER POSTERIOR A LA FECHA DE LLEGADA DEL MANIFIESTO.");
	        	}
			}

			return mapErrores;
		}

		//validar que la fecha de numeracion sea posterior a la fecha de llegada
		@ServicioAnnot(tipo = "V", codServicio = 3492, descServicio = "valida que el BL tenga como destinacion solo importacion para una DAM Diferida Sin ICA")
		@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
		@OrquestaDespaAnnot(codServInstancia = 3492, numSecEjec = 0, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
		@Override
		public Map<String, String> validaTipoDestinacionBlDAMDiferidaSinIca(Declaracion declaracion, Map<String,Object> variablesIngreso){
			Map mapErrores = new HashMap<String, Object>();
			Boolean isDAMDiferida = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
			Manifiesto manifiesto = variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca")!=null?(Manifiesto)variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca"):null;
			Boolean isRectiDiferidaNormal = variablesIngreso.get("isRectiDiferidaNormal")!=null?(Boolean)variablesIngreso.get("isRectiDiferidaNormal"):false;
			if(isDAMDiferida && manifiesto != null && !isRectiDiferidaNormal){
				if(!manifiesto.isEsSigad()){
				DUA dua = declaracion.getDua();
				//validamos si el BL es tipo 23
				Map<String,Object> params = new HashMap<String,Object>();
				params.put("numeroCorrelativo", manifiesto.getNumeroCorrelativo());
				DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService = fabricaDeServicios.getService("manifiesto.documentoOAManifiestoValidacionService");
				Elementos<DatoDocTransporte> listaDocumentos = dua.getListDocTransporte();
				boolean flag= false;
				for(DatoDocTransporte documento : listaDocumentos){
					List<DocumentoDeTransporte> documentoTransporteLst;
	        		//Numero de 
	        		if(documento.getNumdetalle()!=null&&documento.getNumdetalle()>0){	        			
	        			documentoTransporteLst = documentoOAManifiestoValidacionService.obtenerDocumentoDeTransporte(manifiesto.getNumeroCorrelativo(),documento.getNumdoctransporte(),documento.getNumdetalle().toString());
	        		}else{
	        			documentoTransporteLst = documentoOAManifiestoValidacionService.obtenerDocumentoDeTransporte(manifiesto.getNumeroCorrelativo(),documento.getNumdoctransporte());
	        		}
					if(documentoTransporteLst!= null &&!documentoTransporteLst.isEmpty()){
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						for(DocumentoDeTransporte docutrans :documentoTransporteLst ){
							
							if (docutrans.getDestinacion().getCodDatacat()!=null &&  !"".equals(docutrans.getDestinacion().getCodDatacat().trim().toString()) && !"23".equals(docutrans.getDestinacion().getCodDatacat())){
								String mensaje = "B/L  con destinaci�n transito cod_tipo="+ docutrans.getDestinacion().getCodDatacat()+
										" corresponde a "+ catalogoAyudaService.getDescripcionDataCatalogo("217",docutrans.getDestinacion().getCodDatacat())
										+" no se puede destinar.";
								return getDUAError("37044",new Object[]{docutrans.getDestinacion().getCodDatacat(),catalogoAyudaService.getDescripcionDataCatalogo("217",docutrans.getDestinacion().getCodDatacat()).toUpperCase()});
							}
						}
					}


				}
			  }
			}
			return mapErrores;
		}


	@ServicioAnnot(tipo = "V", codServicio = 3497, descServicio = "Valida la unidad de carga de la declaraci�n")
	@Override
	public List<Map<String,String>> validarUnidadCarga(DUA dua, Date fechaReferencia){
		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>();
		
		if(dua.getUnidadCarga() != null && dua.getUnidadCarga().getCntCarga() != null) {
			if (SunatStringUtils.isEmpty(dua.getUnidadCarga().getCodCarga())) {
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
						"37084",new String[] {dua.getUnidadCarga().getCodCarga()}));
			}
		}
		
		if(dua.getUnidadCarga() != null && !SunatStringUtils.isEmpty(dua.getUnidadCarga().getCodCarga())) {
			boolean esUnidadCargaValida = CollectionUtils.isEmpty(
					((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).
					validarElementoCat("144", dua.getUnidadCarga().getCodCarga(), fechaReferencia));
			if(!esUnidadCargaValida) {
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
						"37081",new String[] {dua.getUnidadCarga().getCodCarga()}));
			}
			
			if(dua.getUnidadCarga().getCodCarga().equals("08") && SunatStringUtils.isEmpty(dua.getUnidadCarga().getDesCarga())) {
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("37082"));
			}
			
			if(dua.getUnidadCarga().getCntCarga() == null){
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("37083"));
			}
		}
		return lstErrores;
	}
	/**
	 * Establece los valores para las validacion e inicializa los parametros para los metodos de validacion.
	 * 
	 * @param declaracion Declaracion
	 * @param numOrden String
	 * @param codUsuario String
	 * @param annEnvio Integer
	 * @param numEnvio Long
	 * @param tipoSender String
	 * @param numeroDocumentoIdentidadSender String
	 * @param tipoDocumentoIdentidadSender String
	 * @param codTransaccion String
	 * @return el mapa de errrores
	 */
	public Map<String, ?> setupDeclaracionEER(Declaracion declaracion, String numOrden, String codUsuario, Integer annEnvio, 
			Long numEnvio, String tipoSender, String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender, String codTransaccion) {
		Map<String, Object> response = new HashMap<String, Object>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"); 
		ValPrecedenteEERService precedenteService = fabricaDeServicios.getService("ingreso.validador.precedentes");
		Integer vigenciaRLGA = 0;
		String paisOrigen = declaracion.getDua().getListSeries().get(0).getCodpaisorige();
		String codEstadoMerca = declaracion.getDua().getListSeries().get(0).getCodestamerca();

		boolean contieneFA = true;
		if(declaracion.getDua()==null) declaracion.setDua(new DUA());
		String codaduana = ConstantesDataCatalogo.ADUANA_AEREA_CALLAO;
		String codregimen = ConstantesDataCatalogo.REGIMEN_EER;
		if(declaracion!=null){
			declaracion.setCodaduana(codaduana);
			declaracion.setCodregimen(codregimen);
			declaracion.getDua().setCodaduanaorden(codaduana);
			declaracion.getDua().setCodregimen(codregimen);
		}

		//se establecen los valores para evitar los null pointer
		DUA dua=declaracion.getDua();
		
		if(dua!=null){
			if(dua.getConsignatario()!=null)
				dua.getConsignatario().setDocumento(new Documento());
			if(dua.getEmbarcador()!=null)
				dua.getEmbarcador().setDocumento(new Documento());
			if(dua.getRemitente()!=null)
				dua.getRemitente().setDocumento(new Documento());
			if (dua.getListDocAutorizantes()==null)
				dua.setListDocAutorizantes(new Elementos<DatoDocAutorizante>());
			if (dua.getListSeries()==null)
				dua.setListSeries(new Elementos<DatoSerie>());
			else{
				for(DatoSerie serie:dua.getListSeries()){
					if (serie.getListRegPrecedencia()==null)
						serie.setListRegPrecedencia(new Elementos<DatoRegPrecedencia>());
				}
			}
		}
		if(contieneFA) {
			if (dua.getListOtrosDocSoporte()==null)
				dua.setListOtrosDocSoporte(new Elementos<DatoOtroDocSoporte>());
			if (dua.getListOtrosDocSoporteCO()==null)
				dua.setListOtrosDocSoporteCO(new Elementos<DatoOtroDocSoporte>());
			if (dua.getListFacturaRef()==null)
				dua.setListFacturaRef(new Elementos<DatoFacturaref>());
			if (dua.getListIndicadores()==null)
				dua.setListIndicadores(new Elementos<DatoIndicadores>());
			if (dua.getListObservaciones()==null)
				dua.setListObservaciones(new Elementos<Observacion>());
			if (dua.getListTributosAutocalculados()==null)
				dua.setListTributosAutocalculados(new Elementos<DatoTributosAutocalc>());
			if (dua.getManifiesto().getListEquipamientos()==null)
				dua.getManifiesto().setListEquipamientos(new Elementos<DatoEquipamiento>());
			else{
				for(DatoEquipamiento equipamiento:dua.getManifiesto().getListEquipamientos()){
					if (equipamiento.getListPrecintos()==null)
						equipamiento.setListPrecintos(new Elementos<DatoPrecinto>());
				}
			}
		 
		}
		
		//calculo del seguro en cada caso por series
		calculoSeguro(declaracion);
        //calculo de los totales
		calculoTotales(declaracion);
		//setemos la guia en la serie
		DatoDocTransporte datoDocTransporte=dua.getListDocTransporte().get(0);
		datoDocTransporte.setCodtipodoctrans("1");
        setDocumentoTransporteSerie(declaracion,datoDocTransporte);
        //realizamos la busqueda de la data de los precedentes
		precedenteService.setDatosRegimenPrecedente(declaracion.getDua(), response);
		//rtineo: verificamos si tiene precedente y asignamos el numCorredoc
        setNumeCorredocPrecendentes(dua, response);
		DataGrupoCat  miDatGrpCat = catalogoAyudaService.getDataGrupoCat(pe.gob.sunat.despaduanero2.manifiesto.util.Constantes.VIGENCIA_RLGA_712, codaduana, new Date());
        if (miDatGrpCat != null) vigenciaRLGA = 1;
        //obtenemos la categoria para pasarlo como parametro de los metodos de validacion
        String codCategoria = declaracion.getDua().getCategoria().getCodDatacat();
        //response.put("codigoAduanaOrden", codaduana);
        response.put("vigenciaRLGA", vigenciaRLGA);
		response.put("declaracion", declaracion);
		response.put("codCategoria", codCategoria);
		response.put("codpaisorige", paisOrigen);
		response.put("codestamerca", codEstadoMerca);
		//seteamos variablesIngreso para Garantia
		Map<String,Object> variablesCancelacion = new HashMap<String,Object>();
        variablesCancelacion.put("tipoDesp","TA"); //Anticipado
        variablesCancelacion.put("annEnvio",annEnvio);
        variablesCancelacion.put("numEnvio",numEnvio);
        //se actualiza el valor del codigo de la garantia R por G
        setValoresGarantia(dua);

		response.put("variablesCancelacion", variablesCancelacion);
        response.put("declaracion", declaracion);
		return response;
	}

	private void calculoTotales(Declaracion declaracion){
		BigDecimal totalBultos = BigDecimal.ZERO;
		BigDecimal totalFob = BigDecimal.ZERO;
		Integer totalNumeroSer = 0;
		BigDecimal totalCantPeBr = BigDecimal.ZERO;
		BigDecimal totalCantUniFis = BigDecimal.ZERO;
		BigDecimal totalCantUniCom = BigDecimal.ZERO;
		BigDecimal totalCantSegDol = BigDecimal.ZERO;
		BigDecimal totalCantValorAdu = BigDecimal.ZERO;
		BigDecimal totalCantAjusteVa = BigDecimal.ZERO;
        BigDecimal totalCantFlete = BigDecimal.ZERO;
		if (declaracion.getDua().getListSeries() != null) {
			for (DatoSerie serie : declaracion.getDua().getListSeries()) {
				totalNumeroSer++; 
				totalFob = totalFob.add(serie.getMtofobdol()==null?BigDecimal.ZERO:serie.getMtofobdol());
				totalBultos = totalBultos.add(serie.getCntbultos()==null?BigDecimal.ZERO:serie.getCntbultos());
				totalCantPeBr =  totalCantPeBr.add(serie.getCntpesobruto()==null?BigDecimal.ZERO:serie.getCntpesobruto());
				totalCantUniFis =  totalCantUniFis.add(serie.getCntunifis()==null?BigDecimal.ZERO:serie.getCntunifis());
				totalCantUniCom =  totalCantUniCom.add(serie.getCntunicomer()==null?BigDecimal.ZERO:serie.getCntunicomer());
				totalCantSegDol =  totalCantSegDol.add(serie.getMtosegdol()==null?BigDecimal.ZERO:serie.getMtosegdol());
                totalCantFlete =  totalCantFlete.add(serie.getMtofledol()==null?BigDecimal.ZERO:serie.getMtofledol());

				totalCantAjusteVa =  totalCantAjusteVa.add(serie.getMtoajuste()==null?BigDecimal.ZERO:serie.getMtoajuste());				
			}
		}
		declaracion.getDua().setCntnumseries(totalNumeroSer);		
		declaracion.getDua().setMtotfobclvta(totalFob);
		declaracion.getDua().setCnttcantbulto(totalBultos);
		declaracion.getDua().setCnttpesobruto(totalCantPeBr);		
		declaracion.getDua().setCnttqunifis(totalCantUniFis);
		declaracion.getDua().setCnttqunicom(totalCantUniCom);
		declaracion.getDua().setMtotsegotros(totalCantSegDol);
		declaracion.getDua().setMtotajustes(totalCantAjusteVa);		
        declaracion.getDua().setMtotflecomex(totalCantFlete);
		prorrateoFleteEER(declaracion);
        for(DatoSerie serie:declaracion.getDua().getListSeries()){
			if(serie.getMtofledol() == null)
				serie.setMtofledol(new BigDecimal(0));
			if(serie.getMtoajuste() ==  null)
				serie.setMtoajuste(new BigDecimal(0));
			serie.setMtovaladuana(serie.getMtofobdol().add(serie.getMtosegdol()).add(serie.getMtoajuste()).add(serie.getMtofledol()));
			totalCantValorAdu =  totalCantValorAdu.add(serie.getMtovaladuana()==null?BigDecimal.ZERO:serie.getMtovaladuana());
			serie.setCodmoneda(ConstantesDataCatalogo.MONEDA_DOLAR);
		}
		declaracion.getDua().setMtovaladuana(totalCantValorAdu);
    }
    private void setDocumentoTransporteSerie(Declaracion declaracion, DatoDocTransporte datoDocTransporte){
        for(DatoSerie serie:declaracion.getDua().getListSeries()) {
            serie.setNumcorredoc(declaracion.getNumeroCorrelativo());
            serie.setDocumentoTransporte(datoDocTransporte);
        }
    }
	private void setValoresGarantia(DUA dua){
		DatoPago pago=dua.getPago();
        if(pago != null){
        	DatoPagoDecla decla=pago.getPagoDeclaracion();
            //String codigoGarantia = dua.getPago().getPagoDeclaracion().getCodgarantia();
        	//setear el tipo de pago cuando viene R pasarlo G
        	String codTipoPago=decla!=null?decla.getCodtipopago():null;
            if(Constantes.COD_INDICADOR_GARANTIA_OMA.equals(codTipoPago)){
				decla.setCodtipopago(ConstantesDataCatalogo.DEUDA_GARANTIZADA);
				//seteamos tambien el indicador de garantia
				if(dua.getListIndicadores()==null)dua.setListIndicadores(new Elementos<DatoIndicadores>());
				DatoIndicadores indicadorGarantia = new DatoIndicadores();
				indicadorGarantia.setCodigoIndicador(ConstantesDataCatalogo.CODIGO_INDICADOR_EER_GARANTIA);
				dua.getListIndicadores().add(indicadorGarantia);
			}

        }
    }

    private void setNumeCorredocPrecendentes(DUA dua, Map<String,Object> response){
		if(response.get("tipoRegimenSeries") != null){
			if(response.get("duasPrecedentesPorSerie") != null){
				Map<Integer,DUA> duasPrecendetePorSerie =  (Map<Integer,DUA>)response.get("duasPrecedentesPorSerie");
				if (!duasPrecendetePorSerie.isEmpty()) {//mlaura PAS20181U220400008-IZV-127
					for(DatoSerie serie: dua.getListSeries()){
							DUA duaPrecedente = duasPrecendetePorSerie.get(serie.getNumserie());
							DatoSerie seriePrecedente = duaPrecedente != null ? (duaPrecedente.getListSeries() != null ? duaPrecedente.getListSeries().get(0) : null) : null; 
							if(seriePrecedente != null){
								serie.getListRegPrecedencia().get(0).setNumcorredocpre(duaPrecedente.getNumcorredoc());
								serie.getListRegPrecedencia().get(0).setCntunidfiqty(seriePrecedente.getCntunifis());
								serie.getListRegPrecedencia().get(0).setCodunifis(seriePrecedente.getCodunifis());
								}
					}
				}//mlaura PAS20181U220400008-IZV-127
			}
		}
	}
//OMA -PAS20181U220200004	
	void seteoFormatoA(Declaracion declaracion){
		
			if(declaracion.getPadre()!=null){
			String codigoAduana = ((Mensaje) declaracion.getPadre()).getControl().getCodigoAduanaOrden()!=null?((Mensaje) declaracion.getPadre()).getControl().getCodigoAduanaOrden().toString():declaracion.getCodaduana().toString();
			declaracion.getDua().setCodaduanaorden(codigoAduana);
			declaracion.setCodaduana(codigoAduana);
		}else{ // para las diligencias PAS20181U220200069
			String codigoAduana  =declaracion.getCodaduana().toString();
			declaracion.getDua().setCodaduanaorden(codigoAduana);
			declaracion.setCodaduana(codigoAduana);
		}
		
		if( declaracion.getDua().getPago() !=null && declaracion.getDua().getPago().getPagoDeclaracion()!=null &&  declaracion.getDua().getPago().getPagoDeclaracion().getCodtipopago() !=null){
			if("R".equals(declaracion.getDua().getPago().getPagoDeclaracion().getCodtipopago())){
				declaracion.getDua().getPago().getPagoDeclaracion().setCodtipopago("G");
			}
		
		}
		List<DatoIndicadores> lstIndicadores =	declaracion.getDua().getListIndicadores();
		for(int z =0 ; z<lstIndicadores.size();z++){
			
			lstIndicadores.get(z).setDestipoindica(declaracion.getDua().getDestipoindica());
		}
		
		
		List<DatoSerie> lstSerie = declaracion.getDua().getListSeries();
		for(int i =0 ; i<lstSerie.size();i++){
			if(lstSerie.get(i).getIndParteVehiculo()!=null ){
			if( "44".equals(lstSerie.get(i).getIndParteVehiculo().toString())){
				lstSerie.get(i).setIndParteVehiculo("1");
				
			}else{
				lstSerie.get(i).setIndParteVehiculo("0");
			}
		   }
			if(lstSerie.get(i).getValindcodlib()==null || !"S".equals(lstSerie.get(i).getValindcodlib().toString())){
				lstSerie.get(i).setValindcodlib("N");
			}
			
			
		}
	}
	
	void seteoFormatoB(Declaracion declaracion){
		List<DAV> listDav=declaracion.getListDAVs();
		if (listDav!=null && !listDav.isEmpty()){
			for (DAV dav : listDav) {
				if(dav.getIntermediario()!=null && dav.getIntermediario().getTipoParticipante()!=null && dav.getIntermediario().getTipoParticipante().getCodDatacat()!=null){
					if("true".equals(dav.getIntermediario().getTipoParticipante().getCodDatacat())){
						dav.getIntermediario().getTipoParticipante().setCodDatacat("90");
					}
				}
				if(!CollectionUtils.isEmpty(dav.getListDocumentoSoporteFormatoB())){
					for(DocumentoSoporteFormatoB docSoporteB : dav.getListDocumentoSoporteFormatoB()) {
						if(dav.getResolucion()!=null){
							docSoporteB.setCodResolucion(dav.getResolucion().getCodResolucion());
							docSoporteB.setNumResolucion(dav.getResolucion().getNumResolucion());
							docSoporteB.setDesResolucion(dav.getResolucion().getDesResolucion());
							docSoporteB.setFechaResolucion(dav.getResolucion().getFechaResolucion());
							
						}
					}
				}
				
				if(!CollectionUtils.isEmpty(dav.getListFacturas())){
					for(DatoFactura datoFactura : dav.getListFacturas()){
					//	String numfactura =  datoFactura.getNumfactura();
						Integer numsecfactu = datoFactura.getNumsecfactu();
						// seteo de incoterm de DAV A  FACTURA (LISTA FACTURA)
						if(SunatStringUtils.isEmpty(datoFactura.getCodincoterm()))
						datoFactura.setCodincoterm(dav.getCodincoterm());
						//seteo de deslugtrans de DAv a factura (lista de factura)
						if(SunatStringUtils.isEmpty(datoFactura.getDeslugtrans()))
						datoFactura.setDeslugtrans(dav.getDeslugtrans());
						//seteo de codpaisembar de DAV a factura (lista de factura)
						if(SunatStringUtils.isEmpty(datoFactura.getCodpaisembar()))
						datoFactura.setCodpaisembar(dav.getCodpaisembar());
						//seteo de la listafacturasucesivas
						if(!CollectionUtils.isEmpty(dav.getListFactSucesivas())){
							for(DatoFactSuce datoFactSuce : dav.getListFactSucesivas()){	
							 	if(datoFactSuce.getNumsecfactu().toString().equals(numsecfactu.toString())){
								 		datoFactura.getListFactSucesivas().add(datoFactSuce);
									}

								}
						}
						
						if(!CollectionUtils.isEmpty(dav.getListItems())){
							
							for(DatoItem datoItem : dav.getListItems()){
								if("true".equals(datoItem.getIndsoftware())){
									datoItem.setIndsoftware("3");
								}
								else{
									datoItem.setIndsoftware(null);
								}
								
								if("true".equals(datoItem.getInddeducdisti())){
									datoItem.setInddeducdisti("1");
								}else{
									datoItem.setInddeducdisti("2");
								}
								
								//seteo el padre de datoitem es factura
								datoItem.setPadre(datoFactura);
								// seterear lista items dentro de factura 
							 	if(datoItem.getNumsecfactu().toString().equals(numsecfactu.toString())){
								 		datoFactura.getListItems().add(datoItem);
									}
										
								}
						}
					}
				}
				
				//al final se setea el padre de DAV
				dav.setPadre(declaracion);
			}
			
		}else{
			declaracion.setListDAVs(new Elementos<DAV>());
		}
	}
//FIN OMA
	
	//OJO CON ESTE SERVICIO - AL PARECER SE DEBE ELIMINAR - PAS20191U220200019
	/**
	 * PAS20181U220200049
	 * SE DEJA EL CODIGO PERO NO SE ESTA REGISTRANDO EL SERVICIO EN EL ORQUESTADOR - VER ESTO EN EL PASE QUE VALIDAR DIFERIDOS 
	 * No se permite la numeraci�n de una declaraci�n para la modalidad despacho diferido,  cuando se cumplan las siguientes condiciones:
	 * 1. Que no cuente con el ICA, y; 
	 * 2. Que alguna de las series de la declaraci�n consigne una Subpartida Nacional (SPN) con unidad de medida de peso o volumen (seg�n arancel) o una unidad comercial de peso � volumen.
	 * @param declaracion declaracion transmitida
	 * @param variablesIngreso Variables de validacion de un determinado proceso
	 * @return errores de validacion
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2548, descServicio = "Valida sin ICA, peso y volumen")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "this" })
	@OrquestaDespaAnnot(codServInstancia = 2548, numSecEjec = 44, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	@Override	
	public Map<String, String> validaSinICAPesoUnidadVolumenDAMDiferida(Declaracion declaracion, Map<String,Object> variablesIngreso){
		DUA dua = declaracion.getDua();
		Boolean isDAMDiferidaSinIca = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
		Manifiesto manifiesto = variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca")!=null?(Manifiesto)variablesIngreso.get("manifiestoForValidationDAMDiferidaSinIca"):null;
		String viaTransporte = variablesIngreso.get("viaTransp")!=null?variablesIngreso.get("viaTransp").toString():"0";
		boolean flag= false;
		String unidadPesoVolumen=" ";
		String documentoTransporte=" ";
		if(ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equalsIgnoreCase(viaTransporte)) {
			if(isDAMDiferidaSinIca && manifiesto != null){
				Elementos<DatoDocTransporte> listaDocumentos = dua.getListDocTransporte();			
				for (DatoSerie serie:dua.getListSeries()){
					if(esUnidadPesoVolumen(serie.getCodunifis()) || esUnidadPesoVolumen(serie.getCodunicomer())){
						if(esUnidadPesoVolumen(serie.getCodunifis())) {
							unidadPesoVolumen = serie.getCodunifis();
						}
						else if(esUnidadPesoVolumen(serie.getCodunicomer())) {
							unidadPesoVolumen = serie.getCodunicomer();
						}
						for(DatoDocTransporte documento:listaDocumentos){
							Elementos<DatoSerieDocSoporte> listaDocumentosSerie = serie.getListSerieDocSoporte();
							for(DatoSerieDocSoporte documentoSerie:listaDocumentosSerie){
								if(documentoSerie.getCodtipodocsoporte().equalsIgnoreCase("2")) {
									if(documentoSerie.getNumiddocsoporte().equals(documento.getNumsecdoctrans())) {
										documentoTransporte = documento.getNumdoctransporte().toString();
										break;
									}								
								}
							}
						}
						flag=true; 
						break;
					}
				}
			}
		}
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(flag) {
			return catalogoAyudaService.getError("70151", new String[] {unidadPesoVolumen, documentoTransporte});
			//DECLARACION PRESENTA SUBPARTIDA ARANCELARIA CON UNIDAD FISICA DE PESO VOLUMEN {0}, DOCUMENTO DE TRANSPORTE {1} DEBE CONTAR CON ICA
		}
		return new HashMap<String,String>();
	}
	
	// Inicio PAS20181U220200049
	private boolean esUnidadPesoVolumen (String codigoUnidad){
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (catalogoAyudaService.getDataGrupoCat(ConstantesGrupoCatalogo.GRUPO_CATALOGO_PESOS_VOLUMEN, codigoUnidad) != null)
			return true;
		else
			return false;		
	}

	/**
	 * Establece la dua como variable global de las validaciones.
	 * 
	 * @param declaracion Declaracion
	 * @param numOrden String
	 * @param codUsuario String
	 * @param annEnvio Integer
	 * @param numEnvio Long
	 * @param tipoSender String
	 * @param numeroDocumentoIdentidadSender String
	 * @param tipoDocumentoIdentidadSender String
	 * @param codTransaccion String
	 * @return el mapa de errrores
	 */
	@Override
	public Map<String, ?> setupDeclaracionEspeciales(Declaracion declaracionEspecial, String numOrden, String codUsuario,
			Integer annEnvio, Long numEnvio, String tipoSender, String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender, String codTransaccion) {
		Map<String, Object> response = new HashMap<String, Object>();
		
		// TODO Auto-generated method stub
		try{			
			Integer vigenciaRLGA = 0;
			Declaracion declaracionXML = declaracionEspecial;
			boolean contieneFA = true;
			if(declaracionEspecial.getDua()==null) declaracionEspecial.setDua(new DUA());
			String codigoAduana = ((Mensaje) declaracionEspecial.getPadre()).getControl().getCodigoAduanaOrden()!=null?((Mensaje) declaracionEspecial.getPadre()).getControl().getCodigoAduanaOrden().toString():declaracionEspecial.getCodaduana().toString();
			declaracionEspecial.getDua().setCodaduanaorden(codigoAduana);
			declaracionXML.setCodaduana(codigoAduana);
			declaracionXML.setCodtipotrans(codTransaccion);
			declaracionXML.setNumorden(numOrden);
			//adecuar Dato Documento de Transporte al Manifiesto
			declaracionXML.getDua().setListDocTransporte(declaracionXML.getDua().getListDocTransporte());
			Elementos<DatoSerie> lstSeries= declaracionXML.getDua().getListSeries();			
			Elementos<DatoDocTransporte> lstDocTransporte= declaracionXML.getDua().getListDocTransporte();
			if (!CollectionUtils.isEmpty(lstDocTransporte)){
				DatoDocTransporte datDocTransporte = lstDocTransporte.get(0);
				if (!CollectionUtils.isEmpty(lstSeries)){
					for(DatoSerie datoSerie: lstSeries ){
						datoSerie.setDocumentoTransporte(datDocTransporte);
					}
					
				}
			}
			
			//agregar participante 41 si es diferente a beneficiario
			Participante consignatario = declaracionXML.getDua().getDeclarante();
			if (!consignatario.getNumeroDocumentoIdentidad().equals(numeroDocumentoIdentidadSender)){
				Participante participanteAgente = new Participante();
				participanteAgente.setNumeroDocumentoIdentidad(numeroDocumentoIdentidadSender);
				participanteAgente.getTipoParticipante().setCodDatacat(tipoSender);
				participanteAgente.getTipoDocumentoIdentidad().setCodDatacat(tipoDocumentoIdentidadSender);
				declaracionXML.getDua().setAgenteAduanas(participanteAgente);				
			}else{
				declaracionXML.getDua().setAgenteAduanas(null);	
			}
			declaracionXML.getDua().setCodtipoperacion(codTransaccion);
			declaracionXML.getDua().setCodtipooper(tipoSender);
			declaracionXML.getDua().setNumdocumento(numeroDocumentoIdentidadSender);
			declaracionXML.getDua().setNumorden(numOrden.substring(4,10));
			declaracionXML.getDua().setAnnorden(Integer.valueOf(numOrden.substring(0, 4)));
		    //Validar Indicadores de la Declaracion
			Map<String, Object> argumentoGrabacion = new HashMap<String, Object>();
			argumentoGrabacion.put("declaracion", declaracionXML);
			argumentoGrabacion.put("tipoSender", tipoSender);
			argumentoGrabacion.put("numeroDocumentoIdentidadSender",  numeroDocumentoIdentidadSender );
			argumentoGrabacion.put("tipoDocumentoIdentidadSender",  tipoDocumentoIdentidadSender );	
			argumentoGrabacion.put("codTransaccion",  codTransaccion );		 
			argumentoGrabacion.put("numOrden", numOrden);
			argumentoGrabacion.put("codUsuario", codUsuario);
			argumentoGrabacion.put("annEnvio", annEnvio);
			argumentoGrabacion.put("numEnvio", numEnvio);
			response.put("variablesIngreso", argumentoGrabacion);
			response.put("declaracion", declaracionXML);
			

			/*if(declaracionEspecial!=null){
				declaracionEspecial.setCodaduana(codaduana);
				declaracionEspecial.setCodregimen(codregimen);
				declaracionEspecial.getDua().setCodaduanaorden(codaduana);
				declaracionEspecial.getDua().setCodregimen(codregimen);
			}*/

		}catch(Exception e){
			e.printStackTrace();
			log.debug("setupDeclaracionEspeciales:ERROR!!!:"+e.toString());
		}
		return response;
	}
	 
/*
	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}
*/
	//
	//	public OpecomextDAO getOpecomextDao() {
	//		return opecomextDao;
	//	}
	//
	//
	//	public void setOpecomextDao(OpecomextDAO opecomextDao) {
	//		this.opecomextDao = opecomextDao;
	//	}
	//	public ManifiestoService getManifiestoService() {
	//		return manifiestoService;
	//	}
	//
	//
	//	public DocumentoOAManifiestoValidacionService getDocumentoOAManifiestoValidacionService() {
	//		return documentoOAManifiestoValidacionService;
	//	}
	//
	//
	//	public void setManifiestoService(ManifiestoService manifiestoService) {
	//		this.manifiestoService = manifiestoService;
	//	}
	//
	//
	//	public void setDocumentoOAManifiestoValidacionService(
	//			DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService) {
	//		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
	//	}
/*
	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}
	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}
	public SprDAOService getSprDAOService() {
		return sprDAOService;
	}
	public void setSprDAOService(SprDAOService sprDAOService) {
		this.sprDAOService = sprDAOService;
	}
	public ValParticipante getValParticipante() {
		return valParticipante;
	}
	public void setValParticipante(ValParticipante valParticipante) {
		this.valParticipante = valParticipante;
	}
	public ValidadorLocalAnexo getValidadorLocalAnexo() {
		return validadorLocalAnexo;
	}
	public void setValidadorLocalAnexo(ValidadorLocalAnexo validadorLocalAnexo) {
		this.validadorLocalAnexo = validadorLocalAnexo;
	}
*/
/*
	public CatalogoHelperImpl getCatalogoHelper() {
		return catalogoHelper;
	}
	public HotSwappableTargetSource getSwapperDatasource() {
		return swapperDatasource;
	}
	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}
	
    public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}
	 
	
	public ResolucionService getResolucionService() {
		return resolucionService;
	}
	public void setResolucionService(ResolucionService resolucionService) {
		this.resolucionService = resolucionService;
	}
*/
}