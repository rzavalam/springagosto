package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.prevcontrabando2.ace.service.ConsultaMedidaPreventivaService;
import pe.gob.sunat.prevcontrabando2.operativo.model.CabActas;
import pe.gob.sunat.prevcontrabando2.operativo.model.DetItemsActa;

public class ValPrecedenteActaEquipajeServiceImpl extends IngresoAbstractServiceImpl implements ValPrecedenteActaEquipajeService {
	private String SUSPENCION_PLAZO_REGULARIZACION_DESPACHO_ANTICIPADO_URGENTE = "1606";
	private String SUSPENCION_PLAZO_VCTO_ART78 ="3095";

	public List<Map<String, String>> validaActaIncautacionEquipaje (String puntoDeLlegada, List<DatoSerie> listSeries, String codAduanaOrden, Date fechaReferencia){
		List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
		String codAreaEquipaje =  new String();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		//Establecer una asociaci�n entre las aduanas (Catalogo 00 y un nuevo Catalogo que tendr� las �reas de Equipaje, llenar el
		// mismo con dicha informaci�n
		//Con el par�metro de la aduana consultar el �rea de equipaje que servir� como par�metro para el query
		codAreaEquipaje = this.getAreaEquipaje(codAduanaOrden);
		if (SunatStringUtils.isEmptyTrim(codAreaEquipaje)) {
			listMapError.add(catalogoAyudaService.getError("37218",new String[] {}));
			return listMapError;
		}
		listMapError.add(validarPuntoLlegada(puntoDeLlegada));
		String codiAduan="";
		for(DatoSerie serie:listSeries) {
			if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
				for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
					String strPrecedencia = regPrec.getCodaduapre() + '-' + SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4) + '-' + ConstantesDataCatalogo.ACTA_INCAUTACION + '-' + regPrec.getNumdeclpre();
					codiAduan = regPrec.getCodaduapre() != null ? regPrec.getCodaduapre().toString() : "0";
					CabActas listCabActa = consultarActaIncautacionPrece(regPrec, null);//csantillan -- El codAreaEquipaje se validara para el rechazo 32032

					if (!codAduanaOrden.equals(codiAduan)) {
						listMapError.add(catalogoAyudaService.getError("37209", new String[]{serie.getNumserie().toString(), codiAduan, "DEL ACTA DE INCAUTACION", strPrecedencia, codAduanaOrden}));
						break;
					}
					if (listCabActa == null) {

						//Serie […]: <TipoDocumento> N� AAA-XXXX-RR-YYYYYY no existe
						listMapError.add(catalogoAyudaService.getError("37230", new String[]{serie.getNumserie().toString(), strPrecedencia}));
					} else {
						// Se verifica validaciones adicionales
						listMapError.addAll(this.valActaIncautacionEquipajeAdicional(listCabActa, fechaReferencia, serie.getNumserie().toString(), strPrecedencia, regPrec));
						// Se verifica si a nivel de item existe
						CabActas cabActaResult = listCabActa;
						List<DetItemsActa> listDetItemActa = this.consultarDetalleActa(cabActaResult, regPrec.getNumserpre());
						if (CollectionUtils.isEmpty(listDetItemActa)) {
							//Serie […]: Serie/Item […] del <TipoDocumento> N� AAA-20XX-RR-YYYYYY  no existe
							listMapError.add(catalogoAyudaService.getError("37214", new String[]{serie.getNumserie().toString(), SunatStringUtils.toStringObj(regPrec.getNumserpre()), "ACTA DE INCAUTACION", strPrecedencia}));
						} else {
							if (!listDetItemActa.get(0).getCptocPreco().equals(codAreaEquipaje)) {//csantillan bug P_SNAA0004-15591
								listMapError.add(catalogoAyudaService.getError("32032", new String[]{serie.getNumserie().toString(), strPrecedencia}));
							}
						}
					}
				}
			}
		}
		return listMapError;
	}

	private String getAreaEquipaje(String codAduana ) {
		//csantillan PAS20191U220200002 -- Se descomenta por bug P_SNAA0004-15677
		String codAreaEquipaje =  new String();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listServiciosCatalogo =  catalogoAyudaService.getListaElementosAsoc(ConstantesTipoCatalogo.CATALOGO_ASOCIACION_ADUANA_AREAEQUIPAJE, "C", codAduana);
		if (!CollectionUtils.isEmpty(listServiciosCatalogo)) {
			codAreaEquipaje = listServiciosCatalogo.get(0).get("cod_datacat");
		} else {
			codAreaEquipaje = null;
		}
		return codAreaEquipaje;
	}

	private CabActas  consultarActaIncautacionPrece(DatoRegPrecedencia regPrec, String codAreaEquipaje) {
		ConsultaMedidaPreventivaService consultaMedidaPreventivaSevice = (ConsultaMedidaPreventivaService)fabricaDeServicios.getService("prevcontrabando2.consultaMedidaPreventivaService");
		CabActas cabActas = new CabActas();
		cabActas.setCaduaPreco(regPrec.getCodaduapre());
		cabActas.setFannoPreco(SunatStringUtils.substring(regPrec.getAnndeclpre(),0,4));
		cabActas.setNcorrPreco(SunatStringUtils.lpad(regPrec.getNumdeclpre(),6,'0'));
		cabActas.setNelimRegis(0);
		cabActas.setCptocPreco(codAreaEquipaje);
		CabActas listCabActa = consultaMedidaPreventivaSevice.consultarActaIncautacionPrece(cabActas);
		return listCabActa;
	}

	private List<DetItemsActa> consultarDetalleActa(CabActas cabActaResult, Integer numSerpre) {
		ConsultaMedidaPreventivaService consultaMedidaPreventivaSevice = (ConsultaMedidaPreventivaService)fabricaDeServicios.getService("prevcontrabando2.consultaMedidaPreventivaService");
		DetItemsActa detItemActas = new DetItemsActa();
		detItemActas.setCaduaPreco(cabActaResult.getCaduaPreco());
		detItemActas.setFannoPreco(cabActaResult.getFannoPreco());
		detItemActas.setNcorrPreco(SunatStringUtils.substring(cabActaResult.getNcorrPreco(),0,6));
		detItemActas.setCptocPreco(cabActaResult.getCptocPreco());
		detItemActas.setCtdocPreco(cabActaResult.getCtdocPreco());
		detItemActas.setNelimRegis(cabActaResult.getNelimRegis());
		detItemActas.setNumitem(numSerpre);
		List<DetItemsActa> listDetItemActa = consultaMedidaPreventivaSevice.consultarDetalleActa(detItemActas);
		return listDetItemActa;
	}

	private  List<Map<String,String>> valActaIncautacionEquipajeAdicional (CabActas cabActaResult, Date fechaReferencia, String numeSerie, String strPrecedencia, DatoRegPrecedencia regPrec) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
		String codAnulacion = SunatStringUtils.toStringObj(cabActaResult.getNelimRegis());
		Date fechaNotificacion = cabActaResult.getFecNotif();

		Date fechaPlazoMaximo = this.getFechaVencimiento(regPrec, fechaReferencia, fechaNotificacion);
		if (SunatStringUtils.isEqualTo(codAnulacion, ConstantesDataCatalogo.IND_REGISTRO_INACTIVO)){
			//Serie […]:Acta de Incautaci�n N� AAA-XXXX-AC-YYYYYY-Z est� anulada
			listMapError.add(catalogoAyudaService.getError("37215",new String[] {numeSerie, strPrecedencia }));
		}

		if (SunatDateUtils.isDefaultDate(fechaNotificacion)|| fechaNotificacion==null) {
			//Serie […]:Acta de Incautaci�n N� AAA-XXXX-AC-YYYYYY-Z no est� Notificada
			listMapError.add(catalogoAyudaService.getError("37016",new String[] {numeSerie, strPrecedencia }));
		}

		if (SunatDateUtils.esFecha1MayorQueFecha2(fechaReferencia,fechaPlazoMaximo, SunatDateUtils.COMPARA_SOLO_FECHA)){
			//Verificar Expediente de suspension de plazo
			String[] codProcedimSuspencion = {SUSPENCION_PLAZO_REGULARIZACION_DESPACHO_ANTICIPADO_URGENTE,SUSPENCION_PLAZO_VCTO_ART78};
			ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
			List<Map<String, Object>> expedienteSuspension = funcionesService.buscarExpedienteSuspensionPrece
					(cabActaResult.getCaduaPreco(), cabActaResult.getFannoPreco(), cabActaResult.getCtipoActa(), cabActaResult.getNcorrPreco(),fechaPlazoMaximo,codProcedimSuspencion);
			if (CollectionUtils.isEmpty(expedienteSuspension)  ) {
				//Serie […]: Acta de Incautaci�n N� AAA-XXXX-AC-YYYYYY se encuentra vencida
				listMapError.add(catalogoAyudaService.getError("37217",new String[] {numeSerie, strPrecedencia }));
			}
			// Se actualiza la fecha de vencimiento con respecto a la fecha maxima de uso del AC
						regPrec.setFecvencpre(fechaPlazoMaximo);
		} else {
			// Se actualiza la fecha de vencimiento con respecto a la fecha maxima de uso del AC
			regPrec.setFecvencpre(fechaPlazoMaximo);
		}
		return listMapError;
	}

	public  Date getFechaVencimiento(DatoRegPrecedencia regPrec, Date fechaReferencia, Date fechaNotificacion) {
		if (fechaNotificacion == null || SunatDateUtils.isDefaultDate(fechaNotificacion)) {
			String codAreaEquipaje = this.getAreaEquipaje(regPrec.getCodaduapre());
			if (SunatStringUtils.isEmptyTrim(codAreaEquipaje)) {
				return null;
			}
			CabActas listCabActa = this.consultarActaIncautacionPrece(regPrec, codAreaEquipaje);
			if (listCabActa==null) {
				return null;
			}
			CabActas cabActaResult = listCabActa;
			fechaNotificacion = cabActaResult.getFecNotif();
		}
		//El plazo de 30 dias debe estar en DataCatalogo
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DataCatalogo catPlazoModalidadAnticipada = catalogoAyudaService.getDataCatalogo(
				ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,
				ConstantesDataCatalogo.COD_PLAZO_ACOGIMIENTO_EQUIPAJES, fechaReferencia);
		Integer plazoAcogimientoEquipaje = SunatNumberUtils.toInteger(catPlazoModalidadAnticipada.getDesCorta());
		Date fechaPlazoMaximo = null;
		fechaPlazoMaximo=this.getFechaHabil(fechaNotificacion, plazoAcogimientoEquipaje, regPrec.getCodaduapre());
		return fechaPlazoMaximo;
	}


	private Date getFechaHabil(Date fechaNotificacion , Integer plazoAcogimientoEquipaje, String codAduanaOrden) {
		Map<String, Object> paramDias = new HashMap<String, Object>();
		paramDias.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(fechaNotificacion));
		paramDias.put("FECHAHASTA", plazoAcogimientoEquipaje);
		paramDias.put("TIPO", 2);
		paramDias.put("INCLUYE", "S");
		paramDias.put("SUSPENDE", "S");
		DiasUtilesDAO diasUtilesDAOsolicitud = fabricaDeServicios.getService("despaduanero2.solicitud.diasUtilesDAO");
		DataSourceContextHolder.setKeyDataSource(codAduanaOrden);
		String resultadoDiaUtil = diasUtilesDAOsolicitud.getSPDiasUtiles(paramDias); // yyyyMMdd
		Date fechaHabil = SunatDateUtils.getDateFromInteger(Integer.parseInt(resultadoDiaUtil));
		return fechaHabil;
	}

	private Map<String, String> validarPuntoLlegada (String puntoLlegada){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String,String> mapError=new HashMap<String,String>();
		String codigoPuntoLLegadaMercancia =puntoLlegada!=null?puntoLlegada.toString():"";
		if (!SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL)){
			//El punto de llegada para precedente Acta de incautaci�n debe ser Control de Equipajes Internacional
			mapError = catalogoAyudaService.getError("37219",new String[] {codigoPuntoLLegadaMercancia, ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL});
		}
		return mapError;
	}

}
