package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
/*branch 2011-009 hosorio inicio*/
public class ComparadorDeclaracionAdmisionTemporal extends ComparadorDeclaracion {

	public ComparadorDeclaracionAdmisionTemporal(FabricaDeServicios fabricaDeServicios){
		super(fabricaDeServicios);
	}
	
	public void comparacionListaseries(Elementos<DatoSerie> listaRectificado, Elementos<DatoSerie> listaActual) throws Exception {
		int iserie = 0;
		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoSerie rectificado : listaRectificado) {
				DatoSerie actual = (DatoSerie) buscarEnLista(listaActual, rectificado);
				comparacionDetDeclara(rectificado, actual, iserie);
				//comparacionDetImpoConsumo(rectificado.getDatoAdiSerieImpoConsumo(), actual.getDatoAdiSerieImpoConsumo(), iserie);
				comparacionDetImpoConsumo(rectificado.getDatoAdiSerieImpoConsumo(), actual!=null ? actual.getDatoAdiSerieImpoConsumo(): null, iserie);
				comparacionDetAdmTemp(rectificado, actual, iserie);
				//comparacionSerieReexp(rectificado.getDatoAdiSerieAtreexp(), actual.getDatoAdiSerieAtreexp(), iserie);
				comparacionSerieReexp(rectificado.getDatoAdiSerieAtreexp(),  actual!=null ? actual.getDatoAdiSerieAtreexp(): null, iserie);
				comparacionConveniosSerie(rectificado, actual, iserie);
				comparacionListaDeclPrecede(rectificado, actual, iserie);
				comparacionListaVehiculoCetico(rectificado, actual, iserie);
				comparacionListaSerieDocSoporteAutoriz(rectificado, actual, iserie);
				comparacionListaSerieDocSoporteFactura(rectificado, actual, iserie);
				iserie++;
			}// fin de SERIES
		}
	}
}
