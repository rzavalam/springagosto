package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.lentes;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesGafa;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorLentesGafa extends ValidadorLentesAbstract
{
  
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    // TODO Auto-generated method stub
	  List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

	  //lstErrores.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores)){
          DatoItem item = obtenerItem(objeto, dua);
          //lstErrores.addAll(validarNombreComercial(objeto, item));
          lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarMaterial(objeto));
//          lstErrores.addAll(validarTipoLente(objeto));
          lstErrores.addAll(validarNroFocos(objeto));
          lstErrores.addAll(validarColor(objeto));
          lstErrores.addAll(validarTratamiento(objeto));
//          lstErrores.addAll(validarAcabado(objeto));
      }

    return lstErrores;
  }
  @Override
  public List<ErrorDescrMinima> validarMaterial(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    LentesGafa gafa = (LentesGafa) object;
    String materialMontura = gafa.getMaterialMontura().getValtipdescri();
    String materialLente   = gafa.getMaterialLente().getValtipdescri();
    String nombreComercial = gafa.getNombreComercial().getValtipdescri();
    
    if(SunatStringUtils.isEqualTo(GAFAS_SOL,nombreComercial) || 
    		SunatStringUtils.isEqualTo(GAFAS_CORRECT,nombreComercial)){
      if(!((SunatStringUtils.isEqualTo(PLASTICO,materialMontura) || 
    		  SunatStringUtils.isEqualTo(TITANIO,materialMontura) ||
    		  SunatStringUtils.isEqualTo(METAL,materialMontura) || 
    		  SunatStringUtils.isEqualTo(COD_ZZZ,gafa.getMaterialMontura().getCodtipvalor())))){
    	  lst.add(obtenerError("31450",gafa.getMaterialMontura()));//F5
      }
      if(!((SunatStringUtils.isEqualTo(CRISTAL,materialLente) || 
    		  SunatStringUtils.isEqualTo(RESINA,materialLente) || 
    		  SunatStringUtils.isEqualTo(POLICARBONATO,materialLente)))){
        lst.add(obtenerError("31451",gafa.getMaterialLente())); //F6
      }
    }
    return lst;
  }
}
