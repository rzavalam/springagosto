package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public abstract class IngresoAbstractServiceImpl {
	protected final Log log = LogFactory.getLog(getClass());
    
    @Autowired
    @Qualifier("ingreso2.fabricaDeServicios")
	protected FabricaDeServicios fabricaDeServicios;
        
    public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
        this.fabricaDeServicios = fabricaDeServicios;
    }

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}




}
