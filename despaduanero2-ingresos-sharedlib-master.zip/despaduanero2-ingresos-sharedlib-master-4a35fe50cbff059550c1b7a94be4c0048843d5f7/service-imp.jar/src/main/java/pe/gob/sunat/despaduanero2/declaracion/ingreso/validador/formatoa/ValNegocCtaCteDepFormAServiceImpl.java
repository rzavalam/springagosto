package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Depocta;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.DepoctaDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Seriesd;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionDepositoAduaneroService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;

public class ValNegocCtaCteDepFormAServiceImpl extends ValDuaAbstract implements ValNegocCtaCteDepFormA{
	//private HotSwappableTargetSource swapperDatasource;
	//private FabricaDeServicios fabricaDeServicios;
	//SPTD_Ctactedeposito
	/**
	 * En el Mapa vienen los siguientes parametros
	   "caduregpre", datoRegPreActual.getCodaduapre());
	   "fanoregpre", datoRegPreActual.getCodaduapre());
	   "ndclregpre", datoRegPreActual.getCodaduapre());
	   "numserpre", datoRegPreActual.getCodaduapre());
	   "sumPesoBruto", datoSerieActual.getCntpesobruto());
	   "sumCntunifis", datoSerieActual.getCntunifis());
	 * 
	 */
	public List<Map<String,String>> ctaCteDeposito(Map<String,Object> datosDepocCta){
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();

		//Extraemos los valores del Mapa
		String codregipre = (String)datosDepocCta.get("codregipre");
		String pcaduregpre=datosDepocCta.get("caduregpre").toString();
		String pfanoregpre=datosDepocCta.get("fanoregpre").toString().substring(0, 4);
		String pndclregpre=datosDepocCta.get("ndclregpre").toString();
		Integer pnume_serpr=(Integer)datosDepocCta.get("numserpre");
		String CDAPrece = pcaduregpre+"-"+pfanoregpre+"-"+codregipre+"-"+pndclregpre+"-"+pnume_serpr.toString(); 

		BigDecimal ppeso_bruto=(BigDecimal)datosDepocCta.get("sumPesoBruto");
		BigDecimal punid_fiqty=(BigDecimal)datosDepocCta.get("sumCntunifis");

		BigDecimal p_peso_bruto=BigDecimal.ZERO;
		BigDecimal d_unid_fiqty=BigDecimal.ZERO;
		BigDecimal p_unid_fiqty=BigDecimal.ZERO;
		BigDecimal d_peso_brafo=BigDecimal.ZERO;
		String numeroSerie = "";
		String codiError="";
		Map<String,String> paramsDetDeclaracion=new HashMap<String,String>();
		paramsDetDeclaracion.put("cod_aduana", pcaduregpre);
		paramsDetDeclaracion.put("ann_presen", pfanoregpre);
		paramsDetDeclaracion.put("cod_regimen", codregipre);
		paramsDetDeclaracion.put("num_declaracion", pndclregpre);
		paramsDetDeclaracion.put("num_secserie", pnume_serpr.toString());

		/**
		 * Obtenemos el peso y unidades fisicas de la serie de la precedencia, se busca en NSIGAD caso contrario vamos al ASIGAD
		 */
		List<Map<String,Object>> duaPrecedente = new ArrayList<Map<String,Object>>();
		duaPrecedente = ((DetDeclaraDAO)fabricaDeServicios.getService("detDeclaraDAO")).findSeriesByDocumento(paramsDetDeclaracion);
		if (CollectionUtils.isEmpty(duaPrecedente)){
			ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduanero = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
			Seriesd seriesd = consultaDeclaracionDepositoAduanero.consultarSerieDeposito(pfanoregpre.substring(2, 4),pcaduregpre, SunatStringUtils.lpad(pndclregpre, 6, '0'), SunatStringUtils.lpad(String.valueOf(pnume_serpr.intValue()),4,' '));
			if (seriesd==null){
				//Solo se retorna, el error se encuentra en las validaciones de regimen de precedencia
				return listError;
			} else{
				d_unid_fiqty = seriesd.getUnidFiqty();
				d_peso_brafo = seriesd.getPesoBrafo();
				 numeroSerie = seriesd.getNumeSerie();
			}
		} else{
			d_unid_fiqty = SunatNumberUtils.toBigDecimal(duaPrecedente.get(0).get("CNT_UNIFIS"));
			d_peso_brafo = SunatNumberUtils.toBigDecimal(duaPrecedente.get(0).get("CNT_PESO_BRUTO"));
			 numeroSerie = duaPrecedente.get(0).get("NUM_SECSERIE").toString();
		}


		/**
		 * Pasa todas las validaciones del regimen de precedencia a ValNegocDuaregap a excepcion de los que tienen que ver con el depocta
		 */		

		// Debe buscar en la instancia centralizada ya que puede existir descargos por aduanas diferentes.
		HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
		Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." +ConstantesDataCatalogo.ADUANA_CENTRALIZADA));
		Map<String,Object> paramsCtaCte=new HashMap<String, Object>();
		paramsCtaCte.put("anoPrese", pfanoregpre.substring(2, 4));
		paramsCtaCte.put("codiAduan", pcaduregpre);
		paramsCtaCte.put("numeCorre", SunatStringUtils.lpad(pndclregpre,6,'0'));
		paramsCtaCte.put("numeSerpr", SunatStringUtils.lpad(String.valueOf(pnume_serpr.intValue()),4,' '));
		paramsCtaCte.put("notSdel", "S");
		List<Depocta> listDepocta = new ArrayList<Depocta>();

		listDepocta=((DepoctaDAO)fabricaDeServicios.getService("depoctaDAO")).findByMap(paramsCtaCte);
		swapperDatasource.swap(o);
		/**
		 * NSR: Sumamos los valores devueltos de depocta ya que corresponden a la misma serie precedente
		 * Esta linea hace lo mismo que hace el query comentado
		 */
		/**
		 * ESM: los valores deben sumarse sin considerar el numero de la serie 
		 * PAS20134E600000059
		 */
		Map<String,Object> mapValoresCtaCte = SumValoresDepocta(listDepocta);
		Map<String,Object> mapValoresCtaCteUsadaporSerieActual = new HashMap<String, Object>();
		BigDecimal p_peso_Usado = BigDecimal.ZERO;
		BigDecimal p_unid_fiqty_Usado = BigDecimal.ZERO;
		if (!CollectionUtils.isEmpty(listDepocta)){
			for(Depocta depocta:listDepocta){


				if(depocta.getNumePoliz().equals((String)datosDepocCta.get("ndclActual"))
						&& depocta.getRegiPoliz().equals((String)datosDepocCta.get("codregiActual"))
						){
					p_peso_Usado = SunatNumberUtils.sum(p_peso_Usado,depocta.getPesoBruto()); 
					p_unid_fiqty_Usado = SunatNumberUtils.sum(p_unid_fiqty_Usado,depocta.getUnidFiqty()); 

				}

			}
		}
		mapValoresCtaCteUsadaporSerieActual.put("p_peso_bruto", p_peso_Usado);
		mapValoresCtaCteUsadaporSerieActual.put("p_unid_fiqty", p_unid_fiqty_Usado);	

		p_peso_bruto=(BigDecimal)mapValoresCtaCte.get("p_peso_bruto");
		p_unid_fiqty=(BigDecimal)mapValoresCtaCte.get("p_unid_fiqty");

		if( SunatNumberUtils.isGreaterThanZero((BigDecimal)mapValoresCtaCteUsadaporSerieActual.get("p_peso_bruto"))){ 
			p_peso_bruto=SunatNumberUtils.diference(p_peso_bruto, (BigDecimal)mapValoresCtaCteUsadaporSerieActual.get("p_peso_bruto"));
		}
		if( SunatNumberUtils.isGreaterThanZero((BigDecimal)mapValoresCtaCteUsadaporSerieActual.get("p_unid_fiqty"))){ 
			p_unid_fiqty=SunatNumberUtils.diference(p_unid_fiqty, (BigDecimal)mapValoresCtaCteUsadaporSerieActual.get("p_unid_fiqty"));
		}


		BigDecimal totpesob=SunatNumberUtils.diference(d_peso_brafo, SunatNumberUtils.sum(p_peso_bruto, ppeso_bruto));
		BigDecimal totunid= SunatNumberUtils.diference(d_unid_fiqty, SunatNumberUtils.sum(p_unid_fiqty, punid_fiqty));

		//NSR: Calculo el Saldo para el mensaje de Error, aunque se deberia realizar la validacion con el Saldo no con la formulas de arriba. 
		BigDecimal SaldoPesoBruto = SunatNumberUtils.diference(d_peso_brafo,p_peso_bruto);
		BigDecimal SaldoUnidFiqty = SunatNumberUtils.diference(d_unid_fiqty,p_unid_fiqty);

		if (SunatNumberUtils.isLessThanZero(totpesob)){
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30539",	new String[] {CDAPrece,SaldoPesoBruto.toString(),ppeso_bruto.toString(),numeroSerie}));//Pase548
		}
		if (SunatNumberUtils.isLessThanZero(totunid)){	
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30540",	new String[] {CDAPrece,SaldoUnidFiqty.toString(),punid_fiqty.toString(),numeroSerie}));//pase548
		}

		if ( SunatNumberUtils.isEqualToZero(totunid)){
			if( !SunatNumberUtils.isEqualToZero(totpesob)){
				/* INICIO - PAS20165E220300041 - RF02 - JHINOSTROZAN */
				// ATENCI�N DE INCIDENCIA M_SNADE255-758
				//codiError="0947";
				//listError.add(ResponseMapManager.getErrorResponseMap(codiError,"DEBE DECLARAR POR EL TOTAL DEL PESO BRUTO PENDIENTE DE REGULARIZAR EN LA DUA DEP�SITO("+CDAPrece+")"));
				codiError = "35765";
				listError.add(((CatalogoAyudaService) fabricaDeServicios
						.getService("Ayuda.catalogoAyudaService")).getError(
						codiError,
						new String[] {
								numeroSerie,
								ppeso_bruto.toString(),
								totpesob.toString(),
								punid_fiqty.toString(),
								totunid.toString(),
								pcaduregpre + "-" + pfanoregpre + "-"
										+ codregipre + "-" + pndclregpre }));
				/* FIN - PAS20165E220300041 - RF02 - JHINOSTROZAN */
			}
		}
		if ( SunatNumberUtils.isEqualToZero(totpesob)){
			if( !SunatNumberUtils.isEqualToZero(totunid)){
				codiError="30565";
				/* INICIO - PAS20165E220300041 - RF02 - JHINOSTROZAN */
				// ATENCI�N DE INCIDENCIA M_SNADE255-757
				//listError.add(ResponseMapManager.getErrorResponseMap(codiError,"DEBE DECLARAR POR EL TOTAL DE UNIDADES FISICAS PENDIENTE DE REGULARIZAR EN LA DUA DEP�SITO ("+CDAPrece+")"));
				listError.add(((CatalogoAyudaService) fabricaDeServicios
						.getService("Ayuda.catalogoAyudaService")).getError(
						codiError,
						new String[] {
								numeroSerie,
								ppeso_bruto.toString(),
								totpesob.toString(),
								punid_fiqty.toString(),
								totunid.toString(),
								pcaduregpre + "-" + pfanoregpre + "-"
										+ codregipre + "-" + pndclregpre }));
				/* FIN - PAS20165E220300041 - RF02 - JHINOSTROZAN */
			}
		}					
		return listError;
	}

	private Map<String,Object> SumValoresDepocta(List<Depocta> listDepocta){
		Map<String,Object> mapDepocta=new HashMap<String,Object>();
		BigDecimal p_peso_bruto = BigDecimal.ZERO;
		BigDecimal p_unid_fiqty = BigDecimal.ZERO;
		if (!CollectionUtils.isEmpty(listDepocta)){
			for(Depocta depocta:listDepocta){
				p_peso_bruto = SunatNumberUtils.sum(p_peso_bruto,depocta.getPesoBruto()); 
				p_unid_fiqty = SunatNumberUtils.sum(p_unid_fiqty,depocta.getUnidFiqty()); 
			}
		}
		mapDepocta.put("p_peso_bruto", p_peso_bruto);
		mapDepocta.put("p_unid_fiqty", p_unid_fiqty);
		return mapDepocta;
	}
	
	
	/**
	 * Val ct cte deposito.
	 * 
	 * @param declaracion Declaracion
	 * @param declaracionBD Declaracion
	 * @param variablesIngreso Map<String,Object>
	 * @return el list
	 * @throws Exception excepci�n exception
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3032, descServicio = "valida cuenta corriente de deposito")
	@ServInstDetAnnot(tipoRpta = { 1, 1, 1 }, nomAtr = { "declaracion", "declaracionBD", "variablesIngreso" })
	@OrquestaDespaAnnot(codServInstancia = 3032, numSecEjec = 424, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> valCtCteDeposito(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso)
			throws Exception {
		//branch ingreso 2011-009 gmontoya 15	
		List<Map<String, String>> resultadoError = new ArrayList<Map<String, String>>();
		 


		
		// si no ha declarado reg. precedencia en la numeracion ,pero si en la rectificacion
		if (!isRegimenDeposito(declaracionBD) && isRegimenDeposito(declaracion)) {
			// validar cuenta corriente componente de gustavo
			//branch ingreso 2011-009 gmontoya 15
			variablesIngreso.put("fechaVigenciaRegimenBD", declaracionBD.getDua().getFecdeclaracion());
			variablesIngreso.put("numeroDeclaracion", declaracionBD.getNumdeclRef().getNumcorre());
//			resultadoError = RectificacionServiceImpl.getInstance().getValidacionesService().getValNegocNumeracFormA().validarCtaCteDeposito(
			ValRegPrecDepositoService valRegPrecDepositoService = fabricaDeServicios.getService("ingreso.ValRegPrecDeposito");
			resultadoError = valRegPrecDepositoService.validarCtaCteDeposito(
					declaracion, variablesIngreso);
			variablesIngreso.remove("fechaVigenciaRegimenBD");
			variablesIngreso.remove("numeroDeclaracion");
			// si existe saldo suficiente . Es decir no hay errores

			if (resultadoError.isEmpty())
				variablesIngreso.put("indAfectaDesafectaRegPreDepo", "A");
		} else if (isRegimenDeposito(declaracionBD) && isRegimenDeposito(declaracion))
		// si ha declarado el regimen precedente en la numeracion y rectificacion pero cambia los montos
		{
			// si cambia el total de unidades fisicas
			BigDecimal totalUnidFisDeclarado = obtenerTotalUnidadesFisicaDeposito(declaracionBD);
			BigDecimal totalUnidFisRectificado = obtenerTotalUnidadesFisicaDeposito(declaracion);
			
			//branch ingreso 2011-009 gmontoya 15
			// si cambia el total de pesos brutos
			BigDecimal totalPesoBrutoDeclarado = obtenerTotalPesosBrutosDeposito(declaracionBD);
			BigDecimal totalPesoBrutoRectificado = obtenerTotalPesosBrutosDeposito(declaracion);

			// si rectificado > a declarado se debe validar la cta cte de deposito
			//if ((totalUnidFisRectificado.compareTo(totalUnidFisDeclarado) != 0)|| (totalPesoBrutoRectificado.compareTo(totalPesoBrutoDeclarado) != 0)){
				// validar cuenta corriente componente de gustavo
				// si existe saldo suficiente
				variablesIngreso.put("fechaVigenciaRegimenBD", declaracionBD.getDua().getFecdeclaracion());
				variablesIngreso.put("numeroDeclaracion", declaracionBD.getNumdeclRef().getNumcorre());
				ValRegPrecDepositoService valRegPrecDepositoService = fabricaDeServicios.getService("ingreso.ValRegPrecDeposito");
				resultadoError = valRegPrecDepositoService.validarCtaCteDeposito(
						declaracion, variablesIngreso);
				variablesIngreso.remove("fechaVigenciaRegimenBD");
				variablesIngreso.remove("numeroDeclaracion");
				if (resultadoError.isEmpty())
					variablesIngreso.put("indAfectaDesafectaRegPreDepo", "A");
				else {
					// se desafecta
					variablesIngreso.put("indAfectaDesafectaRegPreDepo", "D");
				}
			//}
			//fin

		}
		// si se ha declarado en la numeracion , pero no en la rectificacion=> se desafecta
		else if (isRegimenDeposito(declaracionBD) && !isRegimenDeposito(declaracion)) {
			// se desafecta
			variablesIngreso.put("indAfectaDesafectaRegPreDepo", "D");

		}		
		return resultadoError;
	}

	/**
	 * Obtener total unidades fisica deposito.
	 * 
	 * @param declaracion
	 *            Declaracion
	 * @return el big decimal
	 */
	private BigDecimal obtenerTotalUnidadesFisicaDeposito(Declaracion declaracion) {

		BigDecimal totalUnidFisicas = BigDecimal.ZERO;
		if (!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())) {
			for (DatoSerie serie : declaracion.getDua().getListSeries()) {
				if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
					for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
						if ("70".equals(regPrec.getCodregipre()))
							totalUnidFisicas = SunatNumberUtils.sum(totalUnidFisicas, serie.getCntunifis());
					}
				}
			}
		}

		return totalUnidFisicas;
	}	
	/**
	 * Obtener total pesos brutos deposito.
	 * 
	 * @param declaracion
	 *            Declaracion
	 * @return el big decimal
	 */
	private BigDecimal obtenerTotalPesosBrutosDeposito(Declaracion declaracion) {

		BigDecimal totalPesosBrutos = BigDecimal.ZERO;
		if (!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())) {
			for (DatoSerie serie : declaracion.getDua().getListSeries()) {
				if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
					for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
						if ("70".equals(regPrec.getCodregipre()))
							totalPesosBrutos = SunatNumberUtils.sum(totalPesosBrutos, serie.getCntpesobruto());
					}
				}
			}
		}

		return totalPesosBrutos;
	}		
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}
	
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	public HotSwappableTargetSource getSwapperDatasource() {
		return swapperDatasource;
	}
	
	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}*/
}
