package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.tecnologia.receptor.model.Control;//RIN10
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;//RIN10

public class ValmontoFBServiceImpl extends ValDuaAbstract implements ValmontoFB{

	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos
	 */
    /*GGRANADOS FORMB
	public Map<String, String> indestiprov(java.lang.String arg) {
		java.util.Map<String, String> result = new HashMap<String, String>();
		if (!catalogoHelper.isValid(arg, "332"))
			//TODO set errorCode
			result = catalogoHelper.getErrorMap("");
		return result;
	}*/

	/**
	 * Valida el codigo de moneda del monto
	 * @param datoMontoProv
	 * @return
	 */
	public List<Map<String, String>> codmoneda(DatoMontoProv montoProv){
        List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

        if (((Declaracion) montoProv.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
            return listErr;
        }
        
		if (montoProv.getValdefinitivo() == null
				&& montoProv.getIndtipovalor() == null
				&& montoProv.getCodmoneda() == null
				&& montoProv.getValmonto() == null
				&& montoProv.getFecvalestima() == null) {
			return listErr;
		}

        //if (montoProv != null && SunatStringUtils.isEqualTo(montoProv.getIndtipovalor(), "2")) {
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J1", montoProv.getCodmoneda()));
		//if (montoProv.getValmonto()!= null &&  (SunatStringUtils.isEmpty(montoProv.getCodmoneda()) || !catalogoHelper.isValid(montoProv.getCodmoneda(), "J1"))){
		if (montoProv.getValmonto()!= null &&  (SunatStringUtils.isEmpty(montoProv.getCodmoneda()) || !validaCatalogo)){
                listErr.add(getErrorMap("30166",
                        new Object[] { ((DAV) montoProv.getPadre().getPadre().getPadre()).getNumsecuprov(),
                                ((DatoFactura) montoProv.getPadre().getPadre()).getNumsecfactu(),
                                ((DatoItem) montoProv.getPadre()).getNumsecitem(), 
                                montoProv.getCodmoneda()!=null?montoProv.getCodmoneda():" " }));
        }
        

        return listErr;
    }

	/**
	 * Valida la fecha del tipo de cambio
	 * @param monto
	 * @return
	 */
    public List<Map<String, String>> fectipocambio(DatoMontoProv monto){
        List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

        if (((Declaracion) monto.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
            return listErr;
        }

        if (monto != null && SunatStringUtils.isEqualTo(monto.getIndtipovalor(), "2")) {
            if (monto.getFectipocambio() == null) {
            	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");            
                listErr.add(catalogoAyudaService.getError("30167"));
            }
        }

        return listErr;
    }

/**
	 * Valida la fecha de valor estimada
	 * @param monto
	 * @return
	 */
    public List<Map<String, String>> fecvalestima(DatoMontoProv monto){
        List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

        if (((Declaracion) monto.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
            return listErr;
        }

        if (monto != null && SunatStringUtils.isEqualTo(monto.getIndtipovalor(), "2")) {
            if (monto.getFecvalestima() == null) {
            	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
                listErr.add(catalogoAyudaService.getError("30168"));
            }
        }

        return listErr;
    }

	/**
	 * Valida el indicador de tipo de valor
	 * @param datoMontoProv
	 * @return
	 */
    //GGRANADOS FORMB
    public Map<String, String> indtipovalor(DatoMontoProv montoProv){
        Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) montoProv.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
        
		if (montoProv.getValdefinitivo() == null
				&& montoProv.getIndtipovalor() == null
				&& montoProv.getCodmoneda() == null
				&& montoProv.getValmonto() == null
				&& montoProv.getFecvalestima() == null) {
			return result;
		}
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("332", montoProv.getIndtipovalor()));
        //if (SunatStringUtils.isEmpty(montoProv.getIndtipovalor()) || !catalogoHelper.isValid(montoProv.getIndtipovalor(), "332"))
		if (SunatStringUtils.isEmpty(montoProv.getIndtipovalor()) || !validaCatalogo)
            result = getErrorMap("30347",
                    new Object[] { ((DAV) montoProv.getPadre().getPadre().getPadre()).getNumsecuprov(),
                            ((DatoFactura) montoProv.getPadre().getPadre()).getNumsecfactu(),
                            ((DatoItem) montoProv.getPadre()).getNumsecitem(),
                            montoProv.getIndtipovalor()!=null?montoProv.getIndtipovalor():" "});

        return result;
    }
	
	/**
	 * Valida el valor del monto
	 * @param monto
	 * @return
	 */
    public List<Map<String, String>> valmonto(DatoMontoProv monto){
    	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

        if (((Declaracion) monto.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
            return listErr;
        }
        if (monto != null) {
            if (SunatStringUtils.isEqualTo(monto.getIndtipovalor(), "1")) {
                if (!SunatNumberUtils.isGreaterThanZero(monto.getValdefinitivo())) {
                	//RIN 10 - BUG 21740 - Percy HM - inicio
                	try{
                		//Para las transacciones 1001, 1003, se indica el item o serie
                		Mensaje mensaje = (Mensaje)monto.getPadre().getPadre().getPadre().getPadre().getPadre();
                		Control control = mensaje.getControl();
                		
                		if(control.getTipoDeTransaccion().equals("1001") || control.getTipoDeTransaccion().equals("1003")){
                			if(monto.getPadre() instanceof pe.gob.sunat.despaduanero2.declaracion.model.DatoItem){
                    			DatoItem datoItem = (DatoItem)monto.getPadre();
                    			listErr.add(getErrorMap("35567", new Object[]{"ITEM", datoItem.getNumsecitem(), monto.getValdefinitivo()}));
                    			return listErr;
                			}
                		}
                	}catch(Exception e){
                		//e.printStackTrace();
                	}
                	//RIN 10 - BUG 21740 - fin
                    listErr.add(catalogoAyudaService.getError("30170"));
                }
            }
            if (SunatStringUtils.isEqualTo(monto.getIndtipovalor(), "2")) {
                if (!SunatNumberUtils.isGreaterThanZero(monto.getValmonto()))
                    listErr.add(catalogoAyudaService.getError("30169"));
            }
        }

        return listErr;
    }

	/**
     * Valida el valor definitivo
     * @param monto
     * @return
     */
    //COMENTADO EN LA TX XX01 GGRANADOS FORMB
    public List<Map<String, String>> valdefinitivo(DatoMontoProv monto){

        List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

        if (((Declaracion) monto.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
            return listErr;
        }

        if (monto != null && SunatStringUtils.isEqualTo(monto.getIndtipovalor(), "1")) {
            if (!SunatNumberUtils.isGreaterThanZero(monto.getValdefinitivo())){
            	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
                listErr.add(catalogoAyudaService.getError("30170"));
            }
        }
        return listErr;
    }

	
		
	/**
	 * Validar c�digo del monto de la determinaci�n del valor	  
	 * @param dav
	 * @return map
	 * @pase PAS20134E610000270 FORMATO B 
	 */
    public Map<String, String> validarCodigoMontoFormatoB(DatoMonto datoMonto){
        Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) datoMonto.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
        boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J3", datoMonto.getCodmonto()));
        //if (!catalogoHelper.isValid(datoMonto.getCodmonto(), "J3"))
        if (!validaCatalogo)
            result = getErrorMap("30597", new Object[] { ((DAV) datoMonto.getPadre()).getNumsecuprov(),
                    datoMonto.getCodmonto() });

        return result;
    }


}
