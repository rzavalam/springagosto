/*
 * Clase que define el servicio de validaciones de la mercancia
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValMcia. Clase que define el servicio de validaciones de la mercancia.
 */
public class ValMciaServiceImpl extends ValDuaAbstract implements ValMcia{
	
	//private FabricaDeServicios fabricaDeServicios;

	/**
	 * Valida el C�digo del tipo de mercancia restringida o prohibida.<br>
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipoexoneracion String. C�digo del tipo de mercancia restringida o prohibida
	 * @return Map
	 */
	public Map<String, String> codtipoexoneracion(String codtipoexoneracion){
		if (!SunatStringUtils.isEmptyTrim(codtipoexoneracion)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("333", codtipoexoneracion))
			boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("333", codtipoexoneracion,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				return getDUAError("30021","Error catalogo codtipoexoneracion");
		}
		return new HashMap<String,String>();
	}

	/**
	 * Valida el C�digo de exoneraci�n de mercanc�a restringida o prohibida.  Envia en ambos casos c�digo 98.<br>
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codexoneracion String. C�digo de exoneraci�n de mercanc�a restringida o prohibida.
	 * @return Map
	 */
	public Map<String, String> codexoneracion(String codexoneracion){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("49", codexoneracion))
		if (SunatStringUtils.isEmpty(codexoneracion) || "98".equals(codexoneracion) || "97".equals(codexoneracion))
			return new HashMap<String,String>();
		else
			return getDUAError("00150","Error catalogo codexoneracion");
	}

	/**
	 * Valida el C�digo de producto restringido o prohibido.<br>
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codproducto String. C�digo de producto restringido o prohibido.
	 * @return Map
	 */
	public Map<String, String> codproducto(String codproducto){
		//return !SunatStringUtils.isEmptyTrim(codproducto)?new HashMap<String,String>():getDUAError("30022","");
		//TODO rc. segun macroinput no aplica a ninguna transaccion
		return new HashMap<String,String>();
	}

	/**
	 * Valida el C�digo de riesgo sanitario de SENASA.<br>
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codriesgosanitario String.C�digo de riesgo sanitario de SENASA.
	 * @return Map
	 */
	public Map<String, String> codriesgosanitario(String codriesgosanitario){
		if (!SunatStringUtils.isEmptyTrim(codriesgosanitario)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("341", codriesgosanitario))
			boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("341", codriesgosanitario, SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				return getDUAError("30023","Error catalogo codriesgosanitario");
		}else
			return new HashMap<String,String>();
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
