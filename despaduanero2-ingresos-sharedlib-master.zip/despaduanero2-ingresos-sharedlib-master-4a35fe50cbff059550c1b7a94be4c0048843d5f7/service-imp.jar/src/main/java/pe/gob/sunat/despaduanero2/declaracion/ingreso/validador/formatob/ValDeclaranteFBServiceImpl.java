/*
 * Clase que define el servicio de validaciones del declarante del formato B de la dua.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * The Class ValDeclaranteFB. Clase que define el servicio de validaciones del declarante del formato B de la dua.
 */
public class ValDeclaranteFBServiceImpl extends ValParticipanteFB implements ValDeclaranteFB {

	/**
	 * Valida el codigo del tipo de participante contra el catalogo 123
	 */
	public Map<String, String> codtipparticipante(DataCatalogo tipoParticipante) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> result = super.codtipparticipante(tipoParticipante);
		if(result != null)
			result = catalogoAyudaService.getError("30116");

		return new HashMap<String, String>();
	}

	//glazaror... metodo optimizado
	public Map<String, String> codtipparticipante(DataCatalogo tipoParticipante, Map<String, Object> variablesIngreso) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> result = super.codtipparticipante(tipoParticipante, variablesIngreso);
		if(result != null) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			//result = getCatalogoHelper().getErrorMap("30116");

			//glazaror... utilizamos catalogoAyudaService.getError
			result = catalogoAyudaService.getError("30116");
		}

		return new HashMap<String, String>();
	}

	/**
	 * Valida el codigo del tipo de documento del declarante
	 * @param dav
	 * @return
	 */
	@Deprecated
	public Map<String, String> codtipdocparticipante (DAV dav) {

		if(dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat() == null ||
				!SunatStringUtils.isStringInList(dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat(),"3,6,7,9,13" )){
			return getErrorMap("30134", new Object[]{dav.getNumsecuprov(), dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat()});
		}

		//RIN13-INSI
		//Map<String, String> result = super.codtipdocparticipante(dav.getPersonaDecl().getTipoParticipante());
		Map<String, String> result = super.codtipdocparticipante(dav.getPersonaDecl().getTipoDocumentoIdentidad()); 

		if(result != null){
			return  getErrorMap("30134", new Object[]{dav.getNumsecuprov(), dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat()});
		}

		return new HashMap<String, String>();
	}

	//glazaror... metodo optimizado
	@Override
	public Map<String, String> codtipdocparticipante (DAV dav, Map<String, Object> variablesIngreso) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat() == null ||
				!SunatStringUtils.isStringInList(dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat(),"3,6,7,9,13" )){
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			//return getCatalogoHelper().getErrorMap("30134", new Object[]{dav.getNumsecuprov(), dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat()});

			//glazaror... utilizamos catalogoAyudaService.getError
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String tipoDocumentoIdentidad = (dav.getPersonaDecl() != null && dav.getPersonaDecl().getTipoDocumentoIdentidad() != null) ? dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat() : " ";
			return catalogoAyudaService.getError("30134",  new String[] {numeroSecuenciaProveedor, tipoDocumentoIdentidad});
		}

		//RIN13-INSI
		//Map<String, String> result = super.codtipdocparticipante(dav.getPersonaDecl().getTipoParticipante());
		Map<String, String> result = super.codtipdocparticipante(dav.getPersonaDecl().getTipoDocumentoIdentidad(), variablesIngreso); 

		if(result != null){
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			//return  getCatalogoHelper().getErrorMap("30134", new Object[]{dav.getNumsecuprov(), dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat()});

			//glazaror... utilizamos catalogoAyudaService.getError
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String tipoDocumentoIdentidad = (dav.getPersonaDecl() != null && dav.getPersonaDecl().getTipoDocumentoIdentidad() != null) ? dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat() : " ";
			return catalogoAyudaService.getError("30134",  new String[] {numeroSecuenciaProveedor, tipoDocumentoIdentidad});
		}

		return new HashMap<String, String>();
	}

	/**
	 * valida el numero de documento del declarante
	 * @param dav
	 * @return
	 */
	public Map<String, String> numdocparticipante (DAV dav) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (StringUtils.isEmpty(dav.getPersonaDecl().getNumeroDocumentoIdentidad()) || 
				SunatStringUtils.isLengthGreaterThanNumber(dav.getPersonaDecl().getNumeroDocumentoIdentidad(), 11)){
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*return getCatalogoHelper().getErrorMap("30135", 
		    		new Object[] {	dav.getNumsecuprov(), 
		    						dav.getPersonaDecl().getNumeroDocumentoIdentidad()!=null?dav.getPersonaDecl().getNumeroDocumentoIdentidad():" "});*/

			//glazaror... utilizamos catalogoAyudaService.getError
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String numeroDocumentoIdentidad = (dav.getPersonaDecl() != null) ? dav.getPersonaDecl().getNumeroDocumentoIdentidad() : " ";
			return catalogoAyudaService.getError("30135",  new String[] {numeroSecuenciaProveedor, numeroDocumentoIdentidad});
		}

		return new HashMap<String, String>();
	}

	/**
	 * Valida el nombre del declarante, que se envie un dato car�cter de longitud mayor a 5.
	 * 
	 * @param arg String
	 * @return el map
	 */

	public Map<String, String> nomparticipante(DAV dav) {
		if(StringUtils.isEmpty(dav.getPersonaDecl().getNombreRazonSocial()) || 
				SunatStringUtils.length(dav.getPersonaDecl().getNombreRazonSocial()) < 5){
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*return catalogoHelper.getErrorMap("30136", 
						new Object[] {dav.getNumsecuprov(),
						dav.getPersonaDecl().getNombreRazonSocial()!=null?dav.getPersonaDecl().getNombreRazonSocial():" "});*/

			//glazaror... utilizamos catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String razonSocial = (dav.getPersonaDecl() != null && dav.getPersonaDecl().getNombreRazonSocial() != null) ? dav.getPersonaDecl().getNombreRazonSocial().trim() : " ";
			return catalogoAyudaService.getError("30136",  new String[] {numeroSecuenciaProveedor, razonSocial});
		}
		return new HashMap<String, String>();
	}


	/**
	 * Valida el cargo del declarante
	 * @param dav
	 * @return
	 */
	public Map<String, String> validarCargoDeclarante(DAV dav){
		if (StringUtils.isEmpty(dav.getNomcargdecla()) ||  SunatStringUtils.length(dav.getNomcargdecla()) < 5) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*return catalogoHelper.getErrorMap("30602", new Object[] { dav.getNumsecuprov(), 
            														  dav.getNomcargdecla()!=null?dav.getNomcargdecla():" " });*/

			//glazaror... utilizamos catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String nombreCargo = (dav.getNomcargdecla() != null) ? dav.getNomcargdecla() : " ";
			return catalogoAyudaService.getError("30602",  new String[] {numeroSecuenciaProveedor, nombreCargo});
		}

		return new HashMap<String, String>();
	}
	/**
	 * Validar la vigencia del documento de identidad.
	 * 
	 * @param tipoDocumentoIdentidad String,numeroDocumentoIdentidad String 
	 * @return el map
	 */
	@Override
	public Map<String, String> vigenciaTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad,Date fecha_referencia) {
		Map<String, String> result = super.vigenciaTipoDocumento(tipoDocumentoIdentidad,numeroDocumentoIdentidad,fecha_referencia);

		if(result != null) {              
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("30791");
			return result;
		}

		return new HashMap<String, String>();
	}




	/**
	 * Validar si existe numero de documento de identidad.
	 * 
	 * @param tipoDocumentoIdentidad String,numeroDocumentoIdentidad String 
	 * @return el map
	 */
	@Override
	public Map<String, String> existenciaTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad) {
		java.util.Map<String, String> result = super.existenciaTipoDocumento(tipoDocumentoIdentidad,numeroDocumentoIdentidad);

		if(result != null) {        
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("30791");
			return result;
		}

		return new HashMap<String, String>();
	}
	/**
	 * Validar el formato del numero de documento de identidad.
	 * 
	 * @param tipoDocumentoIdentidad String,numeroDocumentoIdentidad String 
	 * @return el map
	 */
	@Override
	public Map<String, String> formatoTipoDocumento(String tipoDocumentoIdentidad,String  numeroDocumentoIdentidad) {
		java.util.Map<String, String> result = super.formatoTipoDocumento(tipoDocumentoIdentidad,numeroDocumentoIdentidad);

		if(result != null) {          
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("30791");
			return result;
		}

		return new HashMap<String, String>();
	}
	/**
	 * Validar la edad del declarante del formato B.
	 * 
	 * @param tipoDocumentoIdentidad String,numeroDocumentoIdentidad String 
	 * @return el map
	 */
	@Override
	public Map<String, String> edadPersonaDecl(String tipoDocumentoIdentidad,String numeroDocumentoIdentidad,Date fecha_referencia) {
		java.util.Map<String, String> result = super.edadPersonaDecl(tipoDocumentoIdentidad,numeroDocumentoIdentidad,fecha_referencia);
		if(result != null){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("30792");
			return result;
		}
		return new HashMap<String, String>();
	}
	/**
	 * Validar la edad del declarante del formato B.
	 * 
	 * @param tipoDocumentoIdentidad String,numeroDocumentoIdentidad String 
	 * @return el map
	 */
	@Override
	public Map<String, String> codTipDocParticipanteDecl(String tipoDocumentoIdentidad) {
		java.util.Map<String, String> result = super.codTipDocParticipanteDecl(tipoDocumentoIdentidad);
		if(result != null){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("30793");
			return result;
		}
		return new HashMap<String, String>();
	}

	/**
	 * Validar la el Nombre declarante del formato B.
	 * 
	 * @param tipoDocumentoIdentidad String,numeroDocumentoIdentidad String 
	 * @return el map
	 */
	@Override
	public Map<String, String> validarNombrePersonaDecl(String tipoDocumentoIdentidad,String numeroDocumentoIdentidad,String nombreDeclaranteTransmitido) {
		java.util.Map<String, String> result =     super.validarNombrePersonaDecl(tipoDocumentoIdentidad,numeroDocumentoIdentidad,nombreDeclaranteTransmitido);
		if(result != null){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("30794",new String []{nombreDeclaranteTransmitido,result.get("nombreDeclarante")});
			return result;
		}
		return new HashMap<String, String>();
	}
}
