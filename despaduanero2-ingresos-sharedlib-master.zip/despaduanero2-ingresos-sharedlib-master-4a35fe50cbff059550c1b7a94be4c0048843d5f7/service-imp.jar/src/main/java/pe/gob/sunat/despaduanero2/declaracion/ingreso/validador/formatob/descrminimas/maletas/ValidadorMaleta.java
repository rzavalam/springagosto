package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.maletas;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.maletas.model.Maleta;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorMaleta extends ValidadorAbstract {

  private static final String UNIDAD           = "U";
  private static final String DOCENA           = "12U";
  private static final String JUEGO            = "SET";
  private static final String CON_CATALOGO     = "0";
  private static final String COD_ZZZ = "1";

  private static final String CODIGO_ASOCIACION_CATALOGO = "016";
  private static final String OTROS_NOMBRE_COMERCIAL = "039";//antes ZZZ
  private static final String NOMBRE_MALETAS   = "027";
  private static final String FORMATO_MEDIDAS  = "\\d{1,3}(\\.\\d){1}(\\\"|\\'\\')";
  private static final String SIN_ACCESORIOS = "006";//adicionado pase PAS20155E220000396
  private static final String SIN_APLICACION = "010";//adicionado pase PAS20155E220000396

  public ValidadorMaleta() {
    super();
  }

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto,
                                                     Declaracion dua) throws Exception{
    
    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

    //lstErrores.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores)){
          DatoItem item = obtenerItem(objeto,dua);
          lstErrores.addAll(validarUnidadComercial(objeto, item));
          lstErrores.addAll(validarAccesorios(objeto));
          lstErrores.addAll(validarAplicaciones(objeto));
          lstErrores.addAll(validarCorrelacionPartida(objeto, dua));
          lstErrores.addAll(validarPresentacion(objeto, item));
          //lstErrores.addAll(validarMaterialMaletas(objeto));
          lstErrores.addAll(validarMaterialMaletas(objeto, dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarMedidas(objeto));
      }


    return lstErrores;
  }

  public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract objeto,
                                                       DatoItem item) {
    List<ErrorDescrMinima> errLst  = new ArrayList<ErrorDescrMinima>();
    Maleta maleta = (Maleta) objeto;
    String datoAValidar = item.getCodunidcomer(); 
    Object[] demasArgumentosMSJError = new Object[] { 
    		maleta.getNumsecprove(),
    		maleta.getNumsecfact(),
    		maleta.getNumsecitem(),
    		"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
    if (SunatStringUtils.isEmpty(item.getCodunidcomer())) {
    	ErrorDescrMinima err = obtenerError("31100", ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
        errLst.add(err);
    }
    else{
      if (!(SunatStringUtils.isEqualTo(datoAValidar, UNIDAD) ||
            SunatStringUtils.isEqualTo(datoAValidar, DOCENA) ||
            SunatStringUtils.isEqualTo(datoAValidar, JUEGO))) {
    	 ErrorDescrMinima err = obtenerError("31102", ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
         errLst.add(err);
      }
    }
    return errLst;
  }

  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarModelo(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCorrelacionPartida(ModelAbstract objeto,
                                                          Declaracion dua) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Maleta maleta           = (Maleta) objeto;
    String datoAValidar     = maleta.getNombreComercial().getValtipdescri();
    String codTipoValor     = maleta.getNombreComercial().getCodtipvalor();
    DatoItem item           = obtenerItem(objeto,dua);
    String subPartida       = item.getNumpartnandi().toString();
      if(COD_ZZZ.equals(codTipoValor)){
        datoAValidar = OTROS_NOMBRE_COMERCIAL;
      } 
      if (noEstaCorrelacionado(datoAValidar, subPartida,
                               CODIGO_ASOCIACION_CATALOGO,  dua.getDua().getFecdeclaracion())) {
        lst.add(obtenerError("31105", objeto.getNombreComercial()));
      }
    return lst;
  }

  private List<ErrorDescrMinima> validarMaterial(DatoDescrMinima tipo, DatoDescrMinima subtipo,
                                                String err1, String err2, String err3, String err4, Date fechaVigencia){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    String tipoAVAlidar = tipo.getValtipdescri();
    String subTipoAValidar = subtipo.getValtipdescri();
    
    if(CON_CATALOGO.equals(tipo.getCodtipvalor())){
        if(CON_CATALOGO.equals(subtipo.getCodtipvalor())){
          if(!estaCorrelacionado(tipoAVAlidar, subTipoAValidar, "021",  fechaVigencia)){
            lst.add(obtenerError(err1, tipo)); 
          }
        }else{
          lst.add(obtenerError(err2, subtipo)); 
        }
    }else{
      if(!COD_ZZZ.equals(subtipo.getCodtipvalor())){
        lst.add(obtenerError(err3, subtipo));
      }
    }
    
//    List<String> sinSubTipo = Arrays.asList("005","006");
//    if(sinSubTipo.contains(tipoAVAlidar) && 
//        !SunatStringUtils.isEmptyTrim(subTipoAValidar)){
//      lst.add(obtenerError(err4, subtipo)); 
//    }    //comentado porque tipo 005 y 006 tienen subtipos registrados en asoc 021 PAS20155E220000396
    return lst;
  }
  
    
  public List<ErrorDescrMinima> validarMaterialMaletas(ModelAbstract object, Date fechaVigencia){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Maleta maleta = (Maleta) object;
    Long sumaPorcentajes        = new Long(0);
    
    lst.addAll(validarMaterial(maleta.getTipo1erComp(), maleta.getSubTipo1erComp(), "31754", "31755", "31756","31757", fechaVigencia));
    if(!SunatStringUtils.isEmptyTrim(maleta.getPorcentaje1erComp().getValtipdescri())){
      sumaPorcentajes = Long.parseLong(maleta.getPorcentaje1erComp().getValtipdescri());
    }else{
      lst.add(obtenerError("31109", maleta.getPorcentaje2doComp()));
    }
    
    Boolean compo2Obligatorio = (!SunatStringUtils.isEmptyTrim(maleta.getTipo2doComp().getValtipdescri())||
    		!SunatStringUtils.isEmptyTrim(maleta.getSubTipo2doComp().getValtipdescri()));
    Boolean compo3Obligatorio = (!SunatStringUtils.isEmptyTrim(maleta.getTipo3erComp().getValtipdescri()) || 
    		!SunatStringUtils.isEmptyTrim(maleta.getSubTipo3erComp().getValtipdescri()));

    if(compo2Obligatorio){
    	if(SunatStringUtils.isEmptyTrim(maleta.getTipo2doComp().getValtipdescri()) || 
    	   SunatStringUtils.isEmptyTrim(maleta.getSubTipo2doComp().getValtipdescri())){
    		lst.add(obtenerError("31106",maleta.getSubTipo2doComp())); 
    	}else{
    		lst.addAll(validarMaterial(maleta.getTipo2doComp(), maleta.getSubTipo2doComp(), "31758", "31759", "31760","31761",fechaVigencia));
    		if(!SunatStringUtils.isEmptyTrim(maleta.getPorcentaje2doComp().getValtipdescri())){
              sumaPorcentajes += Long.parseLong(maleta.getPorcentaje2doComp().getValtipdescri());
            }else{
              lst.add(obtenerError("31112", maleta.getPorcentaje2doComp()));
            }
    	}
    }
    if(compo3Obligatorio){
    	if(SunatStringUtils.isEmptyTrim(maleta.getTipo3erComp().getValtipdescri()) || 
    	   SunatStringUtils.isEmptyTrim(maleta.getSubTipo3erComp().getValtipdescri())){
    		lst.add(obtenerError("31106",maleta.getSubTipo3erComp())); 
    	}else{
    		lst.addAll(validarMaterial(maleta.getTipo3erComp(), maleta.getSubTipo3erComp(), "31762", "31763", "31764","31765",fechaVigencia));
    		if(!SunatStringUtils.isEmptyTrim(maleta.getPorcentaje3erComp().getValtipdescri())){
              sumaPorcentajes += Long.parseLong(maleta.getPorcentaje3erComp().getValtipdescri());
            }else{
              lst.add(obtenerError("31115", maleta.getPorcentaje3erComp()));
            }
    	}
    }
    	
    if(sumaPorcentajes != 100){
      DatoDescrMinima suma = maleta.getPorcentaje1erComp();
      suma.setValtipdescri(sumaPorcentajes.toString());
      lst.add(obtenerError("31116", suma));
    }
    
    return lst;
  }
  
    
  public List<ErrorDescrMinima> validarTipoComposicionForro(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarAcabados(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }


  public List<ErrorDescrMinima> validarAccesorios(ModelAbstract objeto) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Maleta maleta = (Maleta) objeto;
    
    /**Inicio de ajustes de PAS20155E220000396**/
    if(maleta.getPrimerAccesorio()!=null && !SunatStringUtils.isEmpty(maleta.getPrimerAccesorio().getValtipdescri())){
    	if(!maleta.getPrimerAccesorio().getValtipdescri().equals(SIN_ACCESORIOS) && 
    			(maleta.getCantidad1erAccesorio() == null || SunatStringUtils.isEmpty(maleta.getCantidad1erAccesorio().getValtipdescri()))){
    		 lst.add(obtenerError("31127", maleta.getCantidad1erAccesorio()));
    	}
    }
    /**Fin de ajustes de PAS20155E220000396**/
    
    if(maleta.getSegundoAccesorio() != null &&
      !SunatStringUtils.isEmpty(maleta.getSegundoAccesorio().getValtipdescri())){      
      if(maleta.getCantidad2doAccesorio() == null ||
          SunatStringUtils.isEmpty(maleta.getCantidad2doAccesorio().getValtipdescri())){
        lst.add(obtenerError("31127", maleta.getCantidad2doAccesorio()));
      }
    }
      if(maleta.getTercerAccesorio() != null &&
          !SunatStringUtils.isEmpty(maleta.getTercerAccesorio().getValtipdescri())){      
          if(maleta.getCantidad3erAccesorio() == null ||
              SunatStringUtils.isEmpty(maleta.getCantidad3erAccesorio().getValtipdescri())){
            lst.add(obtenerError("31127", maleta.getCantidad3erAccesorio()));
          }
    }
    
    return lst;
  }

  public List<ErrorDescrMinima> validarAplicaciones(ModelAbstract objeto) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Maleta maleta = (Maleta) objeto;
    /**Inicio de ajustes de PAS20155E220000396**/
    if(maleta.getPrimeraAplicacion()!=null && 
    		!SunatStringUtils.isEmpty(maleta.getPrimeraAplicacion().getValtipdescri())){
    	DatoDescrMinima cant1daApli = maleta.getCantidad1erAplicacion();
    	if(!maleta.getPrimeraAplicacion().getValtipdescri().equals(SIN_APLICACION) &&
    			(cant1daApli==null || SunatStringUtils.isEmpty(cant1daApli.getValtipdescri()))){
    		 lst.add(obtenerError("31140", cant1daApli));
    	}
    	
    }
    /**Fin de ajustes de PAS20155E220000396**/
    
    if (maleta.getSegundaAplicacion() != null && 
        !SunatStringUtils.isEmpty(maleta.getSegundaAplicacion().getValtipdescri())) {
        DatoDescrMinima cant2daApli = maleta.getCantidad2daAplicacion();
        if(SunatStringUtils.isEmpty(cant2daApli.getValtipdescri())){
          lst.add(obtenerError("31140", cant2daApli));
        }
      
      }
      if (maleta.getTerceraAplicacion() != null && 
          !SunatStringUtils.isEmpty(maleta.getTerceraAplicacion().getValtipdescri())){
          DatoDescrMinima cant3raApli = maleta.getCantidad3erAplicacion();
          if(SunatStringUtils.isEmpty(cant3raApli.getValtipdescri())){
            lst.add(obtenerError("31140", cant3raApli));
          }
      }
    return lst;
  }

  public List<ErrorDescrMinima> validarMedidas(ModelAbstract objeto) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Maleta maleta = (Maleta) objeto;
    String descripcion = maleta.getMedidas().getValtipdescri();
    String nombreComercial = maleta.getNombreComercial().getValtipdescri();
    if (SunatStringUtils.isEqualTo(nombreComercial, NOMBRE_MALETAS)) {
      if (SunatStringUtils.isEmpty(descripcion)) {
        lst.add(obtenerError("31128", maleta.getMedidas()));
        return lst;
      } else if (!cumpleExpresionRegular(descripcion, FORMATO_MEDIDAS)) {
        lst.add(obtenerError("31129", maleta.getMedidas()));
        return lst;
      }
    } else {
      if (SunatStringUtils.isEmpty(descripcion)) {
        lst.add(obtenerError("31130", maleta.getMedidas()));
        return lst;
      } else {
        if (descripcion.indexOf("x") != -1) {
          String[] valMedidas = descripcion.split("x");
          for (String val : valMedidas) {
            if (!cumpleExpresionRegular(val, FORMATO_MEDIDAS)) {
              lst.add(obtenerError("31131", maleta.getMedidas()));
              return lst;
            }
          }
        } else {
          lst.add(obtenerError("31130", maleta.getMedidas()));
          return lst;
        }
      }
    }
    return lst;
  }

  public List<ErrorDescrMinima> validarPresentacion(ModelAbstract objeto,
                                                    DatoItem item) {
    List<ErrorDescrMinima> lst  = new ArrayList<ErrorDescrMinima>();
      Maleta maleta          = (Maleta) objeto;
      String unidadComercial = item.getCodunidcomer();
      String codigo          = maleta.getPresentacion().getValtipdescri();

      if (SunatStringUtils.isEqualTo(unidadComercial, JUEGO)){ 
          if(SunatStringUtils.isEmptyTrim(codigo)) 
            lst.add(obtenerError("31132", maleta.getPresentacion()));
      } else {
          if (!SunatStringUtils.isEmptyTrim(codigo)) {
          lst.add(obtenerError("31135", maleta.getPresentacion(), new String[]{unidadComercial}));
        }
      }
    return lst;
  }

  public List<ErrorDescrMinima> validarPeso(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarUso(ModelAbstract objeto) {
    return new ArrayList<ErrorDescrMinima>();
  }
}
