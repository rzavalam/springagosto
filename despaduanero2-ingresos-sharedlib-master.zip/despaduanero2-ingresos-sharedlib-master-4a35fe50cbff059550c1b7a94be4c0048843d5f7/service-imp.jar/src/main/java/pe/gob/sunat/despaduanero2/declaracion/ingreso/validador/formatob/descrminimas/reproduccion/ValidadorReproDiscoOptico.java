package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.reproduccion;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproDiscoOptico;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * La Class ValidadorDescrMinimaReproDiscosOpticos.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class ValidadorReproDiscoOptico extends ValidadorReproAbstract
{
//  private FabricaDeServicios fabricaDeServicios; Esto no es nesesario por que lo usa de ValidacionFormatoB
 
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);
    //lstErrores.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores)){
          lstErrores.addAll(super.validarUnidadComercial(objeto, dua));
          lstErrores.addAll(super.validarNombreComercial(objeto,dua));
          lstErrores.addAll(super.validarMarcaComercial(objeto));
          lstErrores.addAll(super.validarModelo(objeto));
          lstErrores.addAll(validarDatosEnviadosCorrespondenAltipoDescrMinima(objeto,dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarTipoDisco(objeto));
          lstErrores.addAll(validarLongitudDiametro(objeto));
          lstErrores.addAll(validarCapacidadAlmacenamiento(objeto));
          lstErrores.addAll(validarTipoEmpaque(objeto));
          lstErrores.addAll(validarDiscosXEmpaque(objeto));
          lstErrores.addAll(validarNumeroEmpaques(objeto));
          lstErrores.addAll(validarFormato(objeto));
      }


    return lstErrores;
  }

  public List<ErrorDescrMinima> validarTipoDisco(ModelAbstract objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  private List<ErrorDescrMinima> validarLongitudDiametro(ModelAbstract objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCapacidadAlmacenamiento(ModelAbstract objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarTipoEmpaque(ModelAbstract objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarDiscosXEmpaque (ModelAbstract objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarNumeroEmpaques(ModelAbstract objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarFormato (ModelAbstract objeto)
  {  
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    if(objeto instanceof ReproDiscoOptico)
    {
      ReproDiscoOptico discosOpticos = (ReproDiscoOptico) objeto;
      String datoAValidar = discosOpticos.getFormato().getValtipdescri().trim();
      String discos = discosOpticos.getTipoDisco().getValtipdescri().trim();

        boolean esObligatorio = estaenSubGrupo(discos)?true:false;

       if(esObligatorio)
       {
           if(SunatStringUtils.isEmpty(datoAValidar))
           {
               ErrorDescrMinima error = obtenerError("31704",discosOpticos.getTipoDisco());
               lstError.add(error);

           }
       }
       else if (!SunatStringUtils.isEmpty(datoAValidar))
       {
           String regla="el tipo de disco consignada es diferente a DVD";
           String campo= obtenerDescripcionDelCalogo("500", discosOpticos.getTipoDisco().getCodtipdescr());
           Object[] argumentos = new Object[] { regla,campo };
           ErrorDescrMinima error = obtenerError("30897",discosOpticos.getTipoDisco(), argumentos);
           lstError.add(error);
       }
    }
    
    return lstError;

  }
  
	public boolean estaenSubGrupo(String discos) {	  
		CatalogoValidaService catalogoValidaService = this.fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		List<Map<String, String>> resultado = catalogoValidaService.validarElementoGrupo("559", discos);
		if (resultado.isEmpty()) {
			return true;
		}
		return false;
	}

//	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
//		this.fabricaDeServicios = fabricaDeServicios;
//	}
	
	
}
