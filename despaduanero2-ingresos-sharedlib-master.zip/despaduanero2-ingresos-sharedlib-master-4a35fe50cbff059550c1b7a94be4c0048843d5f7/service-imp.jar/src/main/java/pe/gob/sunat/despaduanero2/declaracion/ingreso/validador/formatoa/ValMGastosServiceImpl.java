/*
 * Clase que define el servicio de validaciones de los montos de la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValMGastos. Clase que define el servicio de validaciones de los montos de la DUA
 */
public class ValMGastosServiceImpl extends ValDuaAbstract implements ValMGastos{
	
	//private FabricaDeServicios fabricaDeServicios;
	
	/**
	 * Valida el tipo del monto
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param tipmonto String, Codigo de tipo de monto
	 * @return Map
	 */
	public Map<String, String> tipmonto(String tipmonto){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("331", tipmonto))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("331", tipmonto,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30019","Error catalogo tipmonto");
	}

	/**
	 * Valida el Monto
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param valmonto BigDecimal. Monto
	 * @return Map
	 */
	public Map<String, String> valmonto(BigDecimal valmonto){
		
		if(valmonto == null ) return new HashMap<String,String>();
		
		return SunatNumberUtils.isGreaterOrEqualsThanZero(valmonto)?new HashMap<String,String>():getDUAError("30020","");
	}

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/


}
