package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.util.DateUtil;
//import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.sigad.ingreso.service.ConsultaComprobanteCustodiaService;
import pe.gob.sunat.sigad.despacho.entrada.service.DAMConsultaService;
import pe.gob.sunat.despaduanero2.declaracion.service.DAMOperativaConsultaService;
import pe.gob.sunat.despaduanero.despacho.entrada.cc.model.CabRetencion;
import pe.gob.sunat.despaduanero.despacho.entrada.cc.model.CabRetencionSerie;
import pe.gob.sunat.despaduanero.despacho.entrada.cc.model.dao.CabRetencionDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.cc.model.dao.CabRetencionSerieDAO;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

import java.text.ParseException;
import java.util.*;

public class ValPrecedenteComprobanteCustodiaServiceImpl extends ValDuaAbstract implements ValPrecedenteComprobanteCustodiaService {

	
	
	public List<Map<String, String>> validaComprobanteCustodia(Declaracion declaracion,String puntoDeLlegada, List<DatoSerie> listSeries,String codAduanaOrden, Date fechaReferencia){
		List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String codiAduan="";
		String anoPrese= "";
		String codaduanaConex= codAduanaOrden;
		String numeCorre="";
		String cantSerie="";

		puntoDeLlegada=declaracion.getDua().getCodlugarecepcion()!=null?declaracion.getDua().getCodlugarecepcion():"";
		if(SunatStringUtils.isEmptyTrim(puntoDeLlegada)){
			Map<String,Object> params=new HashMap<String,Object>();
			params.put("NUM_CORREDOC",declaracion.getDua().getNumcorredoc());
			CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
			Map<String, Object> cabDeclara = cabDeclaraDAO.findMapDUAByPk(params);
			puntoDeLlegada= cabDeclara.get("COD_LUGARRECEP")!=null?cabDeclara.get("COD_LUGARRECEP").toString():"";
			if(puntoDeLlegada.equals("11")) {
				declaracion.getDua().setCodlugarecepcion(puntoDeLlegada);
			}
		}
		listMapError.add(validarPuntoLlegada(puntoDeLlegada));

		ConsultaComprobanteCustodiaService consultaComprobanteCustodiaService = (ConsultaComprobanteCustodiaService)fabricaDeServicios.getService("sigad.ingreso.ConsultaComprobanteCustodiaService");
		for(DatoSerie serie:listSeries) {
			if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
				for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
					String strPrecedencia = regPrec.getCodaduapre() + '-' + SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4) + '-' + ConstantesDataCatalogo.COMPROBANTE_CUSTODIA + '-' + regPrec.getNumdeclpre();
					CabRetencion cabRetencion = new CabRetencion();
					cabRetencion.setCodiAduan(regPrec.getCodaduapre());
					cabRetencion.setAnoPrese(SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4));
					anoPrese = SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4);
					codiAduan = regPrec.getCodaduapre() != null ? regPrec.getCodaduapre().toString() : "0";
					cabRetencion.setNumeCorre(regPrec.getNumdeclpre());
					numeCorre = SunatStringUtils.lpad(regPrec.getNumdeclpre(), 6, '0') != null ? SunatStringUtils.lpad(regPrec.getNumdeclpre(), 6, '0') : "0";
					Integer numSerie = regPrec.getNumserpre();
					cantSerie = String.valueOf(numSerie);
					String numeSerie = regPrec.getNumserpre().toString();
				
				//bug P_SNAA0004-17084 csantillan PAS20191U220200002
				CabRetencion cabRetencion1 = consultaComprobanteCustodiaService.consultarComprobanteCustodia(anoPrese, codiAduan, numeCorre, codaduanaConex,  null);					
				if(cabRetencion1!=null){
						Date fecha1;
						try {
							fecha1 = DateUtil.getNumbertoDateyyyMMdd(cabRetencion1.getFechVcto());
							regPrec.setFecvencpre(fecha1);
						} catch (ParseException e) {
							e.printStackTrace();
						}
				}
				//fin bug P_SNAA0004-17084
				
					CabRetencion cabRetencion2 = consultaComprobanteCustodiaService.consultarComprobanteCustodia(anoPrese, codiAduan, numeCorre, codaduanaConex, cantSerie);

					if (!codAduanaOrden.equals(codiAduan)) {
						listMapError.add(catalogoAyudaService.getError("37209", new String[]{serie.getNumserie().toString(), codiAduan, "DEL COMPROBANTE DE CUSTODIA", strPrecedencia, codAduanaOrden}));
						break;
					}
					if (cabRetencion2 == null) {
						//Serie [x]: <TipoDocumento> N� AAA-XXXX-RR-YYYYYY no existe
						listMapError.add(catalogoAyudaService.getError("37210", new String[]{serie.getNumserie().toString(), strPrecedencia,}));
					} else if (cabRetencion2.getCodiAduan() != null) {
						//cabRetencion2 = consultaComprobanteCustodiaService.consultarComprobanteCustodiaSerie(anoPrese, codiAduan, numeCorre, codaduanaConex,cantSerie);
						CabRetencionSerie cabRetencion3 = consultaComprobanteCustodiaService.consultarComprobanteCustodiaSerie(anoPrese, codiAduan, numeCorre, codaduanaConex, numeSerie);
						if (!numeSerie.equals(SunatStringUtils.trim(cabRetencion3 != null ? cabRetencion3.getNumeSerie() : ""))) {
							listMapError.add(catalogoAyudaService.getError("37211", new String[]{serie.getNumserie().toString(), numeSerie, strPrecedencia}));
						}
						if (!codiAduan.equals(cabRetencion2.getCodiAduan())) {
							listMapError.add(catalogoAyudaService.getError("37209", new String[]{serie.getNumserie().toString(), codiAduan, "DEL COMPROBANTE DE CUSTODIA", strPrecedencia, codAduanaOrden}));
						}
						if ((cabRetencion2.getFechAnula() > 0)) {
							listMapError.add(catalogoAyudaService.getError("37213", new String[]{serie.getNumserie().toString(), strPrecedencia,}));
						}
					} else {
						listMapError.add(catalogoAyudaService.getError("37210", new String[]{serie.getNumserie().toString(), "COMPROBANTE DE CUSTODIA", strPrecedencia,}));
					}
				}
			}
		}
		return listMapError;
	}
	private Map<String, String> validarPuntoLlegada (String puntoLlegada){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String,String> mapError=new HashMap<String,String>();
		String codigoPuntoLLegadaMercancia =puntoLlegada!=null?puntoLlegada.toString():"";
		if (!SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL)){
			//El punto de llegada para precedente Acta de incautaci�n debe ser Control de Equipajes Internacional
			mapError = catalogoAyudaService.getError("37212",new String[] {});
		}
		return mapError;
	}
}
