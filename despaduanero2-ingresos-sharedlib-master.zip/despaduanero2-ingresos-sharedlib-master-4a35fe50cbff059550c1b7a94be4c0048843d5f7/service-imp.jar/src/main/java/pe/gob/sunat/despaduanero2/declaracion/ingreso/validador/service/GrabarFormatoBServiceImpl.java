package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCondTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactSuce;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.DocumentoSoporteFormatoB;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CondicionTransaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FactuSuceDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBMontoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Servicio que permite la grabacion del formato B de la declaracion
 * 
 * @author rcalla
 *
 */
public class GrabarFormatoBServiceImpl extends ValDuaAbstract implements GrabarFormatoBService {

	// private SequenceDAO sequenceDAO;

	// private FormBProveedorDAO formBProveedorDAO;

	// private FormBMontoDAO formBMontoDAO;

	// private ParticipanteDocDAO participanteDAO;

	// private CondicionTransaDAO condicionTransaDAO;

	// private ComprobPagoDAO comprobPagoDAO;

	// private FactuSuceDAO factuSuceDAO;

	// private ItemFacturaDAO itemFacturaDAO;

	// private SeriesItemDAO seriesItemDAO;

	// private VFOBProvisionalDAO fobProvisionalDAO;

	// private FormBItemDescriDAO formBItemDescriDAO;

	// private ObservacionDAO observacionDAO;
	// private FabricaDeServicios fabricaDeServicios;

	public Map<String, String> grabaFB(Declaracion declaracion) {
		FormBProveedorDAO formBProveedorDAO = (FormBProveedorDAO) fabricaDeServicios.getService("formBProveedorDAO");
		FormBMontoDAO formBMontoDAO = (FormBMontoDAO) fabricaDeServicios.getService("formBMontoDAO");
		ParticipanteDocDAO participanteDAO = (ParticipanteDocDAO) fabricaDeServicios.getService("participanteDAO");
		CondicionTransaDAO condicionTransaDAO = (CondicionTransaDAO) fabricaDeServicios
				.getService("condicionTransaDAO");
		ComprobPagoDAO comprobPagoDAO = (ComprobPagoDAO) fabricaDeServicios.getService("comprobPagoDAO");
		FactuSuceDAO factuSuceDAO = (FactuSuceDAO) fabricaDeServicios.getService("factuSuceDAO");
		ItemFacturaDAO itemFacturaDAO = (ItemFacturaDAO) fabricaDeServicios.getService("itemFacturaDAO");
		SeriesItemDAO seriesItemDAO = (SeriesItemDAO) fabricaDeServicios.getService("seriesItemDAO");
		VFOBProvisionalDAO fobProvisionalDAO = (VFOBProvisionalDAO) fabricaDeServicios.getService("fobProvisionalDAO");
		FormBItemDescriDAO formBItemDescriDAO = (FormBItemDescriDAO) fabricaDeServicios
				.getService("formBItemDescriDAO");
		ObservacionDAO observacionDAO = (ObservacionDAO) fabricaDeServicios.getService("observacionDAO");

		NumdeclRef numdeclRef = new NumdeclRef();
		String codTipoGrabado = "T";

		numdeclRef = declaracion.getNumdeclRef();
		// Verifica si es envio complementario
		if (numdeclRef != null) {
			if (SunatStringUtils.length(numdeclRef.getNumcorre()) > 0)
				codTipoGrabado = "T2";
		}

		for (DAV dav : declaracion.getListDAVs()) {
			dav.setNumcorredoc(declaracion.getNumeroCorrelativo());

			dav.setCodtipgrabado("T");

			dav = prepare(dav);

			formBProveedorDAO.insert(dav);

			for (DatoMonto monto : dav.getListMontos())
				formBMontoDAO.insert(monto);

			// for( Participante record: dav.getListProveedores() )
			// PAS20112A600000721 se cambia insert por insertSelective
			if (dav.getProveedor() != null){
			//INICIO CONTROL DE VIGENCIA OEA-ARM
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			DataCatalogo catVigenciaValidacion = catalogoAyudaService.getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,"0039");
				
			Date fechaControlVersionInicio = catVigenciaValidacion.getFecInidatcat();
			Date fechaControlVersionFin = catVigenciaValidacion.getFecFindatcat();
			Date fechaHoy = SunatDateUtils.getCurrentDate();
			if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaControlVersionInicio, fechaHoy, SunatDateUtils.COMPARA_SOLO_FECHA) 
					|| !SunatDateUtils.esFecha1MenorIgualQueFecha2(SunatDateUtils.addDay(fechaHoy, -1), fechaControlVersionFin, SunatDateUtils.COMPARA_SOLO_FECHA)) {
				dav.getProveedor().setCodigoOea(" ");
				dav.getProveedor().setPaisOea(" ");
				} 
			//FIN CONTROL DE VIGENCIA OEA-ARM
				participanteDAO.insertSelective(dav.getProveedor());
				
			}
			
			// PAS20112A600000721 se cambia insert por insertSelective
			if( dav.getProveedorLocal() != null && ! SunatStringUtils.isEmpty( dav.getProveedorLocal().getNombreRazonSocial() ) )
			// for( Participante record: dav.getListProveedoresLocales() )
			/* branch ingreso 2011-009 hosorio inicio */

			{
				if (dav.getProveedorLocal().getTipoParticipante() == null
						|| (dav.getProveedorLocal().getTipoParticipante() != null && SunatStringUtils
								.isEmpty(dav.getProveedorLocal().getTipoParticipante().getCodDatacat()))) {
					DataCatalogo tipPart = new DataCatalogo();
					tipPart.setCodDatacat("91");
					dav.getProveedorLocal().setTipoParticipante(tipPart);
				}
				// RectificacionServiceImpl.getInstance().getSoporteService().completarParticipante(dav.getProveedorLocal());
				((SoporteService) fabricaDeServicios.getService("soporteServiceDef"))
						.completarParticipante(dav.getProveedorLocal());
				/* branch ingreso 2011-009 hosorio fin */
				participanteDAO.insertSelective(dav.getProveedorLocal());

				/* branch ingreso 2011-009 hosorio inicio */
			}
			/* branch ingreso 2011-009 hosorio fin */
			// for( Participante record: dav.getListIntermediarios() )
			// PAS20112A600000721 se cambia insert por insertSelective
			if (dav.getIntermediario() != null
					&& !SunatStringUtils.isEmpty(dav.getIntermediario().getNombreRazonSocial()))
				participanteDAO.insertSelective(dav.getIntermediario());

			// for( Participante record: dav.getListPersonasDeclarantes() )
			if (dav.getPersonaDecl() != null) {

				Map<String, Object> params = new HashMap<String, Object>();
				params.put("numeroCorrelativo", declaracion.getNumeroCorrelativo());
				params.put("codTipoParticipante", "92");
				params.put("tipoDocumentoIdentidad", dav.getPersonaDecl().getTipoDocumentoIdentidad().getCodDatacat());
				params.put("numeroDocumentoIdentidad", dav.getPersonaDecl().getNumeroDocumentoIdentidad());

				// r2bz Se comenta deber�a de insertar puesto que ya se obtuvo
				// la secuencia del participante (metodo prepare)
				// lo cual genera incongruencia cuando se tiene mas de un
				// formato B para una declaraci�n y solo se inserta un registro
				// en participante_doc
				// List<Participante> listParticipante =
				// participanteDAO.findParticipantesByMap(params);
				// if( CollectionUtils.isEmpty(listParticipante) )
				// {
				// PAS20112A600000721 se cambia insert por insertSelective
				dav.getPersonaDecl().getTipoParticipante().setCodDatacat("92");
				// RectificacionServiceImpl.getInstance().getSoporteService().completarParticipante(dav.getPersonaDecl());
				((SoporteService) fabricaDeServicios.getService("soporteServiceDef"))
						.completarParticipante(dav.getPersonaDecl());
				participanteDAO.insertSelective(dav.getPersonaDecl());
				// }
			}


			// dua can
			if (dav.getRepresentanteLegal() != null) {
				participanteDAO.insertSelective(dav.getRepresentanteLegal());
			}

			if (dav.getListCondTransacciones() != null)
				for (DatoCondTransaccion condTransaccion : dav.getListCondTransacciones()) {
					condTransaccion.setNumcorredoc(dav.getNumcorredoc());
					condTransaccion.setNumsecprove(dav.getNumsecuprov());
					condicionTransaDAO.insert(condTransaccion);
				}

			for (DatoFactura factura : dav.getListFacturas()) {
				comprobPagoDAO.insert(factura);

				for (DatoFactSuce factSuce : factura.getListFactSucesivas())
					factuSuceDAO.insert(factSuce);

				for (DatoItem item : factura.getListItems()) {
					itemFacturaDAO.insert(item);

					for (DatoSerieItem serieItem : item.getListSerieItems())
						seriesItemDAO.insert(serieItem);

					if (item.getMontoProv() != null
							&& !SunatStringUtils.isEmptyTrim(item.getMontoProv().getIndtipovalor()))
						fobProvisionalDAO.insertSelective(item.getMontoProv());

					for (DatoDescrMinima descrMinima : item.getListDecrMinima()) // TODO
																					// descomentar
																					// hasta
																					// que
																					// llegue
																					// info
																					// de
																					// serie
																					// item
						formBItemDescriDAO.insert(descrMinima);

					for (Observacion obs : item.getListObservaciones()) {
						obs.setNumsecitem(item.getNumsecitem());
						observacionDAO.insertSelective(obs);
					}

				}
			}
		}

		return null;
	}

	/*
	 * public void setSequenceDAO(SequenceDAO sequenceDAO) { this.sequenceDAO =
	 * sequenceDAO; }
	 * 
	 * 
	 * public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO) {
	 * this.formBProveedorDAO = formBProveedorDAO; }
	 * 
	 * 
	 * public void setFormBMontoDAO(FormBMontoDAO formBMontoDAO) {
	 * this.formBMontoDAO = formBMontoDAO; }
	 * 
	 * 
	 * public void setParticipanteDAO(ParticipanteDocDAO participanteDAO) {
	 * this.participanteDAO = participanteDAO; }
	 * 
	 * 
	 * public void setCondicionTransaDAO(CondicionTransaDAO condicionTransaDAO)
	 * { this.condicionTransaDAO = condicionTransaDAO; }
	 * 
	 * 
	 * public void setComprobPagoDAO(ComprobPagoDAO comprobPagoDAO) {
	 * this.comprobPagoDAO = comprobPagoDAO; }
	 * 
	 * 
	 * public void setFactuSuceDAO(FactuSuceDAO factuSuceDAO) {
	 * this.factuSuceDAO = factuSuceDAO; }
	 * 
	 * 
	 * public void setItemFacturaDAO(ItemFacturaDAO itemFacturaDAO) {
	 * this.itemFacturaDAO = itemFacturaDAO; }
	 * 
	 * 
	 * public void setSeriesItemDAO(SeriesItemDAO seriesItemDAO) {
	 * this.seriesItemDAO = seriesItemDAO; }
	 * 
	 * 
	 * public void setFobProvisionalDAO(VFOBProvisionalDAO provisionalDAO) {
	 * fobProvisionalDAO = provisionalDAO; }
	 * 
	 * 
	 * public void setFormBItemDescriDAO(FormBItemDescriDAO formBItemDescriDAO)
	 * { this.formBItemDescriDAO = formBItemDescriDAO; }
	 * 
	 * 
	 * public void setObservacionDAO(ObservacionDAO observacionDAO) {
	 * this.observacionDAO = observacionDAO; }
	 */

	private DAV prepare(DAV dav) {

		SequenceDAO sequenceDAO = (SequenceDAO) fabricaDeServicios.getService("Framework.sequenceDef");
		if (SunatStringUtils.isEmpty(dav.getCodproveedor())) {
			Long secuenciaProveedor = sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_CODIGO_PROVEEDOR);
			dav.setCodproveedor(SunatStringUtils.rpad(String.valueOf(secuenciaProveedor), 8, '0'));
		}

		for (DatoMonto monto : dav.getListMontos()) {
			monto.setNumcorredoc(dav.getNumcorredoc());
			monto.setNumsecprove(dav.getNumsecuprov());
		}

		if (dav.getProveedor() != null) {
			dav.getProveedor().setSecuenciaDeParticipantes(
					sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
			dav.getProveedor().getDocumento().setNumeroCorrelativo(dav.getNumcorredoc());
		}

		if (dav.getProveedorLocal() != null
				&& !SunatStringUtils.isEmpty(dav.getProveedorLocal().getNombreRazonSocial())) {
			dav.getProveedorLocal().setSecuenciaDeParticipantes(
					sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
			dav.getProveedorLocal().getDocumento().setNumeroCorrelativo(dav.getNumcorredoc());
			/* branch ingreso 2011-009 hosorio inicio */
			if (SunatStringUtils.isEmpty(dav.getProveedorLocal().getTipoParticipante().getCodDatacat()))
				dav.getProveedorLocal().getTipoParticipante().setCodDatacat("91");
			/* branch ingreso 2011-009 hosorio fin */
		}

		if (dav.getIntermediario() != null
				&& !SunatStringUtils.isEmpty(dav.getIntermediario().getNombreRazonSocial())) {// dav.getIntermediario().getNumeroDocumentoIdentidad()
																								// )){//se
																								// cambia
																								// a
																								// que
																								// vea
																								// que
																								// hay
																								// razon
																								// social
																								// PASE451
			dav.getIntermediario().setSecuenciaDeParticipantes(
					sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
			dav.getIntermediario().getDocumento().setNumeroCorrelativo(dav.getNumcorredoc());
		}

		if (dav.getPersonaDecl() != null) {
			dav.getPersonaDecl().setSecuenciaDeParticipantes(
					sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
			dav.getPersonaDecl().getDocumento().setNumeroCorrelativo(dav.getNumcorredoc());
		}

		// dua can
		if (dav.getRepresentanteLegal() != null) {
			dav.getRepresentanteLegal().setSecuenciaDeParticipantes(
					sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
			dav.getRepresentanteLegal().getDocumento().setNumeroCorrelativo(dav.getNumcorredoc());
			dav.getRepresentanteLegal().getTipoParticipante().setCodDatacat("55"); // REPRESENTANTE
																					// LEGAL
																					// IMPORTADOR
		}

		if (!CollectionUtils.isEmpty(dav.getListDocumentoSoporteFormatoB())) {
			// obtener medio de pago
			for (DocumentoSoporteFormatoB docSoporteB : dav.getListDocumentoSoporteFormatoB()) {
				if (docSoporteB.getTipoDocumento().equals("450")) {
					dav.setCodMedioPago(docSoporteB.getCodMedioPago());
					dav.setCodIdentPago(docSoporteB.getCodIdentPago());
					dav.setCodEntidadFinanciera(docSoporteB.getCodEntidadFinanciera());
					dav.setDesMedioPago(docSoporteB.getDesMedioPago());
					dav.setDesEntidadFinanciera(docSoporteB.getDesEntidadFinanciera());
					break;
				}
			}
		}

		for (DatoFactura factura : dav.getListFacturas()) {
			factura.setNumcorredoc(dav.getNumcorredoc());
			factura.setNumsecprove(dav.getNumsecuprov());
			factura.setCodtipograbado("T");
			factura.setCodtipocomprobante("01");

			for (DatoFactSuce factSuce : factura.getListFactSucesivas()) {
				factSuce.setNumcorredoc(dav.getNumcorredoc());
				factSuce.setNumsecprove(dav.getNumsecuprov());
				factSuce.setCodmoneda(Constants.CODIGO_MONEDA_DOLAR);
				factSuce.setNumfact(factura.getNumfactura());
				factSuce.setNumsecfact(factura.getNumsecfactu());
			}

			for (DatoItem item : factura.getListItems()) {
				item.setNumcorredoc(dav.getNumcorredoc());
				item.setNumsecprove(dav.getNumsecuprov());
				item.setNumsecfact(factura.getNumsecfactu());
				item.setNumfact(factura.getNumfactura());
				item.setCodtipograbado("T");

				for (DatoSerieItem serieItem : item.getListSerieItems()) {
					serieItem.setNumcorredoc(dav.getNumcorredoc());
					serieItem.setNumsecprove(dav.getNumsecuprov());
					serieItem.setNumsecfact(factura.getNumsecfactu());
					serieItem.setNumfact(factura.getNumfactura());
					serieItem.setNumsecitem(item.getNumsecitem());
				}

				if (item.getMontoProv() != null) {
					item.getMontoProv().setNumcorredoc(dav.getNumcorredoc());
					item.getMontoProv().setNumsecprove(dav.getNumsecuprov());
					item.getMontoProv().setNumsecfact(factura.getNumsecfactu());
					item.getMontoProv().setNumfact(factura.getNumfactura());
					item.getMontoProv().setNumsecitem(item.getNumsecitem());
				}

				for (DatoDescrMinima descrMinima : item.getListDecrMinima()) {
					descrMinima.setNumcorredoc(dav.getNumcorredoc());
					descrMinima.setNumsecprove(dav.getNumsecuprov());
					descrMinima.setNumsecfact(factura.getNumsecfactu());
					descrMinima.setNumfact(factura.getNumfactura());
					descrMinima.setNumsecitem(item.getNumsecitem());
				}

				for (Observacion obs : item.getListObservaciones()) {
					obs.setNumcorredoc(dav.getNumcorredoc());
				}

			}
		}

		return dav;
	}

	/*
	 * public FabricaDeServicios getFabricaDeServicios() { return
	 * fabricaDeServicios; }
	 * 
	 * 
	 * public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios)
	 * { this.fabricaDeServicios = fabricaDeServicios; }
	 */

}
