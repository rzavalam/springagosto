package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.neumaticos;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.neumaticos.model.Neumatico;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * La Class ValidadorDescrMinNeumaticos.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class ValidadorNeumatico2 extends ValidadorAbstract
{

  private static final String NUMERICA_CODIGO = "01";
	private static final String ALFANUMERICA_CODIGO = "02";
	private static final String MILIMETRICA_CODIGO = "03";
	private static final String NUMERICA_PATRON = "[\\d]{1,4}((\\.)[\\d]{1,2})?";
	private static final String ALFANUMERICA_PATRON ="\\w+";
	private static final String MILIMETRICA_PATRON ="[\\d]{1,5}((\\.)[\\d]{1,2})?";

	
	public ValidadorNeumatico2() {
		super();
	}

  /**
   * {@inheritDoc}
 * @throws Exception 
   **/
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
	  List<ErrorDescrMinima> lstErrores = validarEstructura (objeto);
      //lstErrores.addAll(validarEstructura (objeto));

      if (CollectionUtils.isEmpty(lstErrores)){
          lstErrores.addAll(validarAnchoSeccion(objeto));
          lstErrores.addAll(validarRelacionAspectoSerie(objeto));
          lstErrores.addAll(validarDiametroAro(objeto));
      }

	  return lstErrores;
  }

  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
  }

 	public List<ErrorDescrMinima> validarUso(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}

  	public List<ErrorDescrMinima> validarPrimerMaterial(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}


	public List<ErrorDescrMinima> validarSegundoMaterial(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarTipoNomenclatura(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}

	//R781: variacion se verifica que se registre un valor 
	//num�rico en formato de 6 enteros y dos decimales desde descrposicion, casilla nomenclatura se cierra
  public List<ErrorDescrMinima> validarAnchoSeccion(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}

  	//R780: variacion se retira la casilla nomenclatura por lo que la regla 
	public List<ErrorDescrMinima> validarRelacionAspectoSerie(ModelAbstract objeto){
		List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
		/*if(objeto instanceof Neumatico){
			Neumatico neumatico = (Neumatico) objeto;
			String relAspecto = neumatico.getRelacionAspectoSerie().getValtipdescri();
			String tipoNomenclatura = neumatico.getTipoNomenclatura().getValtipdescri();

            boolean esObligatorio = SunatStringUtils.include(tipoNomenclatura, new String[]{ALFANUMERICA_CODIGO,MILIMETRICA_CODIGO});

            if(esObligatorio)
            {
                if(SunatStringUtils.isEmptyTrim(relAspecto))
                {
                    ErrorDescrMinima error =obtenerError("31707", neumatico.getRelacionAspectoSerie());
                    lstError.add(error);
                }
                else
                {
                    try{
                        Double.parseDouble(relAspecto);
                    }catch(NumberFormatException e){
                        ErrorDescrMinima error =obtenerError("31718",neumatico.getRelacionAspectoSerie());
                        lstError.add(error);
                    }
                }
            }
            else
            {
                if(!SunatStringUtils.isEmpty(relAspecto)){
                    ErrorDescrMinima error =obtenerError("31863",neumatico.getRelacionAspectoSerie());
                    lstError.add(error);
                }
            }
		}*/
		return lstError;
	}

	public List<ErrorDescrMinima> validarDiametroAro(ModelAbstract objeto){
    return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarTipoConstruccion(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarIndiceCapacidadCarga(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarLimiteVelocidad(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCodigoSeguridad(ModelAbstract objeto){
		return new ArrayList<ErrorDescrMinima>();
	}
}
