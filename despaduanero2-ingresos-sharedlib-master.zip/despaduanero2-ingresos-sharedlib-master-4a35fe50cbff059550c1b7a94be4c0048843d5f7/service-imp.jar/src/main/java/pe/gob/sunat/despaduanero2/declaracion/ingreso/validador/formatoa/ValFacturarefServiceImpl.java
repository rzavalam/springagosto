/*
 * Clase que define el servicio de validaciones de las referencias de las facturas
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;


import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * The Class ValFacturaref. Clase que define el servicio de validaciones de las referencias de las facturas.
 */
public class ValFacturarefServiceImpl extends ValDuaAbstract implements ValFacturaref{
	
	/**
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codidfactura String
	 * @return Map
	 */
	public Map<String, String> codidfactura(String codidfactura){
		return !SunatStringUtils.isEmpty(codidfactura)?new HashMap<String,String>():getDUAError("30308", "");
	}

	/**
	 * Valida el N�mero de factura.<br>
	 * Valida que el par&aacute;metro no este vacio.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numfactura String. N�mero de factura
	 * @return Map
	 */
	public Map<String, String> numfactura(String numfactura){
		return (!SunatStringUtils.isEmptyTrim(numfactura))?null:getDUAError("08916","");
	}

	/**
	 * Valida la fecha de factura.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fecfactura Date. Fecha de factura.
	 * @return Map
	 */
	public Map<String, String> fecfactura(Date fecfactura){
		Date fechaActual=new Date(Calendar.getInstance().getTimeInMillis());

		if( fecfactura != null )
		{
			if (fecfactura.getTime() > fechaActual.getTime())
			{	//lmvr RN 169
				return getDUAError("30309","");
			}
		}
		else
			return getDUAError("30580","");	
		
		return new HashMap<String,String>();
	}
	
	
	public Map<String, String> validacionFecFactura(Declaracion declaracion,DatoSerie serie){	
		
		DUA dua=declaracion.getDua();
		Date fechaActual=new Date(Calendar.getInstance().getTimeInMillis());		
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		Integer numSecFactu=0;
		List<DatoFacturaref> list=new ArrayList<DatoFacturaref>();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (FACTURA.equals(serieDoc.getCodtipodocsoporte()))
				numSecFactu=serieDoc.getNumiddocsoporte();
			if (numSecFactu!=null && numSecFactu!=0){
				for(DatoFacturaref facturaRef:dua.getListFacturaRef()){
					if (numSecFactu.intValue()==facturaRef.getNumsecfactu())
						
						if(facturaRef.getFecfactura().getTime() > fechaActual.getTime()){
							return getDUAError("30778",new Object[]{serie.getNumserie(),facturaRef.getNumfactura()});
						}	
				}
			}
		}
		return new HashMap<String,String>();
	}
	
	//inicio gmontoya bug 18093
	public Map<String, String> validacionCorrelacionSerieFactura(Declaracion declaracion,DatoSerie serie){	
		Map<String, String> listaErrores = new HashMap<String, String>();
		
		DUA dua=declaracion.getDua();
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		Integer numSecFactu=0;
		boolean existe = false;
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (FACTURA.equals(serieDoc.getCodtipodocsoporte()))
				numSecFactu=serieDoc.getNumiddocsoporte();
			if (numSecFactu!=null && numSecFactu!=0){
				for(DatoFacturaref facturaRef:dua.getListFacturaRef()){
					if (numSecFactu.intValue()==facturaRef.getNumsecfactu()){
							existe = true;							
						}	
				}
				if(!existe){
					listaErrores.putAll(getDUAError("35253",new Object[]{serie.getNumserie(),numSecFactu}));
				}else{
					existe = false;
				}
			}
		}	
		
		return listaErrores;
	}
	
	public Map<String, String> validacionSecuenciaFactura(Declaracion declaracion){		
		DUA dua=declaracion.getDua();
		int numSecuencia = 1;		
		for(DatoFacturaref facturaRef:dua.getListFacturaRef()){
			if (numSecuencia!=facturaRef.getNumsecfactu()){
				return getDUAError("35252",new Object[]{facturaRef.getNumsecfactu()});
			}
			numSecuencia++;
		}		
		return new HashMap<String,String>();
	}
	//fin gmontoya bug 18093
	
	
	/**
	 * Valida el codigo de tipo de factura. UNCL 1001 - Valor : 380 : Factura Comercial
	 * 
	 * @param codtipofact String
	 * @return el mapa de errores
	 */
	public Map<String,String> codtipofact(String codtipofact){
		if (!SunatStringUtils.isEmpty(codtipofact)){
//			if (FormatoAServiceImpl.getInstance().isValidCatalogo("323", codtipofact))
			if ("380".equals(codtipofact))
				return new HashMap<String,String>();
			else
				return getDUAError("30310", "");
		}else{
			return getDUAError("30310", "codtipofact en blanco");
		}
	}
}
