package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.reproduccion;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;

/**
 * La Class ValidadorDescrMinimaReproControlador.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class ValidadorReproControlador extends ValidadorReproAbstract
{
public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
	  List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);
	  //lstErrores.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores)){
    	  lstErrores.addAll(super.validarUnidadComercial(objeto, dua));
          lstErrores.addAll(super.validarNombreComercial(objeto,dua));
          lstErrores.addAll(super.validarMarcaComercial(objeto));
          lstErrores.addAll(super.validarModelo(objeto));
          lstErrores.addAll(validarDatosEnviadosCorrespondenAltipoDescrMinima(objeto,dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarCantMaxLectoresDiscoOpticos (objeto));
      }


      return lstErrores;
	}

	public List<ErrorDescrMinima>  validarCantMaxLectoresDiscoOpticos (ModelAbstract objeto)
	{
		return new ArrayList<ErrorDescrMinima>();
  }
}
