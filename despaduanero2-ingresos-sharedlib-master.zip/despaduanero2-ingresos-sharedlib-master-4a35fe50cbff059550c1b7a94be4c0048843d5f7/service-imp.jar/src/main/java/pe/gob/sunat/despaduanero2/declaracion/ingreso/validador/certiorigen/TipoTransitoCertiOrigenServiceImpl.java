package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import org.springframework.util.StringUtils;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
//import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDoctrans;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PaisOrigenTratoPreferencialService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.TratoPreferencialInternacionalService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;

/**
 * Validaciones asociadas al indicador de Tipo de Transito del Certificado de Origen 
 * @author rbegazo
 *
 */
public class TipoTransitoCertiOrigenServiceImpl extends ValDuaAbstract implements TipoTransitoCertiOrigenService {

	//private FabricaDeServicios	fabricaDeServicios;
	
	//private TratoPreferencialInternacionalService tpiService;
	//private PaisOrigenTratoPreferencialService paisOrigenTratoPreferencialService;
	//private CatalogoHelperImpl catalogoHelper;
	
	@ServicioAnnot(tipo="V",codServicio=3339, descServicio="validacion de envio de indicador de tr�nsito")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3339,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarIndicadorTransito(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		Map<String, String> listError=new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();

		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		for(DatoAutocertificacion certificadoOrigenActual:listCertificadoOrigen){
			//rtineo optimizacion, llamamos al metodo optimizado
			boolean indTransito = IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, ConstantesTipoCatalogo.CATALOGO_INDICADOR_TRANSITO, certificadoOrigenActual.getIndtrans(), variablesIngreso);
			//boolean indTransito = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat( ConstantesTipoCatalogo.CATALOGO_INDICADOR_TRANSITO, certificadoOrigenActual.getIndtrans()));
			//fin optimizacion
			
			//pase48 - TPI's - se agrega validacion de espacio en blanco de indicador de transito (12/10/2015)
			//amacnillla pase35
			if (!indTransito || certificadoOrigenActual.getIndtrans()==null || /*certificadoOrigenActual.getIndtrans().trim().equals("")*/  StringUtils.isEmpty(certificadoOrigenActual.getIndtrans().trim())){
				String codConvenio = serie.getCodconvinter().toString();
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30681",new String[] {serie.getNumserie().toString(),certificadoOrigenActual.getIndtrans(), codConvenio});
			}
		}
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3340, descServicio="validacion de envio de indicador de tr�nsito, que se envie la fecha y puerto en origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3340,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public List<Map<String, String>> valIndicadorFechaPuertoOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie); 
		DatoAutocertificacion certificadoOrigenActual = CollectionUtils.isEmpty(listCertificadoOrigen)? new DatoAutocertificacion(): listCertificadoOrigen.get(0);
		String indTransito = certificadoOrigenActual.getIndtrans();
		if (SunatStringUtils.include(indTransito, new String[]{ConstantesDataCatalogo.CON_TRANSITO_TERCER_PAIS, ConstantesDataCatalogo.CON_ALMACENAMIENTO_TEMPORAL})){
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			String codConvenio = serie.getCodconvinter().toString();
			if (documentoTransporte != null){	

				//amancil parcche no funca para diligecnias
				//if (SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarqueorg()) == 0){
				if(SunatDateUtils.getIntegerFromDate(documentoTransporte.getFecembarqueorg()) == 0 || SunatDateUtils.isDefaultDate(documentoTransporte.getFecembarqueorg())){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30682",new String[] {serie.getNumserie().toString(),codConvenio,certificadoOrigenActual.getIndtrans()}));
				}			
				//pase48 - TPI's - se agrega validacion de espacio en blanco de codigo de puerto de origen (12/10/2015)
				//amancilla pase35
				if (documentoTransporte.getCodpuertoorg() == null || /*documentoTransporte.getCodpuertoorg().trim().equals("")*/ StringUtils.isEmpty(documentoTransporte.getCodpuertoorg().trim())){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30683",new String[] {serie.getNumserie().toString(),codConvenio,certificadoOrigenActual.getIndtrans()}));
				}
				if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(documentoTransporte.getFecembarqueorg(), documentoTransporte.getFecembarque(), SunatDateUtils.COMPARA_SOLO_FECHA)){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30684",new String[] {serie.getNumserie().toString(),SunatDateUtils.getFormatDate(documentoTransporte.getFecembarqueorg(), "dd/MM/yyyy"),
							SunatDateUtils.getFormatDate(documentoTransporte.getFecembarque(), "dd/MM/yyyy"),codConvenio}));
				}					
			} else {
				//no envio fecha de embarque y/o puerto de embaque de origen
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30682",new String[] {serie.getNumserie().toString(),codConvenio,certificadoOrigenActual.getIndtrans()}));
			}		
		}
			
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3341, descServicio="validacion de envio de indicador de tr�nsito 1 y 3, que el puerto de embarque en origen sea el del pais de origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3341,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> valIndicadorPaisConPuertoEmbarqueOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		Map<String, String> listError= new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();		
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie); 
		DatoAutocertificacion certificadoOrigenActual = CollectionUtils.isEmpty(listCertificadoOrigen)? new DatoAutocertificacion(): listCertificadoOrigen.get(0);
		String indTransito = certificadoOrigenActual.getIndtrans();
		if (SunatStringUtils.include(indTransito, new String[]{ConstantesDataCatalogo.CON_TRANSITO_TERCER_PAIS, ConstantesDataCatalogo.CON_ALMACENAMIENTO_TEMPORAL})){
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			String codConvenio = serie.getCodconvinter().toString();
			String codPaisOrigen = serie.getCodpaisorige();
			if (documentoTransporte != null){			
				String codPaisPtoOrigen = SunatStringUtils.substring(documentoTransporte.getCodpuertoorg(), 0, 2); 	
				
				// Por revisar - Bug 19760 
				
				
				if (!codPaisOrigen.equals(codPaisPtoOrigen)){//porsia..... || !(valDoctrans.codpuertoorg(documentoTransporte.getCodpuertoorg())).isEmpty()
					//pais de puerto de origen no coincide con el pais de origen
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30685",new String[] {serie.getNumserie().toString(),codPaisOrigen,documentoTransporte.getCodpuertoorg()!=null?documentoTransporte.getCodpuertoorg():" ",codConvenio});//no muestre null en error TPI814
				}
				
				
//				else{//jenciso TPI 503 (se considerara tb para los dem�s TPIS)
//					//Si el puerto de embarque corresponde al pais de origen se rechaza
//					String codPaisPtoEmb = SunatStringUtils.substring(documentoTransporte.getCodpuerto(),0,2);
//					if(codPaisPtoEmb.equals(codPaisOrigen)){
//						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30903",new String[] {serie.getNumserie().toString(),codPaisPtoEmb,codConvenio.toString()});
//					}
//				}
			} else {
				//no envio existe puerto de embaque de origen
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30685",new String[] {serie.getNumserie().toString(),codPaisOrigen," ",codConvenio});
			}		 
		}
		return listError;
	}
	

	@ServicioAnnot(tipo="V",codServicio=3399, descServicio="validacion de envio de indicador de tr�nsito 2, que el puerto de embarque sea el del pais de origen")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3399,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public List<Map<String, String>> valIndicadorPaisConPuertoEmbarque(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		List<Map<String, String>> listError= new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();		
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie); 
		DatoAutocertificacion certificadoOrigenActual = CollectionUtils.isEmpty(listCertificadoOrigen)? new DatoAutocertificacion(): listCertificadoOrigen.get(0);
		String indTransito = certificadoOrigenActual.getIndtrans();
		if (SunatStringUtils.include(indTransito, new String[]{ConstantesDataCatalogo.SIN_TRANSITO_TERCER_PAIS})){
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			String codConvenio = serie.getCodconvinter().toString();
			String codPaisOrigen = serie.getCodpaisorige();
			if (documentoTransporte != null){			
				String codPaisPtoOrigen = SunatStringUtils.substring(documentoTransporte.getCodpuerto(), 0, 2); 			
				if (!codPaisOrigen.equals(codPaisPtoOrigen)){
					//pais de puerto no coincide con el pais de origen
//					listError.add(catalogoHelper.getErrorMap("30894", new String[] {serie.getNumserie().toString(),codPaisOrigen,documentoTransporte.getCodpuerto(),codConvenio}));
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30894",new String[] {serie.getNumserie().toString(),codPaisOrigen,documentoTransporte.getCodpuerto(),codConvenio}));
				}
				Date fechaEmbaqueOrigen = documentoTransporte.getFecembarqueorg();
				String codPtoOrigen = documentoTransporte.getCodpuertoorg();
				try{
					if ((fechaEmbaqueOrigen!= null && !DateUtil.dateToString(fechaEmbaqueOrigen, "dd/MM/yyyy").equals(Constantes.DEFAULT_FECHA_BD)) ||(codPtoOrigen!= null && !"".equalsIgnoreCase(codPtoOrigen.trim()))){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30812",new String[] {serie.getNumserie().toString(),codPtoOrigen,SunatDateUtils.getFormatDate(fechaEmbaqueOrigen, "dd/MM/yyyy")}));
					}
				}
	            catch (Exception e){}
			} else {
				//no envio existe puerto de embaque 
//				listError.add(catalogoHelper.getErrorMap("30894", new String[] {serie.getNumserie().toString(),codPaisOrigen,"",codConvenio}));
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30894",new String[] {serie.getNumserie().toString(),codPaisOrigen,"",codConvenio}));
			}		 
		}
		return listError;
	}

	//solo para 229, no debe validar el 30812
	@ServicioAnnot(tipo="V",codServicio=3441, descServicio="validacion de envio de indicador de tr�nsito 2, que el puerto de embarque sea el del pais de origen y envio de puerto de origen opcional")
	@ServInstDetAnnot(tipoRpta={0,1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3441,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public List<Map<String, String>> valIndicadorPaisConPuertoEmbarqueYOrigenOpcional(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		List<Map<String, String>> listError= new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();		
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie); 
		DatoAutocertificacion certificadoOrigenActual = CollectionUtils.isEmpty(listCertificadoOrigen)? new DatoAutocertificacion(): listCertificadoOrigen.get(0);
		String indTransito = certificadoOrigenActual.getIndtrans();
		if (SunatStringUtils.include(indTransito, new String[]{ConstantesDataCatalogo.SIN_TRANSITO_TERCER_PAIS})){
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			String codConvenio = serie.getCodconvinter().toString();
			String codPaisOrigen = serie.getCodpaisorige();
			if (documentoTransporte != null){			
				String codPaisPtoOrigen = SunatStringUtils.substring(documentoTransporte.getCodpuerto(), 0, 2); 			
				if (!codPaisOrigen.equals(codPaisPtoOrigen)){
					//pais de puerto no coincide con el pais de origen
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30894",new String[] {serie.getNumserie().toString(),codPaisOrigen,documentoTransporte.getCodpuerto(),codConvenio}));
				}
				
			} else {
				//no envio existe puerto de embaque 
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30894",new String[] {serie.getNumserie().toString(),codPaisOrigen,"",codConvenio}));
			}		 
		}
		return listError;
	}
	
	//jenciso se cambia el nombre del metodo conforme al registrado en servicio y funcionalidad del metodo 
	//servicio solo para el 812
	@ServicioAnnot(tipo="V",codServicio=3342, descServicio="validacion de envio de indicador de tr�nsito 1 y 3, que el puerto de embarque en origen sea el de cualquier pais de origen del acuerdo")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3342,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> valIndicadorPaisesConPuertoEmbarqueOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ValDoctrans valDoctrans = fabricaDeServicios.getService("ValDoctrans");

		Map<String, String> listError= new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie); 
		DatoAutocertificacion certificadoOrigenActual = CollectionUtils.isEmpty(listCertificadoOrigen)? new DatoAutocertificacion(): listCertificadoOrigen.get(0);
		String indTransito = certificadoOrigenActual.getIndtrans();
		if (SunatStringUtils.include(indTransito, new String[]{ConstantesDataCatalogo.CON_TRANSITO_TERCER_PAIS, ConstantesDataCatalogo.CON_ALMACENAMIENTO_TEMPORAL})){
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			String codPaisOrigen = serie.getCodpaisorige();
			Integer codConvenio = serie.getCodconvinter();
			if (documentoTransporte != null){
				String codPaisPtoOrigen = SunatStringUtils.substring(documentoTransporte.getCodpuertoorg(), 0, 2);
				boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codConvenio.toString(), codPaisPtoOrigen);
				
				
				if (!existePuerto || !(valDoctrans.codpuertoorg(documentoTransporte.getCodpuertoorg())).isEmpty()){//jenciso bug19184 vuelve a verificar que el puerto exista caso contrario muestra mensaje 
					//pais de puerto de origen no coincide con el pais de origen
					//EGH_PAS20165E220100028
					if(documentoTransporte.getCodpuertoorg()!=null)
						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30685",new String[] {serie.getNumserie().toString(),codPaisOrigen, documentoTransporte.getCodpuertoorg()!=null?documentoTransporte.getCodpuertoorg():" ",codConvenio.toString()});//no muestre null en error TPI814
				}	
				
//				else{//jenciso
//					//si tercer pais es del acuerdo se rechaza..
//					String codPaisPtoEmb = SunatStringUtils.substring(documentoTransporte.getCodpuerto(),0,2);
//					boolean existePtoEmb = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codConvenio.toString(), codPaisPtoEmb);
//					if(existePtoEmb){
//						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30903",new String[] {serie.getNumserie().toString(),codPaisPtoEmb,codConvenio.toString()});
//					}
//				}				
			} else {
				//no envio existe puerto de embaque de origen
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30685",new String[] {serie.getNumserie().toString(),codPaisOrigen, " ", codConvenio.toString()});
			}
		}
		return listError;		
	}

	//jenciso valida para tipo de transito 1 o 3 que el Puerto de embarque no sea un puerto del pa�s de origen
	@ServicioAnnot(tipo="V",codServicio=3440, descServicio="validacion de envio de indicador de tr�nsito 1 y 3, que el puerto de embarque no sea un puerto del pa�s de origen del acuerdo")
	@ServInstDetAnnot(tipoRpta={0,1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3440,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> valIndicadorPuertoEmbarqueDistintoPaisOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		Map<String, String> listError= new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie); 
		DatoAutocertificacion certificadoOrigenActual = CollectionUtils.isEmpty(listCertificadoOrigen)? new DatoAutocertificacion(): listCertificadoOrigen.get(0);
		String indTransito = certificadoOrigenActual.getIndtrans();
		if (SunatStringUtils.include(indTransito, new String[]{ConstantesDataCatalogo.CON_TRANSITO_TERCER_PAIS, ConstantesDataCatalogo.CON_ALMACENAMIENTO_TEMPORAL})){
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			String codPaisOrigen = serie.getCodpaisorige();
			Integer codConvenio = serie.getCodconvinter();
			if (documentoTransporte != null){

				//si tercer pais es del acuerdo se rechaza..
				String codPaisPtoEmb = SunatStringUtils.substring(documentoTransporte.getCodpuerto(),0,2);
				boolean existePtoEmb = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codConvenio.toString(), codPaisPtoEmb);
				if(existePtoEmb){
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30903",new String[] {serie.getNumserie().toString(),codPaisPtoEmb,codConvenio.toString()});
				}
								
			} 
		}
		return listError;		
	}


	//jenciso se cambia el nombre del metodo conforme al registrado en servicio y funcionalidad del metodo
	//servicio solo para el 812 801 802
	@ServicioAnnot(tipo="V",codServicio=3402, descServicio="validacion de envio de indicador de tr�nsito 2, que el puerto de embarque sea el de cualquier pais de origen del acuerdo")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3402,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public List<Map<String, String>>  valIndicadorPaisesConPuertoEmbarque(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		List<Map<String, String>>  listError= new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie); 
		DatoAutocertificacion certificadoOrigenActual = CollectionUtils.isEmpty(listCertificadoOrigen)? new DatoAutocertificacion(): listCertificadoOrigen.get(0);
		String indTransito = certificadoOrigenActual.getIndtrans();
		if (SunatStringUtils.include(indTransito, new String[]{ConstantesDataCatalogo.SIN_TRANSITO_TERCER_PAIS})){
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			String codPaisOrigen = serie.getCodpaisorige();
			Integer codConvenio = serie.getCodconvinter();
			if (documentoTransporte != null){
				String codPaisPtoOrigen = SunatStringUtils.substring(documentoTransporte.getCodpuerto(), 0, 2);
				boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codConvenio.toString(), codPaisPtoOrigen);
				if (!existePuerto){
					//pais de puerto de origen no coincide con el pais de origen
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30894", new String[] {serie.getNumserie().toString(),codPaisOrigen, documentoTransporte.getCodpuerto(),codConvenio.toString()}));
				}
				 
				Date fechaEmbaqueOrigen = documentoTransporte.getFecembarqueorg();
				String codPtoOrigen = documentoTransporte.getCodpuertoorg();
				try{
					if ((fechaEmbaqueOrigen!= null && !DateUtil.dateToString(fechaEmbaqueOrigen, "dd/MM/yyyy").equals(Constantes.DEFAULT_FECHA_BD))  && codPtoOrigen!= null && !"".equalsIgnoreCase(codPtoOrigen.trim())){//jenciso VERIFICAR esta validacion no esta en RIN ni F2 Antiguo//RIN06 PAS20155E220100048 
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30812", new String[] {serie.getNumserie().toString(),codPtoOrigen,SunatDateUtils.getFormatDate(fechaEmbaqueOrigen, "dd/MM/yyyy")}));
					}
				}
				catch(Exception e){}
			} else {
				//no envio existe puerto de embaque de origen
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30894", new String[] {serie.getNumserie().toString(),codPaisOrigen, "", codConvenio.toString()}));
			}
		}
		return listError;		
	}
	//solo TPIs 807, 358, 602, 504, 100
	@ServicioAnnot(tipo="V",codServicio=3434, descServicio="validacion de envio de indicador de tr�nsito 2, que el puerto de embarque de origen sea el de cualquier pais de origen del acuerdo")
	@ServInstDetAnnot(tipoRpta={0,1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3434,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public List<Map<String, String>>  valIndicadorPaisesConPuertoEmbarqueYOrigen(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia){
		PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");

		List<Map<String, String>>  listError= new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie); 
		DatoAutocertificacion certificadoOrigenActual = CollectionUtils.isEmpty(listCertificadoOrigen)? new DatoAutocertificacion(): listCertificadoOrigen.get(0);
		String indTransito = certificadoOrigenActual.getIndtrans();
		if (SunatStringUtils.include(indTransito, new String[]{ConstantesDataCatalogo.SIN_TRANSITO_TERCER_PAIS})){
			DatoDocTransporte documentoTransporte = getDocTransporte(dua, serie);
			String codPaisOrigen = serie.getCodpaisorige();
			Integer codConvenio = serie.getCodconvinter();
			if (documentoTransporte != null){
				String codPaisPto = SunatStringUtils.substring(documentoTransporte.getCodpuerto(), 0, 2);
				boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codConvenio.toString(), codPaisPto);
				if (!existePuerto){
					//pais de puerto de origen no coincide con el pais de origen
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30894", new String[] {serie.getNumserie().toString(),codPaisOrigen, documentoTransporte.getCodpuerto(),codConvenio.toString()}));
				}
				
				Date fechaEmbaqueOrigen = documentoTransporte.getFecembarqueorg();
				String codPtoOrigen = documentoTransporte.getCodpuertoorg();				
				String codPaisPtoOrigen = SunatStringUtils.substring(documentoTransporte.getCodpuertoorg(), 0, 2);
				boolean existePuertoOrigen = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codConvenio.toString(), codPaisPtoOrigen);
				if (!existePuertoOrigen){
					//pais de puerto de origen no coincide con el pais de origen
//					listError = catalogoHelper.getErrorMap("30685", new String[] {serie.getNumserie().toString(),codPaisOrigen, documentoTransporte.getCodpuertoorg(),codConvenio.toString()});
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30685",new String[] {serie.getNumserie().toString(),codPaisOrigen, documentoTransporte.getCodpuertoorg()!=null?documentoTransporte.getCodpuertoorg():" ",codConvenio.toString()}));//no muestre null en error TPI814
				}
				
				/* 
				if (fechaEmbaqueOrigen!= null ||codPtoOrigen!= null){//jenciso VERIFICAR esta validacion no esta en RIN ni F2 Antiguo
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30812", new String[] {serie.getNumserie().toString(),codPtoOrigen,SunatDateUtils.getFormatDate(fechaEmbaqueOrigen, "dd/MM/yyyy")}));
				}*/
			} else {
				//no envio existe puerto de embaque de origen
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30894", new String[] {serie.getNumserie().toString(),codPaisOrigen, " ", codConvenio.toString()}));
			}
		}
		return listError;		
	}

	/*
	
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
