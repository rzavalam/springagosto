package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoVentilador;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorComputoVentilador extends ValidadorComputoAbstract
{

    private final static String VENTILADOR_DISCO = "DDR";
    private final static String VENTILADOR_PROCESADOR = "PRO";

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua)throws Exception
  {

	    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);
	   // lstErrores.addAll(validarEstructura(objeto));
      if (CollectionUtils.isEmpty(lstErrores)){
          DatoItem item =  obtenerItem(objeto, dua);
          lstErrores.addAll(validarUnidadComercial(objeto, item));
          //lstErrores.addAll(validarNombreComercial(objeto, item));
          lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarTipoInterface(objeto));
          lstErrores.addAll(validarTipoVentilador(objeto));
          lstErrores.addAll(validarTipoProcesador(objeto));
      }


	    return lstErrores;
	}

    public List<ErrorDescrMinima> validarTipoInterface(ModelAbstract object){
        List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
        ComputoVentilador ventilador = (ComputoVentilador) object;
        String datoAValidar = ventilador.getTipoInterface().getValtipdescri();
        String tipoVentilador = ventilador.getTipoVentilador().getValtipdescri();
        if(SunatStringUtils.isEqualTo(VENTILADOR_DISCO,tipoVentilador)){
            if(SunatStringUtils.isEmpty(datoAValidar)){
                lst.add(obtenerError("31491",ventilador.getTipoVentilador()));
            }
        }
        return lst;
    }


    public List<ErrorDescrMinima> validarTipoVentilador (ModelAbstract object){
        List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
        ComputoVentilador ventilador = (ComputoVentilador) object;
        String datoAValidar = ventilador.getTipoVentilador().getValtipdescri();
        if(!SunatStringUtils.isEmpty(datoAValidar)){
            if(!Arrays.asList(VENTILADOR_DISCO,VENTILADOR_PROCESADOR).contains(datoAValidar)){
                lst.add(obtenerError("31503",ventilador.getTipoVentilador()));
            }
        }else{
            lst.add(obtenerError("31504", ventilador.getTipoVentilador()));
        }

        return lst;
    }

    public List<ErrorDescrMinima> validarTipoProcesador(ModelAbstract object){
        List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
        ComputoVentilador ventilador =  (ComputoVentilador) object;
        String datoAValidar = ventilador.getTipoProcesador().getValtipdescri();
        String tipoVentilador = ventilador.getTipoVentilador().getValtipdescri();

        if(SunatStringUtils.isEqualTo(VENTILADOR_PROCESADOR,tipoVentilador)){
            if(SunatStringUtils.isEmpty(datoAValidar)){
                lst.add(obtenerError("31505", ventilador.getTipoProcesador()));
            }
        }
        return lst;
    }
}
