package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.MRestri;
import pe.gob.sunat.despaduanero.catalogo.tg.service.MrestriDAOService;
import pe.gob.sunat.despaduanero2.ayudas.model.Cambio1;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValModalidadService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
//import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.util.Constantes;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
//PAS20165E220200049 RSV LGA 
import pe.gob.sunat.despaduanero.catalogo.tg.service.FeriasDAOService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.manifiesto.consulta.service.ProrrogaService;

//PAS20165E220200049 RSV LGA

/**
 *
 * DepositoValidacionServiceImpl.java
 * @author Karina Iparraguirre
 * @version 1.0
 *
 */

public class DepositoValidacionServiceImpl  extends ValDuaAbstract implements DepositoValidacionService {



	//protected final Log log = LogFactory.getLog(getClass());
	//private CabDeclaraDAO cabDeclaraDao;    
	//private NandTasaDAO nandTasaDao;
	//private CabManifiestoDAO manifiestoDao;
	//protected CatalogoHelperImpl catalogoHelper;

	//private AyudaService ayudaService;
	//private DdpDAOService ddpDAOService;
	//private MrestriDAOService mrestriDAOService;
	//private FabricaDeServicios fabricaDeServicios;
	//private FeriasDAOService feriasDAOService;
	//private CatalogoAyudaService catalogoAyudaService;
	//private ProrrogaService prorrogaService;

	/** Verifica si existe o no el registro en BD
	 * @param declaracion
	 * @return Map de errores
	 */
	public Map<String, String> validarExistencia(Declaracion declaracion){
		CabDeclaraDAO cabDeclaraDao = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDef");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		Map<String, String> resultadoError = new HashMap<String, String>(); 		
		DUA duaTmp = new DUA();

		Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();

		paramsCabDeclara.put("codigoAduana", declaracion.getCodaduana());
		paramsCabDeclara.put("annoPresentacion",declaracion.getAnnorden() );
		paramsCabDeclara.put("codigoRegimen",declaracion.getDua().getCodregimen());
		paramsCabDeclara.put("numeroDeclaracion", declaracion.getNumorden());

		duaTmp=(DUA)cabDeclaraDao.findDUAByKeyMap(paramsCabDeclara);

		if (duaTmp!=null){// existe ya declaracion en la BD
			resultadoError= catalogoAyudaService.getError("0001", new String[]{"LA ORDEN YA HA SIDO NUMERADA ANTERIORMENTE"});
		}

		return resultadoError;

	}
	/** Valida la vigencia de fecha de expiracion
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarVigenciaFechaExpiracion(Declaracion declaracion){
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		Date fechaActual= new Date();
		int diaenviado=0;
		int diaMaximoMes=0;
		Calendar fechaActualCalendar = Calendar.getInstance();
		boolean flagVigencia=false;
		flagVigencia=PackageGeneral.getVigenciaCambio("983", declaracion.getDua().getCodregimen(), "TD000", "000030", SunatDateUtils.getCurrentDate())>0;

		if (declaracion.getDua().getCodregimen().equals("70") && flagVigencia){
			boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());

			if(declaracionTieneDatoSeries){
				for (DatoSerie datoSerieActual : dua.getListSeries()) {
					if (datoSerieActual.getFecexpiracion()!=null && datoSerieActual.getFecexpiracion().getTime()!=0){
						if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaActual,datoSerieActual.getFecexpiracion(),SunatDateUtils.COMPARA_SOLO_FECHA)){
							result.add(	getDUAError("0482", "VERIFIQUE.FECHA DE EXPIRACION DE MERCANCIA PERECIBLE YYYYMMDD ".concat(datoSerieActual.getFecexpiracion().toString())));
						}
						//Se verifica para que el dia no supere el maximo de dias de un mes.
						FechaBean fechaTmpExp=new FechaBean();
						fechaTmpExp.setFecha(datoSerieActual.getFecexpiracion());
						diaenviado=Integer.parseInt(fechaTmpExp.getDia());

						FechaBean fechaTemporal=new FechaBean( SunatDateUtils.getFormatDate(datoSerieActual.getFecexpiracion(), "dd/MM/yyyy"));
						diaMaximoMes=fechaTemporal.getMaximo(Calendar.DAY_OF_MONTH);
						if (diaenviado>diaMaximoMes){
							result.add(getDUAError("0482", " EL DIA NO CORRESPONDE A DICHO MES  ".concat(datoSerieActual.getFecexpiracion().toString())));  
						}

						// Validaciones sobre la DUA
						if (dua.getCodtipoplazo().equals("1")){  // Agregar por meses
							fechaActualCalendar.add(5, dua.getNumplazosol()*30);
						}else if (dua.getCodtipoplazo().equals("2")){ // Agregar por dias
							fechaActualCalendar.add(2, dua.getNumplazosol()); 	
						}
					}else{
						if (dua.getCodtipoplazo().equals("1")){  // Agregar por meses
							fechaActualCalendar.add(5, dua.getNumplazosol()*30);
						}else if (dua.getCodtipoplazo().equals("2")){ // Agregar por dias
							fechaActualCalendar.add(2, dua.getNumplazosol()); 	
						}
					}
				}	   
			}
		}
		return result;
	}
	/** Valida si es deposito urgente
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarDepositoUrgente(Declaracion declaracion){
		MrestriDAOService mrestriDAOService = (MrestriDAOService)fabricaDeServicios.getService("Ayuda.mrestriService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua= declaracion.getDua();


		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());


		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				Map params = new HashMap();
				FechaBean fechaActual = new FechaBean();
				String fecha=fechaActual.getFormatDate("yyyyMMdd");

				params.put("cnan",datoSerieActual.getNumpartnandi());
				params.put("fechaVigencia",fecha);
				params.put("tipodoc","1");

				//					List<MRestri> listaMercancia =mrestriDao.listadoMercRestringida(params);
				List<MRestri> listaMercancia =mrestriDAOService.listadoMercRestringida(params); 

				if (listaMercancia.size()>0 && declaracion.getDua().getCodregimen().equals("70") && dua.getCodmodalidad().equals("01") && SunatStringUtils.include(datoSerieActual.getCodestamerca(),new String[]{"20","21","22","23","24","25","26","27"})){
					//Graba_telelog(  RIGHT( duadet.Ano_Orden,2), " ",;stserie, "1116" , "PARTIDA NO PUEDE SER ENVIADO COMO URGENTE EN DEPOSITO:ENVIADO-"+STR(duadet.part_nandi,10), " ",  " ")
					result.add(getDUAError("1116", " PARTIDA NO PUEDE SER ENVIADO COMO URGENTE EN DEPOSITO:ENVIADO- ".concat(datoSerieActual.getNumpartnandi().toString())));
				}
			}
		}
		return result;
	}
	/** Valida el regimen de precedencia
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarRegimenPrecedencia(Declaracion declaracion){
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getListRegPrecedencia()!=null){
					for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {

						if (declaracion.getDua().getCodregimen().equals("70") && declaracion.getDua().getCodregimen()!=datoRegPreActual.getCodregipre() && !dua.getCodferia().equals("2") && !SunatStringUtils.include(datoRegPreActual.getCodregipre(),new String[]{"80","83"}) ){
							//Graba_telelog(  RIGHT( duadet.Ano_Orden,2), " ",stserie, "0055", "DUAREGAP.REGI_PROCE: ENVIADO-"+mcadurp+"-"+mfanorp+"-"+mregi_proce+"-"+mndclrp," ", " " )
							result.add(	getDUAError("0055","DUAREGAP.REGI_PROCE: ENVIADO- ".concat(datoRegPreActual.getCodaduapre()).concat("-").concat(datoRegPreActual.getAnndeclpre()).concat("-").concat(datoRegPreActual.getCodregipre()).concat("-").concat(datoRegPreActual.getNumdeclpre())));
						}
					}	
				}	
			}
		}
		return result;
	}
	/** Asignacion de variable xTipo_proce
	 * @param declaracion
	 * @return List de errores
	 */

	/** Validacion del codigo de ultraactividad
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarCodigoUltraActividad(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua= declaracion.getDua();
		DatoDocTransporte documentoTransporte= new DatoDocTransporte();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		boolean verificarCopAplUltra=false;

		// Validaciones sobre las series	
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (! SunatStringUtils.isEmpty(datoSerieActual.getCodaplultra()) ){
					//fnVeriError('I1', APL_ULTRA, '5040', ' ', 'APL_ULTRA')
					verificarCopAplUltra=esDataCatalogo("I1",datoSerieActual.getCodaplultra());
					if (!verificarCopAplUltra){
						result.add(	catalogoAyudaService.getError("5040"));
					}

				}
				for (DatoSerieDocSoporte datoSerieDocSoporteActual : datoSerieActual.getListSerieDocSoporte()) {
					if (datoSerieDocSoporteActual.getCodtipodocsoporte().equals("3")){// Documento de Transporte
						documentoTransporte=getDocTransporte(dua,datoSerieActual);
						if (documentoTransporte !=null && documentoTransporte.getFecembarque().getTime()==0){
							//Instelelog('0065',vArchivo+'FECH_EMBAR - ENVIADO:'+A_CADENA(FECH_EMBAR)) --Faltaria validarla con fecha de termino de la cabecera
							result.add(	getDUAError("0065","FECH_EMBAR - ENVIADO: ".concat(documentoTransporte.getFecembarque().toString())));
						}
					}
				}

				if ( SunatNumberUtils.isLessOrEqualsThanZero(datoSerieActual.getCntunicomer())){
					//Instelelog('0038', vArchivo+'QUNICOM - ENVIADO:'+A_CADENA(QUNICOM))
					result.add(	getDUAError("0038","QUNICOM - ENVIADO: ".concat(datoSerieActual.getCntunicomer().toString())));
				}
			}
		}
		return result;
	}
	/** Valida del codigo de pais
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarPais(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DatoDocTransporte documentoTransporte= new DatoDocTransporte();
		DUA dua= declaracion.getDua();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {

				boolean verificarCatalogoPaisOri=esDataCatalogo("J2",datoSerieActual.getCodpaisorige());
				boolean verificarCatalogoPaisAdq=esDataCatalogo("J2",datoSerieActual.getCodpaisadqui());
				if (!verificarCatalogoPaisOri){
					result.add(	catalogoAyudaService.getError("0049"));
				}
				if (!verificarCatalogoPaisAdq){
					result.add(	catalogoAyudaService.getError("0050"));
				}
				if (datoSerieActual.getCodpaisorige().equals("PE")&& datoSerieActual.getCodpaisadqui().equals("PE")  ){
					for (DatoSerieDocSoporte datoSerieDocSoporteActual : datoSerieActual.getListSerieDocSoporte()) {
						if (datoSerieDocSoporteActual.getCodtipodocsoporte().equals("3")){// Documento de Transporte
							documentoTransporte=getDocTransporte(dua,datoSerieActual);
							if (documentoTransporte.getCodpuerto().substring(0, 2).equals("PE")){
								//Instelelog('0050',vArchivo+'PUER_EMBAR - ENVIADO:'+PUER_EMBAR+' DEBE SER DE PROCEDENCIA DIFERENTE DE PERU')
								result.add(	getDUAError("0050","PUER_EMBAR - ENVIADO: ".concat(documentoTransporte.getCodpuerto().substring(0, 2).concat(" DEBE SER DE PROCEDENCIA DIFERENTE DE PERU "))));

							}
						}
					}
				}
			}
		}


		return result;
	}
	/** Valida el codigo de la moneda
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarMoneda(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua= declaracion.getDua();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());

		//amancilla
		String transaccion = declaracion.getCodtipotrans()!=null?declaracion.getCodtipotrans().toString():"";

		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				boolean verificarMoneda=esDataCatalogo("J1",datoSerieActual.getCodmoneda());
				if (!verificarMoneda){
					result.add(catalogoAyudaService.getError("0021"));
				}
				if (!SunatStringUtils.include(datoSerieActual.getCodmoneda(),new String[]{"USD",""})){
					if ( SunatNumberUtils.isLessOrEqualsThanZero(datoSerieActual.getMtofobmon())){
						//Instelelog('0032', vArchivo+'FOB_DIVFAC - ENVIADO:'+A_CADENA(FOB_DIVFAC)+'-MONEDA:'+COD_MONEDA) 
						//amancilla
						if(!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION)  && !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)){
							result.add(	getDUAError("0032","FOB_DIVFAC - ENVIADO: ".concat(datoSerieActual.getMtofobmon().toString()).concat("-MONEDA:").concat(datoSerieActual.getCodmoneda())));
						}

					}else{
						Map<String,Object> mapCambio1=new HashMap<String,Object>();
						mapCambio1.put("fingreso", SunatDateUtils.getCurrentIntegerDate());
						mapCambio1.put("cmoneda", datoSerieActual.getCodmoneda().toString());
						//						Cambio1 cambio1=cambio1Dao.findByPK(mapCambio1);
						mapCambio1.put("ayudaID", "Cambio1");
						Cambio1 cambio1 = (Cambio1)ayudaService.buscarObject(mapCambio1);
						if (cambio1==null){
							//Instelelog('0032', 'ADUADET1:COD_MONEDA CODIGO DE MONEDA DE TRANSACCION NO REGISTRADA', NUME_SERIE) 
							//amancillla
							if(!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION) && !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)){
								result.add(	getDUAError("0032","ADUADET1:COD_MONEDA CODIGO DE MONEDA DE TRANSACCION NO REGISTRADA ".concat(datoSerieActual.getNumserie().toString())));
							}
						}else{
							//VAL_ABSOLUTO(REDONDEA(fob_divfac*Vpventa,3) - fob_dolpol) > 0.001 
							BigDecimal resultado=new BigDecimal(0);
							BigDecimal fob_divfac=datoSerieActual.getMtofobmon()!=null?datoSerieActual.getMtofobmon():BigDecimal.ZERO;
							BigDecimal dolarVenta=cambio1.getPventa();
							BigDecimal dolares=SunatNumberUtils.multiply(fob_divfac, dolarVenta);

							resultado= SunatNumberUtils.absoluteDiference(dolares, datoSerieActual.getMtofobdol());
							resultado=resultado.setScale(3,BigDecimal.ROUND_HALF_EVEN);
							if (Math.abs(resultado.doubleValue())>0.001){
								//Instelelog('0033', vArchivo+'FOB_DOLPOL - ENVIADO:'+A_CADENA(FOB_DOLPOL)+'-FOB_DIVFAC * COD_MONEDA - CALCULADO: '+A_CADENA(FOB_DIVFAC*VPVENTA)) 
								result.add(	getDUAError("0033","FOB_DOLPOL - ENVIADO: ".concat(datoSerieActual.getMtofobmon().toString()).concat(" -FOB_DIVFAC * COD_MONEDA - CALCULADO: ").concat(datoSerieActual.getMtofobmon().multiply(cambio1.getPventa()).toString())));
							}
						}

					}

				}else{
					if (SunatNumberUtils.isGreaterThanZero(datoSerieActual.getMtofobmon()) 
							&& !SunatNumberUtils.isEqual(datoSerieActual.getMtofobmon(), datoSerieActual.getMtofobdol())){
						//Instelelog('0032', vArchivo+'FOB_DIVFAC - ENVIADO:'+A_CADENA(FOB_DIVFAC)+'-MONEDA:'+COD_MONEDA+'-FOB_DOLPOL:'+A_CADENA(FOB_DOLPOL)) 
						//result.add(	catalogoHelper.getErrorMap("0032","FOB_DIVFAC - ENVIADO: ".concat(datoSerieActual.getMtofobmon().toString()).concat("-MONEDA: ").concat(datoSerieActual.getCodmoneda()).concat("-FOB_DOLPOL: ").concat(datoSerieActual.getMtofobdol().toString())));

						//amancilla
						if(!transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION)  && !transaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)){
							result.add(	catalogoAyudaService.getError("0032") );
						}
					}
				}
			}
		}


		return result;	
	}
	/** Valida el monto del flete
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarFleteSeguro(Declaracion declaracion){

		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua= declaracion.getDua();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if ( SunatNumberUtils.isLessThanZero(datoSerieActual.getMtofledol())){
					//Instelelog('0034',vArchivo+'FLETE - ENVIADO:'+A_CADENA(FLETE)) 
					result.add(	getDUAError("0034","FLETE - ENVIADO: ".concat(datoSerieActual.getMtofledol().toString())));
				}
				boolean verificarSeguro=esDataCatalogo("62",datoSerieActual.getCodtiposeg());
				if (!verificarSeguro)
					result.add(	getDUAError("0082","EL CODIGO DE SEGURO ES INVALIDO"));
			}
		}

		return result;
	}
	/** Valida el valor de aduanas
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarValorAduanas(Declaracion declaracion){

		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua= declaracion.getDua();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				//Si VAL_ABSOLUTO(VAL_ADUANA - (AJUSTE+FOB_DOLPOL+FLETE+SEGURO)) > 0.003 entonces
				BigDecimal resultado=new BigDecimal(0);
				resultado=SunatNumberUtils.sum(datoSerieActual.getMtoajuste(),datoSerieActual.getMtofobdol());
				resultado=SunatNumberUtils.sum(resultado,datoSerieActual.getMtofledol());
				resultado=SunatNumberUtils.sum(resultado,datoSerieActual.getMtosegdol());

				resultado=datoSerieActual.getMtovaladuana().subtract(resultado);
				//resultado=resultado.setScale(3,BigDecimal.ROUND_HALF_EVEN);

				if (Math.abs(resultado.doubleValue())> 0.003){
					//Instelelog('5003', vArchivo+'ENVIADO VAL_ADUANA:'+A_CADENA(VAL_ADUANA)+'-CALCULADO='+A_CADENA(AJUSTE+FOB_DOLPOL+FLETE+SEGURO)) 
					result.add(	getDUAError("5003","ENVIADO VAL_ADUANA: ".concat(datoSerieActual.getMtovaladuana().toString()).concat(" -CALCULADO=").concat(resultado.toString())));
				}
			}
		}
		return result;
	}
	/** Valida el codigo de Nandtasa
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validarNandtasa(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		NandTasaDAO nandTasaDao = (NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua= declaracion.getDua();
		Map<String,Object> mapNandtasa=new HashMap<String,Object>();
		List<Map<String,Object>> listMapNandtasa=new ArrayList<Map<String,Object>>();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());

		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				mapNandtasa=new HashMap<String,Object>();
				mapNandtasa.put("cnan", datoSerieActual.getNumpartnandi());
				mapNandtasa.put("tnan", datoSerieActual.getCodtnan());
				mapNandtasa.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
				listMapNandtasa=nandTasaDao.findByMap(mapNandtasa);
				if (listMapNandtasa.size()==0){
					//RETORNA '5038' 
					result.add(	catalogoAyudaService.getError("05038",new String[]{datoSerieActual.getNumserie().toString()}));
				}

			}
		}
		return result;
	}
	/** Valida el regimen de procedencia
	 * @param declaracion
	 * @return List de errores
	 */
	public List<Map<String, String>> validaRegimenProcedencia(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		boolean declaracionTieneDatoSeries=!CollectionUtils.isEmpty(dua.getListSeries());
		if(declaracionTieneDatoSeries){
			for (DatoSerie datoSerieActual : dua.getListSeries()) {
				if (datoSerieActual.getListRegPrecedencia()!=null){
					for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
						if (!datoRegPreActual.getCodregipre().equals("83") && !datoRegPreActual.getCodregipre().equals("20")){
							// Instelelog('5036',mArchivo||':REGI_PROCE EN DEPOSITO '||mREGI_PROCE)
							result.add(	catalogoAyudaService.getError("5036"));
						}
					}
				}
			}
		}

		return result;
	}
	/** Valida la el codigo de feria
	 * @param declaracion
	 * @return List de errores
	 */	
	public List<Map<String, String>> validarFeriaRegimen(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		CabDeclaraDAO cabDeclaraDao = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDef");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		// Tiene que ser del regimen de precedencia 70
		//if (!dua.getCodferia().equals("2") && declaracion.getDua().getCodregimen().equals("70") ){
		/*if (!dua.getCodferia().equals("2") && declaracion.getNumdeclRef().getCodregimen().equals("70") ){
			//Instelelog( '0510',mArchivo||':CADUREGPRE,FANOREGPRE, NDCLREGPRE, DECLARACION ENVIADA'||mCADUREGPRE||' '||mFANOREGPRE||' '||mNDCLREGPRE);
			result.add(	catalogoHelper.getErrorMap("0510",":CADUREGPRE,FANOREGPRE, NDCLREGPRE, DECLARACION ENVIADA "));
		}
		 */
		// Se cambio por analisis de Elsa 16/12/2009
		for (DatoSerie datoSerieActual : dua.getListSeries()) {
			if (datoSerieActual.getListRegPrecedencia()!=null){
				for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
					Map params = new HashMap();
					params.put("codigoAduana",datoRegPreActual.getCodaduapre());
					params.put("annoPresentacion",datoRegPreActual.getAnndeclpre());// catalogo de ferias
					params.put("codigoRegimen",datoRegPreActual.getCodregipre());
					Integer numDeclPre=SunatNumberUtils.toInteger(datoRegPreActual.getNumdeclpre());
					params.put("numeroDeclaracion",numDeclPre);
					DUA duaPrecedente=new DUA();
					duaPrecedente=cabDeclaraDao.findDUAByKeyMap(params);
					if (duaPrecedente!=null){
						if (!duaPrecedente.getCodferia().equals("2") && datoRegPreActual.getCodregipre().equals("20") ){
							//Instelelog( '0510',mArchivo||':CADUREGPRE,FANOREGPRE, NDCLREGPRE, DECLARACION ENVIADA'||mCADUREGPRE||' '||mFANOREGPRE||' '||mNDCLREGPRE);
							result.add(	catalogoAyudaService.getError("0510"));
						}
					}
				}
			}
		}
		return result;
	}
	/** Valida la via de transporte del regimen de deposito
	 * @param declaracion
	 * @return List de errores
	 */	
	public List<Map<String, String>> validarViaTransporteDeposito(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		DatoManifiesto datoManif= dua.getManifiesto();
		if(datoManif!=null){
			if (datoManif.getCodmodtransp().equals("5") && declaracion.getDua().getCodregimen().equals("70")){
				//instelelog ('0013', 'VIA_TRANSP - TRANSMITIO ' + xvia_transp)
				result.add(	catalogoAyudaService.getError("0013"));
			}
		}

		return result;
	}
	/** Valida el codi_depo
	 * @param declaracion
	 * @return List de errores
	 */	
	public List<Map<String, String>> validarDeposito(Declaracion declaracion){
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		Map<String,Object> mapOpecomext=new HashMap<String,Object>();
		List<Map<String,Object>> listMapOpeComext=new ArrayList<Map<String,Object>>();
		FechaBean fechaActual = new FechaBean();

		DUA dua = declaracion.getDua();
		mapOpecomext.put("codTipOpera", "32"); // Tipo de Depositos
		mapOpecomext.put("numRUC", dua.getNumrucdeposito());
		mapOpecomext.put("ayudaID", "Opecomext");
		listMapOpeComext=ayudaService.buscar(mapOpecomext);

		if (listMapOpeComext.size()==0 || listMapOpeComext==null ){// no existe en la BD
			//Instelelog ('0027', 'CODI_DEPO - CODIGO NO CORRESPONDE A DEPOSITO '+ xcodi_depo)
			result.add(	getDUAError("0027","CODI_DEPO - CODIGO NO CORRESPONDE A DEPOSITO ".concat(dua.getNumrucdeposito()) ));
		}
		listMapOpeComext=null;
		mapOpecomext.put("fechaVigencia", fechaActual.getCalendar().getTime());
		listMapOpeComext=ayudaService.buscar(mapOpecomext);
		if (listMapOpeComext.size()==0 || listMapOpeComext==null ){// no existe en la BD
			//instelelog ('0027','CODI_DEPO - DEPOSITO NO ESTA HABILITADO'|| xcodi_depo);
			result.add(	getDUAError("0027","CODI_DEPO - DEPOSITO NO ESTA HABILITADO ".concat(dua.getNumrucdeposito())));
		}

		return result;
	}
	/** Valida el plazo presentado
	 * @param declaracion
	 * @return List de errores
	 */	
	public List<Map<String, String>> validarPlazoPresentado(Declaracion declaracion){

		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		if (dua.getNumplazosol()!=null){
			if (dua.getNumplazosol()<=0){
				//instelelog ('0300', 'PLAZO_NUM - NO TRASMITIO EL PLAZO SOLICITADO');
				result.add(	getDUAError("0300","PLAZO_NUM - NO TRASMITIO EL PLAZO SOLICITADO"));
			}
			if (!SunatStringUtils.include(dua.getCodtipoplazo(), new String[]{"1","2"})){
				//  instelelog ('0301','PLAZO_TIPO - TIPO DE PLAZO PUEDE SER : 1, 2  TRANSMITIO : '|| xplazo_tipo)
				result.add(	getDUAError("0301","PLAZO_TIPO - TIPO DE PLAZO PUEDE SER : 1, 2  TRANSMITIO : ".concat(dua.getCodtipoplazo())));
			}

			if ( (dua.getCodtipoplazo().equals("1") && dua.getNumplazosol()>12) || (dua.getCodtipoplazo().equals("2") && dua.getNumplazosol()>360)){
				//instelelog('0300','PLAZO_NUM, PLAZO_TIPO - PLAZO SOLICITADO NO GUARDA RELACION CON EL TIPO DE PLAZO  TRANSMITIO : '|| TO_CHAR (xplazo_num, '999')|| '-'|| xplazo_tipo)
				result.add(	getDUAError("0300","PLAZO_NUM, PLAZO_TIPO - PLAZO SOLICITADO NO GUARDA RELACION CON EL TIPO DE PLAZO  TRANSMITIO : ".concat(dua.getNumplazosol().toString().concat(" - ").concat(dua.getCodtipoplazo()))));
			}
		}else{
			result.add(	getDUAError("0300","PLAZO_NUM - NO TRASMITIO EL PLAZO SOLICITADO"));
		}

		return result;
	}
	/** Valida el monto total.
	 * @param declaracion
	 * @return List de errores
	 */	
	public List<Map<String, String>> validarMontoTotales(Declaracion declaracion){

		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		boolean verificarTipoTrat=false;
		BigDecimal resultadoFinal=new BigDecimal(0);

		if ( SunatNumberUtils.isLessOrEqualsThanZero(dua.getMtotflecomex()) ){
			//instelelog ('0034', 'TFLE_COMEX - ' + A_CADENA (xtfle_comex, '999,999,999.999'))
			result.add(	getDUAError("0034","TFLE_COMEX - ".concat(dua.getMtotflecomex().toString())));
		}
		//-	Si VAL_ABSOLUTO (xval_aduana  - (xtajustes + xtfob_clvta + xtfle_comex + xtseg_otros)) > 0.002 
		BigDecimal resultado=new BigDecimal(0);
		BigDecimal mtotajustes=dua.getMtotajustes()==null?BigDecimal.ZERO:dua.getMtotajustes();
		BigDecimal mtotfobclvta=dua.getMtotfobclvta()==null?BigDecimal.ZERO:dua.getMtotfobclvta();
		BigDecimal mtotsegotros=dua.getMtotsegotros()==null?BigDecimal.ZERO:dua.getMtotsegotros();
		BigDecimal mtotflecomex=dua.getMtotflecomex()==null?BigDecimal.ZERO:dua.getMtotflecomex();
		resultado=resultado.add(mtotajustes.add(mtotfobclvta).add(mtotflecomex).add(mtotsegotros));
		resultado=dua.getMtovaladuana().subtract(resultado);


		if (Math.abs(resultadoFinal.doubleValue()) > 0.02){
			//instelelog ('5003', 'VAL_ADUANA - '+ A_CADENA (xval_aduana)+ '-CALCULADO='+ A_CADENA (xtajustes+xtfob_clvta+ xtfle_comex+ xtseg_otros))
			result.add(	getDUAError("5003", "VAL_ADUANA - ".concat(dua.getMtovaladuana().toString()).concat("-CALCULADO=").concat(resultado.toString())));
		}
		verificarTipoTrat=esDataCatalogo("14",dua.getCodtipotratamiento());

		if (!verificarTipoTrat){
			result.add(	getDUAError("0008", "TIPO TRATAMIENTO NO EXISTE"));
		}

		return result;
	}	
	/** Valida el almacen aduanero
	 * @param declaracion
	 * @return List de errores
	 */	
	public List<Map<String, String>> validarAlmacenAduanero(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		Map<String,Object> mapOpecomext=new HashMap<String,Object>();
		DUA dua = declaracion.getDua();
		List<Map<String,Object>> listMapOpeComext=new ArrayList<Map<String,Object>>();
		FechaBean fechaActual = new FechaBean();


		mapOpecomext.put("codTipOpera", "31"); // Tipo de terminal de almacenamiento
		mapOpecomext.put("numRUC", dua.getNumruclugarecep());// Tipo de terminal de almacenamiento
		mapOpecomext.put("fechaVigencia", fechaActual.getCalendar().getTime());
		mapOpecomext.put("ayudaID", "Opecomext");

		listMapOpeComext=ayudaService.buscar(mapOpecomext);
		if (listMapOpeComext.size()==0 || listMapOpeComext==null){
			//fnverierror ('==', xcubialm, '0026', 'ubialma', 'CUBIALM')
			result.add(	catalogoAyudaService.getError("0026"));
		}
		return result;
	}
	
	/** Valida la vigencia de los documentos
	 * @param declaracion
	 * @return List de errores
	 */	
	public List<Map<String, String>> validarVigenciaDocumento(Declaracion declaracion){
		DdpDAOService ddpDAOService = (DdpDAOService)fabricaDeServicios.getService("Ayuda.ddpService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		Map params=new HashMap();
		DUA dua = declaracion.getDua();

		if (dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().equals("4")){
			//Verifica el estado del RUC 

			//			params=ddpDAO.findByPK(dua.getDeclarante().getNumeroDocumentoIdentidad());
			params=ddpDAOService.findByPK(dua.getDeclarante().getNumeroDocumentoIdentidad());
			if (params!=null){
				if (!params.get("ddp_estado").toString().equals("00")){// estado activo de RUC
					//instelelog ('0716',  'TIPO_DOCUM-NUME_DOCUM-VIGENCIA '+ xtipo_docum+ '-' + xnume_docum+ '-'+ A_CADENA (vffin))
					result.add(	getDUAError("0716", "TIPO_DOCUM-NUME_DOCUM-VIGENCIA 4- ".concat(dua.getDeclarante().getNumeroDocumentoIdentidad())));
				}


			}
		}

		return result;
	}
	/** Valida el plazo maximo de deposito
	 * @param declaracion
	 * @return List de errores
	 */	
	public List<Map<String, String>> validarPlazoMaximoDeposito(Declaracion declaracion){
		ValModalidadService valModalidadService = (ValModalidadService)fabricaDeServicios.getService("ingreso.ValModalidad");
		CabDeclaraDAO cabDeclaraDao = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDef");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		FeriasDAOService feriasDAOService = (FeriasDAOService)fabricaDeServicios.getService("Ayuda.feriasService");
		ProrrogaService prorrogaService = (ProrrogaService)fabricaDeServicios.getService("manifiesto.prorrogaService");
		
		
		
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		DUA dua = declaracion.getDua();
		DatoManifiesto datoManif=dua.getManifiesto();

		Date fechaActual=new Date();

		boolean  tieneFeriaPlazo= false;
		boolean  tieneSolProrroga= false;
		boolean  noEstadentro= true;
		if(datoManif!=null && ! SunatStringUtils.isEmptyTrim(datoManif.getNummanif())){
			Manifiesto manifiesto = ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio(
					datoManif.getCodtipomanif(), 
					datoManif.getCodmodtransp(), 
					datoManif.getCodaduamanif(), 
					SunatNumberUtils.toInteger(datoManif.getAnnmanif().substring(0,4)), 
					datoManif.getNummanif(), true); //cambio esantana 

			if(dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)){
				if (manifiesto != null) {

					//PAS20165E220200093 RSERRANO se modifica para que envie la fecha de numeraci�n de la dua en este caso en la numeraci�n
					boolean correspondeModalidadDiferida = valModalidadService.correspondeModalidadDiferida(dua.getFecdeclaracion() == null? fechaActual:dua.getFecdeclaracion()  , manifiesto.getFechaTerminoDeDescarga());
					if (!correspondeModalidadDiferida) {
						DataCatalogo catPlazoModalidadDiferida = catalogoAyudaService.getDataCatalogo(
								ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,ConstantesDataCatalogo.COD_PLAZO_VALIDACION_NUEVA_LGA );
						Date fecVigenciaLGA = catPlazoModalidadDiferida.getFecInidatcat();
						List<Map<String, Object>> lisProrroga =  null;
						if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecVigenciaLGA, SunatDateUtils.COMPARA_SOLO_FECHA)){
							if(!CollectionUtils.isEmpty(declaracion.getDua().getListDocTransporte())){
								for(DatoDocTransporte docTrans:declaracion.getDua().getListDocTransporte()){
									String numDetalle = "";

									//PAS20165E220200093 RSERRANO
									if ( SunatNumberUtils.isGreaterThanZero( docTrans.getNumdetalle())  ) {
										numDetalle = docTrans.getNumdetalle().toString();
									} 
									Map<String,Object> datos=new HashMap<String,Object>();
									datos.put("indDel", Constantes.IND_REGISTRO_ACTIVO);
									datos.put("codEstSol", Constantes.CODIGO_ESTADO_SOLICITUD_PROSUS);
									if(  SunatNumberUtils.isGreaterThanZero(manifiesto.getNumeroCorrelativo()) )
									{
										datos.put("numCorrManif", manifiesto.getNumeroCorrelativo());
									} else  {
										datos.put("numManif", manifiesto.getNumeroManifiesto().trim() );
										datos.put("annManif", manifiesto.getAnioManifiesto() );
										datos.put("codViaManif", manifiesto.getViaTransporte().getCodDatacat() );
										datos.put("codAduanaManif", manifiesto.getAduana().getCodDatacat() );
									}
									datos.put("numDocTransporte", docTrans.getNumdoctransporte()  );
									List<String> listTipSol = new ArrayList<String>();
									listTipSol.add("30");//30, 31 o ambas
									listTipSol.add("31");//30, 31 o ambas 
									datos.put("codTipSol", listTipSol);

									lisProrroga = prorrogaService.getLstMapProSusManif(datos);
									Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
									SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
									String codTipSol = ""; 
									if(!CollectionUtils.isEmpty(lisProrroga)){
										tieneSolProrroga= true;
										for(Map<String, Object> mapaProrroga:lisProrroga){
											if(!CollectionUtils.isEmpty(mapaProrroga)){
												numDetalle = mapaProrroga.get("numDetalle").toString();
												codTipSol = mapaProrroga.get("codTipSol").toString();
												if ( codTipSol.trim().equals("31") ) {
													Date fIni = SunatDateUtils.getDate(mapaProrroga.get("inicioSuspension").toString(), "yyyy-MM-dd"); // originalFormat.parse(mapaProrroga.get("inicioSuspension").toString());
													Date fFin = SunatDateUtils.getDate(mapaProrroga.get("finSuspension").toString(), "yyyy-MM-dd"); 
													if (SunatDateUtils.esFecha1MayorQueFecha2(fIni,new Date(),  SunatDateUtils.COMPARA_SOLO_FECHA) ||
															SunatDateUtils.esFecha1MayorQueFecha2(new Date(),  fFin ,SunatDateUtils.COMPARA_SOLO_FECHA)	){
														noEstadentro= false;
													}
												}
												if ( codTipSol.trim().equals("30") ) {
													if ( !SunatStringUtils.isEmptyTrim( numDetalle )  ) {
														Map<String,Object> datosManif=new HashMap<String,Object>();
														if(  SunatNumberUtils.isGreaterThanZero(manifiesto.getNumeroCorrelativo()) )
														{
															datosManif.put("numDetalleSDA",numDetalle );	
														} else  {
															datosManif.put("numDetalleSIGAD", numDetalle  );
														}
														datosManif.put("numeroManifiesto", manifiesto.getNumeroManifiesto().trim());
														datosManif.put("anioManifiesto", manifiesto.getAnioManifiesto() );
														datosManif.put("codViaManifiesto", manifiesto.getViaTransporte().getCodDatacat() );
														datosManif.put("aduanaManifiesto", manifiesto.getAduana().getCodDatacat() );
														datosManif.put("tipoInterfaz", "1");
														Map<String, Object> temp = prorrogaService.fechaMenorAFechaAbandoLegal(new Date(),datosManif,new HashMap<String,Object>());
														if ( !(Boolean)temp.get("band")){
															noEstadentro= false;
														}
													}
												}

											}
										}
									}

								}
							}

							//PAS20165E220200093 RSERRANO
							// Verifica si todos los BL tienen solicitud de prorroga y que esten dentro de plazo 
							if (tieneSolProrroga && !noEstadentro) {
								return result;
							}
							catPlazoModalidadDiferida = catalogoAyudaService.getDataCatalogo(
									ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,"0019");
							Integer diasPlazo = SunatNumberUtils.toInteger(catPlazoModalidadDiferida.getDesCorta());
							for (DatoSerie datoSerieActual : dua.getListSeries()) {
								if (datoSerieActual.getListRegPrecedencia()!=null){
									for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
										Map parametros = new HashMap();
										parametros.put("codigoAduana",datoRegPreActual.getCodaduapre());
										parametros.put("annoPresentacion",datoRegPreActual.getAnndeclpre().substring(0, 4));// catalogo de ferias
										parametros.put("codigoRegimen",datoRegPreActual.getCodregipre());
										Integer numDeclPre=SunatNumberUtils.toInteger(datoRegPreActual.getNumdeclpre());
										parametros.put("numeroDeclaracion",numDeclPre);
										DUA duaPrecedente=new DUA();
										duaPrecedente=cabDeclaraDao.findDUAByMap(parametros);
										if (duaPrecedente!=null){
											if ( datoRegPreActual.getCodregipre().concat("02").equals(duaPrecedente.getCodtipoperacion()) && 
													datoRegPreActual.getCodregipre().equals( ConstantesDataCatalogo.REG_ADM_TEMP_RME ) ){
												parametros.put("CODIGO",duaPrecedente.getCodferia());	    
												List list= feriasDAOService.findByParams(parametros);
												if(list!=null && list.size()>0){
													Map dataFeria =(Map)list.get(0);
													Integer fechFinFeria=Integer.valueOf(dataFeria.get("FFIN").toString());
													if (fechFinFeria > 19950000) {
														Long diasEntre = SunatDateUtils.getDiferenciaDiasCalendarios(fechaActual , SunatDateUtils.getDateFromInteger(fechFinFeria) );
														if (  SunatNumberUtils.isGreaterThanParam(  diasEntre, diasPlazo)    ){
															tieneFeriaPlazo= false;
														} else {
															tieneFeriaPlazo= true;
														}
													}
												} 
											}
										}
									}
								}
							}
							if (tieneFeriaPlazo) 
								return result;
						}
						result.add(	catalogoAyudaService.getError("0302"));
					} 
				} else {
					result.add(	catalogoAyudaService.getError("09017"));
				}
			}
		}
		return result;
	}


	/**
	 * Metodo interno para la busqueda de catalogos
	 * @param codCatalago
	 * @param codDataCatalogo
	 * @return boolean
	 */
	@SuppressWarnings("unchecked")
	private boolean esDataCatalogo(String codCatalago,String codDataCatalogo){
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		Map params = new HashMap();
		params.put("type","Ayuda");
		params.put("catalogoID",codCatalago);
		params.put("codElemento",codDataCatalogo);
		params.put("fechaVigencia",new Date());


		//List list= dataCatalogoDao.findByMap(params);


		List list = null;
		params.put("ayudaID", "DataCatalogo");
		list= (List)ayudaService.buscar(params);



		if(list!=null && list.size()>0)
			return true;
		else return false;
	}

	/*
	public void setCabDeclaraDao(CabDeclaraDAO cabDeclaraDao) {
		this.cabDeclaraDao = cabDeclaraDao;
	}
	//	public void setMrestriDao(MrestriDAO mrestriDao) {
	//		this.mrestriDao = mrestriDao;
	//	}

	public void setNandTasaDao(NandTasaDAO nandTasaDao) {
		this.nandTasaDao = nandTasaDao;
	}
	//	public void setOpecomextDao(OpecomextDAO opecomextDao) {
	//		this.opecomextDao = opecomextDao;
	//	}
	//	public void setDdpDAO(DdpDAO ddpDAO) {
	//		this.ddpDAO = ddpDAO;
	//	}
	public void setManifiestoDao(CabManifiestoDAO manifiestoDao) {
		this.manifiestoDao = manifiestoDao;
	} 
	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}
	public AyudaService getAyudaService() {
		return ayudaService;
	}
	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}
	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}
	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}
	public MrestriDAOService getMrestriDAOService() {
		return mrestriDAOService;
	}
	public void setMrestriDAOService(MrestriDAOService mrestriDAOService) {
		this.mrestriDAOService = mrestriDAOService;
	}
	
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	public FeriasDAOService getFeriasDAOService() {
		return feriasDAOService;
	}
	public void setFeriasDAOService(FeriasDAOService feriasDAOService) {
		this.feriasDAOService = feriasDAOService;
	}

	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}
	
	public void setProrrogaService(ProrrogaService prorrogaService) {
		this.prorrogaService = prorrogaService;
	}*/
}
