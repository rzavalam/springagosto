package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida;

import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.AGENCIA_ADUANA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ADUANA_AEREA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ADUANA_MARITIMA_CALLAO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_CATALOG_TIP_DOC_SOPORTE;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_DOC_CERTIFICADO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_DOC_EXPEDIENTE_TRAMITE;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_DOC_SOPORTE_CONSTANCIA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ENTI_DIGESA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ENTI_DIQPF;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ENTI_MITINCI;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ENTI_OTO_PERU_PRODUCE;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ENTI_OTRAS_DEPEND_PRODUCE;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ENTI_PESQUERIA_PRODUCE;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_ENTI_SENASA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_JURID_NACIONAL;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_TRANSAC_RECTIFICACION;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.COD_TRANSAC_REGULARIZACION;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.DESPACHO_EXCEPCIONAL;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.EMPRESA_MENSAJERIA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.MATERIAL_USO_AERONAUTICO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.MODULO_TELEDESPACHO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_ADMISION_TEMPORAL;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_COURIER;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_EXPORTACION_TEMPORAL;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_EXPO_DEFINITIVA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_EXPO_DEFINITIVA_DUE;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_EXPO_DEFINITIVA_OE;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_EXPO_SIMPLIFICADA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_IMPORTACION_TEMPORAL;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_IMPO_DEFINITIVA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_IMPO_SIMPLIFICADA;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_REEMBARQUE;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_REEXPORTACION;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_REIMPO_MISMO_ESTADO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGIMEN_TRANSBORDO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REGI_DEPOSITO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REG_TRANSITO;
import static pe.gob.sunat.despaduanero2.declaracion.util.Constants.REIMPO_MISMO_ESTADO;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry; //P46
import java.util.Set;

import org.apache.commons.lang.math.NumberUtils;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.MRestri;
import pe.gob.sunat.despaduanero.catalogo.tg.model.TablNew;
import pe.gob.sunat.despaduanero.catalogo.tg.service.MrestriDAOService;
import pe.gob.sunat.despaduanero.catalogo.tg.service.TablnewDAOService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.CatalogoHelperImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMercancia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Dimerpro;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabMrDocAutorizDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetCtrlCamDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DimerproDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.exception.ServiceException; //P46
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
//import pe.gob.sunat.despaduanero2.util.ResponseListManager;

/**
 * @author hosorio
 *
 */
public class MercanciaRestringidaServiceImpl extends ValDuaAbstract implements MercanciaRestringidaService {

	//private DetCtrlCamDAO detCtrlCamDao;
	//	private MrestriDAO MRestriDao;
	//	private TablNewDAO tablNewDao;
	//private CabMrDocAutorizDAO cabMrDocAutorizDao;
	//private DocAutAsociadoDAO docAutAsocDao;
	//private CatalogoValidaService catalogoService;
	//private CatalogoHelperImpl catalogoHelper;
	//private DimerproDAO dimerproDao;

	//private MrestriDAOService mrestriDAOService;
	//private TablnewDAOService tablnewDAOService;


	//	private static MercanciaRestringidaServiceImpl instance;


	//protected final Log log = LogFactory.getLog(getClass());

	//private FabricaDeServicios fabricaDeServicios;
	//	private MercanciaRestringidaServiceImpl() {
	//	}
	//	
	//	public static MercanciaRestringidaServiceImpl getInstance() {
	//		if(instance == null )
	//		{
	//			instance = new MercanciaRestringidaServiceImpl();
	//		}
	//		
	//		return instance;
	//	}

	/**
	 Valida la mercancia restringida para todas las series
	 * @param  declaracion : Objeto que representa los datos de la declaracion
	 * @return Map<String, ?> Mapa de Errores encontrado
	 */
	@ServicioAnnot(tipo="V",codServicio=3100, descServicio="valida mercancias restringidas")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","codTransaccion"})
	@OrquestaDespaAnnot(codServInstancia=3100,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> validarMercanciaRestringida(
			Declaracion declaracion, String codTransaccion
			)
	{
		Elementos<DatoSerie>  listSeries =declaracion.getDua().getListSeries();
		List<Map<String,String>> lsterror=new ArrayList<Map<String,String>>();
		if(!CollectionUtils.isEmpty(listSeries) ){
			for(DatoSerie serie:listSeries){
				/*Inicio ECC 17022011*/
				//lsterror =  validarMercanciaRestringida(declaracion, serie,codTransaccion);
				lsterror.addAll(validarMercanciaRestringida(declaracion, serie,codTransaccion));
				/*Fin ECC 17022011*/

			}

		}

		return lsterror;
	}



	/**
	 Valida la mercancia restringida de la serie
	 * @param  declaracion : Objeto que representa los datos de la declaracion
	 * @param  serie : Objeto que representa a una serie
	 * @return Map<String, ?> Mapa de Errores encontrado
	 */
	public List<Map<String, String>> validarMercanciaRestringida(
			Declaracion declaracion,
			DatoSerie serie, String codTransaccion)
	{
		MrestriDAOService mrestriDAOService = (MrestriDAOService)fabricaDeServicios.getService("Ayuda.mrestriService");
		if(log.isDebugEnabled())log.debug("validarMercanciaRestringida");
		//ResponseListManager responseListManager= new ResponseListManager();
		List<Map<String,String>> listErrores=new ArrayList<Map<String,String>>();		          

		// codigo del anexo , requerido para la validacion
		String codRegistro= null;
		//String codEntidadRestri= null;

		String[] listaRegimenImpo=new String[]{
				REGIMEN_IMPO_SIMPLIFICADA,REIMPO_MISMO_ESTADO,REGIMEN_REIMPO_MISMO_ESTADO};

		String[] listaRegimenExpo=new String[]{
				REGIMEN_EXPO_DEFINITIVA_OE,REGIMEN_EXPO_SIMPLIFICADA};


		String vRegimenSegunRegimen =  declaracion.getDua().getCodregimen();
		/* Esta variable [vRegimenSegunRegimen] se usa porque las entidades autorizantes 
		 * referencian movimiento de la mercancia, es decir, ingresa (importacion) o 
		 * sale (exportacion) de manera general, no toma en cuenta los diversos regimenes aduaneros, por ej. 
		 * importacion temporal admision temporal, etc  */	    	
		if(Arrays.asList(listaRegimenImpo).contains(vRegimenSegunRegimen)){
			vRegimenSegunRegimen=REGIMEN_IMPO_DEFINITIVA;
		}


		if(Arrays.asList(listaRegimenExpo).contains(vRegimenSegunRegimen)){
			vRegimenSegunRegimen=REGIMEN_EXPO_DEFINITIVA;
		}    	   


		Map<String, Object>   params=new HashMap<String, Object>();
		params.put("cnan", serie.getNumpartnandi());
		params.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
		params.put("codiregi", vRegimenSegunRegimen);

		//		List<MRestri> lstMrestri = MercanciaRestringidaServiceImpl.getInstance().getMRestriDao().listMercRestringida(params);
		List<MRestri> lstMrestri = mrestriDAOService.listMercRestringida(params);

		if(!CollectionUtils.isEmpty(lstMrestri)){
			codRegistro=lstMrestri.get(0).getRegistro();
			//codEntidadRestri=lstMrestri.get(0).getEntidad();
		}


		if(!StringUtils.hasText(codRegistro)) {
			// Si no hay codigo de registro no se puede hacer nada
			//   break;
			return listErrores;
		}

		Map<String,Map<String,Object>> parametros = new HashMap<String, Map<String, Object>>();
		Map<String,Object> mapVariablesControl= new HashMap<String, Object>();
		Map<String,Object> mapParametroIni= new HashMap<String, Object>();
		Map<String,Object> mapErrores= new HashMap<String, Object>();
		Map<String,Object> mapDatosBD= new HashMap<String, Object>();
		Map<String,Object> mapWarnings= new HashMap<String, Object>();
		Map<String,Object> mapMensajes= new HashMap<String, Object>();
		parametros.put("mapParametroIni", mapParametroIni);
		parametros.put("mapVariablesControl", mapVariablesControl);
		parametros.put("mapDatosBD", mapDatosBD);
		parametros.put("mapWarnings", mapWarnings);
		parametros.put("mapMensajes", mapMensajes);
		parametros.put("mapErrores", mapErrores);


		// paso1
		inicializarVariablesControl(declaracion,serie,codRegistro,parametros);
		// si no hay fin de validacion se continua
		if(!((Boolean)mapVariablesControl.get("FinValidacion")).booleanValue() ){

			// paso2
			boolean bRestringida=validarSubPartidaRestringida(declaracion,serie,codRegistro,codTransaccion,parametros);

			// si la partida es restringida , secontinua
			if(bRestringida){

				// paso 3
				// valida si existo doc de autorizacion para la partida (serie)
				validarExisteDocAutorizacionPartida(declaracion,serie,codRegistro,parametros);

				// paso 4
				listErrores=validarCoherenciaVariableControl(declaracion,serie,codRegistro,parametros);

				if(!CollectionUtils.isEmpty(listErrores))
					return listErrores;

				// si existe coherencia en las variables de control
				if(((Boolean)mapVariablesControl.get("existeCoherenciaVarControl")).booleanValue() ){

					// paso 5
					listErrores=validarCoherenciaDocAutorizacion(declaracion,serie,codRegistro,parametros);
					if(!CollectionUtils.isEmpty(listErrores))
						return listErrores;		          			

					// si no hay incoherencia y existe permiso senasa , se continua
					if(! ((Boolean)mapVariablesControl.get("incoherenciadatos"))
							&& 	(Boolean)mapVariablesControl.get("permisoSenasaEncontrado")
							){

						// paso6
						// valida si se requiere verificar la existencia del Doc. Aut en la bd
						listErrores=validarExistenciaDocAutoBD(declaracion,serie,codRegistro,parametros);
						if(!CollectionUtils.isEmpty(listErrores))
							return listErrores;		          			


						// si se requiere validar en BD se continua
						if(((Boolean)mapVariablesControl.get("verificarDocAutorizacionBD"))){


							// PASO 7
							// busca el Doc. Autorizacion en la BD 
							listErrores=buscarDocAutorBD(declaracion,serie,codRegistro,parametros);
							if(!CollectionUtils.isEmpty(listErrores))
								return listErrores;		          			


							// si existe , continua
							if(((Boolean)mapVariablesControl.get("existeDocAutorBD"))){

								// paso 8
								// compara el doc. de Aut. declarado con el doc. de base de datos;
								listErrores=comparacionDocAutorBD(declaracion,serie,codRegistro,codTransaccion,parametros);
								if(!CollectionUtils.isEmpty(listErrores))
									return listErrores;

								// si son iguales continua
								if(((Boolean)mapVariablesControl.get("iguales"))){

									// paso 9
									/*9.	Verificar si es necesario validar que el documento de autorizaci�n encontrado en la BD de Sunat ya ha sido utilizado en otras numeraciones de DUA*/
									listErrores=verificarUsoDocAutorNumeracionPrevia(declaracion,serie,codRegistro,parametros);
									if(!CollectionUtils.isEmpty(listErrores))
										return listErrores;		                                  		 

									if(mapVariablesControl.get("verificarUsoPrevio")!=null){

										boolean verificarPeso=false;

										// Si la condici�n indica que es necesario verificar uso previo pasar al punto 10
										if(((Boolean)mapVariablesControl.get("verificarUsoPrevio"))){

											// paso 10
											// 10.	Validar si el documento de autorizaci�n encontrado en la BD de 
											//SUnat ya sido utilizado en otras numeraciones de DUA
											listErrores=usoCorrectoDocAutorNumeracionPrevia(declaracion,serie,codRegistro,parametros);
											if(!CollectionUtils.isEmpty(listErrores))
												return listErrores;

											if(mapVariablesControl.get("usoCorrecto")!=null && ((Boolean)mapVariablesControl.get("usoCorrecto"))){
												verificarPeso=true;
											}
										}
										//Si la condici�n indica que No es necesario 
										//verificar uso previo pasar al punto 11 : verfificar peso
										else{
											verificarPeso=true;
										}

										if(verificarPeso){

											// paso 11
											// 11.	Verificar si es necesario controlar pesos por usar en [AduaDet1] y saldo de pesos del documento de autorizaci�n 
											listErrores=verificarUsoCorrectoPesosAutorizados(declaracion,serie,codRegistro,codTransaccion,parametros);
											if(!CollectionUtils.isEmpty(listErrores)){
												return listErrores;
											}


											// si requiere verificar Pesos 
											if(mapVariablesControl.get("verificarUsoCorrectoPesos")!=null && ((Boolean)mapVariablesControl.get("usoCorrecto"))){
												// paso 12
												// 12.	Validar que el peso a usarse en la numeraci�n 
												//sea menor al Saldo de peso en el documento de autorizaci�n. 

												listErrores= usoCorrectoPesosAutorizado(declaracion,serie,codRegistro,codTransaccion,parametros);     					   
											}
										}
									}
								}

							}
						}
					}
				}

			}

		}

		return listErrores;

		//
	}


	private  void inicializarVariablesControl(
			Declaracion declaracion,
			DatoSerie serie,
			String codRegistro,
			Map<String,Map<String,Object>> parametros
			){

		DUA dua=declaracion.getDua();
		String codtipooper=declaracion.getDua().getCodtipooper();
		DatoManifiesto datoManifiesto=dua.getManifiesto();
		String codregimen=dua.getCodregimen();
		Boolean FinValidacion=false;
		Boolean vIND_RequiereAutorizacion=null;
		Boolean vIND_TieneAutorizacion=null;
		Boolean vIND_Exonerado=null;

		Map<String,Object> mapParametroIni=parametros.get("mapParametroIni");
		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;

		if(SunatStringUtils.isStringInList(codRegistro, "0501,0505,0502,0503,0505,0504,0301,0401,0402," +
				"1701,1702,2701,2702,2703,0302,0403,0404,0405,1101,1102,1801,1802"))
		{

			String[] listaRegimen1=new String[]{REGIMEN_IMPO_SIMPLIFICADA
					,REGIMEN_COURIER};

			String[] listaRegimen2=new String[]{REGIMEN_IMPORTACION_TEMPORAL,
					REGIMEN_ADMISION_TEMPORAL,REG_TRANSITO
					,REGIMEN_REEMBARQUE};

			DatoMercancia mercancia= serie.getMercancia();
			String codexoneracion=null;
			if(mercancia!=null)
				codexoneracion=mercancia.getCodexoneracion();
			String viaTransporte=null;
			if(datoManifiesto!=null)
				viaTransporte=datoManifiesto.getCodmodtransp();
			String  vCOD_RegimenAduaneroHdr=null;


			if(codregimen.equals(REIMPO_MISMO_ESTADO) 	
					|| codregimen.equals(REGIMEN_REIMPO_MISMO_ESTADO)){

				FinValidacion=true;
				//RETORNA �No se realiza ninguna validaci�n de restringida
			}


			if(!FinValidacion){

				vIND_RequiereAutorizacion=false;
				vIND_TieneAutorizacion=false;
				vIND_Exonerado=false;


				/* [AduaDet1].[TPROD] = 98: Valor que indica exoneracion de presentar documento de autorizacion */
				/* [AduaDet1].[TPROD] = 80: Solo es necesario presentar un informe, no un documento de autorizacion y por eso se considera como un Tipo de Exoneracion, durante la revision de la regla, esta pendiente confirmar si es un �informe� entregado por Senasa o es un informe de verificacion fisica */
				if(SunatStringUtils.isStringInList(codexoneracion, "80,98")){
					vIND_Exonerado=true;

					// si esta exonerado se termina todo

					FinValidacion=true;
				}

				/* Cambio de Alias u Origen de Datos para Regimen de �Importacion Simplificada� 
				 * o �Courier�, este cambio es porque anteriormente se utilizaba dos formatos 
				 * equivalentes a los archivos [AduaHdr1] y [AduaDet1] y eran: [ImpHdr01] y [ImpDet01] respectivamente. Dichos destinos aduaneros  dependen de los valores indicados en los atributos �Via de transporte� (del archivo [AduaHdr1]) y �Tipo de Operador� (del archivo [ImpCtr01]) */
				/* De estos cambios de estructuras, la estructura del [ImpDet01] se separo en dos estructuras: [AduaDet1] y [DuaDocAs] */

				vCOD_RegimenAduaneroHdr=codregimen;

				if("4".equals(viaTransporte) && codtipooper.equals(AGENCIA_ADUANA))	 
				{
					vCOD_RegimenAduaneroHdr=REGIMEN_IMPO_SIMPLIFICADA; 
				}


				if(  SunatStringUtils.isStringInList(viaTransporte, "0,5")  
						&&	(  codtipooper.equals(AGENCIA_ADUANA) || codtipooper.equals(EMPRESA_MENSAJERIA) ) 
						){
					vCOD_RegimenAduaneroHdr=REGIMEN_COURIER; 
				}


				/* Segun el regimen aduanero los parametros de ingreso al procedimiento de Mercancia Restringida varia */
				/* A continuacion se detalla como por cada regimen aduanero la forma de invocar este procedimiento */


				// SI [vCOD_RegimenAduaneroHdr] esta en la lista (�ImportacionSimplificada�, �Courier� ) 
				if(Arrays.binarySearch(listaRegimen1,vCOD_RegimenAduaneroHdr)>=0){

					mapParametroIni.put("pIND_TipoDespachoHdr", DESPACHO_EXCEPCIONAL);

				}

				//SI [pCOD_RegimenAduaneroHdr] esta en la lista (�AdmisionTemporal�, �Transito�, �ReEmbarque�, �ImportacionTemporal�) ENTONCES
				if(Arrays.binarySearch(listaRegimen2,vCOD_RegimenAduaneroHdr)>=0){
					mapParametroIni.put("pIND_TipoDespachoHdr", dua.getCodmodalidad());
				}


			}// fin if de la validacion

		}

		mapVariablesControl.put("vIND_RequiereAutorizacion", vIND_RequiereAutorizacion);
		mapVariablesControl.put("vIND_TieneAutorizacion", vIND_TieneAutorizacion);
		mapVariablesControl.put("vIND_Exonerado", vIND_Exonerado);
		mapVariablesControl.put("FinValidacion", FinValidacion);
	}






	private boolean validarSubPartidaRestringida(
			Declaracion declaracion,
			DatoSerie serie,
			String codRegistro,
			String codTransaccion,
			Map<String,Map<String,Object>> parametros			
			) {
		MrestriDAOService mrestriDAOService = (MrestriDAOService)fabricaDeServicios.getService("Ayuda.mrestriService");
		DUA dua=declaracion.getDua();
		String codtipotrans=codTransaccion;//declaracion.getCodtipotrans(); 
		Date dtFechaActual=SunatDateUtils.getCurrentDate();
		Integer intFechaActual=SunatDateUtils.getCurrentIntegerDate();
		Boolean partidaRestringida=false;
		Map<String,String> params2=null;
		List<MRestri> listaMerc=null;

		String codregimen =dua.getCodregimen();
		String codmodalidad=null;


		Map<String,Object> mapParametroIni=parametros.get("mapParametroIni");
		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");

		codmodalidad=(String)mapParametroIni.get("pIND_TipoDespachoHdr");
		boolean vIND_RequiereAutorizacion=false;


		MRestri mRestringida=null;

		String[] listaRegimenImpo=new String[]{
				REGIMEN_IMPO_SIMPLIFICADA,REIMPO_MISMO_ESTADO,REGIMEN_REIMPO_MISMO_ESTADO};

		String[] listaRegimenExpo=new String[]{
				REGIMEN_EXPO_DEFINITIVA_OE,REGIMEN_EXPO_SIMPLIFICADA};

		String[] listaEntidadesEmisoras=new String[]{COD_ENTI_SENASA, 
				COD_ENTI_SENASA,COD_ENTI_MITINCI,     COD_ENTI_PESQUERIA_PRODUCE,     COD_ENTI_OTO_PERU_PRODUCE,    COD_ENTI_OTRAS_DEPEND_PRODUCE
		};


		String vRegimenSegunRegimen =  codregimen;
		/* Esta variable [vRegimenSegunRegimen] se usa porque las entidades autorizantes 
		 * referencian movimiento de la mercancia, es decir, ingresa (importacion) o 
		 * sale (exportacion) de manera general, no toma en cuenta los diversos regimenes aduaneros, por ej. 
		 * importacion temporal admision temporal, etc  */	    	
		if(Arrays.asList(listaRegimenImpo).contains(vRegimenSegunRegimen)){
			vRegimenSegunRegimen=REGIMEN_IMPO_DEFINITIVA;
		}

		if(Arrays.asList(listaRegimenExpo).contains(vRegimenSegunRegimen)){
			vRegimenSegunRegimen=REGIMEN_EXPO_DEFINITIVA;
		}

		Map<String,Object> params=null;
		boolean vLeyAduanaVigente=false;

		// control de version
		if(existeControlCambio(COD_JURID_NACIONAL,REG_TRANSITO,
				MODULO_TELEDESPACHO,"000030",dtFechaActual)){
			vLeyAduanaVigente=true;
		}


		//RN-MR-SENASA-Anexo18-Anexo22-1.doc	            
		if(SunatStringUtils.isStringInList(codRegistro, "0501,0505")){


			Long numpartnandi=serie.getNumpartnandi();
			DatoMercancia mercancia =serie.getMercancia();
			String codexoneracion=null;

			if(mercancia!=null){
				codexoneracion= mercancia.getCodexoneracion();    
			}

			params=new HashMap<String, Object>();

			if(codregimen.equals(REG_TRANSITO) && vLeyAduanaVigente){
				params.put("entidad", "05");
				params.put("registro", "0501");
			}

			params.put("cnan", numpartnandi);
			params.put("codiregi", vRegimenSegunRegimen);
			params.put("fechaVigencia", intFechaActual);
			/* Aqu� se realiza la b�squeda concreta de la subpartida en la relaci�n de subpartidas restringidas [MRestri] */
			//					    		 listaMerc= MercanciaRestringidaServiceImpl.getInstance().getMRestriDao().listMercRestringida(params);
			listaMerc= mrestriDAOService.listMercRestringida(params);

			if(!CollectionUtils.isEmpty(listaMerc)){
				//Set<String> vEntiRestringenSPN=null;
				String vEntiRestringenSPN=null;
				params2=new HashMap<String, String>();
				params2.put("cprod", "00");
				// Localiza en [MRestriFiltrado] en base [CPROD] = �00� 
				mRestringida=locate(listaMerc, params2);

				if(mRestringida!=null){
					/* Ahora, se evalua si existe la siguiente excepcion: 
					 * Si es Senasa y Tipo de exoneracion �80� 
					 * implica exoneracion de verificacion informatica del documento de autorizacion */

					if( SunatStringUtils.isEqualTo(mRestringida.getEntidad(), COD_ENTI_SENASA) 
							&&   SunatStringUtils.isEqualTo(codexoneracion, "80"))
					{
						vIND_RequiereAutorizacion=false;
					}
					else{
						vIND_RequiereAutorizacion=true;
					}
				}
				else {
					vIND_RequiereAutorizacion=false;
				}



				boolean vCondicionSenasa=false;

				// Localiza en [MRestriFiltrado] en base [Entidad] = �Senasa� Y [Registro] = �0501�  /* 0501: Anexo 18 */
				params2=new HashMap<String, String>();
				params2.put("entidad", "05");
				params2.put("registro", "0501");
				mRestringida=locate(listaMerc, params2);



				boolean vSenasaANivelNacional=false;
				//SI es localizado Y [pCOD_RegimenAduaneroSerie] = �ImportacionDefinitiva� ENTONCES
				if(mRestringida!=null && codregimen.equals(REGIMEN_IMPO_DEFINITIVA)){

					// control de version
					if(existeControlCambio(COD_JURID_NACIONAL,codregimen,
							MODULO_TELEDESPACHO,"000003",dtFechaActual)){
						vSenasaANivelNacional=true;
					}

					if(vSenasaANivelNacional){
						vCondicionSenasa=true;
					}
					else{ vCondicionSenasa=false;}

				}



				//vEntiRestringenSPN=getEntidadesRestringidas(listaMerc);
				vEntiRestringenSPN=ObtieneListaDeEntidades(listaMerc);
				String entidadesEmis="*05*01*11*18*19*";

				//SI [pIND_TipoDespachoHdr] es diferente a �00� Y
				if(StringUtils.hasText(codmodalidad) &&
						!SunatStringUtils.isEqualTo(codmodalidad, DESPACHO_EXCEPCIONAL) 
						//&& existeEntidadRestrictora(vEntiRestringenSPN,Arrays.asList(listaEntidadesEmisoras))
						&& entidadesEmis.indexOf(vEntiRestringenSPN)>=0
						&& !codtipotrans.equals(COD_TRANSAC_REGULARIZACION)
						&& !vCondicionSenasa
						){
					partidaRestringida=false;
				}
				else partidaRestringida=true;

			}// fin si encontro mercancias restringidas
			else{
				partidaRestringida=false;  
			}
		} // p2 fin si anexo 18



		// p2a RN-MR-SENASA-Anexo19-Anexo20-Anexo22-2.doc
		if( SunatStringUtils.isStringInList(codRegistro, "0502,0503,0505")	){
			Long numpartnandi=serie.getNumpartnandi();
			DatoMercancia mercancia =serie.getMercancia();
			String codexoneracion=mercancia!=null?mercancia.getCodexoneracion():null;

			params=new HashMap<String, Object>();

			if(codregimen.equals(REG_TRANSITO) && vLeyAduanaVigente){
				params.put("entidad", "05");
				String[] s=new String[]{"0502","0503"};
				params.put("registroList", Arrays.asList(s));
			}

			params.put("cnan", numpartnandi); 
			params.put("codiregi", vRegimenSegunRegimen);
			params.put("fechaVigencia", intFechaActual);

			//					    		 listaMerc=  MercanciaRestringidaServiceImpl.getInstance().getMRestriDao().listMercRestringida(params);
			listaMerc=  mrestriDAOService.listMercRestringida(params);

			if(!CollectionUtils.isEmpty(listaMerc)) {
				//Set<String> vEntiRestringenSPN=null;
				String vEntiRestringenSPN=null;
				// Localiza en [MRestriFiltrado] en base [CPROD] = �00�
				params2= new HashMap<String, String>();
				params2.put("cprod", "00");
				mRestringida=locate(listaMerc, params2);

				if(mRestringida!=null){
					/* Ahora, se evalua si existe la siguiente excepcion: 
					 * Si es Senasa y Tipo de exoneracion �80� 
					 * implica exoneracion de verificacion informatica del documento de autorizacion */

					if(mRestringida.getEntidad().equals(COD_ENTI_SENASA) 
							&& ( SunatStringUtils.isEqualTo(codexoneracion, "80") )	 
							){
						vIND_RequiereAutorizacion=false;
					}
					else{
						vIND_RequiereAutorizacion=true;
					}
				}
				else {
					vIND_RequiereAutorizacion=false;
				}

				//SI es localizado Y [pCOD_RegimenAduaneroSerie] = �ImportacionDefinitiva� ENTONCES
				boolean vCondicionSenasa=false;
				//vEntiRestringenSPN=getEntidadesRestringidas(listaMerc);
				vEntiRestringenSPN=ObtieneListaDeEntidades(listaMerc);
				String entidadesEmis="*05*01*11*18*19*";

				//SI [pIND_TipoDespachoHdr] es diferente a �00� Y
				if(
						StringUtils.hasText(codmodalidad)&&
						!codmodalidad.equals(DESPACHO_EXCEPCIONAL) 
						&& entidadesEmis.indexOf(vEntiRestringenSPN)>=0
						&& !codtipotrans.equals(COD_TRANSAC_REGULARIZACION)
						&& !vCondicionSenasa
						){
					partidaRestringida=false;
				}
				else partidaRestringida=true;

			}// si encontro mercancias restringidas
			else{ 	partidaRestringida=false;}

			//} // for de series    	

		} // fin si Anexo 19

		//RN-MR-SENASA-Anexo21.doc
		if("0504".equals(codRegistro) ){
			Long numpartnandi=serie.getNumpartnandi();
			DatoMercancia mercancia =serie.getMercancia();
			String codexoneracion=null;

			if(mercancia!=null){
				codexoneracion= mercancia.getCodexoneracion();    
			}

			params=new HashMap<String, Object>();

			if(codregimen.equals(REG_TRANSITO) && vLeyAduanaVigente){
				partidaRestringida=false;
			}
			else{
				params.put("cnan", numpartnandi);
				params.put("codiregi", vRegimenSegunRegimen);
				params.put("fechaVigencia", intFechaActual);
				// Se busca en la tabla [MRESTRI] en base a [pSPNSerie] Y [vRegimenSegunRegimen]  Y [pFEC_FechaNumeracion] cumple 
				//							    		listaMerc=  MercanciaRestringidaServiceImpl.getInstance().getMRestriDao().listMercRestringida(params);
				listaMerc=  mrestriDAOService.listMercRestringida(params);

				// SI se encontro resultado en la busqueda de [pSPNSerie] ENTONCES
				if(listaMerc!=null && !listaMerc.isEmpty()) {

					Set<String> vEntiRestringenSPN=null;
					// Localiza en [MRestriFiltrado] en base [CPROD] = �00�
					params2= new HashMap<String, String>();
					params2.put("cprod", "00");
					mRestringida=locate(listaMerc, params2);
					// SI Es localizado ENTONCES
					if(mRestringida!=null){

						/* Ahora, se evalua si existe la siguiente excepcion: 
						 * Si es Senasa y Tipo de exoneracion �80� 
						 * implica exoneracion de verificacion informatica del documento de autorizacion */

						if(mRestringida.getEntidad().equals(COD_ENTI_SENASA) 
								&& ( codexoneracion!=null && codexoneracion.equals("80") )	 
								){
							vIND_RequiereAutorizacion=false;
						}
						else{
							vIND_RequiereAutorizacion=true;
						}
					}
					else {
						vIND_RequiereAutorizacion=false;
					}
					//SI es localizado Y [pCOD_RegimenAduaneroSerie] = �ImportacionDefinitiva� ENTONCES
					boolean vCondicionSenasa=false;
					vEntiRestringenSPN=getEntidadesRestringidas(listaMerc);


					//SI [pIND_TipoDespachoHdr] es diferente a �00� Y   [pIND_TipoDespachoHdr] es diferente a �blanco�  Y
					if(StringUtils.hasText(codmodalidad) &&
							!codmodalidad.equals(DESPACHO_EXCEPCIONAL) 
							&& existeEntidadRestrictora(vEntiRestringenSPN,Arrays.asList(listaEntidadesEmisoras))
							&& !codtipotrans.equals(COD_TRANSAC_REGULARIZACION)
							&& vCondicionSenasa==false
							){
						partidaRestringida=false;
					}
					else partidaRestringida=true;

				}// si encontro mercancias	   restringidas
				else { partidaRestringida=false; }
			} // else					    	
			//} // for de series    	

		} // fin     //RN-MR-SENASA-Anexo21.doc





		// RN-MR-DIGEMID-Anexo11.doc
		if ( SunatStringUtils.isStringInList(codRegistro, "0301,0401,0402,1701,1702,2701,2702,2703")){
			Long numpartnandi=serie.getNumpartnandi();
			params=new HashMap<String, Object>();

			if(codregimen.equals(REG_TRANSITO) && vLeyAduanaVigente){
				partidaRestringida=false;
			}
			else{
				params.put("cnan", numpartnandi);
				params.put("codiregi", vRegimenSegunRegimen);
				params.put("fechaVigencia", intFechaActual);

				// Se busca en la tabla [MRESTRI] en base a [pSPNSerie] Y [vRegimenSegunRegimen]  Y [pFEC_FechaNumeracion] cumple 
				//							    		listaMerc=  MercanciaRestringidaServiceImpl.getInstance().getMRestriDao().listMercRestringida(params);
				listaMerc=  mrestriDAOService.listMercRestringida(params);
				// SI se encontro resultado en la busqueda de [pSPNSerie] ENTONCES
				if(!CollectionUtils.isEmpty(listaMerc)) {
					// Localiza en [MRestriFiltrado] en base [CPROD] = �00�
					params2= new HashMap<String, String>();
					params2.put("cprod", "00");
					mRestringida=locate(listaMerc, params2);


					// SI Es localizado ENTONCES
					if(mRestringida!=null){
						vIND_RequiereAutorizacion=true;
					}
					else {
						vIND_RequiereAutorizacion=false;
					}

					partidaRestringida=true;
				}// si encontro mercancias	   restringidas
				else { partidaRestringida=false; }
			} // else					    	
		}// RN-MR-DIGEMID-Anexo11.doc



		//RN-MR-DIGEMID-Anexo12.doc
		if( SunatStringUtils.isStringInList(codRegistro, "0302,0403,0404,0405") ){
			Long numpartnandi=serie.getNumpartnandi();
			params=new HashMap<String, Object>();

			if(codregimen.equals(REG_TRANSITO) && vLeyAduanaVigente){
				params.put("entidad", "03");
				params.put("registro", "0302");
			}

			params.put("cnan", numpartnandi);
			params.put("codiregi", vRegimenSegunRegimen);
			params.put("fechaVigencia", intFechaActual);
			/* Aqui se realiza la busqueda concreta de la subpartida en la relacion de 
			 * subpartidas restringidas [MRestri] */				
			//					    		listaMerc=  MercanciaRestringidaServiceImpl.getInstance().getMRestriDao().listMercRestringida(params);
			listaMerc=  mrestriDAOService.listMercRestringida(params);
			//SI se encontro resultado en la busqueda de [pSPNSerie] ENTONCES
			if(!CollectionUtils.isEmpty(listaMerc)) {
				params2=new HashMap<String, String>();
				params2.put("cprod", "00");
				// Localiza en [MRestriFiltrado] en base [CPROD] = �00� 
				mRestringida=locate(listaMerc, params2);

				// si es localizado
				if(mRestringida!=null){
					vIND_RequiereAutorizacion=true;
				}
				else {
					vIND_RequiereAutorizacion=false;
				}

				partidaRestringida=true;
			}// fin si encontro mercancias restringidas
			else{
				partidaRestringida=false; 
			}
		}//RN-MR-DIGEMID-Anexo12.doc


		// P2E RN-MR-PESQUERIA-Anexo09-Anexo10.doc 
		if( SunatStringUtils.isStringInList(codRegistro, "1101,1102,1801,1802") ){
			Long numpartnandi=serie.getNumpartnandi();
			params=new HashMap<String, Object>();

			if(codregimen.equals(REG_TRANSITO) && vLeyAduanaVigente){
				partidaRestringida=false;
			}
			else{
				params.put("cnan", numpartnandi);
				params.put("codiregi", vRegimenSegunRegimen);
				params.put("fechaVigencia", intFechaActual);
				Set<String>  vEntiRestringenSPN =null;
				// Se busca en la tabla [MRESTRI] en base a [pSPNSerie] Y [vRegimenSegunRegimen]  Y [pFEC_FechaNumeracion] cumple 
				//							    		listaMerc=  MercanciaRestringidaServiceImpl.getInstance().getMRestriDao().listMercRestringida(params);
				listaMerc=  mrestriDAOService.listMercRestringida(params);
				// SI se encontro resultado en la busqueda de [pSPNSerie] ENTONCES
				if(!CollectionUtils.isEmpty(listaMerc)) {

					// Localiza en [MRestriFiltrado] en base [CPROD] = �00�
					params2= new HashMap<String, String>();
					params2.put("cprod", "00");
					mRestringida=locate(listaMerc, params2);

					// SI Es localizado ENTONCES
					if(mRestringida!=null){
						vIND_RequiereAutorizacion=true;
					}
					else {
						vIND_RequiereAutorizacion=false;
					}

					//SI es localizado Y [pCOD_RegimenAduaneroSerie] = �ImportacionDefinitiva� ENTONCES
					boolean vCondicionSenasa=false;
					vEntiRestringenSPN=getEntidadesRestringidas(listaMerc);
					//SI [pIND_TipoDespachoHdr] es diferente a �00� Y

					String auxcodtipotrans=codtipotrans.substring(2);

					if(StringUtils.hasText(codmodalidad) &&
							!codmodalidad.equals(DESPACHO_EXCEPCIONAL) 
							&& existeEntidadRestrictora(vEntiRestringenSPN,Arrays.asList(listaEntidadesEmisoras))
							&& !auxcodtipotrans.equals(COD_TRANSAC_REGULARIZACION)
							&& vCondicionSenasa==false
							){
						partidaRestringida=false;
					}
					else partidaRestringida=true;
				}// si encontro mercancias	   restringidas
				else { partidaRestringida=false; }
			} // else					    	
		}//P2E RN-MR-PESQUERIA-Anexo09-Anexo10.doc



		mapVariablesControl.put("vIND_RequiereAutorizacion", vIND_RequiereAutorizacion);
		mapVariablesControl.put("partidaRestringida", partidaRestringida);
		mapDatosBD.put("MRestriFiltrado", listaMerc);

		return partidaRestringida;

	}



	// �	Documento de autorizacion de la serie que contiene la subpartida restringida 
	private  Map<String, ?>  validarExisteDocAutorizacionPartida(
			Declaracion declaracion,
			DatoSerie serie,
			String codRegistro,
			Map<String,Map<String,Object>> parametros
			){
		Map<String,?> respuesta = new HashMap<String, String>();
		DUA dua=declaracion.getDua();
		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		boolean vIND_TieneAutorizacion=false;

		if(   SunatStringUtils.isStringInList(codRegistro, "0501,0505,0502,0503,0505,0504,0301,0401,0402,1701" +
				",1702,2701,2702,2703,0302,0403,0404,0405,1101,1102,1801,1802"))
		{
			boolean localizado=false;   		
			// genero una lista de doc. asociados a la serie
			List<DatoDocAutorizante> lstDocAutorSerie=  generarListaDocAutorizanteSerie(serie,dua);

			if(!CollectionUtils.isEmpty(lstDocAutorSerie)){
				localizado=true;
			}

			if(localizado){
				vIND_TieneAutorizacion=true;
			}
		}
		mapVariablesControl.put("vIND_TieneAutorizacion", vIND_TieneAutorizacion); 	
		return respuesta;

	}

	// �	Documento de autorizacion de la serie que contiene la subpartida restringida 
	private  List<Map<String, String>>  validarCoherenciaVariableControl(
			Declaracion declaracion,
			DatoSerie serie ,
			String codRegistro,
			Map<String,Map<String,Object>> parametros
			){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		DatoMercancia mercancia=    serie.getMercancia();
		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
		String codexoneracion=null;
		if(mercancia!=null)
			codexoneracion=mercancia.getCodexoneracion(); // EL TPROD EN EL ARCHIVO ANTIGUO
		boolean vIND_TieneAutorizacion=(Boolean)mapVariablesControl.get("vIND_TieneAutorizacion");
		boolean vIND_RequiereAutorizacion=(Boolean)mapVariablesControl.get("vIND_RequiereAutorizacion");
		boolean vIND_Exonerado=(Boolean)mapVariablesControl.get("vIND_Exonerado");
		boolean existeCoherencia=true;

		// P4
		if(  SunatStringUtils.isStringInList(codRegistro, "0501,0505,0502,0503,0505,0504,0301,0401,0402,"+
				"1701,1702,2701,2702,2703,0302,0403,0404,0405,1101,1102,1801,1802"))
		{
			/* Si el documento es requerido 
			 * y no existe el documento de autorizacion en el archivo [DuaDocAs] es incoherente */

			if(vIND_RequiereAutorizacion && !vIND_TieneAutorizacion){
				existeCoherencia=false;
				// AGREGAR ERROR LA SERIE {0} NECESITA OBLIGATORIAMENTE DOC. AUTORIZACION
				lstErrores.add(catalogoAyudaService.getError("30409", new String[]{SunatStringUtils.toStringObj(serie.getNumserie())}));
			}

			/* Si no existe documento de autorizacion en el archivo [DuaDocAs] 
			 * y la serie No tiene exoneracion especificado 
			 * (es porque debe presentar documento de autorizacion) es incoherente */
			if(!vIND_TieneAutorizacion && !vIND_Exonerado )
			{
				//SI [pIND_TipoExoneracionSerie] es blanco ENTONCES 
				if(!StringUtils.hasText(codexoneracion)){
					existeCoherencia=false;
					// AGREGAR ERROR  INDIQUE TIPO DE EXONERACION IGUAL A 80, ES UN INFORME
					lstErrores.add(catalogoAyudaService.getError("30410",new String[]{SunatStringUtils.toStringObj(serie.getNumserie())}));
				}
				else{
					existeCoherencia=false;
					// AGREGAR ERROR LA SERIE {} NECESITA OBLIGATORIAMENTE DOC. AUTORIZACION
					lstErrores.add(catalogoAyudaService.getError("30409", new String[]{SunatStringUtils.toStringObj(serie.getNumserie())}));
				}
			}

			/* Si existe documento de autorizacion en el archivo [DuaDocAs] 
			 * y la serie tiene exoneracion especificado es incoherente 
			 * */ 
			if(vIND_TieneAutorizacion && vIND_Exonerado ){
				existeCoherencia=false;
				// AGREGAR ERROR : SI TIENE AUTORIZACION DEJAR EN BLANCO TPROD, SI NO ENVIAR AUTORIZACION SI ES EXONERADO
				lstErrores.add(catalogoAyudaService.getError("30411"));
			}
		}

		mapVariablesControl.put("existeCoherenciaVarControl", existeCoherencia);

		return lstErrores;
	}

	/* Inicialmente, los datos del documento de autorizaci�n estaban registrados en el archivo [AduaDet1], 
	 * luego se implementa la validaci�n de permisos o autorizaciones, 
	 * esta nueva implementaci�n requiere que los datos del documento de autorizaci�n est�n 
	 * registrados en el archivo [DuaDocAs] */
	/* Entonces, si la vigencia de permisos de SENASA est� activo se har� una validaci�n completa de los datos 
	 * en [DuaDocAs] sino s�lo se validar� los datos del documento de autorizaci�n 
	 * que se encuentran en el [AduaDet1]. 
	 * Si la vigencia de permisos de SENASA no est� activo en este procedimiento espec�fico finalizar� 
	 * la validaci�n (se correcto o incorrecto) . Aunque se hace referencia a Vigencia de SENASA, 
	 * las otras entidades tambi�n pasan por esta condicional  */
	//	Coherencia de datos del documento de autorizacion
	private  List<Map<String,String>>  validarCoherenciaDocAutorizacion(
			Declaracion declaracion,
			DatoSerie serie ,
			String codRegistro,
			Map<String,Map<String,Object>> parametros			
			){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");
		Integer intfechaHoy=SunatDateUtils.getCurrentIntegerDate();
		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
		List<MRestri> mRestriFiltrado= (List<MRestri>)mapDatosBD.get("MRestriFiltrado"); 

		Boolean incoherenciadatos=false;
		Boolean permisoSenasaEncontrado=false;

		if(SunatStringUtils.isStringInList(codRegistro, "0501,0505,0502,0503,0505,0504,0301,0401,0402," +
				"1701,1702,2701,2702,2703,0302,0403,0404,0405,1101,1102,1801,1802"))
		{	    	
			/* Primero buscando si validaciOn de permisos de SENASA esta vigente (actualmente, segUn las fechas configuradas, esta vigente) */
			permisoSenasaEncontrado=false; // consulta a chibolo si se requiere la consulta a la tablnew para setear a este valor
			if(this.existeTablNew("1006", "AJ", intfechaHoy)){
				permisoSenasaEncontrado=true;
			}			    	   

			if(permisoSenasaEncontrado){

				Set<String> vEntiRestringenSPN=  this.getEntidadesRestringidas(mRestriFiltrado);
				/*La lista de condiciones que se deben de cumplir para que el documento de autorizaciOn sea coherente, son:*/	


				// obtengo los doc. autorizantes declarados para la serie
				DatoDocAutorizante docAut= new DatoDocAutorizante();
				List<DatoDocAutorizante>  listDocAuto=this.generarListaDocAutorizanteSerie(serie, declaracion.getDua());
				if(!CollectionUtils.isEmpty(listDocAuto)){
					docAut=listDocAuto.get(0);
				}
				else{
					// ERROR LA SERIE{0} , NO TIENE DOC. AUTORIZANTE RELACIONADO
					lstErrores.add(catalogoAyudaService.getError("30428",new String[]{SunatStringUtils.toStringObj(serie.getNumserie())}));
					return lstErrores;
				}


				/* [pCOD_EntidadEmisoraDocas] debe ser una de las entidades que restringe a la [pSPNSerie] 
				 * referenciada en la serie  este valor debe ser una de las entidade|s que se encuentra en [MRestriFiltrado] */

				/* tener en cuenta que [pCOD_EntidadEmisoraDocas], tiene valores como: 
				 * 05senasa. Las dos primeras son el codigo de la entidad */
				String codentidademisora=docAut.getCodentidad(); 
				String codtipodocasoc=docAut.getCodtipodocum();
				String anndocasoc=null;
				if (SunatStringUtils.length(docAut.getAnndocum())>3)
					anndocasoc =docAut.getAnndocum().substring(0,4);
				else
					anndocasoc=docAut.getAnndocum();
				Date fecemision=docAut.getFecemision();
				Date fecvencimiento=docAut.getFecvencimiento();
				//String numdocum =docAut.getNumdocum();



				if(!vEntiRestringenSPN.contains(codentidademisora)){
					incoherenciadatos=true;
					// DOC. ASOCIADO. :  ENTIDAD EMISORA {0} NO AUTORIZADA
					lstErrores.add(catalogoAyudaService.getError("30412", new String[]{codentidademisora}));
				}

				if(!esDataCatalogo(COD_CATALOG_TIP_DOC_SOPORTE, codtipodocasoc)){
					incoherenciadatos=true;
					// DOC. ASOCIADO :  TIPO DE DOC. AUTORIZACION {0} INVALIDO
					lstErrores.add(catalogoAyudaService.getError("30413", new String[]{codtipodocasoc}));
				}

				if(!NumberUtils.isDigits(anndocasoc) ||  SunatNumberUtils.toInteger(anndocasoc) <=1990 ){
					incoherenciadatos=true;
					// DOC. ASOCIADO :  A�O {0} INVALIDO
					lstErrores.add(catalogoAyudaService.getError("30414", new String[]{anndocasoc}));
				}

				// no  existe la aduana en los datos de Doc Asociado
				// [pCOD_AduanaAutorizadaDocas] debe pertenecer a la relacion de aduanas autorizadas (ver detalle) /* columna Nume_Banco */

				//[pFEC_FechaDeEmisionDocas] debe ser mayor a cero
				if(fecemision==null){
					incoherenciadatos=true;
					// DOC. ASOCIADO :  FECHA DE EMISION INVALIDO
					lstErrores.add(catalogoAyudaService.getError("30415"));
				}

				if(fecemision!=null && NumberUtils.isDigits(anndocasoc)){
					Integer annFecEmi= SunatDateUtils.getAnho(fecemision);
					Integer annDoc=SunatNumberUtils.toInteger(anndocasoc);
					if( !SunatNumberUtils.isEqual(annFecEmi, annDoc)){
						//DOC. ASOCIADO : A�O DE DOCUMENTO DIFERENTE A A�O DE EMISION
						lstErrores.add(catalogoAyudaService.getError("30416"));
						incoherenciadatos=true;
					}
				}

				// si la fecha de emision es mayor a la de vencimiento es incoherente
				if(fecemision!=null && fecvencimiento!=null && !SunatDateUtils.isDefaultDate(fecvencimiento) &&  SunatDateUtils.compareDate(fecemision, fecvencimiento)>0){
					incoherenciadatos=true;
					//DOC. ASOCIADO : FECHA DE EMISION MAYOR A FECHA DE VENCIMIENTO
					lstErrores.add(catalogoAyudaService.getError("30417"));
				}


				// FIN P5 RN-MR-SENASA-Anexo18-Anexo22-1.doc

				if(incoherenciadatos)
					return lstErrores;
				else{
					// requiere una validacion adicional en el caso de digess
					//  P5A si es digesa RN-MR-DIGESA-Anexo13.doc
					if(SunatStringUtils.isStringInList(codRegistro, "0401,0402,0403,0404,0405"))
					{
						// si no hay incoherencia
						if(!incoherenciadatos){
							/* 04: Constancia, corresponde a Digesa */
							/* La vigencia del documento no debe pasar de un anio (considerar bisiesto) */
							if(codtipodocasoc.equals(COD_DOC_SOPORTE_CONSTANCIA)){
								if(fecvencimiento!=null && !SunatDateUtils.isDefaultDate(fecvencimiento) && DateUtil.daysBetween(fecemision, fecvencimiento)>365){
									// RETORNA �ERROR�.�VIGENCIA DEL DOCUMENTO ES ANUAL�
									lstErrores.add(catalogoAyudaService.getError("30418"));
									return lstErrores;
								}
							}    	    		 
						}
					}		// RN-MR-DIGESA-Anexo13.doc	   			    	    		 
				}


			} // si encontrado senasa vigente
			else{
				// esta seccion esta relacionada a la seccion de autorizaci�n desde el archivo de series
				// que ya no aplica en el nuevo esquema
				permisoSenasaEncontrado=false;

			}

		}// 5a fin si	
		mapVariablesControl.put("incoherenciadatos", incoherenciadatos);
		mapVariablesControl.put("permisoSenasaEncontrado", permisoSenasaEncontrado);
		return lstErrores;
	}









	/* Aqu�, se verifica si se debe o no validar la existencia del documento de autorizaci�n especificado en el archivo [DuaDocAs] en la relaci�n de documentos de autorizaci�n en la BD de Sunat ([cab_mr_docautoriz]), esta relaci�n contiene los documentos que se reciben de las entidades por interconexi�n.
Inicialmente, se debe verificar si el r�gimen es �ImportacionDefinitiva�, �ImportacinTemporal�, �Deposito�, si la Aduana es �Mar�tima� o �A�rea�, si est� vigente la interconexi�n con Senasa, si alguna de estas condiciones no se cumple entonces no debe verificarse existencia de autorizaci�n.
Si la serie tiene r�gimen de precedencia y este r�gimen es �Admisi�n Temporal� o �Deposito�  entonces no debe verificarse existencia de autorizaci�n, caso contrario, es decir, si no tiene r�gimen de precedencia o este es cualquier valor diferente de �Admisi�n Temporal� o �Deposito� se debe verificar existencia de autorizaci�n  */
	//	Condici�n de existencia del documento de autorizaci�n en BD de Sunat
	private  List<Map<String, String>>  validarExistenciaDocAutoBD(
			Declaracion declaracion,
			DatoSerie serie ,
			String codRegistro,
			Map<String,Map<String,Object>> parametros
			){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DUA dua=declaracion.getDua();
		String codaduanaorden=dua.getCodaduanaorden();
		String codregimen=dua.getCodregimen();
		Integer intfechaHoy=SunatDateUtils.getCurrentIntegerDate();
		Date dtfechaHoy=SunatDateUtils.getCurrentDate();
		Boolean verificarDocAutorizacionBD=false;
		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");
		List<MRestri> mRestriFiltrado= (List<MRestri>)mapDatosBD.get("MRestriFiltrado"); 
		boolean cumplenCondiciones=true;
		String[] arrayRegimens=new String[]{REGIMEN_IMPO_SIMPLIFICADA,REGIMEN_IMPORTACION_TEMPORAL
				, REGIMEN_ADMISION_TEMPORAL
				,REGIMEN_EXPO_DEFINITIVA,REGIMEN_EXPO_DEFINITIVA_DUE,REGIMEN_EXPO_SIMPLIFICADA
				,REGIMEN_EXPORTACION_TEMPORAL,REGIMEN_REEXPORTACION,REGI_DEPOSITO,MATERIAL_USO_AERONAUTICO,
				REG_TRANSITO,REGIMEN_TRANSBORDO
		};

		// obtengo los doc. autorizantes declarados para la serie
		List<DatoDocAutorizante>  listDocAuto=this.generarListaDocAutorizanteSerie(serie, declaracion.getDua());
		DatoDocAutorizante docAuto=new DatoDocAutorizante();
		if(!CollectionUtils.isEmpty(listDocAuto)){
			docAuto=listDocAuto.get(0);	
		}
		String codEntidadEmisora=docAuto!=null?docAuto.getCodentidad():null;
		/*P6*/
		//RN-MR-SENASA-Anexo18-Anexo22-1.doc	    	
		if(    SunatStringUtils.isStringInList(codRegistro, "0501,0505"))
		{	
			Map<String,String>  campos =new HashMap<String, String>();
			campos.put("entidad", COD_ENTI_SENASA);

			/* del primer registro ubicado despu�s de buscar la primera fila cuya entidad sea 
								�Senasa� (entidad = 05)  */
			MRestri mercRestri= locate(mRestriFiltrado, campos);
			if(mercRestri==null) mercRestri=new MRestri();
			String vCodigoDeDispositivoLegal=mercRestri.getRegistro();

			/*[pCOD_RegimenAduaneroDocas] debe estar en la lista ( �Importaci�nDefinitiva�, 
			    	 �Importaci�nTemporal�, �Dep�sito�) (ver c�digos) */

			if(! SunatStringUtils.isStringInList(codregimen, "10,20,70")){
				cumplenCondiciones=false;
			}

			/*[pCOD_EntidadEmisoraDocas] debe ser �Senasa� 
			 * Y [vCodigoDeDispositivoLegal] debe ser �0501� /* 0501:Anexo18 */

			// [pCOD_EntidadEmisoraDocas] debe ser �Senasa� Y [vCodigoDeDispositivoLegal] debe ser �0501
			if(!( SunatStringUtils.isEqualTo(codEntidadEmisora, COD_ENTI_SENASA)  
					&& ( SunatStringUtils.isStringInList(vCodigoDeDispositivoLegal, "0501,01")   )  )){
				cumplenCondiciones=false;
			}

			//[pCOD_AduanaAutorizadaDocas] debe estar en la lista (�AduanaMaritima�, �AduanaAerea�)
			if(! (SunatStringUtils.isStringInList(codaduanaorden, "118,235")) ){
				cumplenCondiciones=false;
			}


			/*Estar vigente el �VALIDACION DE DOCUMENTOS AUTORIZANTES DE SENASA - 
			    		A NIVEL NACIONAL�( det_ctrlcam, Aduana=�983�, RegimenAduanero=[pCOD_RegimenAduaneroHdr],CodigoCambio= �000003�,
			    		Fecha= [pFEC_FechaNumeracion])*/

			if(! existeControlCambio(COD_JURID_NACIONAL, codregimen, MODULO_TELEDESPACHO, "000003", dtfechaHoy)){
				cumplenCondiciones=false;
			}

			/*/* Ahora, verificamos si la serie del archivo [DuaDocAs] tiene alg�n r�gimen de precedencia.
			 *Si no tiene r�gimen de precedencia entonces se debe verificar la existencia de autorizaci�n. Si la serie tiene r�gimen de precedencia y este r�gimen de precedencia es �AdmisionTemporal� o �Deposito� entonces no se verifica existencia de autorizaci�n, 
			 * para cualquier otro r�gimen de precedencia debe verificarse la existencia de autorizaci�n */ 		 

			if(cumplenCondiciones){

				//  obteniendo los regimens de precedencia de la serie
				Elementos<DatoRegPrecedencia> listRegPrecedencia=serie.getListRegPrecedencia();

				/*Localizar l�nea de [DuaDocAs] en 
				 * archivo de Regimen de precedencia [DuaRegAp] en base [vLineaSerieDeDocas]
							SI Es localizado ENTONCES*/

				if(!CollectionUtils.isEmpty(listRegPrecedencia)){
					for(DatoRegPrecedencia regPre:listRegPrecedencia){
						String codregipre=regPre.getCodregipre();
						if(SunatStringUtils.isStringInList(codregipre, "21,70")){
							verificarDocAutorizacionBD=false;
						}
						else{
							verificarDocAutorizacionBD=true;
						}
					} 
				}
				else { verificarDocAutorizacionBD=true; }  // no tiene regimens de precedencia

			} // fin si cumple condiciones
			else { verificarDocAutorizacionBD=false; } // si no cumple condiciones
		}	// fin p6 RN-MR-SENASA-Anexo18-Anexo22-1.doc	 




		// p6a
		// RN-MR-DIGESA-Anexo13.doc
		if(   "0401".equals(codRegistro) )	
		{

			Map<String,String>  campos =new HashMap<String, String>();
			campos.put("entidad", COD_ENTI_DIGESA);

			MRestri mercRestri= this.locate(mRestriFiltrado, campos);
			if(mercRestri==null) mercRestri=new MRestri();
			String vCodigoDeDispositivoLegal=mercRestri.getRegistro();

			/*[pCOD_RegimenAduaneroDocas] debe estar en la lista ( �Importaci�nDefinitiva�, 
			    	 �Importaci�nTemporal�, �Dep�sito�) (ver c�digos) */

			if(!(  codregimen.equals(REGIMEN_IMPO_DEFINITIVA) ||  codregimen.equals(REGIMEN_IMPORTACION_TEMPORAL) ||  codregimen.equals(REGI_DEPOSITO)   )){
				cumplenCondiciones=false;
			}

			/*[pCOD_EntidadEmisoraDocas] debe ser �Digesa� 
			 * Y [vCodigoDeDispositivoLegal] debe ser �0401�  0401:Anexo13 */

			// [pCOD_EntidadEmisoraDocas] debe ser �Senasa� Y [vCodigoDeDispositivoLegal] debe ser �0401
			if(!( codEntidadEmisora.equals(COD_ENTI_DIGESA) && SunatStringUtils.isEqualTo("0401", vCodigoDeDispositivoLegal) )){
				cumplenCondiciones=false;
			}

			//[pCOD_AduanaAutorizadaDocas] debe estar en la lista (�AduanaMaritima�, �AduanaAerea�)
			if(! (codaduanaorden.equals(COD_ADUANA_MARITIMA_CALLAO) || codaduanaorden.equals(COD_ADUANA_AEREA)) ){
				cumplenCondiciones=false;
			}


			/*	Estar vigente el �VALIDACION DE DOCUMENTOS AUTORIZANTES DE DIGESA - A NIVEL NACIONAL�
			 * ( det_ctrlcam, �983�, RegimenAduanero=[pCOD_RegimenAduaneroHdr],
			 * CodigoCambio= �000002�,Fecha= [pFEC_FechaNumeracion])*/			    		 
			if(! existeControlCambio(COD_JURID_NACIONAL, codregimen, MODULO_TELEDESPACHO, "000002", dtfechaHoy)){
				cumplenCondiciones=false;
			}

			/*/* Ahora, verificamos si la serie del archivo [DuaDocAs] tiene alg�n r�gimen de precedencia.
			 *Si no tiene r�gimen de precedencia entonces se debe verificar la existencia de autorizaci�n. Si la serie tiene r�gimen de precedencia y este r�gimen de precedencia es �AdmisionTemporal� o �Deposito� entonces no se verifica existencia de autorizaci�n, 
			 * para cualquier otro r�gimen de precedencia debe verificarse la existencia de autorizaci�n */ 		 

			if(cumplenCondiciones){
				boolean indValidarRelacionDocAutor=false;
				//  obteniendo los regimens de precedencia de la serie
				Elementos<DatoRegPrecedencia> listRegPrecedencia=serie.getListRegPrecedencia();

				/*Localizar l�nea de [DuaDocAs] en 
				 * archivo de Regimen de precedencia [DuaRegAp] en base [vLineaSerieDeDocas]
							SI Es localizado ENTONCES*/

				if(!CollectionUtils.isEmpty(listRegPrecedencia)){
					DatoRegPrecedencia regPre=listRegPrecedencia.get(0);
					String codregipre=regPre.getCodregipre();

					/*SI [pCOD_RegimenDePrecedenciaPre] est� dentro de la lista 
					 * (�ImportacionSimplificada�,�ImportacionTemporal�, 
					 * �AdmisionTemporal�, �ExportacionDefinitiva-O/E�, 
					 * �ExportacionDefinitiva-DUE�,
					 *  �ExportacionSimplificada�, �ExportacionTemporal�, 
					 *�ReExportacion�, �Deposito�, �MaterialParaUsoAeronautico�, 
					 *�Transito�, �Transbordo�)*/
					/* c�digos: '18','20','21','40','41','48','50'
					 * ,'60','70','71','80','81' respectivamente */

					// si el regimen no esta en la lista
					if( Arrays.binarySearch(arrayRegimens, codregipre)<0 ){
						verificarDocAutorizacionBD=false;
					}
					else{
						indValidarRelacionDocAutor=true;
					}
				}
				else {indValidarRelacionDocAutor=true;}


				/* Aqu� llega solo si no tiene R�gimen de Precedencia 
				 * o si este r�gimen esta en la lista de reg�menes 
				 * que evita la verificaci�n de existencia del documento de referencia */
				/* Validar la relaci�n entre el tipo de documento de autorizaci�n 
				 * y la entidad autorizante cuya relaci�n esta en la tabla [TablNew] 
				 * esta verificaci�n en Senasa se hace de manera �fija�, no es configurable, 
				 * debiera ser configurable tambi�n  */

				if(indValidarRelacionDocAutor){
					/*[vTipoControl]     = �AJ�
                                        [vCodigoControl] = [pCOD_EntidadEmisoraDocas] + [pIND_TipoDeDocumentoDeAutorizacionDocas]
					 */
					// Se busca el c�digo-de-relaci�n en tabla [TablNew] 
					String vTipoControl="AJ";
					String pCOD_EntidadEmisoraDocas=docAuto.getCodentidad();
					String pIND_TipoDeDocumentoDeAutorizacionDocas=docAuto.getCodtipodocum();
					String vCodigoControl=pCOD_EntidadEmisoraDocas+pIND_TipoDeDocumentoDeAutorizacionDocas;

					if(this.existeTablNew(vCodigoControl, vTipoControl, intfechaHoy)){
						// SI [pIND_TipoDeDocumentoDeAutorizacionDocas] = �Certificado� ENTONCES
						if(pIND_TipoDeDocumentoDeAutorizacionDocas.equals(COD_DOC_CERTIFICADO)){
							verificarDocAutorizacionBD=false;;  
						}
						else{
							verificarDocAutorizacionBD=true;
						}
					}
					else{
						// RETORNA �Error�.�TIPO DE DOCUMENTO NO PERTENECE A DIGESA�
						lstErrores.add(catalogoAyudaService.getError("30419"));
						return lstErrores;
					}
				}

			} // fin si cumple condiciones
			else { verificarDocAutorizacionBD=false; } // si no cumple condiciones

		} 	     // fin p6a  RN-MR-DIGESA-Anexo13.doc




		// p6b RN-MR-DIQPF-Anexo05.doc
		if( "1701".equals(codRegistro) )	
		{

			/* del primer registro de la b�squeda de subpartidas restringidas*/
			Map<String,String>  campos =new HashMap<String, String>();
			campos.put("entidad", COD_ENTI_DIQPF);
			MRestri mercRestri= this.locate(mRestriFiltrado, campos); // el primer registro
			if(mercRestri==null) mercRestri=new MRestri();
			String vCodigoDeDispositivoLegal=mercRestri.getRegistro();


			/*[pCOD_RegimenAduaneroDocas] debe estar en la lista ( �Importaci�nDefinitiva�, 
			    	 �Importaci�nTemporal�, �Dep�sito�) (ver c�digos) */

			if(!(  codregimen.equals(REGIMEN_IMPO_DEFINITIVA) ||  codregimen.equals(REGIMEN_IMPORTACION_TEMPORAL) ||  codregimen.equals(REGI_DEPOSITO)   )){
				cumplenCondiciones=false;
			}


			String numdocum=docAuto.getNumdocum();

			// ([pCOD_EntidadEmisoraDocas] debe ser �DIQPF-Produce� Y [vCodigoDeDispositivoLegal] debe ser �1701� 
			if(!( SunatStringUtils.isEqualTo(codEntidadEmisora, COD_ENTI_DIQPF)  && SunatStringUtils.isEqualTo("1701", vCodigoDeDispositivoLegal) )){
				cumplenCondiciones=false;
			}

			/* Formato del numero de autorizaci�n de DIQPF-Produce pertenezca a Lima */
			//AAAAA-X-9999

			String patronDocProduceLima ="00015\\-[I|S]\\-\\d{4}";
			if(!SunatStringUtils.parseFormat(patronDocProduceLima, numdocum)){
				cumplenCondiciones=false;
			}


			//[pCOD_AduanaAutorizadaDocas] debe estar en la lista (�AduanaMaritima�, �AduanaAerea�)
			if(! (codaduanaorden.equals(COD_ADUANA_MARITIMA_CALLAO) || codaduanaorden.equals(COD_ADUANA_AEREA)) ){
				cumplenCondiciones=false;
			}



			/*Estar vigente la �VALIDACION DE DOCUMENTOS AUTORIZANTES DE PRODUCE� 
			 * para la Aduana conectada (det_ctrlcam, Aduana=[pCOD_Aduana],
			 *  RegimenAduanero=[pCOD_RegimenAduaneroHdr], CodigoCambio=�000001�, 
			 *  Fecha=[pFEC_FechaNumeracion]) */
			if(! existeControlCambio(codaduanaorden, codregimen, MODULO_TELEDESPACHO, "000001", dtfechaHoy)){
				cumplenCondiciones=false;
			}

			/*/* Ahora, verificamos si la serie del archivo [DuaDocAs] tiene alg�n r�gimen de precedencia.
			 *Si no tiene r�gimen de precedencia entonces se debe verificar la existencia de autorizaci�n. Si la serie tiene r�gimen de precedencia y este r�gimen de precedencia es �AdmisionTemporal� o �Deposito� entonces no se verifica existencia de autorizaci�n, 
			 * para cualquier otro r�gimen de precedencia debe verificarse la existencia de autorizaci�n */ 		 

			if(cumplenCondiciones){
				//  obteniendo los regimens de precedencia de la serie
				Elementos<DatoRegPrecedencia> listRegPrecedencia=serie.getListRegPrecedencia();

				/*Localizar l�nea de [DuaDocAs] en 
				 * archivo de Regimen de precedencia [DuaRegAp] en base [vLineaSerieDeDocas]
							SI Es localizado ENTONCES*/

				if(!CollectionUtils.isEmpty(listRegPrecedencia)){

					for(DatoRegPrecedencia regPre:listRegPrecedencia){
						String codregipre=regPre.getCodregipre();

						/*SI [pCOD_RegimenDePrecedenciaPre] est� dentro de la lista 
						 * (�ImportacionSimplificada�,�ImportacionTemporal�, 
						 * �AdmisionTemporal�, �ExportacionDefinitiva-O/E�, 
						 * �ExportacionDefinitiva-DUE�,
						 *  �ExportacionSimplificada�, �ExportacionTemporal�, 
						 *�ReExportacion�, �Deposito�, �MaterialParaUsoAeronautico�, 
						 *�Transito�, �Transbordo�)*/
						/* c�digos: '18','20','21','40','41','48','50'
						 * ,'60','70','71','80','81' respectivamente */

						// si el regimen  esta en la lista
						if( Arrays.binarySearch(arrayRegimens, codregipre)>=0 ){
							verificarDocAutorizacionBD=false;
						}
						else{
							verificarDocAutorizacionBD=true;
						}
					} 
				}
				else { 
					verificarDocAutorizacionBD=true;

				}

			} // fin si cumple condiciones
			else { verificarDocAutorizacionBD=false; } // si no cumple condiciones

		} 	     // p6b RN-MR-DIQPF-Anexo05.doc

		mapVariablesControl.put("verificarDocAutorizacionBD", verificarDocAutorizacionBD);

		return lstErrores;

	}

	/*
 �	B�squeda de documento de autorizaci�n en BD de Sunat 
 (que contiene documentos de autorizaci�n enviados por entidades autorizantes por interconexi�n)
	 * */
	private  List<Map<String, String>>   buscarDocAutorBD(Declaracion declaracion, DatoSerie serie, String codRegistro, Map<String,Map<String,Object>> parametros){
		CabMrDocAutorizDAO cabMrDocAutorizDao = fabricaDeServicios.getService("cabMrDocAutorizDAO");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;
		DUA dua=declaracion.getDua();
		String codregimen=dua.getCodregimen();
		Integer intfechaHoy=SunatDateUtils.getCurrentIntegerDate();

		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");
		String vRegimenSegunRegimen=null;
		Boolean existeDocAutorBD=false;



		String[] regimenExport=new String[]{REGIMEN_EXPO_DEFINITIVA_OE,REGIMEN_EXPO_DEFINITIVA_DUE,REGIMEN_EXPO_SIMPLIFICADA,REGIMEN_EXPORTACION_TEMPORAL,REGIMEN_REEXPORTACION};

		List<Map<String,Object>>  listDocAutoBD=null;
		vRegimenSegunRegimen=REGIMEN_IMPO_DEFINITIVA;

		// obtengo los doc. autorizantes declarados para la serie
		List<DatoDocAutorizante>  listDocAuto=this.generarListaDocAutorizanteSerie(serie, declaracion.getDua());
		DatoDocAutorizante docAutor=new DatoDocAutorizante();
		if(!CollectionUtils.isEmpty(listDocAuto)){
			docAutor=listDocAuto.get(0);	
		}
		//Integer numsecdocum=docAutor.getNumsecdocum();

		String codEntidadEmisora=docAutor!=null?docAutor.getCodentidad():null;	    	

		// si esta en la lista
		if(Arrays.binarySearch(regimenExport, codregimen) >=0 ){
			vRegimenSegunRegimen=REGIMEN_EXPO_DEFINITIVA_OE;
		}

		/*p7*/ //RN-MR-SENASA-Anexo18-Anexo22-1.doc
		if(  SunatStringUtils.isStringInList(codRegistro, "0501,0505,1701")  )
		{
			Map<String,Object> params=new HashMap<String, Object>();
			String codtipodocum=docAutor.getCodtipodocum();
			String numdocum=docAutor.getNumdocum();
			String anndocum=docAutor.getAnndocum().substring(0, 4);
			//String anndocum=docAutor.getAnndocum().substring(0, 4);
			//String anndocum1=(SunatDateUtils.getDate(docAutor.getAnndocum(), "yyyy")).toString();

			params.put("codientidad", codEntidadEmisora);
			params.put("ccoddoc", codtipodocum);
			params.put("ccordoc", numdocum);
			params.put("anodoc", anndocum);
			params.put("cregimen", vRegimenSegunRegimen);

			//			    			 listDocAutoBD= MercanciaRestringidaServiceImpl.getInstance().getCabMrDocAutorizDao().findMrDocAutorizBase(params);
			listDocAutoBD= cabMrDocAutorizDao.findMrDocAutorizBase(params);//gmontoya IoC
			//Si no se encuentra resultado en la b�squeda ENTONCES
			if(CollectionUtils.isEmpty(listDocAutoBD)){
				// RETORNA DOCUMENTO NO EXISTE EN LA RELACION DE DOCUMENTOS DE AUTORIZACION EN BD DE SUNAT: {0} - {1}
				lstErrores.add(catalogoAyudaService.getError("30420",new String[]{numdocum,anndocum}));
			}
			else{
				existeDocAutorBD=true;
				//	[vFEC_FechaDeVencimientoBD] = [DocumentoDeAutorizacionBD].[Fec_Venc]
			}
		} /*p7*/ //RN-MR-SENASA-Anexo18-Anexo22-1.doc




		//p7a RN-MR-DIGESA-Anexo13.doc
		if( "0401".equals(codRegistro)  )
		{
			Map<String,Object> params=new HashMap<String, Object>();
			String codtipodocum=docAutor.getCodtipodocum();
			String numdocum=docAutor.getNumdocum();
			String anndocum=docAutor.getAnndocum();
			String codtipodocumaux=codtipodocum;

			/* Cambio de tipo de documento autorizado para Digesa, en Teledespacho presenta Certificado (03) 
			 * pero en la BD de Sunat es Registro(08) */
			if( SunatStringUtils.isEqualTo(codEntidadEmisora, COD_ENTI_DIGESA) && SunatStringUtils.isEqualTo(codtipodocum, COD_DOC_CERTIFICADO) ){
				codtipodocumaux="08"; // �Registro� /* c�digo 08 */
			}
			params.put("codientidad", codEntidadEmisora);
			params.put("ccoddoc", codtipodocumaux);
			params.put("anodoc", anndocum);
			params.put("cregimen", vRegimenSegunRegimen);

			if(  COD_ENTI_DIGESA.equals(codEntidadEmisora) && "08".equals(codtipodocumaux)){

				params.put("codregsani", numdocum);
				params.put("fecvigencia",intfechaHoy );
				//				    			 listDocAutoBD=MercanciaRestringidaServiceImpl.getInstance().getCabMrDocAutorizDao().findMrDocAutorizDigesa(params);
				listDocAutoBD= cabMrDocAutorizDao.findMrDocAutorizDigesa(params); //gmontoya IoC
			}
			else{
				params.put("ccordoc", numdocum);	 
				//		    			           listDocAutoBD=MercanciaRestringidaServiceImpl.getInstance().getCabMrDocAutorizDao().findMrDocAutorizDigesa(params);
				listDocAutoBD=cabMrDocAutorizDao.findMrDocAutorizDigesa(params);//gmontoya IoC
			}

			if( CollectionUtils.isEmpty(listDocAutoBD)){
				existeDocAutorBD=false;
				//RETORNA �Error�.�Documento no existe en relaci�n de documentos de autorizaci�n en BD de Sunat�
				lstErrores.add(catalogoAyudaService.getError("30420",new String[]{numdocum,anndocum}));
			}
			else{
				existeDocAutorBD=true;
				// 	[vFEC_FechaDeVencimientoBD] = [DocumentoDeAutorizacionBD].[Fec_Venc]
			}

		}//p7a RN-MR-DIGESA-Anexo13.doc

		mapDatosBD.put("listDocAutoBD", listDocAutoBD);
		mapVariablesControl.put("existeDocAutorBD", existeDocAutorBD);


		return lstErrores;

	}


	/*�	Comparaci�n de documento de autorizaci�n 
	 * presentado por Teledespacho versus encontrado en BD*/
	/* Si el documento de autorizaci�n especificado en el archivo [DuaDocAs] 
	 * se encuentra en la BD de Sunat ambos documentos deben ser iguales 
	 * en sus caracter�sticas de Fecha de Emisi�n, Fecha de Vencimiento y RUC del importador. 
	 * El resultado es saber si los atributos en son iguales. 
	 * Aparte de la comparaci�n de atributos,hay algunas condiciones 
	 * adicionales que determinar�n si son iguales o no, por ejemplo para el caso de �Rectificaciones� */
	private  List<Map<String, String>>  comparacionDocAutorBD(
			Declaracion declaracion,
			DatoSerie serie ,
			String codRegistro,
			String codTransaccion,
			Map<String,Map<String,Object>> parametros
			){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DUA dua=declaracion.getDua();
		String codaduanaorden=dua.getCodaduanaorden();
		String codregimen=dua.getCodregimen();
		Integer intfechaHoy=SunatDateUtils.getCurrentIntegerDate();
		Date dtFechaHoy = SunatDateUtils.getCurrentDate();
		List<Map<String,String>> lstErrores=new ArrayList<Map<String,String>>();

		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");
		String codtipotrans=codTransaccion;

		Boolean iguales=false;

		// obtengo los doc. autorizantes declarados para la serie
		List<DatoDocAutorizante>  listDocAuto=this.generarListaDocAutorizanteSerie(serie, declaracion.getDua());
		DatoDocAutorizante docAut=new DatoDocAutorizante();
		if(!CollectionUtils.isEmpty(listDocAuto)){
			docAut=listDocAuto.get(0);	
		}

		//Integer numsecdocum=docAut!=null?docAut.getNumsecdocum():null; 
		String codEntidadEmisora=docAut!=null?docAut.getCodentidad():null;
		Date fecEmision=docAut!=null?docAut.getFecemision():null;
		String anndDoc= docAut!=null?docAut.getAnndocum():null;
		String numDoc= docAut!=null?docAut.getNumdocum():null;

		List<MRestri> mRestriFiltrado= (List<MRestri>)mapDatosBD.get("MRestriFiltrado"); 
		List<Map<String,Object>> listDocAutoBD=  (List<Map<String,Object>>)mapDatosBD.get("listDocAutoBD");

		String numeroDocumentoIdentidad=dua.getDeclarante().getNumeroDocumentoIdentidad();

		// p8 RN-MR-SENASA-Anexo18-Anexo22-1.doc
		if( SunatStringUtils.isStringInList(codRegistro, "0501,0505")) 
		{
			boolean cumpleCondiciones=true;
			/* Primera lista de condiciones que se deben de cumplir son */

			// busco en la lista de doc obtenidos en BD , el Doc Aut. Declarado		
			Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAut);
			//	Deben tener la misma fecha de emisi�n de documento
			// si son distintos

			Integer intFecEmiBD=(Integer)docAutBD.get("fecemis");
			Integer intFecEmisioDocAut=SunatDateUtils.getIntegerFromDate(fecEmision);

			if( !SunatNumberUtils.isEqual(intFecEmisioDocAut, intFecEmiBD)){
				cumpleCondiciones=false;
			}

			Integer intFecVenBD=(Integer)docAutBD.get("fecvenc");
			Integer intFecVenDocAut=SunatDateUtils.getIntegerFromDate(docAut.getFecvencimiento());

			//Deben tener la misma fecha de vencimiento de documento
			if(!SunatNumberUtils.isEqual(intFecVenDocAut, intFecVenBD))
			{
				cumpleCondiciones=false;
			}

			//Deben referenciar al mismo importador
			// si son distintos
			String importador=(String)docAutBD.get("librtribu");
			if(! SunatStringUtils.isEqualTo(numeroDocumentoIdentidad, importador)){
				cumpleCondiciones=false;
			}

			// SI se-cumplen-todas-las-condiciones-anteriores ENTONCES
			if(cumpleCondiciones){

				/* Aqu� viene la verificaci�n de condiciones adicionales 
				 * para saber si son �iguales o no�. */
				/* Cuando es rectificaci�n el numero de DUA especificado en el archivo [AduaHdr1] 
				 * debe ser el mismo numero de DUA que contiene el Documento de autorizaci�n, 
				 * y adem�s, la serie del documento de autorizaron debe ser igual a la serie del [DuaDocAs],
				 *  es decir, la autorizaci�n debe ser para la serie. 
				 *  Esta validaci�n incluye la vigencia de un control de cambio: 1022: Vigencia V�lida Senasa  */

				boolean vCodigo1022=false;
				if(this.existeTablNew("1022", "AJ", intfechaHoy)){
					vCodigo1022=true;
				}

				Map<String,String> nombres=new HashMap<String, String>();
				nombres.put("entidad",COD_ENTI_SENASA);

				MRestri restrig=this.locate(mRestriFiltrado, nombres);
				if(restrig==null) restrig=new MRestri();

				String auxcodtipotrans=codtipotrans.substring(2);

				if(auxcodtipotrans.equals(COD_TRANSAC_RECTIFICACION) 
						&& codregimen.equals(REGIMEN_IMPO_DEFINITIVA)	
						&& codEntidadEmisora.equals(COD_ENTI_SENASA)
						&& (restrig!=null && restrig.getRegistro().equals("0501"))
						&& (codaduanaorden.equals(COD_ADUANA_AEREA) || codaduanaorden.equals(COD_ADUANA_MARITIMA_CALLAO) )
						&& vCodigo1022
						){

					boolean localizado=false;
					localizado=localizaSerieDocAurBD(listDocAutoBD, serie.getNumserie());
					if(localizado){
						iguales=true;
						//RETORNA �Son iguales�
					}
					else{
						// AGREGAR ERROR DOCUMENTO DE AUTORIZACION: {0} - {1} NO TIENE ASOCIADO UNA SERIE DE LA DUA 	                      	
						lstErrores.add(catalogoAyudaService.getError("30421",new String[]{numDoc,anndDoc}));
					}
				}
				else{
					iguales=true;
					// RETORNA �Son iguales�
				}
			}
			else{
				// 	RETORNA �ERROR�.�DOCUMENTO AUTORIZACION NO REGISTRADO EN EL SISTEMA: {0} - {1}�
				lstErrores.add(catalogoAyudaService.getError("30422",new String[]{numDoc,anndDoc}));
			}
		}// p8 RN-MR-SENASA-Anexo18-Anexo22-1.doc

		// P8a RN-MR-DIGESA-Anexo13.doc
		if("0401".equals(codRegistro)  )
		{

			boolean cumpleCondiciones=true;
			/* Primera lista de condiciones que se deben de cumplir son */

			// busco en la lista de doc obtenidos en BD , el Doc Aut. Declarado		
			Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAut);
			//	Deben tener la misma fecha de emisi�n de documento
			// si son distintos

			Integer iFecEmision=SunatDateUtils.getIntegerFromDate(docAut.getFecemision());
			Integer iFecEmisionBD=(Integer)docAutBD.get("fecemis");
			Integer iFecVenc=SunatDateUtils.getIntegerFromDate(docAut.getFecvencimiento());
			Integer iFecVencBD=(Integer)docAutBD.get("fecvenc");
			if(!SunatNumberUtils.isEqual(iFecEmision, iFecEmisionBD)){
				cumpleCondiciones=false;
			}

			//Deben tener la misma fecha de vencimiento de documento
			if(!SunatNumberUtils.isEqual(iFecVenc, iFecVencBD))
			{
				cumpleCondiciones=false;
			}

			// SI [pIND_TipoDeDocumentoDeAutorizacionDocas] = �Expediente-EnTramite�) ENTONCES
			if(COD_DOC_EXPEDIENTE_TRAMITE.equals(docAut.getCodtipodocum())){
				//Deben referenciar al mismo importador
				// si son distintos
				if(!numeroDocumentoIdentidad.equals(docAutBD.get("librtribu"))){
					cumpleCondiciones=false;
				}
			}

			// SI se-cumplen-todas-las-condiciones-anteriores ENTONCES
			if(!cumpleCondiciones){
				// 	RETORNA �ERROR�.�DOCUMENTO AUTORIZACION NO REGISTRADO EN EL SISTEMA�
				lstErrores.add(catalogoAyudaService.getError("30422",new String[]{numDoc,anndDoc}));
			}

			// SI [pFEC_FechaNumeracion] es posterior a [vFEC_FechaVencimientoBD] ENTONCES
			if(dtFechaHoy.after(SunatDateUtils.getDateFromInteger((Integer)docAutBD.get("fecvenc")))){
				// 	RETORNA �Error�.�DOCUMENTO DE AUTORIZACION FUERA DE VIGENCIA�
				lstErrores.add(catalogoAyudaService.getError("30423"));
				cumpleCondiciones=false;
			}


			if(cumpleCondiciones) iguales=true;
			else{
				// 	RETORNA �ERROR�.�DOCUMENTO AUTORIZACION NO REGISTRADO EN EL SISTEMA�
				lstErrores.add(catalogoAyudaService.getError("30422",new String[]{numDoc,anndDoc}));
			}
		}// P8a RN-MR-DIGESA-Anexo13.doc

		// P8B RN-MR-DIQPF-Anexo05.doc
		if( "1701".equals(codRegistro)  )
		{

			boolean cumpleCondiciones=true;
			/* Primera lista de condiciones que se deben de cumplir son */
			// busco en la lista de doc obtenidos en BD , el Doc Aut. Declarado		
			Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAut);
			//	Deben tener la misma fecha de emisi�n de documento
			// si son distintos
			if(docAut.getFecemision().compareTo(SunatDateUtils.getDateFromInteger((Integer)docAutBD.get("fecemis")))!=0){
				cumpleCondiciones=false;
			}

			//Deben tener la misma fecha de vencimiento de documento
			if(docAut.getFecvencimiento().compareTo(SunatDateUtils.getDateFromInteger((Integer)docAutBD.get("fecvenc")))!=0)
			{
				cumpleCondiciones=false;
			}
			//Deben referenciar al mismo importador
			// si son distintos
			if(!numeroDocumentoIdentidad.equals(docAutBD.get("librtribu"))){
				cumpleCondiciones=false;
			}
			if(dtFechaHoy.after(SunatDateUtils.getDateFromInteger((Integer)docAutBD.get("fecvenc")))){
				cumpleCondiciones=false;

			}
			// si las partidas son distintas
			if(serie.getNumpartnandi().compareTo((Long)docAutBD.get("partnandi"))!=0)
			{
				cumpleCondiciones=false;
			}
			//[pIND_TipoDeDocumentoDeAutorizacionDocas] debe ser �01� para DIQPF-Produce
			if(!docAut.getCodtipodocum().equals("01")){
				cumpleCondiciones=false;
			}

			//[pCOD_Aduana] debe estar en la lista de [DocumentoDeAutorizacionBD].([CodigoAduana] + [TObservacion])
			String docAduAux=(String)docAutBD.get("codiaduan")+(String)docAutBD.get("tobsev");

			if(!codaduanaorden.equals(docAduAux)){
				cumpleCondiciones=false;
			}


			// SI se-cumplen-todas-las-condiciones-anteriores ENTONCES
			if(!cumpleCondiciones){
				// 	RETORNA �ERROR�.�DOCUMENTO AUTORIZACION NO REGISTRADO EN EL SISTEMA: {0} - {1}�
				lstErrores.add(catalogoAyudaService.getError("30422",new String[]{numDoc,anndDoc}));
			}
			else{
				iguales=true;
				// 	RETORNA �Son iguales�
			}
		}// P8B RN-MR-DIQPF-Anexo05.doc

		mapVariablesControl.put("iguales",iguales);


		return lstErrores;

	}


	/*	Condici�n para verificar uso de documento de autorizaci�n en numeraciones previas*/
	private  List<Map<String, String>>  verificarUsoDocAutorNumeracionPrevia(
			Declaracion declaracion,
			DatoSerie serie ,
			String codRegistro,
			Map<String,Map<String,Object>> parametros
			){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DUA dua=declaracion.getDua();
		String codaduanaorden=dua.getCodaduanaorden();
		String codregimen=dua.getCodregimen();
		//Integer intfechaHoy=SunatDateUtils.getCurrentIntegerDate();
		Date dtFechahoy= SunatDateUtils.getCurrentDate();
		List<Map<String,String>> lstErrores=new ArrayList<Map<String,String>>();

		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");
		Boolean verificarUsoPrevio=null;
		// obtengo los doc. autorizantes declarados para la serie
		List<DatoDocAutorizante>  listDocAuto=this.generarListaDocAutorizanteSerie(serie, declaracion.getDua());
		DatoDocAutorizante docAuto=new DatoDocAutorizante();
		if(!CollectionUtils.isEmpty(listDocAuto)){
			docAuto=listDocAuto.get(0);	
		}

		//Integer numsecdocum=docAuto!=null?docAuto.getNumsecdocum():null;


		List<MRestri> mRestriFiltrado= (List<MRestri>)mapDatosBD.get("MRestriFiltrado"); 
		List<Map<String,Object>> listDocAutoBD=  (List<Map<String,Object>>)mapDatosBD.get("listDocAutoBD");

		//P9 RN-MR-SENASA-Anexo18-Anexo22-1.doc
		if( SunatStringUtils.isStringInList(codRegistro, "0501,0505"))
		{


			//Primera Condici�n, es que cumpla todas las siguientes reglas:
			boolean cumplenCondiciones=true;
			Map<String,String>  campos =new HashMap<String, String>();
			campos.put("entidad", COD_ENTI_SENASA);

			/* del primer registro ubicado despu�s de buscar la primera fila cuya entidad sea 
								�Senasa� (entidad = 05)  */
			MRestri mercRestri= locate(mRestriFiltrado, campos);
			if(mercRestri==null) mercRestri=new MRestri();
			String vCodigoDeDispositivoLegal=mercRestri.getRegistro();

			/*[pCOD_RegimenAduaneroDocas] debe estar en la lista ( �Importaci�nDefinitiva�, 
			    	 �Importaci�nTemporal�, �Dep�sito�) (ver c�digos) */

			if(!(  REGIMEN_IMPO_DEFINITIVA.equals(codregimen) ||  REGIMEN_IMPORTACION_TEMPORAL.equals(codregimen) 
					||  REGI_DEPOSITO.equals(codregimen)   )){
				cumplenCondiciones=false;
			}
			// [pCOD_EntidadEmisoraDocas] debe ser �Senasa� Y [vCodigoDeDispositivoLegal] debe ser �0501
			if(!(COD_ENTI_SENASA.equals(docAuto.getCodentidad()) &&  SunatStringUtils.isStringInList(vCodigoDeDispositivoLegal, "05,0501"))){
				cumplenCondiciones=false;
			}
			//[pCOD_AduanaAutorizadaDocas] debe estar en la lista (�AduanaMaritima�, �AduanaAerea�)
			if(! (COD_ADUANA_MARITIMA_CALLAO.equals(codaduanaorden) || COD_ADUANA_AEREA.equals(codaduanaorden)) ){
				cumplenCondiciones=false;
			}
			/*Estar vigente el �VALIDACION DE DOCUMENTOS AUTORIZANTES DE SENASA - 
			    		A NIVEL NACIONAL�( det_ctrlcam, Aduana=�983�, RegimenAduanero=[pCOD_RegimenAduaneroHdr],CodigoCambio= �000003�,
			    		Fecha= [pFEC_FechaNumeracion])*/

			if(! existeControlCambio(COD_JURID_NACIONAL, codregimen, MODULO_TELEDESPACHO, "000003", dtFechahoy)){
				cumplenCondiciones=false;
			}

			// Segunda Condici�n:
			//[pCOD_RegimenAduaneroDocas] sea �ImportacionDefinitiva� 
			// la segunda condicion no tiene sentido , porque esta incluida en la primera condicion
			if(cumplenCondiciones){
				verificarUsoPrevio=true;
				// RETORNA �Es necesario verificar uso correcto de documento de autorizaci�n en numeraciones previas�
			}
			else{
				// obtengo los doc Autorizantes  de BD  de Interconexxion relacionados al Doc Declarado
				Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAuto);

				// 	SI [pFEC_FechaNumeracion] es posterior a [vFEC_FechaDeVencimientoBD] 
				//Y No tiene Expediente de Ampliaci�n ENTONCES
				if(dtFechahoy.after(SunatDateUtils.getDateFromInteger((Integer)docAutBD.get("fecvenc")))
						&&	 !docAutBD.get("sautoriza").equals("E")
						){
					// RETORNA �Error�.�Documento de Autorizaci�n fuera de vigencia� 
					/* No es necesario verificar uso correcto */
					lstErrores.add(catalogoAyudaService.getError("30423"));
				}
				else{
					verificarUsoPrevio=false;
					// 	RETORNA �No es necesario verificar uso correcto de documento de autorizaci�n en numeraciones previas�
				}
			}
		} //P9 RN-MR-SENASA-Anexo18-Anexo22-1.doc
		mapVariablesControl.put("verificarUsoPrevio", verificarUsoPrevio);
		return lstErrores;

	}



	/*10.	Validar si el documento de autorizaci�n encontrado en la BD de SUnat 
	 * ya sido utilizado en otras numeraciones de DUA. Ver */

	/* Para verificar uso previo del documento de autorizaci�n significa 
	 * buscar dicho documento en la tabla [Restring] 
	 * cuyo n�mero de DUA en [Restring] sea diferente al n�mero de DUA Actual, es decir, el posible numero de DUA especificado en el archivo [AduaHdr1] */            
	/*Uso correcto de documento de autorizaci�n en numeraciones previas y en la numeraci�n actual*/
	private  List<Map<String, String>>  usoCorrectoDocAutorNumeracionPrevia(
			Declaracion declaracion,
			DatoSerie serie ,
			String codRegistro,
			Map<String,Map<String,Object>> parametros
			){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DocAutAsociadoDAO docAutAsocDao = fabricaDeServicios.getService("docAutAsocDao");
		DUA dua=declaracion.getDua();
		String codaduanaorden=dua.getCodaduanaorden();
		//String codregimen=dua.getCodregimen();
		String annpresen=declaracion.getAnnorden();
		//Date dtFechaHoy=  SunatDateUtils.getCurrentDate();
		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");
		//Map<String,Object> mapWarnings= parametros.get("mapWarnings");
		List<Map<String,String>> lstErrores=new ArrayList<Map<String,String>>();
		// obtengo los doc. autorizantes declarados para la serie
		List<DatoDocAutorizante>  listDocAuto=this.generarListaDocAutorizanteSerie(serie, declaracion.getDua());
		DatoDocAutorizante docAuto=new DatoDocAutorizante();
		if(!CollectionUtils.isEmpty(listDocAuto)){
			docAuto=listDocAuto.get(0);	
		}

		//Integer numsecdocum=docAuto!=null?docAuto.getNumsecdocum():null;
		List<Map<String,Object>> listDocAutoBD=  (List<Map<String,Object>>)mapDatosBD.get("listDocAutoBD");
		Boolean usoCorrecto=null;


		if( SunatStringUtils.isStringInList(codRegistro, "0501,0505")  )
			//P10 RN-MR-SENASA-Anexo18-Anexo22-1.doc
		{
			// buscar el documento en la tabla DocAutoriz (nuevo modelo de BD)
			Map<String,Object> params =new HashMap<String, Object>();

			params.put("codentidad", docAuto.getCodentidad());
			params.put("numdocum", docAuto.getNumdocum());
			params.put("anndocum", docAuto.getAnndocum().substring(0, 4));
			params.put("codtipodocum", docAuto.getCodtipodocum());
			params.put("codaduana", codaduanaorden);
			params.put("annpresen", annpresen);

			List<Map<String,Object>> lstDocUsados=null;
			// consulta si los doc. aut han sido usados por otras duas
			//			            	 lstDocUsados= MercanciaRestringidaServiceImpl.getInstance().getDocAutAsocDao().findDocAutoUsadosByParams(params);
			lstDocUsados= docAutAsocDao.findDocAutoUsadosByParams(params);//gmontoya IoC

			// obtengo los doc Autorizantes  de BD  de Interconexxion relacionados al Doc Declarado
			Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAuto);

			Integer intHoy=SunatDateUtils.getCurrentIntegerDate();
			Integer intFecVenc=(Integer)docAutBD.get("fecvenc");


			//Si no se encuentra resultado ENTONCES

			if(CollectionUtils.isEmpty(lstDocUsados)){

				/* Se estar�a usando por primera vez el documento de autorizaci�n */
				// SI [pFEC_FechaNumeracion] es posterior a [vFEC_FechaDeVencimientoBD] ENTONCES
				if( SunatNumberUtils.isGreaterThanParam(intHoy, intFecVenc)){
					//RETORNA DOC. ASOCIADO: {0} - {1} . FUERA DE VENCIMIENTO : {2}
					lstErrores.add(catalogoAyudaService.getError("30424",new String[]{docAuto.getNumdocum(),docAuto.getAnndocum(),SunatStringUtils.toStringObj(intFecVenc)}));
				}
			}
			else{ // si se encuentra
				//AlertaInternaAPersonalDeAduanas( �Senasa�, �Documento usado anteriormente�)
				if( SunatNumberUtils.isGreaterThanParam(intHoy, intFecVenc)){
					//AlertaInternaAPersonalDeAduanas( �Senasa�, �Fuera de vencimiento�)
				}
			}
			///* El uso correcto implica el cumplimiento de las siguientes condiciones */

			// La subpartida del documento de autorizaci�n en la BD de Sunat debe ser la misma subpartida de la serie
			boolean cumpleCondiciones=true;

			Long numPartida=SunatNumberUtils.toLong(docAutBD.get("partnandi"));

			if(  ! SunatNumberUtils.isEqual(numPartida, serie.getNumpartnandi())){
				cumpleCondiciones=false;
			}

			// [pIND_TipoDeDocumentoDeAutorizacionDocas] debe ser �09� para Senasa
			if(!SunatStringUtils.isEqualTo(docAuto.getCodtipodocum(), "09")){
				cumpleCondiciones=false;
			}

			/*[pCOD_Aduana] debe estar en la lista de especificada en el 
			 * 
			            	  [DocumentoDeAutorizacionBD]. ( [CodigoAduana]+ [TObservacion] ) La entidad especifica en que aduana se podr� usar
			            	  , por el momento solo se puede usar para las aduanas �mar�tima� y �a�rea� */
			String docAduAux=(String)docAutBD.get("codiaduan")+(String)docAutBD.get("tobsev");

			if(!SunatStringUtils.isEqualTo(codaduanaorden, docAduAux)){
				cumpleCondiciones=false;
			}

			//SI no se cumple alguna de las tres condiciones previas ENTONCES
			if(!cumpleCondiciones){
				// 	RETORNA �Error�.�USO INCORRECTO DE DOC. DE AUTORIZACION: {0} -{1}�
				lstErrores.add(catalogoAyudaService.getError("30425",new String[]{docAuto.getNumdocum(),docAuto.getAnndocum()}));
				return lstErrores;
			}
			else{
				usoCorrecto=true;
				//RETORNA �Uso correcto del documento de autorizaci�n�
			}
		}    //P10 RN-MR-SENASA-Anexo18-Anexo22-1.doc

		mapVariablesControl.put("usoCorrecto", usoCorrecto);
		return lstErrores;

	}




	/*/* El control de pesos autorizados s�lo se aplicar� si el documento de autorizaci�n especifica que no incluye �controlador biol�gico�
( [det_mr_docautoriz].[IND_CTRL_BIO], este valor es retornado en [DocumentoDeAutorizacionBD] ) */
	private  List<Map<String, String>>  verificarUsoCorrectoPesosAutorizados(
			Declaracion declaracion,
			DatoSerie serie ,
			String codRegistro,
			String codTransaccion,
			Map<String,Map<String,Object>> parametros
			){

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String,Object> mapVariablesControl=parametros.get("mapVariablesControl");;
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");
		Map<String,Object> mapParametroIni= parametros.get("mapParametroIni");
		List<Map<String,String>> lstErrores=new ArrayList<Map<String,String>>();
		// obtengo los doc. autorizantes declarados para la serie
		List<DatoDocAutorizante>  listDocAuto=this.generarListaDocAutorizanteSerie(serie, declaracion.getDua());
		DatoDocAutorizante docAuto=new DatoDocAutorizante();
		if(!CollectionUtils.isEmpty(listDocAuto)){
			docAuto=listDocAuto.get(0);	
		}
		//Integer numsecdocum=docAuto.getNumsecdocum();

		List<Map<String,Object>> listDocAutoBD=  (List<Map<String,Object>>)mapDatosBD.get("listDocAutoBD");
		Boolean verificarUsoCorrectoPesos=null;

		//P11 RN-MR-SENASA-Anexo18-Anexo22-1.doc
		if( SunatStringUtils.isStringInList(codRegistro, "0501,0505") )
		{
			// obtengo los doc Autorizantes  de BD  de Interconexxion relacionados al Doc Declarado
			Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAuto);
			String ctrBiolog=(String)docAutBD.get("ctrlbio");
			if(! SunatStringUtils.isEqualTo(ctrBiolog, "1") ){
				// 	RETORNA �No es necesario verificar uso correcto de pesos autorizados y por usar�
				verificarUsoCorrectoPesos=false;
			}
			else{
				// 	RETORNA �Es necesario verificar uso correcto de pesos autorizados y por usar�
				verificarUsoCorrectoPesos=true;
			}
		}    //P11 RN-MR-SENASA-Anexo18-Anexo22-1.doc


		//P11a RN-MR-DIQPF-Anexo05.doc
		if( "1701".equals(codRegistro) )
			/*/* El documento de autorizaci�n de la DIQPF de Produce, s�lo puede usarse una vez, caso contrario 
			 *mostrar� un  mensaje de error. Entonces basta que el documento tenga como �cantidad utilizada 
			 * una cantidad mayor a cero para ya no verificar uso de peso y mostrar el mensaje de error  */           	

		{
			// obtengo los doc Autorizantes  de BD  de Interconexxion relacionados al Doc Declarado
			Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAuto);
			BigDecimal cantidadutilizada=  ((BigDecimal)docAutBD.get("cntutil"));
			String pIND_TipoDespachoHdr=(String)mapParametroIni.get("pIND_TipoDespachoHdr");

			String auxcodtipotrans=codTransaccion.substring(2);

			if( SunatNumberUtils.isGreaterThanZero(cantidadutilizada)
					&& COD_TRANSAC_REGULARIZACION.equals(auxcodtipotrans)	
					&& DESPACHO_EXCEPCIONAL.equals(pIND_TipoDespachoHdr)
					){
				// RETORNA DOC. AUTORIZACION YA FUE UTILIZADO : {0} - {1}
				lstErrores.add(catalogoAyudaService.getError("30426", new String[]{docAuto.getNumdocum(),docAuto.getAnndocum()}));
				return lstErrores;
			}
			else{
				// 	RETORNA �Es necesario verificar uso correcto de pesos autorizados y por usar�
				verificarUsoCorrectoPesos=true;
			}
		}    //P11a RN-MR-DIQPF-Anexo05.doc

		mapVariablesControl.put("verificarUsoCorrectoPesos",verificarUsoCorrectoPesos);

		return lstErrores;

	}


	/*�	Uso correcto de pesos autorizados y por usar*/
	// /* Aqu� b�sicamente verifica que el peso neto a importar no sea mayor al 
	// peso neto autorizado por el documento de autorizaci�n encontrado en la BD de Sunat  */
	private  List<Map<String, String>>   usoCorrectoPesosAutorizado(
			Declaracion declaracion,
			DatoSerie serie ,
			String codRegistro,
			String codTransaccion,
			Map<String,Map<String,Object>> parametros
			){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DocAutAsociadoDAO docAutAsocDao = fabricaDeServicios.getService("docAutAsocDao");
		DUA dua=declaracion.getDua();
		String codregimen=dua.getCodregimen();
		//Integer intfechaHoy=SunatDateUtils.getCurrentIntegerDate();
		Map<String,Object> mapDatosBD= parametros.get("mapDatosBD");
		// obtengo los doc. autorizantes declarados para la serie
		List<DatoDocAutorizante>  listDocAuto=this.generarListaDocAutorizanteSerie(serie, declaracion.getDua());
		DatoDocAutorizante docAuto=new DatoDocAutorizante();
		if(!CollectionUtils.isEmpty(listDocAuto)){
			docAuto=listDocAuto.get(0);	
		}
		//Integer numsecdocum=docAuto.getNumsecdocum();
		List<Map<String,Object>> listDocAutoBD=  (List<Map<String,Object>>)mapDatosBD.get("listDocAutoBD");
		List<Map<String,String>> lstErrores=new ArrayList<Map<String,String>>();

		if( SunatStringUtils.isStringInList(codRegistro, "0501,0505") )
			// 12 RN-MR-SENASA-Anexo18-Anexo22-1.doc
		{
			/* Lo primero es detectar cuanto peso ya ha sido utilizado, la observaci�n es la siguiente: 
			 * si el documento de autorizaci�n tiene varias l�neas de la misma partida, 
			 * toma la �cantidad utilizada� de la primera l�nea */

			Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAuto);
			BigDecimal vPesoUtilizadoActual=(BigDecimal)docAutBD.get("cntutil");
			//[vPesoAcumuladoAutorizado] = SUMA (Pesos) de [DocumentoDeAutorizacionBD] en base [pSPNSerie]
			BigDecimal vPesoAcumuladoAutorizado=sumaPesosSerieDocAutoBd(listDocAutoBD, serie);
			//[vSaldoDePeso] = [vPesoAcumuladoAutorizado] menos [vPesoUtilizadoActual]
			BigDecimal vSaldoDePeso= SunatNumberUtils.diference(vPesoAcumuladoAutorizado, vPesoUtilizadoActual) ;
			/*SI [pCOD_RegimenAduaneroDocas] = �ImportacionDefinitiva� Y  
    	                [pIND_TipoDeTransaccion] est� dentro de la lista 
    	                ( �Regularizaci�n�, �Rectificaci�n�) /* 03, 05 */ 

			String auxcodtipotrans=codTransaccion.substring(2);

			if(REGIMEN_IMPO_DEFINITIVA.equals(codregimen)
					&&  SunatStringUtils.isStringInList(auxcodtipotrans, "03,04")){
				// /* para estos tipos de transacci�n, al parecer, 
				//ya viene con un numero de DUA �original� en Hdr 
				NumdeclRef numdeclRef=declaracion.getNumdeclRef();
				String numcorreref=numdeclRef!=null?numdeclRef.getNumcorre():null;
				String codaduanaref=numdeclRef!=null?numdeclRef.getCodaduana():null;
				String annpresref=numdeclRef!=null?numdeclRef.getAnnprese():null;

				String numcorreRectificado= numcorreref;
				Map<String,Object> params=new HashMap<String, Object>();
				params.put("numdeclaracion", numcorreRectificado);
				params.put("numsecserie", serie.getNumserie());
				params.put("codentidad", docAuto.getCodentidad());
				params.put("numdocum", docAuto.getNumdocum());
				params.put("anndocum", docAuto.getAnndocum());
				params.put("codtipodocum", docAuto.getCodtipodocum());
				params.put("numpartida", serie.getNumpartnandi());
				params.put("codaduana", codaduanaref);
				params.put("anhopresen", annpresref);


				/* documentos de autorizaci�n usados en DUAs previas es la relaci�n de tablas [Retring] 
				 * con [di09seriesi], 
				 * esta ultima el nombre de  la tabla depende del A�o de proceso (en este caso 09) */
				//								BigDecimal vPesosUsadosEnRectificacion =MercanciaRestringidaServiceImpl.getInstance().getDocAutAsocDao().sumaPesosUsadoRectificacionByParam(params);
				BigDecimal vPesosUsadosEnRectificacion = docAutAsocDao.sumaPesosUsadoRectificacionByParam(params);//gmontoya IoC
				vSaldoDePeso=SunatNumberUtils.sum(vPesosUsadosEnRectificacion, vSaldoDePeso)  ;
			}


			/* la validaci�n es: El peso neto a usarse debe ser menor o igual 
			 * al Saldo por usarse del peso autorizado */

			//SI [pCNT_PesoNetoSerie] es mayor a [vSaldoDePeso] ENTONCES
			if(SunatNumberUtils.isGreaterThanParam(serie.getCntpesoneto(), vSaldoDePeso)){
				// 	RETORNA �Error�.�USO INCORRECTO DE LOS PESOS AUTORIZADO , PESO SERIE : {0} ES MAYOR AL SALDO DISPONIBLE {1}�
				lstErrores.add(catalogoAyudaService.getError("30427",new String[]{SunatStringUtils.toStringObj(serie.getCntpesoneto()),SunatStringUtils.toStringObj(vSaldoDePeso)}));
				return lstErrores;
			}
			else{
				//RETORNA �Uso correcto de pesos autorizados�
			}
		} // 12 RN-MR-SENASA-Anexo18-Anexo22-1.doc



		// 12 a RN-MR-DIQPF-Anexo05.doc
		if(  "1701".equals(codRegistro) )
		{
			/* Si el documento de autorizaci�n tiene varias l�neas de la misma partida,
			 *  toma la �cantidad utilizada� de la primera l�nea */						
			Map<String,Object>  docAutBD=obtenerDocAutorBD(listDocAutoBD,docAuto);
			BigDecimal vPesoUtilizadoActual=(BigDecimal)docAutBD.get("cntutil");
			// /* Esta columna �Pesos� es Neto si entidad es DIQPF, 
			// sino es peso bruto � difiere con la parte inicial de este procedimiento espec�fico �vPesoSerie */
			BigDecimal vPesoAcumuladoAutorizado=sumaPesosSerieDocAutoBd(listDocAutoBD, serie);
			//[vSaldoDePeso] = [vPesoAcumuladoAutorizado] menos [vPesoUtilizadoActual]
			BigDecimal vSaldoDePeso=vPesoAcumuladoAutorizado.add(vPesoUtilizadoActual.negate());
			/*SI [pCOD_RegimenAduaneroDocas] = �ImportacionDefinitiva� Y  
    	                [pIND_TipoDeTransaccion] est� dentro de la lista 
    	                ( �Regularizaci�n�, �Rectificaci�n�) /* 03, 05 */ 

			String auxcodtipotrans= codTransaccion.substring(2);
			if(codregimen.equals(REGIMEN_IMPO_DEFINITIVA)
					&& (auxcodtipotrans.equals(COD_TRANSAC_REGULARIZACION)
							|| auxcodtipotrans.equals(COD_TRANSAC_RECTIFICACION)  )		
					){

				// /* para estos tipos de transacci�n, al parecer, 
				//ya viene con un numero de DUA �original� en Hdr 
				String numcorreref=declaracion.getNumdeclRef()!=null?declaracion.getNumdeclRef().getNumcorre():null;							
				String numcorreRectificado= numcorreref;
				Map<String,Object> params=new HashMap<String, Object>();
				params.put("numcorredoc", numcorreRectificado);
				params.put("numsecserie", serie.getNumserie());
				params.put("codentidad", docAuto.getCodentidad());
				params.put("numdocum", docAuto.getNumdocum());
				params.put("anndocum", docAuto.getAnndocum());
				params.put("codtipodocum", docAuto.getCodtipodocum());
				/* documentos de autorizaci�n usados en DUAs previas es la relaci�n de tablas [Retring] 
				 * con [di09seriesi], 
				 * esta ultima el nombre de  la tabla depende del A�o de proceso (en este caso 09) */
				//								BigDecimal vPesosUsadosEnRectificacion =MercanciaRestringidaServiceImpl.getInstance().getDocAutAsocDao().sumaPesosUsadoRectificacionByParam(params);
				BigDecimal vPesosUsadosEnRectificacion =docAutAsocDao.sumaPesosUsadoRectificacionByParam(params);//gmontoya IoC
				vSaldoDePeso=SunatNumberUtils.sum(vPesosUsadosEnRectificacion, vSaldoDePeso)  ;
			}
		} // 12 a RN-MR-DIQPF-Anexo05.doc
		return lstErrores;

	}


	private boolean localizaSerieDocAurBD(List<Map<String,Object>> listDocAutorBD , Integer numSerie){
		boolean localizado=false;

		if(!CollectionUtils.isEmpty(listDocAutorBD)){	
			for(Map<String,Object> mapDocAutorBD:listDocAutorBD){
				BigDecimal numSerieBD=(BigDecimal) mapDocAutorBD.get("numeserie");
				if (numSerieBD.compareTo(new BigDecimal(numSerie.toString()))==0){
					localizado=true;
				}

			}
		}
		return localizado;

	}





	private boolean existeControlCambio(String aduana, String regimen, String modulo, String codcambio , Date fecha){
		DetCtrlCamDAO detCtrlCamDao = fabricaDeServicios.getService("detCtrlCamDAO");
		boolean controlCambio=false;
		Map<String,Object> params=new HashMap<String, Object>();

		if(aduana!=null) params.put("codAduana", aduana);
		if(regimen!=null) params.put("codRegimen", regimen);
		if(modulo!=null) params.put("codModulo", modulo);
		if(codcambio!=null) params.put("codCambio", codcambio);
		params.put("numSecItem", 1);
		params.put("indEstado", 1);
		if(fecha!=null) params.put("fechaVigencia", fecha);

		//	    	if(MercanciaRestringidaServiceImpl.getInstance().getDetCtrlCamDao().count(params)>0){
		if(detCtrlCamDao.count(params)>0){
			controlCambio=true;

		}

		return controlCambio;

	}

	public int countDetCtrl(Map<String,Object> params){
		DetCtrlCamDAO detCtrlCamDao = fabricaDeServicios.getService("detCtrlCamDAO");
		return detCtrlCamDao.count(params);
	}

	private boolean existeTablNew(String codigo, String Tipo, Integer fecha){
		TablnewDAOService tablnewDAOService = fabricaDeServicios.getService("Ayuda.tablnewServiceService");
		boolean vigente=false;
		Map<String,Object> params=new HashMap<String, Object>();

		params.put("codigo", codigo);
		params.put("Tipo", Tipo);
		params.put("fechavigencia", fecha);

		//            List<TablNew> listTabl=MercanciaRestringidaServiceImpl.getInstance().getTablNewDao().findTablNewByParams(params);
		List<TablNew> listTabl=tablnewDAOService.findTablNewByParams(params);
		if(listTabl!=null && !listTabl.isEmpty()){
			vigente=true;

		}

		return vigente;

	}


	private boolean existeEntidadRestrictora(Collection<String> EntidadesRestric, List<String> EntidadesEmisoras){
		boolean existe=false;
		if(!CollectionUtils.isEmpty(EntidadesRestric)){
			for(String entidad:EntidadesRestric){
				if(EntidadesEmisoras.contains(entidad)){
					existe=true;
				}
				else existe=false;
			}
		}
		return existe;

	}

	/* obtener una lista de los Doc. Autorizantes (DatoDocAutorizante) a partir
	 * de la seccion  listSerieDocSoporte de la Serie
	 */
	public List<DatoDocAutorizante> generarListaDocAutorizanteSerie(DatoSerie serie , DUA dua){

		List<DatoDocAutorizante> lsDocs =null;
		if(!CollectionUtils.isEmpty(serie.getListSerieDocSoporte())){
			for(DatoSerieDocSoporte serieDoc: serie.getListSerieDocSoporte()){
				// tomo el id
				Integer numiddocsoporte=serieDoc.getNumiddocsoporte();
				String codtipodocsoporte=serieDoc.getCodtipodocsoporte();
				//String codtipoproceso=serieDoc.getCodtipodocsoporte();

				if( SunatStringUtils.isEqualTo(codtipodocsoporte, Constants.DOCUMENTO_AUTORIZACION) ){
					if(numiddocsoporte!=null){
						if(!CollectionUtils.isEmpty(dua.getListDocAutorizantes())){	
							// busco  el id , al en los docuementos autorizantes a la DUA
							for(DatoDocAutorizante docAuto:dua.getListDocAutorizantes()){
								// si lo encontre
								if( SunatNumberUtils.isEqual(docAuto.getNumsecdocum(),numiddocsoporte) ){
									if(lsDocs==null) lsDocs=new ArrayList<DatoDocAutorizante>();
									lsDocs.add(docAuto);
									// valido que sea del tipo de proceso P: Documento de autorizacion
								}
							}
						}
					}
				}
			}
		}

		return lsDocs;
	}

	// Similar al Metodo Locale de Fox
	public MRestri locate(List<MRestri> restri,Map<String,String> nombres){
		boolean b=false;
		MRestri restriLoc=null;

		if(!CollectionUtils.isEmpty(restri)){
			for(MRestri r:restri){

				for(String s: nombres.keySet())
				{
					if(nombres.get(s).equals(r.getValuebyProperName(s))){
						b=true;
					}	
					else{
						b=false;
					}
				}		

				if(b){
					restriLoc=r;
					break;
				}
			}
		}
		return restriLoc;
	}


	public Map<String,Object> obtenerDocAutorBD(List<Map<String,Object>> listDocAutoBD,
			DatoDocAutorizante docAut
			){

		Map<String,Object> cabAutRet=null;
		if(!CollectionUtils.isEmpty(listDocAutoBD)){
			for( Map<String,Object>  docAutBD: listDocAutoBD){
				// para saber si es el mismo
				if( SunatStringUtils.isEqualTo(docAut.getAnndocum().substring(0,4), (String)docAutBD.get("anodoc"))
						&& SunatStringUtils.isEqualTo(docAut.getNumdocum(), (String)docAutBD.get("ccordoc"))
						&& SunatStringUtils.isEqualTo(docAut.getCodentidad(), (String)docAutBD.get("codiEntidad"))								
						){
					cabAutRet=docAutBD;
					break;

				}
			}
		}
		return cabAutRet;
	}


	public BigDecimal sumaPesosSerieDocAutoBd(List<Map<String,Object>> listDocAutoBD,
			DatoSerie serie
			){

		BigDecimal sumaPesos=BigDecimal.ZERO;

		for( Map<String,Object>  docAutBD: listDocAutoBD){
			// para saber si es de la misma serie
			if( serie.getNumserie().compareTo(((Integer)(docAutBD.get("numeserie"))))==0) 
			{
				sumaPesos= SunatNumberUtils.sum(sumaPesos, (BigDecimal)docAutBD.get("peso"));
			}
		}
		return sumaPesos;

	}


	// arma un set con los codigos de entidades restringidas de la lista listaMerc
	private Set<String> getEntidadesRestringidas(List<MRestri> listaMerc){

		Set<String> vEntiRestringenSPN=new HashSet<String>();

		if(!CollectionUtils.isEmpty(listaMerc)){
			for(MRestri res:listaMerc){
				vEntiRestringenSPN.add(res.getEntidad());
			}
		}


		return vEntiRestringenSPN;
	}

	private String ObtieneListaDeEntidades(List<MRestri> listaMerc){

		//Set<String> vEntiRestringenSPN=new HashSet<String>();
		String result="*";
		if(!CollectionUtils.isEmpty(listaMerc)){
			for(MRestri res:listaMerc){
				result=result+res.getEntidad()+"*";
			}
		}


		return result;
	}

	private boolean esDataCatalogo(String codCatalago,String codDataCatalago){
		CatalogoValidaService catalogoService =(CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");

		if(!CollectionUtils.isEmpty(catalogoService.validarElementoCat(codCatalago, codDataCatalago))){
			return false;
		}
		else return true;
	}


/*
	public DetCtrlCamDAO getDetCtrlCamDao() {
		return detCtrlCamDao;
	}

	public void setDetCtrlCamDao(DetCtrlCamDAO detCtrlCamDao) {
		this.detCtrlCamDao = detCtrlCamDao;
	}
*/
	//	public MrestriDAO getMRestriDao() {
	//		return MRestriDao;
	//	}
	//
	//	public void setMRestriDao(MrestriDAO restriDao) {
	//		MRestriDao = restriDao;
	//	}

	//	public TablNewDAO getTablNewDao() {
	//		return tablNewDao;
	//	}
	//
	//
	//
	//
	//	public void setTablNewDao(TablNewDAO tablNewDao) {
	//		this.tablNewDao = tablNewDao;
	//	}



/*
	public CabMrDocAutorizDAO getCabMrDocAutorizDao() {
		return cabMrDocAutorizDao;
	}




	public void setCabMrDocAutorizDao(CabMrDocAutorizDAO cabMrDocAutorizDao) {
		this.cabMrDocAutorizDao = cabMrDocAutorizDao;
	}

	public DocAutAsociadoDAO getDocAutAsocDao() {
		return docAutAsocDao;
	}

	public void setDocAutAsocDao(DocAutAsociadoDAO docAutAsocDao) {
		this.docAutAsocDao = docAutAsocDao;
	}

	public CatalogoValidaService getCatalogoService() {
		return catalogoService;
	}

	public void setCatalogoService(CatalogoValidaService catalogoService) {
		this.catalogoService = catalogoService;
	}

	public CatalogoHelperImpl getCatalogoHelper() {
		return catalogoHelper;
	}

	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}
*/

	@ServicioAnnot(tipo="V",codServicio=3254, descServicio="valida las mercancias probidas de la serie")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","codTransaccion"})
	@OrquestaDespaAnnot(codServInstancia=3254,numSecEjec=427,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String,String>>  validarMercanciaProhibida(Declaracion declaracion,String codTransaccion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DimerproDAO dimerproDao = (DimerproDAO)fabricaDeServicios.getService("dimerproDAO");
		
		boolean usarCodigoNuevo = false;
		Date fecVigencia = SunatDateUtils.getDate(catalogoAyudaService.getElementoCat("517", "FEC_INIVIG").get("des_datacat").toString());

		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			usarCodigoNuevo = true;
		}

		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>() ;


		String codRegimen=declaracion.getDua().getCodregimen();
		String codAduanaOrden=declaracion.getDua().getCodaduanaorden();
		if(SunatStringUtils.isStringInList(codRegimen, "10,20,21,70")){

			if(!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())){
				for(DatoSerie serie:declaracion.getDua().getListSeries()){


					String codExoneracion=serie.getMercancia()!=null?serie.getMercancia().getCodexoneracion():null;
					DatoDocTransporte docTransporte= getDocTransporte(declaracion.getDua(),serie);
					Date fecEmbarque=docTransporte!=null?docTransporte.getFecembarque():null;
					Integer iFecEmbarque=SunatDateUtils.getIntegerFromDate(fecEmbarque);

					String codiregi=codRegimen;
					String cadenaValidar="20,21";
					if(usarCodigoNuevo){
						cadenaValidar="10,20,21";
					}
					if(SunatStringUtils.isStringInList(codRegimen, cadenaValidar))
						codiregi="10";


					Map<String,Object> param= new HashMap<String, Object>();

					String numpartida= "";
					if(serie.getNumpartnandi()!=null)
						numpartida=Cadena.padLeft(serie.getNumpartnandi().toString(),10,'0');

					param.put("cnan", numpartida);
					param.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
					param.put("codiregi", codiregi);


					List<Dimerpro> lstProhib= dimerproDao.listByParameterMap(param);
					if(!CollectionUtils.isEmpty(lstProhib)){
						for(Dimerpro prohibida:lstProhib){
							int mProhibe = 0 ;
							if(SunatStringUtils.isEqualTo("00", prohibida.getCprod())){
								/*RIN14-F2_3003 : Inicio*/
								if(usarCodigoNuevo){
									lstErrores.add(getDUAError("35345", new Object[]{numpartida}));
								}else{
									lstErrores.add(getDUAError("00143", new Object[]{serie.getNumserie()}));
								}								
								/*RIN14-F2_3003 : Fin*/
								break;
							}

							/*RIN14-F2_3003 : Inicio*/
							if(usarCodigoNuevo){
								if(!SunatStringUtils.isEqualTo("00", prohibida.getCprod()) ){
									if ( SunatStringUtils.isStringInList(codExoneracion, "98,97") ) {
										mProhibe = 0;
									}else{
										lstErrores.add(getDUAError("35346", new Object[]{serie.getNumserie()}));
									}
								}

								if(SunatStringUtils.isEqualTo(serie.getCodtnan(), prohibida.getTnan()))
								{
									lstErrores.add(getDUAError("35347", new Object[]{numpartida}));
								}

								if(SunatStringUtils.isEqualTo(prohibida.getSestMerca(), serie.getCodestamerca()))
								{
									lstErrores.add(getDUAError("35348", new Object[]{prohibida.getSestMerca()}));
								}

								if( !SunatStringUtils.isEmptyTrim(prohibida.getCpais()) &&
										SunatStringUtils.isEqualTo(serie.getCodpaisorige(), prohibida.getCpais()) )
								{
									String desPais = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_NACIONALIDAD, prohibida.getCpais());
									lstErrores.add(getDUAError("35349", new Object[]{ serie.getNumserie().toString(), prohibida.getCpais().concat(" - ").concat(desPais) }));
								}
								if( !SunatStringUtils.isEmpty(prohibida.getCodiAduan()) &&
										SunatStringUtils.isEqualTo(codAduanaOrden, prohibida.getCodiAduan()) )
								{
									String desAduana = catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_CODIGO_ADUANA, prohibida.getCodiAduan());
									lstErrores.add(getDUAError("35350", new Object[]{ serie.getNumserie().toString(), prohibida.getCodiAduan().concat(" - ").concat(desAduana) }));
								}
								if( SunatStringUtils.isEqualTo(numpartida, Constants.SPN_ARTICULO_PREFERENCIA) &&
										!SunatStringUtils.isEqualTo(declaracion.getDua().getCodtipotratamiento(), "4") )
								{
									lstErrores.add(getDUAError("35351", new Object[]{serie.getNumserie().toString()}));
								}	
							}else{
								if(!SunatStringUtils.isEqualTo("00", prohibida.getCprod())
										&& SunatStringUtils.isEqualTo("98", codExoneracion)	
										){
									mProhibe = 0; 
								}


								if(!SunatStringUtils.isEqualTo("00", prohibida.getCprod())
										&& !SunatStringUtils.isEqualTo("98", codExoneracion)	
										){
									lstErrores.add(getDUAError("00143", new Object[]{serie.getNumserie()}));
									break;
								}



								if(SunatStringUtils.isEmptyTrim(prohibida.getCpais()) ||
										!SunatStringUtils.isEqualTo(prohibida.getCpais(), "BE")
										){


									if(SunatStringUtils.isEqualTo(prohibida.getCtratfec(), "1")){
										if(SunatNumberUtils.isGreaterThanParam(iFecEmbarque, prohibida.getFverifica())){
											mProhibe=1;
										}	
									}

									if(!SunatStringUtils.isEmpty(prohibida.getCnan()) 
											&& SunatNumberUtils.toLong(prohibida.getCnan())>0 ){


										if(SunatNumberUtils.isEqual(serie.getNumpartnandi(), SunatNumberUtils.toLong(prohibida.getCnan()))
												&& SunatStringUtils.isEqualTo(serie.getCodtnan(), prohibida.getTnan()) ){
											mProhibe=1;
										}

									}	


									if(!SunatStringUtils.isEmpty(prohibida.getSestMerca())){
										if(SunatStringUtils.isEqualTo(serie.getCodestamerca(), prohibida.getSestMerca())){
											mProhibe=1; 
										}
									}


									if(!SunatStringUtils.isEmpty(prohibida.getCpais())){
										if(SunatStringUtils.isEqualTo(serie.getCodpaisorige(),prohibida.getCpais())){
											mProhibe=1;
										}
									}


									if(!SunatStringUtils.isEmpty(prohibida.getCodiAduan())){
										if(SunatStringUtils.isEqualTo(codAduanaOrden, prohibida.getCodiAduan())){
											mProhibe=1;
										} 
									}


								}

								else{

									if(!SunatNumberUtils.isEqual(serie.getNumpartnandi(), SunatNumberUtils.toLong(prohibida.getCnan()) )
											|| !SunatStringUtils.isEqualTo(serie.getCodtnan(), prohibida.getTnan())
											|| !SunatStringUtils.isEqualTo(serie.getCodpaisorige(), prohibida.getCpais())		
											){
										mProhibe=0;
									}

								}


								if(mProhibe==1){
									lstErrores.add(getDUAError("00143", new Object[]{serie.getNumserie()}));
									break;

								}
							}  
						}

					}

				}
			}

		}
		//EJHM P46 correccion a bug de mensajes repetidos
		return eliminarRepetidosDeListaErroresPK(lstErrores);

	}
	//INICIO EJHM P46
	private List<Map<String,String>> eliminarRepetidosDeListaErroresPK(List<Map<String,String>> lstErrores)
			throws ServiceException {
		List<Map<String,String>> lstErroresNoRepetido = new java.util.ArrayList<Map<String,String>>();
		Map<String, Object> mapNoRepetido = new HashMap<String, Object>(lstErrores.size());
		for(Map<String,String> p : lstErrores) {
			mapNoRepetido.put(p.get("codError")+p.get("codTipAlerta")+p.get("desError"), p);
		}
		for(Entry<String, Object> p : mapNoRepetido.entrySet()) {
			lstErroresNoRepetido.add((Map<String,String>)p.getValue());                              
		}
		lstErrores.clear();
		lstErrores.addAll(lstErroresNoRepetido);

		return lstErrores;
	}
	//FIN EJHM P46

	protected DatoDocTransporte getDocTransporte(DUA dua, DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		String numDocTransporte="";
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if ("3".equals(serieDoc.getCodtipodocsoporte()))
				numDocTransporte=String.valueOf(serieDoc.getNumiddocsoporte());
		}
		for(DatoDocTransporte docTransp:dua.getListDocTransporte()){
			if (numDocTransporte!=null){
				if (numDocTransporte.equals(String.valueOf(docTransp.getNumsecdoctrans())))
					return docTransp;
			}
		}
		return null;
	}

	/*
	public DimerproDAO getDimerproDao() {
		return dimerproDao;
	}

	public void setDimerproDao(DimerproDAO dimerproDao) {
		this.dimerproDao = dimerproDao;
	}

	public MrestriDAOService getMrestriDAOService() {
		return mrestriDAOService;
	}

	public void setMrestriDAOService(MrestriDAOService mrestriDAOService) {
		this.mrestriDAOService = mrestriDAOService;
	}

	public TablnewDAOService getTablnewDAOService() {
		return tablnewDAOService;
	}

	public void setTablnewDAOService(TablnewDAOService tablnewDAOService) {
		this.tablnewDAOService = tablnewDAOService;
	}



	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}



	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

*/

}
