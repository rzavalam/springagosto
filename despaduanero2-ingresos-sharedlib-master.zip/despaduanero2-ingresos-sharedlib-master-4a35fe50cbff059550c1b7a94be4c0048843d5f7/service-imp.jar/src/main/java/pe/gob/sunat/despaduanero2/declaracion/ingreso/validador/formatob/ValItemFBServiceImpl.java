package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.ayudas.model.CatRefpartidas;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.TipoDeDescrMinimaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.FormatoBUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.dudarazonable.model.CabDudaRazonable;
import pe.gob.sunat.despaduanero2.dudarazonable.model.DetDudaRazonable;
import pe.gob.sunat.despaduanero2.dudarazonable.service.DudaBusquedaService;
//import pe.gob.sunat.despaduanero2.model.Solicitud;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elemento;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
//import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;

public class ValItemFBServiceImpl extends ValDuaAbstract implements ValItemFB{

	//private FabricaDeServicios fabricaDeServicios;
	//private AyudaService ayudaService; 
	//private ValSerieItemFB  valSerieItem;
	
	/*
	public AyudaService getAyudaService() {
		return ayudaService;
	}

	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}


	public void setValSerieItem(ValSerieItemFB valSerieItem) {
		this.valSerieItem = valSerieItem;
	}
*/
	/**
	 * Validar que la secuencia de items no se repita y sea mayor a cero, es
	 * �nica a nivel de todo el formato B
	 * @param declaracion
	 * @return
	 */
	public Map<String, String> numsecitem(Declaracion declaracion) {
		Map<String, String> result = new HashMap<String, String>();

		if (declaracion.isExoneradoFB()) {
			return result;
		}

		int secuencia = 1;

		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura davfactura : dav.getListFacturas()){
				for (DatoItem davitem : davfactura.getListItems()){
					if (davitem.getNumsecitem() == null || davitem.getNumsecitem() != secuencia) {
						result = getErrorMap("05506",
								new Object[] { ((DAV) davitem.getPadre().getPadre()).getNumsecuprov(),
										((DatoFactura) davitem.getPadre()).getNumsecfactu(),
										davitem.getNumsecitem()!=null?davitem.getNumsecitem():" "});
					}
					secuencia++;
				}
			}
		}
		return result;
	}

	/**
	 * Validar codigo del pais de origen de mercanc�a declarado en el item 
	 * @param datoItem
	 * @return
	 */
	public Map<String, String> codpaisorige(DatoItem datoItem) {

		Map<String, String> result = new HashMap<String, String>();		

		if (((Declaracion) datoItem.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", datoItem.getCodpaisorige()));
		//if (!catalogoHelper.isValid(datoItem.getCodpaisorige(), "J2")){
		if (!validaCatalogo){
			result = getErrorMap("30147", 
					new Object[]{
							((DAV)datoItem.getPadre().getPadre()).getNumsecuprov(),
							((DatoFactura)datoItem.getPadre()).getNumsecfactu(),  
							datoItem.getNumsecitem(),
							datoItem.getCodpaisorige()});
		}

		return result;
	}

	/** Validar que sea un dato num�rico mayor a cero 
	 *  Se valida que se haya transmitido el valor FOB unitario 
	 * @param datoItem
	 * @return map
	 */	
	public Map<String, String> mtofobunita(DatoItem datoItem){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) datoItem.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}

		if (!SunatNumberUtils.isGreaterThanZero(datoItem.getMtofobunita())) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result = catalogoHelper.getErrorMap("30148",
                    new Object[] {                   
                    datoItem.getNumsecitem()!=null?datoItem.getNumsecitem():" ",
                    datoItem.getMtofobunita()!=null?datoItem.getMtofobunita():" "});*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			String numeroSecuenciaItem = (datoItem.getNumsecitem() != null) ? datoItem.getNumsecitem().toString() : " ";
			String montoFobUnitario = (datoItem.getMtofobunita() != null) ? datoItem.getMtofobunita().toString() : " ";
			result = catalogoAyudaService.getError("30148", new String[] {numeroSecuenciaItem, montoFobUnitario});

		}

		return result;
	}

	/**
	 * Validar que sea un dato num�rico mayor o igual a cero
	 * @param item
	 * @return
	 */
	//GGRANADOS FORMB
	public Map<String, String> mtoajusunita(DatoItem item) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}

		if (!SunatNumberUtils.isGreaterOrEqualsThanZero(item.getMtoajusunita()))
			result = catalogoAyudaService.getError("30149");
		return result;
	}

	/**
	 * Se valida que se haya transmitido la cantidad comercial de mercancia 
	 * @param item
	 * @return
	 */
	public Map<String, String> cntcantcomer(DatoItem item){

		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}

		if (!SunatNumberUtils.isGreaterThanZero(item.getCntcantcomer())){
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result = catalogoHelper.getErrorMap("30150",
                    new Object[] { 
                    item.getNumsecitem(), 
                    item.getCntcantcomer() });*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String numeroSecuenciaItem = (item.getNumsecitem() != null) ? item.getNumsecitem().toString() : " ";
			String cantidadComercial = (item.getCntcantcomer() != null) ? item.getCntcantcomer().toString() : " ";
			result = catalogoAyudaService.getError("30150", new String[] {numeroSecuenciaItem, cantidadComercial});
		}

		return result;
	}

	/**
	 * Validar que exista en la tabla CAT_REFPARTIDAS, en caso contario validar
	 * en funcion del Catalogo, la clase debe heredar las funciones del Modelo
	 * de catalogos. Si existe en la tabla CAT_REFPARTIDAS, REFes 'KV' y
	 * codunidcomer no es '12U', 'GRU', 'MLL' o 'ZZZ' se genera el mensaje de
	 * error 0062; si codunidcomer es 'ZZZ' y la longitud del valor del campo
	 * obsdeclaracion del segmento DatosObservaciones es menor a 5 caracteres se
	 * genera el mensaje de error 1150.Si REF es 'CA' y codunidcomer no es
	 * '12U', '2U' o 'U' se genera el mensaje de error 0062
	 */
	public List<Map<String, String>> codunidcomer(DatoItem item) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();		

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}   

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tipoUso", "DVA");
		params.put("capitulo", SunatStringUtils.substringFox(item.getNumpartnandi().toString(), 1, 4));
		params.put("finivig", SunatNumberUtils.getTodayAsInteger());
		params.put("ffinvig", SunatNumberUtils.getTodayAsInteger());

		//List<CatRefPartida> catRefPartidas = new ArrayList<CatRefPartida>();
		//List<CatRefPartida> catRefPartidasTmp = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);

		List<CatRefpartidas> catRefPartidas = new ArrayList<CatRefpartidas>();

		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> catRefPartidasTmp =  (List<CatRefpartidas>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).getCatRefPartidas(params);



		if(catRefPartidasTmp != null)
			catRefPartidas.addAll( catRefPartidasTmp );

		params.remove("capitulo");
		params.put("cnan", item.getNumpartnandi());

		//catRefPartidasTmp = FormatoBServiceImpl.getInstance().getCatRefPartidasDAO().getCatRefPartidas(params);

		params.put("ayudaID", "CatRefpartidas");
		List<CatRefpartidas> catRefPartidTmp =  (List<CatRefpartidas>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).getCatRefPartidas(params);


		if(catRefPartidTmp != null)
			catRefPartidas.addAll( catRefPartidTmp );

		if(catRefPartidas != null && catRefPartidas.size() > 0)
		{
			for (CatRefpartidas catRefPartida : catRefPartidas) {
				if( SunatStringUtils.isEqualTo(catRefPartida.getRef(), "KV") ) //(si corresponde a Anillos para ojetes)
				{
					if(! SunatStringUtils.isStringInList(item.getCodunidcomer(), "12U,GRU,MLL,ZZZ"))
					{
						result.add(  catalogoAyudaService.getError("0062") );
					}else if(SunatStringUtils.isEqualTo(item.getCodunidcomer(), "ZZZ")){
						for(Observacion obs:item.getListObservaciones())
						{
							if(! SunatStringUtils.isLengthGreaterThanNumber(obs.getObsdeclaracion(), 4))
							{
								result.add(  catalogoAyudaService.getError("1150") );
							}
						}
					}
				}else if( SunatStringUtils.isEqualTo(catRefPartida.getRef(), "CA")
						&& ! SunatStringUtils.isStringInList(item.getCodunidcomer(), "12U,2U,U") ){
					result.add(  catalogoAyudaService.getError("0062") );
				}
			}
		}else{
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("29", item.getCodunidcomer()));
			//if(! catalogoHelper.isValid(item.getCodunidcomer(), "29") )
			if(!validaCatalogo )
				result.add(  catalogoAyudaService.getError("5570") );	
		}

		return result;
	}

	/**
	 * Validar codigo del pais de de adquisici�n 
	 * @param item
	 * @return
	 */
	public Map<String, String> codpaisadqui(DatoItem item) {

		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}	
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", item.getCodpaisadqui()));
		//if (!catalogoHelper.isValid(item.getCodpaisadqui(), "J2")){
		if (!validaCatalogo){
			result = getErrorMap("30151", 
					new Object[]{
							((DAV)item.getPadre().getPadre()).getNumsecuprov(),
							((DatoFactura)item.getPadre()).getNumsecfactu(),  
							item.getNumsecitem(),
							item.getCodpaisadqui()});
		}

		return result;
	}

	/**
	 * Si de la funci�n TipoMercancia definido en la fila 389, se obtiene el
	 * cTipo_Merc<>'K9', validar que se envie un dato texto de longitud mayor a
	 * 10 caracteres
	 */
	//GGRANADOS FORMB
	public Map<String, String> descomercial(DatoItem item) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}   

		String mCaraTipo = "";
		for (DatoDescrMinima descrMinima : item.getListDecrMinima()) {
			if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "03") )
				mCaraTipo = descrMinima.getValtipdescri();			
		}		

		String tipoMerc = funcionesService.fnTipo(item.getNumpartnandi().toString(), item.getDescomercial(), mCaraTipo,
				SunatNumberUtils.getTodayAsInteger());

		if (!SunatStringUtils.isEqualTo(tipoMerc, "K9")) {
			if (!SunatStringUtils.isLengthGreaterOrEqualsThanNumber(item.getDescomercial(), 10))
				result = catalogoAyudaService.getError("05571");
		}

		return result;
	}

	/**
	 * 
	 * @param item
	 * @return
	 */
	//GGRANADOS FORMB
	public Map<String, String> desmarca(DatoItem item) {
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}   

		if (!SunatStringUtils.isLengthGreaterThanNumber(item.getDesmarca(), 0))
			result = getErrorMap("30152",new Object[]{item.getNumsecitem().toString()});//adicionado bug 19858
		return result;
	}

	/*
	//GGRANADOS FORMB
	public Map<String, String> desmodelo(String arg) {
		Map<String, String> result = new HashMap<String, String>();

//		if (!SunatStringUtils.isLengthGreaterThanNumber(arg, 10))
//			//TODO Actualizar M�todo de grabaci�n de Error/Alerta
//			result = catalogoHelper.getErrorMap("30153");

		return result;
	}*/

	/**
	 * Validar que sea un dato vacio o de enviarse un dato tipo a�o del formato
	 * AAAA
	 * @param item
	 * @return
	 */
	//ggranados correcion de validacion, puede ser ano como aro.
	public Map<String, String> annfabrica(DatoItem item) {

		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}	

		if (SunatStringUtils.isEmpty(item.getAnnfabrica())) {
			return result;
		}

		if (!SunatStringUtils.isNumeric(item.getAnnfabrica()) || SunatStringUtils.isLengthGreaterThanNumber(item.getAnnfabrica(), 4)){
			//glazaror... hacemos uso de catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String numeroSecuenciaItem = (item.getNumsecitem() != null) ? item.getNumsecitem().toString() : " ";
			String anioFabricacion = (item.getAnnfabrica() != null) ? item.getAnnfabrica().toString() : " ";
			result = catalogoAyudaService.getError("30154", new String[] {numeroSecuenciaItem, anioFabricacion});
		}

		return result;
	}

	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos
	 */
	public Map<String, String> codestamer(DatoItem item) {
		Map<String, String> result = new HashMap<String, String>();

		if ( ((Declaracion)item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}		
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("25", item.getCodestamer()));
		//if (!catalogoHelper.isValid(item.getCodestamer(), "25")){
		if (!validaCatalogo){
			result = getErrorMap("30155", 
					new Object[]{
							((DAV)item.getPadre().getPadre()).getNumsecuprov(),
							((DatoFactura)item.getPadre()).getNumsecfactu(),  
							item.getNumsecitem(),
							item.getCodestamer()});
		}
		return result;
	}
	

	@ServicioAnnot(tipo = "V", codServicio = 3506, descServicio = "Valida el estado de la mercanc�a del item, cuando se declare como otros")
	@Override
	public Map<String, String> codEstaMerOtros(DatoItem item){
		Map<String, String> result = new HashMap<String, String>();
		
		if (((Declaracion)item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
		    return result;
		}
		
		if (!SunatStringUtils.isEmptyTrim(item.getCodestamer()) && item.getCodestamer().equals("99") && 
        		SunatStringUtils.isEmptyTrim(item.getDesEstMer())) {
        	result =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
        			"37103", new String[] {item.getNumsecitem().toString()});
        }
		
		return result;
	}

	
	
	/**
	 * Validar que se haya transmitido la unidad comercial de mercancia, el valor debe estar de acuerdo con el cat�logo 29
	 * @param item
	 * @return map
	 *  
	 */
	public Map<String, String> validarUnidadComercial (DatoItem item) {
		//glazaror... invocamos al nuevo metodo para mantener la logica en un solo metodo
		return validarUnidadComercial(item, null);
	}

	//glazaror... validarUnidadComercial optimizado
	public Map<String, String> validarUnidadComercial (DatoItem item, Map<String, Object> variablesIngreso) {

		Map<String, String> result = new HashMap<String, String>();

		if ( ((Declaracion)item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}
		if (variablesIngreso != null) {
			//glazaror... hacemos uso del utilitario IngresoVariablesUtil
			if (!IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, "29", item.getCodunidcomer(), variablesIngreso)) {
				//glazaror... hacemos uso de catalogoAyudaService.getError
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				String numeroSecuenciaItem = (item.getNumsecitem() != null) ? item.getNumsecitem().toString() : " ";
				String unidadComercial = (item.getCodunidcomer() != null) ? item.getCodunidcomer().toString() : " ";
				result = catalogoAyudaService.getError("30629", new String[] { numeroSecuenciaItem, unidadComercial});
			}

		} else {
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("29", item.getCodunidcomer()));
			//if(!catalogoHelper.isValid(item.getCodunidcomer(), "29") ){
			if(!validaCatalogo ){
				result = getErrorMap("30629", 
						new Object[]{
								item.getNumsecitem(),					
								item.getCodunidcomer()});					
			}
		}
		return result;
	}



	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Modelo de catalogos
	 */
	/*	public List<Map<String, String>> indsoftware(DatoItem item, Declaracion declaracion) {
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();

		String codigoRegimen = declaracion.getDua().getCodregimen();

		Timestamp pFecha = new Timestamp(System.currentTimeMillis());

		if (SunatStringUtils.isEqualTo(codigoRegimen, "10")) {
			Integer vigencia = funcionesService.getVigenciaCambio("983", codigoRegimen, "TD000", "000033", pFecha);

			if (vigencia == 1) {
				if (!SunatStringUtils.isEqualTo(item.getIndsoftware(), "3") && !SunatStringUtils.isEmpty(item.getIndsoftware()))
					result.add( catalogoHelper.getErrorMap("1325") );
				else {

					Integer partidaSoftware = funcionesService.getCountPartidaSoftware(item.getNumpartnandi(), pFecha);
					if (SunatStringUtils.isEqualTo(item.getIndsoftware(), "3") && partidaSoftware == 0)
						result.add( catalogoHelper.getErrorMap("1326") );
				}

				if (!catalogoHelper.isValid(item.getIndsoftware(), "342"))
					result.add( catalogoHelper.getErrorMap("5573") );
			}
		}

		return result;
	}*/
	/**
	 * 
	 * @param item
	 * @return
	 */
	//GGRANADOS FORMB
	public Map<String, String> indvarios(DatoItem item){

		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}

		if (SunatStringUtils.isEmpty(item.getIndvarios()))
			return result;
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("343",item.getIndvarios()));
		//if ((!SunatStringUtils.isStringInList(item.getIndvarios(), "3,4")) || (!catalogoHelper.isValid(item.getIndvarios(), "343")))
		if ((!SunatStringUtils.isStringInList(item.getIndvarios(), "3,4")) || !validaCatalogo)
			result = getErrorMap("30157", 
					new Object[] { 
							item.getNumsecitem(), 
							item.getIndvarios() });
		return result;
	}

	/**
	 * Si el campo indvarios tiene un valor diferente a '4', verificar que sea
	 * un dato num�rico mayor a cero, sino generar el mensaje de error 5582, si
	 * el valor de los campos mtofobunita*cntcantcomer es diferente a mtofobitem
	 * y mtofobitem/cntcantcomer es diferente a mtofobunita se genera el mensaje
	 * de error 5583
	 */
	//GGRANADOS FORMB
	public List<Map<String, String>> mtofobitem(DatoItem datoItem) {

		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

		if (((Declaracion) datoItem.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return listErr;
		}

		//glazaror... hacemos referencia a catalogoAyudaService para obtener descripcion de errores
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		if (SunatStringUtils.isEqualTo(datoItem.getIndvarios(), "4")
				&& !SunatNumberUtils.isGreaterThanZero(datoItem.getMtofobitem())) {
			//listErr.add(catalogoHelper.getErrorMap("05582"));
			//glazaror... hacemos uso de catalogoAyudaService.getError
			listErr.add(catalogoAyudaService.getError("05582"));
		}

		if (datoItem.getMtofobunita() != null && datoItem.getCntcantcomer() != null && 
				SunatNumberUtils.isGreaterThanZero(datoItem.getCntcantcomer())) {
			BigDecimal tempMultiply = datoItem.getMtofobunita().multiply(datoItem.getCntcantcomer()).setScale(6, RoundingMode.HALF_UP);
			BigDecimal tempDivide = datoItem.getMtofobitem().divide(datoItem.getCntcantcomer(),6,RoundingMode.HALF_UP);

			if (!SunatNumberUtils.isEqual(datoItem.getMtofobitem(), tempMultiply) && 
					!SunatNumberUtils.isEqual(datoItem.getMtofobunita(), tempDivide)) {
				//glazaror... evitamos el uso de catalogoHelper.getErrorMap
				/*listErr.add(catalogoHelper.getErrorMap("05583",
                        new Object[] { 
                        datoItem.getNumsecitem(), 
                        SunatStringUtils.toStringObj(datoItem.getMtofobitem().setScale(6, RoundingMode.HALF_UP)) }));*/

				//glazaror... hacemos uso de catalogoAyudaService.getError
				String numeroSecuenciaItem = (datoItem.getNumsecitem() != null) ? datoItem.getNumsecitem().toString() : " ";
				String monto = SunatStringUtils.toStringObj(datoItem.getMtofobitem().setScale(6, RoundingMode.HALF_UP));
				listErr.add(catalogoAyudaService.getError("05583", new String[] {numeroSecuenciaItem, monto}));
			}

		} else {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*listErr.add(catalogoHelper.getErrorMap("05583",
                    new Object[] { 
                    datoItem.getNumsecitem()!=null?datoItem.getNumsecitem():" ", 
                    datoItem.getMtofobitem()!=null?SunatStringUtils.toStringObj(datoItem.getMtofobitem().setScale(6, RoundingMode.HALF_UP)):" " }));*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			String numeroSecuenciaItem = (datoItem.getNumsecitem() != null) ? datoItem.getNumsecitem().toString() : " ";
			String monto = datoItem.getMtofobitem()!=null?SunatStringUtils.toStringObj(datoItem.getMtofobitem().setScale(6, RoundingMode.HALF_UP)):" ";
			listErr.add(catalogoAyudaService.getError("05583", new String[] {numeroSecuenciaItem, monto}));

		}

		//Ini RIN10 - AMANCILLA BUG 21621
		String codRegimen = ((Declaracion) datoItem.getPadre().getPadre().getPadre()).getDua().getCodregimen();
		if("10".equals(codRegimen) && datoItem.getMontoProv()!=null){
			String tipoValorProvisional = datoItem.getMontoProv().getIndtipovalor()!=null?datoItem.getMontoProv().getIndtipovalor():"";
			if(Constantes.IND_VALOR_DEFINITIVO.equals(tipoValorProvisional)){


				BigDecimal mtoFobUnitario = datoItem.getMtofobunita();

				//amancilla PAS20155E220200167
				BigDecimal mtoAjuste = datoItem.getMtoajusunita()!=null?datoItem.getMtoajusunita():BigDecimal.ZERO;
				BigDecimal mtoTotalFobAjustado = mtoFobUnitario.add(mtoAjuste);

				BigDecimal mtoFobDefinitivo = datoItem.getMontoProv().getValdefinitivo();
				if(tieneMtoValido(mtoFobDefinitivo) && tieneMtoValido(mtoFobUnitario)
						&& !SunatNumberUtils.isEqual(mtoFobDefinitivo,mtoTotalFobAjustado)) {

					//FALTA REGISTRAR EL CATALOGO
					//EL VALOR DEFINITIVO {0} DEL ITEM {1} DEBE SER IGUAL AL FOB UNITARIO {2} + AJUSTES {3}
					listErr.add(getErrorMap("35543", new Object[] {
							SunatStringUtils.toStringObj(mtoFobDefinitivo.setScale(6, RoundingMode.HALF_UP)),
							datoItem.getNumsecitem(),SunatStringUtils.toStringObj(mtoFobUnitario.setScale(6, RoundingMode.HALF_UP))
							,SunatStringUtils.toStringObj(mtoAjuste.setScale(6, RoundingMode.HALF_UP))}));
				}

			}
		}
		//fin RIN10 - amancilla

		return listErr;
	}


	//Ini RIN10 - AMANCILLA BUG 21621
	private boolean tieneMtoValido(BigDecimal valmonto) {

		return valmonto!=null && valmonto.compareTo(BigDecimal.ZERO)==1?true:false;
	}

	//Fin RIN10 - AMANCILLA BUG 21621
	/**
	 * Validar que la partida Exista en el Arancel 
	 * @param item
	 * @param fechaReferencia
	 * @return
	 */
	//GGRANADOS FORMB
	public Map<String, String> numpartnandi(DatoItem item, Date fechaReferencia) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}

		DatoSerieItem serie = item.getListSerieItems().get(0);

		String mCaraTipo = "";
		for (DatoDescrMinima descrMinima : item.getListDecrMinima()) {
			if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "03") )
				mCaraTipo = descrMinima.getValtipdescri();			
		}		

		String tipoMerc = funcionesService.fnTipo(item.getNumpartnandi().toString(), item.getDescomercial(), mCaraTipo, SunatNumberUtils.getTodayAsInteger());
		if(! SunatStringUtils.isEqualTo(tipoMerc, "**")){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("");
		}
		HashMap<String,Object> paramsNandtasa=new HashMap<String,Object>();
		paramsNandtasa.put("cnan", item.getNumpartnandi());
		Integer fechaReferenciaInt=SunatDateUtils.getIntegerFromDate(fechaReferencia);
		paramsNandtasa.put("finitas", fechaReferenciaInt);
		paramsNandtasa.put("ffintas", fechaReferenciaInt);
		//		NandTasaDAO nandtasaDAO=FormatoAServiceImpl.getInstance().getNandtasaDAO();
		//		if (nandtasaDAO.count(paramsNandtasa)==0)
		int contNandTasa=((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).count(paramsNandtasa);
		if (contNandTasa==0)
			result=getErrorMap("05038",new Object[]{serie.getNumserie(),item.getNumpartnandi().toString()});
		//result= catalogoHelper.getErrorMap("05038", new Object[] {serie.getNumserie().toString() }) ;
		return result;
	}

	/**
	 * 
	 * @param item
	 * @return
	 */
	public Map<String, String> inddeducdisti(DatoItem item){

		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("358", item.getInddeducdisti()));
		//if (!catalogoHelper.isValid(item.getInddeducdisti(), "358"))
		if (!validaCatalogo)
			result = getErrorMap("30159", new Object[]{
					((DAV)item.getPadre().getPadre().getPadre()).getNumsecuprov(),
					((DatoFactura)item.getPadre().getPadre()).getNumsecfactu(),  
					item.getNumsecitem(),
					item.getInddeducdisti()});

		return result;
	}

	//GGRANADOS FORMB
	public Map<String, String> descaracteristicas(DatoItem item) {
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}


		Date fechaVigencia = (item.getPadre()!=null && item.getPadre().getPadre().getPadre() instanceof Declaracion &&
				((Declaracion) item.getPadre().getPadre().getPadre()).getDua()!=null && 
				((Declaracion) item.getPadre().getPadre().getPadre()).getDua().getFecdeclaracion()!=null)?
						((Declaracion)item.getPadre().getPadre().getPadre()).getDua().getFecdeclaracion():null; 
						/*amancillaa solo se valida si no tiene desde minimas */						
						//boolean esPartidaDescMin = catalogoHelper.isValid(item.getNumpartnandi().toString(), Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN,fechaVigencia );
						boolean esPartidaDescMin = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, item.getNumpartnandi().toString(),fechaVigencia));
						//boolean esSubPartDescMin = catalogoHelper.isValid(SunatStringUtils.substring(item.getNumpartnandi().toString(), 0, 4),Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, fechaVigencia);
						boolean esSubPartDescMin = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, SunatStringUtils.substring(item.getNumpartnandi().toString(), 0, 4),fechaVigencia));

						if (esPartidaDescMin || esSubPartDescMin) {
							return result;
						}
						/*fin amancillaa*/
						if (SunatStringUtils.isEmpty(item.getDescaracteristicas())){
							CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
							result = catalogoAyudaService.getError("30160");
						}
						return result;
	}
	//GGRANADOS FORMB
	public Map<String, String> desclasevari(DatoItem item) {
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}

		Date fechaVigencia = (item.getPadre()!=null && item.getPadre().getPadre().getPadre() instanceof Declaracion &&
				((Declaracion) item.getPadre().getPadre().getPadre()).getDua()!=null && 
				((Declaracion) item.getPadre().getPadre().getPadre()).getDua().getFecdeclaracion()!=null)?
						((Declaracion)item.getPadre().getPadre().getPadre()).getDua().getFecdeclaracion():null; 

						/*amancillaa solo se valida si no tiene desde minimas */
						//boolean esPartidaDescMin = catalogoHelper.isValid(item.getNumpartnandi().toString(),Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN,fechaVigencia);
						boolean esPartidaDescMin = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, item.getNumpartnandi().toString(),fechaVigencia));
						//boolean esSubPartDescMin = catalogoHelper.isValid(SunatStringUtils.substring(item.getNumpartnandi().toString(), 0, 4),Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN,fechaVigencia);
						boolean esSubPartDescMin = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, SunatStringUtils.substring(item.getNumpartnandi().toString(), 0, 4),fechaVigencia));

						if (esPartidaDescMin || esSubPartDescMin) {
							return result;
						}
						/*fin amancillaa*/

						if (SunatStringUtils.isEmpty(item.getDesclasevari())){
							CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
							result = catalogoAyudaService.getError("30161");
						}
							

						return result;
	}

	/* GGRANADOS FORMB
	public Map<String, String> desusoaplica(String arg) {
		Map<String, String> result = new HashMap<String, String>();
//		if (SunatStringUtils.isEmpty(arg))
//			result = catalogoHelper.getErrorMap("30162");

		return result;
	}
	 */
	/* GGRANADOS FORMB
	public Map<String, String> desmaterialcomp(String arg) {
		Map<String, String> result = new HashMap<String, String>();

//		if (SunatStringUtils.isEmpty(arg))
//			result = catalogoHelper.getErrorMap("30163");

		return result;
	}
	 */
	/**
	 * "Verificar que si envio suministros gratuitos (DAVs.codnatutrans='14')
	 * debe indicar un valor fob unitario en los items
	 * (DatosItem.mtofobunita>0)"
	 * 
	 * @param item
	 * @return
	 */
	public Map<String, String> valgralitemfb1(DAV dav) {

		Map<String, String> result = new HashMap<String, String>();

		if(((Declaracion)dav.getPadre()).isExoneradoFB()){
			return result;
		}


		if (SunatStringUtils.isEqualTo(dav.getCodnatutrans(), "14")) {

			for (DatoFactura datoFactura : dav.getListFacturas()) {

				for (DatoItem item : datoFactura.getListItems()) {
					if (!SunatNumberUtils.isGreaterThanZero(item.getMtofobunita())) {
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						result = catalogoAyudaService.getError("01108");
					}
				}
			}
		}

		return result;
	}

	/* GGRANADOS FORMB
	public List<Map<String, String>> valgralitemfb2(DatoItem item, DAV dav, Declaracion declaracion) {
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		if (!(SunatStringUtils.isEqualTo(declaracion.getDua().getCodregimen(), Constants.REGIMEN_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO.toString()) && SunatStringUtils
				.isEqualTo(declaracion.getDua().getCodtipoperacion(), "2005"))) { //ESantana
			// invocar fpAnoCarro valgralitemfb3
			//listErr.addAll( valgralitemfb3(dav, declaracion) );
		}

		return listErr;
	}*/

	/**
	 * Funcion fpAnoCarro Aplicar la referencia de la ingenieria en reversa
	 * 
	 */
	public  List<Map<String, String>>  valgralitemfb3(DAV dav, Declaracion declaracion) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>();

		if(declaracion.isExoneradoFB()){
			return listErr;
		}

		//Esantana
		if (SunatStringUtils.isEqualTo(declaracion.getDua().getCodregimen(), Constants.REGIMEN_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO.toString()) 
				&& SunatStringUtils.isEqualTo(declaracion.getDua().getCodtipoperacion(), "2005")) {				
			return listErr;
		}		 

		String numDocumento = null;
		String tipDocumento = null;

		Integer vigfec_carc = 99999999;
		Integer vigfec_embar = 99999999;
		Integer vigfec_peusa = 0;
		Integer fechaIngSi = 0;

		// Cuando no es Numeracion la fecha de referencia o fecha de ingreso es la fecha de la Declaracion
		if (declaracion.getNumdeclRef() != null) {
			fechaIngSi = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
		} else {
			fechaIngSi = SunatNumberUtils.getTodayAsInteger();
		}
		Integer flag_tpn=0;
		//for (DatoPago pago : declaracion.getDua().getListPagos())
		//for (DatoPagoTrans pagotrans : declaracion.getDua().getPago().getListPagoTransacciones())
		DatoPago pago=declaracion.getDua().getPago();
		DatoPagoTrans trans=pago!=null?pago.getPagoTransaccion():null;
		Date feccarcr=trans!=null?trans.getFeccarcr():null;		

		if( feccarcr != null )
			vigfec_carc = SunatDateUtils.getIntegerFromDate(feccarcr);

		//for (Datodeclarante declarante : declaracion.getDua().getListDeclarantes()) {
		if (SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getTipoParticipante().getCodDatacat(), "45")) {
			numDocumento = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
			tipDocumento = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		}
		//}

		if (funcionesService.existsInEmpresasPublicas(tipDocumento, numDocumento)) {
			return listErr; //TODO validar el error
		}

		for (DatoSerie serie : declaracion.getDua().getListSeries()) {

			Map<String, Elemento> resultado = getItemCorrespondienteAsMap(serie, declaracion);
			DatoItem item = (DatoItem) resultado.get("item");
			DatoFactura factura = (DatoFactura) resultado.get("factura");

			/*if( item == null){

				listErr.add( getCatalogoHelper().getErrorMap("30348", new Object[]{serie.getNumserie()} ) );

			}else{ ya se valida en el metodo ValSerieItemFB.verificarSerieFormatoAEstaEnFormatoB */ 
			if( item != null){
				String mCaraTipo = "";
				String mClasVari = "";
				String mUsoAplic = "";

				for (DatoDescrMinima descrMinima : item.getListDecrMinima()) {
					if (SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "03"))
						mCaraTipo = descrMinima.getValtipdescri();
					else if (SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "04"))
						mClasVari = descrMinima.getValtipdescri();
					else if (SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "05"))
						mUsoAplic = descrMinima.getValtipdescri();
				}

				Integer fechaEmbarque = 0;
				//for(DatoDocTransporte docTransporte: declaracion.getDua().getListDocTransporte() )
				//{/// obtener por docsoporte
				DatoDocTransporte docTransp=getDocTransporte(declaracion.getDua(),serie);

				if (docTransp!=null){
					Date fecEmbarque=docTransp.getFecembarque();
					if (fecEmbarque!=null){
						fechaEmbarque = SunatDateUtils.getIntegerFromDate(docTransp.getFecembarque());

					}
				}


				//}

				Integer lnFechaEmbarque = 0;			

				if (SunatStringUtils.isStringInList(item.getCodestamer(), "20,21,22,23,24,25,26,27,28")) {
					if (fechaEmbarque == 20050714 || fechaEmbarque == 20050715)
						lnFechaEmbarque = 20050713;
					else
						lnFechaEmbarque = fechaEmbarque;

					String paisProce = factura.getCodpaisembar();

					if (funcionesService.existsInMRestri("98", serie.getNumpartnandi().toString(), lnFechaEmbarque)) {
						Integer auxn = 0;
						boolean du50 = false;

						if (vigfec_carc > 0) {
							if (funcionesService.hasVigenciaCriterio("1035", vigfec_carc) && funcionesService.hasVigenciaCriterio("1035", fechaEmbarque))
								du50 = true;

							if (funcionesService.hasVigenciaCriterio("1036", vigfec_carc) && funcionesService.hasVigenciaCriterio("1036", fechaEmbarque))
								auxn = 1;

						} else {
							if (funcionesService.hasVigenciaCriterio("1035", fechaEmbarque))
								du50 = true;

							if (funcionesService.hasVigenciaCriterio("1036", fechaEmbarque))
								auxn = 1;

						}

						if (funcionesService.hasVigenciaCriterio("1037", fechaIngSi) && SunatStringUtils.isEqualTo(item.getCodestamer(), "28")
								&& SunatStringUtils.isEqualTo(paisProce, "US")) {
							return listErr;
						}

						BigDecimal vehesp = serie.getValpreciovta();

						if (SunatNumberUtils.isEqual(vehesp, new BigDecimal(1))) {

							CatRefpartidas catRefPartida = funcionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig("VIA", serie.getNumpartnandi().toString(), fechaEmbarque);
							if( catRefPartida != null ) {
								du50 = false;
								auxn = 0;
							} else {
								/**
								 * GrabaTelelog (" ", " ", "5798", "SERIES PART_NANDI: ENVIADO-"+A_CADENA(Tempo2.part_nandi,10)+" NO CORRESPONDE AL TIPO DE USO PARA VEHICULOS ESPECIALES" )
								 */
								listErr.add( getErrorMap("5798", serie.getNumpartnandi()) );
							}
						}

						if (serie.getCodtratprefe() > 0) {
							// a. **TPNS libres de validar prohibicion
							boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("TV",SunatStringUtils.toStringObj(serie.getCodtratprefe())));
							//if (catalogoHelper.existsTratamiento("TV", serie.getCodtratprefe()))
							if (validaCatalogo)
								du50 = false;

							// e. **TPNS libres de computo de anos
							validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("TW",SunatStringUtils.toStringObj(serie.getCodtratprefe())));
							//if (catalogoHelper.existsTratamiento("TW", serie.getCodtratprefe()))
							if (validaCatalogo)
								auxn = 0;
						}

						/*sql=" select cdocumen from cat_refruc where ctipo_uso='CAU'"+;
						        " and ctipodoc='"+xTipo_Docum+"' and cdocumen='"+xNume_Docum+"' "+;
						     " and TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD')) BETWEEN finivig and ffinvig " +;
						     " and tlib='T' and clib='"+str(Tempo2->trat_prefe,4)+"'"
						 =sqlejecuta(PROGRAM(),LINENO(), SQL, "cCurtmp" )
						 IF (RECCOUNT()>0) THEN
						   IF xNume_Docum=cCurtmp.cdocumen THEN
						       auxn=0
						       flag_tpn=1
						   ENDIF
						 ENDIF      
						 &&FIN-VCA30072009
						  ENDIF*/

						if (funcionesService.existsInCatRefRuc(new String[] { "CAU" }, serie.getCodtratprefe().toString(), tipDocumento, numDocumento,"")) {
							auxn=0;
							flag_tpn=1;
						}

						// 14. mEncend = SUBSTR(wclas_vari,69,3)
						String mEncend = SunatStringUtils.substringFox(item.getDesclasevari(), 69, 3);
						String catego = SunatStringUtils.substringFox(item.getDescomercial(), 1, 2);
						BigDecimal mPesoBruto = serie.getCntpesobruto();

						CatRefpartidas refpartida = null;
						if (du50) {

						}

						// 21. Anno_TOPE= Al a�o de la Fecha de Embarque
						// (Tempo2.fech_embar)
						Integer anoTope = SunatNumberUtils.getAnioFromDate(fechaEmbarque);
						Integer lnAnosOld = 5;

						// 23. Se verifica si est� en la lista de partidas de
						// Veh�culos usados con dos a�os de antig�edad.
						refpartida = funcionesService.existsInRefPartidasByTipoUsoAndPartidaAndFechVig("VA1", serie.getNumpartnandi().toString(), fechaEmbarque);
						if (refpartida != null ) {
							lnAnosOld = (Integer) refpartida.getNumeroAnosAntiguedad();
						}

						if (auxn == 1) {
							// a. *Nuevo Anexo2 con tipo de encendido vigente a la
							// fecha de embarque
							refpartida = funcionesService.getRefPartidasByTipoUsoAndPartidaAndFechaVigAndTipoEnceAndTipoCate("VA7", serie.getNumpartnandi()
									.toString(), fechaEmbarque, mEncend, null);

							if (refpartida != null )
								lnAnosOld = refpartida.getNumeroAnosAntiguedad();
						}

						if (serie.getCodtratprefe() != 0) {
							// a. *Tipo_uso = VA3 (para 5 a�os de antiguedad como
							// m�ximo)
							refpartida = funcionesService.getRefPartidasByTipoUsoAndPartidaAndFechaVigAndCLib("VA3", serie.getNumpartnandi().toString(),
									fechaEmbarque, serie.getCodtratprefe().toString());

							if (refpartida != null )
								lnAnosOld = refpartida.getNumeroAnosAntiguedad();

							// e. *Tipo_uso = VA2 (para 8 a�os de antiguedad como
							// m�ximo)
							refpartida = funcionesService.getRefPartidasByTipoUsoAndPartidaAndFechaVigAndCLib("VA2", serie.getNumpartnandi().toString(),
									fechaEmbarque, serie.getCodtratprefe().toString());

							if (refpartida != null )
								lnAnosOld = refpartida.getNumeroAnosAntiguedad();

							// i. *Tipo_uso = VA6 (para 5 a�os de antiguedad entre
							// a�o de contrato y a�o de fabricaci�n)
							refpartida = funcionesService.getRefPartidasByTipoUsoAndAduanaAndPaisOrigenAndClib("VA6", declaracion.getCodaduana(), serie
									.getCodpaisorige(), serie.getCodtratprefe().toString(), serie.getNumpartnandi());

							if (refpartida != null ){
								lnAnosOld = refpartida.getNumeroAnosAntiguedad();
								anoTope = refpartida.getTasaRef().intValue();
							}

							/*       IF flag_tpn=1 &&Si es un RUC activo por medida cautelar deber� tomar su a�o de antiguedad segun la medida
							         SQL = "SELECT NUM_ANN_ANTIG ANNOS FROM cat_refpartidas WHERE tipo_uso='CAU' AND cnan="+;
							                STR(Tempo2->part_nandi,10)+" AND "+STR(Tempo2->fech_embar,8)+;
							               " BETWEEN finivig AND ffinvig and cod_tlib='T' and cod_clib='"+str(Tempo2->trat_prefe,4)+"'" 
							         = sqlejecuta(PROGRAM(),LINENO(), SQL, "cAnexoCAU" )
							         IF RECCOUNT()>0
							            lnAnosOld = cAnexoCAU.ANNOS
							                     USE IN cAnexoCAU         
							         ENDIF
							      ENDIF
							 */
							if (flag_tpn==1){
								refpartida = funcionesService.getRefPartidasByTipoUsoAndPartidaAndFechaVigAndCLib("CAU", serie.getNumpartnandi().toString(),
										fechaEmbarque, serie.getCodtratprefe().toString());
								if (refpartida != null ){
									lnAnosOld = refpartida.getNumeroAnosAntiguedad();
								}
							}
						}


						/**validadorVehiculoService-validarAntiguedadVehiculo PAS20145E220000081 AREY**/
						// 31. *Se validan algunos TPNs
						// 32. *Se verifica si corresponde a un TPN exonerado de la
						// validaci�n de los 5 a�os
						if (!funcionesService.existsInCatRefRuc(new String[] { "VH1" }, serie.getCodtratprefe().toString(), tipDocumento, numDocumento,"")) {

							/**AREY							if (!(SunatStringUtils.isNumeric(item.getAnnfabrica()) && SunatStringUtils.isLengthEqualsToNumber( item.getAnnfabrica(), 4))){
								listErr.add( catalogoHelper.getErrorMap("30154", item.getAnnfabrica()) );
							    return listErr;
							}
							 **/							
							if (serie.getNumpartnandi() >= 8703210010L && serie.getNumpartnandi() <= 8703900090L) {
								// i. *Autos de Coleccion Deben ser de 35 A�os como
								// minimo
								if ((anoTope - item.getAnnfabricaAsInteger() + auxn) > lnAnosOld
										&& SunatDateUtils.getAnho(SunatDateUtils.getDateFromInteger(fechaEmbarque)) - item.getAnnfabricaAsInteger() + auxn < 35) {//KIB solo el a�o de la fecha de embarque
									/**
									 * 1. GrabaTelelog (� �,�
									 * �,"5758","ENVIADO BDUADET2.ARO_ANO: "
									 * +Tempo2.aro_ano) 2. RETORNA
									 */
									//AREY									listErr.add( catalogoHelper.getErrorMap("05758", item.getAnnfabrica()) );
									//AREY									return listErr;
								}
							} else {
								// i. *Antig�edad de Vehiculo Mayor de 5 A�os
								Integer count = funcionesService.getRefPartidasByTipoUsoAndPartida("843", serie.getNumpartnandi().toString());
								if ( count == 0) {
									if ((anoTope - item.getAnnfabricaAsInteger() + auxn) > lnAnosOld) {
										/**
										 * a. GrabaTelelog (� �,� �,"5757",
										 * "ENVIADO EN ITEM DEL FORM. B:.ARO_ANO: "
										 * +Tempo2.aro_ano+" : Antiguedad maxima "+
										 * A_CADENA(lnAnosOld,1)+" a�os") b. RETORNA
										 */
										//AREY										listErr.add( catalogoHelper.getErrorMap("5757", item.getAnnfabrica()) );
										//AREY										return listErr;
									}
									// 3. *Ver si corresponde a un TPN exon. de val.
									// de Peso_vehic y para partes y piesas
									// TODO Revisar esta parte clib=227
									if (serie.getCodtratprefe().toString().equals("227")){
										if (funcionesService.existsInCatRefRuc(new String[] { "VH2", "VKM" }, serie.getCodtratprefe().toString(), tipDocumento,
												numDocumento,"")) {

											// b. Se verifica a�o de fabricaci�n en la
											// tabla CANTMAXLIBE del PRAD1:
											Integer anioEmbarque = SunatNumberUtils.getAnioFromDate(fechaEmbarque);
											Map<String, Object> cantMaxLibe = funcionesService.getCantMaxLibeByClibAndAduanaAndRegimenAndMarcaAndChasisAndAnnFabrica(
													serie.getCodtratprefe().toString(), declaracion.getCodaduana(), declaracion.getDua().getCodregimen(), item.getDesmarca(),
													SunatStringUtils.substringFox(mClasVari, 7, 20), item.getAnnfabricaAsInteger());
											if (cantMaxLibe != null & cantMaxLibe.size() > 0) {
												Integer ann_fabr = (Integer) cantMaxLibe.get("ann_fabr");
												if (anioEmbarque < ann_fabr) {
													/**
													 * ii. GrabaTelelog (� �,� �,"5757",
													 * "ENVIADO TPN 227. ANNO EMBARQUE MENOR A ANO DE FABRICACION"
													 * )
													 */
													//listErr.add( catalogoHelper.getErrorMap("5757") ); // nuevo error 30348
													listErr.add( getErrorMap("30438", new Object[] { "**","ANIO EMBARQUE ".concat(anioEmbarque.toString()).concat(" MENOR A ANO DE FABRICACION ").concat(ann_fabr.toString()) }) );
												}

												// iv. ** La fabricacion se cuenta a a
												// partir del a�o siguiente a su
												// fabricacion

												if (anioEmbarque > (ann_fabr + 5)) {
													/**
													 * vi. GrabaTelelog (� �,�
													 * �,"5757","ENVIADO ARO_ANO: "
													 * +Tempo2.aro_ano+" : TPN 227 Antiguedad maxima 5 a�os entre a�o siguiente de fabr. y a�o de embarque"
													 * )
													 */
													//listErr.add( catalogoHelper.getErrorMap("5757", item.getAnnfabrica()) );

													listErr.add( getErrorMap("30438", new Object[] { "***","ANTIGUEDAD MAXIMA 5 A�OS ENTRE A�O SIGUIENTE DE FABR. Y A�O DE EMBARQUE" }) );
													return listErr;
												}
											} else {
												/**3t
												 * // * i. GrabaTelelog (� �,� �,"1286",
												 * "TPN 227. ENVIADO EN BDUADET2 NO EXISTE. ARO_ANO: "
												 * +Tempo2.aro_ano+
												 * "- MARCA: "+Tempo2.marc_comer
												 * +" CHASIS :"+
												 * SUBSTR(Tempo2.Clas_Vari,7,20))
												 */
												//listErr.add( catalogoHelper.getErrorMap("1286", new Object[] { item.getAnnfabrica(), item.getDesmarca(),
												//		SunatStringUtils.substringFox(mClasVari, 7, 20) }) );
												//KIB: para TPN 227, los datos del a�o de fabricacion, marca y chasis no existen en la cta cte de vehi c/medida cautelar
												listErr.add( getErrorMap("30438", new Object[] { "*","LOS DATOS DEL A�O DE FABRICACION: " .concat(item.getAnnfabrica()!=null?item.getAnnfabrica():"").concat(", MARCA: ").concat(item.getDesmarca()!=null?item.getDesmarca():"").concat(" Y CHASIS: ").concat(SunatStringUtils.substringFox(mClasVari, 7, 20)).concat(" NO EXISTEN EN LA CTA CTE DE VEHI C/MEDIDA CAUTELAR") }) );
											}

										}}
								}
							}
						}
					}
				}
				// 10. Vehiculo usado con tpn 252, para regimen=10, debe tener m�s
				// de 24 asientos

				if ( SunatNumberUtils.isEqual(serie.getCodtratprefe(), 252) 
						&& SunatStringUtils.isEqualTo(declaracion.getDua().getCodregimen(), "10")
						&& SunatNumberUtils.isEqual(serie.getNumpartnandi(), 8702109000L)) {

					String prefix = SunatStringUtils.substringFox(mUsoAplic, 1, 2);

					if (SunatStringUtils.isEmpty(prefix) || (new Integer(prefix)) <= 24) {
						listErr.add( getErrorMap("5682", prefix) );
						return listErr;
					}
				}
				// 12. ** Validaci�n de TPN 227
				if ( SunatNumberUtils.isEqual(serie.getCodtratprefe(), 227)  && fechaEmbarque < 20050716) {
					// TODO validar clib=' 227' verificar que solo haga una sola vez par el 227
					if (funcionesService.existsInCatRefRuc(new String[] { "'VH2", "VKM" }, serie.getCodtratprefe().toString(), tipDocumento, numDocumento,"")) {
						Integer anioEmbarque = SunatNumberUtils.getAnioFromDate(fechaEmbarque);
						Map<String, Object> cantMaxLibe = funcionesService.getCantMaxLibeByClibAndAduanaAndRegimenAndMarcaAndChasisAndAnnFabrica(serie
								.getCodtratprefe().toString(), "000", declaracion.getDua().getCodregimen(), item.getDesmarca(), SunatStringUtils.substringFox(mClasVari, 7,
										20), item.getAnnfabricaAsInteger());

						if (cantMaxLibe != null && cantMaxLibe.size() > 0) {
							Integer ann_fabr = (Integer) cantMaxLibe.get("ann_fabr");

							if (anioEmbarque < ann_fabr) {
								//listErr.add( catalogoHelper.getErrorMap("5757") );//KIB como arriba con su **
								//listErr.add( catalogoHelper.getErrorMap("30403", new Object[] { "****",item.getAnnfabrica(), item.getDesmarca(),SunatStringUtils.substringFox(mClasVari, 7, 20) }) );
								listErr.add( getErrorMap("30438", new Object[] { "****","ANIO EMBARQUE ".concat(anioEmbarque.toString()).concat(" MENOR A ANO DE FABRICACION ").concat(ann_fabr.toString()) }) );


							}

							// c. ** La fabricacion se contara a partir del a�o
							// siguiente a su fabricacion
							if (anioEmbarque > (ann_fabr + 5)) {
								//listErr.add( catalogoHelper.getErrorMap("5757", item.getAnnfabrica()) ); //KIB igual que arrriba**
								//listErr.add( catalogoHelper.getErrorMap("30403", new Object[] { "+",item.getAnnfabrica(), item.getDesmarca(),SunatStringUtils.substringFox(mClasVari, 7, 20) }) );
								listErr.add( getErrorMap("30438", new Object[] { "#","ANTIGUEDAD MAXIMA 5 A�OS ENTRE A�O SIGUIENTE DE FABR. Y A�O DE EMBARQUE" }) );

							}
						} else {
							//listErr.add( catalogoHelper.getErrorMap("1286", new Object[] { item.getAnnfabrica(), item.getDesmarca(),
							//		SunatStringUtils.substringFox(mClasVari, 7, 20) }) );//igual que arriba ***
							listErr.add( getErrorMap("30438", new Object[] { "##","LOS DATOS DEL A�O DE FABRICACION: " .concat(item.getAnnfabrica()!=null?item.getAnnfabrica():"").concat(", MARCA: ").concat(item.getDesmarca()!=null?item.getDesmarca():"").concat(" Y CHASIS: ").concat(SunatStringUtils.substringFox(mClasVari, 7, 20)).concat(" NO EXISTEN EN LA CTA CTE DE VEHI C/MEDIDA CAUTELAR") }) );
						}
					}
				}

				// && 20100202 LLG : Implementaci�n de TPN 308 asinado a la empresa con RUC 20427557376
				//  && Se valida la fecha de vigencia y que el TPN sea igual a 308
				Timestamp pFecha = new Timestamp(System.currentTimeMillis());
				Integer vigencia = funcionesService.getVigenciaCambio("983", declaracion.getDua().getCodregimen(), "TD000", "000071", pFecha);
				if ( SunatNumberUtils.isEqual(serie.getCodtratprefe(), 308) && vigencia>0  ) {
					if (funcionesService.existsInCatRefRuc(new String[] { "VH1" }, serie.getCodtratprefe().toString(), tipDocumento, numDocumento,declaracion.getDua().getCodaduanaorden())) {
						if (serie.getNumpartnandi()>= 8701000000L && serie.getNumpartnandi()<= 8705909000L)   {
							listErr.add( getErrorMap("30439", new Object[]{"*"," PARTIDA: ".concat(serie.getNumpartnandi()!=null?serie.getNumpartnandi().toString():"").concat(" NO SE ENCUENTRA ASOCIADA AL DOCUMENTO:").concat(numDocumento)}) );
						}else{// && En caso el rango de partida consultada sea valida, se consulta a NANDLIBE
							HashMap<String,Object> paramsNandtasa=new HashMap<String,Object>();
							paramsNandtasa.put("tlib", "T");
							paramsNandtasa.put("clib", serie.getCodtratprefe());
							paramsNandtasa.put("cnan", serie.getNumpartnandi());
							//ESANTANA				    Integer fechaReferenciaInt=SunatDateUtils.getCurrentIntegerDate();
							Integer fechaReferenciaInt=SunatDateUtils.getIntegerFromDate(fechaIngSi);
							paramsNandtasa.put("fecvigencia", fechaReferenciaInt);
							//				    		NandTasaDAO nandtasaDAO=FormatoAServiceImpl.getInstance().getNandtasaDAO();
							//				    		if (nandtasaDAO.count(paramsNandtasa)==0){//&& En caso no existiese registro en NANDLIBE
							int contNandTasa=((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).count(paramsNandtasa);
							if (contNandTasa==0){//&& En caso no existiese registro en NANDLIBE
								listErr.add( getErrorMap("30439",new Object[]{"**"," PARTIDA: ".concat(serie.getNumpartnandi()!=null?serie.getNumpartnandi().toString():"").concat(" NO SE ENCUENTRA ASOCIADA AL DOCUMENTO:").concat(numDocumento)}) );
							}
						}

					}else{//&& En caso no existiese registro en CAT_REFRUC
						listErr.add( getErrorMap("30439", new Object[]{"***"," RUC: ".concat(numDocumento).concat("  NO CORRESPONDE CON NUMERACI�N DE TPN 308")}) );
					}

				}
				if ( SunatNumberUtils.isEqual(serie.getCodtratprefe(), 308) && vigencia>0  ) {
					String cad_chasis=SunatStringUtils.substringFox(mClasVari, 7, 20);
					Map<String, Object> cantMaxLibe = funcionesService.getCantMaxLibeByClibAndAduanaAndRegimenAndMarcaAndChasisAndAnnFabrica(serie
							.getCodtratprefe().toString(), "000", declaracion.getDua().getCodregimen(), item.getDesmarca().trim(), SunatStringUtils.substringFox(mClasVari, 7,
									20).trim(), item.getAnnfabricaAsInteger());
					if (!cantMaxLibe.isEmpty()){
						Long qactduas=SunatNumberUtils.toLong(cantMaxLibe.get("qactduas"));
						Long qmaxduas=SunatNumberUtils.toLong(cantMaxLibe.get("qmaxduas"));
						if (qactduas>=qmaxduas){ //en caso la cantidad de duas actualizadas sea igual o mayor a la cantidad de duas maximas
							//_telelog(RIGHT(duadet.Ano_Orden,2), " "," ", "8573","TPN "+TPN_DEC+": EXCEDE CANTIDAD DE UNIDADES PERMITIDAS (MAX = "+ALLTRIM(STR(tpnmaxvehi3.qmaxduas))+")"," ")
							listErr.add( getErrorMap("30439", new Object[]{"#"," EXCEDE CANTIDAD DE UNIDADES PERMITIDAS (MAX = ".concat(qmaxduas.toString())}) );

						}else{
							boolean TPN_MAX =true;
						}


					}else{//=graba_telelog(RIGHT(duadet.Ano_Orden,2), " "," ", "0053","TPN "+TPN_DEC+" NO HABILITADO PARA VEHICULO CON ESAS CARATERISTICAS"," ")
						listErr.add( getErrorMap("30439", new Object[]{"#*","TPN NO HABILITADO PARA VEHICULO CON ESAS CARATERISTICAS"}) );	
					}

				}


			}

		}

		return listErr;
	}

	/**
	 * Funcion fpCeticos. Aplicar la referencia de la ingenieria en reversa
	 * 
	 * @param item
	 * @return
	 */
	public Map<String, String> valgralitemfb4(DAV dav, Declaracion declaracion) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		Map<String, String> result = new HashMap<String, String>();

		if(declaracion.isExoneradoFB()){

			return result;

		}


		for (DatoSerie serie : declaracion.getDua().getListSeries()) {

			if (SunatStringUtils.isStringInList(serie.getCodestamerca(), "20,21,22,23,24,25,26,27,28")) {

				List<CatRefpartidas> resultados = funcionesService.getPartidaVehiculo("CET", declaracion.getDua().getCodregimen(), declaracion.getCodaduana());

				if (resultados != null && resultados.size() > 0) {

					for (CatRefpartidas catRefPartida : resultados) {
						String capitulo = catRefPartida.getCapitulo();
						String cnan = catRefPartida.getPartidaArancelaria().toString();

						boolean error = false;

						if (SunatStringUtils.isEmpty(capitulo) && !SunatStringUtils.isEmpty(cnan)
								&& SunatStringUtils.isEqualTo(cnan, serie.getNumpartnandi().toString()))
							error = true;

						if (!SunatStringUtils.isEmpty(capitulo)
								&& SunatStringUtils.isEqualTo(capitulo, SunatStringUtils.substringFox(serie.getNumpartnandi().toString(), 1, 4))
								&& !SunatStringUtils.isEmpty(cnan) && SunatStringUtils.isEqualTo(cnan, serie.getNumpartnandi().toString()))
							error = true;

						if (!SunatStringUtils.isEmpty(capitulo) && SunatStringUtils.isEmpty(cnan)
								&& SunatStringUtils.isEqualTo(capitulo, SunatStringUtils.substringFox(serie.getNumpartnandi().toString(), 1, 4)))
							error = true;

						if (error)
							if (SunatStringUtils.isEqualTo(serie.getCodtiposeg(), "9") && !SunatStringUtils.isEqualTo(serie.getCodpaisorige(), "1B")) {
								// 1. GrabaTelelog (� �, � �, '6053',
								// "ENVIADO PAIS_EMBAR: "+Tempo2.pais_embar+
								// " ENVIE:1B")
								CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
								result = catalogoAyudaService.getError("06053");
							}
					}
				}
			}
		}

		return result;
	}
	//lmvr - RN 179
	public List<Map<String, String>> valPaisAdqui (DAV dav, Declaracion declaracion) {
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

		for (DatoFactura factura : dav.getListFacturas()) {
			for (DatoItem item : factura.getListItems()) {
				DatoSerie serie = getSerieCorrespondiente(item, declaracion);
				if (serie != null) {
					if (!SunatStringUtils.isEqualTo(serie.getCodpaisadqui(), item.getCodpaisadqui())) {
						//glazaror... evitamos el uso de catalogoHelper.getErrorMap
						//listErr.add(catalogoHelper.getErrorMap("30576", new Object[] { serie.getNumserie(), serie.getCodpaisadqui(),item.getCodpaisadqui(), item.getNumsecitem() }));
						// SERIE {0}: PAIS DE ADQUISICION [{1}] DECLARADO EN  FORMATO A DEBE SER EL MISMO PAIS DE ADQUISICION [{2}] DEL ITEM [{3}] DEL FORMATO B

						//glazaror... hacemos uso de catalogoAyudaService.getError
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						String numeroSerie = (serie.getNumserie() != null) ? serie.getNumserie().toString() : " ";
						String codigoPaisAdquisicion = (serie.getCodpaisadqui() != null) ? serie.getCodpaisadqui().toString() : " ";
						String codigoPaisAdquisicionItem = (item.getCodpaisadqui() != null) ? item.getCodpaisadqui().toString() : " ";
						String numeroSecuenciaItem = (item.getNumsecitem() != null) ? item.getNumsecitem().toString() : " ";
						listErr.add(catalogoAyudaService.getError("30576", new String[] {numeroSerie, codigoPaisAdquisicion, codigoPaisAdquisicionItem, numeroSecuenciaItem}));

					}


				}

			}
		}

		return listErr;
	}

	/**
	 * se ha desagreado en distintos servicios, por el momento 
	 * se retira de la TX XX01. 
	 * @param dav
	 * @param declaracion
	 * @return
	 */
	@Deprecated
	public List<Map<String, String>> valgralitemfb6(DAV dav, Declaracion declaracion) {

		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

		if(declaracion.isExoneradoFB()){
			return listErr;
		}

		// 27. *: Validar Partidas (Series-Correlacion-Items)
		for (DatoFactura factura : dav.getListFacturas()) {
			for (DatoItem item : factura.getListItems()) {
				DatoSerie serie = getSerieCorrespondiente(item, declaracion);
				if (serie != null) {

					// Se verifica que la partida del formato A no sea diferente
					// a la partida del formato B

					if( ! SunatNumberUtils.isEqual(serie.getNumpartnandi(), item.getNumpartnandi()) )
					{
						listErr.add( getErrorMap("30356", new Object[]{serie.getNumpartnandi().toString(),serie.getNumserie(), item.getNumpartnandi().toString(), item.getNumsecitem() } ));
						//lmvr [RN 174]- SERIE[{1}]: SPN {[0]} DECLARADA EN EL FORMATO A DEBE SER LA MISMA SPN [{2}] DEL �TEM [{3}] DEL FORMATO B
					}

					// 33. *: Validar Pais de Origen (Series-Correlacion-Items)
					if (!SunatStringUtils.isEqualTo(serie.getCodpaisorige(), item.getCodpaisorige())) {
						listErr.add(getErrorMap("05775", new Object[] { serie.getNumserie(), serie.getCodpaisorige(), item.getNumsecitem(),
								item.getCodpaisorige() }));
					}

					// 38. *: Validar Estado de Mercanc�a
					// (Series-Correlacion-Items)
					if (!SunatStringUtils.isEqualTo(serie.getCodestamerca(), item.getCodestamer())) {
						listErr.add(getErrorMap("05776", new Object[] { serie.getNumserie(), serie.getCodestamerca(), item.getNumsecitem(),
								item.getCodestamer() }));
					}
				}

			}
		}

		// 43. Si ha enviado Informaci�n de Facturas de la Declaraci�n entonces
		// 44. Se verifica que las Facturas del Formato B (en XML
		// secci�n DAVs DatosFactura.nume_factu) correspondan a las
		// Facturas del Formato A. (en XML secci�n DAMs
		// DatosFactura.nume_factu)
		Elementos<DatoFacturaref> listFacturaRef=declaracion.getDua().getListFacturaRef();

		if( ! CollectionUtils.isEmpty(listFacturaRef) )
		{
			for (DatoFacturaref facturaRef : listFacturaRef) {
				DatoFactura facturafb = getFacturaFBCorrespondiente(facturaRef, declaracion);
				DUA dua = (DUA) facturaRef.getPadre();
				if (facturafb == null) {
					for (DatoSerie datoSerie : dua.getListSeries()) {
						List<DatoFacturaref> listnumfactura = getFacturaRef(dua,datoSerie);
						for (DatoFacturaref factura : listnumfactura) {      
							if (facturaRef.getNumfactura().equals(factura.getNumfactura())){
								listErr.add(getErrorMap("05778", new Object[] {datoSerie.getNumserie(),facturaRef.getNumfactura()}));
								break;
							}
						}
					}
				} else {

					if (!SunatDateUtils.isEqualTo(facturafb.getFecfactura(), facturaRef.getFecfactura())) {
						for (DatoSerie datoSerie : dua.getListSeries()) {
							List<DatoFacturaref> listnumfactura = getFacturaRef(dua,datoSerie);
							for (DatoFacturaref factura : listnumfactura) {      
								if ( facturaRef.getNumfactura().equals(factura.getNumfactura())){
									// listErr.add(catalogoHelper.getErrorMap("05779", new
									// Object[] { facturaRef.getFecfactura() }));
									listErr.add(getErrorMap("05779", new Object[] {datoSerie.getNumserie(), facturaRef.getNumfactura(),SunatDateUtils.getFormatDate(facturaRef.getFecfactura(), "dd-MM-yyyy"),SunatDateUtils.getFormatDate(facturafb.getFecfactura(), "dd-MM-yyyy") }));
									break;
								}
							}
						}

					}
				}
			}
			for (DatoFactura factura : dav.getListFacturas()) {
				DatoFacturaref factDecl = getFacturaDeclCorrespondiente(factura, declaracion);
				if (factDecl == null) {
					listErr.add(getErrorMap("30620", new Object[] { factura.getNumfactura() }));
					//NUMERO DE FACTURA(S) DECLARADO EN EL FORMATO B DEBE SER EL MISMO CONSIGNADO EN EL FORMATO A
				} else {
					if (!SunatDateUtils.isEqualTo(factura.getFecfactura(), factDecl.getFecfactura())) {
						// listErr.add(catalogoHelper.getErrorMap("05779", new
						// Object[] { factura.getFecfactura() }));
						//listErr.add(catalogoHelper.getErrorMap("05779", new Object[] { factura.getFecfactura() }));						
						listErr.add(getErrorMap("30621", new Object[] {factDecl.getNumserie(), factura.getNumfactura(),SunatDateUtils.getFormatDate(factDecl.getFecfactura(), "dd-MM-yyyy"),SunatDateUtils.getFormatDate(factura.getFecfactura(), "dd-MM-yyyy") }));
					}
				}
			}
		}		
		for (DatoFactura factura : dav.getListFacturas()) {

			for (DatoItem item : factura.getListItems()) {
				BigDecimal qty = new BigDecimal(0);
				BigDecimal taju = new BigDecimal(0);
				BigDecimal qfob = new BigDecimal(0);

				for (DatoSerieItem datoSerieItem : item.getListSerieItems()) {
					qty = SunatNumberUtils.sum(qty, datoSerieItem.getCant_mercd());
					taju = SunatNumberUtils.sum(taju, datoSerieItem.getMtoajuitser());

					if( SunatStringUtils.isStringInList(item.getIndvarios(), "0,2"))
						qfob = SunatNumberUtils.sum(qfob, datoSerieItem.getMtofobitser());

					if( SunatStringUtils.isStringInList(item.getIndvarios(), "1,3,4"))
						qfob = SunatNumberUtils.sum(qfob, datoSerieItem.getMtofobitser());

				}
				if (!SunatNumberUtils.isEqual(item.getCntcantcomer(), qty)) {
					listErr.add(getErrorMap("05647", new Object[] { item.getCntcantcomer(), qty, factura.getNumsecfactu(), item.getNumsecitem() }));
				}

				//JPL Correccion Bug Ajuste de Montos con Cantidades.
				BigDecimal mtoAjusUnitaTotalizado =  SunatNumberUtils.multiply(item.getMtoajusunita(), qty);

				BigDecimal diferenciaAjusteTotalizado = SunatNumberUtils.absoluteDiference(mtoAjusUnitaTotalizado, taju);
				//Fin JPL Correccion Bug Ajuste de Montos con Cantidades.					

				if (!SunatNumberUtils.isLessOrEqualsThanParam(diferenciaAjusteTotalizado, new BigDecimal(1))) {
					listErr.add(getErrorMap("05649",new Object[] { item.getMtoajusunita(), taju, factura.getNumsecfactu(), item.getNumsecitem() }));
				}

				if (!SunatNumberUtils.isEqual(item.getMtofobitem(), qfob)) {
					//
					// Tener en cuenta que los registros con ITEM_FB.posinfveri
					// (en XML DatosItem.indvarios) igual a '0' o '2' se suman
					// juntos, y por otra parte los que tienen
					// ITEM_FB.posinfveri igual a '1' o '3' o '4' se suman
					// juntos.
					listErr.add(getErrorMap("05648", new Object[] { item.getMtofobitem(), qfob, factura.getNumsecfactu(), item.getNumsecitem() }));
				}

			}
		}

		/*branch ingreso 2011--009 hosorio 05/07/2011 inicio*/
		// para corregir el bug 3527
		//ValSerieItemFB valFBItem=new ValSerieItemFB();
		for(DatoSerie serie:declaracion.getDua().getListSeries() ){
			ValSerieItemFB valSerieItem =   fabricaDeServicios.getService("ValSerieItemFB");
			BigDecimal qCanMerc=BigDecimal.ZERO;
			List<DatoSerieItem> seriesItems = valSerieItem.getSeriesItemCorrespondiente(serie, declaracion);

			for (DatoSerieItem datoSerieItem : seriesItems) {
				qCanMerc = SunatNumberUtils.sum(qCanMerc, datoSerieItem.getCant_mercd());	
			}

			/*
			 **
			 * r2bz La diferencia debe ser considerando un redondeo a tres
			 * decimales, dado que asi es la estructura en el formato A, a
			 * diferencia del B que es a 6 deciamles
			 **/
			BigDecimal dif = SunatNumberUtils.absoluteDiference(SunatNumberUtils.scaleHalfUp(qCanMerc,3), serie.getCntunicomer());			

			if( SunatNumberUtils.isGreaterThanParam(dif, BigDecimal.ZERO) )
			{
				listErr.add ( getErrorMap("05642", new Object[]{serie.getCntunicomer(), qCanMerc, serie.getNumserie()}));
				//lmvr - RN 166: SERIE[{2}]: CANTIDAD DE UNIDADES COMERCIALES[{0}] DECLARADA EN EL FORMATO A DEBE SER LA MISMA DE  LA SUMATORIA DE UNIDADES COMERCIALES[{1}] DEL FORMATO B
			}					
		}

		return listErr;
	}

	/**
	 * Se identifica que se haya transmitido el c�digo de identificador
	 * * @param item
	 * @return
	 */


	public List<Map<String, String>> indsoftware(DatoItem item){
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}

		if (SunatStringUtils.isEmpty(item.getIndsoftware())) {
			return result;
		}
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("342", item.getIndsoftware()));
		//if (!item.getIndsoftware().equals("3") || (!catalogoHelper.isValid(item.getIndsoftware(), "342"))) {
		if (!item.getIndsoftware().equals("3") || !validaCatalogo) {
			result.add(getErrorMap(
					"05573",
					new Object[] { 	((DAV) item.getPadre().getPadre()).getNumsecuprov(),
							((DatoFactura) item.getPadre()).getNumsecfactu(), item.getNumsecitem(),
							item.getIndsoftware()!=null?item.getIndsoftware():" "}));

		}

		if (item.getIndsoftware().equals("3")) {
			validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("MPD", item.getNumpartnandi().toString()));
			//if (!catalogoHelper.isValid(item.getNumpartnandi().toString(), "MPD")) {
			if (!validaCatalogo) {
				result.add(getErrorMap("30634",
						new Object[] {	item.getNumsecitem(),
								item.getNumpartnandi()!=null?item.getNumpartnandi().toString():" "}));
			}

			DatoMonto otrosGastos = FormatoBUtils.getMontoDAV((DAV) item.getPadre().getPadre(), Constants.TIPO_MONTO_DAV_VOTR_GASTO);

			if (!SunatNumberUtils.isGreaterThanZero(otrosGastos.getMtologistico())) {

				result.add(getErrorMap("30635",
						new Object[] {	item.getNumsecitem(),
								otrosGastos.getMtologistico()!=null?otrosGastos.getMtologistico():" ",
										Constants.TIPO_MONTO_DAV_VOTR_GASTO }));

			}
		}
		return result;
	}

	public  DatoSerie getSerieCorrespondiente(DatoItem item, Declaracion declaracion) {
		for (DatoSerieItem datoSerieItem : item.getListSerieItems()) {
			for (DatoSerie datoserie : declaracion.getDua().getListSeries()) {
				if (SunatNumberUtils.isEqual(datoserie.getNumserie(), datoSerieItem.getNumserie()))
					return datoserie;
			}
		}

		return null;
	}

	public  DatoItem getItemCorrespondiente(DatoSerie serie, Declaracion declaracion) {
		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura factura : dav.getListFacturas()) {
				for (DatoItem item : factura.getListItems()) {
					for (DatoSerieItem serieItem : item.getListSerieItems()) {
						if (SunatNumberUtils.isEqual(serieItem.getNumserie(), serie.getNumserie())) {
							return item;
						}
					}
				}
			}
		}

		return null;
	}

	private Map<String, Elemento> getItemCorrespondienteAsMap(DatoSerie serie, Declaracion declaracion) {
		Map<String, Elemento> result = new HashMap<String, Elemento>();
		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura factura : dav.getListFacturas()) {
				for (DatoItem item : factura.getListItems()) {
					for (DatoSerieItem serieItem : item.getListSerieItems()) {
						if (SunatNumberUtils.isEqual(serieItem.getNumserie(), serie.getNumserie())) {
							result.put("serieItem", serieItem);
							result.put("item", item);
							result.put("factura", factura);
							return result;
						}
					}
				}
			}
		}

		return result;
	}

	private DatoFactura getFacturaFBCorrespondiente(DatoFacturaref datoFacturafa, Declaracion declaracion) {

		for( DAV dav : declaracion.getListDAVs() )
		{
			for (DatoFactura factura : dav.getListFacturas()) {
				if (SunatStringUtils.isEqualTo(factura.getNumfactura(), datoFacturafa.getNumfactura()))
					return factura;
			}			
		}
		return null;
	}

	private DatoFacturaref getFacturaDeclCorrespondiente(DatoFactura datoFacturafb, Declaracion declaracion) {
		for (DatoFacturaref facturaref : declaracion.getDua().getListFacturaRef()) {
			if (SunatStringUtils.isEqualTo(facturaref.getNumfactura(), datoFacturafb.getNumfactura()))
				return facturaref;
		}

		return null;
	}

	/** Validar que la cantidad de unidades comerciales del Formato B sea el mismo a la sumatoria de la cantidad de unidades comerciales correlacionadas. En caso contrario (Ver F25).
			Validar que el total de ajustes del Formato B sea el mismo a la sumatoria de los ajustes correlacionados, redondeada a 6 decimales. En caso contrario (Ver F26).
			Validar que el valor del FOB por �tem del Formato B sea el mismo a la sumatoria de los FOB por �tems correlacionados. En caso contrario (Ver F27).
			Validar que la totalidad de los �tems del Formato B est�n correlacionados en las series del Formato A y viceversa. En caso contrario (Ver F24).
	 ** @param  item
		/ * @return map
		/ * @pase */



	public List<Map<String, String>> validarDatosItemXSerieItem(DatoItem item){

		List<Map<String, String>> result = new ArrayList<Map<String, String>>();

		if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
			return result;
		}

		BigDecimal totalCantMercd = BigDecimal.ZERO;
		BigDecimal totalAjustesFB = BigDecimal.ZERO;
		BigDecimal totalFobFB = BigDecimal.ZERO;
		BigDecimal totalAjusteItem = SunatNumberUtils.scaleHalfUp(
				SunatNumberUtils.multiply(item.getMtoajusunita(), item.getCntcantcomer()), 6);

		for (DatoSerieItem serieItem : item.getListSerieItems()) {
			totalCantMercd = SunatNumberUtils.sum(totalCantMercd, serieItem.getCant_mercd());
			totalAjustesFB = SunatNumberUtils.sum(totalAjustesFB, serieItem.getMtoajuitser());
			totalFobFB = SunatNumberUtils.sum(totalFobFB, serieItem.getMtofobitser());
		}
		//glazaror... hacemos uso de catalogoAyudaService para obtener descripcion de errores
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		// compara cantidad de unidades comerciales
		if (!SunatNumberUtils.isEqual(item.getCntcantcomer(), totalCantMercd)) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result.add(catalogoHelper.getErrorMap("30639", 
            		new Object[] { item.getNumsecitem(),
            		item.getCntcantcomer()!=null?item.getCntcantcomer():" ",
                    totalCantMercd }));*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			String numeroSecuenciaItem = (item.getNumsecitem() != null) ? item.getNumsecitem().toString() : " ";
			String cantidadComercial = (item.getCntcantcomer() != null) ? item.getCntcantcomer().toString() : " ";
			String total = (totalCantMercd != null) ? totalCantMercd.toString() : " ";
			result.add(catalogoAyudaService.getError("30639", new String[] {numeroSecuenciaItem, cantidadComercial, total}));
		}

		//Por bug 21210 RIN 16
		BigDecimal totalAjusteFBScala6 = BigDecimal.valueOf(0.000000);
		if(SunatNumberUtils.isGreaterThanZero(totalCantMercd) && totalCantMercd != BigDecimal.ZERO){//PAS201930001100004
			totalAjusteFBScala6 = SunatNumberUtils.divide(totalAjustesFB,totalCantMercd,6);
		}
		// compara total de ajustes
		if (!SunatNumberUtils.isEqual(totalAjusteItem, totalAjustesFB) && !SunatNumberUtils.isEqual(totalAjusteFBScala6, item.getMtoajusunita())) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result.add(catalogoHelper.getErrorMap("30640",
            		new Object[] { item.getNumsecitem(),
            		item.getMtoajusunita()!=null? SunatStringUtils.toStringObj(item.getMtoajusunita().setScale(6, RoundingMode.HALF_UP)):" ",
                    item.getCntcantcomer()!=null?item.getCntcantcomer():" ",
                    SunatStringUtils.toStringObj(totalAjustesFB.setScale(6, RoundingMode.HALF_UP))}));*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			String montoAjusteUnitario = item.getMtoajusunita()!=null? SunatStringUtils.toStringObj(item.getMtoajusunita().setScale(6, RoundingMode.HALF_UP)):" ";
			String cantidadComercial = item.getCntcantcomer()!=null?item.getCntcantcomer().toString():" ";
			String totalAjustes = SunatStringUtils.toStringObj(totalAjustesFB.setScale(6, RoundingMode.HALF_UP));
			//result.add(catalogoAyudaService.getError("30640", new String[] {montoAjusteUnitario, cantidadComercial, totalAjustes}));
			//ggranados correcion msg
			result.add(catalogoAyudaService.getError("30640", new String[] {item.getNumsecitem().toString(), montoAjusteUnitario, cantidadComercial, totalAjustes}));

		}

		// compara total del fob
		BigDecimal diferencia = new BigDecimal(0);
		BigDecimal totalFobFBSacale6 = BigDecimal.ZERO;
		BigDecimal itemMtofobitem6 = BigDecimal.ZERO;
		BigDecimal margen = new BigDecimal(0.1);
		MathContext mc = new MathContext(6);
		totalFobFBSacale6 = totalFobFB.round(mc);
		itemMtofobitem6  =item.getMtofobitem().round(mc);
		diferencia = SunatNumberUtils.absoluteDiference(totalFobFBSacale6,
				SunatNumberUtils.toBigDecimal(itemMtofobitem6));
		if (!SunatNumberUtils.isEqual(item.getMtofobitem(), totalFobFB)   &&   !SunatNumberUtils.isLessThanParam(diferencia, margen)) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result.add(catalogoHelper.getErrorMap("30641",
                    new Object[] { item.getNumsecitem().toString(),            		
            		item.getMtofobitem()!=null?SunatStringUtils.toStringObj(item.getMtofobitem().setScale(3, RoundingMode.HALF_UP)):" ",
            		SunatStringUtils.toStringObj(totalFobFB.setScale(6, RoundingMode.HALF_UP)) }));*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			String numeroSecuenciaItem = (item.getNumsecitem() != null) ? item.getNumsecitem().toString() : " ";
			String montoFobItem = item.getMtofobitem()!=null?SunatStringUtils.toStringObj(item.getMtofobitem().setScale(6, RoundingMode.HALF_UP)):" ";
			String totalFob = SunatStringUtils.toStringObj(totalFobFB.setScale(6, RoundingMode.HALF_UP));

			result.add(catalogoAyudaService.getError("30641", new String[] {numeroSecuenciaItem, montoFobItem, totalFob}));

		}

		return result;
	}

	@ServicioAnnot(tipo = "V", codServicio = 3327, descServicio = "Valida a nivel de �tem que no se rectique a menos un monto ya ajustado en duda")
	@ServInstDetAnnot(tipoRpta = { 1, 1 }, nomAtr = { "declaracion", "declaracionBD" })
	@OrquestaDespaAnnot(codServInstancia = 3327, numSecEjec = 438, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoItem")
	public Map<String, String> validarAjusteDudaPorItem (DatoItem item, Declaracion declaracion){
		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		DudaBusquedaService miDudaBusquedaService = (DudaBusquedaService)this.fabricaDeServicios.getService("dudarazonable.DudaBusquedaService");
		Map<String,Object> mapDAM = new HashMap<String,Object>(); 
		mapDAM.put("numCorrelativoDAM", declaracion.getNumeroCorrelativo());
		mapDAM.put("codigoEstado", pe.gob.sunat.despaduanero2.dudarazonable.util.Constantes.ESTADO_DUDA_CONFIRMADA_POR_RENUNCIA);
		CabDudaRazonable resultadoCabDuda = miDudaBusquedaService.obtenerCabDudaRazonableGeneral(mapDAM);
		if(resultadoCabDuda==null){
			mapDAM.put("codigoEstado", pe.gob.sunat.despaduanero2.dudarazonable.util.Constantes.ESTADO_DUDA_CONFIRMADA_FINAL);
			resultadoCabDuda = miDudaBusquedaService.obtenerCabDudaRazonableGeneral(mapDAM);			
		}
		if (resultadoCabDuda != null){
			DetDudaRazonable objDetDudaRaz = new DetDudaRazonable();
			DetDudaRazonable dataDetDudaRaz = new DetDudaRazonable();
			boolean itemTieneDuda = false;
			objDetDudaRaz.setNumeroCorrelativo(resultadoCabDuda.getNumeroCorrelativo());
			objDetDudaRaz.setNumeroSecuenciaItem(item.getNumsecitem());
			dataDetDudaRaz = miDudaBusquedaService.getDetDudaRazonableActivo(objDetDudaRaz);
			if (dataDetDudaRaz != null){
				itemTieneDuda =  true;
			}

			if (itemTieneDuda){
				BigDecimal fobDuda = dataDetDudaRaz.getMontoFobSustentoActual();
				BigDecimal diferencia = new BigDecimal(0);
				/**El valor rectificado puede ser menor que el valor ajustado por duda razonable hasta por un margen de 0.1*/
				/**PAS20181U220100018: Se coloca margen en negativo*/
				BigDecimal margen = new BigDecimal(-0.1);
				/**Inicio - atencion de ticket INC 2016-058391 - rgrados*/
				diferencia = SunatNumberUtils.diference(item.getMtofobunita(), fobDuda);
				if (!SunatNumberUtils.isEqual(item.getMtofobunita(), fobDuda)   &&   SunatNumberUtils.isLessThanParam(diferencia, margen)) {
					/**Fin - atencion de ticket INC 2016-058391 - rgrados*/
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					DatoSerie serie = getSerieCorrespondiente(item, declaracion);
					String msjSerie = serie.getNumserie().toString();
					String msjItem = item.getNumsecitem().toString();
					String msjMontoFob = dataDetDudaRaz.getMontoFobSustentoActual().toString();
					resultadoError = catalogoAyudaService.getError("30817", new String[] {msjItem, msjSerie, msjMontoFob});
				}
			}
		}
		return resultadoError;
	}
	/*
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
