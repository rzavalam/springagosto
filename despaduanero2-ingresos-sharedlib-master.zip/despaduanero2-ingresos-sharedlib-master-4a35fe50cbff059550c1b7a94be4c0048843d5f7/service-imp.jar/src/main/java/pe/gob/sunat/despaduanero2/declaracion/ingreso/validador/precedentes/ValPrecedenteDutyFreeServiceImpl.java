package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;


import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero.despacho.entrada.df.model.PolizaDf;
import pe.gob.sunat.despaduanero.despacho.entrada.df.model.SeriesDf;
import pe.gob.sunat.despaduanero.despacho.salida.simplificada.model.dao.PolizadxDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
//import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;

import java.text.SimpleDateFormat;
import java.util.*;

import pe.gob.sunat.despaduanero2.declaracion.service.DAMOperativaConsultaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDutyFreeService;
import weblogic.utils.ArrayUtils;

public class ValPrecedenteDutyFreeServiceImpl extends ValDuaAbstract implements ValPrecedenteDutyFreeService {


	public List<Map<String, String>> validaDutyFree(Declaracion declaracion,String puntoDeLlegada, List<DatoSerie> listSeries, String codAduanaOrden, Date fechaReferencia){

		List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
//		PolizaDfDAO polizadfDAO = this.fabricaDeServicios.getService("polizadfDef.".concat(codigoAduana));

	//	Map<String, Object> declaracionExportacion = polizadfDAO.selectPolizaByMap(parametrosBusqueda);
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String codiAduan="";
		String anoPrese= "";
		String codaduanaConex= codAduanaOrden;
		String numeCorre="";
		String cantSerie="";
		String numeSeriDf="";
		listMapError.add(validarPuntoLlegada(puntoDeLlegada));
		ConsultaDutyFreeService consultaDutyFreeService = (ConsultaDutyFreeService)fabricaDeServicios.getService("sigad.ingreso.ConsultaDutyFreeService");
		for(DatoSerie serie:listSeries) {
			if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
				for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
					String strPrecedencia = regPrec.getCodaduapre() + '-' + SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4) + '-' + ConstantesDataCatalogo.REG_DUTY_FREE + '-' + regPrec.getNumdeclpre();
					PolizaDf polizaDf = new PolizaDf();
					polizaDf.setCodiAduan(regPrec.getCodaduapre());
					polizaDf.setAnoPrese(SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4));
					anoPrese = SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4);
					codiAduan = regPrec.getCodaduapre() != null ? regPrec.getCodaduapre().toString() : "0";
					polizaDf.setNumeCorre(regPrec.getNumdeclpre());
					numeCorre = SunatStringUtils.lpad(regPrec.getNumdeclpre(), 6, '0') != null ? SunatStringUtils.lpad(regPrec.getNumdeclpre(), 6, '0') : "0";
					Integer numSerie = serie.getNumserie();
					cantSerie = String.valueOf(numSerie);

					Map<String, Object> params = new HashMap();
					params.put("codigoAduana", regPrec.getCodaduapre());
					params.put("annoPresentacion", SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4));
					params.put("codigoRegimen", regPrec.getCodregipre());
					params.put("numeroDeclaracion", regPrec.getNumdeclpre() != null ? regPrec.getNumdeclpre().toString() : "0");
					CabDeclaraDAO cabdeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
					DUA dua = cabdeclaraDAO.findDUAByMap(params);
					String numeSerie = regPrec.getNumserpre().toString();
					if (dua != null) {
						String msjError = "";
						String numCorredoc = "";
						numCorredoc = dua.getNumcorredoc().toString();
						msjError = validarlevanteAutorizado(numCorredoc);//E4
						if (!SunatStringUtils.isEmptyTrim(msjError)) {
							listMapError.add(catalogoAyudaService.getError("37222", new String[]{serie.getNumserie().toString(), strPrecedencia}));
						}
						String estado = dua.getCodEstdua() == null ? "00" : dua.getCodEstdua();
						if ("08".equals(estado)) {//dam legajada
							listMapError.add(catalogoAyudaService.getError("37223", new String[]{serie.getNumserie().toString(), strPrecedencia}));
						}
					}

					PolizaDf polizaDf2 = consultaDutyFreeService.consultarDutyFree(anoPrese, codiAduan, numeCorre, codaduanaConex, cantSerie);
					Integer poliLevante = 0;
					poliLevante = polizaDf2 != null ? polizaDf2.getFechVista() : 0;

					if (!codAduanaOrden.equals(codiAduan)) {
						listMapError.add(catalogoAyudaService.getError("37209", new String[]{serie.getNumserie().toString(), codiAduan, "DE LA DECLARACION DE DUTY FREE", strPrecedencia, codAduanaOrden}));
						break;
					}
					if (polizaDf2 == null) {
						//Serie [x]: <TipoDocumento> N� AAA-XXXX-RR-YYYYYY no existe
						listMapError.add(catalogoAyudaService.getError("37227", new String[]{serie.getNumserie().toString(), serie.getNumserie().toString(), strPrecedencia}));
					} else {
						SeriesDf seriesDf = consultaDutyFreeService.consultarDutyFreeSeries(anoPrese, codiAduan, numeCorre, codaduanaConex, numeSerie);
						numeSeriDf = seriesDf != null ? seriesDf.getNumeSerie() : "0";        //csantillan PAS20191U220200002 bug P_SNAA0004-15600
						if (seriesDf == null || !numeSerie.equals(SunatStringUtils.trim(numeSeriDf))) {
							listMapError.add(catalogoAyudaService.getError("37228", new String[]{serie.getNumserie().toString(), numeSerie, strPrecedencia}));
						}
						if (!codiAduan.equals(polizaDf2.getCodiAduan())) {
							listMapError.add(catalogoAyudaService.getError("37209", new String[]{serie.getNumserie().toString(), "DUTTY FREE"}));
						}
						if (poliLevante == 0) {
							listMapError.add(catalogoAyudaService.getError("37223", new String[]{serie.getNumserie().toString(), strPrecedencia}));
						}
					}
				}
			}

		}
		return listMapError;
	}
	private String validarlevanteAutorizado(String numCorredocDam) {
		String msjError = "";
		Boolean  levanteAutorizado = false;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC",numCorredocDam);
		Map<String, Object> declaracion = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDuaByNumCorreDoc(params);

		if(!CollectionUtils.isEmpty(declaracion)){
			String fechaAutorizacionLevante = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(declaracion.get("FEC_AUTLEVANTE"));
			if(!fechaAutorizacionLevante.equals(Constantes.DEFAULT_FECHA_BD)){
				levanteAutorizado= true;
			}
		}

		if (levanteAutorizado == false) {
			msjError = "Declaraci�n de Material de Uso Aeron�utico precedente no cuenta con Levante autorizado";
		}

		return msjError;
	}
	private Map<String, String> validarPuntoLlegada (String puntoLlegada){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String,String> mapError=new HashMap<String,String>();
		String codigoPuntoLLegadaMercancia =puntoLlegada!=null?puntoLlegada.toString():"";
		if (!SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DUTTY_FREE)){
			//El punto de llegada para precedente Acta de incautaci�n debe ser duty Free
			mapError = catalogoAyudaService.getError("37225",new String[] {codigoPuntoLLegadaMercancia, ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DUTTY_FREE});
		}
		return mapError;
	}

}
