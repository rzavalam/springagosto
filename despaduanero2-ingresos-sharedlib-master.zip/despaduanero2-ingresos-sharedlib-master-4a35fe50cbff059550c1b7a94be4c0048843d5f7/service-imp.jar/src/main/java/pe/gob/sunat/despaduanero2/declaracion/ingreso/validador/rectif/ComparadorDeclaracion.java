/*
 * Clase que define el servicio de comparacion de valores en la declaracion enviada y la registrada en BD
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DatoRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DetSolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.RecordBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaEntidadService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes.ValPrecedenteActaEquipajeService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DescrPosicion;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAdiSerieAtreexp;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAdiSerieImpoConsumo;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCertificadoOrigen;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCondTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoContrato;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactSuce;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMercancia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMonto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMovEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoObserv;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtraAduana;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPrecinto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoTributosAutocalc;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.ingreso.vuce.model.DocControlMercRestringidaVuce;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.model.Control;//P46 - PAS20155E220000329
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;//P46 - PAS20155E220000329
import pe.gob.sunat.despaduanero2.declaracion.ingreso.util.Constantes; // JCV 

import pe.gob.sunat.despaduanero2.service.ParticipanteService; //PAS20191U220200019


/*branch ingreso 2011-009 hosorio*/
//public class ComparadorDeclaracion extends ValDuaAbstract {
public class ComparadorDeclaracion extends DocumentComparator {

	Declaracion objnuevo;
	Declaracion objanterior;
	boolean enviaFechaLlegada;     
	public Long numcorredoc;
	private List<Participante> listaParticipantes;

	private FabricaDeServicios fabricaDeServicios;
	private SoporteService soporteService;
	private SequenceDAO sequenceDAO;

	protected final static String DOC_SOPORTE="1";
	protected final static String FACTURA="2";
	protected final static String DOC_TRANSPORTE="3";
	protected final static String DOC_AUTORIZANTE="4";
	protected final static String CERTI_ORIGEN="5";


	public static final String DOC_RESOLUTIVO = "21";
	public static final String SOLICITUD_SUCE = "20";

		
	public void clean(){
		tipoComparacion="N";
		listaCambios=new ArrayList<DetSolicitudRectificacionBean>();
		objnuevo = null;
		objanterior = null;
		enviaFechaLlegada = false;
		numcorredoc = null;
		listaParticipantes = new ArrayList<Participante>(); 
	}


	public ComparadorDeclaracion(FabricaDeServicios fabricaDeServicios) {
		super();

		this.fabricaDeServicios=fabricaDeServicios;  

		soporteService = fabricaDeServicios.getService("soporteServiceDef");
		sequenceDAO = fabricaDeServicios.getService("Framework.sequenceDef");
		// TODO Auto-generated constructor stub
		mapIdentificadoresClase = new HashMap<Class, List<String>>();
		// DUA
		mapIdentificadoresClase.put(DatoDocAutorizante.class, Arrays.asList(new String[] { "numsecdocum" }));
		mapIdentificadoresClase.put(DatoIndicadores.class, Arrays.asList(new String[] { "codtipoindica" }));
		mapIdentificadoresClase.put(DatoOtroDocSoporte.class, Arrays.asList(new String[] { "numsecdocum","codtipoproceso" }));
		mapIdentificadoresClase.put(DatoFacturaref.class, Arrays.asList(new String[] { "numsecfactu" }));
		mapIdentificadoresClase.put(DatoTributosAutocalc.class, Arrays.asList(new String[] { "codtributo" }));
		mapIdentificadoresClase.put(Observacion.class, Arrays.asList(new String[] { "numsecuencia","codtipobserva" }));
		mapIdentificadoresClase.put(DatoObserv.class, Arrays.asList(new String[] { "numsecuencia","codtipobserva" }));
		mapIdentificadoresClase.put(DatoSerie.class, Arrays.asList(new String[] { "numserie" }));
		mapIdentificadoresClase.put(DatoDocTransporte.class, Arrays.asList(new String[] { "numsecdoctrans" }));
		mapIdentificadoresClase.put(DatoContrato.class, Arrays.asList(new String[] { "numfactu" }));
		mapIdentificadoresClase.put(DatoRegPrecedencia.class, Arrays.asList(new String[] { "codaduapre", "codregipre", "numdeclpre", "numserpre","anndeclpre", "codAlmZofra" })); //csantillan PAS20181U220200054
		mapIdentificadoresClase.put(DatoSerieDocSoporte.class, Arrays.asList(new String[] { "numiddocsoporte" }));
		mapIdentificadoresClase.put(DatoAutocertificacion.class, Arrays.asList(new String[] { "numsecCO" }));
		mapIdentificadoresClase.put(DatoVehiculo.class, Arrays.asList(new String[] { "numserie" }));
		mapIdentificadoresClase.put(DatoMontoGasto.class, Arrays.asList(new String[] { "tipmonto" }));
		mapIdentificadoresClase.put(DatoEquipamiento.class, Arrays.asList(new String[] { "numequipo" }));
		mapIdentificadoresClase.put(DatoPrecinto.class, Arrays.asList(new String[] { "numprecinto" }));
		mapIdentificadoresClase.put(DatoMovEquipamiento.class, Arrays.asList(new String[] { "numequipo", "codtipmov" }));

		// DAV
		mapIdentificadoresClase.put(DAV.class, Arrays.asList(new String[] { "numsecuprov" }));
		mapIdentificadoresClase.put(DatoMonto.class, Arrays.asList(new String[] { "codmonto" }));
		mapIdentificadoresClase.put(DatoCondTransaccion.class, Arrays.asList(new String[] { "codindcondtra" }));
		mapIdentificadoresClase.put(DatoFactura.class, Arrays.asList(new String[] { "numsecfactu" }));
		mapIdentificadoresClase.put(DatoFactSuce.class, Arrays.asList(new String[] { "numfactsuc" }));
		mapIdentificadoresClase.put(DatoItem.class, Arrays.asList(new String[] { "numsecitem" }));
		mapIdentificadoresClase.put(DatoSerieItem.class, Arrays.asList(new String[] { "numserie" }));
		mapIdentificadoresClase.put(DatoDescrMinima.class, Arrays.asList(new String[] { "numsecitem","codtipdescr" }));

		this.listaCambios = new ArrayList<DetSolicitudRectificacionBean>();
	}

	/**
	 * Comparacion.
	 * 
	 * @throws Exception 
	 */
	public void comparacion() throws Exception {

		this.numcorredoc = this.objanterior.getDua().getNumcorredoc();
		// completa el objeto , con los datos que serviran de pk
		completarDatos(this.objnuevo);

		//PAS20191U220200019 - mtorralba 20190426 - Se completa la informaci�n del Transportista en el objeto anterior
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", new Date());
		if (!CollectionUtils.isEmpty(MapaValManNum)){
			completarDatosEmpresaTransporte(catalogoAyudaService, this.objanterior);
		}

		// se hace la comparacion en sentido normal para detectar los registros nuevos o rectificados
		this.tipoComparacion = "N";
		comparacion(this.objnuevo, this.objanterior);

		// se hace la comparacion en sentido inverso para detectar los registros eliminados
		this.tipoComparacion = "I";
		comparacion(this.objanterior, this.objnuevo);
	}

	/**
	 * Comparacion.
	 * 
	 * @param declaraRecti Declaracion
	 * @param declaraOld Declaracion
	 * @throws Exception 
	 */	
	
	public void comparacion(Object rectificado, Object anterior) throws Exception {
		Declaracion declaraRecti=(Declaracion)rectificado;
		Declaracion declaraOld=(Declaracion)anterior;

		DUA duaRectificado = declaraRecti.getDua();
		DUA duaActual = declaraOld.getDua();
		comparacionCabDeclara(duaRectificado, duaActual);
		comparacionDatoDeclarante(duaRectificado.getDeclarante(), duaActual.getDeclarante());
		comparacionAgente(declaraRecti.getDua(), declaraOld.getDua());
		comparacionDatoPuntoLLegada(duaRectificado.getNumruclugarecep(), duaActual.getNumruclugarecep());
		comparacionManifiesto(duaRectificado.getManifiesto(), duaActual.getManifiesto());
		comparacionListaObservacion(duaRectificado.getListObservaciones(), duaActual.getListObservaciones());
		// 1. Excluir de la verificaci�n de indicadores el segmento indicadores
		// r2bz Si deberian de anularse,  PAS20110001128  solo de los transmitidos por el usuario
		comparacionListaIndicadorDUA(duaRectificado.getListIndicadores(), duaActual.getListIndicadores());
		comparacionListaDocAsociado(duaRectificado.getListOtrosDocSoporte(), duaActual.getListOtrosDocSoporte());
		comparacionListaDocAsociado(duaRectificado.getListOtrosDocSoporteCO(),duaActual.getListOtrosDocSoporteCO());

		comparacionListaDocAutorizante(duaRectificado.getListDocAutorizantes(), duaActual.getListDocAutorizantes());
		comparacionListaFormaFacturas(duaRectificado.getListFacturaRef(), duaActual.getListFacturaRef());
		comparacionCertiOrigen(duaRectificado.getDatoCertificadoOrigen(), duaActual.getDatoCertificadoOrigen());
		
		//comparacionImpoConsumo(duaRectificado.getPagoElectronico(), duaActual.getPagoElectronico());
		//PAS20171U220200005 Inicio se obtiene los totales
		ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService"); 
		DatoIndicadores indicadorRecti = valMercanciaVigenteService.obtenerIndicadorLlaveManoDespachoParcial (duaRectificado.getListIndicadores());
		DatoIndicadores indicadorActual = valMercanciaVigenteService.obtenerIndicadorLlaveManoDespachoParcial (duaActual.getListIndicadores());
		comparacionImpoConsumo(duaRectificado.getPagoElectronico(), duaActual.getPagoElectronico(), indicadorRecti, indicadorActual);
		//PAS20171U220200005 Fin
		
		comparacionGralTransito(duaRectificado, duaActual);
		comparacionGralAdmTem(duaRectificado, duaActual);
		comparacionRucAnexoUbicacion(duaRectificado.getRucAnexoUbicacion(), duaActual.getRucAnexoUbicacion());
		comparacionListaseries(duaRectificado.getListSeries(), duaActual.getListSeries());
		comparacionDAV(declaraRecti, declaraOld);
		comparacionListaFormBFacturas(declaraRecti, declaraOld);//se adiciona para comparar facturas considerando todas las facturas 
		comparacionListaDatoItem(declaraRecti, declaraOld);//se adiciona para comparar los items considerando todas las facturas
			
	}
 
	
	/**
	 * Comparacion cab declara.
	 * 
	 * @param duaRecti DUA
	 * @param duaOld DUA
	 * @throws Exception 
	 */
	public void comparacionCabDeclara(DUA duaRecti, DUA duaOld) throws Exception {

		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

		String codTabla = ConstantesDataCatalogo.TABLA_CAB_DECLARA;
		Map<String, Object> clave = obtenerClave(codTabla, duaRecti);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codregimen"), datos, "COD_REGIMEN", "dua.codregimen","./userram:AssociatedCrossBorderCustomsProcedure/ram:TypeCode");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codaduanaorden"), datos, "COD_ADUANA", "dua.codaduanaorden","./userram:AssociatedCrossBorderCustomsProcedure/ram:DeclarationLodgementLogisticsLocation/ram:ID");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codmodalidad"), datos, "COD_MODALIDAD", "dua.codmodalidad","./userram:AssociatedCrossBorderCustomsProcedure/ram:TransactionNatureCode");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codlugarecepcion"), datos, "COD_LUGARRECEP", "dua.codlugarecepcion","./userram:ExaminationTransportEvent/ram:OccurrenceLogisticsLocation/ram:TypeCode");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codtiplugarrecep"), datos, "COD_TIPLUGARRECEP", "dua.codtiplugarrecep","./rsm:SpecifiedGoodsClearanceConsignment/userram:ExaminationTransportEvent/ram:OccurrenceLogisticsLocation/ram:TypeCode");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codanexo"), datos, "COD_LOCALANEXO", "dua.codanexo","./userram:ExaminationTransportEvent/ram:OccurrenceLogisticsLocation/ram:SubordinateSubordinateLocation/ram:ID");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttpesobruto"), datos, "CNT_PESOBRUTO_TOTAL", "dua.cnttpesobruto","./userram:GrossWeightMeasure");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttpesoneto"), datos, "CNT_PESONETO_TOTAL", "dua.cnttpesoneto","./userram:NetWeightMeasure");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtotfobclvta"), datos, "MTO_TOTFOBDOL", "dua.mtotfobclvta", "./userram:FOBAmount");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtotflecomex"), datos, "MTO_TOTFLETEDOL", "dua.mtotflecomex", null);
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtotsegotros"), datos, "MTO_TOTSEGDOL", "dua.mtotsegotros","./userram:InsuranceValueAmount");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtovaladuana"), datos, "MTO_TOTVALORADU", "dua.mtovaladuana","./userram:DeclaredValueForCustomsAmount");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtotajustes"), datos, "MTO_TOTAJUSTESDOL", "dua.mtotajustes", null);
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cntnumseries"), datos, "CNT_TOTSERIES", "dua.cntnumseries","./userram:ConsignmentItemQuantity");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttcantbulto"), datos, "CNT_TOTBULTOS", "dua.cnttcantbulto","./userram:PackageQuantity");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "numruclugarecep"), datos, "COD_RUCLUGRECEP", "dua.numruclugarecep","./userram:ExaminationTransportEvent/ram:OccurrenceLogisticsLocation/ram:ID");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "mtototautoliq"), datos, "MTO_TOTAUTOLIQ", "dua.mtototautoliq","./userram:AssociatedCrossBorderCustomsProcedure/ram:TotalPayableAmount");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttqunifis"), datos, "CNT_TQUNIFIS", "dua.cnttqunifis","./userram:AssociatedCrossBorderCustomsProcedure/ram:TariffQuantity");
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codpropiedad"), datos, "COD_PROPIEDAD", "dua.codpropiedad", null);
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codtipoplazo"), datos, "COD_TIPOPLAZO", "dua.codtipoplazo", null);
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "cnttqunicom"), datos, "CNT_TQUNICOM", "dua.cnttqunicom", null);
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "numplazosol"), datos, "NUM_PLAZOSOL", "dua.numplazosol", null);
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codtipotratamiento"), datos, "COD_TIPTRATMERC", "dua.codtipotratamiento", null);
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codprodurgente"), datos, "COD_PRODURGENTE", "dua.codprodurgente", null);
		
		Date fecfinprovsionalRecti = duaRecti.getFecfinprovsional();
		Date fecfinprovsionalActu = duaOld.getFecfinprovsional();
		if (fecfinprovsionalRecti == null)
			fecfinprovsionalRecti = SunatDateUtils.getDateFromInteger(99991231); // valor por defaul 99991231

		if (fecfinprovsionalActu == null)
			fecfinprovsionalActu = SunatDateUtils.getDateFromInteger(99991231); // valor por defaul 99991231

		agregarCambioAtributo(comparaAtributo(fecfinprovsionalRecti, fecfinprovsionalActu), datos, "FEC_FINPROVSIONAL", "dua.fecfinprovsional", null);

		// dato pago Declaracion
		// dato pago transaccion
		DatoPago pagoRec = duaRecti.getPago();
		DatoPago pagoOrig = duaOld.getPago();

		if (pagoRec == null)
			pagoRec = new DatoPago();
		if (pagoOrig == null)
			pagoOrig = new DatoPago();

		DatoPagoDecla datPagoDecRec = pagoRec.getPagoDeclaracion();
		DatoPagoDecla datoPagoDecOrig = pagoOrig.getPagoDeclaracion();

		DatoPagoTrans datPagoTraRec = pagoRec.getPagoTransaccion();
		DatoPagoTrans datoPagoTraOrig = pagoOrig.getPagoTransaccion();

		agregarCambioAtributo(comparaAtributo(datPagoDecRec, datoPagoDecOrig, "codgarantia"), datos, "NUM_CTACTE", "dua.pago.pagoDeclaracion.codgarantia", null);
		agregarCambioAtributo(comparaAtributo(datPagoTraRec, datoPagoTraOrig, "codmodpago"), datos, "COD_MODPAGO", "dua.pago.pagoTransaccion.codmodpago", null);
		agregarCambioAtributo(comparaAtributo(datPagoTraRec, datoPagoTraOrig, "codentipago"), datos, "COD_ENTIPAGO","dua.pago.pagoTransaccion.codentipago", null);
		agregarCambioAtributo(comparaAtributo(datPagoTraRec, datoPagoTraOrig, "numplazcredito"), datos, "CNT_PLZCREDITO","dua.pago.pagoTransaccion.numplazcredito", null);
		agregarCambioAtributo(comparaAtributo(datPagoTraRec, datoPagoTraOrig, "feccarcr"), datos, "FEC_CARCR","dua.pago.pagoTransaccion.feccarcr", null);


		// Dato Otra Aduana
		DatoOtraAduana datOtrAduaRect = duaRecti.getOtraAduana();
		DatoOtraAduana datOtrAduOrig = duaOld.getOtraAduana();

		// comentado no se conoce la ubicacion real del atributo 17/12/2009 revisar
		/*
		 * addDiferencia(datOtrAduaRect, datOtrAduOrig,"codviatrades", datos, "COD_TIPADUDEST" , "dua.otraAduana.codviatrades", null);
		 */

		agregarCambioAtributo(comparaAtributo(datOtrAduaRect, datOtrAduOrig, "codopadusal"), datos, "COD_ADUDEST", "dua.otraAduana.codopadusal", null);
		// Dato manifiesto
		DatoManifiesto manifRecti = duaRecti.getManifiesto();
		DatoManifiesto manigOrig = duaOld.getManifiesto();

		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "codaduamanif"), datos, "COD_ADUAMANIFIESTO", "dua.manifiesto.codaduamanif",null);
		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "codtipomanif"), datos, "COD_TIPMANIFIESTO", "dua.manifiesto.codtipomanif", null);
		/*branch 2011-009 ingreso hosorio inicio*/
		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "codmodtransp"), datos, "COD_VIATRANS");
		/*branch 2011-009 ingreso hosorio fin*/

		// comparacion especial
		String annmanifrecti = null;
		String annmaniforig = null;
		/*branch 2011-009 hosorio*/
		annmanifrecti="0";
		annmaniforig="0";
		/*branch 2011-009 hosorio fin*/
		if (manifRecti != null && SunatStringUtils.isLengthGreaterOrEqualsThanNumber(manifRecti.getAnnmanif(), 4))
			annmanifrecti = manifRecti.getAnnmanif().substring(0, 4);
		if (manigOrig != null && SunatStringUtils.isLengthGreaterOrEqualsThanNumber(manigOrig.getAnnmanif(), 4))
			annmaniforig = manigOrig.getAnnmanif().substring(0, 4);
		/*inicio de ajuste por comparacion con ceros por error reportado pase 490*/
		String numemanifrecti = null;
		String numemaniforig = null;
		  numemanifrecti = "0";
		  numemaniforig = "0";
		if(manifRecti !=null && !SunatStringUtils.isEmpty(manifRecti.getNummanif()))
			numemanifrecti = (new Integer (manifRecti.getNummanif())).toString();
		if(manigOrig !=null && !SunatStringUtils.isEmpty(manigOrig.getNummanif()))
			numemaniforig = (new Integer (manigOrig.getNummanif())).toString();
		/*fin de ajuste*/
			

		agregarCambioAtributo(comparaAtributo(annmanifrecti, annmaniforig), datos, "ANN_MANIFIESTO", "dua.manifiesto.annmanif", null);
		agregarCambioAtributo(comparaAtributo(numemanifrecti, numemaniforig), datos, "NUM_MANIFIESTO", "dua.manifiesto.nummanif", null);// ajuste de pase 490
//		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "nummanif"), datos, "NUM_MANIFIESTO", "dua.manifiesto.nummanif", null);
		//agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);
		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "feciniembarque"), datos, "FEC_INIEMBARQUE", "dua.manifiesto.feciniembarque",null);
		agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "numviaje"), datos, "NUM_VIAJE", "dua.manifiesto.numviaje", null);
		if(!sonIgualesValidacionIncluyeDefault(duaRecti.getIndSocorro(), duaOld.getIndSocorro(),new String("N"))){
			agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "indSocorro"), datos, "IND_SOCORRO", null, null);
		}		
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "fecfinacoregimen"), datos, "FEC_VENREGIMEN", null, null);
		/*branch ingreso 2011-009 hosorio inicio*/
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codtipoperacion"), datos, "COD_TIPDESP");

		/* PAS20145E220000090 - MATC 20140610 INICIO */
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "fecLlegada"), datos, "FEC_LLEGADA", "dua.fecLlegada", null);

		//agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);
		/* PAS20145E220000090 - MATC 20140610 FINAL */

		/* PAS20145E220000105 - BUG 18338 inicio se incorpora*/
		String modalidadRecti=this.tipoComparacion.equals("N") ? duaRecti.getCodmodalidad() : duaOld.getCodmodalidad();
		if(modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)){
			Date fechaDeclara=this.tipoComparacion.equals("N") ? duaRecti.getFecdeclaracion() : duaOld.getFecdeclaracion();
			Date fechaLlegada=this.tipoComparacion.equals("N") ? duaRecti.getFecLlegada() : duaOld.getFecLlegada();
			DatoManifiesto manifDUAURG =this.tipoComparacion.equals("N") ? duaRecti.getManifiesto() : duaOld.getManifiesto();
			if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaDeclara, fechaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA)){
				// esUrgenteExcepcional
				/*String codaduamanif=manifDUA.getCodaduamanif();
		   		String annmanif=SunatStringUtils.length(manifDUA.getAnnmanif())>3?manifDUA.getAnnmanif().substring(0,4):null;
		   		String nummanif=manifDUA.getNummanif();
		   		String codmodtransp=manifDUA.getCodmodtransp();
		   		String codtipmanif  = manifDUA.getCodtipomanif();
	    		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
	    		if(codtipmanif!=null && annmanif!=null){
		    		Manifiesto manif =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
		    		if( manif != null ) {
		    			Date fecTerminoDeDescarga = manif.getFechaTerminoDeDescarga();*/

				Date fecTerminoDeDescarga = obtieneFechaDescarga(manifDUAURG);
				if (!SunatDateUtils.sonIguales(fecTerminoDeDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
					agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);
				}	    			
				/*}
	    		}*/
			}else{//esUrgenteAnticipada (tiene fechaDescarga)
				Date fecTerminoDeDescarga = obtieneFechaDescarga(manifDUAURG);
				if (!SunatDateUtils.sonIguales(fecTerminoDeDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
					agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);
				}	
			}
		}//FIN DE URGENTES
		/* PAS20145E220000105 - BUG 18338 Fin*/
		/*PAS20145E220000105 - BUG 18550 Inicio*/
		else if(modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)){
			DatoManifiesto manifDUAEXC =this.tipoComparacion.equals("N") ? duaRecti.getManifiesto() : duaOld.getManifiesto();
			Date fecTerminoDeDescarga = obtieneFechaDescarga(manifDUAEXC);

			if (!SunatDateUtils.sonIguales(fecTerminoDeDescarga, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
				agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);
			}

		}//FIN DE EXCEPCIONALES
		else if(modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)){
			//agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);
			/*PAS20145E220000105 - BUG 18550 Fin*/			
			/*PAS20145E220000399 - BUG 20554 Inicio*/	
			DatoManifiesto manifDUAEXC = this.tipoComparacion.equals("N") ? (duaRecti.getManifiesto()!=null ? duaRecti.getManifiesto():null) :
				(duaOld.getManifiesto()!=null? duaOld.getManifiesto():null);

			Map<Object, Object> manifiestoMap=null;
			if (manifDUAEXC != null && 	manifDUAEXC.getNummanif()!=null &&	manifDUAEXC.getCodaduamanif()!= null &&	manifDUAEXC.getCodtipomanif()!=null && 
					manifDUAEXC.getCodmodtransp()!=null) {

				String annManif = "0";
				Map<String, Object> paramsMap = new HashMap<String, Object>();
				if (SunatStringUtils.length(manifDUAEXC.getAnnmanif()) > 3)	annManif = manifDUAEXC.getAnnmanif().substring(0, 4);
				paramsMap.put("anioManifiesto", annManif);
				paramsMap.put("numeroManifiesto",SunatStringUtils.lpad(manifDUAEXC.getNummanif(), 6, ' '));
				paramsMap.put("aduana", manifDUAEXC.getCodaduamanif());
				paramsMap.put("tipoManifiesto", manifDUAEXC.getCodtipomanif());
				paramsMap.put("viaTransporte", manifDUAEXC.getCodmodtransp());

				manifiestoMap = ((CabManifiestoDAO)fabricaDeServicios.getService("manifiesto.manifiestoDAO")).getByNumeroAnioAduanaTipoManifTipoVia(paramsMap);	    		 
			}
			String fecTerminoDeDescargaBD = manifiestoMap!=null? new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(manifiestoMap.get("fechaTerminoDeDescarga")) : null;
			if(fecTerminoDeDescargaBD!=null && !SunatDateUtils.sonIguales(SunatDateUtils.getDate(fecTerminoDeDescargaBD,"MM/dd/yyyy"), SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){
				//Si no tiene fecha de regu en la dua, coteja las fechas de llegada
				Date fechaRegu=this.tipoComparacion.equals("N") ?  duaOld.getFecregulariza(): duaRecti.getFecregulariza();
				if(fechaRegu==null || (fechaRegu!=null && SunatDateUtils.sonIguales(fechaRegu, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA))){
					//No corresponde comparar fectermino, sino fecllegada, que ya se ve arriba.
				}				
			}else{
				agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);
			}

		}else{
			agregarCambioAtributo(comparaAtributo(manifRecti, manigOrig, "fectermino"), datos, "FEC_TERM", "dua.manifiesto.fectermino", null);	
		}/*PAS20145E220000399 - BUG 20554 Fin*/	

		/*branch ingreso 2011-009 hosorio fin*/		
		// sobre esta tabla siempre se hara modificaciones , no eliminacion ni creacion de registro
		agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);

	}


	/**
	 * Obtiene Fecha descarga del manifiesto
	 * 
	 * @param manifDUAXML DatoManifiesto
	 * @returns fecTerminoDescarga Date
	 */
	public Date obtieneFechaDescarga(DatoManifiesto manifDUAXML){//adicionada por bug 18550 arey

		Date fecTerminoDescarga=SunatDateUtils.getDefaultDate();

		if(manifDUAXML!=null){
			String codaduamanif=manifDUAXML.getCodaduamanif();
			String annmanif=SunatStringUtils.length(manifDUAXML.getAnnmanif())>3?manifDUAXML.getAnnmanif().substring(0,4):null;
			String nummanif=manifDUAXML.getNummanif();
			String codmodtransp=manifDUAXML.getCodmodtransp();
			String codtipmanif  = manifDUAXML.getCodtipomanif();
			ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");

			if(codaduamanif!=null && annmanif!=null && nummanif!=null &&  codmodtransp!=null && codtipmanif!=null){
				Manifiesto manifBD =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
				if( manifBD != null ) {
					fecTerminoDescarga = manifBD.getFechaTerminoDeDescarga();
				}
			}
		}
		return fecTerminoDescarga;
	}

	/**
	 * Comparacion manifiesto.
	 * 
	 * @param rectificado DatoManifiesto
	 * @param actual DatoManifiesto
	 * @throws Exception 
	 */
	public void comparacionManifiesto(DatoManifiesto rectificado, DatoManifiesto actual) throws Exception {
		if (rectificado == null)
			rectificado = new DatoManifiesto(); // manifiesto en blanco
		if (actual == null)
			actual = new DatoManifiesto(); // manifiesto en blanco
		// se habilita equipamientos
		comparacionListaEquipamiento(rectificado.getListEquipamientos(), actual.getListEquipamientos());
		comparacionEmpresaTransporte(rectificado.getEmpTransporte(), actual.getEmpTransporte());
	}

	/**
	 * Comparacion lista equipamiento.
	 * 
	 * @param listaRectificado Elementos<DatoEquipamiento>
	 * @param listaActual Elementos<DatoEquipamiento>
	 * @throws Exception 
	 */
	public void comparacionListaEquipamiento(Elementos<DatoEquipamiento> listaRectificado, Elementos<DatoEquipamiento> listaActual) throws Exception {
		// verifica los nuevos o rectificados
		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoEquipamiento equipRec : listaRectificado) {
				DatoEquipamiento equipOrig = (DatoEquipamiento) buscarEnLista(listaActual, equipRec);
				// tabla equipamiento es de manifiesto
				comparacionEquipamiento(equipRec, equipOrig);
				// REVISAR PORBLEMAS DE FOREIGN KEY USADISMC.FK01_PRECINTO_MOVO
				comparacionListaPrecinto(equipRec, equipOrig);
			}
		}
	}

	/**
	 * Comparacion equipamiento.
	 * 
	 * @param rectificado DatoEquipamiento
	 * @param actual DatoEquipamiento
	 * @throws Exception 
	 */
	public void comparacionEquipamiento(DatoEquipamiento rectificado, DatoEquipamiento actual) throws Exception {
		if (rectificado != null) {
			String codTabla = ConstantesDataCatalogo.TABLA_EQUIPAMIENTO;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);

			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtamequip"), datos, "COD_TAM_EQUIPAMIEN", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codcondequip"), datos, "COD_LLENADO", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
			
			if (SunatStringUtils.isEqualTo(tipoCambio, Constants.IND_REGISTRO_NUEVO)){
				if (!CollectionUtils.isEmpty(rectificado.getListmovEquipamiento())) {
					codTabla = ConstantesDataCatalogo.TABLA_MOVEQUIPAMIENTO;
					for (DatoMovEquipamiento rectif : rectificado.getListmovEquipamiento()) {
						//codTabla = ConstantesDataCatalogo.TABLA_MOVEQUIPAMIENTO;
						datos = new HashMap<String, DatoRectificacionBean>();
						clave = obtenerClave(codTabla, rectif);
						agregarCambioRegistro(codTabla, clave, datos,  Constants.IND_REGISTRO_NUEVO);
					}
				}
			}
		}
	}
	
	
	/**
	 * Comparacion lista precinto.
	 * 
	 * @param equipRec DatoEquipamiento
	 * @param equipOrig DatoEquipamiento
	 * @throws Exception 
	 */
	public void comparacionListaPrecinto(DatoEquipamiento equipRec, DatoEquipamiento equipOrig) throws Exception {
		Map<String, Object> clave = new HashMap<String, Object>();
		clave.put("NUM_CORREDOC", numcorredoc);
		clave.put("NUM_EQUIPAMIENTO", equipRec.getNumequipo());
		clave.put("COD_TIPMOV", "99"); // revisar

		Elementos<DatoPrecinto> listPrecintosRect = null;
		Elementos<DatoPrecinto> listPrecintosOrig = null;

		if (equipRec != null)
			listPrecintosRect = equipRec.getListPrecintos();
		if (equipOrig != null)
			listPrecintosOrig = equipOrig.getListPrecintos();

		if (!CollectionUtils.isEmpty(listPrecintosRect)) {
			for (DatoPrecinto precRec : listPrecintosRect) {
				DatoPrecinto precOrig = (DatoPrecinto) buscarEnLista(listPrecintosOrig, precRec);
				comparacionPrecinto(precRec, precOrig, clave);
			}
		}
	}

	/**
	 * Comparacion precinto.
	 * 
	 * @param rectificado DatoPrecinto
	 * @param actual DatoPrecinto
	 * @param claveForanea Map<String,Object>
	 * @throws Exception 
	 */
	public void comparacionPrecinto(DatoPrecinto rectificado, DatoPrecinto actual, Map<String, Object> claveForanea) throws Exception {

		if (rectificado != null) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PRECINTO;
			clave.putAll(claveForanea);
			clave.put("NUM_PRECINTO", rectificado.getNumprecinto());
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);			
		}
	}

	/**
	 * Comparacion empresa transporte.
	 * 
	 * @param rectificado Participante
	 * @param actual Participante
	 * @throws Exception 
	 */
	public void comparacionEmpresaTransporte(Participante rectificado, Participante actual) throws Exception {
		// empresa de transporte

		//if (rectificado != null) {
		if (!isEmpty(rectificado)) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC;
			// para el caso de empresa de transporte la clave es NUM_CORREDOC + COD_TIPPARTIC
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", rectificado.getTipoParticipante().getCodDatacat());
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			/*branch ingreso 2011-009 hosorio inicio*/
			try {
				if(!rectificado.getTipoParticipante().getCodDatacat().equals(actual.getTipoParticipante().getCodDatacat())){
					tipoCambio=Constants.IND_REGISTRO_NUEVO;
					//PAS20112A600001128 colocamos la secuencia del actual, dado que en el antiguo no se tiene ese registro
					clave.put("NUM_SECPARTIC", Long.parseLong("0"));
					actual=null;
				}
				else{
					//PAS20112A600001128 colocamos la secuencia del actual, dado que en el antiguo no se tiene ese registro
					clave.put("NUM_SECPARTIC", actual.getSecuenciaDeParticipantes());
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			/*branch ingreso 2011-009 hosorio fin*/


			agregarCambioAtributo(comparaAtributo(rectificado, actual, "tipoDocumentoIdentidad.codDatacat"), datos, "COD_TIPDOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numeroDocumentoIdentidad"), datos, "NUM_DOCIDENT", null, null);		
			if (!SunatStringUtils.isEmptyTrim(rectificado.getNombreRazonSocial()))
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nombreRazonSocial"), datos, "NOM_RAZONSOCIAL", null, null);	
			if (!SunatStringUtils.isEmptyTrim(rectificado.getDireccion()))
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "direccion"), datos, "DIR_PARTIC", null, null);

			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion lista observacion.
	 * 
	 * @param listaRectificado Elementos<Observacion>
	 * @param listaActual Elementos<Observacion>
	 * @throws Exception 
	 */
	public void comparacionListaObservacion(Elementos<Observacion> listaRectificado, Elementos<Observacion> listaActual) throws Exception {

		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (Observacion rectificado : listaRectificado) {
				Observacion actual = (Observacion) buscarEnLista(listaActual, rectificado);
				comparacionObservacion(rectificado, actual);
			}
		}
	}

	/**
	 * Comparacion observacion.
	 * 
	 * @param rectificado Observacion
	 * @param actual Observacion
	 * @throws Exception 
	 */
	public void comparacionObservacion(Observacion rectificado, Observacion actual) throws Exception {

		if (rectificado != null) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_OBSERVACION;
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("NUM_SECOBS", rectificado.getNumsecuencia());
			/*branch ingreso 2011-009  hosorio inicio 26/05/2011*/
			clave.put("COD_TIPOBS", rectificado.getCodtipobserva());
			//String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			//agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipobserva"), datos, "COD_TIPOBS", null, null);
			/*branch ingreso 2011-009  hosorio fin 26/05/2011*/
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "obsdeclaracion"), datos, "OBS_OBS", "obsdeclaracion", rectificado);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion lista indicador dua.
	 * 
	 * @param listaRectificado Elementos<DatoIndicadores>
	 * @param listaActual Elementos<DatoIndicadores>
	 * @throws Exception 
	 */
	public void comparacionListaIndicadorDUA(Elementos<DatoIndicadores> listaRectificado, Elementos<DatoIndicadores> listaActual) throws Exception {

		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoIndicadores rectificado : listaRectificado) {
				DatoIndicadores actual = (DatoIndicadores) buscarEnLista(listaActual, rectificado);
				comparacionIndicadorDUA(rectificado, actual);
			}
		}
	}

	/**
	 * Comparacion indicador dua.
	 * 
	 * @param rectificado DatoIndicadores
	 * @param actual DatoIndicadores
	 * @throws Exception 
	 */
	public void comparacionIndicadorDUA(DatoIndicadores rectificado, DatoIndicadores actual) throws Exception {

		if (rectificado != null) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_INDICADOR", rectificado.getCodtipoindica());
			String codTabla = ConstantesDataCatalogo.TABLA_INDICADORDUA;
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			
			//PAS20165E220200010 RSV no se permite actualiza el indicador 05 de importador frecuente
			//region amancillaa SDA2-RIN18-PAS20171U220200035
			if ( rectificado.getCodtipoindica()!=null &&  
			     !rectificado.getCodtipoindica().equals(ConstantesDataCatalogo.INDICADOR_IMPORTADOR_FRECUENTE)
					&& !ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA.equals(rectificado.getCodtipoindica())) {

			//endregion amancillaa

				if(tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)){
					IndicadorDUADAO indicadorDuaDAO = fabricaDeServicios.getService("indicadorDUADAO");
					Map<String, Object> paramInd = new HashMap<String, Object>();				
					paramInd.put("num_corredoc",clave.get("NUM_CORREDOC"));
					paramInd.put("cod_indicador",clave.get("COD_INDICADOR"));	
					Map<String, Object> mapIndicador = indicadorDuaDAO.findByDocumentoAndValor(paramInd);
					if(mapIndicador==null){//NO EXISTE EN BD
						agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
					}
					else {
						if(mapIndicador.get("IND_ACTIVO").toString().equals(Constants.INDICADOR_NO_ACTIVO))agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
					}
					
				}else{			
					agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
				}
			}
			//PAS20165E220200010 RSV no se permite actualiza el indicador 05 de importador frecuente
			
			/*if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)){//bug 18461  pase 105 arey se quita por bug 18605 no se envia a rectificar
				rectificado.setValindicador("T");
			}
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "valindicador"), datos, "COD_TIPOREGISTRO", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
			 */

		}
	}

	/**
	 * Comparacion lista doc asociado.
	 * 
	 * @param listaRectificado Elementos<DatoOtroDocSoporte>
	 * @param listaActual Elementos<DatoOtroDocSoporte>
	 * @throws Exception 
	 */
	public void comparacionListaDocAsociado(Elementos<DatoOtroDocSoporte> listaRectificado, Elementos<DatoOtroDocSoporte> listaActual)
			throws Exception {

		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoOtroDocSoporte rectificado : listaRectificado) {
				DatoOtroDocSoporte actual = (DatoOtroDocSoporte) buscarEnLista(listaActual, rectificado);
				comparacionDocAsociado(rectificado, actual);
			}
		}
	}

	/**
	 * Comparacion doc autorizante.
	 * 
	 * @param rectificado DatoDocAutorizante
	 * @param actual DatoDocAutorizante
	 * @throws Exception 
	 */
	public void comparacionDocAutorizante(DatoDocAutorizante rectificado, DatoDocAutorizante actual,boolean usarCodigoNuevo) throws Exception {

		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_DOCASOCIADO;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			// caso especial el a�o viene en formato fecha hay que transformarlo a numerico
			Long annodocRect = null;
			Long annodocAct = null;
			if (SunatStringUtils.isLengthGreaterOrEqualsThanNumber(rectificado.getAnndocum(), 4))
				annodocRect = Long.valueOf(rectificado.getAnndocum().substring(0, 4));
			if (actual != null && SunatStringUtils.isLengthGreaterOrEqualsThanNumber(actual.getAnndocum(), 4))
				annodocAct = Long.valueOf(actual.getAnndocum().substring(0, 4));

			agregarCambioAtributo(comparaAtributo(annodocRect, annodocAct), datos, "ANN_DOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numdocum"), datos, "NUM_DOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecemision"), datos, "FEC_EMIS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipodocum"), datos, "COD_TIPDOCASO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecvencimiento"), datos, "FEC_VENC", null, null);
			//R2BZ es parte de la clave
			//agregarCambioAtributo(comparaAtributo(rectificado, actual, "codTipoOper"), datos, "COD_TIPOPER", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codentidad"), datos, "COD_ENTI", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desentidad"), datos, "OBS_OBS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipodocentidad"), datos, "COD_TIPDOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codentidademisora"), datos, "COD_IDENT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codigoAduanaAut"), datos, "COD_ADU_AUT", null, null);//P_SNADE046-2094
			//Inicio RIN14
			if(usarCodigoNuevo){
				agregarCambioAtributo(comparaAtributo(rectificado, actual, "codsubtipodocum"), datos, "COD_SUBTIPODOC", null, null);
				agregarCambioAtributo(comparaAtributo(rectificado, actual, "nroitemdocum"), datos, "NUM_ITEMDOC", null, null);
				agregarCambioAtributo(comparaAtributo(rectificado, actual, "codsubentidad"), datos, "COD_SUBENTI", null, null);
			}
			//Fin RIN14
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion lista forma facturas.
	 * 
	 * @param listaRectificado Elementos<DatoFacturaref>
	 * @param listaActual Elementos<DatoFacturaref>
	 * @throws Exception 
	 */
	public void comparacionListaFormaFacturas(Elementos<DatoFacturaref> listaRectificado, Elementos<DatoFacturaref> listaActual) throws Exception {

		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoFacturaref rectificado : listaRectificado) {
				DatoFacturaref actual = (DatoFacturaref) buscarEnLista(listaActual, rectificado);
				comparacionFormaFactura(rectificado, actual);
			}
		}
	}

	/**
	 * Comparacion forma factura.
	 * 
	 * @param rectificado DatoFacturaref
	 * @param actual DatoFacturaref
	 * @throws Exception 
	 */
	public void comparacionFormaFactura(DatoFacturaref rectificado, DatoFacturaref actual) throws Exception {

		if (rectificado != null) {

			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_FORMA_FACTU;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numfactura"), datos, "NUM_FACT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecfactura"), datos, "FEC_FACT", null, null);

			// agregarCambioAtributo(comparaAtributo(rectificado, actual,"XXX"), datos, "COD_MOMGRAB", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion lista doc autorizante.
	 * 
	 * @param listaRectificado Elementos<DatoDocAutorizante>
	 * @param listaActual Elementos<DatoDocAutorizante>
	 * @throws Exception 
	 */
	public void comparacionListaDocAutorizante(Elementos<DatoDocAutorizante> listaRectificado, Elementos<DatoDocAutorizante> listaActual)
			throws Exception {
		boolean usarCodigoNuevo = false;
		Date fecVigencia = SunatDateUtils.getDate(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService"))
				.getElementoCat("517", "FEC_INIVIG")
				.get("des_datacat").toString());

		if (SunatDateUtils.esFecha1MayorIgualQueFecha2(new Date(), fecVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			usarCodigoNuevo = true;
		}
		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoDocAutorizante rectificado : listaRectificado) {
				DatoDocAutorizante actual = (DatoDocAutorizante) buscarEnLista(listaActual, rectificado);
				comparacionDocAutorizante(rectificado, actual, usarCodigoNuevo);
			}
		}
	}

	/**
	 * Comparacion doc asociado.
	 * 
	 * @param rectificado DatoOtroDocSoporte
	 * @param actual DatoOtroDocSoporte
	 * @throws Exception 
	 */
	public void comparacionDocAsociado(DatoOtroDocSoporte rectificado, DatoOtroDocSoporte actual) throws Exception {

		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_DOCASOCIADO;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);

			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			// caso especial el a�o viene en formato fecha hay que transformarlo a numerico
			Long annodocRect = null;
			Long annodocAct = null;
			if (SunatStringUtils.isLengthGreaterOrEqualsThanNumber(rectificado.getAnndocasoc(), 4))
				annodocRect = Long.valueOf(rectificado.getAnndocasoc().substring(0, 4));
			if (actual != null && SunatStringUtils.isLengthGreaterOrEqualsThanNumber(actual.getAnndocasoc(), 4))
				annodocAct = Long.valueOf(actual.getAnndocasoc().substring(0, 4));

			//R2BZ Es parte de la clave, no debe ser parte de los datos rectificados.
			//agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipoproceso"), datos, "COD_TIPOPER", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipodocasoc"), datos, "COD_TIPDOCASO", null, null);
			agregarCambioAtributo(comparaAtributo(annodocRect, annodocAct), datos, "ANN_DOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numdocasoc"), datos, "NUM_DOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecvencimiento"), datos, "FEC_VENC", null, null);			
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecdocasoc"), datos, "FEC_EMIS", null, null);			
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipoentidad"), datos, "COD_ENTI", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desentidad"), datos, "OBS_OBS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipodocentidad"), datos, "COD_TIPDOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codentidademisora"), datos, "COD_IDENT", null, null);

			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion certi origen.
	 * 
	 * @param rectificado DatoCertificadoOrigen
	 * @param actual DatoCertificadoOrigen
	 * @throws Exception 
	 */
	public void comparacionCertiOrigen(DatoCertificadoOrigen rectificado, DatoCertificadoOrigen actual) throws Exception {

		if (rectificado == null)
			rectificado = new DatoCertificadoOrigen();
		if (actual == null)
			actual = new DatoCertificadoOrigen();
		comparacionListaAutoCertiOrigen(rectificado.getListAutocertificacion(), actual.getListAutocertificacion());
	}

	/**
	 * Comparacion lista auto certi origen.
	 * 
	 * @param listaRectificado Elementos<DatoAutocertificacion>
	 * @param listaActual Elementos<DatoAutocertificacion>
	 * @throws Exception 
	 */
	public void comparacionListaAutoCertiOrigen(Elementos<DatoAutocertificacion> listaRectificado, Elementos<DatoAutocertificacion> listaActual)
			throws Exception {
		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoAutocertificacion rectificado : listaRectificado) {
				DatoAutocertificacion actual = (DatoAutocertificacion) buscarEnLista(listaActual, rectificado);
				comparacionAutoCertificado(rectificado, actual);
			}
		}
	}

	/**
	 * Comparacion auto certificado.
	 * 
	 * @param rectificado DatoAutocertificacion
	 * @param actual DatoAutocertificacion
	 * @throws Exception 
	 */
	public void comparacionAutoCertificado(DatoAutocertificacion rectificado, DatoAutocertificacion actual) throws Exception {

		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_CERTORIGEN;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numdocumento"), datos, "NUM_CERTIFICADO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecemision"), datos, "FEC_CERTIFICADO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipoCO"), datos, "COD_TIPCERTIFICADO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipoemisorCO"), datos, "COD_EMISCERT", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nomemisorCO"), datos, "NOM_EMISCERTIF", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "feciniembarque"), datos, "FEC_INIPERIODOEMB", null, null);
			if(rectificado.getFecfinembarque()!= null
					&& !SunatDateUtils.sonIguales(rectificado.getFecfinembarque(), SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)  ){
				agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecfinembarque"), datos, "FEC_FINPEREMB", null, null);
			}			
			//agregarCambioAtributo(comparaAtributo(rectificado, actual, "nomProdmerc"), datos, "NOM_PRODMERC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nomproduc"), datos, "NOM_PRODMERC", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codcriterioO"), datos, "COD_CRITERIOORIGEN", null, null);
			if(actual!=null){
				if(!sonIgualesValidacionIncluyeDefault(rectificado.getIndtrans(), actual.getIndtrans(),new String("1"))){
					agregarCambioAtributo(comparaAtributo(rectificado, actual, "indtrans"), datos, "IND_PROCETERCERPAIS", null, null);
				}
			}else{
				agregarCambioAtributo(comparaAtributo(rectificado, actual, "indtrans"), datos, "IND_PROCETERCERPAIS", null, null);
			}

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codffco"), datos, "COD_FFCO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecEmborigen"), datos ,"FEC_EMBORIGEN", null, null); //linea adicionado por PAS20155E220100048 bug 567
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codPuertoEmbOrigen"), datos, "COD_PTOEMBORIGEN",null, null);//adicionado por PAS20155E220200172
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numautoexp"), datos, "NUM_AUTORIZEXP",null, null);//con el visto bueno de Ana Teresa PAS20165E220200047
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "indElectronico"), datos, "IND_ELECTRONICO",null, null);//PAS20181U220200056
			
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}
	
	
	/**
	 * Comparacion impo consumo.
	 * 
	 * @param duaRecti DUA
	 * @param duaOld DUA
	 * @throws Exception 
	 */
	public void comparacionImpoConsumo(DatoPagoDecla duaRecti, DatoPagoDecla duaOld) throws Exception {
		if (duaRecti != null) {
			String codTabla = ConstantesDataCatalogo.TABLA_IMPCONSUMO; // IMPCONSUMO
			Map<String, Object> clave = obtenerClave(codTabla, duaRecti);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

			// dato pago transaccion
			//DatoPago pagoRec = duaRecti.getPago();
			//DatoPago pagoOrig = duaOld.getPago();

			//if (pagoRec == null)
			//	pagoRec = new DatoPago();
			//if (pagoOrig == null)
			//	pagoOrig = new DatoPago();


			//DatoPagoDecla datPagoDecRec = pagoRec.getPagoDeclaracion();
			//DatoPagoDecla datoPagoDecOrig = pagoOrig.getPagoDeclaracion();
			String tipoCambio = evaluarCambioRegistro(duaRecti, duaOld);

			agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codbcopagoelec"), datos, "COD_BCOPAGOELEC", null, null);
			agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "numctapagoelec"), datos, "NUM_CUENTAPAGOE", null, null);		
			// sobre esta tabla siempre se hara modificaciones , no eliminacion ni creacion de registro
			//agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}
	
	/**
	 * PAS20171U220200005 Comparacion impo consumo con los totales de envios para mercancia vigente.
	 * 
	 * @param duaRecti DUA
	 * @param duaOld DUA
	 * @throws Exception 
	 */
	public void comparacionImpoConsumo(DatoPagoDecla duaRecti, DatoPagoDecla duaOld, DatoIndicadores indicadorRecti, DatoIndicadores indicadorActual) throws Exception {
		
		String codTabla = ConstantesDataCatalogo.TABLA_IMPCONSUMO; // IMPCONSUMO
		Map<String, Object> clave = new HashMap<String, Object>();
		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
		String tipoCambio = "";
		
		if (duaRecti != null) {			
			clave = obtenerClave(codTabla, duaRecti);
			tipoCambio = evaluarCambioRegistro(duaRecti, duaOld);

			agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codbcopagoelec"), datos, "COD_BCOPAGOELEC", null, null);
			agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "numctapagoelec"), datos, "NUM_CUENTAPAGOE", null, null); 
		}
		 
		if(indicadorRecti!=null){			
			if(CollectionUtils.isEmpty(clave)){
				clave.put("NUM_CORREDOC",indicadorRecti.getNumeroCorrelativo().toString());
			}
			if(tipoCambio.isEmpty()){
				tipoCambio = evaluarCambioRegistro(indicadorRecti, indicadorActual);
			}
				
			agregarCambioAtributo(comparaAtributo(indicadorRecti, indicadorActual, "destipoindica"), datos, "NUM_TOTALENVIOS", null, null);
		}
		
		if(duaRecti!=null || indicadorRecti!=null){
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion gral transito.
	 * 
	 * @param duaRecti DUA
	 * @param duaOld DUA
	 * @throws Exception 
	 */
	public void comparacionGralTransito(DUA duaRecti, DUA duaOld) throws Exception {
		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

		String codTabla = ConstantesDataCatalogo.TABLA_CAB_ADI_TRANSITO; // GRALTRANSITO
		Map<String, Object> clave = obtenerClave(codTabla, duaRecti);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codtipempaque"), datos, "COD_TIPEMPAQUE", null, null);

		// sobre esta tabla siempre se hara modificaciones , no eliminacion ni creacion de registro
		agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);
	}

	/**
	 * Comparacion gral adm tem.
	 * 
	 * @param duaRecti DUA
	 * @param duaOld DUA
	 * @throws Exception 
	 */
	public void comparacionGralAdmTem(DUA duaRecti, DUA duaOld) throws Exception {
		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
		String codTabla = ConstantesDataCatalogo.TABLA_CAB_ADI_ADMTEM; // GRALADMTEM
		Map<String, Object> clave = obtenerClave(codTabla, duaRecti);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codferia"), datos, "COD_FERIA", null, null);
		// sobre esta tabla siempre se hara modificaciones , no eliminacion ni creacion de registro
		agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);
	}

	/**
	 * Comparacion fin ubicacion.
	 * 
	 * @param duaRecti DUA
	 * @param duaOld DUA
	 * @throws Exception 
	 */
	public void comparacionFinUbicacion(DUA duaRecti, DUA duaOld) throws Exception {
		String codTabla = ConstantesDataCatalogo.TABLA_FINYUBICACION;
		Map<String, Object> clave = obtenerClave(codTabla, duaRecti);
		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "desfinalidad"), datos, "DES_FINALIDAD", null, null);

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codlocalanexo"), datos, "COD_LOCALANEXO", null, null);

		String numDocAct = null;
		String numDocRecti = null;
		if (duaOld.getRucAnexoUbicacion() != null)
			numDocAct = duaOld.getRucAnexoUbicacion().getNumeroDocumentoIdentidad();
		if (duaRecti.getRucAnexoUbicacion() != null)
			numDocRecti = duaRecti.getRucAnexoUbicacion().getNumeroDocumentoIdentidad();
		agregarCambioAtributo(comparaAtributo(numDocRecti, numDocAct), datos, "NUM_DOC_LOCMERC", null, null);

		// sobre esta tabla siempre se hara modificaciones , no eliminacion ni creacion de registro
		agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);
	}

	/**
	 * Comparacion ruc anexo ubicacion.
	 * 
	 * @param rectificado Participante
	 * @param actual Participante
	 * @throws Exception 
	 */
	public void comparacionRucAnexoUbicacion(Participante rectificado, Participante actual) throws Exception {

		if (!isEmpty(rectificado)) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC; // T0089 PARTICIPANTEDOC
			// para el caso del ruc asociado la clave es NUM_CORREDOC + COD_TIPPARTIC
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", ConstantesDataCatalogo.TIPO_OPERADOR_ANEXO_UBICACION);			
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)) clave.put("NUM_SECPARTIC", Long.parseLong("0"));
			else clave.put("NUM_SECPARTIC", actual.getSecuenciaDeParticipantes());
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "tipoDocumentoIdentidad"), datos, "COD_TIPDOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numeroDocumentoIdentidad"), datos, "NUM_DOCIDENT", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion agente.
	 * 
	 * @param rectificado DUA
	 * @param actual DUA
	 * @throws Exception 
	 */
	public void comparacionAgente(DUA rectificado, DUA actual) throws Exception {
		Map<String, Object> clave = new HashMap<String, Object>();
		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
		String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC; // T0089 PARTICIPANTEDOC
		// para el caso del agente la clave a grbar en la solicitud sera: NUM_CORREDOC+COD_TIPPARTIC

		clave.put("NUM_CORREDOC", numcorredoc);
		clave.put("COD_TIPPARTIC", ConstantesDataCatalogo.TIPO_OPERADOR_AGENTE_DE_ADUANA);		
		clave.put("NUM_SECPARTIC", Long.parseLong("0"));

		agregarCambioAtributo(comparaAtributo(rectificado, actual, "numdocumento"), datos, "NUM_DOCIDENT", "dua.numdocumento",
				"./userram:CustomsImportAgentTradeParty/ram:ID");
		agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipooper"), datos, "COD_TIPDOC", "dua.codtipooper",
				"./userram:CustomsImportAgentTradeParty/ram:ID/@schemeID");

		if (CollectionUtils.isEmpty(datos))
			clave.clear();
		// Es un dato obligatorio no cabe eliminacion , cualquiere cambio, representa es un nuevo registro		
		agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_NUEVO);
	}

	/**
	 * Comparacion dato declarante.
	 * 
	 * @param rectificado Participante
	 * @param actual Participante
	 * @throws Exception 
	 */
	public void comparacionDatoDeclarante(Participante rectificado, Participante actual) throws Exception {

		if (!isEmpty(rectificado) && tipoComparacion.equals("N")) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC; // T0089 PARTICIPANTEDOC
			// para el caso del declarante la clave a grbar en la solicitud sera: NUM_CORREDOC+COD_TIPPARTIC
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
			clave.put("NUM_SECPARTIC", actual.getSecuenciaDeParticipantes());

			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)) clave.put("NUM_SECPARTIC", Long.parseLong("0"));
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "tipoDocumentoIdentidad"), datos, "COD_TIPDOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numeroDocumentoIdentidad"), datos, "NUM_DOCIDENT", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	public Participante obtieneParticipante(String tipoParticipante)
	{
		List<Participante> listParticipante =new ArrayList<Participante>();
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("numeroCorrelativo", numcorredoc);
		paramsMap.put("codTipoParticipante", tipoParticipante);
		//		listParticipante=RectificacionServiceImpl.getInstance().getFuncionesService().getListParticipante(paramsMap);				
		listParticipante=((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).getListParticipante(paramsMap);
		return listParticipante.get(0);
	}
	/*branch ingreso 2011-009 hosorio inicio 21/07/2011 */
	public void comparacionDatoPuntoLLegada(String rectificado, String actual) throws Exception {

		if (rectificado != null) {
			Map<String, Object> clave = new HashMap<String, Object>();

			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC;
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL);
			clave.put("NUM_SECPARTIC", obtieneParticipante(ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL).getSecuenciaDeParticipantes());

			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)) clave.put("NUM_SECPARTIC", Long.parseLong("0"));
			agregarCambioAtributo(comparaAtributo(rectificado, actual), datos, "NUM_DOCIDENT", null, null);
			//agregarCambioAtributo(comparaAtributo(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC, null), datos, "COD_TIPDOC", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}	
	/*branch ingreso 2011-009 hosorio fin 21/07/2011 */

	/**
	 * Comparacion listaseries.
	 * 
	 * @param listaRectificado Elementos<DatoSerie>
	 * @param listaActual Elementos<DatoSerie>
	 * @throws Exception 
	 */
	public void comparacionListaseries(Elementos<DatoSerie> listaRectificado, Elementos<DatoSerie> listaActual) throws Exception {
		int iserie = 0;
		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoSerie rectificado : listaRectificado) {
				DatoSerie actual = (DatoSerie) buscarEnLista(listaActual, rectificado);
				comparacionDetDeclara(rectificado, actual, iserie);

				comparacionDetImpoConsumo(rectificado.getDatoAdiSerieImpoConsumo(), actual!=null ? actual.getDatoAdiSerieImpoConsumo():null, iserie);
				comparacionSerieReexp(rectificado.getDatoAdiSerieAtreexp(), actual!=null ? actual.getDatoAdiSerieAtreexp():null, iserie);
				comparacionConveniosSerie(rectificado, actual, iserie);
				comparacionListaDeclPrecede(rectificado, actual, iserie);
				comparacionListaVehiculoCetico(rectificado, actual, iserie);
				comparacionListaSerieDocSoporteAutoriz(rectificado, actual, iserie);
				comparacionListaSerieDocSoporteFactura(rectificado, actual, iserie);
				iserie++;
			}// fin de SERIES
		}
	}

	/**
	 * Comparacion det declara.
	 * 
	 * @param rectificado DatoSerie
	 * @param actual DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionDetDeclara(DatoSerie rectificado, DatoSerie actual, Integer iserie) throws Exception {

		if (rectificado != null) {

			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			String codTabla = ConstantesDataCatalogo.TABLA_DET_DECLARA;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codaplultra"), datos, "COD_ULTRACTIVIDAD", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codunicomer"), datos, "COD_UNICOMER", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntunicomer"), datos, "CNT_COMER", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codclasbul"), datos, "COD_CLASEBULTOS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntbultos"), datos, "CNT_BULTO", "dua.listSeries[" + iserie + "].cntbultos",
					null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntpesoneto"), datos, "CNT_PESO_NETO", "dua.listSeries[" + iserie
					+ "].cntpesoneto", null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntpesobruto"), datos, "CNT_PESO_BRUTO", "dua.listSeries[" + iserie
					+ "].cntpesobruto", null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntpesovehic"), datos, "CNT_PESOVEHIC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codunifis"), datos, "COD_UNIFISICA", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntunifis"), datos, "CNT_UNIFIS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codunicomisc"), datos, "COD_UNI_ISC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntunicomisc"), datos, "CNT_UNIISC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numpartnandi"), datos, "NUM_PARTNANDI", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numpartnalad"), datos, "NUM_PARNALADISA", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numpartnaban"), datos, "NUM_PARNABANDINA", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numpartcorre"), datos, "NUM_PARCORRELACION", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codpaisorige"), datos, "COD_PAISORIGEN", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codpaisadqui"), datos, "COD_PAISADQUI", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codpaisprodes"), datos, "COD_PAISPROCED", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codmoneda"), datos, "COD_MONETRANS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofobmon"), datos, "MTO_FOBMONTRANS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofobdol"), datos, "MTO_FOBDOL", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofledol"), datos, "MTO_FLETEDOL", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtosegdol"), datos, "MTO_SEGDOL", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtoajuste"), datos, "MTO_AJUSTE", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtovaladuana"), datos, "MTO_VALORADU", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtiposeg"), datos, "COD_TIPSEG", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipoflete"), datos, "COD_TIPFLETE", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "descomercial"), datos, "DES_COMER", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desformapres"), datos, "DES_FORMAPRESEN", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desmatecomp"), datos, "DES_MATECOMP", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desusoaplica"), datos, "DES_USOAPLIC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desotros"), datos, "DES_OTROSCARAC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codestamerca"), datos, "COD_ESTMERC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecexpiracion"), datos, "FEC_EXPIRACION", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtnan"), datos, "COD_TIPTASAAPLICAR", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipomarge"), datos, "COD_TIPMARGEN", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "valestimado"), datos, "MTO_ESTIMADO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codvalajuste"), datos, "COD_VALORAJUSTE", null, null);
//			agregarCambioAtributo(comparaAtributo(rectificado, actual, "poralcohol"), datos, "POR_ALCOHOL", null, null);// se retira porque el campo corresponde a det_adi_impoconsu PASE436
			DatoProducto produRec = null;
			DatoProducto producOrig = null;
			
			if (rectificado != null)
				produRec = rectificado.getProducto();
			if (actual != null)
				producOrig = actual.getProducto();
			agregarCambioAtributo(comparaAtributo(produRec, producOrig, "codexpantidum"), datos, "COD_EXPOAPLICANTID", null, null);
			agregarCambioAtributo(comparaAtributo(produRec, producOrig, "codpantidum"), datos, "COD_PRODANTID", null, null);
			agregarCambioAtributo(comparaAtributo(produRec, producOrig, "mtofobfactu"), datos, "MTO_FOBFACT", null, null);
			DatoMercancia mercanciaRect = null;
			DatoMercancia mercanciaOrig = null;
			if (rectificado != null)
				mercanciaRect = rectificado.getMercancia();
			if (actual != null)
				mercanciaOrig = actual.getMercancia();
			agregarCambioAtributo(comparaAtributo(mercanciaRect, mercanciaOrig, "codtipoexoneracion"), datos, "COD_TIPEXONRESTRI", null, null);
			agregarCambioAtributo(comparaAtributo(mercanciaRect, mercanciaOrig, "codexoneracion"), datos, "COD_EXMERCREST", null, null);
			agregarCambioAtributo(comparaAtributo(mercanciaRect, mercanciaOrig, "codproducto"), datos, "COD_PRODRESTR", null, null);
			agregarCambioAtributo(comparaAtributo(mercanciaRect, mercanciaOrig, "codriesgosanitario"), datos, "COD_RSSENASA", null, null);
			DatoDocTransporte docTransRect = getDocTransporte(rectificado,"R");
			DatoDocTransporte docTransOrig = getDocTransporte(actual, "A");
			agregarCambioAtributo(comparaAtributo(docTransRect, docTransOrig, "codpuerto"), datos, "COD_PUER_EMBAR", null, null);
			agregarCambioAtributo(comparaAtributo(docTransRect, docTransOrig, "fecembarque"), datos, "FEC_EMBARQUE", null, null);
			agregarCambioAtributo(comparaAtributo(docTransRect, docTransOrig, "codtipodoctrans"), datos, "COD_TIPDOCTRANSP", null, null);
			agregarCambioAtributo(comparaAtributo(docTransRect, docTransOrig, "numdoctransporte"), datos, "NUM_DOCTRANSP", null, null);
			agregarCambioAtributo(comparaAtributo(docTransRect, docTransOrig, "numdetalle"), datos, "NUM_DETALLE", null, null);
			agregarCambioAtributo(comparaAtributo(docTransRect, docTransOrig, "numdocmaster"), datos, "NUM_DOCTRANSPMASTER", null, null);
			agregarCambioAtributo(comparaAtributo(docTransRect, docTransOrig, "fecembarqueorg"), datos, "FEC_EMBORIGEN", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion det impo consumo.
	 * 
	 * @param rectificado DatoSerie
	 * @param actual DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionDetImpoConsumo(DatoAdiSerieImpoConsumo rectificado, DatoAdiSerieImpoConsumo actual, Integer iserie) throws Exception {
		if (rectificado != null) {

			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_DETIMPCONSUMO;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			/**
			 * Estos datos se cargan a nivel de series pero se graban en tabla diferente, por tanto siempre iba a dar como rectificado
			 */

			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "valpreciovta"), datos, "MTO_PVPMONNAC", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "deszonafranca"), datos, "DES_ZONAFRANCA", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "valindcodlib"), datos, "IND_ACOGCODLIBER", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofobnet"), datos, "MTO_FOBPNETO", null, null);//adicionado pase399

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "indParteVehiculo"), datos, "IND_PARTESVEHIC", null, null);//adicionado pase399
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "poralcohol"), datos, "POR_ALCOHOL", null, null);//se coloca porque el campo corresponde a det_adi_impoconsu PASE436
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion det adm temp.
	 * 
	 * @param rectificado DatoSerie
	 * @param actual DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionDetAdmTemp(DatoSerie rectificado, DatoSerie actual, Integer iserie) throws Exception {
		if (rectificado != null) {
			String codTabla = ConstantesDataCatalogo.TABLA_DET_ADI_ATPA;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			DatoProducto produRec = null;
			DatoProducto producOrig = null;

			if (rectificado != null)
				produRec = rectificado.getProducto();
			if (actual != null)
				producOrig = actual.getProducto();

			agregarCambioAtributo(comparaAtributo(produRec, producOrig, "numitem"), datos, "COD_INSUMO", null, null);

			agregarCambioAtributo(comparaAtributo(produRec, producOrig, "codtipoequi"), datos, "COD_UMEQUI", null, null);

			agregarCambioAtributo(comparaAtributo(produRec, producOrig, "cntunimedidaequi"), datos, "CNT_UNIEQUI", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion serie reexp.
	 * 
	 * @param rectificado DatoSerie
	 * @param actual DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionSerieReexp(DatoAdiSerieAtreexp rectificado, DatoAdiSerieAtreexp actual, Integer iserie) throws Exception {
		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_DET_ADI_ATREEX;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			/*DatoProducto produRec = null;
			DatoProducto producOrig = null;

			if (rectificado != null)
				produRec = rectificado.getProducto().getPormerma();
			if (actual != null)
				producOrig = actual.getPormerma();
			 */
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "pormerma"), datos, "POR_MERMA", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion convenios serie.
	 * 
	 * @param rectificado DatoSerie
	 * @param actual DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionConveniosSerie(DatoSerie rectificado, DatoSerie actual, Integer iserie) throws Exception {
		if (rectificado != null) {
			Map<String, Object> clave = new HashMap<String, Object>();
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("NUM_SECSERIE", rectificado.getNumserie());
			/*branch ingreso 2011-009 hosorio inicio*/

			if(actual != null){
				/*BUG 105 de RECTI TPIS*/
				if(actual.getCodtratprefe()!=null && (actual.getCodtratprefe()!=0 || rectificado.getCodtratprefe()!=0 )){
					clave.put("COD_TIPCONVENIO", "T");
					//clave.put("COD_CONVENIO", actual.getCodtratprefe()!=0?actual.getCodtratprefe():rectificado.getCodtratprefe());
					clave.put("COD_CONVENIO", actual.getCodtratprefe()!=0?SunatStringUtils.lpad(String.valueOf(actual.getCodtratprefe()),4,' '):SunatStringUtils.lpad(String.valueOf(rectificado.getCodtratprefe()),4,' '));
					//comparacionConvenio(rectificado.getCodtratprefe(), actual != null ? actual.getCodtratprefe() : null, clave);
					comparacionConvenioObject(rectificado.getCodtratprefe(), actual != null ? actual.getCodtratprefe() : null, clave, rectificado, actual);
					//rpumacayo pase 70
				}

				if(actual.getCodconvinter()!=null && (actual.getCodconvinter()!=0 || rectificado.getCodconvinter()!=0 )) {
					clave.put("COD_TIPCONVENIO", "I");
					//clave.put("COD_CONVENIO", actual.getCodconvinter()!=0?actual.getCodconvinter():rectificado.getCodconvinter());
					clave.put("COD_CONVENIO", actual.getCodconvinter()!=0?SunatStringUtils.lpad(String.valueOf(actual.getCodconvinter()),4,' '):SunatStringUtils.lpad(String.valueOf(rectificado.getCodconvinter()),4,' '));
					//comparacionConvenio(rectificado.getCodconvinter(), actual != null ? actual.getCodconvinter() : null, clave);
					//rpumacayo pase 70
					comparacionConvenioObject(rectificado.getCodconvinter(), actual != null ? actual.getCodconvinter() : null, clave, rectificado, actual);
				}

				if(actual.getCodliberatorio()!=null && (actual.getCodliberatorio()!=0 || rectificado.getCodliberatorio()!=0)){
					clave.put("COD_TIPCONVENIO", "C");
					//clave.put("COD_CONVENIO", actual.getCodliberatorio()!=0?actual.getCodliberatorio():rectificado.getCodliberatorio());
					clave.put("COD_CONVENIO", actual.getCodliberatorio()!=0?SunatStringUtils.lpad(String.valueOf(actual.getCodliberatorio()),4,' '):SunatStringUtils.lpad(String.valueOf(rectificado.getCodliberatorio()),4,' '));
					/*branch ingreso 2011-009 hosorio fin*/
					//comparacionConvenio(rectificado.getCodliberatorio(), actual != null ? actual.getCodliberatorio() : null, clave);
					//rpumacayo pase 70
					comparacionConvenioObject(rectificado.getCodliberatorio(), actual != null ? actual.getCodliberatorio() : null, clave, rectificado, actual);
				}
			}else{
				////ggranados pase 102
				// agregar serie con convenio
				//cactual
				if(rectificado.getCodtratprefe()!=null && rectificado.getCodtratprefe()!=0 ){
					clave.put("COD_TIPCONVENIO", "T");
					//clave.put("COD_CONVENIO", actual.getCodtratprefe()!=0?actual.getCodtratprefe():rectificado.getCodtratprefe());
					clave.put("COD_CONVENIO",SunatStringUtils.lpad(String.valueOf(rectificado.getCodtratprefe()),4,' '));
					//comparacionConvenio(rectificado.getCodtratprefe(), actual != null ? actual.getCodtratprefe() : null, clave);
					comparacionConvenioObject(rectificado.getCodtratprefe(), null, clave, rectificado, actual);
					//rpumacayo pase 70
				}

				if(rectificado.getCodconvinter()!=null && rectificado.getCodconvinter()!=0 ) {
					clave.put("COD_TIPCONVENIO", "I");
					//clave.put("COD_CONVENIO", actual.getCodconvinter()!=0?actual.getCodconvinter():rectificado.getCodconvinter());
					clave.put("COD_CONVENIO", SunatStringUtils.lpad(String.valueOf(rectificado.getCodconvinter()),4,' '));
					//comparacionConvenio(rectificado.getCodconvinter(), actual != null ? actual.getCodconvinter() : null, clave);
					//rpumacayo pase 70
					comparacionConvenioObject(rectificado.getCodconvinter(), null, clave, rectificado, actual);
				}

				if(rectificado.getCodliberatorio()!=null && (rectificado.getCodliberatorio()!=0 || rectificado.getCodliberatorio()!=0)){
					clave.put("COD_TIPCONVENIO", "C");
					//clave.put("COD_CONVENIO", actual.getCodliberatorio()!=0?actual.getCodliberatorio():rectificado.getCodliberatorio());
					clave.put("COD_CONVENIO", SunatStringUtils.lpad(String.valueOf(rectificado.getCodliberatorio()),4,' '));
					/*branch ingreso 2011-009 hosorio fin*/
					//comparacionConvenio(rectificado.getCodliberatorio(), actual != null ? actual.getCodliberatorio() : null, clave);
					//rpumacayo pase 70
					comparacionConvenioObject(rectificado.getCodliberatorio(),null , clave, rectificado, actual);
				}
				
				
			}
		}

	}

	/**
	 * Comparacion convenio.
	 * 
	 * @param rectificado Integer
	 * @param actual Integer
	 * @param claveForanea Map<String,Object>
	 * @throws Exception 
	 */
	public void comparacionConvenio(Integer rectificado, Integer actual, Map<String, Object> claveForanea) throws Exception {
		if (rectificado != null && rectificado.intValue()>0 ) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			clave.putAll(claveForanea);
			//clave.put("COD_CONVENIO", rectificado);
			String codTabla = ConstantesDataCatalogo.TABLA_CONVENIOSERIE;
			/*branch ingreso 2011-009 hosorio inicio*/
			if(actual!=null && actual.intValue()==0)
				actual=null;
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);			
			/*branch ingreso 2011-009 hosorio fin*/
			clave.put("COD_CONVENIO", SunatStringUtils.lpad(String.valueOf(rectificado),4,' '));//r2bz		
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion convenio. El metodo comparacionConvenio genera un error pq el atributo datos es null y 
	 * por tanto no agrega ningun cambio. 
	 * 
	 * @param rectificado Integer
	 * @param actual Integer
	 * @param claveForanea Map<String,Object>
	 * @throws Exception 
	 */
	private void comparacionConvenioObject(Integer rectificado, Integer actual, Map<String, Object> claveForanea, DatoSerie rectificadoObj, DatoSerie actualObj ) throws Exception {
		if (rectificado != null && rectificado.intValue()>0 ) {

			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			clave.putAll(claveForanea);
			//clave.put("COD_CONVENIO", rectificado);

			String codTabla = ConstantesDataCatalogo.TABLA_CONVENIOSERIE;

			//if(actual!=null && actual.trim().length()==0 || actual.equals("0"))
			if(actual!=null && actual.intValue()==0)
				actual=null;

			String tipoCambio = evaluarCambioRegistro(rectificado, actual);	

			//  clave.put("COD_CONVENIO", SunatStringUtils.lpad(String.valueOf(rectificado),4,' '));//se habilita
			if(tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)){//actualizado por bug 17526 arey
				agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
			}else{					
				if (clave.get("COD_TIPCONVENIO").equals("T")){
					agregarCambioAtributo(comparaAtributo(rectificadoObj, actualObj, "codtratprefe"), datos, "COD_CONVENIO", null, null);
				}
				if (clave.get("COD_TIPCONVENIO").equals("I")){
					agregarCambioAtributo(comparaAtributo(rectificadoObj, actualObj, "codconvinter"), datos, "COD_CONVENIO", null, null);
				}
				if (clave.get("COD_TIPCONVENIO").equals("C")){
					agregarCambioAtributo(comparaAtributo(rectificadoObj, actualObj, "codliberatorio"), datos, "COD_CONVENIO", null, null);
				}
				agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
			}
		}
	}

	/**
	 * Comparacion lista decl precede.
	 * 
	 * @param rectificado DatoSerie
	 * @param actual DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionListaDeclPrecede(DatoSerie rectificado, DatoSerie actual, Integer iserie) throws Exception {
		Elementos<DatoRegPrecedencia> listaRectificado = null;
		Elementos<DatoRegPrecedencia> listaActual = null;
		if (rectificado != null)
			listaRectificado = rectificado.getListRegPrecedencia();
		if (actual != null)
			listaActual = actual.getListRegPrecedencia();

		if (!CollectionUtils.isEmpty(listaRectificado)) {
			for (DatoRegPrecedencia regPreRec : listaRectificado) {
				DatoRegPrecedencia regPreOrig = buscarEnLista(listaActual, regPreRec);
				comparacionDeclPrecede(regPreRec, regPreOrig, iserie);
			}

		}
	}

	/**
	 * Comparacion decl precede.
	 * 
	 * @param rectificado DatoRegPrecedencia
	 * @param actual DatoRegPrecedencia
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionDeclPrecede(DatoRegPrecedencia rectificado, DatoRegPrecedencia actual, Integer iserie) throws Exception {
		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_DOCUPRECE_DUA;
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecvencpre"), datos, "FEC_VENCREGPRE", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion lista vehiculo cetico.
	 * 
	 * @param serieRec DatoSerie
	 * @param seriOrig DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionListaVehiculoCetico(DatoSerie serieRec, DatoSerie seriOrig, Integer iserie) throws Exception {
		// DatosVehiculos
		Elementos<DatoVehiculo> listVehiRecti = null;
		Elementos<DatoVehiculo> listVehiOrig = null;
		if (serieRec != null)
			listVehiRecti = serieRec.getListVehiculos();
		if (seriOrig != null)
			listVehiOrig = seriOrig.getListVehiculos();

		if (!CollectionUtils.isEmpty(listVehiRecti)) {
			for (DatoVehiculo vehiculoRect : listVehiRecti) {
				if(! SunatStringUtils.isEmpty(vehiculoRect.getAnnmespubli()) )
				{
					String annmespubli = vehiculoRect.getAnnmespubli();
					if (annmespubli.length()!=6 && annmespubli.length()!=1){
						String s2 = annmespubli.substring(0, 4);
						String s3 = annmespubli.substring(5, 7);
						String s4 = s2.concat(s3);
						vehiculoRect.setAnnmespubli(s4);
					} else {	
						vehiculoRect.setAnnmespubli(annmespubli);
					}
				}
				DatoVehiculo vehiOrig = (DatoVehiculo) buscarEnLista(listVehiOrig, vehiculoRect);
				comparacionVehiculoCetico(vehiculoRect, vehiOrig, iserie);
				comparacionListaMontoGastoVehiculo(vehiculoRect, vehiOrig, iserie);
			}// fin for dato vehiculo
		} // fin if vehiculo
	}

	/**
	 * Comparacion vehiculo cetico.
	 * 
	 * @param rectificado DatoVehiculo
	 * @param actual DatoVehiculo
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionVehiculoCetico(DatoVehiculo rectificado, DatoVehiculo actual, Integer iserie) throws Exception {
		if (rectificado != null) {
			String codTabla = ConstantesDataCatalogo.TABLA_VEHI_CETICO;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nomlibro"), datos, "NOM_PUBLI", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codejempl"), datos, "NUM_EJEMPLARPUB", null, null);
			//Este campo tiene Default 0 en la BD asi que verificamos con el metodo sonIgualesValidacionIncluyeDefault
			if(actual!=null){
				if(!sonIgualesValidacionIncluyeDefault(rectificado.getAnnmespubli(), actual.getAnnmespubli(),new String("0"))){
					agregarCambioAtributo(comparaAtributo(rectificado, actual, "annmespubli"), datos, "PER_PUBLI", null, null);
				}
			}else{
				agregarCambioAtributo(comparaAtributo(rectificado, actual, "annmespubli"), datos, "PER_PUBLI", null, null);				
			}
			//Este campo tiene Default 0 en la BD asi que verificamos con el metodo sonIgualesValidacionIncluyeDefault
			if(actual!=null){
				if(!sonIgualesValidacionIncluyeDefault(rectificado.getNumpagin(), actual.getNumpagin(),new Integer("0"))){
					agregarCambioAtributo(comparaAtributo(rectificado, actual, "numpagin"), datos, "NUM_PAGINA", null, null);
				}
			}else{
				agregarCambioAtributo(comparaAtributo(rectificado, actual, "numpagin"), datos, "NUM_PAGINA", null, null);
			}
			//Este campo tiene Default 0 en la BD asi que verificamos con el metodo sonIgualesValidacionIncluyeDefault
			if(actual!=null){
				if(!sonIgualesValidacionIncluyeDefault(rectificado.getNumfactconve(), actual.getNumfactconve(), new BigDecimal("0"))){
					agregarCambioAtributo(comparaAtributo(rectificado, actual, "numfactconve"), datos, "COD_FACTORCONV", null, null);
				}
			}else{
				agregarCambioAtributo(comparaAtributo(rectificado, actual, "numfactconve"), datos, "COD_FACTORCONV", null, null);
			}
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion lista monto gasto vehiculo.
	 * 
	 * @param rectificado DatoVehiculo
	 * @param actual DatoVehiculo
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionListaMontoGastoVehiculo(DatoVehiculo rectificado, DatoVehiculo actual, Integer iserie) throws Exception {
		Elementos<DatoMontoGasto> listGastosRecti = null;
		Elementos<DatoMontoGasto> listGastosOrig = null;
		if (rectificado != null)
			listGastosRecti = rectificado.getListMontoGastos();
		if (actual != null)
			listGastosOrig = actual.getListMontoGastos();

		if (!CollectionUtils.isEmpty(listGastosRecti)) {
			for (DatoMontoGasto gastoRecti : listGastosRecti) {
				DatoMontoGasto gastoOrig = (DatoMontoGasto) buscarEnLista(listGastosOrig, gastoRecti);
				comparacionMontoGastoVehiculo(gastoRecti, gastoOrig);
			}
		}
	}

	/**
	 * Comparacion monto gasto vehiculo.
	 * 
	 * @param rectificado DatoMontoGasto
	 * @param actual DatoMontoGasto
	 * @throws Exception 
	 */
	public void comparacionMontoGastoVehiculo(DatoMontoGasto rectificado, DatoMontoGasto actual) throws Exception {

		if (rectificado != null) {
			String codTabla = ConstantesDataCatalogo.TABLA_MONTOGASTO;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "valmonto"), datos, "MTO_GASTO", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}

	}

	/**
	 * Comparacion lista serie doc soporte autoriz.
	 * 
	 * @param rectificado DatoSerie
	 * @param actual DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionListaSerieDocSoporteAutoriz(DatoSerie rectificado, DatoSerie actual, Integer iserie) throws Exception {

		Elementos<DatoSerieDocSoporte> listaSerieSoporteRect = null;
		Elementos<DatoSerieDocSoporte> listaSerieSoporteOrig = null;
		if (rectificado != null)
			listaSerieSoporteRect = getListSerieSoporteByType(rectificado, DOC_SOPORTE);
		if (actual != null)
			listaSerieSoporteOrig = getListSerieSoporteByType(actual, DOC_SOPORTE);
		if (!CollectionUtils.isEmpty(listaSerieSoporteRect)) {
			for (DatoSerieDocSoporte serieSoporteRect : listaSerieSoporteRect) {
				DatoSerieDocSoporte serieSoporteOrig = (DatoSerieDocSoporte) buscarEnLista(listaSerieSoporteOrig, serieSoporteRect);
				comparacionSerieDocSoporte(serieSoporteRect, serieSoporteOrig);
			}
		}

		listaSerieSoporteRect = null;
		listaSerieSoporteOrig = null;
		if (rectificado != null)
			listaSerieSoporteRect = getListSerieSoporteByType(rectificado, DOC_AUTORIZANTE);
		if (actual != null)
			listaSerieSoporteOrig = getListSerieSoporteByType(actual, DOC_AUTORIZANTE);
		if (!CollectionUtils.isEmpty(listaSerieSoporteRect)) {
			for (DatoSerieDocSoporte serieSoporteRect : listaSerieSoporteRect) {
				DatoSerieDocSoporte serieSoporteOrig = (DatoSerieDocSoporte) buscarEnLista(listaSerieSoporteOrig, serieSoporteRect);
				comparacionSerieDocAutoriz(serieSoporteRect, serieSoporteOrig);
			}
		}

		listaSerieSoporteRect = null;
		listaSerieSoporteOrig = null;
		if (rectificado != null)
			listaSerieSoporteRect = getListSerieSoporteByType(rectificado, CERTI_ORIGEN);
		if (actual != null)
			listaSerieSoporteOrig = getListSerieSoporteByType(actual, CERTI_ORIGEN);
		if (!CollectionUtils.isEmpty(listaSerieSoporteRect)) {
			for (DatoSerieDocSoporte serieSoporteRect : listaSerieSoporteRect) {
				DatoSerieDocSoporte serieSoporteOrig = (DatoSerieDocSoporte) buscarEnLista(listaSerieSoporteOrig, serieSoporteRect);
				comparacionSerieDocCertiOirgen(serieSoporteRect, serieSoporteOrig);
			}
		}

	}

	/**
	 * Comparacion serie doc soporte.
	 * 
	 * @param rectificado DatoSerieDocSoporte
	 * @param actual DatoSerieDocSoporte
	 * @throws Exception 
	 */
	public void comparacionSerieDocSoporte(DatoSerieDocSoporte rectificado, DatoSerieDocSoporte actual) throws Exception {
		if (rectificado != null) {
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			String codTabla = ConstantesDataCatalogo.TABLA_DET_AUTORIZACION;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion serie doc autoriz.
	 * 
	 * @param rectificado DatoSerieDocSoporte
	 * @param actual DatoSerieDocSoporte
	 * @throws Exception 
	 */
	public void comparacionSerieDocAutoriz(DatoSerieDocSoporte rectificado, DatoSerieDocSoporte actual) throws Exception {
		if (rectificado != null) {
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			String codTabla = ConstantesDataCatalogo.TABLA_DET_AUTORIZACION;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion serie doc certi oirgen.
	 * 
	 * @param rectificado DatoSerieDocSoporte
	 * @param actual DatoSerieDocSoporte
	 * @throws Exception 
	 */
	public void comparacionSerieDocCertiOirgen(DatoSerieDocSoporte rectificado, DatoSerieDocSoporte actual) throws Exception {
		if (rectificado != null) {
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			String codTabla = ConstantesDataCatalogo.TABLA_DET_AUTORIZACION;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion lista serie doc soporte factura.
	 * 
	 * @param rectificado DatoSerie
	 * @param actual DatoSerie
	 * @param iserie Integer
	 * @throws Exception 
	 */
	public void comparacionListaSerieDocSoporteFactura(DatoSerie rectificado, DatoSerie actual, Integer iserie) throws Exception {
		Elementos<DatoSerieDocSoporte> listaSerieSoporteRect = null;
		Elementos<DatoSerieDocSoporte> listaSerieSoporteOrig = null;
		if (rectificado != null)
			listaSerieSoporteRect = getListSerieSoporteByType(rectificado, FACTURA);
		if (actual != null)
			listaSerieSoporteOrig = getListSerieSoporteByType(actual, FACTURA);
		if (!CollectionUtils.isEmpty(listaSerieSoporteRect)) {
			for (DatoSerieDocSoporte serieSoporteRect : listaSerieSoporteRect) {
				DatoSerieDocSoporte serieSoporteOrig = (DatoSerieDocSoporte) buscarEnLista(listaSerieSoporteOrig, serieSoporteRect);
				comparacionSerieDocSoporteFactura(serieSoporteRect, serieSoporteOrig);
			}
		}
	}

	/**
	 * Comparacion serie doc soporte factura.
	 * 
	 * @param rectificado DatoSerieDocSoporte
	 * @param actual DatoSerieDocSoporte
	 * @throws Exception 
	 */
	public void comparacionSerieDocSoporteFactura(DatoSerieDocSoporte rectificado, DatoSerieDocSoporte actual) throws Exception {
		if (rectificado != null) {
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			String codTabla = ConstantesDataCatalogo.TABLA_FACTURA_SERIE;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion dav.
	 * 
	 * @param declaraRecti Declaracion
	 * @param declaraOld Declaracion
	 * @throws Exception 
	 */
	public void comparacionDAV(Declaracion declaraRecti, Declaracion declaraOld) throws Exception {

		String tipoCambioProv = new String();
		String tipoCambioDecl = new String();
		Elementos<DAV> listDAVRect = declaraRecti.getListDAVs();
		Elementos<DAV> listDAVOrig = declaraOld.getListDAVs();
		if (!CollectionUtils.isEmpty(listDAVRect)) {
			for (DAV davRect : listDAVRect) {
				DAV davOrig = (DAV) buscarEnLista(listDAVOrig, davRect);
				tipoCambioProv = comparacionParticipanteProveedor(davRect, davOrig);
				tipoCambioDecl = comparacionFormBPersonaDeclarante(davRect, davOrig);
				comparacionFormBProveedor(davRect, davOrig, tipoCambioProv, tipoCambioDecl);
				// PAS20191U220500009 20190327 GTP: Comparacion descrip_otros (cod_tabla = 'T0070'; cod_catalogo in ('147', '148'))
				comparacionDescrip_otros(davRect, davOrig);
				/*branch ingreso 2011-009 hosorio inicio 15/07/2011*/
				comparacionFormBProveedorLocal(davRect, davOrig);

				/*branch ingreso 2011-009 hosorio fin 15/07/2011*/
				comparacionFormbIntermediario(davRect, davOrig);
				comparacionListaFormBMontos(davRect, davOrig);
				//comparacionListaFormBFacturas(davRect, davOrig); la comparacion se hace a un nivel superior PAS20155E220200139
				comparacionListaCondTransaccion(davRect, davOrig);
			}
		}
	}

	//PAS20155E220200139
	public void comparacionListaDatoItem(Declaracion declaraRecti, Declaracion declaraOld) throws Exception {
		Elementos<DAV> listDAVRect = declaraRecti.getListDAVs();
		Elementos<DAV> listDAVOrig = declaraOld.getListDAVs();
		Elementos<DatoItem> lstItemRecti = new Elementos<DatoItem>();
		Elementos<DatoItem> lstItemOrig = new Elementos<DatoItem>();
		
		if (!CollectionUtils.isEmpty(listDAVRect)) {
			for (DAV davRect : listDAVRect) {	
				DAV davOrig = (DAV) buscarEnLista(listDAVOrig, davRect);
				Elementos<DatoFactura> listDatFactRecti = null;
				Elementos<DatoFactura> listDatFactOrig = null;
			    if (davRect != null)
					listDatFactRecti = davRect.getListFacturas();
				if (davOrig != null)
					listDatFactOrig = davOrig.getListFacturas();

			     if (!CollectionUtils.isEmpty(listDatFactRecti)) {
			    	 for (DatoFactura facturaRecti : listDatFactRecti) {
			    		 //DatoFactura facturaOrig = (DatoFactura) buscarEnLista(listDatFactOrig, facturaRecti);
			    		 if (facturaRecti != null)
			    			 lstItemRecti.addAll(facturaRecti.getListItems());
			    	 }
			     }
			     
			     if (!CollectionUtils.isEmpty(listDatFactOrig)) {
				     for (DatoFactura facturaRectiOrig : listDatFactOrig) {
			    		 //DatoFactura facturaOrig = (DatoFactura) buscarEnLista(listDatFactOrig, facturaRecti);
			    		 if (facturaRectiOrig != null)					
			    			 lstItemOrig.addAll(facturaRectiOrig.getListItems()) ;							
			    	 }
			     }


	      }
		}
		if (!CollectionUtils.isEmpty(lstItemRecti)) {
			for (DatoItem itemRecti : lstItemRecti) {
				DatoItem itemOrig = (DatoItem) buscarEnLista(lstItemOrig, itemRecti);
				comparacionItemFactura(itemRecti, itemOrig);
				comparacionFobProvisional(itemRecti, itemOrig);
				comparacionListaDescripcionMinima(itemRecti, itemOrig);
				comparacionListaObservacionItem(itemRecti, itemOrig);
				comparacionListaDatoSerieItem(itemRecti, itemOrig);
			}
		}
		
	}
	
	public void comparacionListaFormBFacturas(Declaracion declaraRecti, Declaracion declaraOld) throws Exception {
		
		Elementos<DAV> listDAVRect = declaraRecti.getListDAVs();
		Elementos<DAV> listDAVOrig = declaraOld.getListDAVs();
		Elementos<DatoFactura> listDatFactRecti = new Elementos<DatoFactura>();
		Elementos<DatoFactura> listDatFactOrig =  new Elementos<DatoFactura>();

		if (!CollectionUtils.isEmpty(listDAVRect)) {
			for (DAV davRect : listDAVRect) {
            if (davRect != null)
			        listDatFactRecti.addAll(davRect.getListFacturas());
			}
			
			for (DAV davOrig : listDAVOrig) {
                 if (davOrig != null)
        			listDatFactOrig.addAll(davOrig.getListFacturas());
			}

		}


			if (!CollectionUtils.isEmpty(listDatFactRecti)) {
				for (DatoFactura facturaRecti : listDatFactRecti) {
				DatoFactura facturaOrig = (DatoFactura) buscarEnLista(listDatFactOrig, facturaRecti);
				comparacionComproPagoFact(facturaRecti, facturaOrig);
				comparacionListaFacturaSucesiva(facturaRecti, facturaOrig);
				}
			}
		
	}
	//PAS20155E220200139
	/**
	 * Comparacion lista form b montos.
	 * 
	 * @param davRect DAV
	 * @param davOrig DAV
	 * @throws Exception 
	 */
	public void comparacionListaFormBMontos(DAV davRect, DAV davOrig) throws Exception {

		Elementos<DatoMonto> listMontoRect = null;
		Elementos<DatoMonto> listMontoOrig = null;
		if (davRect != null)
			listMontoRect = davRect.getListMontos();
		if (davOrig != null)
			listMontoOrig = davOrig.getListMontos();
		if (!CollectionUtils.isEmpty(listMontoRect)) {
			for (DatoMonto montoRect : listMontoRect) {
				DatoMonto montoOrig = (DatoMonto) buscarEnLista(listMontoOrig, montoRect);
				comparacionFormBMontos(montoRect, montoOrig);
			}
		}
	}

	/**
	 * Comparacion form b montos.
	 * 
	 * @param rectificado DatoMonto
	 * @param actual DatoMonto
	 * @throws Exception 
	 */
	public void comparacionFormBMontos(DatoMonto rectificado, DatoMonto actual) throws Exception {
		if (rectificado != null) {
			String codTabla = ConstantesDataCatalogo.TABLA_FORMBMONTO;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			BigDecimal mtoRec = SunatNumberUtils.scaleHalfUp(rectificado.getMtologistico(), 2);
			BigDecimal mtoAct = SunatNumberUtils.scaleHalfUp(actual != null ? actual.getMtologistico() : BigDecimal.ZERO, 2);
			agregarCambioAtributo(comparaAtributo(mtoRec, mtoAct), datos, "MTO_VALOR", null, null);

			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}

	}

	/**
	 * Comparacion lista form b facturas.
	 * 
	 * @param davRecti DAV
	 * @param davOrig DAV
	 * @throws Exception 
	 */
	public void comparacionListaFormBFacturas(DAV davRecti, DAV davOrig) throws Exception {

		Elementos<DatoFactura> listDatFactRecti = null;
		Elementos<DatoFactura> listDatFactOrig = null;

		if (davRecti != null)
			listDatFactRecti = davRecti.getListFacturas();
		if (davOrig != null)
			listDatFactOrig = davOrig.getListFacturas();

		if (!CollectionUtils.isEmpty(listDatFactRecti)) {
			for (DatoFactura facturaRecti : listDatFactRecti) {
				DatoFactura facturaOrig = (DatoFactura) buscarEnLista(listDatFactOrig, facturaRecti);
				comparacionComproPagoFact(facturaRecti, facturaOrig);
				comparacionListaFacturaSucesiva(facturaRecti, facturaOrig);
				//PAS20155E220200139
				//comparacionListaDatoItem(facturaRecti, facturaOrig);//gmontoya bug 17543//se descomenta por bug 18713 arey se comenta 
			}
			// inicio gmontoya bug 17543
			/*boolean encontrado = false;
			for (DatoFactura facturaRecti : listDatFactRecti) {
				for (DatoItem itemRecti : facturaRecti.getListItems()) {
					for (DatoFactura facturaOrig : listDatFactOrig) {					
						DatoItem itemOrig = (DatoItem) buscarEnLista(facturaOrig.getListItems(), itemRecti);
						if(itemOrig!=null){
							encontrado = true;
							comparacionListaDatoItem(facturaRecti, facturaOrig);
						}
					}					
				}
				if(!encontrado){
					comparacionListaDatoItem(facturaRecti, null);					
				}
				encontrado = false;
			}*/
			//fin gmontoya bug 17543//BUG 18713 arey
		}
	}

	/**
	 * Comparacion compro pago fact.
	 * 
	 * @param rectificado DatoFactura
	 * @param actual DatoFactura
	 * @throws Exception 
	 */
	public void comparacionComproPagoFact(DatoFactura rectificado, DatoFactura actual) throws Exception {

		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_COMPROBPAGO;
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codpaisembar"), datos, "COD_PAISEMBARQUE", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cnttotitems"), datos, "CNT_TOTITEMS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codmoneda"), datos, "COD_MONEDA", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofactufob"), datos, "MTO_FACT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecfactura"), datos, "FEC_FACT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "indtipodecl"), datos, "IND_DDJJ", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numfactura"), datos, "NUM_FACT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "deslugtrans"), datos, "DIR_LUGARTRANS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codincoterm"), datos, "COD_INCOTERM", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numsecprove"), datos, "NUM_SECPROVE", null, null);			
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);

		}

	}

	/**
	 * Comparacion lista factura sucesiva.
	 * 
	 * @param facturaRecti DatoFactura
	 * @param facturaOrig DatoFactura
	 * @throws Exception 
	 */
	public void comparacionListaFacturaSucesiva(DatoFactura facturaRecti, DatoFactura facturaOrig) throws Exception {

		Elementos<DatoFactSuce> lstfactSuceRecti = null;
		Elementos<DatoFactSuce> lstfactSuceOrig = null;

		if (facturaRecti != null)
			lstfactSuceRecti = facturaRecti.getListFactSucesivas();
		if (facturaOrig != null)
			lstfactSuceOrig = facturaOrig.getListFactSucesivas();

		if (!CollectionUtils.isEmpty(lstfactSuceRecti)) {
			for (DatoFactSuce rectificado : lstfactSuceRecti) {
				DatoFactSuce actual = null;
				if (!CollectionUtils.isEmpty(lstfactSuceOrig))
					actual = lstfactSuceOrig.get(0);
				comparacionFacturaSucesiva(rectificado, actual);
			}
		}
	}

	/**
	 * Comparacion factura sucesiva.
	 * 
	 * @param rectificado DatoFactSuce
	 * @param actual DatoFactSuce
	 * @throws Exception 
	 */
	public void comparacionFacturaSucesiva(DatoFactSuce rectificado, DatoFactSuce actual) throws Exception {

		if (rectificado != null) {
			String codTabla = ConstantesDataCatalogo.TABLA_FACTUSUCE;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numfactsuc"), datos, "NUM_FACT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fecfactsuc"), datos, "FEC_FACT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofactsuc"), datos, "MTO_FACT", null, null);
			//PAS20155E220200139
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofactsuc"), datos, "MTO_FACT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numsecprove"), datos, "NUM_SECPROVE", null, null); //se adiciona
			//PAS20155E220200139
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
	}

	/**
	 * Comparacion lista dato item.
	 * 
	 * @param facturaRecti DatoFactura
	 * @param facturaOrig DatoFactura
	 * @throws Exception 
	 */
	public void comparacionListaDatoItem(DatoFactura facturaRecti, DatoFactura facturaOrig) throws Exception {
		Elementos<DatoItem> lstItemRecti = null;
		Elementos<DatoItem> lstItemOrig = null;

		if (facturaOrig != null)
			lstItemOrig = facturaOrig.getListItems();
		if (facturaRecti != null)
			lstItemRecti = facturaRecti.getListItems();

		if (!CollectionUtils.isEmpty(lstItemRecti)) {
			for (DatoItem itemRecti : lstItemRecti) {
				DatoItem itemOrig = (DatoItem) buscarEnLista(lstItemOrig, itemRecti);
				comparacionItemFactura(itemRecti, itemOrig);
				comparacionFobProvisional(itemRecti, itemOrig);
				comparacionListaDescripcionMinima(itemRecti, itemOrig);
				comparacionListaObservacionItem(itemRecti, itemOrig);
				comparacionListaDatoSerieItem(itemRecti, itemOrig);
			}
		}
	}

	/**
	 * Comparacion lista dato serie item.
	 * 
	 * @param itemRecti DatoItem
	 * @param itemOrig DatoItem
	 * @throws Exception 
	 */
	public void comparacionListaDatoSerieItem(DatoItem itemRecti, DatoItem itemOrig) throws Exception {

		Elementos<DatoSerieItem> lstSerieItemRecti = null;
		Elementos<DatoSerieItem> lstSerieItemOrig = null;

		if (itemRecti != null)
			lstSerieItemRecti = itemRecti.getListSerieItems();
		;
		if (itemOrig != null)
			lstSerieItemOrig = itemOrig.getListSerieItems();
		;

		/*branch ingreso 2011-009 hosorio inicio 23/06/2011*/
		//if (CollectionUtils.isEmpty(lstSerieItemRecti)) {
		if (!CollectionUtils.isEmpty(lstSerieItemRecti)) {
			/*branch ingreso 2011-009 hosorio fin 23/06/2011*/
			for (DatoSerieItem serieItemRecti : lstSerieItemRecti) {
				DatoSerieItem serieItemOrig = (DatoSerieItem) buscarEnLista(lstSerieItemOrig, serieItemRecti);
				comparacionDatoSerieItem(serieItemRecti, serieItemOrig);
			}
		}
	}

	/**
	 * Comparacion dato serie item.
	 * 
	 * @param rectificado DatoSerieItem
	 * @param actual DatoSerieItem
	 * @throws Exception 
	 */
	public void comparacionDatoSerieItem(DatoSerieItem rectificado, DatoSerieItem actual) throws Exception {

		if (rectificado != null) {

			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_SERIES_ITEM;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioAtributo(comparaAtributo(rectificado,actual, "numsecprove"), datos, "NUM_SECPROVE", null, null); //se adiciona arey bug 18713
			agregarCambioAtributo(comparaAtributo(rectificado,actual, "numsecfact"), datos, "NUM_SECFACT", null, null); //se adiciona arey bug 18713			
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofobitser"), datos, "MTO_FOB", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cant_mercd"), datos, "CNT_MERC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtoajuitser"), datos, "MTO_AJUSTE", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);

		}
	}

	/**
	 * Comparacion lista descripcion minima.
	 * 
	 * @param itemRecti DatoItem
	 * @param itemOrig DatoItem
	 * @throws Exception 
	 */
	public void comparacionListaDescripcionMinima(DatoItem itemRecti, DatoItem itemOrig) throws Exception {

		Elementos<DatoDescrMinima> lstDescriMiniRecti = null;
		Elementos<DatoDescrMinima> lstDescriMiniOrig = null;

		if (itemRecti != null)
			lstDescriMiniRecti = itemRecti.getListDecrMinima();
		if (itemOrig != null)
			lstDescriMiniOrig = itemOrig.getListDecrMinima();
		/*branch ingreso 2011-009 hosorio inicio 09/15/2011*/
		if (!CollectionUtils.isEmpty(lstDescriMiniRecti)) {
			/*branch ingreso 2011-009 hosorio fin 09/15/2011*/
			for (DatoDescrMinima descMinRecti : lstDescriMiniRecti) {
				DatoDescrMinima desMinOrig = (DatoDescrMinima) buscarEnLista(lstDescriMiniOrig, descMinRecti);
				comparacionDescripcionMinima(descMinRecti, desMinOrig);
			}
		}
	}

	/**
	 * Comparacion descripcion minima.
	 * 
	 * @param rectificado DatoDescrMinima
	 * @param actual DatoDescrMinima
	 * @throws Exception 
	 */
	public void comparacionDescripcionMinima(DatoDescrMinima rectificado, DatoDescrMinima actual) throws Exception {

		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_FORMBITEMDESCRI;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);

			if(rectificado.getCodmercancia()==null || rectificado.getCodmercancia().isEmpty()){
				rectificado.setCodmercancia("**");
			}

			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "valtipdescri"), datos, "DES_DESCRIPCION", null, null);
			/*pase 548 Adicionado para Recti. automat. DESCRMINIMAS*/
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipvalor"), datos, "COD_TIPVALOR", null, null);
			/*pase 548 Fin cambios*/
			//PAS20155E220200139
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numsecprove"), datos, "NUM_SECPROVE", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numsecfact"), datos, "NUM_SECFACT", null, null);
			//PAS20155E220200139
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);

		}
	}

	/**
	 * Comparacion lista observacion item.
	 * 
	 * @param itemRecti DatoItem
	 * @param itemOrig DatoItem
	 * @throws Exception 
	 */
	public void comparacionListaObservacionItem(DatoItem itemRecti, DatoItem itemOrig) throws Exception {

		Elementos<Observacion> lstObservRecti = null;
		Elementos<Observacion> lstObservOrig = null;
		if (itemRecti != null)
			lstObservRecti = itemRecti.getListObservaciones();
		if (itemOrig != null)
			lstObservOrig = itemOrig.getListObservaciones();

		//R2BZ Falto la negacion
		if (!CollectionUtils.isEmpty(lstObservRecti)) {
			for (Observacion obserRecti : lstObservRecti) {
				Observacion obserOrig = (Observacion) buscarEnLista(lstObservOrig, obserRecti);
				comparacionObservacionItem(obserRecti, obserOrig);
			}
		}
	}

	/**
	 * Comparacion observacion item.
	 * 
	 * @param rectificado Observacion
	 * @param actual Observacion
	 * @throws Exception 
	 */
	public void comparacionObservacionItem(Observacion rectificado, Observacion actual) throws Exception {

		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_OBSERVACION;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipocambio = evaluarCambioRegistro(rectificado, actual);
			//agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipobserva"), datos, "COD_TIPOBS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "obsdeclaracion"), datos, "OBS_OBS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numsecitem"), datos, "NUM_SECITEM", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipocambio);

		}
	}

	/**
	 * Comparacion item factura.
	 * 
	 * @param rectificado DatoItem
	 * @param actual DatoItem
	 * @throws Exception 
	 */
	public void comparacionItemFactura(DatoItem rectificado, DatoItem actual) throws Exception {

		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_ITEMFACTURA;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numpartnandi"), datos, "NUM_PARARANCEL", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntcantcomer"), datos, "CNT_UNI", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codunidcomer"), datos, "COD_UNICOMER", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codproducto"), datos, "COD_PROD", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codpaisorige"), datos, "COD_PAISORIGEN", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codpaisadqui"), datos, "COD_PAISADQUI", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numsecprove"), datos, "NUM_SECPROVE", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numsecfact"), datos, "NUM_SECFACT", null, null);
			/*pase 548 Adicionado para Recti. automat. DESCRMINIMAS*/
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipdescrmin"), datos, "COD_TIPDESCRMIN", null, null);
			/*pase 548 Fin de cambios*/

			// otros datos item
			Integer annFacRecti = null;
			Integer annFacActual = null;
			if (rectificado != null && rectificado.getAnnfabrica() != null && !SunatStringUtils.isEmpty(rectificado.getAnnfabrica())
					&& rectificado.getAnnfabrica().length() > 3)
				annFacRecti = SunatNumberUtils.toInteger(rectificado.getAnnfabrica().substring(0, 4));

			if (actual != null && actual.getAnnfabrica() != null && !SunatStringUtils.isEmpty(actual.getAnnfabrica())
					&& actual.getAnnfabrica().length() > 3)
				annFacActual = SunatNumberUtils.toInteger(actual.getAnnfabrica().substring(0, 4));

			agregarCambioAtributo(comparaAtributo(annFacRecti, annFacActual), datos, "ANN_FABRICACION", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofobunita"), datos, "MTO_FOBUNITARIO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtofobitem"), datos, "MTO_FOBITEM", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codestamer"), datos, "COD_ESTMERC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "indsoftware"), datos, "IND_SOFTWARE", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "inddeducdisti"), datos, "IND_DEDUC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "indvarios"), datos, "IND_OTROS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "descomercial"), datos, "DES_COMER", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desmodelo"), datos, "DES_MODELO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desmarca"), datos, "DES_MARCA", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desusoaplica"), datos, "DES_USOAPLIC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "descaracteristicas"), datos, "DES_CARACTERISTICAS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desclasevari"), datos, "DES_CLASEVARI", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "desmaterialcomp"), datos, "DES_MATERIALCOMP", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "mtoajusunita"), datos, "MTO_AJUUNITARIO", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);

		}

	}

	/**
	 * Comparacion fob provisional.
	 * 
	 * @param rectificado DatoItem
	 * @param actual DatoItem
	 * @throws Exception 
	 */
	public void comparacionFobProvisional(DatoItem rectificado, DatoItem actual) throws Exception {

		DatoMontoProv montoItemRecti = null;
		DatoMontoProv montoItemOrig = null;

		if (rectificado != null)
			montoItemRecti = rectificado.getMontoProv();
		if (actual != null)
			montoItemOrig = actual.getMontoProv();

		if (montoItemRecti != null) {
			//Inicio - RIN10-PAS20155E220000333-BUG-22198 - Solo si tiene mas de los 5 atributos (clave) fectipocambio, numcorredoc, numsecfact, numsecitem, numsecprove
			//Se considera una rectificaci�n de los montos provisionales
			if (sizeBean(DatoMontoProv.class, montoItemRecti) > 5){
			//Fin - RIN10-PAS20155E220000333-BUG-22198
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL;
			Map<String, Object> clave = obtenerClave(codTabla, montoItemRecti);
			String tipoCambio = evaluarCambioRegistro(montoItemRecti, montoItemOrig);

			agregarCambioAtributo(comparaAtributo(montoItemRecti, montoItemOrig, "codmoneda"), datos, "COD_MONEDA", null, null);
                        if(rectificado.getMontoProv().getIndtipovalor() != null && !pe.gob.sunat.despaduanero2.ayudas.util.Constantes.IND_VALOR_DEFINITIVO.equals(rectificado.getMontoProv().getIndtipovalor())){
			agregarCambioAtributo(comparaAtributo(montoItemRecti, montoItemOrig, "valmonto"), datos, "MTO_MONTO", null, null);
                        }
			
			agregarCambioAtributo(comparaAtributo(montoItemRecti, montoItemOrig, "indtipovalor"), datos, "COD_TIPOVALOR", null, null);

			/* Inicio de cambios por el bug 21726 pase 42*/
			agregarCambioAtributo(comparaAtributo(montoItemRecti, montoItemOrig, "numsecprove"), datos, "NUM_SECPROVE", null, null);
			agregarCambioAtributo(comparaAtributo(montoItemRecti, montoItemOrig, "numsecfact"), datos, "NUM_SECFACT", null, null);
			/* Fin de cambios por el bug 21726 pase 42*/
			Date fecestimrecti = null;
			Date fecestimactu = null;
			if (montoItemRecti != null && montoItemRecti.getFecvalestima() != null)
				fecestimrecti = SunatDateUtils.getDateFromInteger(SunatDateUtils.getIntegerFromDate(montoItemRecti.getFecvalestima()));
			if (montoItemOrig != null && montoItemOrig.getFecvalestima() != null)
				fecestimactu = SunatDateUtils.getDateFromInteger(SunatDateUtils.getIntegerFromDate(montoItemOrig.getFecvalestima()));

			agregarCambioAtributo(comparaAtributo(fecestimrecti, fecestimactu), datos, "FEC_VALESTIMA", null, null);

			agregarCambioAtributo(comparaAtributo(montoItemRecti, montoItemOrig, "valdefinitivo"), datos, "MTO_DEFINITIVO", null, null);

			Date fectipcamrecti = null;
			Date fectipcamactu = null;

			if (montoItemRecti != null && montoItemRecti.getFectipocambio() != null)
				fectipcamrecti = SunatDateUtils.getDateFromInteger(SunatDateUtils.getIntegerFromDate(montoItemRecti.getFectipocambio()));
			if (montoItemOrig != null && montoItemOrig.getFectipocambio() != null)
				fectipcamactu = SunatDateUtils.getDateFromInteger(SunatDateUtils.getIntegerFromDate(montoItemOrig.getFectipocambio()));

			agregarCambioAtributo(comparaAtributo(fectipcamrecti, fectipcamactu), datos, "FEC_TIPCAMB", null, null);

			//if (!CollectionUtils.isEmpty(datos)) removido por bug 21726
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
			//Inicio - RIN10-PAS20155E220000333-BUG-22198 - Solo si tiene mas de los 5 atributos (clave) fectipocambio, numcorredoc, numsecfact, numsecitem, numsecprove
			//Se considera una rectificaci�n de los montos provisionales
			}
			//Fin - RIN10-PAS20155E220000333-BUG-22198

		}

	}

	/**
	 * Comparacion lista cond transaccion.
	 * 
	 * @param davRecti DAV
	 * @param davOrig DAV
	 * @throws Exception 
	 */
	public void comparacionListaCondTransaccion(DAV davRecti, DAV davOrig) throws Exception {
		Elementos<DatoCondTransaccion> lstCondTransRecti = null;
		Elementos<DatoCondTransaccion> lstCondTransOrig = null;

		if (davRecti != null)
			lstCondTransRecti = davRecti.getListCondTransacciones();
		if (davOrig != null)
			lstCondTransOrig = davOrig.getListCondTransacciones();

		if (!CollectionUtils.isEmpty(lstCondTransRecti)) {
			for (DatoCondTransaccion condiTransRecti : lstCondTransRecti) {
				DatoCondTransaccion condiTransOrig = (DatoCondTransaccion) buscarEnLista(lstCondTransOrig, condiTransRecti);
				comparacionCondTransaccion(condiTransRecti, condiTransOrig);
			}
		}
	}

	/**
	 * Comparacion cond transaccion.
	 * 
	 * @param rectificado DatoCondTransaccion
	 * @param actual DatoCondTransaccion
	 * @throws Exception 
	 */
	public void comparacionCondTransaccion(DatoCondTransaccion rectificado, DatoCondTransaccion actual) throws Exception {

		if (rectificado != null) {
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_CONDICION_TRANSA;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "indcondtra"), datos, "IND_TRANSACCION", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);

		}
	}

	/**
	 * Comparacion form b proveedor.
	 * 
	 * @param rectificado DAV
	 * @param actual DAV
	 * @throws Exception 
	 */
	public void comparacionFormBProveedor(DAV rectificado, DAV actual, String tipoCambioProv, String tipoCambioDecl) throws Exception {

		if (rectificado != null) {

			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_FORMBPROVEEDOR;
			Map<String, Object> clave = obtenerClave(codTabla, rectificado);
			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			if(actual!=null){
				if(!sonIgualesValidacionIncluyeDefault(rectificado.getCodproveedor(), actual.getCodproveedor(),actual.getCodproveedor())){
					agregarCambioAtributo(comparaAtributo(rectificado, actual, "codproveedor"), datos, "COD_PROVE", null, null);
				}
			}else	agregarCambioAtributo(comparaAtributo(rectificado, actual, "codproveedor"), datos, "COD_PROVE", null, null);

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codnatutrans"), datos, "COD_NATUTRANS", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "indexisinter"), datos, "IND_INTEMEDIARIO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "cntfacturas"), datos, "CNT_FACT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numenvio"), datos, "NUM_ENVIO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codcondprov"), datos, "COD_CONDPROVE", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codtipinter"), datos, "COD_TIPINTERM", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codnivcomer"), datos, "COD_NIVELCOMER", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nomcargdecla"), datos, "NOM_CARGO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codformenvio"), datos, "COD_FORMAENVIO", null, null);
			//pase 105 mordonezl
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "flag"), datos, "IND_FLAG", null, null);
			// INI PAS20191U220500009 20190315 GTP: Datos de medio de pago formato B
			String codTipoMedioPago_actual=null;
			String datosMedioPago_actual=null;
			String codEntidadFinaciera_actual=null;
			String codTipoMedioPago_rectifi=null;
			String datosMedioPago_rectifi=null;
			String codEntidadFinaciera_rectifi=null;
			try {
				codTipoMedioPago_actual = actual.getCodMedioPago();
				datosMedioPago_actual = actual.getCodIdentPago();
				codEntidadFinaciera_actual = actual.getCodEntidadFinanciera();
			} catch (Exception e) {
			}	
			try {
				//codTipoMedioPago_rectifi = rectificado.getListDocumentoSoporteFormatoB().get(0).getCodMedioPago();
				//datosMedioPago_rectifi = rectificado.getListDocumentoSoporteFormatoB().get(0).getCodIdentPago();
				//codEntidadFinaciera_rectifi = rectificado.getListDocumentoSoporteFormatoB().get(0).getCodEntidadFinanciera();
				// JCV 20190809 PAS20191U220500098 Para que no borre los datos en la regularizacion
				codTipoMedioPago_rectifi = rectificado.getListDocumentoSoporteFormatoB()!=null?rectificado.getListDocumentoSoporteFormatoB().get(0).getCodMedioPago():rectificado.getCodMedioPago();
				datosMedioPago_rectifi = rectificado.getListDocumentoSoporteFormatoB()!=null?rectificado.getListDocumentoSoporteFormatoB().get(0).getCodIdentPago():rectificado.getCodIdentPago();
				codEntidadFinaciera_rectifi = rectificado.getListDocumentoSoporteFormatoB()!=null?rectificado.getListDocumentoSoporteFormatoB().get(0).getCodEntidadFinanciera():rectificado.getCodEntidadFinanciera();
			} catch (Exception e) {
			}	
			agregarCambioAtributo(comparaAtributo(codTipoMedioPago_rectifi, codTipoMedioPago_actual), datos, "COD_MEDIO_PAGO", null, null);
			agregarCambioAtributo(comparaAtributo(datosMedioPago_rectifi, datosMedioPago_actual), datos, "COD_IDENT_PAGO", null, null);
			agregarCambioAtributo(comparaAtributo(codEntidadFinaciera_rectifi, codEntidadFinaciera_actual), datos, "COD_ENTI_FINANC", null, null);
			// FIN PAS20191U220500009
			/*branch ingreso 2011-009 hosorio inicio*/
			String numDocOriginal=null;
			String numDocRectifi=null;
			try {
				numDocOriginal=actual.getProveedorLocal().getNumeroDocumentoIdentidad();
			} catch (Exception e) {
			}
			try {
				numDocRectifi=rectificado.getProveedorLocal().getNumeroDocumentoIdentidad();
			} catch (Exception e) {
			}			
			agregarCambioAtributo(comparaAtributo(numDocRectifi, numDocOriginal), datos, "COD_DOCIDENTPROVLOC", null, null);
			String codDocProvOrig=null;
			String codDocProvRecti=null;
			try {
				codDocProvOrig=actual.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat();
			} catch (Exception e) {
			}
			try {
				codDocProvRecti=rectificado.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat();
			} catch (Exception e) {
			}						
			agregarCambioAtributo(comparaAtributo(codDocProvRecti, codDocProvOrig), datos, "COD_DOCPROVLOCAL",null, null);
			/*branch ingreso 2011-009 hosorio fin*/

			/**
			 * r2bz Para el tipo de participante proveedor se actualiza el numero de la secuencia
			 */
			if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO) && tipoCambioProv.equals(Constants.IND_REGISTRO_NUEVO)){
				Long numSecProvOrig=null;
				Long numSecProvRecti=null;
				try {
					numSecProvOrig=actual.getProveedor().getSecuenciaDeParticipantes();
				} catch (Exception e) {
				}
				try {
					numSecProvRecti=rectificado.getProveedor().getSecuenciaDeParticipantes();
				} catch (Exception e) {
				}						
				agregarCambioAtributo(comparaAtributo(numSecProvRecti, numSecProvOrig), datos, "NUM_CODSECPROVE", null, null);
			}

			if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO) && tipoCambioDecl.equals(Constants.IND_REGISTRO_NUEVO)){
				Long numSecProvOrig=null;
				Long numSecProvRecti=null;
				try {
					numSecProvOrig=actual.getPersonaDecl().getSecuenciaDeParticipantes();
				} catch (Exception e) {
				}
				try {
					numSecProvRecti=rectificado.getPersonaDecl().getSecuenciaDeParticipantes();
				} catch (Exception e) {
				}						
				agregarCambioAtributo(comparaAtributo(numSecProvRecti, numSecProvOrig), datos, "NUM_SECDECLARANTE", null, null);
			}

			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}

	}
	
	/**
	 * Comparacion descrip_otros.
	 * PAS20191U220500009 20190315 GTP
	 * 
	 * @param rectificado DAV
	 * @param actual DAV
	 * @throws Exception 
	 */
	public void comparacionDescrip_otros(DAV rectificado, DAV actual) throws Exception {
		if (rectificado != null) {
			String cod_mPago = rectificado.getListDocumentoSoporteFormatoB() != null && rectificado.getListDocumentoSoporteFormatoB().size() > 0 ? rectificado.getListDocumentoSoporteFormatoB().get(0).getCodMedioPago() : "";
			String cod_eFina = rectificado.getListDocumentoSoporteFormatoB() != null && rectificado.getListDocumentoSoporteFormatoB().size() > 0 ? rectificado.getListDocumentoSoporteFormatoB().get(0).getCodEntidadFinanciera() : "";
			boolean is147_14 = cod_mPago != null && cod_mPago.equals("14") ? true : false;
			boolean is148_99 = cod_eFina != null && cod_eFina.equals("99") ? true : false;			
			if(is147_14 || is148_99) { // si otros medios de pago
				Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
				String codTabla = Constantes.TABLA_DESCRIP_OTROS;
				Map<String, Object> clave = obtenerClave(codTabla, rectificado);
				String tipoCambio = null; //evaluarCambioRegistro(rectificado, actual);
				String desMedioPago_actual=null;
				String desEntidadFinanciera_actual=null;
				String desMedioPago_rectifi=null;
				String desEntidadFinanciera_rectifi=null;
				
				try {
					desMedioPago_actual=actual.getDesMedioPago();
					desEntidadFinanciera_actual=actual.getDesEntidadFinanciera();
				} catch (Exception e) {
				}	
				try {
					desMedioPago_rectifi=rectificado.getListDocumentoSoporteFormatoB().get(0).getDesMedioPago();
					desEntidadFinanciera_rectifi=rectificado.getListDocumentoSoporteFormatoB().get(0).getDesEntidadFinanciera();
				} catch (Exception e) {
				}	
				
				if(is147_14) {
					agregarCambioAtributo(comparaAtributo(desMedioPago_rectifi, desMedioPago_actual), datos, "DES_VALOR", null, null);
					clave.put("COD_CAMPO", "COD_MEDIO_PAGO");					
					if (desMedioPago_actual == null || desMedioPago_actual.isEmpty()) {
						if (desMedioPago_rectifi != null && !desMedioPago_rectifi.isEmpty()) {
							tipoCambio = "N";
						}
					} else {
						if (desMedioPago_rectifi != null && !desMedioPago_rectifi.isEmpty()) {
							tipoCambio = "R";
						}
					}
				} else					
				if(is148_99) {
					agregarCambioAtributo(comparaAtributo(desEntidadFinanciera_rectifi, desEntidadFinanciera_actual), datos, "DES_VALOR", null, null);
					clave.put("COD_CAMPO", "COD_ENTI_FINANC");
					if (desEntidadFinanciera_actual == null || desEntidadFinanciera_actual.isEmpty()) {
						if (desEntidadFinanciera_rectifi != null && !desEntidadFinanciera_rectifi.isEmpty()) {
							tipoCambio = "N";
						}
					} else {
						if (desEntidadFinanciera_rectifi != null && !desEntidadFinanciera_rectifi.isEmpty()) {
							tipoCambio = "R";
				}
					}
				}
				if (tipoCambio != null) {
				agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
			}
			}

		}

	}

	/**
	 * Comparacion participante proveedor.
	 * 
	 * @param davRecti DAV
	 * @param davOrig DAV
	 * @throws Exception 
	 */
	public String comparacionParticipanteProveedor(DAV davRecti, DAV davOrig) throws Exception {

		Participante rectificado = null;
		Participante actual = null;
		String tipoCambio = new String();

		if (davRecti != null)
			rectificado = davRecti.getProveedor();
		if (davOrig != null)
			actual = davOrig.getProveedor();

		/*BUG 17482*/
		if(actual!=null && actual.getTipoDocumentoIdentidad()!=null && actual.getTipoDocumentoIdentidad().getCodDatacat()!=null && actual.getTipoDocumentoIdentidad().getCodDatacat().toString().trim().length()==0 &&				
				(rectificado.getTipoDocumentoIdentidad()==null || rectificado.getTipoDocumentoIdentidad().getCodDatacat()==null ||
				rectificado.getTipoDocumentoIdentidad().getCodDatacat().trim().length()==0)){
			rectificado.setTipoDocumentoIdentidad(actual.getTipoDocumentoIdentidad());
		}

		if (!(rectificado == null)) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", rectificado.getTipoParticipante().getCodDatacat()); // 93


			tipoCambio = evaluarCambioRegistro(rectificado, actual);
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC;

			clave.put("NUM_SECPARTIC", getSecuenciaParticipante(tipoCambio,actual, rectificado));
			if (tipoCambio.equals(Constants.IND_CAMPO_NUEVO)){
				Long numSecParticipante= sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
				clave.put("NUM_SECPARTIC",numSecParticipante);
				rectificado.setSecuenciaDeParticipantes(numSecParticipante);
			}

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "tipoDocumentoIdentidad"), datos, "COD_TIPDOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numeroDocumentoIdentidad"), datos, "NUM_DOCIDENT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "pais"), datos, "COD_PAISORIGEN", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "direccion"), datos, "DIR_PARTIC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "telefono"), datos, "NUM_TELEFONO", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "fax"), datos, "NUM_FAX", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "email"), datos, "NOM_EMAIL", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "paginaWeb"), datos, "NOM_PAGINAWEB", null, null);			
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nombreRazonSocial"), datos, "NOM_RAZONSOCIAL", null, null);	
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "ciudad"), datos, "DES_UBIGEOCIUDAD", null, null);
			//INICIO CONTROL DE VIGENCIA OEA-ARM
			CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			DataCatalogo catVigenciaValidacion = catalogoAyudaService.getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,"0039");
			
			Date fechaControlVersionInicio = catVigenciaValidacion.getFecInidatcat();
			Date fechaControlVersionFin = catVigenciaValidacion.getFecFindatcat();
			Date fechaHoy = SunatDateUtils.getCurrentDate();
			if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaControlVersionInicio, fechaHoy, SunatDateUtils.COMPARA_SOLO_FECHA) 
					&& SunatDateUtils.esFecha1MenorIgualQueFecha2(SunatDateUtils.addDay(fechaHoy, -1), fechaControlVersionFin, SunatDateUtils.COMPARA_SOLO_FECHA)) {
		    //FIN CONTROL DE VIGENCIA OEA-ARM
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "codigoOea"), datos, "COD_EMPRESA", null, null);// verificar 
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "paisOea"), datos, "COD_PAISARM", null, null);
	   		}

			DetSolicitudRectificacionBean drb = agregarCambioRegistro(codTabla, clave, datos, tipoCambio);

		}
		return tipoCambio;
	}

	/**
	 * Comparacion form b persona declarante.
	 * 
	 * @param davRecti DAV
	 * @param davOrig DAV
	 * @throws Exception 
	 */
	public String comparacionFormBPersonaDeclarante(DAV davRecti, DAV davOrig) throws Exception {
		Participante rectificado = null;
		Participante actual = null;
		String tipoCambio = new String();
		if (davRecti != null)
			rectificado = davRecti.getPersonaDecl();
		if (davOrig != null && !isEmpty(davOrig.getPersonaDecl()))
			actual = davOrig.getPersonaDecl();

		if (!isEmpty(rectificado)) {

			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC;

			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", "92");
			//clave.put("NUM_SECPARTIC", actual.getSecuenciaDeParticipantes());

			tipoCambio = evaluarCambioRegistro(rectificado, actual);

			//if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)) clave.put("NUM_SECPARTIC", Long.parseLong("0"));
			clave.put("NUM_SECPARTIC", getSecuenciaParticipante(tipoCambio,actual, rectificado));
			if (tipoCambio.equals(Constants.IND_CAMPO_NUEVO)){
				Long numSecParticipante= sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
				clave.put("NUM_SECPARTIC",numSecParticipante);
				rectificado.setSecuenciaDeParticipantes(numSecParticipante);
			}

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nombreRazonSocial"), datos, "NOM_RAZONSOCIAL", null, null);			
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numeroDocumentoIdentidad"), datos, "NUM_DOCIDENT", null, null);
			String tipDocOrig =null;
			String tipDocRecti=null;
			try {
				tipDocOrig=actual.getTipoDocumentoIdentidad().getCodDatacat();
			} catch (Exception e) {
			}
			try {
				tipDocRecti=rectificado.getTipoDocumentoIdentidad().getCodDatacat();
			} catch (Exception e) {
			}
			agregarCambioAtributo(comparaAtributo(tipDocRecti, tipDocOrig), datos, "COD_TIPDOC", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}
		return tipoCambio;
	}

	/**
	 * Comparacion form b proveedor local.
	 * 
	 * @param davRecti DAV
	 * @param davOrig DAV
	 * @throws Exception 
	 */
	public void comparacionFormBProveedorLocal(DAV davRecti, DAV davOrig) throws Exception {
		Participante rectificado = null;
		Participante actual = null;
		if (davRecti != null)
			rectificado = davRecti.getProveedorLocal();
		/*branch ingreso 2011-009 hosorio inicio 25/07/2011*/
		//if (davOrig != null)
		if (davOrig != null && !isEmpty(davOrig.getProveedorLocal()))
			actual = davOrig.getProveedorLocal();
		/*branch ingreso 2011-009 hosorio fin 25/07/2011*/

		if (!isEmpty(rectificado)) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC;
			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR_LOCAL);


			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			clave.put("NUM_SECPARTIC", getSecuenciaParticipante(tipoCambio,actual, rectificado));

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "tipoDocumentoIdentidad"), datos, "COD_TIPDOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numeroDocumentoIdentidad"), datos, "NUM_DOCIDENT", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nombreRazonSocial"), datos, "NOM_RAZONSOCIAL", null, null);
			agregarCambioRegistro(codTabla, clave, datos, tipoCambio);
		}

	}

	/**
	 * Comparacion formb intermediario.
	 * 
	 * @param davRecti DAV
	 * @param davOrig DAV
	 * @throws Exception 
	 */
	public void comparacionFormbIntermediario(DAV davRecti, DAV davOrig) throws Exception {

		Participante rectificado = null;
		Participante actual = null;
		if (davRecti != null)
			rectificado = davRecti.getIntermediario();
		if (davOrig != null)
			actual = davOrig.getIntermediario();

		if (!isEmpty(rectificado)) {
			Map<String, Object> clave = new HashMap<String, Object>();
			Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
			String codTabla = ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC;

			clave.put("NUM_CORREDOC", numcorredoc);
			clave.put("COD_TIPPARTIC", ConstantesDataCatalogo.TIPO_OPERADOR_INTERMEDIARIO);

			String tipoCambio = evaluarCambioRegistro(rectificado, actual);

			clave.put("NUM_SECPARTIC", getSecuenciaParticipante(tipoCambio,actual, rectificado));

			agregarCambioAtributo(comparaAtributo(rectificado, actual, "tipoDocumentoIdentidad"), datos, "COD_TIPDOC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "numeroDocumentoIdentidad"), datos, "NUM_DOCIDENT", null, null);		
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "nombreRazonSocial"), datos, "NOM_RAZONSOCIAL", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "direccion"), datos, "DIR_PARTIC", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "pais"), datos, "COD_PAISORIGEN", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "email"), datos, "NOM_EMAIL", null, null);
			agregarCambioAtributo(comparaAtributo(rectificado, actual, "ciudad"), datos, "DES_UBIGEOCIUDAD", null, null);

			DetSolicitudRectificacionBean drb = agregarCambioRegistro(codTabla, clave, datos, tipoCambio);

			if (((tipoCambio.equals(Constants.IND_REGISTRO_NUEVO))) && drb != null) {
				// se registra las referencias que hay que actualizar al momento de insertar en tablas definitivas
				drb.setListaReferencias(new ArrayList<RecordBean>());

				RecordBean rb = new RecordBean();
				rb.setCodtabla(ConstantesDataCatalogo.TABLA_FORMBPROVEEDOR);

				Map<String, Object> keyref = new HashMap<String, Object>();
				keyref.put("NUM_CORREDOC", numcorredoc);
				keyref.put("NUM_SECPROVE", davRecti.getNumsecuprov());
				rb.setKey(keyref);

				Map<String, Object> datoref = new HashMap<String, Object>();
				datoref.put("NUM_SECPARTIC", "NUM_SECINTERMEDIARIO");
				rb.setDatos(datoref);

				drb.getListaReferencias().add(rb);
			}

		}
	}


	/**
	 * Agregar cambio atributo.
	 * 
	 * @param datoRec DatoRectificacionBean
	 * @param datosRef Map<String,DatoRectificacionBean>
	 * @param columna String
	 * @param objectPath String
	 * @param xmlPath String
	 */
	public void agregarCambioAtributo(DatoRectificacionBean datoRec, Map<String, DatoRectificacionBean> datosRef, String columna, String objectPath,
			String xmlPath) {
		if (datoRec != null) {
			datoRec.setObjectPath(objectPath);
			datoRec.setXmlPath(xmlPath);
			datosRef.put(columna, datoRec);
		}

	}

	/**
	 * Agregar cambio atributo.
	 * 
	 * @param datoRec DatoRectificacionBean
	 * @param datosRef Map<String,DatoRectificacionBean>
	 * @param columna String
	 * @param objectPath String
	 * @param objetoPadre Object
	 */
	public void agregarCambioAtributo(DatoRectificacionBean datoRec, Map<String, DatoRectificacionBean> datosRef, String columna, String objectPath,
			Object objetoPadre) {
		if (datoRec != null) {
			datoRec.setObjetoPadre(objetoPadre);
			datoRec.setObjectPath(objectPath);
			datosRef.put(columna, datoRec);
		}

	}





	/**
	 * Retorna el valor de objnuevo.
	 * 
	 * @return  objnuevo
	 */
	public Object getObjnuevo() {
		return objnuevo;
	}

	/**
	 * Retorna el valor de objanterior.
	 * 
	 * @return  objanterior
	 */
	public Declaracion getObjanterior() {
		return objanterior;
	}

	/**
	 * Establece un valor a objanterior.
	 * 
	 * @param objanterior Declaracion
	 */
	public void setObjanterior(Declaracion objanterior) {
		this.objanterior = objanterior;
	}

	/**
	 * Establece un valor a objnuevo.
	 * 
	 * @param objnuevo Declaracion
	 */
	public void setObjnuevo(Declaracion objnuevo) {
		this.objnuevo = objnuevo;
	}

	/**
	 * Retorna el valor de numcorredoc.
	 * 
	 * @return  numcorredoc
	 */
	public Long getNumcorredoc() {
		return numcorredoc;
	}

	/**
	 * Establece un valor a numcorredoc.
	 * 
	 * @param numcorredoc Long
	 */
	public void setNumcorredoc(Long numcorredoc) {
		this.numcorredoc = numcorredoc;
	}


	/**
	 * Retorna el valor de enviaFechaLlegada.
	 * 
	 * @return  enviaFechaLlegada
	 */
	public boolean getEnviaFechaLlegada() {
		return enviaFechaLlegada;
	}

	/**
	 * Establece un valor a enviaFechaLlegada
	 * 
	 * @param enviaFechaLlegada boolean
	 */
	public void setEnviaFechaLlegada(boolean enviaFechaLlegada) {
		this.enviaFechaLlegada = enviaFechaLlegada;
	}


	/**
	 * Retorna el valor de doc transporte.
	 * 
	 * @param serie DatoSerie
	 * @param tipo String
	 * @return  doc transporte
	 */
	private DatoDocTransporte getDocTransporte(DatoSerie serie, String tipo) {

		DUA dua = null;
		if (tipoComparacion.equals("N")) {
			if (tipo.equals("R"))
				dua = ((Declaracion) objnuevo).getDua();
			else
				dua = ((Declaracion) objanterior).getDua();
		} else {
			if (tipo.equals("R"))
				dua = ((Declaracion) objanterior).getDua();
			else
				dua = ((Declaracion) objnuevo).getDua();

		}
		List<DatoSerieDocSoporte> serieDocs = null;
		if (serie != null)
			serieDocs = serie.getListSerieDocSoporte();
		String numDocTransporte = "";
		if (!CollectionUtils.isEmpty(serieDocs)) {
			for (DatoSerieDocSoporte serieDoc : serieDocs) {
				if (serieDoc.getCodtipodocsoporte() != null && serieDoc.getCodtipodocsoporte().equals("3"))// P46-INSI
					numDocTransporte = String.valueOf(serieDoc.getNumiddocsoporte());
			}
		}

		if (!CollectionUtils.isEmpty(dua.getListDocTransporte())) {
			for (DatoDocTransporte docTransp : dua.getListDocTransporte()) {
				if (numDocTransporte.equals(String.valueOf(docTransp.getNumsecdoctrans())))
					return docTransp;
			}
		}
		return null;
	}

	private Long getSecuenciaParticipante(String tipoCambio, Object actual, Object rectificado){
		Long secParticipante = Long.parseLong("0");
		if (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO)){
			secParticipante = Long.parseLong("0");
		} else if (tipoCambio.equals(Constants.IND_REGISTRO_ANULADO)){				
			secParticipante = actual==null?((Participante) rectificado).getSecuenciaDeParticipantes():((Participante) actual).getSecuenciaDeParticipantes();		
		} else {
			secParticipante = ((Participante) actual).getSecuenciaDeParticipantes();
		}
		return secParticipante;
	}

	/**
	 * Retorna el valor de tipo comparacion.
	 * 
	 * @return  tipo comparacion
	 */
	public String getTipoComparacion() {
		return tipoComparacion;
	}

	/**
	 * Establece un valor a tipoComparacion.
	 * 
	 * @param tipoComparacion String
	 */
	public void setTipoComparacion(String tipoComparacion) {
		this.tipoComparacion = tipoComparacion;
	}

	/**
	 * Retorna el valor de lista participantes.
	 * 
	 * @return  lista participantes
	 */
	public List<Participante> getListaParticipantes() {
		return listaParticipantes;
	}

	/**
	 * Establece un valor a listaParticipantes.
	 * 
	 * @param listaParticipantes List<Participante>
	 */
	public void setListaParticipantes(List<Participante> listaParticipantes) {
		this.listaParticipantes = listaParticipantes;
	}

	/**
	 * Completar datos.
	 * 
	 * @param declaracion Declaracion
	 */
	public void completarDatos(Object objDeclaracion) {
		Declaracion declaracion=(Declaracion)objDeclaracion;
		DescrPosicion descrMinNuevaEstructura = null;//pase 548 Transmision de Rectificacion DESCRMINIMAS 

		String codTipoOper;
		if (declaracion.getDua().getManifiesto() != null) {
			codTipoOper = obtenerTipoParticipante(declaracion);
			/*  PAS20191U220200019 - Para obtener el tipo de Participante
			String viaTransporte = declaracion.getDua().getManifiesto().getCodmodtransp();
			if ("1".equals(viaTransporte)) {
				codTipoOper = ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA;
			} else if ("4".equals(viaTransporte)) {
				codTipoOper = ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
			}
			*/
			//if (declaracion.getDua().getManifiesto().getEmpTransporte() != null) {
			if (!isEmpty(declaracion.getDua().getManifiesto().getEmpTransporte())) {
				DataCatalogo tippartra = new DataCatalogo();
				tippartra.setCodDatacat(codTipoOper);
				declaracion.getDua().getManifiesto().getEmpTransporte().setTipoParticipante(tippartra);
				soporteService.completarParticipante(declaracion.getDua().getManifiesto().getEmpTransporte());
			}
		}

		//PAS20145E220000090 - MATC 20140613 INICIO
		if( this.enviaFechaLlegada ) { 
			declaracion.getDua().setFecLlegada(declaracion.getDua().getManifiesto().getFectermino());
			//gmontoya 17732 se desmarca comentada por bug blocker arey
			declaracion.getDua().getManifiesto().setFectermino(SunatDateUtils.getDefaultDate());
		}
		else {
			if( this.objanterior != null  && !SunatDateUtils.sonIguales(this.objanterior.getDua().getFecLlegada(), SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA ) )
				declaracion.getDua().setFecLlegada(this.objanterior.getDua().getFecLlegada());
		}
		//PAS20145E220000090 - MATC 20140613 FINAL

		if (declaracion.getDua().getRucAnexoUbicacion()!= null && !isEmpty(declaracion.getDua().getRucAnexoUbicacion())) {
			soporteService.completarParticipante(declaracion.getDua().getRucAnexoUbicacion());
		}

		if (declaracion.getDua().getDeclarante()!= null && !isEmpty(declaracion.getDua().getDeclarante())) {
			soporteService.completarParticipante(declaracion.getDua().getDeclarante());
		}
		//PAS20144E610000033 -GIMJ		
		if (this.objanterior.getDua().getPagoElectronico()!= null && declaracion.getDua().getPagoElectronico()==null) {
			DatoPagoDecla datoPagoDecla = new DatoPagoDecla();
			datoPagoDecla.setNumcorredoc(this.objanterior.getDua().getPagoElectronico().getNumcorredoc());
			declaracion.getDua().setPagoElectronico(datoPagoDecla);
		}
		
		/*Inicio PAS20171U220200005 para la comparaci�n se requiere el key*/
		if (this.objnuevo.getDua().getListIndicadores() != null){
			Elementos<DatoIndicadores> nuevosIndicadores = this.objnuevo.getDua().getListIndicadores(); 
			
			if(nuevosIndicadores!=null){//P_SNADE054-1474
				for(DatoIndicadores   indicador: nuevosIndicadores ){
					String codIndicador = indicador.getCodtipoindica();
					if(codIndicador!=null && ( codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO )
										|| codIndicador.equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES) )) {
						if(indicador.getNumeroCorrelativo()==null)indicador.setNumeroCorrelativo(numcorredoc);
					}
				}
			}
		}/*Fin PAS20171U220200005*/
		

		//BUG 18245 pase 105 -arey
		if (this.objanterior.getDua().getDatoCertificadoOrigen().getListAutocertificacion()!=null){
			if (!CollectionUtils.isEmpty(this.objanterior.getDua().getDatoCertificadoOrigen().getListAutocertificacion())) {
				for(DatoAutocertificacion certif :  this.objanterior.getDua().getDatoCertificadoOrigen().getListAutocertificacion()){
					if(certif.getNomProdmerc()!=null && certif.getNomProdmerc()!=" "){
						certif.setNomproduc(certif.getNomProdmerc());
					}
					/**Inicio adicionado PAS20155E220100048 bug 567*/
					if(certif.getFecEmborigen()==null){
						certif.setFecEmborigen(this.objanterior.getDua().getListDocTransporte().get(0).getFecembarqueorg());
					}
					/**Fin adicionado PAS20155E220100048 bug 567*/
					/**Inicio adicionado PAS20155E220200172**/
					if(certif.getCodPuertoEmbOrigen()==null){
						certif.setCodPuertoEmbOrigen(this.objanterior.getDua().getListDocTransporte().get(0).getCodpuertoorg());
					}
					/**Fin adicionado PAS20155E220200172**/
				}
			}	
		}

		//Bug 20737-Regularizacion: Al setearle valor al nomproduc del obj original, si no se setea e mismo valor al obj nuevo,
		//el comparador detecta cambio a pesar q en el xml no se envia retificacion
		if (this.objnuevo.getDua().getDatoCertificadoOrigen().getListAutocertificacion()!=null){
			if (!CollectionUtils.isEmpty(this.objnuevo.getDua().getDatoCertificadoOrigen().getListAutocertificacion())) {
				for(DatoAutocertificacion certif :  this.objnuevo.getDua().getDatoCertificadoOrigen().getListAutocertificacion()){
					if(certif.getNomproduc()==null && certif.getNomProdmerc()!=null && certif.getNomProdmerc()!=" "){
						certif.setNomproduc(certif.getNomProdmerc());
					}
				}
			}	
		}
		//fin bug 20737

		// Control de movimientos de equipamiento para los precintos
		if (this.objnuevo.getDua().getManifiesto().getListEquipamientos() != null){
			for (DatoEquipamiento datoEquipamiento: this.objnuevo.getDua().getManifiesto().getListEquipamientos()){
				datoEquipamiento.setNumcorredoc(numcorredoc);				
				if (datoEquipamiento.getListPrecintos()!=null){
					Elementos<DatoMovEquipamiento> listDatoMovEquipamiento= new Elementos<DatoMovEquipamiento>();					
					if (datoEquipamiento.getListmovEquipamiento() ==null){
						datoEquipamiento.setListmovEquipamiento(new Elementos<DatoMovEquipamiento>());
					}	
					DatoMovEquipamiento datoMovEquipamiento = new DatoMovEquipamiento(); 
					datoMovEquipamiento.setNumcorredoc(numcorredoc);
					datoMovEquipamiento.setNumequipo(datoEquipamiento.getNumequipo());
					datoMovEquipamiento.setCodtipmov("99");
					listDatoMovEquipamiento.add(datoMovEquipamiento);				
					datoEquipamiento.setListmovEquipamiento(listDatoMovEquipamiento);
				}
			}
		}
		
		
		//BUG 18461 pase 105 -arey -- se quita por bug 18605 no se envia a rectificar el valor T.
		/*if(this.objanterior.getDua().getListIndicadores()!=null){
			IndicadorDUADAO indicadorDuaDAO = fabricaDeServicios.getService("indicadorDUADAO");
		   	for (DatoIndicadores datoInd : this.objanterior.getDua().getListIndicadores()) {
		 		Map paramInd = new HashMap();				
		 		paramInd.put("num_corredoc",numcorredoc);
		 		paramInd.put("cod_indicador",datoInd.getCodtipoindica());

		 		Map mapIndicador = indicadorDuaDAO.findByDocumentoAndValor(paramInd);
		 		if(mapIndicador!=null && !mapIndicador.isEmpty()){
		 			String codTipoRegistro =(String) mapIndicador.get("COD_TIPOREGISTRO");
		 			datoInd.setValindicador(codTipoRegistro);
		 		}	
		 	}
		}*/
  		
		if (!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())) {

			for (DatoSerie serie : declaracion.getDua().getListSeries()) {
				serie.setNumcorredoc(numcorredoc);

				DatoProducto product = serie.getProducto();
				String codpantidum = product != null ? product.getCodpantidum() : null;
				if (SunatStringUtils.isEmptyTrim(codpantidum))
					serie.getProducto().setCodpantidum("0");
				if (SunatStringUtils.isEmptyTrim(serie.getIndzonafranca()))
					serie.setIndzonafranca("0");

				if (!CollectionUtils.isEmpty(serie.getListVehiculos())) {

					for (DatoVehiculo vehiculo : serie.getListVehiculos()) {
						vehiculo.setNumcorredoc(numcorredoc);
						vehiculo.setNumserie(serie.getNumserie());

						if (!CollectionUtils.isEmpty(vehiculo.getListMontoGastos())) {
							for (DatoMontoGasto monto : vehiculo.getListMontoGastos()) {
								monto.setNumcorredoc(numcorredoc);
								monto.setNumserie(serie.getNumserie());
							}
						}

					}

				}

				if (!CollectionUtils.isEmpty(serie.getListSerieDocSoporte())) {
					for (DatoSerieDocSoporte serieSoporte : serie.getListSerieDocSoporte()) {
						serieSoporte.setNumcorredoc(numcorredoc);
						serieSoporte.setNumserie(serie.getNumserie());

						for (DatoOtroDocSoporte docSoporte : declaracion.getDua().getListOtrosDocSoporte()) {
							if (SunatNumberUtils.isEqual(serieSoporte.getNumiddocsoporte(), docSoporte.getNumsecdocum())) {
								serieSoporte.setCodtipooper(docSoporte.getCodtipoproceso());
							}
						}
					}
				}

				Elementos<DatoSerieDocSoporte> listaSerieSoporte = getListSerieSoporteByType(serie, DOC_SOPORTE);
				if (!CollectionUtils.isEmpty(listaSerieSoporte)) {
					/*branch 2011-009 hosorio inicio*/
					//for (DatoSerieDocSoporte serieSoporte : serie.getListSerieDocSoporte()) {
					for (DatoSerieDocSoporte serieSoporte : listaSerieSoporte) {
						/*branch 2011-009 hosorio fin*/
						for (DatoOtroDocSoporte docSoporte : declaracion.getDua().getListOtrosDocSoporte()) {
							if (SunatNumberUtils.isEqual(serieSoporte.getNumiddocsoporte(), docSoporte.getNumsecdocum())) {
								serieSoporte.setCodtipooper(docSoporte.getCodtipoproceso());
							}
						}

					}
				}

				listaSerieSoporte = getListSerieSoporteByType(serie, DOC_AUTORIZANTE);
				if (!CollectionUtils.isEmpty(listaSerieSoporte)) {
					/*branch 2011-009 hosorio inicio*/
					//for (DatoSerieDocSoporte serieSoporte : serie.getListSerieDocSoporte()) {
					for (DatoSerieDocSoporte serieSoporte : listaSerieSoporte) {
						/*branch 2011-009 hosorio fin*/
						serieSoporte.setCodtipooper("P");
					}
				}

				listaSerieSoporte = getListSerieSoporteByType(serie, CERTI_ORIGEN);
				if (!CollectionUtils.isEmpty(listaSerieSoporte)) {
					/*branch 2011-009 hosorio inicio*/
					//for (DatoSerieDocSoporte serieSoporte : serie.getListSerieDocSoporte()) {
					for (DatoSerieDocSoporte serieSoporte : listaSerieSoporte) {
						/*branch 2011-009 hosorio fin*/
						serieSoporte.setCodtipooper("C");

					}
				}

				if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
					for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
						regPrec.setNumcorredoc(numcorredoc);
						regPrec.setNumserie(serie.getNumserie());
					}
				}

				/**
				 * Generamos objeto de datos adicionales, que actualmente estan en series
				 */
				DatoAdiSerieImpoConsumo datoAdiSerieImpoConsumo = new DatoAdiSerieImpoConsumo (); 
				CompletarDatosAdicionalesSerieImpoConsumo(datoAdiSerieImpoConsumo, serie);
				if ((sizeBean(DatoAdiSerieImpoConsumo.class, datoAdiSerieImpoConsumo)> 2)
						// P46 - PAS20155E220000329 - bug 22350: se agrega condicion para evitar que se considere como anulacion del campo valpreciovta  
						// en el caso que en la numeracion y rectificacion no se transmita valpreciovta 
						|| (ConstantesDataCatalogo.TRANSACCION_RECTIFICACION.equals(getTransaccion(serie)))){
					serie.setDatoAdiSerieImpoConsumo( datoAdiSerieImpoConsumo);					
				}

				DatoAdiSerieAtreexp datoAdiSerieAtreexp = new DatoAdiSerieAtreexp();
				if (CompletarDatosAdicionalesSerieAtreexp(datoAdiSerieAtreexp, serie)
						// P46 - PAS20155E220000329 - bug 22081
						|| (ConstantesDataCatalogo.TRANSACCION_RECTIFICACION.equals(getTransaccion(serie))))
					serie.setDatoAdiSerieAtreexp(datoAdiSerieAtreexp);
			}
		}

		if (!CollectionUtils.isEmpty(declaracion.getDua().getListDocAutorizantes())) {
			for (DatoDocAutorizante autoriz : declaracion.getDua().getListDocAutorizantes()) {
				autoriz.setNumcorredoc(numcorredoc);
				autoriz.setCodTipoOper("P");
				/*r2bz PAra los documentos VUCE la comparacion debe realizarse con los datos del documento de control*/
				if (SunatStringUtils.isStringInList(autoriz.getCodtipodocum(), DOC_RESOLUTIVO, SOLICITUD_SUCE)) {
					try {
						MercanciaRestringidaEntidadService mercanciaRestringidaEntidadService = fabricaDeServicios.getService("mercanciaRestringidaEntidadService");						
						DocControlMercRestringidaVuce docControlMercRestringidaVuce = 
								mercanciaRestringidaEntidadService.obtenerDocumentoVuce(SunatNumberUtils.toLong(autoriz.getNumdocum()), autoriz.getCodtipodocum());
						if (docControlMercRestringidaVuce!= null){
							autoriz.setFecemision(SunatDateUtils.sonIguales(docControlMercRestringidaVuce.getFechaDocumento(),SunatDateUtils.getDefaultDate(),SunatDateUtils.COMPARA_SOLO_FECHA)?docControlMercRestringidaVuce.getFechaInicioVigencia() :docControlMercRestringidaVuce.getFechaDocumento());
							autoriz.setFecvencimiento(docControlMercRestringidaVuce.getFechaFinVigencia());	
						}
					} catch (Exception e) {						
						
					}
				}
				
				/* olunar 2012-009 */
				if(autoriz.getFecvencimiento()!=null)
					autoriz.setFecvencimiento(SunatDateUtils.getOnlyDateFrom(autoriz.getFecvencimiento()));
				if(autoriz.getFecemision()!=null)
					autoriz.setFecemision(SunatDateUtils.getOnlyDateFrom(autoriz.getFecemision()));
				/* fin */				
			}
		}

		if (declaracion.getDua().getDatoCertificadoOrigen() != null) {			
			if (!CollectionUtils.isEmpty(declaracion.getDua().getDatoCertificadoOrigen().getListAutocertificacion())) {				
				for (DatoAutocertificacion cert : declaracion.getDua().getDatoCertificadoOrigen().getListAutocertificacion()) {
					cert.setNumcorredoc(numcorredoc);
					cert.setCodTipoOper("C");
					cert.setFecEmborigen(declaracion.getDua().getListDocTransporte().get(0).getFecembarqueorg());//linea adicionada por PAS20155E220100048 bug 567
					cert.setCodPuertoEmbOrigen(declaracion.getDua().getListDocTransporte().get(0).getCodpuertoorg());//adicionado por PAS20155E220200172
					//r2bz
					DatoOtroDocSoporte soporteCO = new DatoOtroDocSoporte() ;
					soporteCO.setAnndocasoc(SunatDateUtils.getAnho((Date)cert.getFecemision()).toString());
					soporteCO.setNumdocasoc(cert.getNumdocumento());
					soporteCO.setCodtipodocasoc(cert.getCodtipoCO());
					soporteCO.setFecdocasoc(cert.getFecemision());
					soporteCO.setCodtipoproceso(cert.getCodTipoOper());
					soporteCO.setFecvencimiento(SunatDateUtils.getDate("31/12/9999", "dd/MM/yyyy"));
					soporteCO.setNumsecdocum(cert.getNumsecCO());
					//declaracion.getDua().setListOtrosDocSoporteCO(new Elementos<DatoOtroDocSoporte> ());
					declaracion.getDua().getListOtrosDocSoporteCO().add(soporteCO);
				}			
			}


		}

		if (!CollectionUtils.isEmpty(declaracion.getDua().getListOtrosDocSoporte())) {
			for (DatoOtroDocSoporte soporte : declaracion.getDua().getListOtrosDocSoporte())
				soporte.setNumcorredoc(numcorredoc);
		}

		if (!CollectionUtils.isEmpty(declaracion.getDua().getListOtrosDocSoporteCO())) {
			for (DatoOtroDocSoporte soporteCO : declaracion.getDua().getListOtrosDocSoporteCO())
				soporteCO.setNumcorredoc(numcorredoc);
		}



		if (!CollectionUtils.isEmpty(declaracion.getDua().getListFacturaRef())) {
			for (DatoFacturaref factref : declaracion.getDua().getListFacturaRef()){
				factref.setNumcorredoc(numcorredoc);
				/* gmontoya 2012-009 */
				if(factref.getFecfactura()!=null)
					factref.setFecfactura(SunatDateUtils.getOnlyDateFrom(factref.getFecfactura()));
				/* fin */		
			}
		}

		if (declaracion.getDua().getPago().getPagoDeclaracion()!= null && declaracion.getDua().getPago().getPagoDeclaracion().getNumctapagoelec()!= null){
			declaracion.getDua().setPagoElectronico(declaracion.getDua().getPago().getPagoDeclaracion());
			declaracion.getDua().getPagoElectronico().setNumcorredoc(numcorredoc);
		}

		if (!CollectionUtils.isEmpty(declaracion.getListDAVs())) {

			for (DAV dav : declaracion.getListDAVs()) {

				dav.setNumcorredoc(numcorredoc);

				if( dav.getProveedorLocal() != null && ! SunatStringUtils.isEmpty( dav.getProveedorLocal().getNombreRazonSocial() ) ){
					dav.getProveedorLocal().getTipoParticipante().setCodDatacat("91");
					soporteService.completarParticipante(dav.getProveedorLocal());
				}
				/*BUG 17482 - arey*/
				if(dav.getProveedor()!=null && dav.getCodproveedor().trim().length()>0 
						&& (dav.getProveedor().getNumeroDocumentoIdentidad()==null || dav.getProveedor().getNumeroDocumentoIdentidad().trim().length()==0) ){
					dav.getProveedor().setNumeroDocumentoIdentidad(dav.getCodproveedor());
				}

				if (dav.getPersonaDecl() != null){
					dav.getPersonaDecl().getTipoParticipante().setCodDatacat("92");//pase 436 - 2015
					soporteService.completarParticipante(dav.getPersonaDecl());
				}

				if (!CollectionUtils.isEmpty(dav.getListFacturas())) {

					for (DatoFactura factura : dav.getListFacturas()) {
						factura.setNumcorredoc(numcorredoc);
						factura.setNumsecprove(dav.getNumsecuprov());
						/* gmontoya 2012-009 */
						if(factura.getFecfactura()!=null)
							factura.setFecfactura(SunatDateUtils.getOnlyDateFrom(factura.getFecfactura()));
						/* fin */
						if (!CollectionUtils.isEmpty(factura.getListFactSucesivas())) {
							for (DatoFactSuce factSuce : factura.getListFactSucesivas()) {
								factSuce.setNumcorredoc(numcorredoc);
								factSuce.setNumsecprove(dav.getNumsecuprov());
								factSuce.setNumsecfact(factura.getNumsecfactu());
							}
						}

						if (!CollectionUtils.isEmpty(factura.getListItems())) {
							for (DatoItem item : factura.getListItems()) {
								item.setNumcorredoc(numcorredoc);
								item.setNumsecprove(dav.getNumsecuprov());
								item.setNumsecfact(factura.getNumsecfactu());

								if (item.getMontoProv() != null) {
									item.getMontoProv().setNumcorredoc(numcorredoc);
									item.getMontoProv().setNumsecprove(dav.getNumsecuprov());
									item.getMontoProv().setNumsecfact(factura.getNumsecfactu());
									item.getMontoProv().setNumsecitem(item.getNumsecitem());
								}

								if (!CollectionUtils.isEmpty(item.getListDecrMinima())) {
									for (DatoDescrMinima descri : item.getListDecrMinima()) {
										descri.setNumcorredoc(numcorredoc);
										descri.setNumsecprove(dav.getNumsecuprov());
										descri.setNumsecfact(factura.getNumsecfactu());
										descri.setNumsecitem(item.getNumsecitem());
										//pase 548 
										//agregado - Diligencia de Rectificacion DESCRMINIMAS
										//Transmision de la Rectificacion DESCRMINIMAS									
										String codigoCampo = item.getListDecrMinima().get(0).getCodtipdescr();	
										descrMinNuevaEstructura =((FormBItemDescriDAO) fabricaDeServicios.getService("formBItemDescriDAO")).getDescrPosicion(codigoCampo); 
										if(descrMinNuevaEstructura!=null){
											descri.setCodmercancia(descrMinNuevaEstructura.getCodigoTipoDescrMinima());
											item.setCodtipdescrmin(descrMinNuevaEstructura.getCodigoTipoDescrMinima());
										}
									}
								}

								if (!CollectionUtils.isEmpty(item.getListSerieItems())) {
									for (DatoSerieItem serieItem : item.getListSerieItems()) {
										serieItem.setNumcorredoc(numcorredoc);
										serieItem.setNumsecprove(dav.getNumsecuprov());
										serieItem.setNumsecfact(factura.getNumsecfactu());
										serieItem.setNumsecitem(item.getNumsecitem());
									}
								}
								if (!CollectionUtils.isEmpty(item.getListObservaciones())) {
									for (Observacion obsItem : item.getListObservaciones()) {
										obsItem.setNumcorredoc(numcorredoc);
										obsItem.setNumsecitem(item.getNumsecitem());
									}									
								}
							}
						}

					}
				}

				if (!CollectionUtils.isEmpty(dav.getListMontos())) {
					for (DatoMonto monto : dav.getListMontos()) {
						monto.setNumcorredoc(numcorredoc);
						monto.setNumsecprove(dav.getNumsecuprov());
					}
				}

				if (!CollectionUtils.isEmpty(dav.getListCondTransacciones())) {
					for (DatoCondTransaccion trans : dav.getListCondTransacciones()) {
						trans.setNumcorredoc(numcorredoc);
						trans.setNumsecprove(dav.getNumsecuprov());
					}
				}

			}

		}

	}

	/**
	 * Obtener clave.
	 * 
	 * @param codTabla String
	 * @param objeto Object
	 * @return el map
	 * @throws Exception 
	 */
	public Map<String, Object> obtenerClave(String codTabla, Object objeto) {

		Map<String, Object> clave = new HashMap<String, Object>();

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_CAB_DECLARA)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_IMPCONSUMO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_CAB_ADI_TRANSITO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_CAB_ADI_ADMTEM)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_FINYUBICACION)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_DET_DECLARA)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
		}
		if (codTabla.equals(ConstantesDataCatalogo.TABLA_DETIMPCONSUMO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
		}
		if (codTabla.equals(ConstantesDataCatalogo.TABLA_DET_ADI_ATPA)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
		}
		if (codTabla.equals(ConstantesDataCatalogo.TABLA_DET_ADI_ATREEX)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_VEHI_CETICO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_MONTOGASTO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
			clave.put("COD_CPTOGASTOS", getAtributo(objeto, "tipmonto"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
			clave.put("NUM_SECDOC", getAtributo(objeto, "numiddocsoporte"));
			clave.put("COD_TIPOPER", getAtributo(objeto, "codtipooper"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_FACTURA_SERIE)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
			clave.put("NUM_SECFACT", getAtributo(objeto, "numiddocsoporte"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_DOCASOCIADO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECDOC", getAtributo(objeto, "numsecdocum"));
			if (objeto instanceof DatoDocAutorizante)
				clave.put("COD_TIPOPER", getAtributo(objeto, "codTipoOper"));
			else if (objeto instanceof DatoOtroDocSoporte)
				clave.put("COD_TIPOPER", getAtributo(objeto, "codtipoproceso"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_FORMA_FACTU)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECFACT", getAtributo(objeto, "numsecfactu"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_DOCUPRECE_DUA)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
			clave.put("COD_ADUANAPRE", getAtributo(objeto, "codaduapre"));
			clave.put("COD_REGIMENPRE", getAtributo(objeto, "codregipre"));
			String andecl = (String) getAtributo(objeto, "anndeclpre");
			if (SunatStringUtils.length(andecl) > 3)
				andecl = andecl.substring(0, 4);
			clave.put("ANN_PRESENPRE", andecl);

			Integer numDeclPre = SunatNumberUtils.toInteger(getAtributo(objeto, "numdeclpre"));

			clave.put("NUM_DECLARACIONPRE", numDeclPre);
			clave.put("NUM_SECSERIEPRE", getAtributo(objeto, "numserpre"));

		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_CERTORIGEN)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECDOC", getAtributo(objeto, "numsecCO"));

			if (objeto instanceof DatoDocAutorizante)
				clave.put("COD_TIPOPER", getAtributo(objeto, "codTipoOper"));
			else if (objeto instanceof DatoOtroDocSoporte)
				clave.put("COD_TIPOPER", getAtributo(objeto, "codtipoproceso"));
			else
				clave.put("COD_TIPOPER", getAtributo(objeto, "codTipoOper"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBPROVEEDOR)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecuprov"));
		}
		// PAS20191U220500009 20190327 GTP
		if (codTabla.equals(Constantes.TABLA_DESCRIP_OTROS)) {
		//if (codTabla.equals("T9833")) {
			//DAV rectificado = (DAV) objeto;
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECDOC", getAtributo(objeto, "numsecuprov"));
			// PAS20191U220500080 JCV 20190621 Debe ser la tabla de 
			//clave.put("COD_TABLA", codTabla);
			clave.put("COD_TABLA", ConstantesDataCatalogo.TABLA_FORMBPROVEEDOR);
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_CONDICION_TRANSA)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecprove"));
			clave.put("COD_INDTRANSACCION", getAtributo(objeto, "codindcondtra"));

		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_FACTUSUCE)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			//clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecprove")); //NO ES PK PAS20155E220200139
			clave.put("NUM_SECFACT", getAtributo(objeto, "numsecfact"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_COMPROBPAGO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			//clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecprove"));
			clave.put("NUM_SECFACT", getAtributo(objeto, "numsecfactu"));

		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_ITEMFACTURA)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			//clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecprove"));
			//clave.put("NUM_SECFACT", getAtributo(objeto, "numsecfact"));
			clave.put("NUM_SECITEM", getAtributo(objeto, "numsecitem"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			//clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecprove"));//erodriguezb RIN10 bug 21106
			//clave.put("NUM_SECFACT", getAtributo(objeto, "numsecfact"));//erodriguezb RIN10 bug 21106
			clave.put("NUM_SECITEM", getAtributo(objeto, "numsecitem"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBITEMDESCRI)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			//clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecprove")); //no es pk 			//PAS20155E220200139
			//clave.put("NUM_SECFACT", getAtributo(objeto, "numsecfact"));//no es pk 			//PAS20155E220200139
			clave.put("NUM_SECITEM", getAtributo(objeto, "numsecitem"));
			/*branch ingreso 2011-009 hosorio inicio*/
			//clave.put("COD_TIPDESC", getAtributo(objeto, "codtipdescr"));
			//	pase 548 
			//clave.put("COD_TIPDESC", SunatStringUtils.rpad((String)getAtributo(objeto, "codtipdescr"), 3, ' '));
			clave.put("COD_TIPDESC",  getAtributo(objeto, "codtipdescr")!=null?SunatStringUtils.trim((String)getAtributo(objeto, "codtipdescr")):' ');//modificado para DESCRMINIMAS
			clave.put("COD_MERCANCIA", getAtributo(objeto, "codmercancia")!=null?getAtributo(objeto, "codmercancia"):"**" ); //modificado para DESCRMINIMAS
			/*branch ingreso 2011-009 hosorio fin*/

		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_OBSERVACION)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECOBS", getAtributo(objeto, "numsecuencia"));
			//clave.put("NUM_SECITEM", getAtributo(objeto, "numsecitem")); //r2bz la clave deber�a ser con respecto al tipo de observaci�n
			clave.put("COD_TIPOBS", getAtributo(objeto, "codtipobserva")); 

		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_SERIES_ITEM)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			//clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecprove"));//esta columna no es pk arey bug 18713
			//clave.put("NUM_SECFACT", getAtributo(objeto, "numsecfact"));//esta columna no es pk arey bug 18713
			clave.put("NUM_SECITEM", getAtributo(objeto, "numsecitem"));
			clave.put("NUM_SECSERIE", getAtributo(objeto, "numserie"));
		}

		if (codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBMONTO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_SECPROVE", getAtributo(objeto, "numsecprove"));
			clave.put("COD_MONTO", getAtributo(objeto, "codmonto"));
		}
		
		if (codTabla.equals(ConstantesDataCatalogo.TABLA_EQUIPAMIENTO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_EQUIPAMIENTO", getAtributo(objeto, "numequipo"));			
		}
		
		if (codTabla.equals(ConstantesDataCatalogo.TABLA_MOVEQUIPAMIENTO)) {
			clave.put("NUM_CORREDOC", getAtributo(objeto, "numcorredoc"));
			clave.put("NUM_EQUIPAMIENTO", getAtributo(objeto, "numequipo"));
			clave.put("COD_TIPMOV", getAtributo(objeto, "codtipmov"));		
		}
		return clave;
	}

	/**
	 * Checks if is empty.
	 * 
	 * @param participante Participante
	 * @return true, if is empty
	 */
	public boolean isEmpty(Participante participante) {
		if (participante != null) {
			/*branch ingreso 2011-009 hosorio inico 25/07/2011*/
			//if (participante.getNumeroDocumentoIdentidad() == null)
			if (SunatStringUtils.isEmptyTrim(participante.getNumeroDocumentoIdentidad()))
				/*branch ingreso 2011-009 hosorio inico 25/07/2011*/
				return true;
		} else
			return true;

		return false;
	}

	/**
	 * Buscar en lista.
	 * 
	 * @param lstObj List<DatoRegPrecedencia>
	 * @param obj DatoRegPrecedencia
	 * @return el dato reg precedencia
	 */
	public DatoRegPrecedencia buscarEnLista(List<DatoRegPrecedencia> lstObj, DatoRegPrecedencia obj) {

		if (!CollectionUtils.isEmpty(lstObj)) {

			for (DatoRegPrecedencia regPrec : lstObj) {

				String anhoPre1 = null;
				String anhoPre2 = null;
				if (SunatStringUtils.length(regPrec.getAnndeclpre()) > 3)
					anhoPre1 = regPrec.getAnndeclpre().substring(0, 4);
				if (SunatStringUtils.length(obj.getAnndeclpre()) > 3)
					anhoPre2 = obj.getAnndeclpre().substring(0, 4);

				Integer numDeclRect = SunatNumberUtils.toInteger(regPrec.getNumdeclpre());
				Integer numDeclAct = SunatNumberUtils.toInteger(obj.getNumdeclpre());

				if (SunatStringUtils.isEqualTo(regPrec.getCodregipre(), obj.getCodregipre())
						&& SunatStringUtils.isEqualTo(regPrec.getCodaduapre(), obj.getCodaduapre())
						&& SunatNumberUtils.isEqual(numDeclRect, numDeclAct) && SunatNumberUtils.isEqual(regPrec.getNumserpre(), obj.getNumserpre())
						&& SunatStringUtils.isEqualTo(anhoPre1, anhoPre2)) {
					return regPrec;
				}

			}

		}
		return null;
	}
	/*branch 2011-009 hosorio inicio*/
	protected Elementos<DatoSerieDocSoporte> getListSerieSoporteByType(DatoSerie serie,String listCodtipodocsoporte){
		Elementos<DatoSerieDocSoporte> listaSerieSoporte=new Elementos<DatoSerieDocSoporte>();
		if(!CollectionUtils.isEmpty(serie.getListSerieDocSoporte())){
			for(DatoSerieDocSoporte serieSoporte:serie.getListSerieDocSoporte()){
				if( SunatStringUtils.isStringInList(serieSoporte.getCodtipodocsoporte(), listCodtipodocsoporte) ){
					listaSerieSoporte.add(serieSoporte);
				}
			}
		}


		return listaSerieSoporte;

	}
	/*branch 2011-009 hosorio fin*/

	//Ini P46 - PAS20155E220000329 - bug 22350
	private String getTransaccion(DatoSerie datoSerie) {
//		Mensaje mensaje = (Mensaje)datoSerie.getPadre().getPadre().getPadre();
//		Control control = mensaje.getControl();
//		
//		String transaccion = "";
//		
//		if(control.getTipoDeTransaccion() != null && control.getTipoDeTransaccion().length() == 4) {
//			transaccion = control.getTipoDeTransaccion().substring(2, 4);
//		}
		/**Inicio de ajustes indicados por errores 24 - pase508*/
		String transaccion = "";
		
		boolean esMensajeNulo = datoSerie == null || datoSerie.getPadre() == null 
				|| datoSerie.getPadre().getPadre() == null
				|| datoSerie.getPadre().getPadre().getPadre() == null;

		if(!esMensajeNulo) {
			Mensaje mensaje = (Mensaje)datoSerie.getPadre().getPadre().getPadre();
			Control control = mensaje.getControl();
			
			if(control != null && control.getTipoDeTransaccion() != null 
					&& control.getTipoDeTransaccion().length() == 4) {
				transaccion = control.getTipoDeTransaccion().substring(2, 4);
			}	
		}
		/**Fin de ajustes indicados por errores 24 - pase508*/	

		return transaccion;
	}
	//Fin P46 - PAS20155E220000329 - bug 22350
		
	private DatoAdiSerieImpoConsumo CompletarDatosAdicionalesSerieImpoConsumo (DatoAdiSerieImpoConsumo datoAdiSerieImpoConsumo, DatoSerie serie){
		datoAdiSerieImpoConsumo.setNumcorredoc(serie.getNumcorredoc());
		datoAdiSerieImpoConsumo.setNumserie(serie.getNumserie());
		datoAdiSerieImpoConsumo.setValindcodlib(serie.getValindcodlib()==null?null:serie.getValindcodlib());
		
		//Ini P46 - PAS20155E220000329 - bug 22350
		if(ConstantesDataCatalogo.TRANSACCION_RECTIFICACION.equals(getTransaccion(serie))) {
			datoAdiSerieImpoConsumo.setValpreciovta(serie.getValpreciovta());
		} else {
		if (serie.getValpreciovta()!=null && BigDecimal.ZERO.compareTo(serie.getValpreciovta())!=0)
			datoAdiSerieImpoConsumo.setValpreciovta(serie.getValpreciovta());
		}
		//Fin P46 - PAS20155E220000329 - bug 22350

		if( ! SunatStringUtils.isEmpty(serie.getDeszonafranca()) )
			datoAdiSerieImpoConsumo.setDeszonafranca(serie.getDeszonafranca());

		if (serie.getMtofobnet()!=null && BigDecimal.ZERO.compareTo(serie.getMtofobnet())!=0)
			datoAdiSerieImpoConsumo.setMtofobnet(serie.getMtofobnet());	
        /*Adicionado por por_alcohol que no carga donde corresponde al comparar Pase436*/
        if(serie.getPoralcohol()!=null && BigDecimal.ZERO.compareTo(serie.getPoralcohol())!=0)
               datoAdiSerieImpoConsumo.setPoralcohol(serie.getPoralcohol());
        /*Adicionado por por_alcohol que no carga donde corresponde al comparar Pase436*/

		return datoAdiSerieImpoConsumo;

	}

	private  boolean CompletarDatosAdicionalesSerieAtreexp (DatoAdiSerieAtreexp datoAdiSerieAtreexpDato, DatoSerie serie){
		DatoProducto product=serie.getProducto();
		BigDecimal pormerma=product!=null?product.getPormerma():null;

		datoAdiSerieAtreexpDato.setNumcorredoc(serie.getNumcorredoc());
		datoAdiSerieAtreexpDato.setNumserie(serie.getNumserie());	
		datoAdiSerieAtreexpDato.setPormerma(pormerma);
		return pormerma!=null;				
	}

	/* Inicio RIN 10 3007 erodriguezb */

	public void comparacionValorProvisional(Map<String, Object> variablesIngreso) throws Exception {

		Boolean todosItemsValorDefinitivo = variablesIngreso.containsKey("todosItemsValorDefinitivo")?
				(Boolean)variablesIngreso.get("todosItemsValorDefinitivo"):false;
				Boolean tieneIndicadorVP = variablesIngreso.containsKey("tieneIndicadorVP")?(Boolean)variablesIngreso.get("tieneIndicadorVP"):false;
				Boolean declaracionDiligenciada = variablesIngreso.containsKey("declaracionDiligenciada")?(Boolean)variablesIngreso.get("declaracionDiligenciada"):false;

				Declaracion declaraRecti = (Declaracion) this.objnuevo;
				Declaracion declaraOld = (Declaracion) this.objanterior;

				DUA duaRecti = declaraRecti.getDua();
				DUA duaActual = declaraOld.getDua();

				boolean tieneCanal = SunatStringUtils.isEmptyTrim(duaActual.getCodCanal())?false:true;

				String codTabla = null;
				Map<String, Object> clave = new HashMap<String, Object>();

				Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();
				//2.1
				if(!tieneCanal && tieneIndicadorVP && todosItemsValorDefinitivo){
					//--> Se actualiza la "Fecha fin del valor provisional" con el valor por defecto, Formato A
					//codTabla = ConstantesDataCatalogo.TABLA_CAB_DECLARA;
					//clave = obtenerClave(codTabla, duaRecti);

					//Date fecfinprovsionalRecti = SunatDateUtils.getDateFromInteger(99991231);
					//DatoRectificacionBean datoRec1 = new DatoRectificacionBean(fecfinprovsionalRecti, null);
					//datoRec1.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);
					//agregarCambioAtributo(datoRec1, datos, "FEC_FINPROVSIONAL", "dua.fecfinprovsional", null);

					//agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);

					//--> Actualiza la "Fecha fin del valor provisional" Formato B - Valor por defecto
					//--> Actualiza "Valor Estimado" �tems Formato B - Valor por defecto
					//--> Limpia campo FOB Unitario Provisional Formato B *****
					//codTabla = ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL;
					String codTablaFobUnit = ConstantesDataCatalogo.TABLA_ITEMFACTURA;
					Map<String, Object> claveFobUnit = new HashMap<String, Object>();
					//Date fecValorEstimado = DateUtil.stringToDate("01/01/0001");
					//DatoRectificacionBean datoRec2 = new DatoRectificacionBean(fecValorEstimado, null);
					//datoRec2.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);
					//DatoRectificacionBean datoRec3 = new DatoRectificacionBean(BigDecimal.ZERO, null);
					//datoRec3.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);
					DatoRectificacionBean datoRec4 = new DatoRectificacionBean(BigDecimal.ZERO, null);
					datoRec4.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);

					if (!CollectionUtils.isEmpty(declaraOld.getListDAVs())) {
						for (DAV dav : declaraOld.getListDAVs()) {				
							for (DatoFactura factura : dav.getListFacturas()) {
								for (DatoItem item : factura.getListItems()) {
									//datos = new HashMap<String, DatoRectificacionBean>();
									DatoMontoProv montoItem = item.getMontoProv();
									//clave = obtenerClave(codTabla, montoItem);	
									//agregarCambioAtributo(datoRec2, datos, "FEC_VALESTIMA", null, null);
									//agregarCambioAtributo(datoRec3, datos, "MTO_MONTO", null, null);
									//agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);

									datos = new HashMap<String, DatoRectificacionBean>();
									claveFobUnit = obtenerClave(codTablaFobUnit, montoItem);
									agregarCambioAtributo(datoRec4, datos, "MTO_FOBUNITARIO", null, null);
									agregarCambioRegistro(codTablaFobUnit, claveFobUnit, datos, Constants.IND_REGISTRO_RECTIFICADO);
								}
							}
						}
					}

					// --> Actualiza "Valor Estimado" Series Formato A - Valor por defecto
					//			codTabla = ConstantesDataCatalogo.TABLA_DET_DECLARA;
					//			DatoRectificacionBean datoRec5 = new DatoRectificacionBean(BigDecimal.ZERO, null);
					//			datoRec5.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);
					//			
					//			if (!CollectionUtils.isEmpty(duaActual.getListSeries())) {
					//				for (DatoSerie datoSerie : duaActual.getListSeries()) {
					//					datos = new HashMap<String, DatoRectificacionBean>();
					//					clave = obtenerClave(codTabla, datoSerie);
					//					agregarCambioAtributo(datoRec5, datos, "MTO_ESTIMADO", null, null);
					//					
					//					agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);
					//				}
					//			}
				}
				// Con canal, antes de la diligencia de despacho
				else if(tieneCanal && !declaracionDiligenciada){
					// **** EL METODO COMPARADOR YA COMPARA ESTOS CAMPOS
					/*
			//--> Se actualiza la "Fecha fin del valor provisional" con el valor por defecto, Formato A
			codTabla = ConstantesDataCatalogo.TABLA_CAB_DECLARA;
			clave = obtenerClave(codTabla, duaRecti);

			Date fecfinprovsionalRecti = SunatDateUtils.getDateFromInteger(99991231);
			DatoRectificacionBean datoRec1 = new DatoRectificacionBean(fecfinprovsionalRecti, null);
			datoRec1.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);
			agregarCambioAtributo(datoRec1, datos, "FEC_FINPROVSIONAL", "dua.fecfinprovsional", null);

			agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);

			//--> Actualiza "Valor Estimado" �tems Formato B - Valor por defecto
			codTabla = ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL;
			DatoRectificacionBean datoRec3 = new DatoRectificacionBean(BigDecimal.ZERO, null);
			datoRec3.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);
			if (!CollectionUtils.isEmpty(declaraOld.getListDAVs())) {
				for (DAV dav : declaraOld.getListDAVs()) {				
					for (DatoFactura factura : dav.getListFacturas()) {
						for (DatoItem item : factura.getListItems()) {
							datos = new HashMap<String, DatoRectificacionBean>();
							DatoMontoProv montoItem = item.getMontoProv();
							clave = obtenerClave(codTabla, montoItem);	
							agregarCambioAtributo(datoRec3, datos, "MTO_MONTO", null, null);
							agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);
						}
					}
				}
			}

			// --> Actualiza "Valor Estimado" Series Formato A - Valor por defecto
			codTabla = ConstantesDataCatalogo.TABLA_DET_DECLARA;
			DatoRectificacionBean datoRec5 = new DatoRectificacionBean(BigDecimal.ZERO, null);
			datoRec5.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);
			if (!CollectionUtils.isEmpty(duaActual.getListSeries())) {
				for (DatoSerie datoSerie : duaActual.getListSeries()) {
					datos = new HashMap<String, DatoRectificacionBean>();
					clave = obtenerClave(codTabla, datoSerie);
					agregarCambioAtributo(datoRec5, datos, "MTO_ESTIMADO", null, null);
					agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);
				}
			}*/
				}

				//Inicio rin10 bug 21795
				if(variablesIngreso.containsKey("cambiarFechaFinValorProvisional")){
					actualizarFechaFinValorProvisional(variablesIngreso.get("cambiarFechaFinValorProvisional"));
				}
				//Fin rin10


	}

	private void actualizarFechaFinValorProvisional(Object valorCampo) {

		if (!CollectionUtils.isEmpty(this.listaCambios)) {
			for (DetSolicitudRectificacionBean soli : this.listaCambios) {
				if(ConstantesDataCatalogo.TABLA_CAB_DECLARA.equals(soli.getCodtabla())){
					if(soli.getDatosRectificados().containsKey("FEC_FINPROVSIONAL")){
						DatoRectificacionBean columnaRect = soli.getDatosRectificados().get("FEC_FINPROVSIONAL");
						columnaRect.setDatoNuevo(valorCampo);	
					}
				}
				if(ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL.equals(soli.getCodtabla())){
					if(soli.getDatosRectificados().containsKey("FEC_VALESTIMA")){
						DatoRectificacionBean columnaRect = soli.getDatosRectificados().get("FEC_VALESTIMA");
						columnaRect.setDatoNuevo(valorCampo);	
					}
				}

			}
		}
	}

	/* Fin RIN10 3007 erodriguezb*/

	//PAS20191U220200019 - mtorralba 20190426
	private void completarDatosEmpresaTransporte(CatalogoAyudaService catalogoAyudaService, Declaracion declaracion ) {
		/*
		Via     Transporte
		3       15
		4       11
		8       12
		1       12
		*/

		String codTipoParticipante = obtenerTipoParticipante(declaracion);
		Map<String,Object> mapaParticipante = new HashMap<String,Object>();
		mapaParticipante.put("numeroCorrelativo", declaracion.getDua().getNumcorredoc());
		mapaParticipante.put("codTipoParticipante", codTipoParticipante);
		ParticipanteService  participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
		List<Participante> listaParticipantes = participanteService.obtenerParticipanteByParameterMap(mapaParticipante);

		if( listaParticipantes!= null && listaParticipantes.size()>0) {
			Participante empresaTransporte = listaParticipantes.get(0);
			if( declaracion.getDua().getManifiesto().getEmpTransporte() == null ) {
				declaracion.getDua().getManifiesto().setEmpTransporte(new Participante());
				declaracion.getDua().getManifiesto().getEmpTransporte().setNumeroDocumentoIdentidad(empresaTransporte.getNumeroDocumentoIdentidad());
				declaracion.getDua().getManifiesto().getEmpTransporte().getTipoDocumentoIdentidad().setCodDatacat(empresaTransporte.getTipoDocumentoIdentidad().getCodDatacat());
			}
			declaracion.getDua().getManifiesto().getEmpTransporte().setCiudad(empresaTransporte.getCiudad());
			declaracion.getDua().getManifiesto().getEmpTransporte().setDireccion(empresaTransporte.getDireccion());
			declaracion.getDua().getManifiesto().getEmpTransporte().setNombreRazonSocial(empresaTransporte.getNombreRazonSocial());
			declaracion.getDua().getManifiesto().getEmpTransporte().getPais().setCodDatacat(empresaTransporte.getPais().getCodDatacat());
			declaracion.getDua().getManifiesto().getEmpTransporte().setDireccion(empresaTransporte.getDireccion());
			declaracion.getDua().getManifiesto().getEmpTransporte().getTipoParticipante().setCodDatacat(codTipoParticipante);
		}
		return;
	}


	private String obtenerTipoParticipante(Declaracion declaracion) {

		String codTipoParticipante = ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
		//Obtenemos el tipo de participante dependiendo de la v�a de transporte
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String,String>> lista = catalogoAyudaService.getListaElementosAsoc("457", "C", declaracion.getDua().getManifiesto().getCodmodtransp(), declaracion.getDua().getFecdeclaracion());
		if(!CollectionUtils.isEmpty(lista)){
			codTipoParticipante = lista.get(0).get("cod_datacat");
		}
		return codTipoParticipante;
	}


	//	public ProveedorFuncionesService getFuncionesService() {
	//		return funcionesService;
	//	}
	//
	//	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
	//		this.funcionesService = funcionesService;
	//	}

	public SoporteService getSoporteService() {
		return soporteService;
	}

	public void setSoporteService(SoporteService soporteService) {
		this.soporteService = soporteService;
	}

	public SequenceDAO getSequenceDAO() {
		return sequenceDAO;
	}

	public void setSequenceDAO(SequenceDAO sequenceDAO) {
		this.sequenceDAO = sequenceDAO;
	}	

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}	

}