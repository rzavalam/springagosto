package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilPrenda;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.NumberUtil;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;


/**
 * 
 * @author lalberti
 * 
 */
public class ValidadorTextilPrenda2 extends ValidadorTextilAbstract
{
	//amancilla
	private static final String CODIGO_PARA_CONJUNTO    = "CJN";
	private static final String CAPITULO_61             = "61";
	private static final String CAPITULO_63             = "63"; //adicionado por PAS20155E220000508
	private static final String TEJIDO_PUNTO            = "PTO";
	private static final String TEJIDO_BUCLE            = "TCB";
	private static final String SP_6302                 = "6302600000";
	private static final String SP_94_04                = "9404900000";
	private static final String PN_6212                 = "6212";
	private static final String PN_6301                 = "6301";
	private static final String PN_6302                 = "6302";
	private static final String FORMAT_6302_10_39       = "6302(1|2|3){1}[0-9]{1}";
	private static final String ROP_CAMA_CONT_CATALOG   = "426";
	private static final String CATALOGO_SUBGR_ROPA_SUP = "556";
	private static final String CATALOGO_SUBGR_ROPA_INF = "584";
	private static final String CATALOGO_SUBGR_OTRAS    = "557";

	private static final String PATRON_NUMERO = "[\\d]{1,4}?";//adicionado por 137 MIN
	private static final String PATRON_OZ = "([\\d]{1,4}(OZ))?";
	private static final String SP_620310				  = "6203421010";
	private static final String SP_620320				  = "6203421020";
	private static final String CATALOGO_SPN_EXCEPCIONADAS_GRAMAJE = "557";//PAS20175E220200069

	private static List<String> unComSet                = new ArrayList<String>(Arrays.asList("U", "2U","12U"));
	private static String       codErrorUnidadComercial = "31303";

	//private DatoItem item;

	public ValidadorTextilPrenda2()
	{
		super();
		/*
        unComSet.add("U");
        unComSet.add("2U");
        unComSet.add("12U");
        ValidadorTextilAbstract.getErrors().put("codUnComErr", "31303");
		 */
	}

	@Override
	public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
	{
		List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);
		// lstErrores.addAll(validarEstructura(objeto));
		if (CollectionUtils.isEmpty(lstErrores))
		{
			DatoItem item = obtenerItem(objeto, dua);

			lstErrores.addAll(validarUnidadComercial(objeto, item, unComSet,codErrorUnidadComercial));
			lstErrores.addAll(this.validarFOBVsPesoObs(objeto, dua));
			lstErrores.addAll(validarTipoTela(objeto, item));
			lstErrores.addAll(validarGramaje(objeto,item));
			lstErrores.addAll(validarPesoUnitario(objeto));
			lstErrores.addAll(validarConstruccionSuperior(objeto, item));
			lstErrores.addAll(validarConstruccionInferior(objeto,item));
			lstErrores.addAll(validarConstruccionOtras(objeto,item));
			lstErrores.addAll(validarPresentacionesRopaCamaSegunTamano(objeto,item));
			lstErrores.addAll(validarPresentacionRopaCamaSegunContenido(objeto,item));
			lstErrores.addAll(validarNumeroPiezasDelConjunto(objeto));
			lstErrores.addAll(validarNumeroPiezasParteInferior(objeto));
			lstErrores.addAll(validarNumeroPiezasParteSuperior(objeto));
			lstErrores.addAll(validarSumaPorcenComp(objeto));
		}

		return lstErrores;
	}

	public List<ErrorDescrMinima> validarTipoTela(ModelAbstract object,
			DatoItem item){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		TextilPrenda prenda = (TextilPrenda) object;
		String datoAValidar = prenda.getTipoTela().getValtipdescri();
		String subpartida   = item.getNumpartnandi().toString();
		String capitulo     = subpartida.substring(0, 2);
		String partida62    = subpartida.substring(0, 4);

		//    if (SunatStringUtils.isEqualTo(capitulo, CAPITULO_61) 
		//        SunatStringUtils.isEqualTo(partida62, PN_6212))
		//        && !SunatStringUtils.isEqualTo(datoAValidar, TEJIDO_PUNTO)) {    	
		//      lst.add(obtenerError("31309", prenda.getTipoTela())); //se retira  por PAS20155E220000508   
		if (!(SunatStringUtils.isEqualTo(capitulo, CAPITULO_61) ||
				SunatStringUtils.isEqualTo(partida62, PN_6212)    ||
				SunatStringUtils.isEqualTo(capitulo, CAPITULO_63) ||
				SunatStringUtils.isEqualTo(subpartida, SP_94_04)     ) //se adiciona 63 y 9404  por PAS20155E220000508   
				&& SunatStringUtils.isEqualTo(datoAValidar, TEJIDO_PUNTO)) {
			lst.add(obtenerError("31310", prenda.getTipoTela()));
		}
		if (SunatStringUtils.isEqualTo(subpartida, SP_6302)
				&& !SunatStringUtils.isEqualTo(datoAValidar, TEJIDO_BUCLE)) {
			lst.add(obtenerError("31311", prenda.getTipoTela()));
		} else if (!SunatStringUtils.isEqualTo(subpartida, SP_6302)
				&& SunatStringUtils.isEqualTo(datoAValidar, TEJIDO_BUCLE)) {
			lst.add(obtenerError("31312", prenda.getTipoTela()));
		}
		return lst;
	}

	public List<ErrorDescrMinima> validarCompoConfeccion1erComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCompoConfeccionPorcen1erComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCompoConfeccion2doComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCompoConfeccionPorcen2doComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarGradoElaboracion(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarPrimerAcabado(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarSegundoAcabado(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarGramaje(ModelAbstract object, DatoItem item){
		CatalogoAyudaService catalogoAyudaService =  (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		TextilPrenda prenda        = (TextilPrenda) object;
		String datoAValidar        = prenda.getGramaje().getValtipdescri();


		String partida             = item.getNumpartnandi().toString().substring(0, 4);
		Boolean esObligatorio      = (PN_6301.equals(partida) || PN_6302.equals(partida))?true:false;

		if(esObligatorio && catalogoAyudaService.getDataCatalogo(CATALOGO_SPN_EXCEPCIONADAS_GRAMAJE, item.getNumpartnandi().toString(),null)!=null ){//PAS20175E220200069
			esObligatorio = false;
		}

		if( SunatStringUtils.isEmpty(datoAValidar) && esObligatorio){
			lst.add(obtenerError("31331", prenda.getGramaje()));
		}

		//adicionado por 137 MIN
		if(!SunatStringUtils.isEmpty(datoAValidar) && esObligatorio){
			if(!cumpleExpresionRegular(datoAValidar, PATRON_NUMERO)){
				lst.add(obtenerError("31322", prenda.getGramaje()));
			} 
		}
		if(!SunatStringUtils.isEmpty(datoAValidar) && (SP_620310.equals( item.getNumpartnandi().toString()) || SP_620320.equals( item.getNumpartnandi().toString()))){
			if(!cumpleExpresionRegular(datoAValidar, PATRON_OZ)){
				lst.add(obtenerError("33014", prenda.getGramaje()));
			}
		}

		return lst;
	}

	public List<ErrorDescrMinima> validarPesoUnitario(ModelAbstract object){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		TextilPrenda prenda        = (TextilPrenda) object;
		String datoAValidar        = prenda.getPesoUnitario().getValtipdescri();


		if(!SunatStringUtils.isEmpty(datoAValidar)){
			/*  try{*/
			//int pesoUnitario       = Integer.parseInt(datoAValidar);
			//amancilla segun RIN puede enviar decimales el F2 de GSN estaba mal para variar

			BigDecimal pesoUnitario = SunatNumberUtils.toBigDecimal(datoAValidar);

			if(pesoUnitario.compareTo(BigDecimal.ZERO)<=0){
				lst.add(obtenerError("31333", prenda.getPesoUnitario()));
			}
			/*}catch(NumberFormatException ex){
        lst.add(obtenerError("31333", prenda.getPesoUnitario()));
      }*/
		}else{
			lst.add(obtenerError("31333", prenda.getPesoUnitario()));
		}
		return lst;
	}

	//este campo ya no se transmite PASE137
	public List<ErrorDescrMinima> validarPresentacionRopaCamaSegunContenido(ModelAbstract object, DatoItem item){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		/* TextilPrenda prenda        = (TextilPrenda) object;
    String partida             = item.getNumpartnandi().toString().substring(0, 6);
    if(cumpleExpresionRegular(partida, FORMAT_6302_10_39)){
      if(SunatStringUtils.isEmpty(prenda.getPresentacionRopaCamaSegunContenido().getValtipdescri())){
        lst.add(obtenerError("31378", prenda.getPresentacionRopaCamaSegunContenido()));
      }
    }*/
		return lst;
	}

	public List<ErrorDescrMinima> validarMedidasYPresentaciones(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCompoConfeccion3erComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCompoConfeccionPorcen3erComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCompoConfeccion4toComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCompoConfeccionPorcen4toComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarOtrasConfeccionesRellenoAlmohada(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarAplicacionesPrendasVestir(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarComplementoPrendasVestir(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarPresentacionesRopaCamaSegunTamano(ModelAbstract object,DatoItem item){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		TextilPrenda prenda        = (TextilPrenda) object;
		String partida = item.getNumpartnandi().toString().substring(0, 6);
		if(cumpleExpresionRegular(partida, FORMAT_6302_10_39)){
			if(SunatStringUtils.isEmpty(prenda.getPresentacionesRopaCamaSegunTamano().getValtipdescri())){
				lst.add(obtenerError("31375", prenda.getPresentacionesRopaCamaSegunTamano()));
			}
		}
		return lst;
	}

	private List<ErrorDescrMinima> validarNroPieza(String nombre, String dato,
			DatoDescrMinima object){

		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		Boolean esObligatorio = SunatStringUtils.isEqualTo(nombre, CODIGO_PARA_CONJUNTO)?true:false;
		if (esObligatorio &&
				SunatStringUtils.isEmptyTrim(dato)){
			lst.add(obtenerError("31840", object));
		}
		return lst;
	}

	/*amancilla Bug Bug 20731 */
	private List<ErrorDescrMinima> validarNroPiezaDelConjunto(String nombre, String dato,
			DatoDescrMinima object){

		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		Boolean esObligatorio = SunatStringUtils.isEqualTo(nombre, CODIGO_PARA_CONJUNTO)?true:false;
		if (esObligatorio){
			if(SunatStringUtils.isEmptyTrim(dato)){
				lst.add(obtenerError("31840", object));
			}
		}else{
			//no es CJN pero aun asi envia el dato rechazamos
			if(!SunatStringUtils.isEmptyTrim(dato)){
				lst.add(obtenerError("31856", object));
			}
		}

		return lst;
	}


	public List<ErrorDescrMinima> validarNumeroPiezasDelConjunto(ModelAbstract object){
		TextilPrenda prenda = (TextilPrenda) object;
		return validarNroPiezaDelConjunto(prenda.getNombreComercial().getValtipdescri(),
				prenda.getNumeroPiezasDelConjunto().getValtipdescri(), prenda.getNumeroPiezasDelConjunto());
	}

	public List<ErrorDescrMinima> validarNumeroPiezasParteSuperior(ModelAbstract object){
		TextilPrenda prenda = (TextilPrenda) object;
		return validarNroPieza(prenda.getNombreComercial().getValtipdescri(),
				prenda.getNumeroPiezasParteSuperior().getValtipdescri(), prenda.getNumeroPiezasParteSuperior());
	}

	public List<ErrorDescrMinima> validarNumeroPiezasParteInferior(ModelAbstract object){
		TextilPrenda prenda = (TextilPrenda) object;
		return validarNroPieza(prenda.getNombreComercial().getValtipdescri(),
				prenda.getNumeroPiezasParteInferior().getValtipdescri(), prenda.getNumeroPiezasParteInferior());
	}

	public List<ErrorDescrMinima> validarPrimeraPiezaSuperior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarSegundaPiezaSuperior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarTerceraPiezaSuperior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCuartaPiezaSuperior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarQuintaPiezaSuperior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarPrimeraPiezaInferior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarSegundaPiezaInferior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarTerceraPiezaInferior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarCuartaPiezaInferior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarQuintaPiezaInferior(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> ValidarSumaPorcenComp(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarConstruccionSuperior(ModelAbstract object,
			DatoItem item){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		TextilPrenda prenda      = (TextilPrenda) object;
		String partida           = item.getNumpartnandi().toString();
		//rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
		Map<String,Object> variablesIngreso = object.getMapCatalogos();
		if(estaEnSubGrupoCatalogo(CATALOGO_SUBGR_ROPA_SUP, partida, variablesIngreso)){
			//Validaci�n tipo de manga.
			String[] args;
			if( SunatStringUtils.isEmpty(prenda
					.getTipoMangaSuperior().getValtipdescri())){
				args = new String[]{prenda
						.getTipoMangaSuperior().getCodtipdescr(),partida};
				lst.add(obtenerError("31335", prenda.getTipoMangaSuperior(),args));
			}
			//Validaci�n tipo de cuello.
			if( SunatStringUtils.isEmpty(prenda.getTipoCuelloSuperior().getValtipdescri())){
				args = new String[]{prenda
						.getTipoCuelloSuperior().getCodtipdescr(),partida};
				lst.add(obtenerError("31335", prenda.getTipoCuelloSuperior(),args));
			}
			//Validaci�n parte delantera superior.
			if( SunatStringUtils.isEmpty(prenda.getParteDelanteraSuperior()
					.getValtipdescri())){
				args = new String[]{prenda.getParteDelanteraSuperior()
						.getCodtipdescr(),partida};
				lst.add(obtenerError("31335", prenda.getParteDelanteraSuperior(),args));
			}
			//Validaci�n Parte Interna
			if(SunatStringUtils.isEmpty(prenda.getParteInternaSuperior().getValtipdescri())){
				args = new String[]{prenda.getParteInternaSuperior().getCodtipdescr(),partida};
				lst.add(obtenerError("31335", prenda.getParteInternaSuperior(),args));
			}
			//Validacion largo de la prenda parte superior.
			if(SunatStringUtils.isEmpty(prenda.getLargoPrendaSuperior().getValtipdescri())){
				args = new String[]{prenda
						.getLargoPrendaSuperior().getCodtipdescr(),partida};
				lst.add(obtenerError("31335", prenda.getLargoPrendaSuperior(),args));
			}
			//Validaci�n bolsillos parte superior
			/*if(SunatStringUtils.isEmpty(prenda.getBolsillosSuperior().getValtipdescri())){
        args = new String[]{prenda
                            .getBolsillosSuperior().getCodtipdescr(),partida};
        lst.add(obtenerError("31335", prenda.getBolsillosSuperior(),args));
      }
      //Validaci�n cintura superior
      if(SunatStringUtils.isEmpty(prenda.getCinturaSuperior().getValtipdescri())){
        args = new String[]{prenda
                            .getCinturaSuperior().getCodtipdescr(),partida};
        lst.add(obtenerError("31335", prenda.getCinturaSuperior(),args));
      }*///ya no se transmite las casillas bolsillo y cintura
		}
		return lst;
	}

	public List<ErrorDescrMinima> validarConstruccionInferior(ModelAbstract object, DatoItem item){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
		TextilPrenda prenda  = (TextilPrenda) object;
		String partida       = item.getNumpartnandi().toString();
		//rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
		Map<String,Object> variablesIngreso = object.getMapCatalogos();
		if(estaEnSubGrupoCatalogo(CATALOGO_SUBGR_ROPA_INF, partida, variablesIngreso)){
			String[] args;
			//Validacion largo inferior.
			if(SunatStringUtils.isEmpty(prenda.getLargoPrendaInferior().getValtipdescri())){
				args = new String[]{prenda
						.getLargoPrendaInferior().getCodtipdescr(),partida};
				lst.add(obtenerError("31335",prenda.getLargoPrendaInferior(),args));
			}
			//Validar pie de prenda
			/*if(SunatStringUtils.isEmpty(prenda.getPiePrendaInferior().getValtipdescri())){
        args = new String[]{prenda
                            .getPiePrendaInferior().getCodtipdescr(),partida};
        lst.add(obtenerError("31335", prenda.getPiePrendaInferior(),args));
      }
      //Validando abertura inferior
      if(SunatStringUtils.isEmpty(prenda.getAberturaPrendaInferior().getValtipdescri())){
        args = new String[]{prenda
                            .getAberturaPrendaInferior().getCodtipdescr(),partida};
        lst.add(obtenerError("31335", prenda.getAberturaPrendaInferior(),args));
      }
      //Validando Bolsillos inferiores
      if(SunatStringUtils.isEmpty(prenda.getBolsillosInferior().getValtipdescri())){
        args = new String[]{prenda
                            .getBolsillosInferior().getCodtipdescr(),partida};
        lst.add(obtenerError("31335", prenda.getBolsillosInferior(),args));
      }
      //Validando cintura inferior
      if(SunatStringUtils.isEmpty(prenda.getCinturaInferior().getValtipdescri())){
        args = new String[]{prenda
                            .getCinturaInferior().getCodtipdescr(),partida};
        lst.add(obtenerError("31335", prenda.getCinturaInferior(),args));
      }
      //Validando peto inferior
      /*if(SunatStringUtils.isEmpty(prenda.getPetoInferior().getValtipdescri())){
        args = new String[]{prenda
                            .getPetoInferior().getCodtipdescr(),partida};
        lst.add(obtenerError("31335", prenda.getPetoInferior(),args));
      }*///ya no se transmiten las casillas, excepto el largo
		}
		return lst;
	}

	public List<ErrorDescrMinima> validarConstruccionOtras(ModelAbstract object,
			DatoItem item){
		List<ErrorDescrMinima> lst   = new ArrayList<ErrorDescrMinima>();
		TextilPrenda prenda          = (TextilPrenda) object;
		String subpartida            = item.getNumpartnandi().toString();
		String partida = subpartida.substring(0, 4);
		//rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
		Map<String,Object> variablesIngreso = object.getMapCatalogos();
		if (estaEnSubGrupoCatalogo(CATALOGO_SUBGR_OTRAS, subpartida.substring(0, 4),variablesIngreso) ||
				SP_94_04.equals(subpartida)){
			String[] args;
			if(SunatStringUtils.isEmpty(prenda.getCara().getValtipdescri())){
				args = new String[]{prenda
						.getCara().getCodtipdescr(),partida};
				lst.add(obtenerError("31335", prenda.getCara(), args));
			}
			/*
      if(SunatStringUtils.isEmpty(prenda.getElastico().getValtipdescri())){
        args = new String[]{prenda
                            .getElastico().getCodtipdescr(),partida};
        lst.add(obtenerError("31335",prenda.getElastico(),args));
      }
      if(SunatStringUtils.isEmpty(prenda.getForma().getValtipdescri())){
        args = new String[]{prenda
                            .getForma().getCodtipdescr(),partida};
        lst.add(obtenerError("31335", prenda.getForma(),args));
      }*///casilla ya no se transmite
			if (SunatStringUtils.isEmpty(prenda.getUso().getValtipdescri())){
				args = new String[]{prenda
						.getUso().getCodtipdescr(),partida};
				lst.add(obtenerError("31335",prenda.getUso(),args));
			}
			if(SunatStringUtils.isEmpty(prenda.getOtrasConfeccionesRellenoAlmohada().getValtipdescri())){
				args = new String[]{prenda
						.getOtrasConfeccionesRellenoAlmohada().getCodtipdescr(),partida};
				lst.add(obtenerError("31335", prenda.getOtrasConfeccionesRellenoAlmohada(),args));
				return lst;
			}
		}

		return lst;
	}

	//ya no se transmite casilla
	public List<ErrorDescrMinima> validarPresentacionRopaCamaContenido
	(ModelAbstract object,DatoItem item){
		List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();

		/*Date fechaVigencia = object.getFechaIniVigenciaValidador();//AREY-MIN PASE137
    String partida = item.getNumpartnandi().toString().substring(0, 4);
    if(cumpleExpresionRegular(partida, FORMAT_6302_10_39)){
      TextilPrenda prenda = (TextilPrenda) object;
      String datoAValidar = prenda.getPresentacionRopaCamaSegunContenido().getCodtipdescr();
      if (SunatStringUtils.isEmpty(datoAValidar) ||
          noEstaEnCatalogo(datoAValidar, ROP_CAMA_CONT_CATALOG,fechaVigencia)){
        lst.add(obtenerError("31356", prenda.getPresentacionRopaCamaSegunContenido()));
      }
    }*/
		return lst;
	}

	public List<ErrorDescrMinima> validarAplicaciones(ModelAbstract object) {
		return new ArrayList<ErrorDescrMinima>();
	}

	public List<ErrorDescrMinima> validarComplementos(ModelAbstract object){
		return new ArrayList<ErrorDescrMinima>();
	}
	public List<ErrorDescrMinima> validarSumaPorcenComp(ModelAbstract object){
		List<ErrorDescrMinima> lst =  new ArrayList<ErrorDescrMinima>();
		TextilPrenda prenda = (TextilPrenda) object;
		Integer p1 = 0;
		Integer p2 = 0;
		Integer p3 = 0;
		Integer p4 = 0;
		try{
			p1 = !SunatStringUtils.isEmptyTrim(prenda.getCompoConfeccionPorcen1erComp().getValtipdescri())?
					Integer.parseInt(prenda.getCompoConfeccionPorcen1erComp().getValtipdescri()):0;
					p2 = prenda.getCompoConfeccionPorcen2doComp()!=null &&
							!SunatStringUtils.isEmptyTrim(prenda.getCompoConfeccionPorcen2doComp().getValtipdescri())?
									Integer.parseInt(prenda.getCompoConfeccionPorcen2doComp().getValtipdescri()) : 0;
									p3 = prenda.getCompoConfeccionPorcen3erComp() != null &&
											!SunatStringUtils.isEmptyTrim(prenda.getCompoConfeccionPorcen3erComp().getValtipdescri())?
													Integer.parseInt(prenda.getCompoConfeccionPorcen3erComp().getValtipdescri()) : 0;
													p4 = prenda.getCompoConfeccionPorcen4toComp() != null && 
															!SunatStringUtils.isEmptyTrim(prenda.getCompoConfeccionPorcen4toComp().getValtipdescri())?
																	Integer.parseInt(prenda.getCompoConfeccionPorcen4toComp().getValtipdescri()) : 0;
		}catch(NumberFormatException e){}
		if((p1 + p2 + p3 + p4) != 100){
			Integer sum = p1 + p2 + p3 + p4;
			DatoDescrMinima suma = prenda.getCompoConfeccionPorcen1erComp();
			suma.setValtipdescri(sum.toString());
			lst.add(obtenerError("31364", suma));
		}
		return lst;
	}
}
