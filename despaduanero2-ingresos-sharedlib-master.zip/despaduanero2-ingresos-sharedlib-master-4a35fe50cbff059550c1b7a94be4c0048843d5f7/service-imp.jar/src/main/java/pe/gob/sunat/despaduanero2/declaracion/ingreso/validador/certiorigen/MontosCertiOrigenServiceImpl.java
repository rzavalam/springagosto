package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.EquivMonto;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.Certifiorigen;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.Diseriesi;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.FormBCorr;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.SimplificadaFormBCorr;
import pe.gob.sunat.despaduanero.despacho.entrada.dq.model.Polizaq;
import pe.gob.sunat.despaduanero.despacho.entrada.dq.model.Seriesq;
import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.TratoPreferencialInternacionalService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.sigad.despacho.entrada.service.ConsultaFormatoBService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaCertificadoOrigenService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoConsumoService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoSimplificadaService;

/**
 * Validaciones de calculo respecto a los montos topes para importar sin certificado de origen, dependiendo del tipo de TLC
 * @author rbegazo
 *
 */
public class MontosCertiOrigenServiceImpl extends ValDuaAbstract implements MontosCertifiOrigenService {

	//private FabricaDeServicios	fabricaDeServicios;
	
	private static final String GRUPO_TLC_MONTO_CIF = "599";
	
	@ServicioAnnot(tipo="V",codServicio=3375, descServicio="Cuando no se tienen Certificado de Origen, se valida que el CIF de la serie no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3375,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valMontoCIFEnvioNoRequiereCO(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		
		//rtineo optimizacion
		listError = valMontoCIFPorSerie(serie, arrayTipoCertificado,variablesIngreso);
		//fin optimizacion
		return listError;
	}
	
	/**-
	@ServicioAnnot(tipo="V",codServicio=3376, descServicio="Cuando no se tienen Certificado de Origen, y existen varias series con la misma subpartida los valores CIF no debe ser mayor al permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3376,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valMontoCIFSubpartidaNoRequiereCO(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		Integer codConvenio = serie.getCodconvinter();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			BigDecimal mtoCifAcumulado = this.calcularMtoCifSubpartida(serie, codTipoCO);
			BigDecimal mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
				listError = catalogoHelper.getErrorMap("30716", new String[] {serie.getNumserie().toString(),serie.getNumpartnandi().toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
			}
		}
		return listError;
	}
    **/

	@ServicioAnnot(tipo="V",codServicio=3376, descServicio="Cuando no se tienen Certificado de Origen, y existen varias series con la misma subpartida los valores CIF no debe ser mayor al permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3376,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valMontoCIFSubpartidaNoRequiereCO(Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF};
		List<Map<String, String>> listError = new ArrayList<Map<String,String>>();
		List<DatoSerie> lstSeries = declaracion.getDua().getListSeries();
		List<DatoSerie> subSetSeries = new ArrayList<DatoSerie>();	
		List<String> listNumSubPartidas = new ArrayList<String>();
		//rtineo optimizacion comentado porque no se utiliza
		//List<String> serviciosTLC = new ArrayList<String>();
		//rtineo fin optimizacion
		
		//amancilla inicio PAS20165E220200126 se verifica que nunca se ejecuta este servicio dado
		// donde se setea este variable se ejecuta siempre despues
		variablesIngreso.put("indValidaTLC", true);
		//amancilla fin PAS20165E220200126

		for (DatoSerie serie:lstSeries){
			//rtineo optimizacion utilizamos el nuevo metodo
			if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)){
				continue;
			}
			//fin optimizacion
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(declaracion.getDua(), serie);
			if(CollectionUtils.isEmpty(listCertificadoOrigen))continue;
			String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();
			if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {				
				DatoSerie subSetSerie = new DatoSerie();
				String idPartConvPais = SunatStringUtils.toStringObj(serie.getNumpartnandi()).concat(serie.getCodconvinter().toString()).concat(serie.getCodpaisorige());
				//jenciso se a�ade provedor (nombre  y pais)
				Participante prov = this.getProveedorCorrespondiente(serie, declaracion);
				if(prov!=null){
					idPartConvPais = idPartConvPais.concat(prov.getNombreRazonSocial()).concat(prov.getPais().getCodDatacat());
				}
				//Llenar las series que seran evaluadas en una lista de objetos del tipo Serie, con monto CIF acumulado
				if(!SunatStringUtils.isEmptyTrim(idPartConvPais) && !listNumSubPartidas.contains(idPartConvPais)){
					listNumSubPartidas.add(idPartConvPais);
					subSetSerie.setValindcodlib(idPartConvPais);
					subSetSerie.setMtovaladuana(serie.getMtovaladuana());
					subSetSerie.setDesotros(serie.getNumserie().toString());
					subSetSerie.setCodconvinter(serie.getCodconvinter());
					subSetSerie.setNumpartnandi(serie.getNumpartnandi());
					subSetSeries.add(subSetSerie);
				} else{
					Iterator<DatoSerie> iterDatosSeries = subSetSeries.iterator(); 
					while(iterDatosSeries.hasNext()){
						subSetSerie = iterDatosSeries.next();
						if (subSetSerie.getValindcodlib().equals(idPartConvPais)){
							subSetSerie.setMtovaladuana(SunatNumberUtils.sum(subSetSerie.getMtovaladuana(),serie.getMtovaladuana()));
							subSetSerie.setDesotros(subSetSerie.getDesotros().concat(",").concat(serie.getNumserie().toString()));
							subSetSerie.setCodconvinter(serie.getCodconvinter());
							subSetSerie.setNumpartnandi(serie.getNumpartnandi());
							//iterDatosSeries.remove();
							//subSetSeries.add(subSetSerie);
							break;
						}
					}
				}
			}
		}
		if (!CollectionUtils.isEmpty(subSetSeries)){
			Iterator<DatoSerie> iterDatosSeries = subSetSeries.iterator(); 
			while(iterDatosSeries.hasNext()){
				DatoSerie subSetSerie = iterDatosSeries.next();
				BigDecimal mtoCifAcumulado = subSetSerie.getMtovaladuana();	
				//rtineo optimizacion verificamos si los atributos del grupo de tratados internacionales fueron cargados anteriormente
				BigDecimal mtoTopeCif = null;
				
				if (variablesIngreso != null) {
					Map<String, String> grupoTratadosInternacionales = (Map<String, String>) variablesIngreso.get("grupoTratadosInternacionales");
					if (grupoTratadosInternacionales == null) {
						grupoTratadosInternacionales = cargarGrupoTratadosInternacionales(variablesIngreso);
					}
					mtoTopeCif = SunatNumberUtils.toBigDecimal(grupoTratadosInternacionales.get(subSetSerie.getCodconvinter().toString()));
				}else{
					//continuzamos con metodo pesado
					mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN,
							ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
							ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, subSetSerie.getCodconvinter().toString()));
				}
				//rtineo fin optimizacion
					
				if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
//					listError = catalogoHelper.getErrorMap("30716", new String[] {subSetSerie.getDesotros(),subSetSerie.getNumpartnandi().toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30716",new String[] {subSetSerie.getDesotros(),subSetSerie.getNumpartnandi().toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()}));
				}				
			}
		}
		return listError;
	}

	

	@ServicioAnnot(tipo="V",codServicio=3377, descServicio="Cuando se tiene como CO una Declaracion de Origen, se valida que el CIF de la serie no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3377,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valMontoCIFEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//rtineo optimizacion
		listError = valMontoCIFPorSerie(serie, arrayTipoCertificado,variablesIngreso);
		//fin optimiacion
		return listError;
	}

	@ServicioAnnot(tipo="V",codServicio=3378, descServicio="Cuando se tiene como CO una Declaracion de Origen, se valida que el CIF de la serie con la misma factura no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3378,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valMontoCIFFacturaEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//rtineo optimizacion se agrega variablesIngreso
		listError = valMontoCIFPorFactura(serie, arrayTipoCertificado, true, null,false,variablesIngreso);
		return listError;
	}

	//registrar como servicio
	@ServicioAnnot(tipo="V",codServicio=3430, descServicio="Cuando se tiene como CO una Declaracion de Origen, se valida que el CIF de la serie con la misma factura y proveedor no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={0,1,1},nomAtr={"variablesIngreso","fechaReferencia","declaracion"})
	@OrquestaDespaAnnot(codServInstancia=3430,numSecEjec=210,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, String>> valMontoCIFFacturaProveedorEnvioDeclaracion( Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
//		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
//			return listError;
//		}

		DUA dua = declaracion.getDua();
		List<DatoSerie> listSeriesVerificar = new ArrayList<DatoSerie>();
		List<String> listIdComparaSerie = new ArrayList<String>();
		List<String> serviciosTLC = new ArrayList<String>();

		Date fecha_default   = SunatDateUtils.getDefaultDate();//RN07 TPI814
		for(DatoSerie serie: dua.getListSeries()){
			if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, serviciosTLC)){
				continue;
			}
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
			if(CollectionUtils.isEmpty(listCertificadoOrigen))continue;
			String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();
			if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {				
				
					DatoFacturaref serFacturaRef = new DatoFacturaref();
					serFacturaRef = this.getDatoFacturaRef(dua, serie);
					String serNumFactura = serFacturaRef.getNumfactura()!=null?serFacturaRef.getNumfactura():" ";//RN07 TPI814;
					Date serFechaFactura = serFacturaRef.getFecfactura()!=null?serFacturaRef.getFecfactura():fecha_default;//RN07 TPI814;
					String nombreProveedor = "";
					String paisProveedor = "";declaracion.getListDAVs();
					Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion);
					if(proveedor==null) continue;//si no tiene proveedor no entra a la comparacion
					else{
						nombreProveedor = proveedor.getNombreRazonSocial().trim();
						nombreProveedor = proveedor.getPais().getCodDatacat();
					}
					String codTPI =  serie.getCodconvinter().toString();
					String idComparaSerie = serNumFactura.concat(SunatDateUtils.getIntegerFromDate(serFechaFactura).toString()).concat(nombreProveedor).concat(paisProveedor).concat(codTPI);
					if(!listIdComparaSerie.contains(idComparaSerie)){
						listIdComparaSerie.add(idComparaSerie);
						listSeriesVerificar.add(serie);
					}				
			}
			
		}
		
		if(CollectionUtils.isNotEmpty(listSeriesVerificar)){
			for(DatoSerie serie: listSeriesVerificar){
				listError.add(this.valMontoCIFPorFactura(serie, arrayTipoCertificado, false, declaracion, true));
			}
		}	
		
		//listError = valMontoCIFPorFactura(serie, arrayTipoCertificado, false, declaracion, true);
		return listError;
	}


	@Deprecated
	@ServicioAnnot(tipo="V",codServicio=3379, descServicio="Cuando no se requiere un CO, se valida que el valor CIF de la serie con la misma factura y proveedor  no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={0,1,1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3379,numSecEjec=211,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public Map<String, String> valMontoCIFFacturaNoRequiereCO(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracion) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
				
		//listError = this.valMontoCIFPorFacturaProveedorConSinTPI(serie, arrayTipoCertificado, declaracion);
		return listError;
	}

	@ServicioAnnot(tipo="V",codServicio=3433, descServicio="Cuando no se requiere un CO, se valida que el valor CIF de la serie con la misma factura y proveedor  no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={0,1},nomAtr={"declaracion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3433,numSecEjec=211,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public List<Map<String, String>> valMontoCIFFacturaProveedorNoRequiereCO( Declaracion declaracion,  Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
//		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
//			return listError;
//		}
		//listError = valMontoCIFPorFactura(serie, arrayTipoCertificado, false, null, false);
		DUA dua = declaracion.getDua();
		List<DatoSerie> listSeriesVerificar = new ArrayList<DatoSerie>();
		List<String> listIdComparaSerie = new ArrayList<String>();
		//se setea el valor indValidaTLC
//		List<String> serviciosTLC = new ArrayList<String>();
		Map<String, Object> variablesIngreso = new HashMap<String, Object>();
	    variablesIngreso.put("indValidaTLC", true);
		Date fecha_default   = SunatDateUtils.getDefaultDate();//RN07 TPI814
		for(DatoSerie serie: dua.getListSeries()){
			//se cambia de invocacion del metodo para validar las vigencias de validacion rin peru -corea
			//if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, serviciosTLC)){
			if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)){
				continue;
			}
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
			if(CollectionUtils.isEmpty(listCertificadoOrigen))continue;
			String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();
			if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {				
				
					DatoFacturaref serFacturaRef = new DatoFacturaref();
					serFacturaRef = this.getDatoFacturaRef(dua, serie);
					String serNumFactura = serFacturaRef.getNumfactura()!=null?serFacturaRef.getNumfactura():" ";//RN07 TPI814
					Date serFechaFactura = serFacturaRef.getFecfactura()!=null?serFacturaRef.getFecfactura():fecha_default;//RIN07 TPI814
					String nombreProveedor = "";
					String paisProveedor = "";declaracion.getListDAVs();
					Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion);
					if(proveedor==null) continue;//si no tiene proveedor no entra a la comparacion
					else{
						nombreProveedor = proveedor.getNombreRazonSocial().trim();
						paisProveedor = proveedor.getPais().getCodDatacat();//PAS20155E220200192 estaba mal el nombre de la variable
					}
					String codTPI =  serie.getCodconvinter().toString();
					String idComparaSerie = serNumFactura.concat(SunatDateUtils.getIntegerFromDate(serFechaFactura).toString()).concat(nombreProveedor).concat(paisProveedor).concat(codTPI);
					if(!listIdComparaSerie.contains(idComparaSerie)){
						listIdComparaSerie.add(idComparaSerie);
						listSeriesVerificar.add(serie);
					}				
			}
			
		}
		
		if(CollectionUtils.isNotEmpty(listSeriesVerificar)){
			// PAS20155E220100048
			// -- Consultar en Catalogo si la verificacion de suma debe considerar TPI
			for(DatoSerie serie: listSeriesVerificar){
				String codTPI = serie.getCodconvinter().toString();
				DataGrupoCat dato = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataGrupoCat(GRUPO_TLC_MONTO_CIF, codTPI);
				if (dato != null){
					listError.add(this.valMontoCIFPorFacturaProveedorConTPI(serie, arrayTipoCertificado, declaracion, codTPI));
				} else {
					listError.add(this.valMontoCIFPorFacturaProveedorConSinTPI(serie, arrayTipoCertificado, declaracion));
				}
			}
		}		
				
		//listError = this.valMontoCIFPorFacturaProveedorConSinTPI(serieIgual, arrayTipoCertificado, declaracion);
		return listError;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3424, descServicio="para Declaracion de origen, se valida que el valor CIF de todas las series en la misma DUA con mismo proveedor y TPI no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={0,1,1,1},nomAtr={"serie","variablesIngreso","fechaReferencia","declaracion"})
	@OrquestaDespaAnnot(codServInstancia=3424,numSecEjec=212,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public Map<String, String> valMontoCIFProveedorConSinCO(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracion) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		Integer codConvenio = serie.getCodconvinter();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
						
			Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion);
			if(proveedor != null){
				String nombreProveedor =  "";
				String paisProveedor = "";
				nombreProveedor= proveedor.getNombreRazonSocial();
				paisProveedor = proveedor.getPais().getCodDatacat();
							
				BigDecimal mtoCifAcumulado = this.calcularMontoCIFProveedorConSinCO(serie, declaracion, nombreProveedor, paisProveedor, codTipoCO);
				BigDecimal mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
				if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30912",new String[] {serie.getNumserie().toString(),nombreProveedor,mtoTopeCif.toString(),  mtoCifAcumulado.toString()});
				}
			}
			
		}
		return listError;
	}
	
	private BigDecimal calcularMontoCIFProveedorConSinCO(DatoSerie serie, Declaracion declaracion, String nombreProveedor, String paisProveedor, String codTipoCO){
		BigDecimal mtoCifAcumulado = BigDecimal.ZERO;
		DUA dua = (DUA) serie.getPadre();
		Integer codConvenio = serie.getCodconvinter();
		int contador = 0;
		for(DatoSerie serieRef: dua.getListSeries()){
			Participante proveedorRef = this.getProveedorCorrespondiente(serieRef, declaracion);
			String nombreProveedorRef= proveedorRef.getNombreRazonSocial();
			String paisProveedorRef = proveedorRef.getPais().getCodDatacat();
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serieRef);
			String codTipoCORef = CollectionUtils.isEmpty(listCertificadoOrigen)? null : listCertificadoOrigen.get(0).getCodtipoCO();		
			Integer codConvenioRef = serieRef.getCodconvinter();
			if(nombreProveedor.equals(nombreProveedorRef) && paisProveedor.equals(paisProveedorRef) && codConvenio.equals(codConvenioRef) && (codTipoCO.equals(codTipoCORef) || codTipoCORef == null ||codTipoCORef.trim().isEmpty())){
				mtoCifAcumulado = SunatNumberUtils.sum(mtoCifAcumulado, serieRef.getMtovaladuana());
				contador ++;
			}
		}
		// Si solo existe una coincidencia no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual
		if (SunatNumberUtils.isLessOrEqualsThanParam(contador,1)) mtoCifAcumulado = BigDecimal.ZERO;
		return mtoCifAcumulado;
	}


	@ServicioAnnot(tipo="V",codServicio=3383, descServicio="Cuando el CO corresponda a una Declaracion de origen, se valida que el valor de factura en USD no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3383,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valMontoUSDFacturaEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
	if(!CollectionUtils.isEmpty(listCertificadoOrigen))	{
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			BigDecimal mtofobmon = listCertificadoOrigen.get(0).getMtofobmon();		
			Integer codConvenio = serie.getCodconvinter();
			if (SunatNumberUtils.isGreaterThanZero(mtofobmon)) {
				DatoOtroDocSoporte docSoporte = getDocSoportePorTipo (dua, serie, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_DOC_COMERCIAL);
				//Si no existe documento comercial el error se controla por el servicio correspondiente
				if (docSoporte != null && docSoporte.getFecdocasoc()!= null) {
					String codmoneda = listCertificadoOrigen.get(0).getCodmoneda();
					
					if (codmoneda != null) {
						Date fechaDocComercial = docSoporte.getFecdocasoc();
						//rtineo optimizacion, se agrega variableIngreso
							BigDecimal mtoTopeFactura = this.obtenerMontoTopeFactura(codConvenio,ConstantesAtributo.MTO_FACTURA_USD_CERTIORIGEN,variablesIngreso);
							BigDecimal mtoFactorConver = this.obtenerFactorConversionOtraMoneda(codmoneda,ConstantesDataCatalogo.MONEDA_DOLAR,fechaDocComercial,variablesIngreso);
							//fin optimizacion
							BigDecimal mtoCalculado = SunatNumberUtils.multiply(mtofobmon, mtoFactorConver);
							if (SunatNumberUtils.isGreaterThanParam(mtoCalculado,mtoTopeFactura)) {
								listError = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30723", new String[] {
										serie.getNumserie().toString(),mtoTopeFactura.toString(),mtoCalculado.toString() });
							}
						}

					}
				}			
			}

		}	
		return listError;
	}

	@ServicioAnnot(tipo="V",codServicio=3384, descServicio="Cuando el CO corresponda a una Declaracion de origen, se valida que el valor de factura tanto en EUR como en USD no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3384,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valMontoUSDEURFacturaEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			BigDecimal mtofobmon = listCertificadoOrigen.get(0).getMtofobmon();		
			Integer codConvenio = serie.getCodconvinter();
			//amancilla String numautoexp = listCertificadoOrigen.get(0).getNumautoexp();
			String numautoexp = listCertificadoOrigen.get(0).getNumautoexp()!=null?listCertificadoOrigen.get(0).getNumautoexp().trim():"";
			if (SunatStringUtils.isEmpty(numautoexp)) {
				if (SunatNumberUtils.isGreaterThanZero(mtofobmon)) {
					DatoOtroDocSoporte docSoporte = getDocSoportePorTipo (dua, serie, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_DOC_COMERCIAL);
					if (docSoporte != null && docSoporte.getFecdocasoc()!= null) {
						String codmoneda = listCertificadoOrigen.get(0).getCodmoneda();
						Date fechaDocComercial = docSoporte.getFecdocasoc();
						
						if (SunatStringUtils.include(codmoneda,new String[]{ConstantesDataCatalogo.MONEDA_DOLAR})){
							//rtineo optimizacion
							BigDecimal mtoTopeFactura  = this.obtenerMontoTopeFactura(codConvenio, ConstantesAtributo.MTO_FACTURA_USD_CERTIORIGEN,variablesIngreso);
							//fin optimizacion
							
							if(SunatNumberUtils.isGreaterThanParam(mtofobmon, mtoTopeFactura)){
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30723",new String[] {serie.getNumserie().toString(), mtoTopeFactura.toString(), mtofobmon.toString()}));
							}
						}else if (SunatStringUtils.include(codmoneda,new String[]{ConstantesDataCatalogo.MONEDA_EUROS})){
							//rtineo optimizacion
							BigDecimal mtoTopeFactura  = this.obtenerMontoTopeFactura(codConvenio, ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN,variablesIngreso);
							//fin optimizacion
							
							if(SunatNumberUtils.isGreaterThanParam(mtofobmon, mtoTopeFactura)){
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30724",new String[] {serie.getNumserie().toString(), mtoTopeFactura.toString(), mtofobmon.toString() }));
						}
						}else{//otro tipo de moneda
							//rtineo optimizacion
							BigDecimal mtoTopeFacturaUSD  = this.obtenerMontoTopeFactura(codConvenio, ConstantesAtributo.MTO_FACTURA_USD_CERTIORIGEN,variablesIngreso);
							//fin optimizacion
							
							BigDecimal mtoFactorConverUSD = BigDecimal.ONE;
							//rtineo optimizacion
							mtoFactorConverUSD = this.obtenerFactorConversionOtraMoneda(codmoneda, ConstantesDataCatalogo.MONEDA_DOLAR, fechaDocComercial,variablesIngreso);
							//fin optimizacion
							
							BigDecimal mtoCalculadoUSD = SunatNumberUtils.multiply(mtofobmon, mtoFactorConverUSD);
							//rtineo optimizacion
							BigDecimal mtoTopeFacturaEUR  = this.obtenerMontoTopeFactura(codConvenio, ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN,variablesIngreso);
							//fin optimizacion
							
							BigDecimal mtoFactorConverEUR = BigDecimal.ONE;
							//rtineo optimizacion
							mtoFactorConverEUR = this.obtenerFactorConversionOtraMoneda(codmoneda, ConstantesDataCatalogo.MONEDA_EUROS, fechaDocComercial,variablesIngreso);
							//fin optimizacion
							
							BigDecimal mtoCalculadoEUR = SunatNumberUtils.multiply(mtofobmon,mtoFactorConverEUR);
							
							if(SunatNumberUtils.isGreaterThanParam(mtoCalculadoUSD, mtoTopeFacturaUSD) || SunatNumberUtils.isGreaterThanParam(mtoCalculadoEUR, mtoTopeFacturaEUR)){
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30906",new String[] {serie.getNumserie().toString(), mtoCalculadoUSD.toString(), mtoCalculadoEUR.toString() }));
							}
							
						}
//						
//						//Comparamos los Dolares con respecto a Euros
//						if (SunatStringUtils.include(codmoneda,new String[]{ConstantesDataCatalogo.MONEDA_DOLAR,ConstantesDataCatalogo.MONEDA_EUROS}) || 
//								!SunatStringUtils.include(codmoneda, new String[]{ConstantesDataCatalogo.MONEDA_DOLAR,ConstantesDataCatalogo.MONEDA_EUROS})){
//							BigDecimal mtoTopeFacturaEUR  = this.obtenerMontoTopeFactura(codConvenio, ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN);
//							BigDecimal mtoFactorConverUSD = BigDecimal.ONE;
//							//if (!codmoneda.equals(ConstantesDataCatalogo.MONEDA_DOLAR)){
//								mtoFactorConverUSD = this.obtenerFactorConversionOtraMoneda(codmoneda, ConstantesDataCatalogo.MONEDA_EUROS, fechaDocComercial);
//							//}						
//							BigDecimal mtoCalculadoUSD = SunatNumberUtils.multiply(mtofobmon,mtoFactorConverUSD);
//							if (SunatNumberUtils.isGreaterThanParam(mtoCalculadoUSD, mtoTopeFacturaEUR)){
////								listError.add(catalogoHelper.getErrorMap("30724", new String[] {serie.getNumserie().toString(), mtoTopeFacturaEUR.toString(), mtoCalculadoUSD.toString(), }));
//								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30724",new String[] {serie.getNumserie().toString(), mtoTopeFacturaEUR.toString(), mtoCalculadoUSD.toString(), }));
//							}
//						}
//						//Comparamos los Euros con respecto a Dolares
//						if (SunatStringUtils.include(codmoneda,new String[]{ConstantesDataCatalogo.MONEDA_DOLAR,ConstantesDataCatalogo.MONEDA_EUROS}) ||
//								!SunatStringUtils.include(codmoneda, new String[]{ConstantesDataCatalogo.MONEDA_DOLAR,ConstantesDataCatalogo.MONEDA_EUROS})){
//							BigDecimal mtoTopeFacturaUSD  = this.obtenerMontoTopeFactura(codConvenio, ConstantesAtributo.MTO_FACTURA_USD_CERTIORIGEN);
//							BigDecimal mtoFactorConverEUR = BigDecimal.ONE;
//							//if (!codmoneda.equals(ConstantesDataCatalogo.MONEDA_EUROS)){
//								mtoFactorConverEUR = this.obtenerFactorConversionOtraMoneda(codmoneda, ConstantesDataCatalogo.MONEDA_DOLAR, fechaDocComercial);	
//							//}
//							BigDecimal mtoCalculadoEUR = SunatNumberUtils.multiply(mtofobmon,mtoFactorConverEUR);
//							if (SunatNumberUtils.isGreaterThanParam(mtoCalculadoEUR, mtoTopeFacturaUSD)){
////								listError.add(catalogoHelper.getErrorMap("30723", new String[] {serie.getNumserie().toString(), mtoTopeFacturaUSD.toString(), mtoCalculadoEUR.toString()}));
//								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30723",new String[] {serie.getNumserie().toString(), mtoTopeFacturaUSD.toString(), mtoCalculadoEUR.toString()}));
//							}
							//}						
							}
						}
			}
		}
		return listError;
	}
	
	//807
	@ServicioAnnot(tipo="V",codServicio=3425, descServicio="Cuando el CO corresponda a una Declaracion de origen, se valida que el valor total factura o total FOB,  tanto en EUR como en USD no supere el monto maximo permitido por tipo de TLC, Nivel Nacional")
	@ServInstDetAnnot(tipoRpta={0,1},nomAtr={"declaracion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3425,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valMontoUSDEURFacturaEnvioDeclaracionNivelNacional(Declaracion declaracion, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ConsultaCertificadoOrigenService certificadoOrigen = fabricaDeServicios.getService("sigad.ingreso.ConsultaCertificadoOrigenService");
		Map<String, String> listError=new HashMap<String, String>();
		boolean validarNivelNacional= false;
		DUA dua = declaracion.getDua();
		String tipoDocumento = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		String numeroDocumento = dua.getDeclarante().getNumeroDocumentoIdentidad();
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<DatoSerie> listSeriesVerificar = new ArrayList<DatoSerie>();
		List<String> listIdComparaSerie = new ArrayList<String>();
		// si no tiene manifiesto no realiza la validacion...
		if(dua.getManifiesto()==null || dua.getManifiesto().getAnnmanif()==null || dua.getManifiesto().getNummanif()==null || dua.getManifiesto().getCodaduamanif()==null){
			return listError;
		}
		List<String> serviciosTLC = new ArrayList<String>();
		for(DatoSerie serie: dua.getListSeries()){
			if(tpiService.validarServicioTLC(this, serie, fechaReferencia, serviciosTLC)){
				List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
				if(CollectionUtils.isEmpty(listCertificadoOrigen))continue;
				String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();	
				BigDecimal mtofobmon = listCertificadoOrigen.get(0).getMtofobmon();		
				if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
					//amancilla String numautoexp = listCertificadoOrigen.get(0).getNumautoexp();
					String numautoexp = listCertificadoOrigen.get(0).getNumautoexp()!=null?listCertificadoOrigen.get(0).getNumautoexp().trim():"";
					if ( SunatStringUtils.isEmpty(numautoexp) && SunatNumberUtils.isGreaterThanZero(mtofobmon)) {
						validarNivelNacional=true;
						Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion); 
						String nombreProveedor = proveedor.getNombreRazonSocial().trim().toUpperCase().toString(); 
						String paisProveedor = proveedor.getPais().getCodDatacat();
						String idComparaSerie = serie.getCodconvinter().toString().concat(codTipoCO).concat(tipoDocumento).concat(numeroDocumento);
						idComparaSerie = idComparaSerie.concat(nombreProveedor).concat(paisProveedor);
						if(!listIdComparaSerie.contains(idComparaSerie)){
							listIdComparaSerie.add(idComparaSerie);
							listSeriesVerificar.add(serie);
						}
						//break;
					}
				}
			}
		}
		
		if(validarNivelNacional && CollectionUtils.isNotEmpty(listSeriesVerificar)){
			
			for(DatoSerie serieVer: listSeriesVerificar){
				List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serieVer);
				String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();
				Participante proveedor = this.getProveedorCorrespondiente(serieVer, declaracion); 
				String nombreProveedor = proveedor.getNombreRazonSocial().trim().toUpperCase().toString(); 
				String paisProveedor = proveedor.getPais().getCodDatacat();
				Certifiorigen certifiorigenparam = new Certifiorigen();
				certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_CONSUMO);
				certifiorigenparam.setCodTipDocimpor(tipoDocumento);
				certifiorigenparam.setNumDocimpor(numeroDocumento);
				certifiorigenparam.setCodTipCert(codTipoCO);//ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN
				certifiorigenparam.setCodTpi(serieVer.getCodconvinter().toString());
				List<Certifiorigen> listaCertificadoDUA = certificadoOrigen.consultarDUAsConCertificadoOrigen(certifiorigenparam);
				
				certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA);
				certifiorigenparam.setCodDocDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_18_13);
				listaCertificadoDUA.addAll(certificadoOrigen.consultarDUAsConCertificadoOrigen(certifiorigenparam));
				//if(!CollectionUtils.isEmpty(listaCertificadoDUA)){
					Map<String,Object> mapTotales  = calcularMtoFOBTotalFacturaImpProvManif(dua, listaCertificadoDUA, paisProveedor, nombreProveedor, true, serieVer.getCodconvinter().toString()); 
					BigDecimal mtoFOBAcumulado =  SunatNumberUtils.toBigDecimal(mapTotales.get("mtoFOBAcumulado"));
					BigDecimal mtoTotFactUSDAcumulado =  SunatNumberUtils.toBigDecimal(mapTotales.get("mtoTotFactUSDAcumulado"));
					BigDecimal mtoTotFactEURAcumulado =  SunatNumberUtils.toBigDecimal(mapTotales.get("mtoTotFactEURAcumulado"));
					boolean indTotalFactura = (Boolean)mapTotales.get("indTotalFactura");
					
					//suma las series transmitidas con igual importador, proveedor
					Map<String,Object> mapTotalesSeries = calcularMtoUSDEURFactImpProvSeriesTrans(declaracion,paisProveedor, nombreProveedor, true, serieVer.getCodconvinter().toString(), fechaReferencia);
					BigDecimal mtoFOBAcumuladoSeries = SunatNumberUtils.toBigDecimal(mapTotalesSeries.get("mtoFOBAcumuladoSeries"));
					BigDecimal mtoTotFactUSDSeries = SunatNumberUtils.toBigDecimal(mapTotalesSeries.get("mtoTotFactUSDSeries"));
					BigDecimal mtoTotFactEURSeries = SunatNumberUtils.toBigDecimal(mapTotalesSeries.get("mtoTotFactEURSeries"));
					boolean indTotalFacturaSerie = (Boolean)mapTotalesSeries.get("indTotalFacturaSerie");
					
					BigDecimal mtoTopeUSD = this.obtenerMontoTopeFactura(serieVer.getCodconvinter(), ConstantesAtributo.MTO_FACTURA_USD_CERTIORIGEN);
					BigDecimal mtoTopeEUR = this.obtenerMontoTopeFactura(serieVer.getCodconvinter(), ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN);
					if(indTotalFactura && indTotalFacturaSerie){
						
						if(SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.sum(mtoTotFactUSDSeries,mtoTotFactUSDAcumulado), mtoTopeUSD) || SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.sum(mtoTotFactEURSeries,mtoTotFactEURAcumulado), mtoTopeEUR)){
							//Las mercanc�as enviadas por el mismo proveedor<XX> al importador exceden los US$ 8,500 o 6,000 euros requiere certificado de origen, monto calculado dolares: <YY> , euros: <ZZ>
							listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30907",new String[] {nombreProveedor, SunatNumberUtils.sum(mtoTotFactUSDSeries,mtoTotFactUSDAcumulado).toString(), SunatNumberUtils.sum(mtoTotFactEURSeries,mtoTotFactEURAcumulado).toString() });
						}
					}else{
						//compara FOB
						if(SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.sum(mtoFOBAcumulado, mtoFOBAcumuladoSeries), mtoTopeUSD)){
							//Las mercanc�as enviadas por el mismo proveedor<XXX> al importador posiblemente exceden los US$ 8,500 o 6,000 euros requiere certificado de origen. Verifique las importaciones realizadas por el mismo proveedor al importador con el mismo manifiesto<ZZZ>, monto calculado dolares: <YYY>.
							String manifiesto = dua.getManifiesto().getCodaduamanif().concat(" - ").concat(dua.getManifiesto().getAnnmanif()).concat(" - ").concat(dua.getManifiesto().getNummanif());
							listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30908",new String[] {nombreProveedor, manifiesto, SunatNumberUtils.sum(mtoFOBAcumulado, mtoFOBAcumuladoSeries).toString() });
						}
					}
							//}
				
			}
		}
		return listError;
	}
	
	//812
	@ServicioAnnot(tipo="V",codServicio=3426, descServicio="Cuando el CO corresponda a una Declaracion de origen, se valida que el valor total factura o total FOB no supere el monto maximo permitido por tipo de TLC, Nivel Nacional")
	@ServInstDetAnnot(tipoRpta={0,1},nomAtr={"declaracion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3426,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valMontoEURFacturaEnvioDeclaracionNivelNacional(Declaracion declaracion, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ConsultaCertificadoOrigenService certificadoOrigen = fabricaDeServicios.getService("sigad.ingreso.ConsultaCertificadoOrigenService");
		Map<String, String> listError=new HashMap<String, String>();
		boolean validarNivelNacional= false;
		DUA dua = declaracion.getDua();
		String tipoDocumento = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		String numeroDocumento = dua.getDeclarante().getNumeroDocumentoIdentidad();
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<DatoSerie> listSeriesVerificar = new ArrayList<DatoSerie>();
		List<String> listIdComparaSerie = new ArrayList<String>();
		if(dua.getManifiesto()==null || dua.getManifiesto().getAnnmanif()==null || dua.getManifiesto().getNummanif()==null || dua.getManifiesto().getCodaduamanif()==null){
			return listError;
		}
		List<String> serviciosTLC = new ArrayList<String>();
		for(DatoSerie serie: dua.getListSeries()){
			if(tpiService.validarServicioTLC(this, serie, fechaReferencia, serviciosTLC)){
				List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
				if(CollectionUtils.isEmpty(listCertificadoOrigen))continue;
				String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();	
				//BigDecimal mtofobmon = listCertificadoOrigen.get(0).getMtofobmon();		
				if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
					String numautoexp = listCertificadoOrigen.get(0).getNumautoexp()!=null?listCertificadoOrigen.get(0).getNumautoexp().trim():"";
					if ( SunatStringUtils.isEmpty(numautoexp)) {
						validarNivelNacional=true;
						Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion); 
						String nombreProveedor = proveedor.getNombreRazonSocial().trim().toUpperCase().toString(); 
						String paisProveedor = proveedor.getPais().getCodDatacat();
						String idComparaSerie = serie.getCodconvinter().toString().concat(codTipoCO).concat(tipoDocumento).concat(numeroDocumento);
						idComparaSerie = idComparaSerie.concat(nombreProveedor).concat(paisProveedor);
						if(!listIdComparaSerie.contains(idComparaSerie)){
							listIdComparaSerie.add(idComparaSerie);
							listSeriesVerificar.add(serie);
						}
						//break;
					}
					}
				}
			}
		
		if(validarNivelNacional && CollectionUtils.isNotEmpty(listSeriesVerificar)){
			
			for(DatoSerie serieVer: listSeriesVerificar){
				List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serieVer);
				String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();
				Participante proveedor = this.getProveedorCorrespondiente(serieVer, declaracion); 
				String nombreProveedor = proveedor.getNombreRazonSocial().trim().toUpperCase().toString(); 
				String paisProveedor = proveedor.getPais().getCodDatacat();
				Certifiorigen certifiorigenparam = new Certifiorigen();
				certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_CONSUMO);
				certifiorigenparam.setCodTipDocimpor(tipoDocumento);
				certifiorigenparam.setNumDocimpor(numeroDocumento);
				certifiorigenparam.setCodTipCert(codTipoCO);//ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN
				certifiorigenparam.setCodTpi(serieVer.getCodconvinter().toString());
				List<Certifiorigen> listaCertificadoDUA = certificadoOrigen.consultarDUAsConCertificadoOrigen(certifiorigenparam);
				
				certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA);
				certifiorigenparam.setCodDocDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_18_13);
				listaCertificadoDUA.addAll(certificadoOrigen.consultarDUAsConCertificadoOrigen(certifiorigenparam));
				
				Map<String,Object> mapTotales  = calcularMtoFOBTotalFacturaEURImpProvManif(dua, listaCertificadoDUA, paisProveedor, nombreProveedor, false, serieVer.getCodconvinter().toString()); 
				//BigDecimal mtoFOBAcumulado =  SunatNumberUtils.toBigDecimal(mapTotales.get("mtoFOBAcumulado"));
				BigDecimal mtoFOBAcumuladoEUR =  SunatNumberUtils.toBigDecimal(mapTotales.get("mtoFOBAcumuladoEUR"));
				//BigDecimal mtoTotFactUSDAcumulado =  SunatNumberUtils.toBigDecimal(mapTotales.get("mtoTotFactUSDAcumulado"));
				BigDecimal mtoTotFactEURAcumulado =  SunatNumberUtils.toBigDecimal(mapTotales.get("mtoTotFactEURAcumulado"));
				boolean indTotalFactura = (Boolean)mapTotales.get("indTotalFactura");
				
				//suma las series transmitidas con igual importador, proveedor
				Map<String,Object> mapTotalesSeries = calcularMtoEURFactImpProvSeriesTrans(declaracion,paisProveedor, nombreProveedor, false, serieVer.getCodconvinter().toString(),fechaReferencia);
				//si la moneda no existe devuelve mensaje
				if(mapTotalesSeries.containsKey("listError")){
					return ( Map<String, String>)mapTotalesSeries.get("listError");
							}
				//BigDecimal mtoFOBAcumuladoSeries = SunatNumberUtils.toBigDecimal(mapTotalesSeries.get("mtoFOBAcumuladoSeries"));
				BigDecimal mtoFOBAcumuladoEURSeries = SunatNumberUtils.toBigDecimal(mapTotalesSeries.get("mtoFOBAcumuladoEURSeries"));
				//BigDecimal mtoTotFactUSDSeries = SunatNumberUtils.toBigDecimal(mapTotalesSeries.get("mtoTotFactUSDSeries"));
				BigDecimal mtoTotFactEURSeries = SunatNumberUtils.toBigDecimal(mapTotalesSeries.get("mtoTotFactEURSeries"));
				boolean indTotalFacturaSerie = (Boolean)mapTotalesSeries.get("indTotalFacturaSerie");
				
				//BigDecimal mtoTopeUSD = this.obtenerMontoTopeFactura(serieVer.getCodconvinter(), ConstantesAtributo.MTO_FACTURA_USD_CERTIORIGEN);
				BigDecimal mtoTopeEUR = this.obtenerMontoTopeFactura(serieVer.getCodconvinter(), ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN);
				if(indTotalFactura && indTotalFacturaSerie){
					
					if(SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.sum(mtoTotFactEURSeries,mtoTotFactEURAcumulado), mtoTopeEUR)){
						//Las mercanc�as enviadas por el mismo proveedor<XX> al importador exceden los 6,000 Euros requiere certificado de origen, monto calculado: <YY>
						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30909",new String[] {nombreProveedor, SunatNumberUtils.sum(mtoTotFactEURSeries,mtoTotFactEURAcumulado).toString() });
						}
				}else{
					//compara FOB, se obtiene el equivalente en dolares en la tabla correspondiente					
					if(SunatNumberUtils.isGreaterThanParam(SunatNumberUtils.sum(mtoFOBAcumuladoEUR, mtoFOBAcumuladoEURSeries), mtoTopeEUR)){						
						//Las mercanc�as enviadas por el mismo proveedor<XXX> al importador posiblemente exceden los 6,000 euros requiere certificado de origen. Verifique las importaciones realizadas por el mismo proveedor al importador con el mismo manifiesto<ZZZ>.monto calculado euros: <YYY>
						String annomanif = SunatStringUtils.length(dua.getManifiesto().getAnnmanif()) > 3 ? dua.getManifiesto().getAnnmanif().substring(0, 4) : null;
						String manifiesto = dua.getManifiesto().getCodaduamanif().concat(" - ").concat(annomanif).concat(" - ").concat(dua.getManifiesto().getNummanif());
						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30910",new String[] {nombreProveedor, manifiesto, SunatNumberUtils.sum(mtoFOBAcumuladoEUR, mtoFOBAcumuladoEURSeries).toString() });
					}
				}
			}
		}
		return listError;
	}

	private Map<String,Object> calcularMtoUSDEURFactImpProvSeriesTrans(Declaracion declaracion, String paisProveedor, String nombreProveedor, boolean matchTPI, String codTPI, Date fechaReferencia){
		
		Map<String, Object> mapRespuesta = new HashMap<String, Object>();
		BigDecimal mtoTotFactUSDSeries = BigDecimal.ZERO;
		BigDecimal mtoTotFactEURSeries = BigDecimal.ZERO;
		BigDecimal mtoFOBAcumuladoSeries = BigDecimal.ZERO;
		BigDecimal mtoFOBAcumuladoEURSeries = BigDecimal.ZERO;
		boolean indTotalFacturaSerie = true;
		DUA dua = declaracion.getDua();
		for(DatoSerie serie: dua.getListSeries()){
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
			String codTipoCO = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getCodtipoCO():null;
			BigDecimal mtofobmon = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getMtofobmon():BigDecimal.ZERO;
			String codMoneda = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getCodmoneda():null;
			DatoOtroDocSoporte docSoporte = getDocSoportePorTipo (dua, serie, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_DOC_COMERCIAL);
			Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion); 
			String nombreProveedorRef = proveedor.getNombreRazonSocial().trim().toUpperCase().toString();					
			String paisProveedorRef = proveedor.getPais().getCodDatacat();
			Integer convInter = serie.getCodconvinter();
			if ((!matchTPI &&(convInter ==null || convInter.equals(new Integer(0)) || convInter.equals(new Integer(codTPI)))) || ( matchTPI && convInter.equals(new Integer(codTPI)))){
				if(nombreProveedor.equals(nombreProveedorRef) && paisProveedor.equals(paisProveedorRef)){
					if(mtofobmon == null ||SunatNumberUtils.isEqualToZero(mtofobmon) )indTotalFacturaSerie=false;
					Date fechaDocComercial = SunatDateUtils.getCurrentDate(); 
					if(docSoporte!=null && docSoporte.getFecdocasoc()!=null)fechaDocComercial = docSoporte.getFecdocasoc();
					if(indTotalFacturaSerie){
						BigDecimal factorConversionUSD = this.obtenerFactorConversionOtraMoneda(codMoneda, ConstantesDataCatalogo.MONEDA_DOLAR, fechaDocComercial);
						BigDecimal factorConversionEUR = this.obtenerFactorConversionOtraMoneda(codMoneda, ConstantesDataCatalogo.MONEDA_EUROS, fechaDocComercial);
						mtoTotFactUSDSeries = SunatNumberUtils.sum(mtoTotFactUSDSeries, SunatNumberUtils.multiply(factorConversionUSD, mtofobmon));
						mtoTotFactEURSeries = SunatNumberUtils.sum(mtoTotFactEURSeries, SunatNumberUtils.multiply(factorConversionEUR, mtofobmon));
					}		
					mtoFOBAcumuladoSeries = SunatNumberUtils.sum(mtoFOBAcumuladoSeries, serie.getMtofobdol());
					BigDecimal factorConversion = this.obtenerFactorConversionOtraMoneda(ConstantesDataCatalogo.MONEDA_DOLAR, ConstantesDataCatalogo.MONEDA_EUROS, fechaReferencia);
					
					mtoFOBAcumuladoEURSeries = SunatNumberUtils.sum(mtoFOBAcumuladoEURSeries, SunatNumberUtils.multiply(factorConversion, serie.getMtofobdol()));
				}
			}
		}
		mapRespuesta.put("mtoTotFactUSDSeries", mtoTotFactUSDSeries);
		mapRespuesta.put("mtoTotFactEURSeries", mtoTotFactEURSeries);
		mapRespuesta.put("mtoFOBAcumuladoSeries", mtoFOBAcumuladoSeries);
		mapRespuesta.put("mtoFOBAcumuladoEURSeries", mtoFOBAcumuladoEURSeries);
		mapRespuesta.put("indTotalFacturaSerie", indTotalFacturaSerie);
		return mapRespuesta;
	}
	
private Map<String,Object> calcularMtoEURFactImpProvSeriesTrans(Declaracion declaracion, String paisProveedor, String nombreProveedor, boolean matchTPI, String codTPI, Date fechaReferencia){
		
		Map<String, Object> mapRespuesta = new HashMap<String, Object>();
		List<String> lstCOCalculados = new ArrayList<String>(); //Contiene los CO a los que ya se les calculo el monto acumulable por factura
		BigDecimal mtoTotFactEURSeries = BigDecimal.ZERO;
		BigDecimal mtoFOBAcumuladoSeries = BigDecimal.ZERO;
		BigDecimal mtoFOBAcumuladoEURSeries = BigDecimal.ZERO;
		boolean indTotalFacturaSerie = true;
		DUA dua = declaracion.getDua();
		CertiOrigenService certiOrigenService = fabricaDeServicios.getService("certiOrigenService");
		for(DatoSerie serie: dua.getListSeries()){
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
			//String codTipoCO = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getCodtipoCO():null;
			BigDecimal mtofobmon = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getMtofobmon():BigDecimal.ZERO;
			String codMoneda = CollectionUtils.isNotEmpty(listCertificadoOrigen)? listCertificadoOrigen.get(0).getCodmoneda():null;
			DatoOtroDocSoporte docSoporte = getDocSoportePorTipo (dua, serie, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_DOC_COMERCIAL);
			Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion); 
			String nombreProveedorRef = proveedor.getNombreRazonSocial().trim().toUpperCase().toString();					
			String paisProveedorRef = proveedor.getPais().getCodDatacat();
			Integer convInter = serie.getCodconvinter();
			if ((!matchTPI &&(convInter ==null || convInter.equals(new Integer(0)) || convInter.equals(new Integer(codTPI)))) || ( matchTPI && convInter.equals(new Integer(codTPI)))){
				if(nombreProveedor.equals(nombreProveedorRef) && paisProveedor.equals(paisProveedorRef)){
					if(mtofobmon == null ||SunatNumberUtils.isEqualToZero(mtofobmon) || codMoneda == null) {
						indTotalFacturaSerie=false;
					}
					Date fechaDocComercial = SunatDateUtils.getCurrentDate(); 
					if(docSoporte!=null && docSoporte.getFecdocasoc()!=null) {
						fechaDocComercial = docSoporte.getFecdocasoc();
					}
					if (CollectionUtils.isNotEmpty(listCertificadoOrigen)) {
					BigDecimal mtoTopeEUR = this.obtenerMontoTopeFactura(new Integer(codTPI), ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN);
					String strCertOrigenPK = listCertificadoOrigen.get(0).getNumsecCO()+"-"+listCertificadoOrigen.get(0).getNumdocumento()+"-"+listCertificadoOrigen.get(0).getCodtipoCO();
					if (lstCOCalculados.indexOf(strCertOrigenPK) == -1) {
						if(indTotalFacturaSerie){
							lstCOCalculados.add(strCertOrigenPK);
							EquivMonto equivMonto = certiOrigenService.consultarMontoEquivalente(codMoneda, fechaDocComercial);							
							if (equivMonto != null && SunatNumberUtils.isGreaterThanZero(equivMonto.getMtoequiv()) ){
								BigDecimal mtoCalculadoEUR = SunatNumberUtils.divide(SunatNumberUtils.multiply(mtoTopeEUR,mtofobmon),equivMonto.getMtoequiv(),3);
								mtoTotFactEURSeries = SunatNumberUtils.sum(mtoTotFactEURSeries,mtoCalculadoEUR);
							} else{
								BigDecimal factorConversionEUR = this.obtenerFactorConversionOtraMoneda(codMoneda, ConstantesDataCatalogo.MONEDA_EUROS, fechaDocComercial);
								if(factorConversionEUR==null){
									mapRespuesta.put("listError",  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30813",new String[] {serie.getNumserie().toString(), codMoneda}));
									return mapRespuesta;
								}else{
									mtoTotFactEURSeries = SunatNumberUtils.sum(mtoTotFactEURSeries, SunatNumberUtils.multiply(factorConversionEUR, mtofobmon));
								}

							}

						}
					}
					}
					mtoFOBAcumuladoSeries = SunatNumberUtils.sum(mtoFOBAcumuladoSeries, serie.getMtofobdol());
					BigDecimal factorConversion = this.obtenerFactorConversionOtraMoneda(ConstantesDataCatalogo.MONEDA_DOLAR, ConstantesDataCatalogo.MONEDA_EUROS, fechaReferencia);				
					mtoFOBAcumuladoEURSeries = SunatNumberUtils.sum(mtoFOBAcumuladoEURSeries, SunatNumberUtils.multiply(factorConversion, serie.getMtofobdol()));
				}
			}
		}
		mapRespuesta.put("mtoTotFactEURSeries", mtoTotFactEURSeries);
		mapRespuesta.put("mtoFOBAcumuladoSeries", mtoFOBAcumuladoSeries);
		mapRespuesta.put("mtoFOBAcumuladoEURSeries", mtoFOBAcumuladoEURSeries);
		mapRespuesta.put("indTotalFacturaSerie", indTotalFacturaSerie);
		return mapRespuesta;
	}

	private Map<String,Object> calcularMtoFOBTotalFacturaImpProvManif(DUA dua, List<Certifiorigen> listcertifiorigen, String paisProveedor, String nombreProveedor, boolean matchTPI, String codTPI){
		ConsultaDeclaracionImpoConsumoService declaracionImpoConsumo = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
		ConsultaDeclaracionImpoSimplificadaService declaracionImpoSimplificada = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoSimplificadaService");
		ConsultaFormatoBService consultaFormatoBService = fabricaDeServicios.getService("sigad.despacho.entrada.service.consultaFormatoBService");
		ConsultaCertificadoOrigenService certificadoOrigen = fabricaDeServicios.getService("sigad.ingreso.ConsultaCertificadoOrigenService");
		BigDecimal mtoFOBAcumulado = BigDecimal.ZERO;
		BigDecimal mtoFOBAcumuladoEUR = BigDecimal.ZERO;
		BigDecimal mtoTotFactUSDAcumulado = BigDecimal.ZERO;
		BigDecimal mtoTotFactEURAcumulado = BigDecimal.ZERO;
		Map<String,Object> mapTotales = new HashMap<String, Object>();
		String cadumanif = dua.getManifiesto().getCodaduamanif();
		//String annomanif = new String(dua.getManifiesto().getAnnmanif().substring(0, 4));
		String annomanif = SunatStringUtils.length(dua.getManifiesto().getAnnmanif()) > 3 ? dua.getManifiesto().getAnnmanif().substring(0, 4) : null;
		String numemanif = dua.getManifiesto().getNummanif();
		boolean indTotalFactura= true;
		for(Certifiorigen certifiorigen :  listcertifiorigen){
			String codiAduan  = certifiorigen.getCodAduanaDua();
			String anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),2,4);;					
			String codiRegi   = certifiorigen.getCodRegimenDua();
			String numeCorre  = SunatStringUtils.lpad(certifiorigen.getNumDua(),6,'0');

			//String numeSeriee = SunatStringUtils.lpad(certifiorigen.getNumSerieDua().toString(),4,' ');
			//String nombreProveedorRef = "";
			//String paisProveedorRef = "";	
			String cadumanifref = new String();
			String annomanifref = new String();
			String numemanifref = new String();

			if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
				Map<String, Object> paramsdua = new HashMap<String, Object>();
				paramsdua.put("CODIADUAN", codiAduan);
				paramsdua.put("ANOPRESE", anoPrese);
				paramsdua.put("NUMECORRE", numeCorre);
				Map<String, Object> declaracionSigad = declaracionImpoConsumo.consultarDeclaracionImportacionConsumo(paramsdua, codiAduan);
				if (declaracionSigad != null){
					cadumanifref = declaracionSigad.get("CADU_MANIF").toString();
					annomanifref = declaracionSigad.get("FECHAMANIF").toString();
					numemanifref = declaracionSigad.get("NUME_MANIF").toString();							
				} else {
					continue;
				}
				// Para declaraciones simplificadas
			} else{
//				continue;
			    Polizaq polizaq = declaracionImpoSimplificada.consultarDeclaracionSimplificada(anoPrese, codiAduan, numeCorre, codiAduan);
			    if (polizaq != null){
			    	cadumanifref = polizaq.getCaduManif();
					annomanifref = polizaq.getFechManif();
					numemanifref = polizaq.getNumeManif().toString();							
			    } else {
			    	continue;
			    }
			}
			if (!cadumanif.equals(cadumanifref) ||  !annomanif.equals(annomanifref) || !numemanif.equals(numemanifref)){
				continue;
			}
			//listamos las series que tienen el mismo proveedor
			if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){				
				FormBCorr formBCorrelacion = new FormBCorr();
				formBCorrelacion.setCodigoAduana(codiAduan);
				formBCorrelacion.setAnnoDeclaracion(anoPrese);
				formBCorrelacion.setNumeroDeclaracion(numeCorre);
				formBCorrelacion.setCodigoRegimen(codiRegi) ;
				formBCorrelacion.setNombreProveedor(nombreProveedor);
				formBCorrelacion.setCodigoPais(paisProveedor);
				List<FormBCorr>  listSeriesProveedor = consultaFormatoBService.selectSeriesByDUAProveedor(formBCorrelacion);
				if (!CollectionUtils.isEmpty(listSeriesProveedor)){
					for(FormBCorr correlSerie: listSeriesProveedor){
						// se busca el monto total factura en certifiorigen
						Certifiorigen certifiorigenSeries = new Certifiorigen();
						certifiorigenSeries.setCodAduanaDua(certifiorigen.getCodAduanaDua());
						certifiorigenSeries.setCodRegimenDua(certifiorigen.getCodRegimenDua());
						certifiorigenSeries.setAnnDua(certifiorigen.getAnnDua());
						certifiorigenSeries.setNumDua(certifiorigen.getNumDua());
						certifiorigenSeries.setCodAduanaDua(certifiorigen.getCodAduanaDua());
						certifiorigenSeries.setNumSerieDua(new Short(correlSerie.getNumeroSerieFA().trim()));
						certifiorigenSeries.setCodTipCert(ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN);//solo para tipo 5
						if(matchTPI ){
							certifiorigenSeries.setCodTpi(codTPI);
							List<Certifiorigen> listCertOrigSerie =  certificadoOrigen.consultarCertificadoOrigen(certifiorigenSeries);
							if(!CollectionUtils.isEmpty(listCertOrigSerie)){
								if(listCertOrigSerie.get(0).getValTotfac().compareTo(BigDecimal.ZERO)==0 || listCertOrigSerie.get(0).getCodMonfac().trim().equals("")){
									indTotalFactura= false;
								}
								if(indTotalFactura){
									//obtiene el valor total factura
									BigDecimal factorConversionUSD = this.obtenerFactorConversionOtraMoneda(listCertOrigSerie.get(0).getCodMonfac(), ConstantesDataCatalogo.MONEDA_DOLAR,listCertOrigSerie.get(0).getFecCert());
									mtoTotFactUSDAcumulado = SunatNumberUtils.sum(mtoTotFactUSDAcumulado, SunatNumberUtils.multiply(factorConversionUSD, listCertOrigSerie.get(0).getValTotfac()));
									BigDecimal factorConversionEUR = this.obtenerFactorConversionOtraMoneda(listCertOrigSerie.get(0).getCodMonfac(), ConstantesDataCatalogo.MONEDA_EUROS,listCertOrigSerie.get(0).getFecCert());
									mtoTotFactEURAcumulado = SunatNumberUtils.sum(mtoTotFactEURAcumulado, SunatNumberUtils.multiply(factorConversionEUR, listCertOrigSerie.get(0).getValTotfac()));
									
								}
								//Se busca series y se acumula Mto FOB 
								
								if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
									Diseriesi seriesi = declaracionImpoConsumo.consultarSerieDeclaracionDefinitiva(anoPrese, codiAduan, numeCorre, correlSerie.getNumeroSerieFA(), codiAduan);
									String tpiSerie= seriesi.getConvInter().toString();
									if ((seriesi != null && !matchTPI &&(tpiSerie.equals(codTPI) || tpiSerie.equals("0"))) || (seriesi != null && matchTPI && tpiSerie.equals(codTPI))){
										
										mtoFOBAcumulado = SunatNumberUtils.sum(mtoFOBAcumulado,seriesi.getFobDolpol());
										BigDecimal factorConver = this.obtenerFactorConversionOtraMoneda(ConstantesDataCatalogo.MONEDA_DOLAR, ConstantesDataCatalogo.MONEDA_EUROS, SunatDateUtils.getDateFromInteger(seriesi.getFechIngsi()));
										mtoFOBAcumuladoEUR = SunatNumberUtils.sum( mtoFOBAcumuladoEUR, SunatNumberUtils.multiply(factorConver ,seriesi.getFobDolpol()));
										
									}
								}
							}
						}
					}
					 
				} else {
					continue;
				}
				
			} else{
				// Para declaraciones simplificadas no tiene Formato B
				//continue;
				anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),0,4);
				SimplificadaFormBCorr simpFormBCorrelacion = new SimplificadaFormBCorr();
				simpFormBCorrelacion.setCodigoAduana(codiAduan);
				simpFormBCorrelacion.setAnnoDeclaracion(anoPrese);
				simpFormBCorrelacion.setNumeroDeclaracion(numeCorre);
				simpFormBCorrelacion.setCodigoRegimen(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_DQ) ;//aqui es DQ
				simpFormBCorrelacion.setNombreProveedor(nombreProveedor);
				simpFormBCorrelacion.setPaisProveedor(paisProveedor);
//				simpFormBCorrelacion.setNumeroSerieI(new Short(numeSeriee.trim()));
				List<SimplificadaFormBCorr> listSeriesSimpProveedor = consultaFormatoBService.selectSeriesSimplificadaByDUAProveedor(simpFormBCorrelacion);
				if(CollectionUtils.isNotEmpty(listSeriesSimpProveedor)){
					for(SimplificadaFormBCorr simpFormbCorr :listSeriesSimpProveedor){
						// se busca el monto total factura en certifiorigen
						Certifiorigen certifiorigenSeries = new Certifiorigen();
						certifiorigenSeries.setCodAduanaDua(certifiorigen.getCodAduanaDua());
						certifiorigenSeries.setCodRegimenDua(certifiorigen.getCodRegimenDua());
						certifiorigenSeries.setAnnDua(certifiorigen.getAnnDua());
						certifiorigenSeries.setNumDua(certifiorigen.getNumDua());
						certifiorigenSeries.setCodAduanaDua(certifiorigen.getCodAduanaDua());
						certifiorigenSeries.setNumSerieDua(simpFormbCorr.getNumeroSerieI());
						certifiorigenSeries.setCodTipCert(ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN);//solo para tipo 5
						if(matchTPI ){
							certifiorigenSeries.setCodTpi(codTPI);
							List<Certifiorigen> listCertOrigSerie =  certificadoOrigen.consultarCertificadoOrigen(certifiorigenSeries);
							if(!CollectionUtils.isEmpty(listCertOrigSerie)){
								if(listCertOrigSerie.get(0).getValTotfac().compareTo(BigDecimal.ZERO)==0 || listCertOrigSerie.get(0).getCodMonfac().trim().equals("")){
									indTotalFactura= false;
								}
								if(indTotalFactura){
									//obtiene el valor total factura
									BigDecimal factorConversionUSD = this.obtenerFactorConversionOtraMoneda(listCertOrigSerie.get(0).getCodMonfac(), ConstantesDataCatalogo.MONEDA_DOLAR,listCertOrigSerie.get(0).getFecCert());
									mtoTotFactUSDAcumulado = SunatNumberUtils.sum(mtoTotFactUSDAcumulado, SunatNumberUtils.multiply(factorConversionUSD, listCertOrigSerie.get(0).getValTotfac()));
									BigDecimal factorConversionEUR = this.obtenerFactorConversionOtraMoneda(listCertOrigSerie.get(0).getCodMonfac(), ConstantesDataCatalogo.MONEDA_EUROS,listCertOrigSerie.get(0).getFecCert());
									mtoTotFactEURAcumulado = SunatNumberUtils.sum(mtoTotFactEURAcumulado, SunatNumberUtils.multiply(factorConversionEUR, listCertOrigSerie.get(0).getValTotfac()));
								}
								
								//Se busca series y se acumula Mto FOB 
								if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA)) {
									anoPrese = anoPrese.substring(2);
									String numSerie =  SunatStringUtils.lpad(simpFormbCorr.getNumeroSerieI().toString(),4,' ');
									Seriesq seriesq  = declaracionImpoSimplificada.consultarSeriesDeclaracionSimplificada(anoPrese, codiAduan, numeCorre, numSerie, codiAduan);
									if (seriesq == null) {
										throw new IllegalArgumentException("NO SE ENCONTRO SERIE [codiRegi=" + codiRegi + ", anoPrese=" + anoPrese + ", codiAduan= " + codiAduan + ", numeCorre= " + numeCorre + ", serie = " + numSerie + "] A PESAR DE QUE ESTA REGISTRADA LA DUA... VERIFICAR EN EL ASIGAD");
									}
									
									String tpiSerie= seriesq!=null && seriesq.getConvInter()!=null? seriesq.getConvInter().toString(): "0";
									if ((seriesq != null && !matchTPI &&(tpiSerie.equals(codTPI) || tpiSerie.equals("0"))) || (seriesq != null && matchTPI && tpiSerie.equals(codTPI))){
										
										mtoFOBAcumulado = SunatNumberUtils.sum(mtoFOBAcumulado,seriesq.getFobDolpol());
										BigDecimal factorConver = this.obtenerFactorConversionOtraMoneda(ConstantesDataCatalogo.MONEDA_DOLAR, ConstantesDataCatalogo.MONEDA_EUROS, SunatDateUtils.getDateFromInteger(seriesq.getFechIngsi()));
										mtoFOBAcumuladoEUR = SunatNumberUtils.sum( mtoFOBAcumuladoEUR, SunatNumberUtils.multiply(factorConver ,seriesq.getFobDolpol()));
										
									}
								}
							}
							
							
						}
						
					}
				}
				
			}
		}
		
		mapTotales.put("mtoFOBAcumulado",mtoFOBAcumulado);
		mapTotales.put("mtoTotFactUSDAcumulado",mtoTotFactUSDAcumulado);
		mapTotales.put("mtoTotFactEURAcumulado",mtoTotFactEURAcumulado);
		mapTotales.put("mtoFOBAcumuladoEUR", mtoFOBAcumuladoEUR);
		mapTotales.put("indTotalFactura",indTotalFactura);
		return mapTotales;
	}
	
	private Map<String,Object> calcularMtoFOBTotalFacturaEURImpProvManif(DUA dua, List<Certifiorigen> listcertifiorigen, String paisProveedor, String nombreProveedor, boolean matchTPI, String codTPI){
		ConsultaDeclaracionImpoConsumoService declaracionImpoConsumo = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
		ConsultaDeclaracionImpoSimplificadaService declaracionImpoSimplificada = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoSimplificadaService");
		ConsultaFormatoBService consultaFormatoBService = fabricaDeServicios.getService("sigad.despacho.entrada.service.consultaFormatoBService");
		ConsultaCertificadoOrigenService certificadoOrigen = fabricaDeServicios.getService("sigad.ingreso.ConsultaCertificadoOrigenService");
		CertiOrigenService certiOrigenService = fabricaDeServicios.getService("certiOrigenService");
		BigDecimal mtoFOBAcumulado = BigDecimal.ZERO;
		BigDecimal mtoFOBAcumuladoEUR = BigDecimal.ZERO;
		//BigDecimal mtoTotFactUSDAcumulado = BigDecimal.ZERO;
		BigDecimal mtoTotFactEURAcumulado = BigDecimal.ZERO;
		Map<String,Object> mapTotales = new HashMap<String, Object>();
		String cadumanif = dua.getManifiesto().getCodaduamanif();
		//String annomanif = new String(dua.getManifiesto().getAnnmanif().substring(0, 4));
		String annomanif = SunatStringUtils.length(dua.getManifiesto().getAnnmanif()) > 3 ? dua.getManifiesto().getAnnmanif().substring(0, 4) : null;
		String numemanif = dua.getManifiesto().getNummanif();
		boolean indTotalFactura= true;
		for(Certifiorigen certifiorigen :  listcertifiorigen){
			String codiAduan  = certifiorigen.getCodAduanaDua();
			String anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),2,4);;					
			String codiRegi   = certifiorigen.getCodRegimenDua();
			String numeCorre  = SunatStringUtils.lpad(certifiorigen.getNumDua(),6,'0');

			//String numeSeriee = SunatStringUtils.lpad(certifiorigen.getNumSerieDua().toString(),4,' ');
			//String nombreProveedorRef = "";
			//String paisProveedorRef = "";	
			String cadumanifref = new String();
			String annomanifref = new String();
			String numemanifref = new String();

			if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
				Map<String, Object> paramsdua = new HashMap<String, Object>();
				paramsdua.put("CODIADUAN", codiAduan);
				paramsdua.put("ANOPRESE", anoPrese);
				paramsdua.put("NUMECORRE", numeCorre);
				Map<String, Object> declaracionSigad = declaracionImpoConsumo.consultarDeclaracionImportacionConsumo(paramsdua, codiAduan);
				if (declaracionSigad != null){
					cadumanifref = declaracionSigad.get("CADU_MANIF").toString();
					annomanifref = declaracionSigad.get("FECHAMANIF").toString();
					numemanifref = declaracionSigad.get("NUME_MANIF").toString();							
				} else {
					continue;
				}
				// Para declaraciones simplificadas
			} else{
//				continue;
			    Polizaq polizaq = declaracionImpoSimplificada.consultarDeclaracionSimplificada(anoPrese, codiAduan, numeCorre, codiAduan);
			    if (polizaq != null){
			    	cadumanifref = polizaq.getCaduManif();
					annomanifref = polizaq.getFechManif();
					numemanifref = polizaq.getNumeManif().toString();							
			    } else {
			    	continue;
			    }
			}
			if (!cadumanif.equals(cadumanifref) ||  !annomanif.equals(annomanifref) || !numemanif.equals(numemanifref)){
				continue;
			}
			//listamos las series que tienen el mismo proveedor
			if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){				
				FormBCorr formBCorrelacion = new FormBCorr();
				formBCorrelacion.setCodigoAduana(codiAduan);
				formBCorrelacion.setAnnoDeclaracion(anoPrese);
				formBCorrelacion.setNumeroDeclaracion(numeCorre);
				formBCorrelacion.setCodigoRegimen(codiRegi) ;
				formBCorrelacion.setNombreProveedor(nombreProveedor);
				formBCorrelacion.setCodigoPais(paisProveedor);
				List<FormBCorr>  listSeriesProveedor = consultaFormatoBService.selectSeriesByDUAProveedor(formBCorrelacion);
				if (!CollectionUtils.isEmpty(listSeriesProveedor)){
					for(FormBCorr correlSerie: listSeriesProveedor){
						// se busca el monto total factura en certifiorigen
						Certifiorigen certifiorigenSeries = new Certifiorigen();
						certifiorigenSeries.setCodAduanaDua(certifiorigen.getCodAduanaDua());
						certifiorigenSeries.setCodRegimenDua(certifiorigen.getCodRegimenDua());
						certifiorigenSeries.setAnnDua(certifiorigen.getAnnDua());
						certifiorigenSeries.setNumDua(certifiorigen.getNumDua());
						certifiorigenSeries.setCodAduanaDua(certifiorigen.getCodAduanaDua());
						certifiorigenSeries.setNumSerieDua(new Short(correlSerie.getNumeroSerieFA().trim()));
						//if(matchTPI ){
							List<Certifiorigen> listCertOrigSerie =  certificadoOrigen.consultarCertificadoOrigen(certifiorigenSeries);
							if(!CollectionUtils.isEmpty(listCertOrigSerie)){
								//de tener TPI solo considerar con tipo certificado cinco
								if(!listCertOrigSerie.get(0).getCodTipCert().equals(ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN)) continue;
								
								if(listCertOrigSerie.get(0).getValTotfac().compareTo(BigDecimal.ZERO)==0 || listCertOrigSerie.get(0).getCodMonfac().trim().equals("")){									
									indTotalFactura= false;
								}
							}else{
								indTotalFactura= false;
							}
							
							if(indTotalFactura){
								//obtiene el valor total factura
								//OBTIENE EL EQUIVALENTE DE NO ENCONTRAR EQUIVALENTE 
								String codMoneda = listCertOrigSerie.get(0).getCodMonfac();
								BigDecimal mtofobmon = listCertOrigSerie.get(0).getValTotfac();
								if(codMoneda.equals(ConstantesDataCatalogo.MONEDA_EUROS)){
									mtoTotFactEURAcumulado = SunatNumberUtils.sum(mtoTotFactEURAcumulado, mtofobmon);
								}else{
									BigDecimal mtoTopeEUR = this.obtenerMontoTopeFactura(new Integer(codTPI), ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN);
									
									EquivMonto equivMonto = certiOrigenService.consultarMontoEquivalente(codMoneda, listCertOrigSerie.get(0).getFecCert());							
									if (equivMonto != null && SunatNumberUtils.isGreaterThanZero(equivMonto.getMtoequiv()) ){
										
										BigDecimal mtoCalculadoEUR = SunatNumberUtils.divide(SunatNumberUtils.multiply(mtoTopeEUR,mtofobmon),equivMonto.getMtoequiv(),3);															
										mtoTotFactEURAcumulado = SunatNumberUtils.sum(mtoTotFactEURAcumulado,mtoCalculadoEUR);
									} else{

										/*INICIO-P34 PAS20165E220200126 AFMA*/
										EquivMonto equivMontoSinVigencia = certiOrigenService.consultarMontoEquivalente(codMoneda, SunatDateUtils.getDefaultDate());
										if(equivMontoSinVigencia!=null){

											throw new IllegalArgumentException("Serie: ["+correlSerie.getNumeroSerieFA()+"] No existe registro vigente para el c�digo de moneda ["+codMoneda+"] consignado en el Certificado de Origen ["+certifiorigen.getNumCert()+"]");

										}
										/*FIN-P34 PAS20165E220200126 AFMA*/
										BigDecimal factorConversionEUR = this.obtenerFactorConversionOtraMoneda(listCertOrigSerie.get(0).getCodMonfac(), ConstantesDataCatalogo.MONEDA_EUROS,listCertOrigSerie.get(0).getFecCert());
										if(factorConversionEUR==null){
											
											throw new IllegalArgumentException("NO ENCONTRO TIPO DE CAMBIO PARA CERTIFICADO DE ORIGEN ASOCIADO A LA SERIE [codiRegi=" + codiRegi + ", anoPrese=" + anoPrese + ", codiAduan= " + codiAduan + ", numeCorre= " + numeCorre + ", serie = " + correlSerie.getNumeroSerieFA() + "] A PESAR DE QUE ESTA REGISTRADA LA DUA... VERIFICAR ");
										}else{
											mtoTotFactEURAcumulado = SunatNumberUtils.sum(mtoTotFactEURAcumulado, SunatNumberUtils.multiply(factorConversionEUR, mtofobmon));
										}
									}
									
								}
								
							}
						//}
						
						
						//Se busca series y se acumula Mto FOB 
						
						if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
							Diseriesi seriesi = declaracionImpoConsumo.consultarSerieDeclaracionDefinitiva(anoPrese, codiAduan, numeCorre, correlSerie.getNumeroSerieFA(), codiAduan);
							if (seriesi == null) {
								throw new IllegalArgumentException("NO SE ENCONTRO SERIE [codiRegi=" + codiRegi + ", anoPrese=" + anoPrese + ", codiAduan= " + codiAduan + ", numeCorre= " + numeCorre + ", serie = " + correlSerie.getNumeroSerieFA() + "] A PESAR DE QUE ESTA REGISTRADA LA DUA... VERIFICAR EN EL ASIGAD");
							}
							String tpiSerie= seriesi.getConvInter().toString();
							if ((seriesi != null && !matchTPI &&(tpiSerie.equals(codTPI) || tpiSerie.equals("0"))) || (seriesi != null && matchTPI && tpiSerie.equals(codTPI))){
								
								mtoFOBAcumulado = SunatNumberUtils.sum(mtoFOBAcumulado,seriesi.getFobDolpol());
								BigDecimal factorConver = this.obtenerFactorConversionOtraMoneda(ConstantesDataCatalogo.MONEDA_DOLAR, ConstantesDataCatalogo.MONEDA_EUROS, SunatDateUtils.getDateFromInteger(seriesi.getFechIngsi()));
								mtoFOBAcumuladoEUR = SunatNumberUtils.sum( mtoFOBAcumuladoEUR, SunatNumberUtils.multiply(factorConver ,seriesi.getFobDolpol()));
								
							}
						}
					}
					 
				} else {
					continue;
				}
				
			} else{
				// Para declaraciones simplificadas no tiene Formato B
				//continue;
				anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),0,4);
				SimplificadaFormBCorr simpFormBCorrelacion = new SimplificadaFormBCorr();
				simpFormBCorrelacion.setCodigoAduana(codiAduan);
				simpFormBCorrelacion.setAnnoDeclaracion(anoPrese);
				simpFormBCorrelacion.setNumeroDeclaracion(numeCorre);
				simpFormBCorrelacion.setCodigoRegimen(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_DQ) ;//aqui es DQ
				simpFormBCorrelacion.setNombreProveedor(nombreProveedor);
				simpFormBCorrelacion.setPaisProveedor(paisProveedor);
//				simpFormBCorrelacion.setNumeroSerieI(new Short(numeSeriee.trim()));
				List<SimplificadaFormBCorr> listSeriesSimpProveedor = consultaFormatoBService.selectSeriesSimplificadaByDUAProveedor(simpFormBCorrelacion);
				if(CollectionUtils.isNotEmpty(listSeriesSimpProveedor)){
					for(SimplificadaFormBCorr simpFormbCorr :listSeriesSimpProveedor){
						// se busca el monto total factura en certifiorigen
						Certifiorigen certifiorigenSeries = new Certifiorigen();
						certifiorigenSeries.setCodAduanaDua(certifiorigen.getCodAduanaDua());
						certifiorigenSeries.setCodRegimenDua(certifiorigen.getCodRegimenDua());
						certifiorigenSeries.setAnnDua(certifiorigen.getAnnDua());
						certifiorigenSeries.setNumDua(certifiorigen.getNumDua());
						certifiorigenSeries.setCodAduanaDua(certifiorigen.getCodAduanaDua());
						certifiorigenSeries.setNumSerieDua(simpFormbCorr.getNumeroSerieI());
						//if(matchTPI ){
							List<Certifiorigen> listCertOrigSerie =  certificadoOrigen.consultarCertificadoOrigen(certifiorigenSeries);
							if(!CollectionUtils.isEmpty(listCertOrigSerie)){
								//de tener TPI solo considerar con tipo certificado cinco
								if(!listCertOrigSerie.get(0).getCodTipCert().equals(ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN)) continue;
								
								if(listCertOrigSerie.get(0).getValTotfac().compareTo(BigDecimal.ZERO)==0 || listCertOrigSerie.get(0).getCodMonfac().trim().equals("")){
									indTotalFactura= false;
								}
							}else{
								indTotalFactura= false;
							}
							
							if(indTotalFactura){
								//obtiene el valor total factura
								//OBTIENE EL EQUIVALENTE DE NO ENCONTRAR EQUIVALENTE 
								String codMoneda = listCertOrigSerie.get(0).getCodMonfac();
								BigDecimal mtofobmon = listCertOrigSerie.get(0).getValTotfac();
								if(codMoneda.equals(ConstantesDataCatalogo.MONEDA_EUROS)){
									mtoTotFactEURAcumulado = SunatNumberUtils.sum(mtoTotFactEURAcumulado, mtofobmon);
								}else{
									BigDecimal mtoTopeEUR = this.obtenerMontoTopeFactura(new Integer(codTPI), ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN);
									
									EquivMonto equivMonto = certiOrigenService.consultarMontoEquivalente(codMoneda, listCertOrigSerie.get(0).getFecCert());							
									if (equivMonto != null && SunatNumberUtils.isGreaterThanZero(equivMonto.getMtoequiv()) ){
										
										BigDecimal mtoCalculadoEUR = SunatNumberUtils.divide(SunatNumberUtils.multiply(mtoTopeEUR,mtofobmon),equivMonto.getMtoequiv(),3);															
										mtoTotFactEURAcumulado = SunatNumberUtils.sum(mtoTotFactEURAcumulado,mtoCalculadoEUR);
									} else{
										BigDecimal factorConversionEUR = this.obtenerFactorConversionOtraMoneda(listCertOrigSerie.get(0).getCodMonfac(), ConstantesDataCatalogo.MONEDA_EUROS,listCertOrigSerie.get(0).getFecCert());
										if(factorConversionEUR==null){
											
											throw new IllegalArgumentException("NO ENCONTRO TIPO DE CAMBIO PARA CERTIFICADO DE ORIGEN ASOCIADO A LA SERIE [codiRegi=" + codiRegi + ", anoPrese=" + anoPrese + ", codiAduan= " + codiAduan + ", numeCorre= " + numeCorre + ", serie = " + simpFormbCorr.getNumeroSerieI().toString() + "] A PESAR DE QUE ESTA REGISTRADA LA DUA... VERIFICAR ");
										}else{
											mtoTotFactEURAcumulado = SunatNumberUtils.sum(mtoTotFactEURAcumulado, SunatNumberUtils.multiply(factorConversionEUR, mtofobmon));
										}
									}
									
								}
								
							}
						//}
						//Se busca series y se acumula Mto FOB 
						if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA)) {
							anoPrese = anoPrese.substring(2);
							String numSerie =  SunatStringUtils.lpad(simpFormbCorr.getNumeroSerieI().toString(),4,' ');
							Seriesq seriesq  = declaracionImpoSimplificada.consultarSeriesDeclaracionSimplificada(anoPrese, codiAduan, numeCorre, numSerie, codiAduan);
							if (seriesq == null) {
								throw new IllegalArgumentException("NO SE ENCONTRO SERIE [codiRegi=" + codiRegi + ", anoPrese=" + anoPrese + ", codiAduan= " + codiAduan + ", numeCorre= " + numeCorre + ", serie = " + numSerie + "] A PESAR DE QUE ESTA REGISTRADA LA DUA... VERIFICAR EN EL ASIGAD");
							}
							
							String tpiSerie= seriesq!=null && seriesq.getConvInter()!=null? seriesq.getConvInter().toString(): "0";
							if ((seriesq != null && !matchTPI &&(tpiSerie.equals(codTPI) || tpiSerie.equals("0"))) || (seriesq != null && matchTPI && tpiSerie.equals(codTPI))){
								
								mtoFOBAcumulado = SunatNumberUtils.sum(mtoFOBAcumulado,seriesq.getFobDolpol());
								BigDecimal factorConver = this.obtenerFactorConversionOtraMoneda(ConstantesDataCatalogo.MONEDA_DOLAR, ConstantesDataCatalogo.MONEDA_EUROS, SunatDateUtils.getDateFromInteger(seriesq.getFechIngsi()));
								mtoFOBAcumuladoEUR = SunatNumberUtils.sum( mtoFOBAcumuladoEUR, SunatNumberUtils.multiply(factorConver ,seriesq.getFobDolpol()));
								
							}
						}
						
						
					}
				}
				
			}
		}
		
		mapTotales.put("mtoFOBAcumulado",mtoFOBAcumulado);
		//mapTotales.put("mtoTotFactUSDAcumulado",mtoTotFactUSDAcumulado);
		mapTotales.put("mtoTotFactEURAcumulado",mtoTotFactEURAcumulado);
		mapTotales.put("mtoFOBAcumuladoEUR", mtoFOBAcumuladoEUR);
		mapTotales.put("indTotalFactura",indTotalFactura);
		return mapTotales;
	}

	@ServicioAnnot(tipo="V",codServicio=3385, descServicio="Cuando el CO corresponda a una Declaracion de origen, se valida que el valor de factura en EUR o su equivalente no supere el monto maximo permitido por tipo de TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3385,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valMontoEURFacturaEnvioDeclaracion(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		CertiOrigenService certiOrigenService = fabricaDeServicios.getService("certiOrigenService");
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			BigDecimal mtofobmon = listCertificadoOrigen.get(0).getMtofobmon();		
			Integer codConvenio = serie.getCodconvinter();
			Date  fecemision = listCertificadoOrigen.get(0).getFecemision();
			Date  fecemisionCalculo = fecemision;
			//amancilla String numautoexp = listCertificadoOrigen.get(0).getNumautoexp();
			String numautoexp = listCertificadoOrigen.get(0).getNumautoexp()!=null?listCertificadoOrigen.get(0).getNumautoexp().trim():"";
			if (SunatStringUtils.isEmpty(numautoexp)) {
				if (SunatNumberUtils.isGreaterThanZero(mtofobmon)) {
					DatoOtroDocSoporte docSoporte = getDocSoportePorTipo (dua, serie, ConstantesDataCatalogo.TIPO_DOC_ASOCIADO_DOC_COMERCIAL);
					if (docSoporte != null) {
						String codmoneda = listCertificadoOrigen.get(0).getCodmoneda();
						Date fechaDocComercial = docSoporte.getFecdocasoc();
						BigDecimal mtoCalculadoEUR = BigDecimal.ZERO;
						//rtineo optimizacion
						BigDecimal mtoTopeFacturaEUR  = this.obtenerMontoTopeFactura(codConvenio, ConstantesAtributo.MTO_FACTURA_EUR_CERTIORIGEN,variablesIngreso);
						//fin optimizacion
						if (SunatStringUtils.isEqualTo(codmoneda,ConstantesDataCatalogo.MONEDA_EUROS)){
							mtoCalculadoEUR = mtofobmon;
						} else {
							if (codmoneda != null){
								EquivMonto equivMonto = certiOrigenService.consultarMontoEquivalente(codmoneda, fecemision);							
								if (equivMonto != null){
									//mtoCalculadoEUR = SunatNumberUtils.multiply(SunatNumberUtils.divide(mtoTopeFacturaEUR, equivMonto.getMtoequiv(),3),mtofobmon);
									mtoTopeFacturaEUR = equivMonto.getMtoequiv();
									mtoCalculadoEUR = mtofobmon;
									fecemisionCalculo = fecemision;
								} else{
									BigDecimal mtoFactorConverEUR = this.obtenerFactorConversionOtraMoneda(codmoneda, ConstantesDataCatalogo.MONEDA_EUROS, fechaDocComercial);
									if (mtoFactorConverEUR!=null) {
									mtoCalculadoEUR = SunatNumberUtils.multiply(mtofobmon, mtoFactorConverEUR) ;
										fecemisionCalculo = fechaDocComercial;
									} else {
										listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30813",new String[] {serie.getNumserie().toString(), codmoneda});
									}
								}
							}
						}
						if (SunatNumberUtils.isGreaterThanParam(mtoCalculadoEUR, mtoTopeFacturaEUR)){

							listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30725",new String[] {serie.getNumserie().toString(), mtoTopeFacturaEUR.toString(), codmoneda, mtoCalculadoEUR.toString(),SunatDateUtils.getFormatDate(fecemisionCalculo, "dd/MM/yyyy") });
						}
					}
				}
			}
		}
		return listError;
	}
	
	
	
	
	@ServicioAnnot(tipo="V",codServicio=3386, descServicio="Cuando el CO corresponda a una Declaracion de origen, se valida que no exista una DUA o DSI a nivel nacional con los datos del certificado y factura")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3386,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public List<Map<String, String>> valUsoCOPorTipoFactura(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		ConsultaCertificadoOrigenService certificadoOrigen = fabricaDeServicios.getService("sigad.ingreso.ConsultaCertificadoOrigenService");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		Declaracion declaracionDB= (Declaracion)variablesIngreso.get("declaracionDB");
		
		String tipoDocumento = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		String numeroDocumento = dua.getDeclarante().getNumeroDocumentoIdentidad();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			List<Certifiorigen> listcertifiorigen = new ArrayList<Certifiorigen>();
			Certifiorigen certifiorigenparam = new Certifiorigen();
			certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_CONSUMO);
			//certifiorigenparam.setNumFactu(getNumFactura(dua, serie)); //jenciso RIN 05 ya no se compara 
			certifiorigenparam.setNumCert(listCertificadoOrigen.get(0).getNumdocumento());
			certifiorigenparam.setFecCert(listCertificadoOrigen.get(0).getFecemision());
			certifiorigenparam.setCodTpi(serie.getCodconvinter().toString());
			certifiorigenparam.setCodTipCert(codTipoCO);
			certifiorigenparam.setCodTipDocimpor(tipoDocumento);//jenciso rin05
			certifiorigenparam.setNumDocimpor(numeroDocumento);////jenciso rin05
			//certifiorigenparam.setNomEmisor(listCertificadoOrigen.get(0).getNomemisorCO());
			
			listcertifiorigen = certificadoOrigen.consultarCertificadoOrigen(certifiorigenparam);
			certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA);
			listcertifiorigen.addAll(certificadoOrigen.consultarCertificadoOrigen(certifiorigenparam));
			if (CollectionUtils.isNotEmpty(listcertifiorigen)){				
				for (Certifiorigen certifiorigen : listcertifiorigen) {
					
					if(declaracionDB==null){
					//Verificamos si el nombre del emisor es el mismo, sin considerar mayusculas y minusculas, se usa SunatStringUtils.isEqualTo
					String NomEmisorDua = listCertificadoOrigen.get(0).getNomemisorCO();
					String NomEmisorCertifi = certifiorigen.getNomEmisor();
					if (SunatStringUtils.isEqualTo(NomEmisorDua, NomEmisorCertifi)){
                                            //verifica el manifiesto de la DUA sea el mismo que el que se transmite
						if(manifiestoCertiOrigenEqualToTransmitido(certifiorigen, dua)){						
						String numdeclaracion = certifiorigen.getCodAduanaDua().concat("-").concat(certifiorigen.getAnnDua()).concat("-").concat(certifiorigen.getCodRegimenDua()).concat("-").concat(certifiorigen.getNumDua()).concat("-").concat(certifiorigen.getNumSerieDua().toString());
//						listError.add(catalogoHelper.getErrorMap("30697", new String[] {serie.getNumserie().toString(),listCertificadoOrigen.get(0).getNumdocumento(), numdeclaracion}));
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30697",new String[] {serie.getNumserie().toString(),listCertificadoOrigen.get(0).getNumdocumento(), numdeclaracion}));
					}
					}
					} else {
						//Verificamos si el nombre del emisor es el mismo, sin considerar mayusculas y minusculas, se usa SunatStringUtils.isEqualTo
						String NomEmisorDua = listCertificadoOrigen.get(0).getNomemisorCO();
						String NomEmisorCertifi = certifiorigen.getNomEmisor();
						String numdeclaracion = certifiorigen.getCodAduanaDua().concat("-").concat(certifiorigen.getAnnDua()).concat("-").concat(certifiorigen.getCodRegimenDua()).concat("-").concat(certifiorigen.getNumDua()).concat("-").concat(certifiorigen.getNumSerieDua().toString());
						String numdeclaracionEnvia = declaracionDB.getCodaduana().toString().concat("-").concat(declaracionDB.getDua().getAnnpresen().toString()).concat("-").concat(declaracionDB.getDua().getCodregimen()).concat("-").concat(String.format("%06d", declaracionDB.getNumeroDeclaracion())).concat("-").concat(certifiorigen.getNumSerieDua().toString())  ;
						if ( !numdeclaracionEnvia.equals(numdeclaracion) && SunatStringUtils.isEqualTo(NomEmisorDua, NomEmisorCertifi)){
							
//							listError.add(catalogoHelper.getErrorMap("30697", new String[] {serie.getNumserie().toString(),listCertificadoOrigen.get(0).getNumdocumento(), numdeclaracion}));
							listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30697",new String[] {serie.getNumserie().toString(),listCertificadoOrigen.get(0).getNumdocumento(), numdeclaracion}));
						}
						
					}
				}
			}
		}
		return listError;
	}
	
	private boolean manifiestoCertiOrigenEqualToTransmitido(Certifiorigen certifiorigen, DUA dua){
		ConsultaDeclaracionImpoConsumoService declaracionImpoConsumo = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
		ConsultaDeclaracionImpoSimplificadaService declaracionImpoSimplificada = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoSimplificadaService");
		String cadumanif = new String(dua.getManifiesto().getCodaduamanif());
		String annomanif = new String(dua.getManifiesto().getAnnmanif().substring(0, 4));
		String numemanif = new String(dua.getManifiesto().getNummanif());
		
		
		String codiAduan  = certifiorigen.getCodAduanaDua();
		String anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),2,4);;					
		String codiRegi   = certifiorigen.getCodRegimenDua();
		String numeCorre  = SunatStringUtils.lpad(certifiorigen.getNumDua(),6,'0');
		
		//String numeSeriee = SunatStringUtils.lpad(certifiorigen.getNumSerieDua().toString(),4,' ');
						
		String cadumanifref = new String();
		String annomanifref = new String();
		String numemanifref = new String();
		
		if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
			Map<String, Object> paramsdua = new HashMap<String, Object>();
			paramsdua.put("CODIADUAN", codiAduan);
			paramsdua.put("ANOPRESE", anoPrese);
			paramsdua.put("NUMECORRE", numeCorre);
			Map<String, Object> declaracionSigad = declaracionImpoConsumo.consultarDeclaracionImportacionConsumo(paramsdua, codiAduan);
			if (declaracionSigad != null){
				cadumanifref = declaracionSigad.get("CADU_MANIF").toString();
				annomanifref = declaracionSigad.get("FECHAMANIF").toString();
				numemanifref = declaracionSigad.get("NUME_MANIF").toString();							
			} else {
				return false;
			}
			// Para declaraciones simplificadas
		} else{
			
		    Polizaq polizaq = declaracionImpoSimplificada.consultarDeclaracionSimplificada(anoPrese, codiAduan, numeCorre, codiAduan);
		    if (polizaq != null){
		    	cadumanifref = polizaq.getCaduManif();
				annomanifref = polizaq.getFechManif();
				numemanifref = polizaq.getNumeManif().toString();							
		    } else {
		    	return false;
		    }
		}
		if (!cadumanif.equals(cadumanifref) ||  !annomanif.equals(annomanifref) || !numemanif.equals(numemanifref)){
			return false;
		}
		return true;
		
	}
	
	
	@ServicioAnnot(tipo="V",codServicio=3432, descServicio="Cuando el CO corresponda a una Declaracion de origen o No requiera certificado de origen, se valida que valor total cif de las DUA o DSI con igual importador, proveedor no supere al permitido")
	@ServInstDetAnnot(tipoRpta={1,1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3432,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")
	public List<Map<String, String>> valMontoImportadorProveedorPeriodo(Declaracion declaracion, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		ConsultaCertificadoOrigenService certificadoOrigen = fabricaDeServicios.getService("sigad.ingreso.ConsultaCertificadoOrigenService");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_DECLARACION_ORIGEN, ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF};
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		DUA  dua = declaracion.getDua();
		String tipoDocumento = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		String numeroDocumento = dua.getDeclarante().getNumeroDocumentoIdentidad();
		List<String> listaIdSeries = new ArrayList<String>();
		//List<DatoSerie> listaSerieAgrupada = new ArrayList<DatoSerie>();
		List<Map<String,Object>> listaSerieAgrupada = new ArrayList<Map<String,Object>>();
	
		//obtenemos series iguales en proveedor, importador para luego compararlos con duas numerados en los ultimos 30 dias
		List<String> serviciosTLC = new ArrayList<String>();

		for(DatoSerie serie: dua.getListSeries()){
			if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, serviciosTLC)){
				continue;
			}
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
			if(CollectionUtils.isEmpty(listCertificadoOrigen))continue;
			String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();
			if(SunatStringUtils.include(codTipoCO, arrayTipoCertificado )){
				Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion); 
				if(proveedor== null) continue;
				String nombreProveedor = proveedor.getNombreRazonSocial().trim().toUpperCase().toString(); 
				String paisProveedor = proveedor.getPais().getCodDatacat();
				//DatoSerie serieAgrupada = new DatoSerie();
				Map<String,Object> mapSerieAgrupada = new HashMap<String, Object>();
				List<DatoSerie> listSeries = new ArrayList<DatoSerie>();
				String idComparaSerie =   serie.getCodconvinter().toString().concat(codTipoCO).concat(tipoDocumento).concat(numeroDocumento);
				idComparaSerie = idComparaSerie.concat(nombreProveedor).concat(paisProveedor);
				if(!listaIdSeries.contains(idComparaSerie) ){
					listaIdSeries.add(idComparaSerie);
					mapSerieAgrupada.put("idComparaSerie", idComparaSerie);
					mapSerieAgrupada.put("mtoValAduana", serie.getMtovaladuana());
					mapSerieAgrupada.put("numSeries", serie.getNumserie().toString());
					mapSerieAgrupada.put("convInternacional", serie.getCodconvinter().toString());
					mapSerieAgrupada.put("tipoCertificado", codTipoCO);
					mapSerieAgrupada.put("nombreProveedor", nombreProveedor);
					mapSerieAgrupada.put("paisProveedor", paisProveedor);
					listSeries.add(serie);
					mapSerieAgrupada.put("listSeries", listSeries);
					
					//serieAgrupada.setNumpartnandi(serie.getNumpartnandi());
					//listaSerieAgrupada.add(serieAgrupada);
					listaSerieAgrupada.add(mapSerieAgrupada);
				}else{
					//Iterator<DatoSerie> iterDatosSeries = listaSerieAgrupada.iterator();
					Iterator<Map<String,Object>> iterDatosSeries = listaSerieAgrupada.iterator();
					while(iterDatosSeries.hasNext()){
						mapSerieAgrupada = iterDatosSeries.next();
						
						//if (serieAgrupada.getValindcodlib().equals(idComparaSerie)){
						if (mapSerieAgrupada.get("idComparaSerie").equals(idComparaSerie)){
							
							mapSerieAgrupada.put("mtoValAduana", SunatNumberUtils.sum(new BigDecimal(mapSerieAgrupada.get("mtoValAduana").toString()),serie.getMtovaladuana()));
							mapSerieAgrupada.put("numSeries", mapSerieAgrupada.get("numSeries").toString().concat(",").concat(serie.getNumserie().toString()));
							//mapSerieAgrupada.put("convInternacional", serie.getCodconvinter().toString());
							listSeries = (List<DatoSerie>)mapSerieAgrupada.get("listSeries"); 
							listSeries.add(serie);
							mapSerieAgrupada.put("listSeries", listSeries);
							
							break;
						}
					}
					
				}
			}
		}
		//para las series encontradas se verifica si existe en DUAs DSI a nivel nacional
		if(!CollectionUtils.isEmpty(listaSerieAgrupada)){
			for(Map<String,Object> mapSerie:listaSerieAgrupada){
				List<Certifiorigen>listcertifiorigen = new ArrayList<Certifiorigen>();
				String codConvenio = mapSerie.get("convInternacional").toString();
				
				Certifiorigen certifiorigenparam = new Certifiorigen();
				certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_CONSUMO);
				certifiorigenparam.setCodTipDocimpor(tipoDocumento);
				certifiorigenparam.setNumDocimpor(numeroDocumento);
				certifiorigenparam.setCodTipCert(mapSerie.get("tipoCertificado").toString());
				certifiorigenparam.setCodTpi(codConvenio);
				//certifiorigenparam.setNomProveedor(mapSerie.get("nombreProveedor").toString());
				
				String fechaHoy = SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy");
				certifiorigenparam.setFechaAcoTpiCompare(SunatDateUtils.addDay(SunatDateUtils.getDate(fechaHoy, "dd/MM/yyyy"), -30)); 
				
				listcertifiorigen = certificadoOrigen.consultarCertificadoOrigen(certifiorigenparam);
				//simplificada si tiene formato B proveedor
				certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA);
				certifiorigenparam.setCodDocDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_18_13);
				listcertifiorigen.addAll(certificadoOrigen.consultarCertificadoOrigen(certifiorigenparam));
				
				if (CollectionUtils.isNotEmpty(listcertifiorigen)){


					/*INICIO-P34 PAS20165E220200126 AFMA*/
					String codigoTransaccion = variablesIngreso.get("codTransaccion")!=null?variablesIngreso.get("codTransaccion").toString():"";
					boolean quitarDuaRectificada = false;
					if("1019".equals(codigoTransaccion))quitarDuaRectificada = true;
					//se obtiene las duas
					BigDecimal mtoCifAcumulado = this.calcularMtoCifImpoProveedorFactura(dua, listcertifiorigen, mapSerie.get("nombreProveedor").toString(), mapSerie.get("paisProveedor").toString(), true, 30,quitarDuaRectificada,declaracion);
/*FIN-P34 PAS20165E220200126 AFMA*/



				
					List<DatoSerie> listSeries = (List<DatoSerie>)mapSerie.get("listSeries");
					if(SunatNumberUtils.isGreaterThanZero(mtoCifAcumulado) || listSeries.size()>1 ){
						//si no hay DUAs a nivel nacional y solo hay una serie en la DUA se valida en el metodo individual
						mtoCifAcumulado = SunatNumberUtils.sum(mtoCifAcumulado, new BigDecimal(mapSerie.get("mtoValAduana").toString()));
						BigDecimal mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
								ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
								ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
						if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
							//IMPORTACI�N DE VARIAS MERCANC�AS SUPERAN LOS ({0}) D�LARES, REQUIERE CERTIFICADO DE ORIGEN, MONTO ACUMULADO: ({1}) , INCLUYE SERIES TRANSMITIDAS: ({2})
							listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30911",new String[] { mtoTopeCif.toString(), mtoCifAcumulado.toString(), mapSerie.get("numSeries").toString()}));
					}
				}
			}
		}
		}
		
		
		
		return listError;

	}
	
	//jenciso ya no se usa
	@ServicioAnnot(tipo="V",codServicio=3387, descServicio="Cuando no se requiere un CO, se valida que no exista una DUA o DSI a nivel nacional con los datos del certificado, factura y manifiesto y que no supere el monto establecido para el TLC")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3387,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen")
	public Map<String, String> valUsoCOPorTipoManifiesto(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ConsultaCertificadoOrigenService certificadoOrigen = fabricaDeServicios.getService("sigad.ingreso.ConsultaCertificadoOrigenService");
		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		String codTransaccion = variablesIngreso.get("codTransaccion")!=null?variablesIngreso.get("codTransaccion").toString():" ";//cambios para PAS20155E220200192 TRX04
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			List<Certifiorigen> listcertifiorigen = new ArrayList<Certifiorigen>();
			Integer codConvenio = serie.getCodconvinter();
			
			Certifiorigen certifiorigenparam = new Certifiorigen();
			certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_CONSUMO);
			certifiorigenparam.setNumFactu(getNumFactura(dua, serie));
			certifiorigenparam.setCodTipDocimpor(dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());
			certifiorigenparam.setNumDocimpor(dua.getDeclarante().getNumeroDocumentoIdentidad());
			certifiorigenparam.setCodTipCert(ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF);
			certifiorigenparam.setCodTpi(codConvenio.toString());
			
			listcertifiorigen = certificadoOrigen.consultarCertificadoOrigen(certifiorigenparam);
			certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA);
			
			listcertifiorigen.addAll(certificadoOrigen.consultarCertificadoOrigen(certifiorigenparam));
			if (CollectionUtils.isNotEmpty(listcertifiorigen)){
				
				/**Inicio cambios PAS20155E220200172 TPI 814**/
				String codigoTransaccion = variablesIngreso.get("codTransaccion")!=null?variablesIngreso.get("codTransaccion").toString():" ";
				BigDecimal mtoCifAcumulado;
				/*reordenado para tener las series del XML que cumplen y descartar*/
				Map<String,Object> mapRespuesta = this.calcularMtoCifFactura(serie, codTipoCO, null, null, false,null,null,false,null);
				BigDecimal mtoCifAcumuladoXML = SunatNumberUtils.toBigDecimal(mapRespuesta.get("mtoValAduanaAcumulado"));
			
				if(!codigoTransaccion.endsWith(Constants.COD_TRANSAC_NUMERACION)){
					variablesIngreso.put("serieTrxRectiRegu", SunatStringUtils.lpad(serie.getNumserie().toString(),4,' '));		
					variablesIngreso.put("lstSeriesXMLCumpleCond",mapRespuesta.get("numSeries"));
					mtoCifAcumulado = this.calcularMtoCifSinCO(dua,listcertifiorigen, variablesIngreso);
				}else{
					mtoCifAcumulado = this.calcularMtoCifSinCO(dua,listcertifiorigen);
				}
				/**Fin cambios PAS20155E220200172 TPI 814**/
				/*reorden
				Map<String,Object> mapRespuesta = this.calcularMtoCifFactura(serie, codTipoCO, null, null, false,null,null,false,null);
				BigDecimal mtoCifAcumuladoXML = SunatNumberUtils.toBigDecimal(mapRespuesta.get("mtoValAduanaAcumulado"));
				*/
				mtoCifAcumulado = SunatNumberUtils.sum(mtoCifAcumulado, mtoCifAcumuladoXML);
				BigDecimal mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
				if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
					
					/**Inicio de cambios para PAS20155E220200192 TRX04**/
					if(codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION)){
						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35627",new String[] {serie.getNumserie().toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
					}else{
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30718",new String[] {serie.getNumserie().toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
					}/**Fin de cambios para PAS20155E220200192 TRX04**/
				}				
			}
		}
		return listError;
	}

	//adicionado en PAS20155E220200172 TPI 814  - por considerar los casos de regu o recti con el mismo DAM como dam acumulada
	private BigDecimal calcularMtoCifSinCO(DUA dua,List<Certifiorigen> listcertifiorigen) {
		return calcularMtoCifSinCO( dua, listcertifiorigen, null);
	}

	@ServicioAnnot(tipo="V",codServicio=3431, descServicio="Cuando no se requiere un CO, se valida que no exista una DUA o DSI a nivel nacional con los datos del certificado, factura , proveedor , importador y que no supere el monto establecido para el TLC")
	@ServInstDetAnnot(tipoRpta={0,1,1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3431,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie")
	public Map<String, String> valUsoCOPorTipoFacturaProveedor(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia, Declaracion declaracion) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		ConsultaCertificadoOrigenService certificadoOrigen = fabricaDeServicios.getService("sigad.ingreso.ConsultaCertificadoOrigenService");
//		
		String[] arrayTipoCertificado = new String []{ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF};
		Map<String, String> listError = new HashMap<String, String>();
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {			
			List<Certifiorigen> listcertifiorigen = new ArrayList<Certifiorigen>();
			Integer codConvenio = serie.getCodconvinter();
			
			//jenciso igual tpi, num factura, fecha factura, proveedo nombre y pais, codigo y numero del importador
			
			Certifiorigen certifiorigenparam = new Certifiorigen();
			certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_CONSUMO);
			certifiorigenparam.setNumFactu(getNumFactura(dua, serie));
			certifiorigenparam.setFecFactu(this.getDatoFacturaRef(dua, serie).getFecfactura());
			certifiorigenparam.setCodTipDocimpor(dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat());
			certifiorigenparam.setNumDocimpor(dua.getDeclarante().getNumeroDocumentoIdentidad());
			//certifiorigenparam.setCodTipCert(ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF);
			certifiorigenparam.setCodTpi(codConvenio.toString());
			Participante prov = this.getProveedorCorrespondiente(serie, declaracion);
			String nombrePoveedor = "";
			String paisProveedor = "";
			if(prov==null) return listError;
			else{
				nombrePoveedor= prov.getNombreRazonSocial();
				paisProveedor = prov.getPais().getCodDatacat();
			}
						
			listcertifiorigen = certificadoOrigen.consultarCertificadoOrigen(certifiorigenparam);
			// simplificada si tiene formato Bs
			certifiorigenparam.setCodRegimenDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA);
			certifiorigenparam.setCodDocDua(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_18_13);
			listcertifiorigen.addAll(certificadoOrigen.consultarCertificadoOrigen(certifiorigenparam));
						
			if (CollectionUtils.isNotEmpty(listcertifiorigen)){
				
/*INICIO-P34 PAS20165E220200126 AFMA*/
				String codigoTransaccion = variablesIngreso.get("codTransaccion")!=null?variablesIngreso.get("codTransaccion").toString():"";
				boolean quitarDuaRectificada = false;
				if("1019".equals(codigoTransaccion))quitarDuaRectificada = true;
				BigDecimal mtoCifAcumulado = this.calcularMtoCifImpoProveedorFactura(dua,listcertifiorigen, nombrePoveedor, paisProveedor, false, 0,quitarDuaRectificada,declaracion);
/*FIN-P34 PAS20165E220200126 AFMA*/
				Map<String,Object> mapRespuesta = this.calcularMtoCifFactura(serie, codTipoCO, null, null, false,nombrePoveedor, paisProveedor, true, declaracion);
				BigDecimal mtoCifAcumuladoXML = SunatNumberUtils.toBigDecimal(mapRespuesta.get("mtoValAduanaAcumulado"));
				int contador = Integer.parseInt(mapRespuesta.get("contador").toString());
				// Si solo existe una coincidencia y monto a nivel nacional es 0 no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual
				if (SunatNumberUtils.isLessOrEqualsThanParam(contador,1) && SunatNumberUtils.isEqualToZero(mtoCifAcumulado) ) 
					mtoCifAcumuladoXML = BigDecimal.ZERO;
				mtoCifAcumulado = SunatNumberUtils.sum(mtoCifAcumulado, mtoCifAcumuladoXML);
				BigDecimal mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
				if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30718",new String[] {serie.getNumserie().toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
				}				
			}
		}
		return listError;
	}
	
	
	private BigDecimal calcularMtoCifImpoProveedorFactura(DUA dua, List<Certifiorigen> listcertifiorigen,
															   String nombreProveedor, String paisProveedor,
															   boolean flagPeriodo, int dias){

		return calcularMtoCifImpoProveedorFactura(dua, listcertifiorigen, nombreProveedor, paisProveedor, flagPeriodo, dias, false,null);
	}

	private BigDecimal calcularMtoCifImpoProveedorFactura(DUA dua, List<Certifiorigen> listcertifiorigen, String nombreProveedor, String paisProveedor, boolean flagPeriodo, int dias,boolean quitarDuaRectificada,Declaracion decla){
		ConsultaDeclaracionImpoConsumoService declaracionImpoConsumo = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
		ConsultaDeclaracionImpoSimplificadaService declaracionImpoSimplificada = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoSimplificadaService");
		ConsultaFormatoBService consultaFormatoBService = fabricaDeServicios.getService("sigad.despacho.entrada.service.consultaFormatoBService");
		BigDecimal mtoCIFAcumulado = BigDecimal.ZERO; 
		
		for (Certifiorigen certifiorigen : listcertifiorigen) {
			String codiAduan  = certifiorigen.getCodAduanaDua();
			String anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),2,4);				
			String codiRegi   = certifiorigen.getCodRegimenDua();
			String numeCorre  = SunatStringUtils.lpad(certifiorigen.getNumDua(),6,'0');
			String numeSeriee = SunatStringUtils.lpad(certifiorigen.getNumSerieDua().toString(),4,' ');
/*INICIO-P34 PAS20165E220200126 AFMA*/
			if(quitarDuaRectificada
					&& codiAduan.equals(decla.getNumdeclRef().getCodaduana())
					&& certifiorigen.getAnnDua().equals(decla.getNumdeclRef().getAnnprese())
					&& codiRegi.equals(decla.getNumdeclRef().getCodregimen())
					&& certifiorigen.getNumDua().equals(decla.getNumeroDeclaracion().toString())){

				continue;
			}
/*FIN-P34 PAS20165E220200126 AFMA*/

			if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){				
			
				FormBCorr formBCorrelacion = new FormBCorr();
				formBCorrelacion.setCodigoAduana(codiAduan);
				formBCorrelacion.setAnnoDeclaracion(anoPrese);
				formBCorrelacion.setNumeroDeclaracion(numeCorre);
				formBCorrelacion.setCodigoRegimen(codiRegi) ;
				formBCorrelacion.setNombreProveedor(nombreProveedor);
				formBCorrelacion.setCodigoPais(paisProveedor);
				formBCorrelacion.setNumeroSerieFA(numeSeriee);
				List<FormBCorr>  listSeriesProveedor = consultaFormatoBService.selectSeriesByDUAProveedor(formBCorrelacion);
				if(CollectionUtils.isNotEmpty(listSeriesProveedor)){
					//Se busca series y se acumula MotCif = acum + fob + flete + seguro
					Diseriesi seriesi = declaracionImpoConsumo.consultarSerieDeclaracionDefinitiva(anoPrese, codiAduan, numeCorre, numeSeriee, codiAduan);	
					if (seriesi != null){
						if(flagPeriodo){
							//se valida que la dua sea de los ultimos 30 d�as
							String fechaHoy = SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy");
							
							if(SunatDateUtils.esFecha1MayorIgualQueFecha2(SunatDateUtils.addDay(SunatDateUtils.getDateFromInteger(seriesi.getFechIngsi()), 30), SunatDateUtils.getDate(fechaHoy, "dd/MM/yyyy"), "COMPARA_SOLO_FECHA")){
								mtoCIFAcumulado = SunatNumberUtils.sum(SunatNumberUtils.sum(SunatNumberUtils.sum(mtoCIFAcumulado,seriesi.getFobDolpol()),seriesi.getSegDolar()),seriesi.getFleDolar());
							}		
						}else{
							mtoCIFAcumulado = SunatNumberUtils.sum(SunatNumberUtils.sum(SunatNumberUtils.sum(mtoCIFAcumulado,seriesi.getFobDolpol()),seriesi.getSegDolar()),seriesi.getFleDolar());
						}
					}
				}
				//simplificada  tiene formato B

			}else{
				anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),0,4);
				SimplificadaFormBCorr simpFormBCorrelacion = new SimplificadaFormBCorr();
				simpFormBCorrelacion.setCodigoAduana(codiAduan);
				simpFormBCorrelacion.setAnnoDeclaracion(anoPrese);
				simpFormBCorrelacion.setNumeroDeclaracion(numeCorre);
				simpFormBCorrelacion.setCodigoRegimen(ConstantesDataCatalogo.REG_IMPO_SIMPLIFICADA_DQ) ;//aqui es DQ
				simpFormBCorrelacion.setNombreProveedor(nombreProveedor);
				simpFormBCorrelacion.setPaisProveedor(paisProveedor);
				simpFormBCorrelacion.setNumeroSerieI(new Short(numeSeriee.trim()));
				List<SimplificadaFormBCorr> listSeriesSimpProveedor = consultaFormatoBService.selectSeriesSimplificadaByDUAProveedor(simpFormBCorrelacion);
				if(CollectionUtils.isNotEmpty(listSeriesSimpProveedor)){
					//si encuentra la serie con el mismo proveedor (nombre y pais) acumula cif verifica antes el periodo
					anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),2,4);
					Seriesq seriesq  = declaracionImpoSimplificada.consultarSeriesDeclaracionSimplificada(anoPrese, codiAduan, numeCorre, numeSeriee, codiAduan);
					if (seriesq != null){
						// FIXME: PAS20155E220100048
						// El monto CIF se obtiene del campo CIF_DOL_POL, debido a que el modulo de Importacion Simplificada (Fox) solo registra este campo
						// Teledespacho registra en los 3 campos que normalmente se usaban, y tambien el campo CIF_DOL_POL.
						if(flagPeriodo){
							//se valida que la dua sea de los ultimos 30 d�as
							String fechaHoy = SunatDateUtils.getCurrentFormatDate("dd/MM/yyyy");
							if(SunatDateUtils.esFecha1MayorIgualQueFecha2(SunatDateUtils.addDay(SunatDateUtils.getDateFromInteger(seriesq.getFechIngsi()), 30), SunatDateUtils.getDate(fechaHoy, "dd/MM/yyyy"), "COMPARA_SOLO_FECHA")){
								//mtoCIFAcumulado = SunatNumberUtils.sum(SunatNumberUtils.sum(SunatNumberUtils.sum(mtoCIFAcumulado,seriesq.getFobDolpol()),seriesq.getSegDolar()),seriesq.getFleDolar());
								mtoCIFAcumulado = SunatNumberUtils.sum(mtoCIFAcumulado,seriesq.getCifDolpol());
							}
						}else{
							//mtoCIFAcumulado = SunatNumberUtils.sum(SunatNumberUtils.sum(SunatNumberUtils.sum(mtoCIFAcumulado,seriesq.getFobDolpol()),seriesq.getSegDolar()),seriesq.getFleDolar());
							mtoCIFAcumulado = SunatNumberUtils.sum(mtoCIFAcumulado,seriesq.getCifDolpol());
						}
					}
				}
				
			}
			
				
			
		}
		return mtoCIFAcumulado;
	}
	
	
	
	
	
	/**
	 * ==================================================================================
	 * Metodos privados
	 * ==================================================================================
	 */
	
	//rtineo optimizacion
	/**
	 * Sobrecargamos el metodocon optimizacion
	 * @param serie
	 * @param arrayTipoCertificado
	 * @param variablesIngreso
	 * @return
	 */
	private Map<String, String> valMontoCIFPorSerie(DatoSerie serie, String[] arrayTipoCertificado, Map<String, Object> variablesIngreso) {
		//verificamos si es que podemos trabajar con variablesIngreso
		if (variablesIngreso == null) {
			//entonces ejecutamos el metodo con logica pesada 
			return valMontoCIFPorSerie(serie, arrayTipoCertificado);
		}
		//ejecutamos de forma optimizada
		Map<String, String> listError = new HashMap<String, String>();
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen = getCertiOrigen(dua, serie);
		String codTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();
		Integer codConvenio = serie.getCodconvinter();

		String codTransaccion = variablesIngreso.get("codTransaccion")!=null?variablesIngreso.get("codTransaccion").toString():" ";//cambios para PAS20155E220200192 TRX04
	
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			//verificamos si los atributos del grupo de tratados internacionales fueron cargados anteriormente
			Map<String, String> grupoTratadosInternacionales = (Map<String, String>) variablesIngreso.get("grupoTratadosInternacionales");
			BigDecimal mtoTopeCif = null;
			if (grupoTratadosInternacionales == null) {
				grupoTratadosInternacionales = cargarGrupoTratadosInternacionales(variablesIngreso);
			}
			mtoTopeCif = SunatNumberUtils.toBigDecimal(grupoTratadosInternacionales.get(codConvenio.toString()));
			BigDecimal mtoValAduana = serie.getMtovaladuana();
			Long numpartnandi = serie.getNumpartnandi();
			String codpaisorige = serie.getCodpaisorige();
			if (SunatNumberUtils.isGreaterThanParam(mtoValAduana, mtoTopeCif)){
//				listError = catalogoHelper.getErrorMap("30695", new String[] {serie.getNumserie().toString(), SunatStringUtils.toStringObj(numpartnandi), codpaisorige, mtoTopeCif.toString(), mtoValAduana.toString()});
				/**Inicio de cambios para PAS20155E220200192 TRX04**/
				if(codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION)){
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35626",new String[] {serie.getNumserie().toString(), SunatStringUtils.toStringObj(numpartnandi), codpaisorige, mtoTopeCif.toString(), mtoValAduana.toString()});
				}else{
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30695",new String[] {serie.getNumserie().toString(), SunatStringUtils.toStringObj(numpartnandi), codpaisorige, mtoTopeCif.toString(), mtoValAduana.toString()});
				}/**Fin de cambios para PAS20155E220200192 TRX04**/
			}
		}
		return listError;	
	}
	//fin optimizacion
	
	/**
	 * Valida que el monto de la serie no supere el monto maximo permitido para el TLC respectivo
	 * @param serie
	 * @param arrayTipoCertificado
	 * @return
	 */
	private Map<String, String> valMontoCIFPorSerie(DatoSerie serie, String[] arrayTipoCertificado ){
		Map<String, String> listError = new HashMap<String, String>();
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO 	   = listCertificadoOrigen.get(0).getCodtipoCO();
		Integer codConvenio = serie.getCodconvinter();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			BigDecimal mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));				
			BigDecimal mtoValAduana = serie.getMtovaladuana();
			Long numpartnandi = serie.getNumpartnandi();
			String codpaisorige = serie.getCodpaisorige();
			if (SunatNumberUtils.isGreaterThanParam(mtoValAduana, mtoTopeCif)){
//				listError = catalogoHelper.getErrorMap("30695", new String[] {serie.getNumserie().toString(), SunatStringUtils.toStringObj(numpartnandi), codpaisorige, mtoTopeCif.toString(), mtoValAduana.toString()});
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30695",new String[] {serie.getNumserie().toString(), SunatStringUtils.toStringObj(numpartnandi), codpaisorige, mtoTopeCif.toString(), mtoValAduana.toString()});
			}
		}
		return listError;	
	}
	
	//rtineo optimizacion
	private Map<String, String> valMontoCIFPorFactura(DatoSerie serie, String[] arrayTipoCertificado, boolean flagEmisor, Declaracion declaracion, boolean flagProveedor) {
		return valMontoCIFPorFactura(serie, arrayTipoCertificado, flagEmisor, declaracion, flagProveedor, null);
	}
	//fin optimizacion

	/**rtineo optimizacion Sobrecargamos el metodo
	 * Determina si el valor CIF considerando el numero de factura supera el valor tope determinado por cada tipo de TLC
	 * @param serie
	 * @param arrayTipoCertificado
	 * @param flagEmisor True: Valida el Emisor y Fecha de lo contrario solo Factura
	 * @return
	 */
	private Map<String, String> valMontoCIFPorFactura(DatoSerie serie, String[] arrayTipoCertificado, boolean flagEmisor, 
			Declaracion declaracion, boolean flagProveedor, Map<String, Object> variablesIngreso){
		Map<String, String> listError = new HashMap<String, String>();
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen)? null: listCertificadoOrigen.get(0).getCodtipoCO();		
		Integer codConvenio = serie.getCodconvinter();
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			String nomemisorCO = listCertificadoOrigen.get(0).getNomemisorCO();
			String nombreProveedor =  "";
			String paisProveedor = "";
			if(flagProveedor){
				Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion);
				nombreProveedor= proveedor.getNombreRazonSocial();
				paisProveedor = proveedor.getPais().getCodDatacat();
			}
					
			Map<String,Object> mapRespuesta = this.calcularMtoCifFactura(serie, codTipoCO, fecemision, nomemisorCO, flagEmisor, nombreProveedor, paisProveedor, flagProveedor, declaracion);
			BigDecimal mtoCifAcumulado = SunatNumberUtils.toBigDecimal(mapRespuesta.get("mtoValAduanaAcumulado"));
			int contador = Integer.parseInt(mapRespuesta.get("contador").toString());
			// Si solo existe una coincidencia  no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual
			if (SunatNumberUtils.isLessOrEqualsThanParam(contador,1)  ) mtoCifAcumulado = BigDecimal.ZERO;
			
			//rtineo optimizacion, verificamos si los grupos de tratados internacionales fueron cargados anteriormente
			BigDecimal mtoTopeCif = null;
			if(variablesIngreso != null){
				Map<String, String> grupoTratadosInternacionales = (Map<String, String>) variablesIngreso.get("grupoTratadosInternacionales");
				if (grupoTratadosInternacionales == null) {
					grupoTratadosInternacionales = cargarGrupoTratadosInternacionales(variablesIngreso);
				}
				mtoTopeCif = SunatNumberUtils.toBigDecimal(grupoTratadosInternacionales.get(codConvenio.toString()));
			}else{
				mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
						ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
						ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			}
			//fin optimizacion
			
			if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30717",new String[] {mapRespuesta.get("numSeries").toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
			}
		}
		return listError;
	}
	
	private Map<String, String> valMontoCIFPorFacturaProveedorConSinTPI(DatoSerie serie, String[] arrayTipoCertificado, Declaracion declaracion ){
		Map<String, String> listError = new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen)? null: listCertificadoOrigen.get(0).getCodtipoCO();		
		Integer codConvenio = serie.getCodconvinter();

		String codTransaccion = declaracion.getCodtipotrans(); //cambios para PAS20155E220200192 TRX04
		
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
//			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
//			String nomemisorCO = listCertificadoOrigen.get(0).getNomemisorCO();			
			String nombreProveedor =  "";
			String paisProveedor = "";
			Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion);
			if(proveedor!=null){
				nombreProveedor= proveedor.getNombreRazonSocial();
				paisProveedor = proveedor.getPais().getCodDatacat();
			}
			Map<String,Object> mapRespuesta = this.calcularMtoCifFacturaProveedorConSinTPI(serie, declaracion, nombreProveedor, paisProveedor);
			BigDecimal mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			BigDecimal mtoCifAcumulado = SunatNumberUtils.toBigDecimal(mapRespuesta.get("mtoValAduanaAcumulado"));
			if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
				/**Inicio de cambios para PAS20155E220200192 TRX04**/
				if(codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION)){
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35627",new String[] {mapRespuesta.get("numSeries").toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
				}else{
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30717",new String[] {mapRespuesta.get("numSeries").toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
			}
				
			}
		}
		return listError;
	}
	

	/**
	 * Valida el monto CIF por (Factura - Proveedor - TPI)
	 * @param serie
	 * @param arrayTipoCertificado
	 * @param declaracion
	 * @return
	 */
	private Map<String, String> valMontoCIFPorFacturaProveedorConTPI(DatoSerie serie, String[] arrayTipoCertificado, Declaracion declaracion, String codigoTPI){
		Map<String, String> listError = new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
		String codTipoCO = CollectionUtils.isEmpty(listCertificadoOrigen)? null: listCertificadoOrigen.get(0).getCodtipoCO();		
		Integer codConvenio = serie.getCodconvinter();

		String codTransaccion = declaracion.getCodtipotrans(); //cambios para PAS20155E220200192 TRX04  
		if (SunatStringUtils.include(codTipoCO, arrayTipoCertificado)) {
			String nombreProveedor =  "";
			String paisProveedor = "";
			Participante proveedor = this.getProveedorCorrespondiente(serie, declaracion);
			if(proveedor!=null){
				nombreProveedor= proveedor.getNombreRazonSocial();
				paisProveedor = proveedor.getPais().getCodDatacat();
			}
			
			Map<String,Object> mapRespuesta = this.calcularMtoCifFacturaProveedorConTPI(serie, declaracion, nombreProveedor, paisProveedor,codigoTPI);
			
			BigDecimal mtoTopeCif = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, 
					ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
					ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
			BigDecimal mtoCifAcumulado = SunatNumberUtils.toBigDecimal(mapRespuesta.get("mtoValAduanaAcumulado"));
			
			if (SunatNumberUtils.isGreaterThanParam(mtoCifAcumulado, mtoTopeCif)) {
				/**Inicio de cambios para PAS20155E220200192 TRX04**/
				if(codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION)){
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35627",new String[] {mapRespuesta.get("numSeries").toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
				}else{
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30717",new String[] {mapRespuesta.get("numSeries").toString(), mtoTopeCif.toString(), mtoCifAcumulado.toString()});
				}/**Fin de cambios para PAS20155E220200192 TRX04**/
			}
		}
		return listError;
	}
	
	
	/** 
	 * Calcula monto CIF por (Factura - Proveedor - TPI)
	 * @param serie
	 * @param codTipoCO
	 * @param fecemision
	 * @param nomemisorCO
	 * @param flagEmisor
	 * @param codigoTPI
	 * @return
	 */
	private Map<String,Object> calcularMtoCifFacturaProveedorConTPI(DatoSerie serie, Declaracion declaracion, String nombreProveedor, String paisProveedor, String codigoTPI){
		DUA dua = (DUA) serie.getPadre();
		Integer codConvenio   = serie.getCodconvinter();
		DatoFacturaref facturaRef = new DatoFacturaref();
		facturaRef = this.getDatoFacturaRef(dua, serie);
		String numFactura = facturaRef.getNumfactura();
		Date fechaFactura = facturaRef.getFecfactura();
		Map<String,Object> mapRespuesta = new HashMap<String, Object>();
		
		List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);//adicionado
		String codTipoCO = (listCertificadoOrigen.get(0).getCodtipoCO()).equals(ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF)?listCertificadoOrigen.get(0).getCodtipoCO():" ";//adicionado
		
		String idSerie = numFactura.concat(SunatDateUtils.getIntegerFromDate(fechaFactura).toString()).concat(nombreProveedor).concat(paisProveedor).concat(codTipoCO);
		String numSeries = 	"";
		BigDecimal mtoValAduanaAcumulado = BigDecimal.ZERO;
		Date fecha_default   = SunatDateUtils.getDefaultDate();//RN07 TPI814
		int contador = 0;
		
		// Si solo existe una coincidencia no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual (error 30695)
		for (DatoSerie serieRef : dua.getListSeries()) {
			// Solo debe considerar las series con el mismo TPI
			if (serieRef.getCodconvinter() == null || (serieRef.getCodconvinter() != null && !codigoTPI.equals(serieRef.getCodconvinter().toString()))){
				continue;
			}
						
			Integer serCodConvenio     = serieRef.getCodconvinter();
			BigDecimal serMtoValAduana = serieRef.getMtovaladuana();
			//String sernumFactura       = getNumFactura(dua, serieRef);	
			DatoFacturaref serFacturaRef = new DatoFacturaref();
			serFacturaRef = this.getDatoFacturaRef(dua, serieRef);
			String serNumFactura = serFacturaRef.getNumfactura()!=null?serFacturaRef.getNumfactura():" ";//RN07 TPI814;
			Date serFechaFactura = serFacturaRef.getFecfactura()!=null?serFacturaRef.getFecfactura():fecha_default;//RN07 TPI814

			String serNombProv = "";
			String serPaisProv = "";
			String serCodTipoCo = "";
			
			List<DatoAutocertificacion> listCertificadoOrigenRef=getCertiOrigen(dua, serieRef);//adicionado TPI814
			if(CollectionUtils.isEmpty(listCertificadoOrigenRef))continue;//adicionado TPI814
			
			for (  DatoSerieDocSoporte docSoporte: serieRef.getListSerieDocSoporte()){//adicionado TPI814
				if(docSoporte.getCodtipodocsoporte().equals("5") && 
						(listCertificadoOrigenRef.get(0).getCodtipoCO()!=null && ConstantesDataCatalogo.TIPO_NO_REQUIERE_CERTIF.equals(listCertificadoOrigenRef.get(0).getCodtipoCO()))){
					serCodTipoCo=listCertificadoOrigenRef.get(0).getCodtipoCO();
				}
				
			}
			Participante serProv = this.getProveedorCorrespondiente(serieRef, declaracion);
			if(serProv!=null){
				serNombProv = serProv.getNombreRazonSocial().trim();
				serPaisProv = serProv.getPais().getCodDatacat();
			}
			
			String idSerieRef = serNumFactura.concat(SunatDateUtils.getIntegerFromDate(serFechaFactura).toString()).concat(serNombProv).concat(serPaisProv).concat(serCodTipoCo);
			if(idSerie.equals(idSerieRef) && (serCodConvenio==null || SunatNumberUtils.isEqualToZero(serCodConvenio) || codConvenio.equals(serCodConvenio)  )){
				mtoValAduanaAcumulado =  SunatNumberUtils.sum(mtoValAduanaAcumulado, serMtoValAduana);
				contador++;
				if(numSeries.isEmpty())numSeries = serieRef.getNumserie().toString() ;
				else numSeries = numSeries.concat(",").concat(serieRef.getNumserie().toString());
			}
		}
		// Si solo existe una coincidencia no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual (error 30695)
		if (SunatNumberUtils.isLessOrEqualsThanParam(contador,1)) mtoValAduanaAcumulado = BigDecimal.ZERO;
		mapRespuesta.put("numSeries", numSeries);
		mapRespuesta.put("mtoValAduanaAcumulado", mtoValAduanaAcumulado);
		return mapRespuesta;
	}
	
	
	/**
	/**
	 * Calcula el monto CIF acumulado de todas las series de la dua que cumplen las condiciones de un determinado pais de origen, tipo de CO y subpartida nacional
	 * @param serie
	 * @param codTipoCO
	 * @return
	 */
	/**
	private BigDecimal calcularMtoCifSubpartida (DatoSerie serie, String codTipoCO){
		Integer codConvenio   = serie.getCodconvinter();
		String  codPaisorige  = serie.getCodpaisorige();		
		Long    numpartnandi  = serie.getNumpartnandi();
		BigDecimal mtoValAduanaAcumulado = BigDecimal.ZERO;
		DUA dua = (DUA) serie.getPadre();
		for (DatoSerie serieSub : dua.getListSeries()) {
			Integer serCodConvenio = serieSub.getCodconvinter();
			String  serCodPaisOrige = serieSub.getCodpaisorige();
			BigDecimal serMtoValAduana = serieSub.getMtovaladuana();
			Long serNumpartnandi = serieSub.getNumpartnandi();
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serieSub);
			if (!listCertificadoOrigen.isEmpty() && listCertificadoOrigen != null) {
				String serCodTipoCO = listCertificadoOrigen.get(0).getCodtipoCO();	
				if (serCodConvenio.equals(codConvenio)       && 
						serCodPaisOrige.equals(codPaisorige) && 
						serCodTipoCO.equals(codTipoCO)       && 
						SunatNumberUtils.isEqual(serNumpartnandi, numpartnandi)){
					mtoValAduanaAcumulado =  SunatNumberUtils.sum(mtoValAduanaAcumulado, serMtoValAduana);				
				}
			}
		}
		return mtoValAduanaAcumulado;
	}
	**/
	
	/**
	 * Determina el monto acumulado por factura y tipo de certificado
	 * @param serie
	 * @param codTipoCO
	 * @param flagEmisor: true:Valida emisor del CO, false: no valida datos de emisor solo factura
	 * @return
	 */
	private Map<String,Object> calcularMtoCifFactura (DatoSerie serie, String codTipoCO, Date fecemision, String nomemisorCO, boolean flagEmisor, String nombreProveedor, String paisProveedor, boolean flagProveedor, Declaracion declaracion){
		DUA dua = (DUA) serie.getPadre();
		Integer codConvenio   = serie.getCodconvinter();
		String  numFactura    = getNumFactura(dua, serie);
		BigDecimal mtoValAduanaAcumulado = BigDecimal.ZERO;
		DatoFacturaref facturaref = getDatoFacturaRef(dua, serie);
		int contador = 0;
		Map<String,Object> mapRespuesta = new HashMap<String, Object>();
		String numSeries = 	"";
		// Si solo existe una coincidencia no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual (error 30695)
		for (DatoSerie serieRef : dua.getListSeries()) {
			Integer serCodConvenio     = serieRef.getCodconvinter();
			BigDecimal serMtoValAduana = serieRef.getMtovaladuana();
			String sernumFactura       = getNumFactura(dua, serieRef);
			DatoFacturaref serFacturaref = getDatoFacturaRef(dua,serieRef);
			
			 
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serieRef);
			if (!listCertificadoOrigen.isEmpty() && listCertificadoOrigen != null) {
				String serCodTipoCO    = listCertificadoOrigen.get(0).getCodtipoCO();
				Integer serFecemision  = SunatDateUtils.getIntegerFromDate(listCertificadoOrigen.get(0).getFecemision());
				String serNomemisorCO  = listCertificadoOrigen.get(0).getNomemisorCO();
				
				if (flagEmisor) {
					if (SunatNumberUtils.isEqual(serCodConvenio,codConvenio)       && 
							SunatStringUtils.isEqualTo(serCodTipoCO,codTipoCO)     &&
							SunatStringUtils.isEqualTo(sernumFactura,numFactura)   &&
							SunatDateUtils.isEqualTo(serFacturaref.getFecfactura(), facturaref.getFecfactura())   &&//jenciso RIN05 
							SunatStringUtils.isEqualTo(serNomemisorCO,nomemisorCO) &&
							SunatNumberUtils.isEqual(serFecemision, SunatDateUtils.getIntegerFromDate(fecemision))){				
						mtoValAduanaAcumulado =  SunatNumberUtils.sum(mtoValAduanaAcumulado, serMtoValAduana);				
						contador++;
						if(numSeries.isEmpty())numSeries = serieRef.getNumserie().toString() ;
						else numSeries = numSeries.concat(",").concat(serieRef.getNumserie().toString());
					}		
				} else if(flagProveedor){
					Participante proveedor = this.getProveedorCorrespondiente(serieRef, declaracion);
					String serNombreProveedor = proveedor.getNombreRazonSocial();
					String serPaisProveedor = proveedor.getPais().getCodDatacat();
					
					if (SunatNumberUtils.isEqual(serCodConvenio,codConvenio)       && 
							SunatStringUtils.isEqualTo(serCodTipoCO,codTipoCO)     &&
							SunatStringUtils.isEqualTo(sernumFactura,numFactura)   &&
							SunatDateUtils.isEqualTo(serFacturaref.getFecfactura(), facturaref.getFecfactura())   &&//jenciso RIN05 
							SunatStringUtils.isEqualTo(serNombreProveedor,nombreProveedor) &&
							SunatStringUtils.isEqualTo(serPaisProveedor, paisProveedor)){				
						mtoValAduanaAcumulado =  SunatNumberUtils.sum(mtoValAduanaAcumulado, serMtoValAduana);
						contador++;
						if(numSeries.isEmpty())numSeries = serieRef.getNumserie().toString() ;
						else numSeries = numSeries.concat(",").concat(serieRef.getNumserie().toString());
					}		
				} else {
					if (SunatNumberUtils.isEqual(serCodConvenio,codConvenio)       && 
							SunatStringUtils.isEqualTo(serCodTipoCO,codTipoCO)     &&
							SunatDateUtils.isEqualTo(serFacturaref.getFecfactura(), facturaref.getFecfactura())   &&//jenciso RIN05
							SunatStringUtils.isEqualTo(sernumFactura,numFactura)){				
						mtoValAduanaAcumulado =  SunatNumberUtils.sum(mtoValAduanaAcumulado, serMtoValAduana);				
						contador++;
						if(numSeries.isEmpty())numSeries = serieRef.getNumserie().toString() ;
						else numSeries = numSeries.concat(",").concat(serieRef.getNumserie().toString());
					}						
				}
			}
					}						
		// Si solo existe una coincidencia no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual (error 30695)
		//jenciso deveulve el valor acumulado segun el metodo que lo llama ya no entrara al acumulado
		//if (SunatNumberUtils.isLessOrEqualsThanParam(contador,1)) mtoValAduanaAcumulado = BigDecimal.ZERO;
		mapRespuesta.put("numSeries", numSeries);
		mapRespuesta.put("mtoValAduanaAcumulado", mtoValAduanaAcumulado);
		mapRespuesta.put("contador", contador);
		return mapRespuesta;
		//return mtoValAduanaAcumulado;
				}
	
	/** 
	 * prueba
	 * @param serie
	 * @param codTipoCO
	 * @param fecemision
	 * @param nomemisorCO
	 * @param flagEmisor
	 * @return
	 */
	private Map<String,Object> calcularMtoCifFacturaProveedorConSinTPI(DatoSerie serie, Declaracion declaracion, String nombreProveedor, String paisProveedor){
		DUA dua = (DUA) serie.getPadre();
		Integer codConvenio   = serie.getCodconvinter();
		//String  numFactura    = getNumFactura(dua, serie);
		DatoFacturaref facturaRef = new DatoFacturaref();
		facturaRef = this.getDatoFacturaRef(dua, serie);
		String numFactura = facturaRef.getNumfactura();
		Date fechaFactura = facturaRef.getFecfactura();
		Map<String,Object> mapRespuesta = new HashMap<String, Object>();
//		String nombProv = "";
//		String paisProv = "";
//		Participante prov = this.getProveedorCorrespondiente(serie, declaracion);
//		if(prov!=null){
//			nombProv = prov.getNombreRazonSocial().trim();
//			paisProv = prov.getPais().getCodDatacat();
//		}
		String idSerie = numFactura.concat(SunatDateUtils.getIntegerFromDate(fechaFactura).toString()).concat(nombreProveedor).concat(paisProveedor);
		String numSeries = 	"";
		BigDecimal mtoValAduanaAcumulado = BigDecimal.ZERO;
		Date fecha_default   = SunatDateUtils.getDefaultDate();//RN07 TPI814
		int contador = 0;
		// Si solo existe una coincidencia no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual (error 30695)
		for (DatoSerie serieRef : dua.getListSeries()) {
			Integer serCodConvenio     = serieRef.getCodconvinter();
			BigDecimal serMtoValAduana = serieRef.getMtovaladuana();
			//String sernumFactura       = getNumFactura(dua, serieRef);	
			DatoFacturaref serFacturaRef = new DatoFacturaref();
			serFacturaRef = this.getDatoFacturaRef(dua, serieRef);
			String serNumFactura = serFacturaRef.getNumfactura()!=null?serFacturaRef.getNumfactura():" ";//RN07 TPI814
			Date serFechaFactura = serFacturaRef.getFecfactura()!=null?serFacturaRef.getFecfactura():fecha_default;//RN07 TPI814
			String serNombProv = "";
			String serPaisProv = "";
			Participante serProv = this.getProveedorCorrespondiente(serieRef, declaracion);
			if(serProv!=null){
				serNombProv = serProv.getNombreRazonSocial().trim();
				serPaisProv = serProv.getPais().getCodDatacat();
			}
			
			String idSerieRef = serNumFactura.concat(SunatDateUtils.getIntegerFromDate(serFechaFactura).toString()).concat(serNombProv).concat(serPaisProv);
//			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serieRef);
//			if (!listCertificadoOrigen.isEmpty() && listCertificadoOrigen != null) {
//				String serCodTipoCO    = listCertificadoOrigen.get(0).getCodtipoCO();
//			}
			if(idSerie.equals(idSerieRef) && (serCodConvenio==null || SunatNumberUtils.isEqualToZero(serCodConvenio) || codConvenio.equals(serCodConvenio)  )){
				mtoValAduanaAcumulado =  SunatNumberUtils.sum(mtoValAduanaAcumulado, serMtoValAduana);
				contador++;
				if(numSeries.isEmpty())numSeries = serieRef.getNumserie().toString() ;
				else numSeries = numSeries.concat(",").concat(serieRef.getNumserie().toString());
			}
		}
		// Si solo existe una coincidencia no debe considerarse como acumulado, ya que ese error se controla con la verificacion individual (error 30695)
		if (SunatNumberUtils.isLessOrEqualsThanParam(contador,1)) mtoValAduanaAcumulado = BigDecimal.ZERO;
		mapRespuesta.put("numSeries", numSeries);
		mapRespuesta.put("mtoValAduanaAcumulado", mtoValAduanaAcumulado);
		return mapRespuesta;
	}
	
	
	/**
	 * Obtiene el monto tope de la factura de acuerdo al tipo de moneda especificado en el atributo del catalogo 
	 * @param codConvenio
	 * @param atributoTipoMoneda
	 * @return
	 */
	private BigDecimal obtenerMontoTopeFactura(Integer codConvenio, String atributoTipoMoneda){
		//rtineo optimizacion
		return obtenerMontoTopeFactura(codConvenio,atributoTipoMoneda,null);
		//fin optimizacion
	}
	
	//rtineo optimziacion
	/**
	 * Obtiene el monto tope de la factura de acuerdo al tipo de moneda especificado en el atributo del catalogo 
	 * @param codConvenio
	 * @param atributoTipoMoneda
	 * @param variablesIngreso
	 * @return
	 */
	private BigDecimal obtenerMontoTopeFactura(Integer codConvenio, String atributoTipoMoneda, Map<String, Object> variablesIngreso) {
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		BigDecimal mtoTopeFactura = BigDecimal.ZERO;
		mtoTopeFactura = SunatNumberUtils.toBigDecimal(tpiService.obtenerAtributo(atributoTipoMoneda, 
				ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, 
				ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso));
		return mtoTopeFactura ;
	}
	//fin optimizacion
	
	/**
	 * Obtener el factor de conversion de una moneda X a otra moneda Y
	 * @param codmonedaOrigen : Moneda que declara el usuario
	 * @param codmonedaDestino : Moneda a convertir 
	 * @param fechacalculo : Fecha de referencia para el tipo de cambio
	 * @return
	 */
	private BigDecimal obtenerFactorConversionOtraMoneda(String codmonedaOrigen, String codmonedaDestino, Date fechacalculo){
		//rtineo optimizacion
		return obtenerFactorConversionOtraMoneda(codmonedaOrigen, codmonedaDestino, fechacalculo, null);
		//fin optimizacion
	}
	
	//rtineo optimizacion
	private BigDecimal obtenerFactorConversionOtraMoneda(String codmonedaOrigen, String codmonedaDestino, Date fechacalculo, Map<String,Object> variablesIngreso){
		//CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		BigDecimal mtofactorcalculado = BigDecimal.ZERO;
		if (codmonedaOrigen.equals(codmonedaDestino)){
			mtofactorcalculado = BigDecimal.ONE;
		} else {
			
			if (codmonedaDestino.equals(ConstantesDataCatalogo.MONEDA_DOLAR)){
				//Map<String, Object> mapCambio1 = catalogoHelper.getCatalogoAyudaService().getTipoCambio(codmonedaOrigen, fechacalculo);
				//Map<String, Object> mapCambio1 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getTipoCambio(codmonedaOrigen, fechacalculo);
				Map<String, Object> mapCambio1 = obtenerCambio(codmonedaOrigen,fechacalculo,variablesIngreso);
				BigDecimal pventaDestino = SunatNumberUtils.toBigDecimal(mapCambio1.get("pventa"));
				mtofactorcalculado = pventaDestino;
			} else if (codmonedaOrigen.equals(ConstantesDataCatalogo.MONEDA_DOLAR)) {
				//Map<String, Object> mapCambio1 = catalogoHelper.getCatalogoAyudaService().getTipoCambio(codmonedaDestino, fechacalculo);
				//Map<String, Object> mapCambio1 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getTipoCambio(codmonedaDestino, fechacalculo);
				Map<String, Object> mapCambio1 = obtenerCambio(codmonedaDestino,fechacalculo,variablesIngreso);
				BigDecimal pventaDestino = SunatNumberUtils.toBigDecimal(mapCambio1.get("pventa"));
				mtofactorcalculado = SunatNumberUtils.divide(BigDecimal.ONE,pventaDestino,6);
			} else {
				//Map<String, Object> mapCambio1 = catalogoHelper.getCatalogoAyudaService().getTipoCambio(codmonedaDestino, fechacalculo);
				//Map<String, Object> mapCambio1 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getTipoCambio(codmonedaDestino, fechacalculo);
				Map<String, Object> mapCambio1 = obtenerCambio(codmonedaDestino,fechacalculo,variablesIngreso);
				BigDecimal pventaDestino = SunatNumberUtils.toBigDecimal(mapCambio1.get("pventa"));
				//mapCambio1 = catalogoHelper.getCatalogoAyudaService().getTipoCambio(codmonedaOrigen, fechacalculo);
				//mapCambio1 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getTipoCambio(codmonedaOrigen, fechacalculo);
				mapCambio1 = obtenerCambio(codmonedaOrigen,fechacalculo,variablesIngreso);
				if (!mapCambio1.isEmpty()) {
				mtofactorcalculado = SunatNumberUtils.toBigDecimal(mapCambio1.get("pventa"));
				mtofactorcalculado = SunatNumberUtils.divide(mtofactorcalculado,pventaDestino,6);
				} else {
					mtofactorcalculado = null;
				}
			}
		}
		return mtofactorcalculado;
	}
	
	//rtineo optimizacion
	private Map<String, Object> obtenerCambio(String codigoMoneda, Date fechaCalculo, Map<String, Object> variablesIngreso) {
		Map<String, Object> mapCambio1 = null;
		if (variablesIngreso != null) {
			//entonces buscamos de variablesIngreso un posible cambio cargado anteriormente
			mapCambio1 = (Map<String, Object>) variablesIngreso.get("tipoCambio" + codigoMoneda);
			if (mapCambio1 == null) {
				//si aun no fue cargado... entonces buscamos el cambio
				mapCambio1 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getTipoCambio(codigoMoneda, fechaCalculo);
				//y lo almacenamos en variablesIngreso
				variablesIngreso.put("tipoCambio" + codigoMoneda, mapCambio1);
			}
		} else {
			//si es que no se envia variablesIngreso entonces se trabaja de la forma antigua
			mapCambio1 = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getTipoCambio(codigoMoneda, fechaCalculo);
		}
		return mapCambio1;
	}
	//fin optimizacion

	
	/**
	 * Determina el monto CIF de aquellas declaraciones de importacion al consumo y simplificado que numeraron para dicho importador con datos de manifiesto y factura iguales
	 * @param dua
	 * @param listcertifiorigen
	 * @return
	 */
	private BigDecimal calcularMtoCifSinCO(DUA dua, List<Certifiorigen> listcertifiorigen, Map<String, Object> variablesIngreso){
		ConsultaDeclaracionImpoConsumoService declaracionImpoConsumo = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
		ConsultaDeclaracionImpoSimplificadaService declaracionImpoSimplificada = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoSimplificadaService");
		
		BigDecimal mtoCIFAcumulado = BigDecimal.ZERO; 
		String cadumanif = new String(dua.getManifiesto().getCodaduamanif());
		String annomanif = new String(dua.getManifiesto().getAnnmanif().substring(0, 4));
		//String numemanif = new String(dua.getManifiesto().getNummanif());
		String numemanif="";
		if(dua.getManifiesto().getNummanif()==null || dua.getManifiesto().getNummanif().isEmpty() || " ".equals(dua.getManifiesto().getNummanif()) ){
			return mtoCIFAcumulado;
		}else{
			 numemanif = new String(dua.getManifiesto().getNummanif());
		}
		
		for (Certifiorigen certifiorigen : listcertifiorigen) {
			String codiAduan  = certifiorigen.getCodAduanaDua();
			String anoPrese   = SunatStringUtils.substring(certifiorigen.getAnnDua(),2,4);;					
			String codiRegi   = certifiorigen.getCodRegimenDua();
			String numeCorre  = SunatStringUtils.lpad(certifiorigen.getNumDua(),6,'0');
			String numeSeriee = SunatStringUtils.lpad(certifiorigen.getNumSerieDua().toString(),4,' ');
			String cadumanifref = new String();
			String annomanifref = new String();
			String numemanifref = new String();
			String numCorredoc = certifiorigen.getNumCorredoc().toString();//adicionado PAS20155E220200172
			String numCorredocref = dua.getNumcorredoc()!=null? dua.getNumcorredoc().toString():" ";//adicionado PAS20155E220200172
			String numDeclaracionref = variablesIngreso!=null && variablesIngreso.get("declaracion")!=null?SunatStringUtils.lpad(((Declaracion)variablesIngreso.get("declaracion")).getNumeroDeclaracion().toString(),6,'0'):" ";
			String numSerieref = variablesIngreso!=null && variablesIngreso.get("serieTrxRectiRegu")!=null?variablesIngreso.get("serieTrxRectiRegu").toString():" ";//adicionado PAS20155E220200172
			String numeroSeriesXML = variablesIngreso!=null && variablesIngreso.get("lstSeriesXMLCumpleCond")!=null?variablesIngreso.get("lstSeriesXMLCumpleCond").toString():"0";//adicionado PAS20155E220200172
			//BigDecimal mtoCIFSerie = (BigDecimal) (variablesIngreso!=null && variablesIngreso.get("mtoCIFSerie")!=null?variablesIngreso.get("mtoCIFSerie"):0);//adicionado PAS20155E220200172
			if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
				Map<String, Object> paramsdua = new HashMap<String, Object>();
				paramsdua.put("CODIADUAN", codiAduan);
				paramsdua.put("ANOPRESE", anoPrese);
				paramsdua.put("NUMECORRE", numeCorre);
				Map<String, Object> declaracionSigad = declaracionImpoConsumo.consultarDeclaracionImportacionConsumo(paramsdua, codiAduan);
				if (declaracionSigad != null){
					cadumanifref = declaracionSigad.get("CADU_MANIF").toString();
					annomanifref = declaracionSigad.get("FECHAMANIF").toString();
					numemanifref = declaracionSigad.get("NUME_MANIF").toString();							
				} else {
					continue;
				}
				// Para declaraciones simplificadas
			} else{
			    Polizaq polizaq = declaracionImpoSimplificada.consultarDeclaracionSimplificada(anoPrese, codiAduan, numeCorre, codiAduan);
			    if (polizaq != null){
			    	cadumanifref = polizaq.getCaduManif();
					annomanifref = polizaq.getFechManif();
					numemanifref = polizaq.getNumeManif().toString();							
			    } else {
			    	continue;
			    }
			}
			if (cadumanif.equals(cadumanifref) &&  annomanif.equals(annomanifref) && numemanif.equals(numemanifref)){
				String[] arraySeriesXMLCumple = numeroSeriesXML.split(",");
				//Se busca series y se acumula MotCif = acum + fob + flete + seguro
				if (codiRegi.equals(ConstantesDataCatalogo.REG_IMPO_CONSUMO)){
					Diseriesi seriesi = declaracionImpoConsumo.consultarSerieDeclaracionDefinitiva(anoPrese, codiAduan, numeCorre, numeSeriee, codiAduan);	
					if (seriesi != null){
						
						//Inicio de ajuste en PAS20155E220200172 por
						//mismo nro dam � mismo nro declaracion
						//si es la misma serie no suma el cambio con el dato anterior registrado
						//si es otra serie pero si figura registrada en el xml como acogida no se suma:
						boolean serieEstaAcogida = false;
						for(String numSerieXML : arraySeriesXMLCumple){
							//la serie de BD est� tambien en el XML acogida pero no es la serie actual que se est� verificando
							if(numSerieXML!="0" && numeSeriee.equals(SunatStringUtils.lpad(numSerieXML,4,' '))){
								serieEstaAcogida=true;
							}
						}
						if (numeSeriee.equals(numSerieref)){
							serieEstaAcogida=true;
						}
						
						if( ( (numCorredoc!="0" && numCorredoc.equals(numCorredocref)) || (numCorredoc.equals("0") && numeCorre.equals(numDeclaracionref)))
								&& serieEstaAcogida){
								mtoCIFAcumulado = SunatNumberUtils.sum(mtoCIFAcumulado, new BigDecimal(0));	
						}else{
							mtoCIFAcumulado = SunatNumberUtils.sum(SunatNumberUtils.sum(SunatNumberUtils.sum(mtoCIFAcumulado,seriesi.getFobDolpol()),seriesi.getSegDolar()),seriesi.getFleDolar());
						}
						//mtoCIFAcumulado = SunatNumberUtils.sum(SunatNumberUtils.sum(SunatNumberUtils.sum(mtoCIFAcumulado,seriesi.getFobDolpol()),seriesi.getSegDolar()),seriesi.getFleDolar());
						//Fin de ajuste en PAS20155E220200172
						
					}
				} else {
					Seriesq seriesq  = declaracionImpoSimplificada.consultarSeriesDeclaracionSimplificada(anoPrese, codiAduan, numeCorre, numeSeriee, codiAduan);
					if (seriesq != null){
						
						//Inicio de ajuste en PAS20155E220200172 por
						//mismo nro dam � mismo nro declaracion
						//si es la misma serie no suma el cambio con el dato anterior registrado
						//si es otra serie pero si figura registrada en el xml como acogida no se suma:
						boolean serieEstaAcogida = false;
						for(String numSerieXML : arraySeriesXMLCumple){
							//la serie de BD est� tambien en el XML acogida pero no es la serie actual que se est� verificando
							if(numSerieXML!="0" && numeSeriee.equals(SunatStringUtils.lpad(numSerieXML,4,' '))){
								serieEstaAcogida=true;
							}
						}
						if (numeSeriee.equals(numSerieref)){
							serieEstaAcogida=true;
						}
						
						if( ( (numCorredoc!="0" && numCorredoc.equals(numCorredocref)) || (numCorredoc.equals("0") && numeCorre.equals(numDeclaracionref)))
								&& serieEstaAcogida){
							mtoCIFAcumulado = SunatNumberUtils.sum(mtoCIFAcumulado, new BigDecimal(0));	
						}else{
							mtoCIFAcumulado = SunatNumberUtils.sum(SunatNumberUtils.sum(SunatNumberUtils.sum(mtoCIFAcumulado,seriesq.getFobDolpol()),seriesq.getSegDolar()),seriesq.getFleDolar());
						}
						//Fin de ajuste en PAS20155E220200172
						//mtoCIFAcumulado = SunatNumberUtils.sum(SunatNumberUtils.sum(SunatNumberUtils.sum(mtoCIFAcumulado,seriesq.getFobDolpol()),seriesq.getSegDolar()),seriesq.getFleDolar());
					}
				}
			}
		}
		return mtoCIFAcumulado;
	}
	
	//rtineo optimizacion
	private Map<String, String> cargarGrupoTratadosInternacionales(Map<String, Object> variablesIngreso) {
		//entonces cargamos los atributos
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, Object>> dataAtributos = catalogoAyudaService.getDataAtributos(ConstantesAtributo.MTO_SERIE_CERTIORIGEN, ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, null, null);
		Map<String, String> grupo = new HashMap<String, String>();
		for (Map<String, Object> dataAtributo : dataAtributos) {
			String valorAtributo = dataAtributo.get("val_atributo") == null ? null : dataAtributo.get("val_atributo").toString();
			// PAS20155E220100048
			grupo.put(dataAtributo.get("cod_datacat").toString(), valorAtributo);
		}
		variablesIngreso.put("grupoTratadosInternacionales", grupo);
		return grupo;
	}
	//fin optimizacion

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/		
}
