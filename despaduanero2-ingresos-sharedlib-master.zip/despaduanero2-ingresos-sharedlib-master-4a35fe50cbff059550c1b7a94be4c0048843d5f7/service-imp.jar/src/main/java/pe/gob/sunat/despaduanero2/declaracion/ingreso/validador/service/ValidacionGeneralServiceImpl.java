package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;//PAS20191U220200019
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.VehiculoService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciadonacion.ValTratamientoDonacionService;//P46
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.service.Datado2Service;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.util.Constantes;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.registro.model.bean.UsuarioSOLBean;
//import pe.gob.sunat.servicio2.registro.service.UsuarioService;

public class ValidacionGeneralServiceImpl extends ValDuaAbstract implements ValidacionGeneralService  {

	//private FabricaDeServicios fabricaDeServicios;
	//private AyudaService ayudaService;
	
	/*Adicionado para PAS20155E220000343**/
	private static final String CAT_MARG_PRORRATEO_SEG = "850";
	private static final String COD_MARG_PRORRATEO_SEG = "TOL_SEG";
	/*Adicionado para PAS20155E220000343**/
	private static final String TRATAMIENTO_DIPLOMATICO = "2";
    @Override
	@ServicioAnnot(tipo="A",codServicio=0000,descServicio="obtiene la fecha de conclusion de despacho")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=0000,numSecEjec=00,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")	
    public Map<String, Object> obtfecConclusionDespacho(Map<String, Object> variablesIngreso)
    {

		// HSAENZ: 08/09/2014: Todo lo que se tenia anteriormente en este metodo, pasa al metodo obtFechaConclusionDespacho 
		//          Se agrega nuevo metodo para calculo de fecha de conclusion. Se pasa por default la fecha actual y 3 meses para el calculo 
		//          (es lo que hacia anteriormente el metodo).
    	Map <String, Object> variablesIngresoTMP = new HashMap<String, Object>();

    	variablesIngresoTMP = obtFechaConclusionDespacho(variablesIngreso, SunatDateUtils.getCurrentDate(), 3);

    	return variablesIngresoTMP;
    	// Fin HSAENZ: 08/09/2014
    	
	}
    
    /**
     * @author hsaenz
     * @since 08/09/2014
     * Obtiene la fecha de conclusion, tanto para el proceso de numeracion como en el de prorroga. 
     */	
    public Map<String, Object> obtFechaConclusionDespacho(Map<String, Object> variablesIngreso, Date fechaInicio, int numeroMeses)
    {
		 Date fechaConclusion=new Date();
		 String resultadoDias="";

		 fechaConclusion = SunatDateUtils.addMonth(fechaInicio, numeroMeses);
		
		 Map<String,Object> params = new HashMap<String,Object>();
		 params.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(fechaConclusion));
		 params.put("FECHAHASTA", 1);
		 params.put("TIPO", 2);
		 params.put("INCLUYE", "S");
		 params.put("SUSPENDE", "S");
		
		 //resultadoDias=(String)NumeracionServiceImpl.getInstance().getDiasUtilesDAO().getSPDiasUtiles(params);
		 resultadoDias=(String)((DiasUtilesDAO)fabricaDeServicios.getService("diasUtilesDAO")).getSPDiasUtiles(params);
		 
		 
		fechaConclusion=SunatDateUtils.getDateFromInteger( SunatNumberUtils.toInteger(resultadoDias));
		 
		variablesIngreso.put("fechaConclusionDespa",fechaConclusion);
		
		return variablesIngreso;
	}
	@ServicioAnnot(tipo="A",codServicio=0000,descServicio="obtiene el tipo de despacho")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=0000,numSecEjec=00,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")	
	public Map<String, Object> validarTipoDespacho(Declaracion declaracion, Map<String, Object> variablesIngreso) {		

		String tipoDesp="";
		 if (declaracion.getDua().getCodmodalidad().equals("10") || (declaracion.getDua().getCodmodalidad().equals("01") && SunatDateUtils.getIntegerFromDate(declaracion.getDua().getManifiesto().getFectermino())>SunatDateUtils.getCurrentIntegerDate() )){
			 tipoDesp="TA";
		 }else if (declaracion.getDua().getCodmodalidad().equals("00") || (declaracion.getDua().getCodmodalidad().equals("01") && SunatDateUtils.getIntegerFromDate(declaracion.getDua().getManifiesto().getFectermino())<=SunatDateUtils.getCurrentIntegerDate() )){
			 tipoDesp="TE";
		 }

		variablesIngreso.put("tipoDesp",tipoDesp);
		
		return variablesIngreso;
	}

	/*Invoca al servicio de datado , implementado por el grupo manifiesto
	 * requiere datos de la declaracion transmitida y la declaracion obtenida de la BD
	 * la validacion lo hace por cada uno de los documentos de transporte transmitidos
	 * */
	
	@ServicioAnnot(tipo="V",codServicio=0000,descServicio="validar datado")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=0000,numSecEjec=00,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")	
	public  List<Map<String,?>> validarDatado(Declaracion declaracion,Map<String, Object> variablesIngreso ) throws Exception{
		List<Map<String,?>> lstErrors=new ArrayList<Map<String,?>>();
		// las validaciones para ver si se puede datar ser�n un servicio del grupo de manifiestos
		// por cada doc. de transporte se invoca al servicio de validacion de datado
		String codTransaccion=(String)variablesIngreso.get("codTransaccion");
		lstErrors=validarDatadoGeneral(codTransaccion,declaracion,variablesIngreso);
		return lstErrors;
	}
	//Este servicio es unicamente para Regularizaci�n XX04 XX05
	//No usarlo desde rectificacion ni numeraci�n, esos usa el servicio validarManifiestoService
	public  List<Map<String,?>> validarDatadoGeneral(String codTransaccion,Declaracion declaracion, Map<String,Object> variablesIngreso) throws Exception{

		List<Map<String,?>> lstErrors=new ArrayList<Map<String,?>>();
		
		boolean esUrgente    = ConstantesDataCatalogo.COD_MODALIDAD_URGENTE.equals(declaracion.getDua().getCodmodalidad())?true:false;
		boolean esAnticipado = ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO.equals(declaracion.getDua().getCodmodalidad())?true:false;
		//Manifiesto manifiesto = null;

		Map<String,Object> dataManif = new HashMap<String,Object>();
		Manifiesto listManifiesto = null;
		//Verificamos que este presente el manifiesto y todos los datos de la PK del manifiesto
		//antes de buscar para evitar fullscans a la BD
		DatoManifiesto manif = declaracion.getDua().getManifiesto();
		
		String codaduamanif=manif.getCodaduamanif();
		String annmanif=manif.getAnnmanif();
		String nummanif=manif.getNummanif();
		String codmodtransp=manif.getCodmodtransp();
		String codtipmanif  = manif.getCodtipomanif();
		Date fechaReferencia = SunatDateUtils.getCurrentDate();
		if(declaracion.getDua().getFecdeclaracion()!=null){
			fechaReferencia = declaracion.getDua().getFecdeclaracion();
		}
		dataManif.put("numeroManifiesto", SunatStringUtils.lpad(nummanif,6,' '));
		dataManif.put("anioManifiesto",  SunatStringUtils.length(annmanif)>3?annmanif.substring(0,4):null);
		dataManif.put("codigoAduana", codaduamanif);
		dataManif.put("codigoTipoManifiesto", "01");
		dataManif.put("codigoViaTransporte", codmodtransp);

		/**
		 * r2bz El servicio de manifiestos se encarga de buscar en el Nsigad o Asigad de corresponder
		 */
		ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");

		/** inicio PAS20181U220200049 cambiamos el buscador de manifiesto para que verifique por sda y si no lo ubica, busca por sigad:**/
		Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion();
		if(fechaDeclaracion==null){
			fechaDeclaracion = new Date();
		}
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaDeclaracion);
		boolean evaluarEER = declaracion.getDua().getCodlugarecepcion()!=null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			listManifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif,codmodtransp, codaduamanif,SunatNumberUtils.toInteger(annmanif), nummanif,true, fechaDeclaracion,evaluarEER);
		}else{
			listManifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif,codmodtransp, codaduamanif,SunatNumberUtils.toInteger(annmanif), nummanif,true);
		}
		//listManifiesto = manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
		/***fin PAS20181U220200049***/

		//dataManif.clear();
		//Verificamos si con los datos transmitidos se encontr� un manifiesto
		if (listManifiesto!=null ){ //Si existe el manifiesto

			//Date fecProgramadaLlegada = listManifiesto.getFechaProgramadaLlegada();
			Date fecProgramadaLlegada = listManifiesto.getFechaEfectivaDeLlegada();
			//Date fechaDescarga=  listManifiesto.getFechaTerminoDeDescarga(); 
			//Date fecLlegada = listManifiesto.getFechaEfectivaDeLlegada();	//pase105 - lmvr
			//Si es Urgente verificamos si al momento de numerar era Urgente Excepcional o Urgente Anticipada
			
			//En caso no tenga o sea igual a la fecha default usamos la fecha Programada
			if(fecProgramadaLlegada == null || SunatDateUtils.sonIguales(fecProgramadaLlegada, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA )){
				fecProgramadaLlegada = listManifiesto.getFechaProgramadaLlegada();
			}
			
		if(esUrgente){
			if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fecProgramadaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ){
				
				variablesIngreso.put("esUrgenteAnticipada", true);
				variablesIngreso.put("esUrgenteExcepcional", false);
			} else {

				variablesIngreso.put("esUrgenteAnticipada", false);
				variablesIngreso.put("esUrgenteExcepcional", true);
					
			}
			
		}
			
		/*	if(esUrgente){
				if (SunatDateUtils.esFecha1MenorIgualQueFecha2(fechaReferencia, fecProgramadaLlegada, SunatDateUtils.COMPARA_SOLO_FECHA) ){
					variablesIngreso.put("esUrgenteAnticipada", true);
					variablesIngreso.put("esUrgenteExcepcional", false);
				} else if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fecLlegada, SunatDateUtils.COMPARA_SOLO_FECHA)) {
					variablesIngreso.put("esUrgenteAnticipada", false);
					variablesIngreso.put("esUrgenteExcepcional", true);
				}
			}*/
//			variablesIngreso.put("esUrgenteAnticipada", false);
//			variablesIngreso.put("esUrgenteExcepcional", true);
			
			Map<String,Object> mapParam = new HashMap<String,Object>();
			mapParam.put("regimenDua", declaracion.getDua().getCodregimen());
			Map<String,?> mapResult=new HashMap<String,Object>();
			//Para el caso de la regularizaci�n verificamos tanto para Anticipado como Excepcional la fecha de termino de la descarga
			mapParam.put("fechaTerminoDeDescarga", manif!=null?manif.getFectermino():null);
			mapParam.put("fechaNumeracionDua",fechaReferencia);
			mapResult=validarExcepcionalManifiesto(mapParam,listManifiesto);
			//Verificamos si devuelve error
			if (mapResult.containsKey(ResponseMapManager.KEY_CODIGO)){
				Map<String, String> mapError = new HashMap<String, String>();
				mapError.put(ResponseMapManager.KEY_CODIGO, (String)mapResult.get(ResponseMapManager.KEY_CODIGO));		
				mapError.put(ResponseMapManager.KEY_DESCRIPCION, (String)mapResult.get(ResponseMapManager.KEY_DESCRIPCION));
				lstErrors.add(mapError);
				return lstErrors;
			}
			
		} else {//No encontro Manifiesto
			//NSR: 16/12/2010 Si no existe el manifiesto con los datos consignados en el XML entonces rechazamos
			//Si no desea adjuntar manifiesto (anticipadas o urgentes) no debe consignar numero, a�o y aduana del manifiesto en el XML
			Map<String, String> mapError = ResponseMapManager.getErrorResponseMap("11000", "El manifiesto no existe "+
															dataManif.get("codigoTipoManifiesto")+"-"+
															dataManif.get("codigoViaTransporte") +"-"+
															dataManif.get("codigoAduana")+"-"+
															dataManif.get("anioManifiesto")+"-"+
															dataManif.get("numeroManifiesto") );
			lstErrors.add(mapError);
			return lstErrors;
		}
		
		/** NSR: Para evitar recorrer todas las series por cada DocTransporte, primero acumulamos los totales y luego
		 * recien validamos. el numero del documento de transporte esta en la lista de docSoporte
		 */
		//Llenamos los datos comunes
		//Si es Urgente consideramos como excepcional
		Map<String,Object> otrosDatos = new HashMap<String, Object>();
		if (esUrgente){
			otrosDatos.put("esUrgenteAnticipada",variablesIngreso.get("esUrgenteAnticipada"));
			otrosDatos.put("esUrgenteExcepcional",variablesIngreso.get("esUrgenteExcepcional"));
		}
		
		if (esUrgente || esAnticipado) {
			if( codTransaccion.endsWith("03") ) {  
				otrosDatos.put("tieneDatadoSobreRecibido", variablesIngreso.get("tieneDatadoSobreRecibido") );
			}
		}
		
		otrosDatos.put("fechaReferencia", fechaReferencia);
		
		//Llenamos los datos comunes
		Map<String,Object> datosComunes = GeneralUtils.getDatosFijosDatadoValidacion(declaracion, codTransaccion, otrosDatos);
		//LLenamos el mapa con los datos de pesos y bultos por cada Documento de Transporte
		//El metodo totalesParaDatadoPorDocTra se encarga de realizar las sumatorias para todas las series
		Map<String, Map<Integer, Map<String, BigDecimal>>> mapTotalesParaDatadoXDocuTrans = GeneralUtils.totalesParaDatadoPorDocTra(declaracion);
		//Declaramos una Lista para almacenar los datos que seran reutilizados al momento de grabar
		List<Map<String,Object>> listaParaDatado = new ArrayList<Map<String,Object>>();
		Boolean hayErroresDatado = false;
		//Por cada documento de transporte de la declaracion Validamos el Datado
		for(DatoDocTransporte docTransporte:declaracion.getDua().getListDocTransporte()){
			Map<String,Object> dataDua=new HashMap<String, Object>();
			//Buscamos el docTransporte en el mapa, si est� entonces extraemos los datos calculados
			//Pesos y Bultos
			if(mapTotalesParaDatadoXDocuTrans.containsKey(docTransporte.getNumdoctransporte())){
				dataDua.putAll(GeneralUtils.getDatosCalculados(declaracion, docTransporte, mapTotalesParaDatadoXDocuTrans));
			} else {
				//TODO NSR: Error? Un documento de transporte al cual ninguna serie hace referencia?, mejor lo pasamos por alto
				continue;
			}
			//Agregamos los datos fijos
			dataDua.putAll(datosComunes);
			//Agregamos los datos correspondientes al Documento de Transporte
			dataDua.putAll(GeneralUtils.getDatosVariablesDatado(declaracion, docTransporte));

			//PAS20191U220200019 - Inicio
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> vigenciaOtraVia = catalogoAyudaService.getElementoAsoc("455", codaduamanif, declaracion.getDua().getCodregimen(), fechaDeclaracion);
			if(!MapUtils.isEmpty(vigenciaOtraVia)){
				String codLugarRecepcion = declaracion.getDua().getCodlugarecepcion() != null ? declaracion.getDua().getCodlugarecepcion().toString() : " ";
				boolean considerarEER = SunatStringUtils.toStringObj(codLugarRecepcion)!=null && SunatStringUtils.toStringObj(codLugarRecepcion).equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
				dataDua.put("fechaReferencia", fechaDeclaracion);
				dataDua.put("considerarEER", considerarEER ? "1" : "0");
				dataDua.put("esOMA", "1");
			}
			//PAS20191U220200019 - Fin

			//Nuevo Datado
			//Map<String,?> mapDatado=datadoService.validarDatado(codTransaccion, dataDua);
			Datado2Service datado2Service = fabricaDeServicios.getService("manifiesto.datado2Service");
			Map<String,?> mapDatado=datado2Service.validarDatado(dataDua);
			if (mapDatado.containsKey(ResponseMapManager.KEY_CODIGO)){
				Map<String, String> mapError = new HashMap<String, String>();
				mapError.put(ResponseMapManager.KEY_CODIGO, (String)mapDatado.get(ResponseMapManager.KEY_CODIGO));		
				mapError.put(ResponseMapManager.KEY_DESCRIPCION, (String)mapDatado.get(ResponseMapManager.KEY_DESCRIPCION));
				lstErrors.add(mapError);
				hayErroresDatado = true;
			}
			/*Para evitar volver a Calcular todos esto datos en caso de que se decida Numerar la Dua
			 *almacenamos estos resultados en una lista, y solo en el caso de que no haya errores, 
			*/
			if ( ! hayErroresDatado){ //Si no hay errores guardamos
				listaParaDatado.add(dataDua);
				variablesIngreso.put("validarManifiesto",true);//Para indicar que grabe datado
			} else { //Si hubiera errores, liberamos la memoria y ya no grabaremos nada
				listaParaDatado.clear();
				variablesIngreso.put("validarManifiesto",false);//Para que quite el flag
			}
		}		
		//Una vez pasado todas las validaciones y si no hay errores de datado
		//Almacenamos los TotalesParaDatado en el mapa variablesIngreso para evitar volver a calcularlo en el servicio de Grabaci�n
		if (( ! hayErroresDatado)){
			variablesIngreso.put("marcaDesdatadoDatado", true);
			variablesIngreso.put("Datado.listaParaDatado",listaParaDatado);				
		}
		
		return lstErrors;
	}

	public  Boolean verificarCancelacion(Long Numecorredoc) {

		Boolean cancelado=false;
		BigDecimal total=new BigDecimal(0);
		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(Numecorredoc);
		//List<DeudaDocum> tmpListDeudaDocum = NumeracionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);
		List<DeudaDocum> tmpListDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
		
		if (tmpListDeudaDocum.size()>0){
			DeudaDocum tmp=	tmpListDeudaDocum.get(0);
			total=total.add(tmp.getMtoGarant());
			total=total.add(tmp.getMtoImpugna());
			total=total.add(tmp.getMtoPagado());
			if (tmp.getMtoDeuda().equals(total)){
				cancelado=true;
			}
		}
		
		
		
		return cancelado;
		 }
	
	/**
	* Servicio que verifica la cuenta corriente de automoviles usados
	* @param declaracion objeto que representa la declaracion rectificada
	* @author hosorio
	* @return HashMap<String, Object>
 * @throws Exception 
	 */
	public Map<String,String> verificaCtaCteVehiUsado(Declaracion declaracion,Map<String, Object> variablesIngreso ) throws Exception{
		Map<String,String> resultadoError=new HashMap<String, String>();
		Map<String,Object> cantMaxLibe;
		Map<String,Object> params;
			// r2bz Si es vehiculo usado el importador asi sea FRECUENTE debe enviar Formato B
		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
		//CantMaxLibeDAO cantmaxlibeDAO = fabricaDeServicios.getService("cantMaxLibeDAO");
			if(funcionesService.isAutoUsa(declaracion.getDua())){
				if( CollectionUtils.isEmpty(declaracion.getListDAVs()) ){		
					//INICIO EJHM P46
					ValTratamientoDonacionService valTratamientoDonacionService = (ValTratamientoDonacionService)fabricaDeServicios.getService("ValTratamientoDonacion");
				      
					boolean esRigmen10=CollectionUtils.isEmpty(valTratamientoDonacionService.validarRegimenDeclaracion(declaracion))?true:false;
					boolean esTratamiento4=CollectionUtils.isEmpty(valTratamientoDonacionService.validarRegimenDeclaracion(declaracion))&&valTratamientoDonacionService.validarTieneTratamientoDonacion(declaracion);
					boolean tieneTrataDiplomatico = SunatStringUtils.isEqualTo(declaracion.getDua().getCodtipotratamiento(), TRATAMIENTO_DIPLOMATICO);
					if(!((esRigmen10 && esTratamiento4) || tieneTrataDiplomatico)){
						//FIN EJHM P46
						//resultadoError= catalogoHelper.getErrorMap("05653", "PARA VEHICULOS USADOS ES OBLIGATORIO EL ENVIO DEL FORMATO B");
						
						resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("05653",new String[] {"PARA VEHICULOS USADOS ES OBLIGATORIO EL ENVIO DEL FORMATO B"});
	        			return resultadoError;	
					}//P46
					
				}
				else{
					if(!CollectionUtils.isEmpty(declaracion.getDua().getListSeries()) ){
						// en vehiculos usados hay una sola serie, un proveedor, una factura , un solo item 
						DatoSerie serie =declaracion.getDua().getListSeries().get(0);
						DAV valordg=declaracion.getListDAVs().get(0);
						DatoFactura factura = valordg.getListFacturas().get(0);
						DatoItem item = factura.getListItems().get(0);
						params=new HashMap<String, Object>();
						Integer count=0;
			        	params.put("tlib", "T");
			        	String clib="";
			        	if(SunatNumberUtils.isGreaterThanZero(serie.getCodtratprefe()) 
			        			//&& serie.getCodtratprefe().toString().length()>=4
			        			){
			        		clib=serie.getCodtratprefe().toString();
			        		params.put("clib", clib);
			        		//count= cantmaxlibeDAO.countByParams(params);
			        		
			        		params.put("ayudaID", "CantMaxLibe");
			        		count = ((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).countByParams(params);
			       
			        	}
						 
						// si existe el tpn en el cantmaxlibe
						if(count>0  ){
							
            VehiculoService vehiculo = fabricaDeServicios.getService("descripcionMinima.VehiculoService");

            String codMarca =  vehiculo.obtenerMarca(item,declaracion);
            String codModelo = vehiculo.obtenerMarca(item,declaracion);

            //String clasevariedad=getDescripcionMinimaItemByTipo(item, ConstantesDataCatalogo.DESC_MINIMA_CLASE_VARIEDAD).getValtipdescri();
            //validar el chasis sea mayor que 6>

            /* se comenta valida lo mismo
							int end=clasevariedad.length()>=27?26:clasevariedad.length();
							if (end<6){
								resultadoError= catalogoHelper.getErrorMap("01260","");
								return resultadoError;
							}*/

            //String codChasis = clasevariedad.substring(6, end) ;

            String codChasis =vehiculo.obtenerChasis(item,declaracion);
            String cad_chasis =   codChasis;
							if (SunatStringUtils.isEmpty(codChasis)){
								//resultadoError= catalogoHelper.getErrorMap("01260","");
								resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("01260");
								return resultadoError;
							}
							if(SunatNumberUtils.isGreaterThanZero(serie.getCodtratprefe())){
								String TPN_DEC=clib;
								if(serie.getCodtratprefe()==244){
									if(valordg!=null && valordg.getProveedor()!=null
											&& org.apache.commons.lang.StringUtils.containsIgnoreCase(valordg.getProveedor().getNombreRazonSocial().trim(), "B.A.S. TRUCKS") ){
							        	params=new HashMap<String, Object>();
							        	params.put("tlib", "T");
							        	params.put("clib", clib);
							        	params.put("caduana", "000");
							        	params.put("cregimen", "10");
							        	params.put("codmarca", codMarca.trim());
							        	params.put("codmodelo", codModelo.trim());
							        	params.put("annfabr", item.getAnnfabrica());
							        	params.put("numpartida", serie.getNumpartnandi());
							        	params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
							        	
							        	//List<Map<String,Object>> lstCantMaxLibe= cantmaxlibeDAO.findCantMaxLibeByParams(params);
							        	
							        	List<Map<String,Object>> lstCantMaxLibe= null;
							        	params.put("ayudaID", "CantMaxLibe");
							        	lstCantMaxLibe= (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findCantMaxLibeByParams(params);

							        	
							        	if(!CollectionUtils.isEmpty(lstCantMaxLibe)  ){
							        		cantMaxLibe=lstCantMaxLibe.get(0);
							        		Long qactduas=(Long)cantMaxLibe.get("qactduas");
							        		Long qmaxduas=(Long)cantMaxLibe.get("qmaxduas");
							        		// si la cantidad de duas es mayor o igual a las max duas , se genera un error
							        		if(qactduas.compareTo(qmaxduas)>=0){
							        			// '=graba_telelog(RIGHT(duadet.Ano_Orden,2), " "," ", "8573","TPN "+TPN_DEC+": EXCEDE CANTIDAD DE DUAS PERMITIDAS (MAX = "+ALLTRIM(STR(tpnmaxvehi1.qmaxduas))+")"," ")
							        			//resultadoError= catalogoHelper.getErrorMap("30338","TPN "+TPN_DEC+ ": EXCEDE CANTIDAD DE DUAS PERMITIDAS "+qmaxduas);
							        			resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30338",new String[] {"TPN "+TPN_DEC+ ": EXCEDE CANTIDAD DE DUAS PERMITIDAS "+qmaxduas});
							        			
							        			return resultadoError;
							        		}else{
							        			variablesIngreso.put("IndAfectaDesafecta","A");
							        		}
							        	}
									}
									else {// si es otro proveedor
					        			//resultadoError= catalogoHelper.getErrorMap("30340", "TPN "+TPN_DEC+" NO HABILITADO PARA ESTE PROVEEDOR "+valordg.getProveedor().getNombreRazonSocial());
					        			resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30340",new String[] {"TPN "+TPN_DEC+" NO HABILITADO PARA ESTE PROVEEDOR "+valordg.getProveedor().getNombreRazonSocial()});
					        			return resultadoError;
									}
								}// fin trato 244
								else if(serie.getCodtratprefe()==227){
                /*se comenta se saca arriba la variable es la misma*/
                //String cad_chasis = 	SunatStringUtils.substringFox(clasevariedad, 7, 20) ;
						        	params=new HashMap<String, Object>();
						        	params.put("tlib", "T");
						        	params.put("clib", clib);
						        	params.put("caduana", "000");
						        	params.put("cregimen", "10");
						        	params.put("codmarca", codMarca.trim());
						        	params.put("codchasisvehi", cad_chasis.trim());
						        	params.put("annfabr", item.getAnnfabrica());
						        	params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
						        	//List<Map<String,Object>> lstCantMaxLibe= cantmaxlibeDAO.findCantMaxLibeByParams(params);
						        	
						        	List<Map<String,Object>> lstCantMaxLibe= null;
						        	params.put("ayudaID", "CantMaxLibe");
						        	lstCantMaxLibe= (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findCantMaxLibeByParams(params);
						        	
						        	
						        	
						        	if(!CollectionUtils.isEmpty(lstCantMaxLibe) ){
						        		cantMaxLibe=lstCantMaxLibe.get(0);
						        		Long qactduas=(Long)cantMaxLibe.get("qactduas");
						        		Long qmaxduas=(Long)cantMaxLibe.get("qmaxduas");
						        		if(qactduas.compareTo(qmaxduas)>=0){
						        			//resultadoError= catalogoHelper.getErrorMap("30338", "TPN "+TPN_DEC+": EXCEDE CANTIDAD DE UNIDADES PERMITIDAS (MAX = "+qmaxduas);
						        			resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30338",new String[] {"TPN "+TPN_DEC+": EXCEDE CANTIDAD DE UNIDADES PERMITIDAS (MAX = "+qmaxduas});
						        		}else{
						        			variablesIngreso.put("IndAfectaDesafecta","A");
						        		}
						        	}
						        	else{
						        		//resultadoError= catalogoHelper.getErrorMap("30339", "TPN "+TPN_DEC+" NO HABILITADO PARA VEHICULO CON ESAS CARATERISTICAS");
						        		resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30339",new String[] {"TPN "+TPN_DEC+" NO HABILITADO PARA VEHICULO CON ESAS CARATERISTICAS"});
						        	}
								}else if(serie.getCodtratprefe()==308){ // && 20100202 LLG : Implementaci�n de TPN 308 asinado a la empresa con RUC 20427557376
									// && Se verifica fecha de vigencia y que TPN sea igual a 308
									Timestamp pFecha = new Timestamp(System.currentTimeMillis());
									//Integer vigencia = funcionesService.getVigenciaCambio("983", declaracion.getDua().getCodregimen(), "TD000", "000071", pFecha);
                /*se comenta se saca arriba la variable es la misma*/
                //String cad_chasis = 	SunatStringUtils.substringFox(clasevariedad, 7, 20) ;
						        	params=new HashMap<String, Object>();
						        	params.put("tlib", "T");
						        	params.put("clib", clib);
						        	params.put("cpaisorigen", " ");
						        	params.put("caduana", declaracion.getDua().getCodaduanaorden());
						        	params.put("cregimen", "10");
						        	params.put("codmarca", codMarca.trim());
						        	params.put("codmodelo", codModelo.trim());
						        	params.put("codchasisvehi", cad_chasis.trim()); 
						        	params.put("tobsreferencia",SunatStringUtils.substringFox(cad_chasis, 11, 7).trim());
						        	params.put("annfabr", item.getAnnfabrica());
						        	params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
						        	//List<Map<String,Object>> lstCantMaxLibe= cantmaxlibeDAO.findCantMaxLibeByParams(params);
						        	
						        	List<Map<String,Object>> lstCantMaxLibe= null;
						        	params.put("ayudaID", "CantMaxLibe");
						        	lstCantMaxLibe= (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findCantMaxLibeByParams(params);
						        	
						        	
						        	if(!CollectionUtils.isEmpty(lstCantMaxLibe)){
						        		cantMaxLibe=lstCantMaxLibe.get(0);
						        		Long qactduas=(Long)cantMaxLibe.get("qactduas");
						        		Long qmaxduas=(Long)cantMaxLibe.get("qmaxduas");
						        		if(qactduas.compareTo(qmaxduas)>=0){
						        			//resultadoError= catalogoHelper.getErrorMap("30338", "TPN "+TPN_DEC+": EXCEDE CANTIDAD DE UNIDADES PERMITIDAS (MAX = "+qmaxduas);
							        		resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30338",new String[] {"TPN "+TPN_DEC+": EXCEDE CANTIDAD DE UNIDADES PERMITIDAS (MAX = "+qmaxduas});
						        		}else{
						        			variablesIngreso.put("IndAfectaDesafecta","A");
						        		}
						        	}
						        	else{
						        		//resultadoError= catalogoHelper.getErrorMap("30339", "TPN "+TPN_DEC+" NO HABILITADO PARA VEHICULO CON ESAS CARATERISTICAS");
						        		resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30339",new String[] {"TPN "+TPN_DEC+" NO HABILITADO PARA VEHICULO CON ESAS CARATERISTICAS"});
						        	}
								}
								else{
						        	params=new HashMap<String, Object>();
						        	params.put("tlib", "T");
						        	params.put("clib", TPN_DEC);
						        	params.put("caduana", "000");
						        	params.put("cpaisorigen", serie.getCodpaisorige());
						        	params.put("cregimen", "10");
						        	params.put("fecvigencia",SunatDateUtils.getCurrentIntegerDate());
						        //	List<Map<String,Object>> lstCantMaxLibe= cantmaxlibeDAO.findCantMaxLibeByParams(params);
						        	
						        	List<Map<String,Object>> lstCantMaxLibe= null;
						        	params.put("ayudaID", "CantMaxLibe");
						        	lstCantMaxLibe= (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findCantMaxLibeByParams(params);
						        	
									if(!CollectionUtils.isEmpty(lstCantMaxLibe)){
										//*!* Para el caso de NO tener restricciones por cod. de chasis y series (1 reg. en tabla)
										cantMaxLibe=lstCantMaxLibe.get(0);
										if(!StringUtils.hasText((String)cantMaxLibe.get("codchasisvehi"))
											&& cantMaxLibe.get("numseriinicial").equals("0")
											&& cantMaxLibe.get("numserifinal").equals("0")
										   ){
							        		Long qactduas=(Long)cantMaxLibe.get("qactduas");
							        		Long qmaxduas=(Long)cantMaxLibe.get("qmaxduas");
				
											if(qactduas.compareTo(qmaxduas)>=0){
							        			//resultadoError= catalogoHelper.getErrorMap("30338", "EXCEDE CANTIDAD DE DUAS PERMITIDAS "+qmaxduas);
							        			resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30338",new String[] {"EXCEDE CANTIDAD DE DUAS PERMITIDAS "+qmaxduas});
							        			return resultadoError;
											}else{
												variablesIngreso.put("IndAfectaDesafecta","A");
											}
										}
										else{
                    /*se comenta se saca arriba la variable es la misma*/
                    //String cad_chasis = 	SunatStringUtils.substringFox(clasevariedad, 7, 20) ;
											int posi_car   = cad_chasis.indexOf("-");
											posi_car++; // se suma 1 por el metodo substringFox
											String chasis_dec =  SunatStringUtils.substringFox(cad_chasis,1,posi_car-1);
											String serie_dec  =   SunatStringUtils.trim(cad_chasis.substring(posi_car));
											String anho_dec   = item.getAnnfabrica();
											String pais_dec   = serie.getCodpaisorige().trim();
											
											// *!* Para el caso de SI tener restricciones por cod. de chasis y series
								        	 params=new HashMap<String, Object>();
								        	params.put("tlib", "T");
								        	params.put("clib", TPN_DEC);
								        	params.put("caduana", "000");
								        	params.put("cpaisorigen", pais_dec);
								        	params.put("cregimen", "10");
								        	params.put("codchasisvehi", chasis_dec);
								        	params.put("rangoserie", serie_dec);
								        	params.put("actualmayorigualmaximo", true);
								        	params.put("rangoanho", anho_dec);
								        	params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
								        	//lstCantMaxLibe= cantmaxlibeDAO.findCantMaxLibeByParams(params);
								        	
								        	params.put("ayudaID", "CantMaxLibe");
								        	lstCantMaxLibe= (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findCantMaxLibeByParams(params);
								        	
								        	
								        	
								        	if(!CollectionUtils.isEmpty(lstCantMaxLibe) ){
												cantMaxLibe=lstCantMaxLibe.get(0);
								        		Long qmaxduas=(Long)cantMaxLibe.get("qmaxduas");
							        			//resultadoError= catalogoHelper.getErrorMap("30337", "TPN "+TPN_DEC+": CHASIS: " + chasis_dec + "  EXCEDE CANTIDAD DE DUAS PERMITIDAS MAX = "+qmaxduas);
							        			resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30337",new String[] {"TPN "+TPN_DEC+": CHASIS: " + chasis_dec + "  EXCEDE CANTIDAD DE DUAS PERMITIDAS MAX = "+qmaxduas});
							        			return resultadoError;
								        	}
								        	else{
									        	 params=new HashMap<String, Object>();
										        	params.put("tlib", "T");
										        	params.put("clib", TPN_DEC);
										        	params.put("caduana", "000");
										        	params.put("cpaisorigen", pais_dec);
										        	params.put("cregimen", "10");
										        	params.put("codchasisvehi", chasis_dec);
										        	params.put("rangoserie", serie_dec);
										        	params.put("actualmenormaximo", true);
										        	params.put("rangoanho", anho_dec);
										        	params.put("fecvigencia", SunatDateUtils.getCurrentIntegerDate());
										        //	lstCantMaxLibe= cantmaxlibeDAO.findCantMaxLibeByParams(params);
										        	
										        	
										        	params.put("ayudaID", "CantMaxLibe");
										        	lstCantMaxLibe= (List<Map<String,Object>>)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).findCantMaxLibeByParams(params);
										        	
										        
										        	if(CollectionUtils.isEmpty(lstCantMaxLibe) ){
									        			//resultadoError= catalogoHelper.getErrorMap("30336", "TPN "+TPN_DEC+": CHASIS: " + chasis_dec + " NO PERMITIDO");
									        			resultadoError=  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30336",new String[] {"TPN "+TPN_DEC+": CHASIS: " + chasis_dec + " NO PERMITIDO"});
									        			return resultadoError;
										        	}else{
										        		variablesIngreso.put("IndAfectaDesafecta","A");
										        	}
								        	}
										}
									}
								}
							} // fin if tpn>0
						} // fin count

						
					}
				}
			}
		return resultadoError;
	}

	/*Invoca al servicio de validacion de desdatado  
	 * la invocacion se hace por cada doc. de transporte
	 * */
	public List<Map<String,?>> validarDesDatado(Declaracion declaracion,String codTransaccion){
		List<Map<String,?>> lstErrors=new ArrayList<Map<String,?>>();
		Datado2Service datado2Service = fabricaDeServicios.getService("manifiesto.datado2Service");
		
	    // las validaciones para ver si se puede datar ser�n un servicio del grupo de manifiestos
		 Map<String,?> mperrores=null;
		
		// por cada doc. de transporte se invoca al servicio de validacion de datado
		for(DatoDocTransporte docTrans:declaracion.getDua().getListDocTransporte()){
			 Map<String,Object> dataDua=new HashMap<String, Object>();
			    dataDua=GeneralUtils.fillDataDuaDocTransp(declaracion,  docTrans,codTransaccion);
			    //mperrores=datadoservice.validarDesDatado(dataDua);
			    mperrores=datado2Service.validarDesDatado(dataDua);
			    if(!CollectionUtils.isEmpty(mperrores))
			    	lstErrors.add(mperrores);	    
		}
		
		
		return lstErrors;
	}
	

	/**
	 * Determina el monto del seguro para el Tipo=1 No asegurado
	 * @param serieActual
	 * @param fechaReferencia
	 * @return
	 */
	private BigDecimal calcularTipoSeguroNoAsegurado (DatoSerie serieActual, Date fechaReferencia){
		
		NandTasaDAO nandtasaDAO = fabricaDeServicios.getService("nandtasaDAO");
		BigDecimal fobSerieMasAjuste = SunatNumberUtils.sum(serieActual.getMtofobdol(), serieActual.getMtoajuste());
		BigDecimal newMtoSeguroSerie = new BigDecimal(0);
		
		Map <String,Object> params = new HashMap<String,Object>();
		params.put("cnan",serieActual.getNumpartnandi());
		params.put("fechavigencia",SunatDateUtils.getIntegerFromDate(fechaReferencia));
		 
		List<Map<String,Object>> listMapNandtasa = nandtasaDAO.findByMap(params);
		if (!listMapNandtasa.isEmpty()){
			 Map<String,Object> mapNandTasa=listMapNandtasa.get(0);
	    	 if(mapNandTasa.containsKey("tseguro")){
	    		 BigDecimal mporc_seguro=(BigDecimal)mapNandTasa.get("tseguro");
	    		 BigDecimal divisor=new BigDecimal(100);
	    		 newMtoSeguroSerie = SunatNumberUtils.divide(SunatNumberUtils.multiply(fobSerieMasAjuste,mporc_seguro),divisor,3);
	         }
		}
		return newMtoSeguroSerie;
	}
	
	/**
	 * Calcula el prorrateo para tipo de seguro 2 y 3
	 * @param serieActual
	 * @param montoCalculoDeclaracion
	 * @return
	 */
	private BigDecimal calcularTipoSeguroIndividualFlotante (DatoSerie serieActual, Map<String, Object> montoCalculoDeclaracion){
		BigDecimal newMtoSeguroSerie = new BigDecimal(0);
		BigDecimal mtoSeguroAProrratear = SunatNumberUtils.toBigDecimal(montoCalculoDeclaracion.get("mtoSeguroAProrratear"));
		BigDecimal mtoFobAProrratear = SunatNumberUtils.toBigDecimal(montoCalculoDeclaracion.get("mtoFobAProrratear"));
		BigDecimal fobSerieSinAjuste= serieActual.getMtofobdol();
		newMtoSeguroSerie =	SunatNumberUtils.multiply(mtoSeguroAProrratear, fobSerieSinAjuste);
		if(SunatNumberUtils.isGreaterOrEqualsThanZero(mtoFobAProrratear)){
			newMtoSeguroSerie=SunatNumberUtils.divide(newMtoSeguroSerie, mtoFobAProrratear, 3);
		}
		return newMtoSeguroSerie;			
	}

	/**
	 * Obtiene los montos a nivel de dua que van a ser considerados para el tipo 2 y 3 de seguro
	 * @param listSeries
	 * @param mtoSeguroDeclaracion
	 * @param mtoFobDeclaracion
	 * @return
	 */
	private Map<String, Object> obtenerMontoFobSeguroParaIndividualFlotante (List<DatoSerie> listSeries, BigDecimal mtoSeguroDeclaracion, BigDecimal mtoFobDeclaracion){
		Map <String,Object> montoCalculoDeclaracion = new HashMap<String,Object>();
		BigDecimal mtoSeguroAProrratear = new BigDecimal(0);
		BigDecimal mtoFobAProrratear = new BigDecimal(0);
		for(DatoSerie serieActual:listSeries){
			String ctiposeguro = serieActual.getCodtiposeg();
			if (SunatStringUtils.include(ctiposeguro, new String[]{ConstantesDataCatalogo.SEGURO_ARANCEL, ConstantesDataCatalogo.SEGURO_PARCIAL,ConstantesDataCatalogo.SEGURO_CETICOS})){
				mtoSeguroAProrratear = SunatNumberUtils.sum(mtoSeguroAProrratear, serieActual.getMtosegdol());
				mtoFobAProrratear = SunatNumberUtils.sum(mtoFobAProrratear, serieActual.getMtofobdol());
			}
		}
		mtoSeguroAProrratear = SunatNumberUtils.diference(mtoSeguroDeclaracion, mtoSeguroAProrratear);
		mtoFobAProrratear = SunatNumberUtils.diference(mtoFobDeclaracion, mtoFobAProrratear);
		montoCalculoDeclaracion.put("mtoSeguroAProrratear", mtoSeguroAProrratear);
		montoCalculoDeclaracion.put("mtoFobAProrratear", mtoFobAProrratear);
		return montoCalculoDeclaracion;
	}
	
		
	/**
	 * Validacion de calculo del seguro prorrateado por tipo
	 * @param declaracion
	 * @param fechaReferencia
	 * @return
	 * @throws Exception
	 */
	public List<Map<String,?>> validarMontoSeguro(Declaracion declaracion, Date fechaReferencia )
			throws Exception{
		List<Map<String, ?>> result = new ArrayList<Map<String,?>>();
		BigDecimal newMtoSeguroSerie= new BigDecimal(0);

		if(!CollectionUtils.isEmpty(declaracion.getDua().getListSeries()) ){
			Map<String,Object> montoCalculoDeclaracion = obtenerMontoFobSeguroParaIndividualFlotante (declaracion.getDua().getListSeries(), declaracion.getDua().getMtotsegotros(), declaracion.getDua().getMtotfobclvta()); 					
			for(DatoSerie serieActual:declaracion.getDua().getListSeries()){
				if (SunatStringUtils.include(serieActual.getCodtiposeg() ,new String []{ConstantesDataCatalogo.SEGURO_FLOTANTE,ConstantesDataCatalogo.SEGURO_INDIVIDUAL})){
					// Verificar si env�o indicador de no prorrateo
					String indicadorSeguro = getIndicador(declaracion.getDua(),ConstantesDataCatalogo.INDICADOR_SEGURO_INDIVIDUALIZADO);
					if (indicadorSeguro  == null) {
						newMtoSeguroSerie = calcularTipoSeguroIndividualFlotante(serieActual, montoCalculoDeclaracion);
						if (!SunatNumberUtils.isEqual(newMtoSeguroSerie, serieActual.getMtosegdol().setScale(3, BigDecimal.ROUND_HALF_UP))){
							
							//Inicio de cambios por ajuste de �l�mite de tolerancia� de +/- 0.1 20150413 PAS20155E220000343
							BigDecimal diferenciaAjusteTotalizado = SunatNumberUtils.absoluteDiference(newMtoSeguroSerie, serieActual.getMtosegdol());
							DataCatalogo datacatalogoTolProrrSeg = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo(CAT_MARG_PRORRATEO_SEG,COD_MARG_PRORRATEO_SEG);
							BigDecimal limiteToleranciaSeg = datacatalogoTolProrrSeg!=null && datacatalogoTolProrrSeg.getDesDatacat()!=null? new BigDecimal(datacatalogoTolProrrSeg.getDesDatacat()): new BigDecimal(0);
																	
							//if (!SunatNumberUtils.isLessOrEqualsThanParam(diferenciaAjusteTotalizado, limiteToleranciaSeg)) {
							if(diferenciaAjusteTotalizado.compareTo(limiteToleranciaSeg) == 1){// si la diferencia es mayor a la tolerancia
								result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("01080",new String[] {serieActual.getNumserie().toString(),serieActual.getMtosegdol().toString(), newMtoSeguroSerie.toString()}));
							}
							//Fin de cambios por ajuste de �l�mite de tolerancia� de +/- 0.1 20150413 PAS20155E220000343
						}
					}
				}else if (SunatStringUtils.isEqualTo(serieActual.getCodtiposeg(), ConstantesDataCatalogo.SEGURO_ARANCEL)){
					newMtoSeguroSerie = calcularTipoSeguroNoAsegurado(serieActual, fechaReferencia);
					if (!SunatNumberUtils.isEqual(newMtoSeguroSerie, serieActual.getMtosegdol().setScale(3, BigDecimal.ROUND_HALF_UP))){
						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30737",new String[] {serieActual.getNumserie().toString(),serieActual.getMtosegdol().toString(), newMtoSeguroSerie.toString(), ConstantesDataCatalogo.SEGURO_ARANCEL}));
						//result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30737",new String[] {serieActual.getNumserie().toString(),serieActual.getMtosegdol().toString()}));//bugs 18528  -> no se levanta bug
					}
				}
			}
		}
		return result;
	}
	
				
	
	public Map<String,?> validarAnticipadoManifiesto (Map<String,Object> dataDua,Manifiesto manifiesto) {
		
		ResponseMapManager responseMapManager=new ResponseMapManager();
		
		if(!dataDua.containsKey("fechaLlegada") || dataDua.get("fechaLlegada")==null ){
			
			responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11500, "No se envio fecha de llegada del manifiesto de carga");
			return responseMapManager.getResponseMap();
		}
		
		Date fechaTerminoDeDescarga= (Date) dataDua.get("fechaLlegada");
		
		boolean isValidFechaLlegada = false;
		try {
			isValidFechaLlegada = DateUtil.equalsDate(manifiesto.getFechaProgramadaLlegada(),fechaTerminoDeDescarga);
		} catch (Exception e) {}
		
		if(!isValidFechaLlegada){
			responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11501, "La fecha de llegada enviada "+DateUtil.dateToStringSilent(fechaTerminoDeDescarga, "dd/MM/yyyy") +" es diferente a la almacenado en el manifiesto de carga "+DateUtil.dateToStringSilent(manifiesto.getFechaProgramadaLlegada(), "dd/MM/yyyy"));
			return responseMapManager.getResponseMap();
		}

		return responseMapManager.getResponseMap();
	}
	/* (non-Javadoc)
	 * @see pe.gob.sunat.despaduanero2.manifiesto.service.DatadaValidaciones#ValidarExcepcionalConManifiesto(java.util.Map)
	 */
	public Map<String,?> validarExcepcionalManifiesto  (Map<String,Object> dataDua,Manifiesto manifiesto) {
		
		ResponseMapManager responseMapManager=new ResponseMapManager();
		
		if(!dataDua.containsKey("fechaTerminoDeDescarga") || dataDua.get("fechaTerminoDeDescarga")==null){
			
			responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11504, "No se envio fecha de termino de descarga");
			return responseMapManager.getResponseMap();
		}
		
		Date fechaTerminoDeDescarga= (Date) dataDua.get("fechaTerminoDeDescarga");
		
		boolean isValidFechaTerminoDescarga = false;
		try {
			isValidFechaTerminoDescarga = DateUtil.equalsDate(manifiesto.getFechaTerminoDeDescarga(),fechaTerminoDeDescarga);
		} catch (Exception e) {}
		
		if(!isValidFechaTerminoDescarga){
			responseMapManager.putError(Constantes.COD_ERROR_MANIFIESTO_DATADO_11505, "La fecha de termino de descarga enviada "+DateUtil.dateToStringSilent(fechaTerminoDeDescarga , "dd/MM/yyyy") +" es diferente a la almacenada en el manifiesto de carga "+DateUtil.dateToStringSilent(manifiesto.getFechaTerminoDeDescarga(), "dd/MM/yyyy"));
			return responseMapManager.getResponseMap();
		}
		
		return responseMapManager.getResponseMap();
		
	}
		

	/**
	 * Sevicio de validacion del usuario que transmite
	 * Para lo que es Agente de Aduanas (41) el cargo  de Representante Legal (06)
	 * Para lo que es Despachador Oficial  (43) el cargo  de Despachador Oficial (16)
	 * Para lo que es Due�o Consignatario  (45) el cargo  de Representante Legal (06)
	 * @param codUsuario
	 * @param tipoSender
	 * @return
	 */
	@Override
	public List<Map<String, ?>> validarUsuarioSEIDA(String codUsuario, String tipoSender ) {
		List<Map<String, ?>> result = new ArrayList<Map<String,?>>();
		Map<String, Object> personalOCE = new HashMap<String, Object>();

		ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
		personalOCE = funcionesService.obtenerPersonalOCE(codUsuario, tipoSender);

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, Object> mapDesSender = catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_TIPO_OPERADOR,tipoSender);
		String desSender = mapDesSender!=null?mapDesSender.get("des_datacat").toString():"";

		if (personalOCE!= null && !personalOCE.isEmpty()) { 
			// El representante de {Agencia} con identificacion { } asociado al usuario {} que transmite la declaraci�n no se encuentra activo 
			if (!SunatStringUtils.isEqualTo(SunatStringUtils.toStringObj(personalOCE.get("cod_estado")), ConstantesDataCatalogo.COD_ESTADO_POCE_HABILITADO)){
				result.add(catalogoAyudaService.getError("30818",new String[] {desSender,SunatStringUtils.toStringObj(personalOCE.get("cod_tipodocid"))+"-"+SunatStringUtils.toStringObj(personalOCE.get("num_docid")), codUsuario}));
				result.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
			}
		} else {
			// El representante de {Agencia} con identificacion { } asociado al usuario {} que transmite la declaraci�n no se encuentra registrado como Operador de Comercio ante SUNAT.
			UsuarioSOLBean usuarioSOL = funcionesService.obtenerUsuariosSOL( codUsuario,  tipoSender) ;
			result.add(catalogoAyudaService.getError("30819",new String[] {desSender,usuarioSOL.getCodDocrepleg()+"-"+usuarioSOL.getNumDocrepleg(), codUsuario}));
			result.add( ResponseMapManager.getErrorResponseMapFinalizarProceso() ) ;
		}
		return result;
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}
	public AyudaService getAyudaService() {
		return ayudaService;
	}
	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
