package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.*;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.controladuanero2.ingreso.eer.model.Asocdocudam;
import pe.gob.sunat.controladuanero2.ingreso.eer.service.AsociacionDocumentoDAMService;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.SecuenciaDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.CabCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.CtaCtePerNat;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.SecuenciaPerdida;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCtacteRegimenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CtaCtePerNatDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionEERBatchService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.manifiesto.util.orquestador.tipos.TipoTransaccion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.DocumentoDAO;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.EnvioBean;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioDAO;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;

public class GrabarDeclaracionEERServiceImpl  extends ValDuaAbstract implements GrabarDeclaracionEERService {
	
	protected final Log logGrabarDeclaracionEER = LogFactory.getLog(getClass());
	
	private String origen="";
	private static final String[] listIndicadoresPermitidosDAM = {"46","49","50"};
	/**
	 * Metodo principal para grabar la declaracion DSEER
	 */
	public Map<String, String> grabarNumeracionEER(Declaracion declaracion, String numOrden, 
														  String codTransaccion, String tipoSender,
														  String numeroDocumentoIdentidadSender, String tipoDocumentoIdentidadSender,
														  Integer annEnvio, Long numEnvio) throws Exception {
		Map<String, String> mapResult = new HashMap<String, String>();
		SecuenciaDeclaracionService secuenciaDeclaracionService = (SecuenciaDeclaracionService)fabricaDeServicios.getService("secuenciaPerdidaService");
		SecuenciaPerdida secuencia = secuenciaDeclaracionService.generaSecuenciaDeclaracion(declaracion);
		try{
			grabarDeclaracionEER(declaracion, secuencia, numOrden, codTransaccion,tipoSender,
					numeroDocumentoIdentidadSender,tipoDocumentoIdentidadSender,annEnvio,numEnvio);
		}catch(Exception e){
			enviarException(secuencia, declaracion);
			throw e ;
		}catch(Error e){
			enviarException(secuencia, declaracion);
			log.error(e.getStackTrace());
			throw e ;
		}
		return mapResult;
	}
	
	private void grabarDeclaracionEER(Declaracion declaracion, SecuenciaPerdida secuencia, String numOrden, String codTransaccion,
			String tipoSender, String numDocIdentSender,  String tipoDocIdentSender,Integer annEnvio, Long numEnvio) throws Exception{
		
		if(UserNameHolder.get()==null) 
			UserNameHolder.set(Constants.NOMBRE_USUARIO_AUDITORIA_ORQUESTADOR);

		//Grabamos el documento
		Documento documento=new Documento();
		documento.setNumeroCorrelativo(declaracion.getNumeroCorrelativo());
		documento.setEstado(ConstantesDataCatalogo.COD_ESTADOS_DOCUMENTO_REGISTRADO);
		documento.setTipoDocumento(ConstantesDataCatalogo.TIPO_DOCUMENTO_ADUANERO_DECLARACION);
		documento.setCodAduana(declaracion.getCodaduana());
		documento.setFechaGeneracion( SunatDateUtils.getCurrentDate() );
		DocumentoDAO documentoDAO = fabricaDeServicios.getService("documentoDAO");
		documentoDAO.insertSelective(documento);
		
		//Grabamos CAB_DECLARA
		DUA dua=declaracion.getDua();
		dua.setNumcorredoc(declaracion.getNumeroCorrelativo());
		dua.setNumeroDeclaracion(declaracion.getNumeroDeclaracion());
		CabDeclaraDAO cabdeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		cabdeclaraDAO.insertDUASelective(fillCabDeclara(declaracion,numOrden));

		//Iniciamos el proceso batch de grabacion
		DeclaracionEERBatchService declaracionEERBatchService = (DeclaracionEERBatchService) fabricaDeServicios.getService("declaracion.DeclaracionEERBatchService");
		declaracionEERBatchService.iniciarRegistrarDeclaracion();
		
		//Grabamos los participantes
		for(Participante participante : fillParticipantes(declaracion,tipoSender,numDocIdentSender,tipoDocIdentSender, codTransaccion)){
			if(participante.getDocumento() == null)
				participante.setDocumento(new Documento());
			participante.getDocumento().setNumeroCorrelativo(declaracion.getNumeroCorrelativo());
			declaracionEERBatchService.insertParticipante(participante);
		}
		
		//Grabamos los indicadores de la DAM
		//IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
		for(DatoIndicadores datoIndicador : fillListIndicadoresDAM(declaracion)){
			datoIndicador.setNumeroCorrelativo(declaracion.getNumeroCorrelativo());
			//indicadorDUADAO.insert(datoIndicador);
			declaracionEERBatchService.insertIndicador(datoIndicador);
		}
		
		//Grabamos la tablas relaciones
		grabarDetalle(declaracion,declaracionEERBatchService);
		//validar la vigencia de mercancias obtener de asigad la declaracion y insertar en cab_ctacte_regimen
		declaracionEERBatchService.procesarRegistrarDeclaracion();
		
		//grabamos la cuenta corriente de persona natural
		if(!dua.getConsignatario().getTipoDocumentoIdentidad().getCodDatacat().equals(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC) && !tienePartida40(declaracion)){
			grabarCuentaCorrientePersonaNatural(declaracion);
		}

		//Si la numeracion viene de MDEER cambiamos el codigo de la transaccion temporalmente para los metodos de Liquidacion y Garantia
        String codTransaccionTmp = codTransaccion;
        if(ConstantesDataCatalogo.TRANSACCION_MANIFIESTO_NUMERACION_MDEER.equals(codTransaccion)){
            codTransaccion = ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER;
        }
        // ECANA PAS20181U220400023 Liquidaci�n de la DSEER
		origen="generaLiquidacionService.grabaLiquidacion";
		GeneraLiquidacionService generaLiquidacionService = (GeneraLiquidacionService) fabricaDeServicios.getService("generaLiquidacionService");
		Map mapResulLiqui = generaLiquidacionService.grabaLiquidacion(declaracion,codTransaccion ,numOrden, numDocIdentSender);
		pintaMensaje(origen);
		
		// ECANA PAS20181U220400023 Liquidaci�n de la DSEER
		Map<String, Object> variablesIngreso = new HashMap();
		if ("OK".equals(mapResulLiqui.get("GRABACION"))) {
			variablesIngreso.put("codTransaccion", codTransaccion);
			variablesIngreso.put("RESULTADO_LIQ", mapResulLiqui);
			origen="generaLiquidacionService.grabaTrama";
			generaLiquidacionService.grabaTrama(variablesIngreso);
			pintaMensaje(origen);
		}
        Date fechaVencimientoConclusion = getFechaConclusion(declaracion,codTransaccion);
		GrabarGeneralService grabarGeneralService = (GrabarGeneralService) fabricaDeServicios.getService("GrabarGeneralService");
		if (declaracion.getDua().getRucCtaCorriente()!=null) {
			origen="grabarGeneralService.afectaGarantia";
			String tipoDesp = Constantes.COD_TIPO_DESPACHO_ANTICIPADO; //cambiar cuando se evalue la verdades modalidad
			grabarGeneralService.afectaGarantia(declaracion, numDocIdentSender, tipoDocIdentSender, numOrden, "",  Constants.COD_TRANS_FINAL_NUMERACION, tipoDesp, fechaVencimientoConclusion, variablesIngreso);
			pintaMensaje(origen);
		}
        //Si la numeracion viene de MDEER devolvemos el valor original a la transaccion
        codTransaccion = codTransaccionTmp;

		//lalberti: se a�ade if para evitar grabar el num_corredoc de las DSEER en el MDEER
		if(!ConstantesDataCatalogo.TRANSACCION_MANIFIESTO_NUMERACION_MDEER.equals(codTransaccion)) {
			origen="actualizarEnvio";
			actualizarEnvio(annEnvio, numEnvio, declaracion.getNumeroCorrelativo());
			pintaMensaje(origen);
		}
		//fin if
	}

	private Boolean tienePartida40(Declaracion declaracion){
        Boolean tienePartida40 = false;
        for(DatoSerie datoSerie: declaracion.getDua().getListSeries()){
            if(datoSerie.getNumpartnandi().equals(Long.parseLong(ConstantesAtributo.PARTIDA_EER_40))){
                tienePartida40=true;
                break;
            }
        }
        return tienePartida40;
    }

	private Date getFechaConclusion(Declaracion declaracion, String codTransaccion){
        Date fechaVencimientoConclusion = null;
        Map <String, Object> parametros = new HashMap<String, Object>();

        Date fechaReferencia = declaracion.getDua().getFecdeclaracion();
        if(fechaReferencia == null && codTransaccion!=null && codTransaccion.substring(2, 4).equals("01")){
            fechaReferencia=new Date();
        }

        GetDeclaracionService getDeclaracionService = (GetDeclaracionService) fabricaDeServicios.getService("declaracionService");
        if(!getDeclaracionService.esVigenteNuevaLGAPorFecha(fechaReferencia)){
            ValidacionGeneralService validacionGeneral = (ValidacionGeneralService) fabricaDeServicios.getService("validaciongeneralservice");
            parametros = validacionGeneral.obtFechaConclusionDespacho(parametros, SunatDateUtils.getCurrentDate(), 3);
        }

        if (parametros.get("fechaConclusionDespa") != null && !parametros.get("fechaConclusionDespa").toString().isEmpty()) {
            fechaVencimientoConclusion = (Date) parametros.get("fechaConclusionDespa");
        }
        return fechaVencimientoConclusion;
    }
	
	//para esto se agregar servicios que verifiquen el correlativo de las facturas y de los documentos de soporte y las series
	private void grabarDetalle(Declaracion declaracion,DeclaracionEERBatchService declaracionEERBatchService){
		DUA dua = declaracion.getDua();
		List<Integer> listNumFacturas = new ArrayList<Integer>();
		List<Integer> listNumDocAutoriz = new ArrayList<Integer>();
		
		//si tiene precedente y es de exportacion entonces no tiene corredoc
		//lo generamos su corredoc con la asociacion
		Long numCorredocPrecendete = obtenerNumeroCorrelativoPrecedente(declaracion);
		
		//obtenemos el numero de la guia EER
		DatoDocTransporte datoDocTransporte=dua.getListDocTransporte().get(0);
		datoDocTransporte.setCodtipodoctrans("1");//directo
		
		for(DatoSerie serie:dua.getListSeries()){
			serie.setNumcorredoc(declaracion.getNumeroCorrelativo());
			serie.setDocumentoTransporte(datoDocTransporte);
			declaracionEERBatchService.insertSerie(serie);
			//datos adicionales, pagina web
			if(serie.getDatoAdiSerieImpoConsumo()!=null){
				Map<String, Object> mapDatoAdicional = new HashMap<String,Object>();
				mapDatoAdicional.put("NUM_CORREDOC", dua.getNumcorredoc());
				mapDatoAdicional.put("NUM_SECSERIE", serie.getNumserie());
				mapDatoAdicional.put("NOM_PAGINAWEB", serie.getDatoAdiSerieImpoConsumo().getNomPaginaWeb());
				declaracionEERBatchService.insertInformacionAdicionalSerie(mapDatoAdicional);
			}
			
			//indicadores serie
			for(DatoIndicadores datoIndicador : serie.getListIndicadores()){
				datoIndicador.setNumeroCorrelativo(dua.getNumcorredoc());
				datoIndicador.setNumeroSerie(serie.getNumserie());
				datoIndicador.setCodigoTipoRegistro(ConstantesDataCatalogo.COD_TIPOREGISTRO_TRANSMISION);
				declaracionEERBatchService.insertIndicadorSerie(datoIndicador);
			}
			
			//Documentos de soporte
			for(DatoSerieDocSoporte serieDoc:serie.getListSerieDocSoporte()){
				//factura
				if(ConstantesDataCatalogo.COD_DOC_SOPORTE_FACTURA.equals(serieDoc.getCodtipodocsoporte())){
					DatoFacturaref facturaRef =	getFacturaRefPorDocSoporte(dua, serieDoc);
					if(facturaRef!=null){
						
						if(!listNumFacturas.contains(facturaRef.getNumsecfactu())){
							listNumFacturas.add(facturaRef.getNumsecfactu());
							facturaRef.setNumcorredoc(serie.getNumcorredoc());
							declaracionEERBatchService.insertFormaFactu(facturaRef);
						}
						
						Map<String,Object> mapFacturaSerie=new HashMap<String,Object>();
						mapFacturaSerie.put("NUM_CORREDOC", serie.getNumcorredoc());
						mapFacturaSerie.put("NUM_SECFACT", facturaRef.getNumsecfactu());
						mapFacturaSerie.put("NUM_SECSERIE", serie.getNumserie());
						declaracionEERBatchService.insertFacturaSerie(mapFacturaSerie);
					}
				}
				
				//documento de autorizacion
				if(ConstantesDataCatalogo.COD_DOC_SOPORTE_DOCUMENTO_AUTORIZACION.equals(serieDoc.getCodtipodocsoporte())){
					DatoDocAutorizante datoDocAutorizante=getDocAutorizanteNew(declaracion.getDua(),serieDoc);
					if(datoDocAutorizante != null){
						
						if(!listNumDocAutoriz.contains(datoDocAutorizante.getNumsecdocum())){
							listNumDocAutoriz.add(datoDocAutorizante.getNumsecdocum());
							datoDocAutorizante.setNumcorredoc(serie.getNumcorredoc());
							datoDocAutorizante.setAnndocum(SunatDateUtils.getAnho(datoDocAutorizante.getFecemision()).toString());
							datoDocAutorizante.setCodTipoOper(ConstantesDataCatalogo.TIPO_PROCESO_DOCUMENTO_AUTORIZACION);
							declaracionEERBatchService.insertDocumentoAutorizante(datoDocAutorizante);
						}
						
						Map<String,Object> mapDetAutorizacion=new HashMap<String,Object>();
						mapDetAutorizacion.put("numCorredoc", serie.getNumcorredoc());
						mapDetAutorizacion.put("numSecserie", serie.getNumserie());
						mapDetAutorizacion.put("numSecdoc", datoDocAutorizante.getNumsecdocum());
						mapDetAutorizacion.put("codTipoper", ConstantesDataCatalogo.TIPO_PROCESO_DOCUMENTO_AUTORIZACION);
						declaracionEERBatchService.insertDetDocumentoAutorizante(mapDetAutorizacion);
					}
				}
			}
			
			//precendentes
			for(DatoRegPrecedencia datoRegPrecedencia:serie.getListRegPrecedencia()){
				datoRegPrecedencia.setNumcorredoc(serie.getNumcorredoc());
				datoRegPrecedencia.setNumserie(serie.getNumserie());
				//en ambos casos se deberia de grabar la declaracion precedente como mercancia vigente
				fillCabCtacteRegimen(serie, datoRegPrecedencia, serie.getNumcorredoc(),numCorredocPrecendete);
				//fin registro en cab_ctacte_regimen
				declaracionEERBatchService.insertDuaPrecedente(datoRegPrecedencia);
			}
		}
	}
	
	private List<DatoIndicadores> fillListIndicadoresDAM(Declaracion declaracion){
		List<DatoIndicadores> listIndicadores = new ArrayList<DatoIndicadores>();
		DUA dua = declaracion.getDua();
		
		for(DatoIndicadores datoIndicador:dua.getListIndicadores()){
			if(ArrayUtils.contains(listIndicadoresPermitidosDAM, datoIndicador.getCodigoIndicador())){
				datoIndicador.setCodigoTipoRegistro(ConstantesDataCatalogo.COD_TIPOREGISTRO_TRANSMISION);
				listIndicadores.add(datoIndicador);
			}
		}
		//si la dua esta garantizada debemos de grabar el indicador de garantizado

		return listIndicadores;
	}
	
	private List<Participante> fillParticipantes(Declaracion declaracion,String tipoSender, String numDocIdentSender, String tipoDocIdentSender, String codTransaccion){
		List<Participante> listParticipantes = new ArrayList<Participante>();
		DUA dua = declaracion.getDua();
		SequenceDAO sequenceDAO = (SequenceDAO) fabricaDeServicios.getService("Framework.sequenceDef");
		
		Participante remitente = dua.getRemitente();
		remitente.setSecuenciaDeParticipantes(sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
		//if("DDB".equals(remitente.getTipoParticipante().getCodDatacat())){
			remitente.getTipoParticipante().setCodDatacat(ConstantesDataCatalogo.TIPO_OPERADOR_PROVEEDOR); //PENDIENTE CAMBIO por el tipo remitente
		//}
		listParticipantes.add(remitente);
		
		Participante consignatario = dua.getConsignatario();
		consignatario.setSecuenciaDeParticipantes(sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
		consignatario.setCodNivelRiesgo("");//pendiente obtener de DUA
		//if("CN".equals(consignatario.getTipoParticipante().getCodDatacat())){
			consignatario.getTipoParticipante().setCodDatacat(ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO);
		//}
		listParticipantes.add(consignatario);
		
		Participante embarcador = dua.getEmbarcador();
		embarcador.setSecuenciaDeParticipantes(sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
		embarcador.setCodNivelRiesgo("");//pendiente obtener de DUA
		//if("CZ".equals(embarcador.getTipoParticipante().getCodDatacat())){
			embarcador.getTipoParticipante().setCodDatacat(ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA); //Pendiente cambio por el tipo embarcador
		//}
		listParticipantes.add(embarcador);
		
		//empresa eer
		Participante empresaEER = new Participante();
		empresaEER.setSecuenciaDeParticipantes(sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
		DataCatalogo tipoDocumento = new DataCatalogo();
		tipoDocumento.setCodDatacat(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC);
		empresaEER.setTipoDocumentoIdentidad(tipoDocumento);
		empresaEER.setNumeroDocumentoIdentidad(numDocIdentSender);
		DataCatalogo tipoParticipante = new DataCatalogo();
		tipoParticipante.setCodDatacat(ConstantesDataCatalogo.COD_OPERADOR_ESER);
		empresaEER.setTipoParticipante(tipoParticipante);
		SoporteService soporteService = fabricaDeServicios.getService("soporteServiceDef");
		soporteService.completarParticipante(empresaEER);
		listParticipantes.add(empresaEER);

		if (!SunatStringUtils.include(codTransaccion,
				new String[] { TipoTransaccion.TX_0444.value(), TipoTransaccion.TX_0446.value() })) { //20190516 jgarciaal: no se graba el DTEER en estas TXs
			//deposito temporal
			Participante depositoTemporalEER = new Participante();
			depositoTemporalEER.setSecuenciaDeParticipantes(sequenceDAO.getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE));
			tipoDocumento.setCodDatacat(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC);
			depositoTemporalEER.setTipoDocumentoIdentidad(tipoDocumento);
			depositoTemporalEER.setNumeroDocumentoIdentidad(dua.getDepositoTemporal().getNumeroDocumentoIdentidad());
			DataCatalogo tipoParticipanteDT = new DataCatalogo();
			tipoParticipanteDT.setCodDatacat(ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER);
			depositoTemporalEER.setTipoParticipante(tipoParticipanteDT);
			soporteService.completarParticipante(depositoTemporalEER);
			listParticipantes.add(depositoTemporalEER);
		}
		
		return listParticipantes;
	}
	
	private DUA fillCabDeclara(Declaracion declaracion, String numOrden){
		DUA dua=declaracion.getDua();
		//creamos un objeto nuevo para tener trazabilidad de los datos que se graban
		DUA cabDeclara = new DUA();
		cabDeclara.setNumcorredoc(dua.getNumcorredoc());
		//cabDeclara.setCodtipgrabado("T");	// no existe el atributo en DUA
		cabDeclara.setCodaduanaorden(dua.getCodaduanaorden());
		cabDeclara.setNumeroDeclaracion(dua.getNumeroDeclaracion());
		
		FechaBean fbCurrent=new FechaBean();
		Integer anho=new Integer(fbCurrent.getAnho());
		dua.setAnnpresen(anho);
		
		cabDeclara.setAnnpresen(dua.getAnnpresen());
		cabDeclara.setCodregimen(dua.getCodregimen());
		cabDeclara.setAnnorden(Integer.valueOf(numOrden.substring(0, 4)));
		cabDeclara.setNumorden(numOrden.substring(4, 10));
		cabDeclara.setCodmodalidad(dua.getCodmodalidad());	//los que numeran con la transaccion 2801 son anticipados
		//cabDeclara.setCodtipoperacion(dua.getCodtipoperacion());	//setear al inicio, codigo del tipo de despacho CAT 310
		//cabDeclara.setCodtiplugarrecep(ConstantesDataCatalogo.DESCARGA_AL_PUNTO_LLEGADA); //catalogo UG, descarga punto de llegada
		//cabDeclara.setCodtiplugarrecep(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO);//catalogo 402, escarga en aeropuesto
		cabDeclara.setMtotfobclvta(dua.getMtotfobclvta());	//42 fob total, sumar de todas las series
		cabDeclara.setMtotflecomex(dua.getMtotflecomex());	//43 flete total
		cabDeclara.setMtotsegotros(dua.getMtotsegotros());	//44 seguro, sumar de todas las series
		cabDeclara.setMtotajustes(dua.getMtotajustes());	//45 ajuste de valor, sumar de todas las series
		cabDeclara.setMtovaladuana(dua.getMtovaladuana());	//Valor en aduana
		cabDeclara.setCnttpesobruto(dua.getCnttpesobruto());	//39 peso bruto, sumar de todas las serie
		cabDeclara.setCnttcantbulto(dua.getCnttcantbulto());	//40 Cantidad de Bultos, sumar de todos las series CNT_TOTBULTOS
		cabDeclara.setCntnumseries(dua.getCntnumseries());	//el total de serie CNT_TOTSERIES
		cabDeclara.setCnttqunifis(dua.getCnttqunifis());	//54 Cantidad de Unidades Fisicas	CNT_TQUNIFIS
		cabDeclara.setCnttqunicom(dua.getCnttqunicom());	//57 cantidad de unidades comerciales, sumar de todas las serie	CNT_TQUNICOM

		//para MDEER
		if (dua.getManifiesto()!=null){
			DatoManifiesto datoManifiesto = new DatoManifiesto();
			datoManifiesto.setCodmodtransp(dua.getManifiesto().getCodmodtransp());
			//mapCabDeclara.put("codPuerPresemani", dua.getManifiesto().getCodpuerto());//Agregado
			datoManifiesto.setCodaduamanif(dua.getManifiesto().getCodaduamanif());
			datoManifiesto.setCodtipomanif(dua.getManifiesto().getCodtipomanif());
			datoManifiesto.setNummanif(dua.getManifiesto().getNummanif());
			
			if (dua.getManifiesto().getAnnmanif()!=null)
				datoManifiesto.setAnnmanif(dua.getManifiesto().getAnnmanif().substring(0,4));
			
			if(! SunatStringUtils.isEmptyTrim(dua.getManifiesto().getNumviaje()))
				datoManifiesto.setNumviaje(dua.getManifiesto().getNumviaje());
			//mapCabDeclara.put("fecIniembarque", dua.getManifiesto().getFeciniembarque());
			cabDeclara.setManifiesto(datoManifiesto);
		}

		if (dua.getPago()!=null){
			if(dua.getPago().getPagoDeclaracion()!=null){
				DatoPago datoPago = new DatoPago();
				DatoPagoDecla datoPagoDecla = new DatoPagoDecla();
				datoPagoDecla.setCodgarantia(dua.getPago().getPagoDeclaracion().getCodgarantia());
				datoPago.setPagoDeclaracion(datoPagoDecla);
				cabDeclara.setPago(datoPago);
				//mapCabDeclara.put("codModpago", dua.getPago().getPagoTransaccion().getCodmodpago());
			}
		}
		
		cabDeclara.setCodEstdua(ConstantesDataCatalogo.COD_DUA_NUMERADA);
		cabDeclara.setFecdeclaracion(SunatDateUtils.getCurrentDate());
		cabDeclara.setCategoria(dua.getCategoria());
		return cabDeclara;
	}
	
	private void grabarCuentaCorrientePersonaNatural(Declaracion declaracion){
		Integer lnSecuencia = 0;
		DUA dua = declaracion.getDua();
		CtaCtePerNat tmpCtaCtePerNat = new CtaCtePerNat();
		tmpCtaCtePerNat.setAnoPrese(dua.getAnnpresen().toString());
		tmpCtaCtePerNat.setCodiRegi(dua.getCodregimen());
		tmpCtaCtePerNat.setLibrTribu(dua.getConsignatario().getNumeroDocumentoIdentidad());
		tmpCtaCtePerNat.setTipoDocum(dua.getConsignatario().getTipoDocumentoIdentidad().getCodDatacat());
		List<CtaCtePerNat> lstCtaCtePerNat = ((CtaCtePerNatDAO)fabricaDeServicios.getService("ctaCtePerNatDAO")).selectBySelective(tmpCtaCtePerNat);
		if (lstCtaCtePerNat != null && lstCtaCtePerNat.size() > 0) {
			lnSecuencia = lstCtaCtePerNat.size();
		}
		tmpCtaCtePerNat.setCodiAduan(dua.getCodaduanaorden());
		tmpCtaCtePerNat.setNumeCorre(dua.getNumeroDeclaracion().toString());
		tmpCtaCtePerNat.setFechAnula(Integer.valueOf("0"));
		tmpCtaCtePerNat.setFlagAnula("0");
		lnSecuencia++;
		tmpCtaCtePerNat.setNumeSecue(lnSecuencia);
		tmpCtaCtePerNat.setCodiExcep(" ");//no tiene ningun codigo de excepcion
		tmpCtaCtePerNat.setTfobDolpo(dua.getMtotfobclvta());
		tmpCtaCtePerNat.setcRegimen(dua.getCodregimen());
		((CtaCtePerNatDAO)fabricaDeServicios.getService("declaracion.ctaCtePerNatDAO.dx")).insertSelective(tmpCtaCtePerNat);
	}
	
	private Long obtenerNumeroCorrelativoPrecedente(Declaracion declaracion){
		AsociacionDocumentoDAMService asociacionDocumentoDAMService = (AsociacionDocumentoDAMService)fabricaDeServicios.getService("eer.asociacionDocumentoDAMEERService");
		//DatoRegPrecedencia  datoRegPrecedencia = declaracion.getDua().getListSeries().get(0).getListRegPrecedencia();
		DUA dua = declaracion.getDua();
		Elementos<DatoRegPrecedencia> listPrecedencia = dua.getListSeries().get(0).getListRegPrecedencia();
		Long numeroCorrelativoPrecendente = 0L;
		if(listPrecedencia.size()>0){
			DatoRegPrecedencia prec = listPrecedencia.get(0);
			if(prec.getNumcorredocpre()==null){
				Map<String,Object> mapPrecedente = new HashMap<String,Object>();
				mapPrecedente.put("COD_ADUANAASIG",prec.getCodaduapre());
				mapPrecedente.put("ANN_PRESENASIG",prec.getAnndeclpre());
				mapPrecedente.put("NUM_DECLARAASIG",prec.getNumdeclpre());
				mapPrecedente.put("COD_REGIMENASIG",prec.getCodregipre());
				Asocdocudam asoc = asociacionDocumentoDAMService.getByDeclaracion(mapPrecedente);
				if(asoc == null){
					Asocdocudam asocdocudam=new Asocdocudam();
					asocdocudam.setAnnPresenAsigad(new Integer(prec.getAnndeclpre().substring(0, 4)));
					asocdocudam.setCodAduanaAsigad(prec.getCodaduapre());
					asocdocudam.setCodRegimenAsigad(prec.getCodregipre());
					asocdocudam.setNumDeclaracionAsigad(new Long(prec.getNumdeclpre()));
					asociacionDocumentoDAMService.insertAsociacion(asocdocudam);
					numeroCorrelativoPrecendente = asocdocudam.getNumeroCorrelativo();
				}else{
					numeroCorrelativoPrecendente = asoc.getNumeroCorrelativo();
				}
			}else{
				numeroCorrelativoPrecendente = prec.getNumcorredocpre();
			}
		}
		 return numeroCorrelativoPrecendente;
		//no inserta en numcorredocpre, porque te valida que exista en det_declara
		/*for(DatoSerie serie : dua.getListSeries()){
			serie.getListRegPrecedencia().get(0).setNumcorredocpre(numeroCorrelativoPrecendente);
		}*/
	}
	
	private void fillCabCtacteRegimen(DatoSerie serie, DatoRegPrecedencia prec, Long numCorredoc, Long numCorredocPrecedente){

		DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
		
		CabCtacteRegimenDAO ctacteRegimenDAO = fabricaDeServicios.getService("declaracion.cabCtaCteRegimen");
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("numCorredoc", numCorredocPrecedente);
		params.put("numSerie", prec.getNumserpre());
		CabCtacteRegimen resultCtaCte = ctacteRegimenDAO.selectByKeyMap(params);
		
		if(resultCtaCte==null){
			CabCtacteRegimen datosCtaCte = new CabCtacteRegimen();
            datosCtaCte.setNumCorredoc(numCorredocPrecedente); 
            datosCtaCte.setNumCtacte((long) 0);
            datosCtaCte.setNumSerie(prec.getNumserie());
            datosCtaCte.setCntUnidades(prec.getCntunidfiqty());
            datosCtaCte.setCntSaldoUnidad(prec.getCntunidfiqty());
            datosCtaCte.setCodTipoUnidad(prec.getCodunifis());
            datosCtaCte.setCodEstctacte("01");
			ctaCteService.insertarCtacteRegimen(datosCtaCte,prec.getNumcorredoc());
			resultCtaCte = ctacteRegimenDAO.selectByKeyMap(params);
		}
		
		if( resultCtaCte!=null ) {
			ctaCteService.actualizaCtacteRegimenEER(resultCtaCte, serie, numCorredoc);	
		}
		return;
	}
	
	//Metodos generales
	private void enviarException(SecuenciaPerdida secuencia, Declaracion declaracion){
		SecuenciaDeclaracionService secuenciaDeclaracionService = (SecuenciaDeclaracionService)fabricaDeServicios.getService("secuenciaPerdidaService");
		pintaMensaje("ENTRO AL EXCEPTION DE LA GRABACION");
		secuencia.setIndicadorRecuperacion(" ");
		if(secuencia.getFechaRegistro() == null) {
			origen="secuenciaDeclaracionService.registrarSecuencia";
			secuenciaDeclaracionService.registrarSecuencia(secuencia);
			pintaMensaje(origen);
		} else {
			origen="secuenciaDeclaracionService.actualizarSecuencia";
			secuenciaDeclaracionService.actualizarSecException(secuencia);
			pintaMensaje(origen);
		}
		//if (variablesIngreso.get("mapGarantia")!=null) {
			//desafectaGarantia (declaracion, variablesIngreso);
		//}
	}
	
	private void pintaMensaje(String mensaje) {
		Long tiempo = System.currentTimeMillis();
		if (log.isDebugEnabled()) {
			log.debug(mensaje.concat(" - Hora: ").concat(tiempo.toString()));
		}
	}
	
	protected void actualizarEnvio(Integer annEnvio, Long numEnvio, Long num_corredoc){
		EnvioDAO envioDAO =  (EnvioDAO)fabricaDeServicios.getService("manifiesto.envioDAO");
		EnvioBean envio = new EnvioBean();
		envio.setAnioEnvio(annEnvio);
		envio.setNumeroEnvio(numEnvio);
		envio.setNumeroCorrelativo(num_corredoc);

		try {
			envioDAO.actualizarEnvio(envio);	
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}
}
