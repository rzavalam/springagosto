package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.administracion2.tramite.model.dao.ExpediDAO;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.CatEmpleadoDAO;
import pe.gob.sunat.despaduanero2.asignacion.model.dao.EspeDocuDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionAutomaticaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaEntidadService;
import pe.gob.sunat.despaduanero2.declaracion.model.CabCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetCtacteRegimenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TabImpDUDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.sigad.ingreso.service.ControlarSaldoReposicionService;//P28
import pe.gob.sunat.tecnologia.receptor.bean.EnvioBean;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioDAO;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.GrabarContingentesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.valorprovisional.ValidadorValorProvisionalService;//rin10
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.asignacion.bean.CatEmpleado;
import pe.gob.sunat.despaduanero2.asignacion.bean.EspeDocu;
import pe.gob.sunat.despaduanero2.asignacion.bean.FiltroCatEmpleado;

@SuppressWarnings("unchecked")
public class GrabarRegularizacionServiceImpl  extends ValDuaAbstract implements GrabarRegularizacionService {

	//private CatalogoAyudaService catalogoayudaservice;
	//private LiquidaDeclaracionService liquidaDeclaracionService;
	//private PlazosProcesoDAO plazosprocesodao;
	//private GrabarRectificacionService grabarRectificacionService;
	//private TabImpDUDAO tabImpDUDAO;
	//private CabDeclaraDAO cabDeclaraDAO;
	//private GeneraRespuestaService genRespuestaService;
	//private GrabarGeneralService grabarGeneralService;
	//EnvioDAO envioDAO;
	//private AsignacionAutomaticaService asignacionAutomaticaService;
	//private CabSolrectiDAO cabSolrectiDAO;
	//protected final Log log = LogFactory.getLog(getClass());
	//private PublicacionAvisoService publicacionAvisoService;
	//private FabricaDeServicios fabricaDeServicios; 
	//GrabarContingentesService grabarContingentesService;

	/*
	 * @ServicioAnnot(tipo="G",codServicio=0000,
	 * descServicio="servicio general de grabado de la regularizacion")
	 * 
	 * @ServInstDetAnnot(tipoRpta={1,1,1,1},nomAtr={"declaracion",
	 * "solicitudRectificacion","marcaRealizarDatado","marcaDesdatadoDatado"
	 * ,"deudadiferencial"})
	 * 
	 * @OrquestaDespaAnnot(codServInstancia=0000,numSecEjec=28,nomClase=
	 * "pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	 */	
	//	public Map<String, String> grabarRegularizacion(Declaracion declaracion,
	//			SolicitudRectificacionBean solicitudRectificacion, 
	//			Map<String, Object> variablesIngreso) throws Exception {
	//		return grabacionRegu(declaracion, solicitudRectificacion, variablesIngreso, true);
	//	}	
	@Transactional (rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
	public Map<String, String> grabarRegularizacion(Declaracion declaracion,
			SolicitudRectificacionBean solicitudRectificacion, 
			Map<String, Object> variablesIngreso) throws Exception {
		GrabarGeneralService grabarGeneralService = (GrabarGeneralService)fabricaDeServicios.getService("GrabarGeneralService");
		GrabarRectificacionService grabarRectificacionService = (GrabarRectificacionService)fabricaDeServicios.getService("GrabarRectificacionServiceImpl");
		boolean siGrabaRegu = false;
		boolean esGarantiaRenovada = false;
		String numeroDocumentoIdentidadSender = (String) variablesIngreso.get("numeroDocumentoIdentidadSender");
		String tipoDocumentoIdentidadSender = (String) variablesIngreso.get("tipoDocumentoIdentidadSender");
		String codUsuario = (String) variablesIngreso.get("codUsuario");
		Map<String, Object> deudadiferencial = (Map<String, Object>) variablesIngreso.get("deudadiferencial");
		// metodo Marcadesdatadodatado del valrectif
		Boolean marcaDesdatadoDatado = (Boolean) variablesIngreso.get("marcaDesdatadoDatado");
		// metodo Infoparadatado del valrectif
		Boolean marcaRealizarDatado = (Boolean) variablesIngreso.get("marcaRealizarDatado");
		Integer annEnvio = (Integer) variablesIngreso.get("annEnvio");
		Long numEnvio = (Long) variablesIngreso.get("numEnvio");
		String codTransaccion = (String) variablesIngreso.get("codTransaccion");
		String numOrden = (String) variablesIngreso.get("numOrden");
		String tipoDesp = (String) variablesIngreso.get("tipoDesp");
		Date fechaVencRegularizacion = (Date) variablesIngreso.get("fechVencRegul");
		//Date fechaConclusionDespa = (Date) variablesIngreso.get("fechaVenConclusion");//ahora se setea la fecha de vencimiento de conclusion. jreynoso
		Date fechaConclusionDespa = (Date) variablesIngreso.get("fechaConclusionDespa");//PAS201830001100011

		if(UserNameHolder.get()==null) 
			UserNameHolder.set(Constants.NOMBRE_USUARIO_AUDITORIA_ORQUESTADOR);

		Map<String, Object> params = new HashMap<String, Object>();
		//PAS20155E220000082 GGRANADOS INICIO - NO SE USA
		//Date FechaActual = new Date();
		//PAS20155E220000082 GGRANADOS FIN

		String codGarantia ="";
		/* Evalua si solo va datar o va desdatar y volver a datar. Si los datos son iguales que el manifiesto, solo regulariza.
			Y si los datos son diferentes debe desdatar, volviendo a datar y regulariza. las urgentes no datan ni desdatan*/
		if (!declaracion.getDua().getCodmodalidad().equals(Constantes.COD_MODALIDAD_URGENTE)) {
			if (marcaRealizarDatado != null && marcaRealizarDatado) {
				grabarGeneralService.registrarDatado(declaracion, Constants.COD_DATADO_REGULARIZACION, codTransaccion, variablesIngreso);
			}
			if (marcaDesdatadoDatado != null && marcaDesdatadoDatado) {
				grabarGeneralService.registrarDatado(declaracion, Constants.COD_DATADO_REGULARIZACION, codTransaccion, variablesIngreso);
			}
		}

		if (SunatStringUtils.include(codTransaccion.substring(2), new String[] { ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT })) { // XX04
			solicitudRectificacion.setCodtransaccion(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT);
		} else {
			solicitudRectificacion.setCodtransaccion(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG);
		}

		//PAS20165E220200076 RSERRANO CONTINGENTES SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
		if (codTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG) ||  codTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT)) {
			GrabarContingentesService grabarContingentesService = (GrabarContingentesService)fabricaDeServicios.getService("declaracion.grabarContingentesService");
			grabarContingentesService.procesarContingenteDiligencia(declaracion, variablesIngreso, false);

			/*INICIO-P28 FSW AFMA*/
			ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");
			controlarSaldoReposicionService.actualizarCtaCte(declaracion,codTransaccion);
			/*FIN-P28 FSW AFMA*/
		}

		if (codTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT)) {
			solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_REGULA_ACEPTADA_AUTOMATIC);
		} else {
			solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_REGULA_RECEPCIONADA);
		}

		if (declaracion.getDua().getCodmodalidad().equals(Constantes.MODALIDAD_ANTICIPADO)) { 
			grabarRectificacionService.Grabacabydetsolicitud(declaracion,
					solicitudRectificacion,
					ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION,
					ConstantesDataCatalogo.COD_EST_CONCLUIDO);

		} else if (declaracion.getDua().getCodmodalidad().equals(Constantes.MODALIDAD_URGENTE)) {
			grabarRectificacionService.Grabacabydetsolicitud(declaracion,
					solicitudRectificacion,
					ConstantesDataCatalogo.TIPO_SOLICITUD_REGULARIZACION,
					ConstantesDataCatalogo.COD_EST_INICIADO);
		}

		/* Evalua si debe grabar en tabla definitiva (condici�n para regularizacion es: cuando la dua es anticipada 
		 * (definir variable "SigrabaRegu" en sesion) */
		if (declaracion.getDua().getCodmodalidad().equals(Constantes.COD_MODALIDAD_ANTICIPADO)) { 
			siGrabaRegu = true;
		}

		DatoPago pago = declaracion.getDua().getPago();
		DatoPagoDecla decla = pago != null ? pago.getPagoDeclaracion() : null;
		codGarantia = decla != null ? decla.getCodgarantia() : null;

		/*
		 * Para "SigrabaRegu" cuando son anticipados � urgentes (tablas temporales): actualizar la fecha 
		 * de vencimiento de la regularizaci�n de despacho anticipado en el campo fec_vencregul de la tabla cab_declara}
		 *  con la fecha termino de descarga enviada 
		 *  (porque ya esta validada contra manifiestos) se le suma 15 d�as calendarios.
		 */

		if (declaracion.getDua().getCodmodalidad().equals(Constantes.COD_MODALIDAD_ANTICIPADO) && 
				declaracion.getDua().getFecvencregula().before(fechaVencRegularizacion)) {
			params.clear();  
			params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
			params.put("FEC_VENCREGULA", fechaVencRegularizacion);
			((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).update(params);
		}

		if (siGrabaRegu) {			
			grabarRectificacionService.grabaTablaNegocio(declaracion,solicitudRectificacion, codTransaccion);

			/* Para "SigrabaRegu", actualizar el campo fec_regulariza de la tabla cab_declara con el sysdate 
			 * y actualizar con sysdate el campo fech_Regul de la tabla tabimpdu. */
			params.clear(); 
			params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
			params.put("FEC_REGULARIZA", new FechaBean().getTimestamp());
			params.put("COD_ESTREGUL", estadoDeRegularizacion(declaracion,Constantes.COD_MODALIDAD_ANTICIPADO));

			if (conclusionAutomatica(declaracion)){
				params.put("FEC_CONCLUSION", new FechaBean().getTimestamp());
				params.put("COD_ESTDUA", Constantes.ESTADO_DECLARACION_DESPACHO_CONCLUIDO);
			}
			params.put("FEC_VENCREGULA", declaracion.getDua().getFecvencregula());
			CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
			cabDeclaraDAO.update(params);

			params.put("codaduana", declaracion.getNumdeclRef().getCodaduana());
			params.put("annprese", declaracion.getNumdeclRef().getAnnprese());
			params.put("numcorre", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0'));
			params.put("codregimen", declaracion.getNumdeclRef().getCodregimen());
			TabImpDUDAO tabImpDUDAO = (TabImpDUDAO)fabricaDeServicios.getService("tabImpDUDAO");
			tabImpDUDAO.actualizarFechRegul(params);

			//Si la declaraci�n tiene asociada una autorizaci�n IQBF, y la declaraci�n tiene modalidad de despacho anticipado
			//Actualizara el estado de la autorizaci�n IQBF a CONCLUIDA, y otros datos
			if (declaracion.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)){
				//PAS20155E220000082 GGRANADOS INICIO - NO SE USA
				//Declaracion declaracionXML = declaracion;
				//if (SunatStringUtils.include(variablesIngreso.get("codTransaccion").toString().substring(2,4), new String[] { "04" })) {
				//	declaracionXML = (Declaracion)variablesIngreso.get("declaracion");
				//}
				//PAS20155E220000082 GGRANADOS FIN
				((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).actualizarConclusionDocAutorizaIQBF(declaracion);
			}			

			actualizarCtaCteRegimen(declaracion, declaracion.getDua().getNumcorredoc());
		}		

		/* 
		 * Segun lo coordinado con elsa esto aplica para anticipadas y urgente
		 * Se hace una b�squeda para obtener todos los registros de la tabla deuda_docum.
		 * Si la fecha de vencimiento tiene el valor de 29991231 (Juan ha realizado un cambio para que siempre se grabe as� 29991231)
		 * Si tiene garant�a, la fecha de vencimiento ser� el valor del d�a 20 del mes siguiente tomando como referencia la fecha de termino de descarga.
		 * Sino tiene garant�a , la fecha de vencimiento ser� el valor de la fecha de termino de descarga.
		 * Se verifica si esta cancelado y si es tipo 01 (DUA), si se cumple se actualiza la fecha de vencimiento con el valor obtenido l�neas arriba.
		 * Sino  esta cancelado para tipo 01 y 02 se actualiza la fecha de vencimiento (con el valor obtenido l�neas arriba )del deuda_docum y se env�a la trama a bancos.
		 * */
		Boolean esAnticipada = declaracion.getDua().getCodmodalidad().equals(Constantes.COD_MODALIDAD_ANTICIPADO);
		Boolean esUrgenteAnticipada = variablesIngreso.containsKey("esUrgenteAnticipada")?(Boolean)variablesIngreso.get("esUrgenteAnticipada"):false; 


		if(esAnticipada || esUrgenteAnticipada){
			DeudaDocum dd=new DeudaDocum();
			DeudaDocum ddUpdate=new DeudaDocum();
			List<DeudaDocum> ListDocum= new ArrayList<DeudaDocum>();

			dd.setNumCorredoc(declaracion.getDua().getNumcorredoc());
			ListDocum=((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(dd);

			for(DeudaDocum deudaActual:ListDocum){
				Date fechaVencimiento =new Date();
				ddUpdate=new DeudaDocum();
				Boolean cancelado=false;
				ddUpdate.setNumCorredoc(deudaActual.getNumCorredoc());
				ddUpdate.setNumIdentdeuda(deudaActual.getNumIdentdeuda());
				if (SunatDateUtils.getIntegerFromDate(deudaActual.getFecVenc()).equals(29991231)){
					if (codGarantia!=null && !"".equals(codGarantia)){// Si tiene garantia,fecha de termino de descarga + el dia 20 del mes siguiente 05/05/2010 coordinado con JCV y EMM.
						fechaVencimiento=declaracion.getDua().getManifiesto().getFectermino();
						fechaVencimiento=SunatDateUtils.addMonth(fechaVencimiento, 1);
						fechaVencimiento=SunatDateUtils.getDateFromInteger(SunatNumberUtils.toInteger(SunatStringUtils.substring(SunatDateUtils.getIntegerFromDate(fechaVencimiento).toString(), 0, 6).concat("20")));

					}else{// Si no tiene garantia colocar solo la fecha de termino de descarga
						fechaVencimiento=SunatDateUtils.getOnlyDateFrom(declaracion.getDua().getManifiesto().getFectermino());
					}

					// La verificacion se realiza para tipo 01 y 02
					if (SunatStringUtils.include(deudaActual.getCodTipdeuda(), new String[] {"01","02"})){
						if (SunatNumberUtils.isGreaterOrEqualsThanParam(deudaActual.getMtoPagado(), deudaActual.getMtoDeuda())){ // El monto pagado es mayor o igual de la deuda
							cancelado=true;
						}

					}
					// Si esta cancelado y si es tipo formato C 01 se actualiza la fecha de vencimiento del deuda_docum
					//if (cancelado && "01".equals(deudaActual.getCodTipdeuda()) ){
					String indiceCDA = SunatStringUtils.substringFox(deudaActual.getNumCda(), 14, 2);
					if (cancelado && SunatStringUtils.isStringInList(indiceCDA, "01,96")) {				
						ddUpdate.setFecVenc(fechaVencimiento);
						((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).updateByPrimaryKeySelective(ddUpdate);
					}
					if (!cancelado && SunatStringUtils.include(deudaActual.getCodTipdeuda(), new String[] { "01", "02" })) {
						ddUpdate.setFecVenc(fechaVencimiento);
						((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).updateByPrimaryKeySelective(ddUpdate);

					}
				}
			}
		}
		/*
		 * 04	8	Para "SigrabaRegu" hacer grabado del adeudo para los reg�menes: 10; 20 y 21
		 * solo para los anticipados liquidacion y garantia// modificacion pase PAS20145E220000399 -  liquidacion y garantia para despachos urgentes garantizados, regimen 10
		 * */
		// inicio PAS201830001100011 
  		Declaracion odeclaracion = (Declaracion)variablesIngreso.get("declaracion");
  		odeclaracion.getDua().setCodCanal(variablesIngreso.get("COD_CANAL")!=null?(String)variablesIngreso.get("COD_CANAL"):"");//PAS20175E220200021
  		
  		Declaracion odeclaracionBD = (Declaracion)variablesIngreso.get("declaracionBD");          
  		if (tieneVP(odeclaracionBD)) {
  		ValidadorValorProvisionalService validadorValorProvisionalService = (ValidadorValorProvisionalService)fabricaDeServicios.getService("ingreso.validadorValorProvisionalService");
  		Map mapVP = validadorValorProvisionalService.grabarValorProvisional(odeclaracion,odeclaracionBD);
  		
  		if(!CollectionUtils.isEmpty(mapVP)){
  			variablesIngreso.put("mapVP", mapVP!=null?mapVP:new HashMap());             
  		}       
  		}
  	    // fin PAS201830001100011   
		boolean grabaTrama = false; //PAS20165E220200094 - mtorralba 20160705 
		if (siGrabaRegu || (declaracion.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) && codGarantia!=null && !"".equals(codGarantia) && declaracion.getDua().getCodregimen().equals(Constantes.REGIMEN_10_IMPORTACION_CONSUMO))) {
			if (SunatStringUtils.include(declaracion.getDua().getCodregimen(), new String[]{Constantes.REGIMEN_10_IMPORTACION_CONSUMO,Constantes.REGIMEN_20_ADM_TMP_MISMO_ESTADO,Constantes.REGIMEN_21_ADM_TMP_PERFEC_ACTIVO})){
				Map<String, Object> mapRetornoLiqui = grabarRectificacionService.Grabadocadeudo(declaracion, deudadiferencial, variablesIngreso);
				if ("OK".equals(mapRetornoLiqui.get("GRABACION"))) {
					variablesIngreso.put("RESULTADO_LIQ", mapRetornoLiqui);
					esGarantiaRenovada = mapRetornoLiqui.get("GARANTIA_RENOVADA") != null ? (Boolean)mapRetornoLiqui.get("GARANTIA_RENOVADA") : false;
					//PAS20165E220200094 - mtorralba 20160705 - Verificamos si corresponde enviar a Bancos
					grabaTrama = mapRetornoLiqui.get("TRAMA_DUA").toString().equals("SI"); 
				}
			}

			if (!declaracion.getDua().getCodregimen().equals(Constantes.REGIMEN_70_DEPOSITO) && !esGarantiaRenovada) {				
				grabarGeneralService.afectaGarantia(declaracion, numeroDocumentoIdentidadSender, tipoDocumentoIdentidadSender, numOrden, codUsuario, "", tipoDesp, fechaConclusionDespa, variablesIngreso);

				//PAS20165E220200094 - mtorralba 20160705 - Graba trama 1010 cuando corresponda
				if( grabaTrama ) {
					LiquidaDeclaracionService liquidaDeclaracionService = (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
					liquidaDeclaracionService.grabaTrama(variablesIngreso);
				}
			}
		}

		if(solicitudRectificacion.getCodtransaccion().equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG)){
			AsignacionAutomaticaService asignacionAutomaticaService = (AsignacionAutomaticaService)fabricaDeServicios.getService("asignacion.service.asignacionAutomatica");
			asignacionAutomaticaService.asignarEspeGECSolRegularizacion(solicitudRectificacion.getNumcorredoc(), solicitudRectificacion.getCodtransaccion());
		}

		actualizarEnvio(annEnvio, numEnvio, solicitudRectificacion.getNumcorredoc());
		variablesIngreso.put("numCorreDocSolicitud", solicitudRectificacion.getNumcorredoc());
		GeneraRespuestaService genRespuestaService = (GeneraRespuestaService)fabricaDeServicios.getService("GenRespuestaServiceImpl");
		genRespuestaService.generaRespuestaEnvio(0, variablesIngreso);


		//Si existe error en grabado de notificaciones, no se debe impedir grabado de regularizaci�n
		try{
			grabarNotificaciones (declaracion, solicitudRectificacion);
		}catch(Exception e){
			log.error(e.getStackTrace()); 
		}

		return new HashMap<String, String>();
	}

	//gmontoya P29 Pase 15 2015 inicio 
	private void actualizarCtaCteRegimen(Declaracion declaracion, Long numCorreDoc){
		boolean esTPN21 = false;

		for(DatoSerie serie:declaracion.getDua().getListSeries()){		
			if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()!=0){
				esTPN21 = serie.getCodtratprefe()==21;
				break;
			}
		}
		if(esTPN21){
			DetCtacteRegimenDAO detCtacteRegimenDAO = fabricaDeServicios.getService("declaracion.detCtaCteRegimen");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("numCorredocDesc", numCorreDoc);
			params.put("indAnulacion", "1");		  
			List<DetCtacteRegimen> listaDet = detCtacteRegimenDAO.listaByKeyMap(params);

			for(DatoSerie serie:declaracion.getDua().getListSeries()){		
				for(DatoRegPrecedencia prec:serie.getListRegPrecedencia()){
					if( esTPN21 ) {
						fillCabCtacteRegimen(serie, prec, numCorreDoc, listaDet);
					}
				}
			}
		}

	}

	private void fillCabCtacteRegimen(DatoSerie serie, DatoRegPrecedencia prec, Long numCorredoc,List<DetCtacteRegimen> listaDet){

		DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
		Map<String,Object> paramCtaCte = new HashMap<String,Object>();
		paramCtaCte.put("codAduana", prec.getCodaduapre());
		paramCtaCte.put("annPresen", prec.getAnndeclpre().substring(0, 4));
		paramCtaCte.put("codRegimen", prec.getCodregipre());
		paramCtaCte.put("numDeclaracion", prec.getNumdeclpre());
		paramCtaCte.put("numSecserie", prec.getNumserpre());
		List<CabCtacteRegimen> listaCabCtacteRegimen = ctaCteService.obtenerCabeceraCtaCte(paramCtaCte);
		if( listaCabCtacteRegimen.size()>0 ) {
			CabCtacteRegimen ctacte = listaCabCtacteRegimen.get(0); 
			boolean actualizarRegu = false;
			BigDecimal diferencia = BigDecimal.ZERO;
			for(DetCtacteRegimen detCtaCte : listaDet){
				if(detCtaCte.getNumCtacte().equals(ctacte.getNumCtacte()) && 
						detCtaCte.getNumSerieDesc().equals(serie.getNumserie())){
					diferencia = SunatNumberUtils.diference(serie.getCntunicomer(), detCtaCte.getCntDescargada());
					actualizarRegu = true;
					break;
				}
			}
			if(actualizarRegu && diferencia.compareTo(BigDecimal.ZERO)!=0){
				ctaCteService.actualizaReguCtacteRegimen(ctacte, serie, numCorredoc,diferencia);
			}else{
				if(!actualizarRegu){
					ctaCteService.actualizaCtacteRegimen(ctacte, serie, numCorredoc);
				}
			}
		}

		return;
	}
	//gmontoya P29 Pase 15 2015 fin 
	/**
	 * Grabar notificaciones correspondientes a la regularizacion 
	 * @author olunar - 2012-06-25
	 * @param declaracion
	 */
	private void grabarNotificaciones(Declaracion declaracion, SolicitudRectificacionBean solicitudRectificacion) {
		PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService) fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		// Notificaci�n al Despachador de Aduana por Aceptaci�n de Regularizaci�n de Dua
		mapMensaje.put("tip_usuario", "1");
		mapMensaje.put("cod_usuario", new String[] { declaracion.getDua().getNumdocumento() });
		ExigibilidadService exigibilidadService = fabricaDeServicios.getService("declaracion.ingreso.exigibilidadService");
		Participante agenciaAduana = exigibilidadService.findRucParticipante(declaracion.getDua().getNumcorredoc(), Constantes.COD_TIPO_PARTICIPANTE_AGENTE_ADUANA);

		if (solicitudRectificacion.getCodtransaccion().equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG)) {
			EspeDocu espeDocu = new EspeDocu();
			espeDocu.setNumCorreDoc(solicitudRectificacion.getNumcorredoc());
			EspeDocuDAO espeDocuDAO = (EspeDocuDAO) fabricaDeServicios.getService("asignacion.espeDocuDAO");
			StringBuffer elaboradorPor = new StringBuffer("");
			if (espeDocuDAO.getEspecAsigDoc(espeDocu).getCodFuncionario() != null) {
				String codFuncionario = espeDocuDAO.getEspecAsigDoc(espeDocu).getCodFuncionario().toUpperCase();
				FiltroCatEmpleado filtro = new FiltroCatEmpleado();
				filtro.setCodPers(codFuncionario);
				CatEmpleadoDAO catEmpleadoDAO = (CatEmpleadoDAO) fabricaDeServicios.getService("asignacion.catEmpleadoDAO");
				CatEmpleado catEmpleado = catEmpleadoDAO.consultarCatEmpleado(filtro);
				elaboradorPor
				.append(catEmpleado.getApPate().trim())
				.append(" ")
				.append(catEmpleado.getApMate().trim())
				.append(" ")
				.append(catEmpleado.getNombres().trim());				
			} else {
				elaboradorPor.append(declaracion.getDua().getCodaduanaorden()
						.equals(ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO) ? "Divisi&oacute;n de Importaci&oacute;n de la IAMC"
								: "Departamento de T&eacute;cnica Aduanera");				
			}
			mapMensaje.put("des_asunto",Constants.ASUNTO_NOTIF_ACEPTA_SOLICITUD_REGULA_DESPACHO_URGENTE);
			mapMensaje.put("ruc", agenciaAduana.getNumeroDocumentoIdentidad());
			mapMensaje.put("razonsocial", agenciaAduana.getNombreRazonSocial());
			mapMensaje.put("elaboradopor", elaboradorPor.toString());
		}
		else{
			mapMensaje.put("des_asunto", Constants.ASUNTO_NOTIF_ACEPTA_SOLICITUD_REGULA_DESPACHO_ANTICIPADO);
		}

		mapMensaje.put("razonsocial", agenciaAduana.getNombreRazonSocial());
		mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
		mapMensaje.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
		mapMensaje.put("ann_presen", declaracion.getDua().getAnnpresen().toString());
		mapMensaje.put("cod_regimen", declaracion.getDua().getCodregimen().toString());
		mapMensaje.put("num_declaracion", declaracion.getNumeroDeclaracion().toString());

		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
		if (solicitudRectificacion.getCodtransaccion().equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG)){// RIN16_Pase400
			publicacionAvisoService.insert(Constants.COD_NOTIF_ACEPTA_SOLICITUD_REGULA_DESPACHO_URGENTE,
					data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
					fechaActual.getTimestamp(),
					fechaVigencia.getTimestamp());
		} else {
			publicacionAvisoService.insert(Constants.COD_NOTIF_ACEPTA_SOLICITUD_REGULA_DESPACHO_ANTICIPADO,
					data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
					fechaActual.getTimestamp(),
					fechaVigencia.getTimestamp());
		}

		// Notificaci�n al Due�o o Consignatario por Aceptaci�n de Regularizaci�n de Dua
		if (declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().equals(Constants.COD_DATA_CATALOG_TIPO_DOC_RUC)) {
			mapMensaje.put("cod_usuario", new String[] { declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad() });
			if (solicitudRectificacion.getCodtransaccion().equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG)) {
				Participante importador = exigibilidadService.findRucParticipante(declaracion.getDua().getNumcorredoc(), Constantes.COD_TIPO_PARTICIPANTE_IMPORTADOR);
				mapMensaje.put("ruc", importador.getNumeroDocumentoIdentidad());
				mapMensaje.put("razonsocial", importador.getNombreRazonSocial());
				data = new StringBuffer(SojoUtil.toJson(mapMensaje));
				publicacionAvisoService.insert(Constants.COD_NOTIF_ACEPTA_SOLICITUD_REGULA_DESPACHO_URGENTE,
						data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
						fechaActual.getTimestamp(),
						fechaVigencia.getTimestamp());
			} else {
				publicacionAvisoService.insert(Constants.COD_NOTIF_ACEPTA_SOLICITUD_REGULA_DESPACHO_ANTICIPADO,
						data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
						fechaActual.getTimestamp(),
						fechaVigencia.getTimestamp());
			}
		}
	}

	protected void actualizarEnvio(Integer annEnvio, Long numEnvio, Long num_corredoc) {
		EnvioDAO envioDAO =  (EnvioDAO)fabricaDeServicios.getService("manifiesto.envioDAO");
		EnvioBean envio = new EnvioBean();
		envio.setAnioEnvio(annEnvio);
		envio.setNumeroEnvio(numEnvio);
		envio.setNumeroCorrelativo(num_corredoc);

		try {
			envioDAO.actualizarEnvio(envio);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	public String estadoDeRegularizacion(Declaracion declaracion, String tipoEstado) {
		String estado = "";
		Date fecSegundaRecepcion;
		Date fecVencPlazoRegul = declaracion.getDua().getFecvencregula();

		if (!verificaTienePlazoAmpliado(declaracion)) {
			if (Constantes.COD_MODALIDAD_ANTICIPADO.equals(tipoEstado)) {
				fecSegundaRecepcion = new Date();
			} else {
				fecSegundaRecepcion = declaracion.getDua().getFecSegundaRecepcion();
			}

			if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fecVencPlazoRegul, fecSegundaRecepcion, SunatDateUtils.COMPARA_SOLO_FECHA)) {
				estado = Constantes.REGULARIZADA_DENTRO_DEL_PLAZO;
			} else {
				if (verificaTieneExpedienteSuspensionPlazo(declaracion)) {
					estado = Constantes.REGULARIZADA_CON_SUSPENSION_DE_PLAZO;
				} else {
					estado = Constantes.REGULARIZADA_FUERA_DEL_PLAZO;
				}
			}
		} else {
			estado = Constantes.REGULARIZADA_CON_SUSPENSION_DE_PLAZO;
		}
		return estado;
	}

	/**
	 * Verifica si la declaracion cuenta con indicador [22] para la conclusion automatica
	 * @param decVen
	 * @return
	 */
	private boolean conclusionAutomatica(Declaracion declaracion){

		ProveedorFuncionesService provFuncService = fabricaDeServicios.getService("funcionesService");

		List<DatoIndicadores> listindicadores = provFuncService.getIndicadorDUA(declaracion.getDua().getNumcorredoc(), Constants.INDICADOR_CONCLUSION_AUTOMATICA, Constants.TIPO_ORIGEN_PORTALFUNCIONARIO, Constants.INDICADOR_ACTIVO);

		if (!CollectionUtils.isEmpty(listindicadores)){
			for(DatoIndicadores indicador:listindicadores){
				if (Constants.INDICADOR_CONCLUSION_AUTOMATICA.equals(indicador.getCodtipoindica())){
					return true;				}
			}
		}
		return false;
	}

	private boolean tieneVP(Declaracion declaracion){ 

		ProveedorFuncionesService provFuncService = fabricaDeServicios.getService("funcionesService");

		List<DatoIndicadores> listindicadores = provFuncService.getIndicadorDUA(declaracion.getDua().getNumcorredoc(), Constantes.COD_INDICADOR_VP, ConstantesDataCatalogo.COD_TIPOREGISTRO_AUTOMATICO, Constants.INDICADOR_ACTIVO);

		if (!CollectionUtils.isEmpty(listindicadores)){
			for(DatoIndicadores indicador:listindicadores){
				if (Constantes.COD_INDICADOR_VP.equals(indicador.getCodtipoindica())){
					return true;				}
			}
		}
		return false;
	}
	
	/**
	 * Verifica si la declaracion cuenta con plazo ampliado
	 * @param decVen
	 * @return
	 */
	private boolean verificaTienePlazoAmpliado(Declaracion declaracion) {
		ProveedorFuncionesService provFuncService = fabricaDeServicios.getService("funcionesService");
		Date fecRegularizacion = provFuncService.getFechaRegularizacion(declaracion.getDua(), declaracion.getDua().getManifiesto().getFectermino());
		Date fecTransRegularizacion = new Date();

		if (SunatDateUtils.esFecha1MayorQueFecha2(declaracion.getDua().getFecvencregula(), fecRegularizacion, SunatDateUtils.COMPARA_SOLO_FECHA) &&
				SunatDateUtils.esFecha1MayorQueFecha2(fecTransRegularizacion, fecRegularizacion, SunatDateUtils.COMPARA_SOLO_FECHA)){
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Verifica si la declaracion cuenta con un expediente concluido [05] para la suspension del plazo
	 * @param decVen
	 * @return
	 */
	private boolean verificaTieneExpedienteSuspensionPlazo(Declaracion decVen) {
		Map<String, Object> mapaExpedi = new HashMap<String, Object>();
		mapaExpedi.put("COD_ADUANA", decVen.getCodaduana());
		mapaExpedi.put("NUM_DECLARACION", decVen.getNumeroDeclaracion());
		mapaExpedi.put("COD_REGIMEN", decVen.getCodregimen());
		mapaExpedi.put("ANN_PRESEN", decVen.getDua().getAnnpresen().toString());
		mapaExpedi.put("PROCEDIM", "1606");
		mapaExpedi.put("TIPO_CONC", Constants.CODIGO_EXPEDIENTE_CONCLUIDO);

		ExpediDAO expediDAO = fabricaDeServicios.getService("tramite.expediDS");
		List<Map<String, Object>> listaExpedientes = expediDAO.findByProdedimiento(mapaExpedi);

		if (CollectionUtils.isEmpty(listaExpedientes)) {
			return false;
		} else {
			return true;
		}
	}

	/************************************************
	 * estableciendo setters de los servicios
	 ************************************************/
	/*
	public PlazosProcesoDAO getPlazosprocesodao() {
		return plazosprocesodao;
	}
	
	public CatalogoAyudaService getCatalogoayudaservice() {
		return catalogoayudaservice;
	}

	public void setCatalogoayudaservice(CatalogoAyudaService catalogoayudaservice) {
		this.catalogoayudaservice = catalogoayudaservice;
	}

	public LiquidaDeclaracionService getLiquidaDeclaracionService() {
		return liquidaDeclaracionService;
	}

	public void setLiquidaDeclaracionService(LiquidaDeclaracionService liquidaDeclaracionService) {
		this.liquidaDeclaracionService = liquidaDeclaracionService;
	}
	 
	public GrabarRectificacionService getGrabarRectificacionService() {
		return grabarRectificacionService;
	}

	public void setGrabarRectificacionService(GrabarRectificacionService grabarRectificacionService) {
		this.grabarRectificacionService = grabarRectificacionService;
	}

	public TabImpDUDAO getTabImpDUDAO() {
		return tabImpDUDAO;
	}

	public void setTabImpDUDAO(TabImpDUDAO tabImpDUDAO) {
		this.tabImpDUDAO = tabImpDUDAO;
	}

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public GeneraRespuestaService getGenRespuestaService() {
		return genRespuestaService;
	}

	public void setGenRespuestaService(GeneraRespuestaService genRespuestaService) {
		this.genRespuestaService = genRespuestaService;
	}

	public void setPlazosprocesodao(PlazosProcesoDAO plazosprocesodao) {
		this.plazosprocesodao = plazosprocesodao;
	}

	
	public GrabarGeneralService getGrabarGeneralService() {
		return grabarGeneralService;
	}

	public void setGrabarGeneralService(GrabarGeneralService grabarGeneralService) {
		this.grabarGeneralService = grabarGeneralService;
	}
	 
	public EnvioDAO getEnvioDAO() {
		return envioDAO;
	}

	public void setEnvioDAO(EnvioDAO envioDAO) {
		this.envioDAO = envioDAO;
	}

	public CabSolrectiDAO getCabSolrectiDAO() {
		return cabSolrectiDAO;
	}

	public void setCabSolrectiDAO(CabSolrectiDAO cabSolrectiDAO) {
		this.cabSolrectiDAO = cabSolrectiDAO;
	}

	public AsignacionAutomaticaService getAsignacionAutomaticaService() {
		return asignacionAutomaticaService;
	}

	public void setAsignacionAutomaticaService(AsignacionAutomaticaService asignacionAutomaticaService) {
		this.asignacionAutomaticaService = asignacionAutomaticaService;
	}

	public void setPublicacionAvisoService(PublicacionAvisoService publicacionAvisoService) {
		this.publicacionAvisoService = publicacionAvisoService;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setGrabarContingentesService(GrabarContingentesService grabarContingentesService) {
		this.grabarContingentesService = grabarContingentesService;
	}*/
}
