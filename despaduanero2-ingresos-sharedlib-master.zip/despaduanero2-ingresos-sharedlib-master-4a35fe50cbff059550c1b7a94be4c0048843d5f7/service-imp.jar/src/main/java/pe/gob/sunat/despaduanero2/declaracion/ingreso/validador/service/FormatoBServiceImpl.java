package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;




//import pe.gob.sunat.despaduanero2.ayudas.model.dao.CantmaxlibeDAO;
//import pe.gob.sunat.despaduanero2.ayudas.model.dao.CatModvehiDAO;

//import pe.gob.sunat.despaduanero2.declaracion.model.dao.EmpreDtnDAO;

@Deprecated
public class FormatoBServiceImpl {

	/*private static FormatoBServiceImpl instance;
	private ApplicationContext appContext= null;
	private ProveedorFuncionesService funcionesService;
	private CatalogoHelperImpl catalogoHelper;
	private GrabarFormatoBService grabarFormatoBService; 
	
	private GetDeclaracionService declaracionService;
	private SoporteService soporteService; 
	//DAO de consulta de datos
	PublicasDAO publicasDAO;
//	EmpredtnDAO empreDtnDAO;
	OpeComExtDAO opeComExtDAO;
	TabRucDAO tabRucDAO;
	TabLibeDAO tablibeDAO ;
	DeclaranDAO declaranDAO;
	DetPosicionDAO detPosicionDAO;
	CabImportFrecDAO cabImportFrecDAO;
	ResSpimDAO resSpimDAO;
	MrestriDAO mrestriDAO;
	TabDescMinDAO tabDescMinDAO;
//	CatRefpartidasDAO catRefPartidasDAO;


	CatRefRucDAO catRefRucDAO;
//	CantmaxlibeDAO cantMaxLibeDAO;
	CategVehiDAO categVehiDAO;
//	CatModvehiDAO catModVehiDAO;
	CabDeclaraDAO cabDeclaraDAO;
	DetDeclaraDAO detDeclaraDAO;
	ComprobPagoDAO comprobPagoDAO;
	ItemFacturaDAO itemFacturaDAO;
	SeriesItemDAO serieItemDAO;
	ParticipanteDocDAO participanteDocDAO;
	DdpDAO ddpDAO;*/
	//private FormBItemDescriDAO formBItemDescriDAO;
	
	private FormatoBServiceImpl() {
	}
	
	/*public static FormatoBServiceImpl getInstance() {
		if(instance == null )
		{
			instance = new FormatoBServiceImpl();
			
			
			instance.catalogoHelper = new CatalogoHelperImpl();			
			instance.funcionesService = new ProveedorFuncionesServiceImpl();

			
			String classpath= "classpath:pe/gob/sunat/despaduanero2/declaracion/ingreso/validador/config/";			
			instance.appContext = new FileSystemXmlApplicationContext(new String[]{classpath+"iavalidaformatob-data.xml", classpath+"iavalidaformatob-service.xml" });

			instance.grabarFormatoBService = (GrabarFormatoBService) instance.appContext.getBean("grabarFormatoBService");						
			instance.publicasDAO 	= 	(PublicasDAO)instance.appContext.getBean("publicasDAO");
			instance.empreDtnDAO 	= 	(EmpreDtnDAO)instance.appContext.getBean("empreDtnDAO");
			instance.opeComExtDAO 	= 	(OpeComExtDAO)instance.appContext.getBean("opeComExtDAO");
			instance.tabRucDAO 		= 	(TabRucDAO)instance.appContext.getBean("tabRucDAO");
			instance.tablibeDAO 	= 	(TabLibeDAO)instance.appContext.getBean("tablibeDAO");
			instance.declaranDAO 	= 	(DeclaranDAO)instance.appContext.getBean("declaranDAO");
			instance.detPosicionDAO = 	(DetPosicionDAO)instance.appContext.getBean("detPosicionDAO");
			instance.cabImportFrecDAO = (CabImportFrecDAO)instance.appContext.getBean("cabImportFrecDAO");
			instance.resSpimDAO 	= 	(ResSpimDAO)instance.appContext.getBean("resSpimDAO");
			instance.mrestriDAO 	= 	(MrestriDAO)instance.appContext.getBean("mrestriDAO");
			instance.tabDescMinDAO 	= 	(TabDescMinDAO)instance.appContext.getBean("tabDescMinDAO");
			instance.catRefPartidasDAO 	= 	(CatRefPartidasDAO)instance.appContext.getBean("catRefPartidasDAO");
			
		}
		
		return instance;
	}
	
	public CatalogoHelperImpl getValidadorCatalogo()
	{
		return catalogoHelper;
	}
	
	public ProveedorFuncionesService getFuncionesService() {
		return funcionesService;
	}

	public PublicasDAO getPublicasDAO() {
		return publicasDAO;
	}

	

	public OpeComExtDAO getOpeComExtDAO() {
		return opeComExtDAO;
	}

	public TabRucDAO getTabRucDAO() {
		return tabRucDAO;
	}

	public void setPublicasDAO(PublicasDAO publicasDAO) {
		this.publicasDAO = publicasDAO;
	}



//	public EmpredtnDAO getEmpreDtnDAO() {
//		return empreDtnDAO;
//	}
//
//	public void setEmpreDtnDAO(EmpredtnDAO empreDtnDAO) {
//		this.empreDtnDAO = empreDtnDAO;
//	}

	public void setOpeComExtDAO(OpeComExtDAO opeComExtDAO) {
		this.opeComExtDAO = opeComExtDAO;
	}

	public void setTabRucDAO(TabRucDAO tabRucDAO) {
		this.tabRucDAO = tabRucDAO;
	}

	public TabLibeDAO getTablibeDAO() {
		return tablibeDAO;
	}

	public void setTablibeDAO(TabLibeDAO tablibeDAO) {
		this.tablibeDAO = tablibeDAO;
	}

	public DeclaranDAO getDeclaranDAO() {
		return declaranDAO;
	}

	public void setDeclaranDAO(DeclaranDAO declaranDAO) {
		this.declaranDAO = declaranDAO;
	}

	public DetPosicionDAO getDetPosicionDAO() {
		return detPosicionDAO;
	}

	public void setDetPosicionDAO(DetPosicionDAO detPosicionDAO) {
		this.detPosicionDAO = detPosicionDAO;
	}

	public CabImportFrecDAO getCabImportFrecDAO() {
		return cabImportFrecDAO;
	}

	public void setCabImportFrecDAO(CabImportFrecDAO cabImportFrecDAO) {
		this.cabImportFrecDAO = cabImportFrecDAO;
	}

	public ResSpimDAO getResSpimDAO() {
		return resSpimDAO;
	}

	public void setResSpimDAO(ResSpimDAO resSpimDAO) {
		this.resSpimDAO = resSpimDAO;
	}

	public MrestriDAO getMrestriDAO() {
		return mrestriDAO;
	}

	public void setMrestriDAO(MrestriDAO mrestriDAO) {
		this.mrestriDAO = mrestriDAO;
	}

	public TabDescMinDAO getTabDescMinDAO() {
		return tabDescMinDAO;
	}

	public void setTabDescMinDAO(TabDescMinDAO tabDescMinDAO) {
		this.tabDescMinDAO = tabDescMinDAO;
	}

	public CatalogoHelperImpl getCatalogoHelper() {
		return catalogoHelper;
	}

	public GrabarFormatoBService getGrabarFormatoBService() {
		return grabarFormatoBService;
	}

	public void setGrabarFormatoBService(GrabarFormatoBService grabarFormatoBService) {
		this.grabarFormatoBService = grabarFormatoBService;
	}

	

	public CatRefRucDAO getCatRefRucDAO() {
		return catRefRucDAO;
	}

	public void setCatRefRucDAO(CatRefRucDAO catRefRucDAO) {
		this.catRefRucDAO = catRefRucDAO;
	}

	

	public CategVehiDAO getCategVehiDAO() {
		return categVehiDAO;
	}

	

	public void setCategVehiDAO(CategVehiDAO categVehiDAO) {
		this.categVehiDAO = categVehiDAO;
	}

//	public CantmaxlibeDAO getCantMaxLibeDAO() {
//		return cantMaxLibeDAO;
//	}
//
//	public void setCantMaxLibeDAO(CantmaxlibeDAO cantMaxLibeDAO) {
//		this.cantMaxLibeDAO = cantMaxLibeDAO;
//	}
//
//
//
//	public CatModvehiDAO getCatModVehiDAO() {
//		return catModVehiDAO;
//	}
//
//	public void setCatModVehiDAO(CatModvehiDAO catModVehiDAO) {
//		this.catModVehiDAO = catModVehiDAO;
//	}

	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}

	public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
		this.catalogoHelper = catalogoHelper;
	}	
	

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public DetDeclaraDAO getDetDeclaraDAO() {
		return detDeclaraDAO;
	}

	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}

	public ComprobPagoDAO getComprobPagoDAO() {
		return comprobPagoDAO;
	}

	public void setComprobPagoDAO(ComprobPagoDAO comprobPagoDAO) {
		this.comprobPagoDAO = comprobPagoDAO;
	}

	public ItemFacturaDAO getItemFacturaDAO() {
		return itemFacturaDAO;
	}

	public void setItemFacturaDAO(ItemFacturaDAO itemFacturaDAO) {
		this.itemFacturaDAO = itemFacturaDAO;
	}

	public SeriesItemDAO getSerieItemDAO() {
		return serieItemDAO;
	}

	public void setSerieItemDAO(SeriesItemDAO serieItemDAO) {
		this.serieItemDAO = serieItemDAO;
	}

	public ParticipanteDocDAO getParticipanteDocDAO() {
		return participanteDocDAO;
	}

	public void setParticipanteDocDAO(ParticipanteDocDAO participanteDocDAO) {
		this.participanteDocDAO = participanteDocDAO;
	}

	public DdpDAO getDdpDAO() {
		return ddpDAO;
	}

	public void setDdpDAO(DdpDAO ddpDAO) {
		this.ddpDAO = ddpDAO;
	}

	public void setDeclaracionService(GetDeclaracionService declaracionService) {
		this.declaracionService = declaracionService;
	}

	public GetDeclaracionService getDeclaracionService() {
		return declaracionService;
	}

        public SoporteService getSoporteService() {
		return soporteService;
	}

	public void setSoporteService(SoporteService soporteService) {
		this.soporteService = soporteService;
	}

        public FormBItemDescriDAO getFormBItemDescriDAO() {
		return formBItemDescriDAO;
	}

	public void setFormBItemDescriDAO(FormBItemDescriDAO formBItemDescriDAO) {
		this.formBItemDescriDAO = formBItemDescriDAO;
	}*/
//	public void setCatRefPartidasDAO(CatRefpartidasDAO catRefPartidasDAO) {
//		this.catRefPartidasDAO = catRefPartidasDAO;
//	}
//
//	public CatRefpartidasDAO getCatRefPartidasDAO() {
//		return catRefPartidasDAO;
//	}

	
}
