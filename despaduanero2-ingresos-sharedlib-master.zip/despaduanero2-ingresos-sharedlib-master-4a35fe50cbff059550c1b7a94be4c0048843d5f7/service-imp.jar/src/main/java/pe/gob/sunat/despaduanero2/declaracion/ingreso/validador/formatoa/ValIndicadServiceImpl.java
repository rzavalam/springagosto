/*
 * Clase que define el servicio de validaciones de Relaci�n de indicadores no comunes  para ciertos regimenes
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.despaduanero.catalogo.tg.model.MRestri;
import pe.gob.sunat.despaduanero.catalogo.tg.service.MrestriDAOService;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;

/**
 * The Class ValIndicad. Clase que define el servicio de validaciones de Relaci�n de indicadores no comunes  para ciertos regimenes.
 */
public class ValIndicadServiceImpl extends ValDuaAbstract implements ValIndicad {

	//private FabricaDeServicios fabricaDeServicios;
	//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
	//private CatalogoAyudaService catalogoAyudaService;
	//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
	//private CatalogoHelperImpl catalogoHelper;
	//private CatalogoAyudaService catalogoAyudaService;
	//private ProveedorFuncionesService funcionesService;
	
	
	/**
	 * Valida el C�digo del tipo de indicador.<br>
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * @param codtipoindica String. C�digo del tipo de indicador.
	 * @return Map<String, ?>
	 * 
	 */
	public Map<String, ?> codtipoindica(String codtipoindica){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("302", codtipoindica))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("302", codtipoindica,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30029","Error catalogo codtipoindica");
	}

	/**
	 * Si es v&aacute;lido se devuelve mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param valindicador String
	 * @return Map
	 */
	public Map<String, ?> valindicador(String valindicador){
		return !SunatStringUtils.isEmptyTrim(valindicador)?new HashMap<String,String>():getDUAError("30030", "");
	}


	public boolean tieneUnidfis(String codigoUnidfis){
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DataGrupoCat txGrupoUnidfis = catalogoAyudaService.getDataGrupoCat(ConstantesGrupoCatalogo.GRUPO_CATALOGO_PESOS_VOLUMEN, codigoUnidfis);
		boolean existeUnidFis = txGrupoUnidfis != null;
		return existeUnidFis ;
	}

	private Map<String, Object> obtenerMapDua(Declaracion declaracion) {
//		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
		Map<String, Object> params = new HashMap<String, Object>();
		/* estos datos son clabes de la dua */
		params.put("codigoAduana", declaracion.getNumdeclRef().getCodaduana());
		params.put("annoPresentacion", declaracion.getNumdeclRef().getAnnprese());
		params.put("codigoRegimen", declaracion.getNumdeclRef().getCodregimen());
		params.put("numeroDeclaracion", declaracion.getNumdeclRef().getNumcorre());
		List<Map<String, Object>> lstdua = cabDeclaraDAO.listCabDeclaraMapByParameterMap(params);

		if (!CollectionUtils.isEmpty(lstdua))
			return lstdua.get(0);

		return null;

	}

	private boolean anularIndicadorRegularizacion(Declaracion declaracion){

		boolean procedeAnularIndicadorRegularizacion = false;

		Map<String, Object> mapDuaBD = obtenerMapDua(declaracion);
		if (mapDuaBD!=null) {
			String modalidadRecti = declaracion.getDua().getCodmodalidad();
			String modalidadBd = (String) mapDuaBD.get("codmodalidad");
			if (!modalidadRecti.equals(modalidadBd)) {
				if ((modalidadBd.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL))
						|| (modalidadBd.equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) && modalidadRecti.equals(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE))
						) {
					return procedeAnularIndicadorRegularizacion = true;
				}
			}
		}

		return procedeAnularIndicadorRegularizacion;
	}



	@ServicioAnnot(tipo="V",codServicio=3393, descServicio="valida valTipoIndicadorRegularizable")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=3393,numSecEjec=37,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	// esta validacion esta en valIndicadorRegularizable
	@Deprecated
	public Map<String, String> valTipoIndicadorRegularizable(Declaracion declaracion) {		
		if (CollectionUtils.isNotEmpty(getListIndicadorByTipo(declaracion.getDua(),ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION))){
			if ((SunatStringUtils.isEqualTo(declaracion.getDua().getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) )) {
				return getDUAError("30766", new Object[]{ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION});
			}
		}
		return new HashMap<String,String>();
	}



	//lmvr:  RN 213 -
	@ServicioAnnot(tipo="V",codServicio=2500, descServicio="valida valIndicadorRegularizable")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","serie","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=2500,numSecEjec=429,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public Map<String, String> valIndicadorRegularizable(Declaracion declaracion, Date fechaReferencia,  String codTransaccion) {
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DUA dua=declaracion.getDua();

		boolean procedeAnularIndicadorRegularizacion = false;

		if(!codTransaccion.endsWith("01")){
			procedeAnularIndicadorRegularizacion = anularIndicadorRegularizacion(declaracion);
		}

		//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
		boolean flagVigencia=false;
		DataCatalogo catVigenciaValidacion = catalogoAyudaService.getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_HABILITACION_RIN,"0020");
		if ( catVigenciaValidacion != null ) {
			Date fecVigenciaRegu = catVigenciaValidacion.getFecInidatcat();
			if (SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fecVigenciaRegu, SunatDateUtils.COMPARA_SOLO_FECHA)){
				flagVigencia=true;
			}
		}
		//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
		//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();
	    boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaDeclaracion):false;
	    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false;	//PASE64
		
		Map<String,String> listError = new HashMap<String,String>();
		if (CollectionUtils.isEmpty(getListIndicadorByTipo(dua,ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION))){
			if ((SunatStringUtils.isEqualTo(dua.getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) )) {	
				for (DatoSerie serie:dua.getListSeries()){	

					//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
					ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
					// SE ADICIONA REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN
					if(!esVigenteRIN05PrimeraParte){
						if ( !flagVigencia) {
							if (funcionesService.getRefPartidas("MSF", null, null, null, null, serie.getNumpartnandi().toString(), null, null, SunatDateUtils.getIntegerFromDate(fechaReferencia), null) != null){
								listError = getDUAError("30596", new Object[]{"MERCANCIA SENSIBLE AL FRAUDE"});
								break;
							}
						}
						
					}
					// FIN REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN
					if(esUnidadPesoVolumen(serie.getCodunifis()) || esUnidadPesoVolumen(serie.getCodunicomer())){
						listError =  getDUAError("30596", new Object[]{"PESO VOLUMEN"});
						break;
					}
					//RIN05 PAS20181U220200004 - CSANTILLAN
					if(esVigenteRIN05PrimeraParte){
					int IQBF = validarMercanciaRestringidaIQBF(dua, serie,codTransaccion);
					if(IQBF >0){
						listError = getDUAError("30596", new Object[]{"MERCANCIAS DE INSUMOS QUIMICOS Y PRODUCTOS FISCALIZADOS"});
						break;
						}
					}
					
					// SE ADICIONA REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN
					if(!esVigenteRIN05PrimeraParte){
						String capitulo=SunatStringUtils.lpad(String.valueOf(serie.getNumpartnandi()),10,'0').substring(0, 2);
						if (esCapituloTextil(capitulo)){
							listError = getDUAError("30596", new Object[]{"PARTIDA CAPITULO TEXTIL"});
							break;
						}												
					}
					// FIN REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN	
					//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
							
				}

				//if (declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL)){
				
				//RIN 22. R213 5. Se incluye el deposito EER
				if(!esVigenteRIN05SegundaParte){  //		CSantillan PAS20181U220200004
					if(SunatStringUtils.include(declaracion.getDua().getCodlugarecepcion(),new String[]{ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL, 
							ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR })){
						listError = getDUAError("30752", new Object[]{});//lmvr-pase105
					} 
				  }
				//else{	
					//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
				if(!esVigenteRIN05PrimeraParte){
						if ( !flagVigencia) {
							String numeroRUCduenioConsignatario = dua.getDeclarante().getNumeroDocumentoIdentidad();
							SoporteService soporteService = fabricaDeServicios.getService("soporteServiceDef");
							Map<String, Object> rptaRuc = soporteService.obtenerPerNatJur("4",numeroRUCduenioConsignatario);
							String flag22 = (String) rptaRuc.get("habidoDdp");
							if(flag22.equals("20")){
								listError = getDUAError("30596", new Object[]{"RUC NO HABIDO"});						
							}
						}											
				}
					//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
				//}
				

			}
		}else{
			//ATENCION DEL BUG 	P_SNAA0004-9829

			if(esVigenteRIN05PrimeraParte){
				if(!validarCondicionesDeIndicadorRegularizabe(dua,fechaReferencia,codTransaccion,flagVigencia)){
					listError = getDUAError("50114", new Object[]{"MERCANCIA NO REGULARIZABLE, NO CORRESPONDE LA TRANSMISION DEL INDICADOR"});
				}
				
			}
			

			if((SunatStringUtils.isEqualTo(dua.getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) ||  SunatStringUtils.isEqualTo(dua.getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_URGENTE))&& !procedeAnularIndicadorRegularizacion ){
				listError = getDUAError("30751", new Object[]{ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION ,dua.getCodmodalidad()});	
			}

			if ((SunatStringUtils.isEqualTo(declaracion.getDua().getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) )&& !procedeAnularIndicadorRegularizacion) {
				return getDUAError("30766", new Object[]{ConstantesDataCatalogo.INDICADOR_REQUIERE_REGULARIZACION});
			}
		}



		return listError;
	}

	
	private boolean validarCondicionesDeIndicadorRegularizabe(DUA dua, Date fechaReferencia,  String codTransaccion,boolean flagVigencia){
				 	
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaDeclaracion = dua.getFecdeclaracion()!=null?dua.getFecdeclaracion():new Date();

		boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaDeclaracion):false;	//PASE64
	    
		 boolean esRegularizable = false;
		 boolean esRegularizableUnidaMedida = true;
		 boolean esRegularizableIQBF = false;
		 boolean esRegularizableDepositoTemporal = false;
		if ((SunatStringUtils.isEqualTo(dua.getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) )) {
			
			for (DatoSerie serie:dua.getListSeries()){	

			
				//ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
	
				// FIN REGLA DE VIGENCIA RIN05 PAS20181U220200004 - CSANTILLAN
				if(esUnidadPesoVolumen(serie.getCodunifis()) || esUnidadPesoVolumen(serie.getCodunicomer())){
					
					esRegularizableUnidaMedida = true;	// Bug P_SNAA0004-9931
					break;
					
				}else{
					esRegularizableUnidaMedida = false;
				}
	
			}
			
			for (DatoSerie serie:dua.getListSeries()){	
			int IQBF = validarMercanciaRestringidaIQBF(dua, serie,codTransaccion);
			if(IQBF >0){
				esRegularizableIQBF = true;
				break;
			}
			}
			if(!esVigenteRIN05SegundaParte){  //		se adiciona regla que va hasta diciembre 
				if(SunatStringUtils.include(dua.getCodlugarecepcion(),new String[]{ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL, 
						ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR })){
					esRegularizableDepositoTemporal= true;
				} 
			  }
			
			if(!esVigenteRIN05SegundaParte){
				if(esRegularizableUnidaMedida || esRegularizableIQBF || esRegularizableDepositoTemporal){
					esRegularizable = true;
				}
			}else{
				if(esRegularizableUnidaMedida || esRegularizableIQBF ){
					esRegularizable = true;
				}
			}
		} 
		
		return esRegularizable;
	}

	//BUG 
		public int validarMercanciaRestringidaIQBF(
				DUA dua,
				DatoSerie serie, String codTransaccion)
		{
		MrestriDAOService mrestriDAOService = (MrestriDAOService)fabricaDeServicios.getService("Ayuda.mrestriService");
		Map<String, Object>   params=new HashMap<String, Object>();
				params.put("cnan", serie.getNumpartnandi());
				params.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
				params.put("entidad", Constants.COD_ENTIDAD_DOCAUT_IQBF);
				
				int lstMrestri = mrestriDAOService.count(params);
				
				return lstMrestri;
		}	
	//
		
		
		
	private boolean esUnidadPesoVolumen (String codigoUnidad){
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (catalogoAyudaService.getDataGrupoCat(ConstantesGrupoCatalogo.GRUPO_CATALOGO_PESOS_VOLUMEN, codigoUnidad) != null)
			return true;
		else
			return false;		
	}

	private boolean esCapituloTextil (String codCapitulo){
		CatalogoValidaService catalogoValidaService = fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		if (CollectionUtils.isEmpty(catalogoValidaService.validarElementoCat(ConstantesTipoCatalogo.CATALOGO_MATERIAS_TEXTILES_SUS_MANUFACTURAS, codCapitulo)))
			return true;
		else
			return false;		
	}


	//esm:  RIN 19 -
	@ServicioAnnot(tipo="V",codServicio=3458, descServicio="valida valIndicadorManifiesto")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=3458,numSecEjec=437,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, String>> valIndicadorManifiesto(Declaracion declaracion, Map<String, Object> variablesIngreso, String codTransaccion, Date fechaReferencia) {	
		DUA dua=declaracion.getDua();
		boolean existeIndManif = false;
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();

		Declaracion declaracionXML = (Declaracion) variablesIngreso.get("declaracionXML");
		if(declaracionXML !=null && declaracionXML.getDua().getListIndicadores() != null ){ 
			for (DatoIndicadores datoIndicador : declaracionXML.getDua().getListIndicadores()){  
				if (datoIndicador.getCodtipoindica() != null 
						&& datoIndicador.getCodtipoindica().trim().equals(ConstantesDataCatalogo.INDICADOR_NO_REQUIERE_VALIDACION_MANIFIESTO))
					existeIndManif = true;
			}
		}

		if(codTransaccion.endsWith("04") && existeIndManif){
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("32016", new String[] {ConstantesDataCatalogo.INDICADOR_NO_REQUIERE_VALIDACION_MANIFIESTO.toString()}));
		}


		if (!CollectionUtils.isEmpty(getListIndicadorByTipo(dua,ConstantesDataCatalogo.INDICADOR_NO_REQUIERE_VALIDACION_MANIFIESTO))){
			
			DatoManifiesto manif=dua.getManifiesto();  
			if(manif.getCodaduamanif()==null || manif.getAnnmanif()==null ||
					manif.getNummanif()==null || manif.getCodmodtransp()==null){
				
				String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
				String numeroManifiesto =   
						manif.getCodaduamanif()+"-"+	annmanif+"-"+ manif.getNummanif();
				Map<String, String> mapError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("12098",new String[]{numeroManifiesto});
				
				listError.add(mapError);
			}
			
			ArrayList<String>  modalidadAceptada = new ArrayList<String>();
			modalidadAceptada.add(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO);
			String modalidadMsj = "ANTICIPADO";
			//Pase PAS20181U220200049 - Inicio
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			Map<String, Object> valIndManif = catalogoAyudaService.getElementoCat("380", "0051", fechaReferencia);
			if (valIndManif!=null && !valIndManif.isEmpty()){
				modalidadAceptada.add(ConstantesDataCatalogo.COD_MODALIDAD_URGENTE);
				modalidadMsj = "ANTICIPADO O URGENTE";
			}  
			
			//if (!SunatStringUtils.isEqualTo(dua.getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)) {
			if (!ArrayUtils.contains(modalidadAceptada.toArray(),dua.getCodmodalidad())) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("32015", new String[] {ConstantesDataCatalogo.INDICADOR_NO_REQUIERE_VALIDACION_MANIFIESTO.toString(),modalidadMsj}));
			}
			if (!SunatStringUtils.isEmptyTrim(declaracion.getDua().getCodCanal()) && !codTransaccion.endsWith("04")&& !codTransaccion.endsWith("02")) { //PAS20165E220200101
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("32016", new String[] {ConstantesDataCatalogo.INDICADOR_NO_REQUIERE_VALIDACION_MANIFIESTO.toString()}));	
			} 
			if (!SunatStringUtils.isEqualTo(dua.getCodregimen(), ConstantesDataCatalogo.REG_IMPO_CONSUMO)) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("32017", new String[] {ConstantesDataCatalogo.INDICADOR_NO_REQUIERE_VALIDACION_MANIFIESTO.toString()}));	
			}
		}

		return listError;
	}

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	
	//PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
	public void setCatalogoAyudaService(CatalogoAyudaService catalogoAyudaService) {
		this.catalogoAyudaService = catalogoAyudaService;
	}
*/
}
