/*
 * Clase que define el servicio de validaciones de los regimenes de precedencias declarados en la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.administracion2.tramite.service.ExpedienteService;
import pe.gob.sunat.despaduanero.despacho.comun.impo.model.Didocrec;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.DiserieFormbItem;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.FormbFactProv;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValItemFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.SumDatoSeriePrec;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DAMOperativaConsultaService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.dao.DetIncidenciaDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionComunService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoConsumoService;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.declaracion.model.CabCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO; //PAS20165E220200102 - mtorralba 20160713

/**
 * The Class ValRegprec. Clase que define el servicio de validaciones de los regimenes de precedencias declarados en la DUA.
 */
public class ValRegprecServiceImpl extends ValDuaAbstract implements ValRegprec{

	
	/**
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated No se encuentra en mapeo DUA vs XML
	 * @param codtipoprece String
	 * @return Map
	 */
	public Map<String, String> codtipoprece(String codtipoprece){
		return !SunatStringUtils.isEmptyTrim(codtipoprece)?new HashMap<String,String>():getDUAError("30093", "");
	}

	/**
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated No se encuentra en mapeo DUA vs XML
	 * @param codaduapre String
	 * @return Map
	 */
	public Map<String, String> codaduapre(String codaduapre){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("00", codaduapre))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("00", codaduapre,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00056","Error catalogo codaduapre");
	}

	/**
	 * Valida el C�digo del regimen de precedencia.<br>
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codregipre String. C�digo del regimen de precedencia.
	 * @return Map
	 */
	public Map<String, String> codregipre(String codregipre){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("17", codregipre))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("17", codregipre,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("00136","Error catalogo codregipre");
	}

	/**
	 * Valida la Fecha de la declaraci�n precedente.<br>
	 * Si el par&aacute;metro codregipre tiene valor, se valida el par&aacute;metro anndeclpre como una cadena de 4 d&iacute;gitos.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param anndeclpre String. Fecha de la declaraci�n precedente.
	 * @param codregipre String. C�digo del regimen de precedencia.
	 * @return Map
	 */
	public Map<String, String> anndeclpre(String anndeclpre, String codregipre){
		if (!SunatStringUtils.isEmptyTrim(codregipre) ){
			if (!SunatStringUtils.isEmptyTrim(anndeclpre) && anndeclpre.trim().length()>4){
				if ( SunatStringUtils.isNumeric(anndeclpre.trim().substring(0, 4)))
					return new HashMap<String,String>();
				else
					return getDUAError("00135","");

			}else{
				return getDUAError("00135","");
			}
		}else
			return new HashMap<String,String>();
	}

	/**
	 * Valida el N�mero de la declaraci�n precedente.<br>
	 * Si el par&aacute;metro codregipre tiene valor, se valida el par&aacute;metro numdeclpre como una cadena de 6 d&iacute;gitos.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numdeclpre String. N�mero de la declaraci�n precedente.
	 * @param codregipre String. C�digo del regimen de precedencia.
	 * @return Map
	 */
	public Map<String, String> numdeclpre(String numdeclpre, String codregipre){
		if (!SunatStringUtils.isEmptyTrim(codregipre)){
			return (SunatStringUtils.isNumeric(numdeclpre) && numdeclpre.trim().length()==6)?new HashMap<String,String>():getDUAError("00057","");
		}else
			return new HashMap<String,String>();
	}

	/**
	 * Valida el N�mero de la serie precedente.<br>
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numserpre Integer. N�mero de la serie precedente.
	 * @return Map
	 */
	public Map<String, String> numserpre(Integer numserpre){
		return SunatNumberUtils.isGreaterThanZero(numserpre)?new HashMap<String,String>():getDUAError("00060","");
	}

	/**
	 * Valida la fecha de vencimiento del regimen de precedencia.<br>
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fecvencpre Date.Fecha de vencimiento del regimen precedente o vigencia de la exportaci�n.
	 * @return Map
	 */
	public Map<String, String> fecvencpre(Date fecvencpre){
		return fecvencpre!=null?new HashMap<String,String>():getDUAError("00058","");
	}

	/**
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated No se encuentra en mapeo DUA vs XML
	 * @param codtipoprodad String
	 * @return Map
	 */
	public Map<String, String> codtipoprodad(String codtipoprodad){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("341", codtipoprodad))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("341", codtipoprodad,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30094","Error catalogo codtipoprodad");
	}

	/**
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated No se encuentra en mapeo DUA vs XML
	 * @param numitem Integer
	 * @return Map
	 */
	public Map<String, String> numitem(Integer numitem){
		return SunatNumberUtils.isGreaterThanZero(numitem)?new HashMap<String,String>():getDUAError("00061","");
	}

	/**
	 * Valida que el par&aacute;metro sea mayor a cero.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * @deprecated No se encuentra en mapeo DUA vs XML
	 * @param cntunidfiqty BigDecimal
	 * @return Map
	 */
	public Map<String, String> cntunidfiqty(BigDecimal cntunidfiqty){
		return SunatNumberUtils.isGreaterThanZero(cntunidfiqty)?new HashMap<String,String>():getDUAError("00031","");
	}

	/*public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

	//iniciio :msancheza TPN21
	/**
	 * Validaciones generales a los datos generales del regimen de precedencia
	 * de importaci�n para consumo
	 * 
	 * @param declaracion
	 * @return
	 */
	public List<Map<String, String>> valCabRegPreTPN21ImpoConsumo(Declaracion declaracion, boolean esTPN21, Date fechaReferencia, String codTransaccion) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		

		DUA duaDeclaracion = declaracion.getDua();

		/**
		 * 2.- ERROR N10. La modalidad de la declaraci�n debe corresponder a Excepcional
		 */

		//PAS20155E220200012 - mtorralba 20150616 - Inicio
		// Ya no valida que la DAM precedente sea Excepcional. Ahora puede ser cualquier Modalidad.
		/*
		String codModalidad = duaDeclaracion.getCodmodalidad();
		if (!codModalidad.equals(Constants.DESPACHO_EXCEPCIONAL)) {
			//�Modalidad de despacho de la declaraci�n no corresponde para el acogimiento de mercanc�as vigentes�.
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31889"));

			//MODALIDAD DE DESPACHO DE LA DECLARACI�N NO CORRESPONDE PARA EL ACOGIMIENTO DE MERCANC�AS VIGENTES
		}
		 */

		//PAS20155E220200012 - mtorralba 20150616 - Fin


		//series de la declaraci�n	
		if (!CollectionUtils.isEmpty(duaDeclaracion.getListSeries())) {

			Elementos<DatoSerie> series = declaracion.getDua().getListSeries();		
			Map<String, SumDatoSeriePrec> listaSeriesPrecTemp = new HashMap<String, SumDatoSeriePrec>();
			for (DatoSerie serie : series) {				
				for (DatoRegPrecedencia precedente : serie.getListRegPrecedencia()) {
					Integer numeroSerieDeclaraci�n = serie.getNumserie();
					boolean serieDeclaracionEsTPN21 = false;				
					String indicadorTPNSerie = serie.getCodtratprefe().toString();
					String mregi_proce = precedente.getCodregipre();				
					String codregipre = precedente.getCodregipre();
					String pcaduregpre = precedente.getCodaduapre();
					String pfanoregpre = SunatStringUtils.substring(
							precedente.getAnndeclpre(), 0, 4);
					String pndclregpre = precedente.getNumdeclpre();
					Integer pnume_serpr = precedente.getNumserpre();

					//msancheza RIN29:BUG 20645: llenamos el objetos SumDatoSeriePrec donde de guardar� la sumatoria para las precedencias

					String numSeriePrec = pcaduregpre + "-" + pfanoregpre + "-"	+ codregipre + "-" + pndclregpre + "-" + pnume_serpr ;						
					SumDatoSeriePrec sumaSeriePrec =  new SumDatoSeriePrec();

					if(listaSeriesPrecTemp.containsKey(numSeriePrec)){
						sumaSeriePrec = listaSeriesPrecTemp.get(numSeriePrec);
					}						

					sumaSeriePrec.setNumeroDeclaracionPrec(numSeriePrec);
					sumaSeriePrec.setCntbultosTotal(sumaSeriePrec.getCntbultosTotal().add(serie.getCntbultos()));
					sumaSeriePrec.setCntpesobrutoTotal(sumaSeriePrec.getCntpesobrutoTotal().add(serie.getCntpesobruto()));
					sumaSeriePrec.setCntpesonetoTotal(sumaSeriePrec.getCntpesonetoTotal().add(serie.getCntpesoneto()));
					sumaSeriePrec.setCntunicomerTotal(sumaSeriePrec.getCntunicomerTotal().add(serie.getCntunicomer()));
					sumaSeriePrec.setCntunifisTotal(sumaSeriePrec.getCntunifisTotal().add(serie.getCntunifis()));
					sumaSeriePrec.setMtofobdolTotal(sumaSeriePrec.getMtofobdolTotal().add(serie.getMtofobdol()));
					sumaSeriePrec.setMtofledolTotal(sumaSeriePrec.getMtofledolTotal().add(serie.getMtofledol()));
					sumaSeriePrec.setMtosegdolTotal(sumaSeriePrec.getMtosegdolTotal().add(serie.getMtosegdol()));
					sumaSeriePrec.setMtoajusteTotal(sumaSeriePrec.getMtoajusteTotal().add(serie.getMtoajuste()!=null?serie.getMtoajuste():BigDecimal.ZERO));
					sumaSeriePrec.setMtovaladuanaTotal(sumaSeriePrec.getMtovaladuanaTotal().add(serie.getMtovaladuana()!=null?serie.getMtovaladuana():BigDecimal.ZERO));

					//fin msancheza
					/**
					 *  3. Declaraci�n con r�gimen [�] precedente no permite acogerse a mercanc�as vigentes (TPN 21)
					 */
					if (esTPN21 && !Constants.REGIMEN_IMPO_DEFINITIVA.equals(mregi_proce)) {		
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31930",new String[] {numeroSerieDeclaraci�n.toString(), mregi_proce}));
					}

					/**
					 * 1.4. Que, cuando se transmita la declaraci�n de r�gimen precedente, sea obligatorio el ingreso de los siguientes campos
					 */						
					//1.4.5 SERIE
					if (SunatStringUtils.isEmptyTrim(pnume_serpr.toString())){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31891",new String[] {numeroSerieDeclaraci�n.toString()}));
					}
					//1.4.1 aduana
					if (SunatStringUtils.isEmptyTrim(pcaduregpre)){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31892",new String[] {numeroSerieDeclaraci�n.toString()}));
					}
					//1.4.2 anio
					if (SunatStringUtils.isEmptyTrim(pfanoregpre)){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31893",new String[] {numeroSerieDeclaraci�n.toString()}));
					}
					//1.4.3 C�digo de identificaci�n del r�gimen: 10 
					if (SunatStringUtils.isEmptyTrim(codregipre)){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31894",new String[] {numeroSerieDeclaraci�n.toString()}));
					}
					//1.4.4 numero declaracion precedente
					if (SunatStringUtils.isEmptyTrim(pndclregpre)){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31895",new String[] {numeroSerieDeclaraci�n.toString()}));
					}				


					listError.addAll(valSerieTPN21RegPrecImpoConsumo(declaracion, serie, precedente, fechaReferencia, codTransaccion, sumaSeriePrec));
					listaSeriesPrecTemp.put(numSeriePrec, sumaSeriePrec);						
				}
			}
		}
		return listError;
	}

	//gmontoya P29 inicio
	@Override
	public boolean existeDUAPrecedente(DatoRegPrecedencia precedente) {
		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
		Map<String, Object> paramsDeclaracion = new HashMap<String, Object>();

		String codregipre = precedente.getCodregipre();
		String pcaduregpre = precedente.getCodaduapre();
		String pfanoregpre = SunatStringUtils.substring(precedente.getAnndeclpre(), 0, 4);
		String pndclregpre = precedente.getNumdeclpre();
		/**
		 * 1.5. La declaracion precedente debe existir, para lo cual se verifica
		 * primero en el NSIGAD y luego en el ASIGAD
		 */
		paramsDeclaracion.put("codigoRegimen", codregipre);
		paramsDeclaracion.put("codigoAduana", pcaduregpre);
		paramsDeclaracion.put("annoPresentacion", new Integer(pfanoregpre.substring(0, 4)));
		paramsDeclaracion.put("numeroDeclaracion", new Integer(pndclregpre.toString()));

		DUA duaPrecedente = cabDeclaraDAO.findDUAByKeyMap(paramsDeclaracion);//gmontoya IoC	

		// Si no esta en el NSIGAD se busca en ASIGAD polizad
		if (duaPrecedente == null) {
			//			duaPrecedente = damOperativaConsultaService.ObtenerDAMOperativa(pcaduregpre, codregipre, new Integer(pfanoregpre.substring(0, 4)), pndclregpre.toString());
			ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
			Map<String, Object> paramsPolizai = new HashMap<String, Object>();
			paramsPolizai.put("NUMECORRE", SunatStringUtils.lpad(pndclregpre, 6, '0'));
			paramsPolizai.put("ANOPRESE", pfanoregpre.substring(2, 4));
			paramsPolizai.put("CODIADUAN", pcaduregpre);
			paramsPolizai.put("TABLA", "di" + pfanoregpre.substring(2, 4) + "polizai");
			//Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + pcaduregpre));//gmontoya IoC
			//Map<String,Object> asigadDua  = dipolizaiDAO.getDatosDUAByPrimaryKey(paramsPolizai);
			Map<String,Object> asigadDua  = consultaDeclaracionImpoConsumoService.consultarDeclaracionImportacionConsumo(paramsPolizai,pcaduregpre);
			//swapperDatasource.swap(o);		

			if (CollectionUtils.isEmpty(asigadDua)) {
				//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31888",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
				return false;
				//DECLARACION PRECEDENTE({0}) NO EXISTE										
			} else{
				return true;
			}
		}else{
			return true;
		}		
	}

	//gmontoya P29 fin



	@SuppressWarnings("unchecked")
	public List<Map<String, String>> valSerieTPN21RegPrecImpoConsumo(Declaracion declaracion, DatoSerie serie, DatoRegPrecedencia precedente, Date fechaReferencia, String codTransaccion, SumDatoSeriePrec sumaSeriePrec) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();	
		Declaracion declaracionPrecedente = new Declaracion();
		Date fecAutLevante = null;	
		//String codcanal = new String();	
		//Long numeroCorreDUAPre = null;
		//Integer numeroSerieDeclaraci�n = serie.getNumserie();			

		String codregipre = precedente.getCodregipre();
		String pcaduregpre = precedente.getCodaduapre();
		String pfanoregpre = SunatStringUtils.substring(precedente.getAnndeclpre(), 0, 4);
		String pndclregpre = precedente.getNumdeclpre();

		//PAS20171U220200005 - mtorralba 20170808 - Inicio 
		ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService"); 
		Map<String,Object> mapaPrecedente = valMercanciaVigenteService.obtenerDAMPrecedenteMercanciaVigente(pcaduregpre, pfanoregpre, codregipre, pndclregpre); 
		DUA duaPrecedente = (DUA)mapaPrecedente.get("duaPrecedente");
		boolean esSIGAD = (Boolean)mapaPrecedente.get("esSIGAD");

		if( duaPrecedente != null ) 
			if( esSIGAD ) { //si es SIGAD
				ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
				Map<String, Object> paramsPolizai = new HashMap<String, Object>();
				paramsPolizai.put("NUMECORRE", SunatStringUtils.lpad(pndclregpre, 6, '0'));
				paramsPolizai.put("ANOPRESE", pfanoregpre.substring(2, 4));
				paramsPolizai.put("CODIADUAN", pcaduregpre);
				paramsPolizai.put("TABLA", "di" + pfanoregpre.substring(2, 4) + "polizai");
				//Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + pcaduregpre));//gmontoya IoC
				//Map<String,Object> asigadDua  = dipolizaiDAO.getDatosDUAByPrimaryKey(paramsPolizai);
				Map<String,Object> asigadDua  = consultaDeclaracionImpoConsumoService.consultarDeclaracionImportacionConsumo(paramsPolizai);
				//swapperDatasource.swap(o);	
				if (CollectionUtils.isEmpty(asigadDua)) {
					//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31888",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
					return listError;
				} else {
					// Obtenemos todos los datos necesarios del ASIGAD para la validaci�n correspondiente
					fecAutLevante = duaPrecedente.getFecAutlevante();
					//codcanal = asigadDua.get("TIPO_AFORO").toString();
					declaracionPrecedente.setDua(duaPrecedente);				
					if (duaPrecedente.getCodEstdua()!= null && "08".equals(duaPrecedente.getCodEstdua())) {
						//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31888",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
						return listError;
					}
					listError.addAll(valCabDetalleSeriesDuaAsigadTPN21(declaracion, declaracionPrecedente, serie, precedente, fechaReferencia, fecAutLevante, sumaSeriePrec));
				}

			} //final DAM SIGAD
			else {
				if ("08".equals(duaPrecedente.getCodEstdua())) {
					return listError;
				}
				fecAutLevante = duaPrecedente.getFecAutlevante();										
				//codcanal = duaPrecedente.getCodCanal();	
				//numeroCorreDUAPre = duaPrecedente.getNumcorredoc();
				//obtenemos declaracion precedente
				declaracionPrecedente = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDeclaracion(pcaduregpre,
						SunatNumberUtils.toInteger(precedente.getNumdeclpre()), new Integer(pfanoregpre), codregipre);
				listError.addAll(valCabDetalleSeriesDuaSDATPN21(declaracion, declaracionPrecedente, serie, precedente, fechaReferencia, fecAutLevante,sumaSeriePrec, codTransaccion));			
			}

		return listError;
	}

	private List<Map<String, String>> valCabDetalleSeriesDuaSDATPN21(Declaracion declaracion, Declaracion declaracionPrecedente, DatoSerie serie, DatoRegPrecedencia precedente,  
			Date fechaReferencia, Date fecAutLevante, SumDatoSeriePrec sumaSeriePrec, String codTransaccion ) {
		List<Map<String, String>> erroresDuaSDAPrec = new ArrayList<Map<String, String>>();
		Map<String, Object> params = new HashMap<String, Object>();
		Map<String, Object> mapRecoFisicoNaranja =  new HashMap<String, Object>();
		Participante consignatarioDeclaracion;
		Participante consignatarioPrecedente;
		DatoSerie seriePrecedente = new DatoSerie();
		String codcanal = new String();	
		Long numeroCorreDUAPre = declaracionPrecedente.getDua().getNumcorredoc();
		DUA duaPrecedente= null;
		Integer numeroSerieDeclaracion = serie.getNumserie();			
		String codregipre = precedente.getCodregipre();
		String pcaduregpre = precedente.getCodaduapre();
		String pfanoregpre = SunatStringUtils.substring(
				precedente.getAnndeclpre(), 0, 4);
		String pndclregpre = precedente.getNumdeclpre();
		Integer pnume_serpr = precedente.getNumserpre();
		String CDAprece = pcaduregpre + "-" + pfanoregpre + "-"
				+ codregipre + "-" + pndclregpre;

		//PAS20171U220200005 - mtorralba 20170810
		ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService");
		Map<String,Object> mapaPrecedenteActual = valMercanciaVigenteService.obtenerIndicadorMercanciaVigente(declaracion.getDua().getListIndicadores());
		boolean tieneIndicadorMercanciaVigente = mapaPrecedenteActual!=null && !mapaPrecedenteActual.isEmpty(); 
		String indicadorMVigDeclarado = tieneIndicadorMercanciaVigente ? mapaPrecedenteActual.get("codIndicador").toString() : "";  

		//PAS20155E220200012 - 20150622 mtorralba - Inicio
		//Si no es numeraci�n, se debe obtener la declaracion precedente declarada en numeracion
		if( !codTransaccion.equals("1001") ) {
			Long numcorre = declaracion.getDua().getNumcorredoc();

		}

		/**
		 * 1.1.	Que, el Tipo de Documento y N�mero del Documento de Identificaci�n del consignatario (importador), 
		 * sea el mismo que el de la declaraci�n que se pretende numerar
		 */
		if (declaracionPrecedente != null) {
			duaPrecedente = declaracionPrecedente.getDua();
			consignatarioDeclaracion = declaracion.getDua().getDeclarante();
			consignatarioPrecedente = duaPrecedente.getDeclarante(); 
			String precedenteNaturalezaCarga = "";
			String declaracionNaturalezaCarga = "";
			codcanal = duaPrecedente.getCodCanal();

			//PAS20171U220200005 - mtorralba 20170822 - Validar indicador de DAM Vigente con indicador de DAM Precedente
			Map<String,Object> mapaPrecedente = valMercanciaVigenteService.obtenerIndicadorMercanciaVigente(duaPrecedente.getListIndicadores());
			String indicadorMVigPrecedente = mapaPrecedente!=null && !mapaPrecedente.isEmpty() ? mapaPrecedente.get("codIndicador").toString() : "";
			erroresDuaSDAPrec.addAll(valMercanciaVigenteService.validaIndicadorDAMVigente(numeroSerieDeclaracion, CDAprece, indicadorMVigDeclarado, indicadorMVigPrecedente));

			if(!consignatarioPrecedente.getTipoDocumentoIdentidad().getCodDatacat().equals(consignatarioDeclaracion.getTipoDocumentoIdentidad().getCodDatacat())|| !consignatarioPrecedente.getNumeroDocumentoIdentidad().equals(consignatarioDeclaracion.getNumeroDocumentoIdentidad())){
				erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31896",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));

			}
			/**
			 * 1.8.	Que, la fecha de numeraci�n de la declaraci�n precedente no supere los cuatro a�os a la fecha de transmisi�n 
			 * de la declaraci�n que se pretende numerar
			 */
			
			if( verificarDeclaracionPrescrita(fechaReferencia, duaPrecedente.getFecdeclaracion()) ){
				erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31899",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));
				return erroresDuaSDAPrec;
				//Declaraci�n precedente prescrita
			}
			/**
			 *  1.2 ERROR N3. Que la declaraci�n precedente debe tener levante autorizado
			 */

			if (fecAutLevante == null
					|| SunatDateUtils.isDefaultDate(fecAutLevante)) {					
				erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31890",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));
				return erroresDuaSDAPrec;
				//Declaraci�n precedente{(0)} no cuenta con Levante Autorizado
			}
			/**
			 *  1.3.	Que, cuente con canal de control rojo o canal naranja remitido a reconocimiento f�sico o canal verde que hayan 
			 *  solicitado reconocimiento f�sico con Expediente c�digo 3092 (Solicitud para reconocimiento f�sico) concluido y procedente,
			 */
			if(!codcanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO)){	
				if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)){
					IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
					params.put("num_corredoc", numeroCorreDUAPre);
					params.put("cod_indicador", ConstantesDataCatalogo.INDICADOR_CAMBIO_A_RECONOCIMIENTO_FISICO);
					params.put("ind_activo", ConstantesDataCatalogo.IND_ACTIVO);
					mapRecoFisicoNaranja =  indicadorDUADAO.findByDocumentoAndValor(params);
					if(mapRecoFisicoNaranja == null || CollectionUtils.isEmpty(mapRecoFisicoNaranja)){
						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31898",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));
						return erroresDuaSDAPrec;
						//Declaraci�n precedente{(0)} no ha sido objeto de reconocimiento f�sico

					}


					/**
					 *  1.6.	Que, la declaraci�n precedente registre como incidencia el c�digo F121 correspondiente a Mercanc�as 
					 *  Vigentes (registrado en la diligencia de despacho), excepto las declaraciones canal verde que hayan solicitado 
					 *  reconocimiento f�sico con Expediente c�digo 3092 concluido y procedente,
					 */
					if(mapRecoFisicoNaranja != null && !CollectionUtils.isEmpty(mapRecoFisicoNaranja)){
						//IncidenciaService incidenciaService = (IncidenciaService)fabricaDeServicios.getService("diligencia.ingreso.incidenciaService");
						DetIncidenciaDAO incidenciaDAO = fabricaDeServicios.getService("diligencia.detIncidenciaDAO");
						Map<String, Object> paramsIncidencia = new HashMap<String, Object>();
						paramsIncidencia.put("NUM_CORREDOC", numeroCorreDUAPre.toString());
						paramsIncidencia.put("COD_INCIDENCIA", new String[]{ConstantesDataCatalogo.COD_INCIDENCIA_MERCANCIAS_VIGENTES, "30"});//30 Bultos faltantes
						List<Map<String, Object>> incidencia = incidenciaDAO.findByIncidencia(paramsIncidencia);
						if(incidencia == null || CollectionUtils.isEmpty(incidencia)){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31912",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));
							return erroresDuaSDAPrec;
						}
					}
				}
				if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_VERDE)){
					//Se evalua si tiene expediente 3092. Para determinar si un expediente est� concluido como PROCEDENTE, este debe tener tipo de conclusi�n 5. 
					Map<String,Object> paramsExpedi = new HashMap<String,Object>();
					paramsExpedi.put("PROCEDIM", ConstantesDataCatalogo.COD_DUA_RECONO_FISICO);
					paramsExpedi.put("COD_ADUANA", pcaduregpre);
					paramsExpedi.put("COD_REGIMEN", codregipre);
					paramsExpedi.put("ANN_PRESEN",  pfanoregpre);
					paramsExpedi.put("NUM_DECLARACION", pndclregpre);
					paramsExpedi.put("TIPO_CONC", ConstantesDataCatalogo.COD_DUA_RECONO_FISICO_PROCEDENTE_Y_CONCLUIDO);
					//swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + pcaduregpre));
					//List<Map<String,Object>> expedis = expediDAO.findByProdedimiento(paramsExpedi);
					/*mapRecoFisicoVerde = (Map<String, Object>) expediDAO.findByProdedimiento(paramsExpedi);
					if(CollectionUtils.isEmpty(mapRecoFisicoVerde)){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31898",new String[] {CDAprece}));
						//Declaraci�n precedente{(0)} no ha sido objeto de reconocimiento f�sico
					}*/
					//Estabilizacion SDA Consulta de expedientes
					ExpedienteService expedienteService = (ExpedienteService)fabricaDeServicios.getService("tramite.ExpedienteService");
					List<Map<String,Object>> expedis = expedienteService.findByDocumentoOrigen(paramsExpedi);
					if(CollectionUtils.isEmpty(expedis)){
						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31898",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));
						return erroresDuaSDAPrec;
						//Declaraci�n precedente{(0)} no ha sido objeto de reconocimiento f�sico
					}
				}

			}
			/*PAS20191U220200026 - mtorralba 20190703 - Se mueve este bloque dentro del bloque cuando NO tieneIndicadorMercanciaVigente
			if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO)||codcanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) ){
				 //**  1.6.	Que, la declaraci�n precedente registre como incidencia el c�digo F121 correspondiente a Mercanc�as 
				 //**  Vigentes (registrado en la diligencia de despacho), excepto las declaraciones canal verde que hayan solicitado 
				 //**  reconocimiento f�sico con Expediente c�digo 3092 concluido y procedente,
				 
				DetIncidenciaDAO incidenciaDAO = fabricaDeServicios.getService("diligencia.detIncidenciaDAO");
				Map<String, Object> paramsIncidencia = new HashMap<String, Object>();
				paramsIncidencia.put("NUM_CORREDOC", numeroCorreDUAPre.toString());
				paramsIncidencia.put("COD_INCIDENCIA", new String[]{ConstantesDataCatalogo.COD_INCIDENCIA_MERCANCIAS_VIGENTES, "30"});
				List<Map<String, Object>> incidencia = incidenciaDAO.findByIncidencia(paramsIncidencia);
				if(incidencia == null || CollectionUtils.isEmpty(incidencia)){
					erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31912",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));
					return erroresDuaSDAPrec;
				}
			}
			*/

			/**
			 * 1.9.	Que la declaraci�n se encuentre cancelada (pagada) si est� acogida a la garant�a previa del Art�culo 160�
			 */
			if(duaPrecedente.getPago()!= null){
				Boolean cancelado=false;
				BigDecimal total=new BigDecimal(0);
				DeudaDocum tmpDeudaDocum = new DeudaDocum();
				tmpDeudaDocum.setNumCorredoc(numeroCorreDUAPre);
				tmpDeudaDocum.setCodTipdeuda("01");
				List<DeudaDocum> tmpListDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);

				if (tmpListDeudaDocum.size()>0){
					DeudaDocum tmp=	tmpListDeudaDocum.get(0);
					total=total.add(tmp.getMtoPagado());
					/*					if (tmp.getMtoDeuda().equals(total)){
						cancelado=true;
					}
					 */
					// PAS20155E220200019 RSV se cambia validaci�n del monto cancelado     
					// GMontoya coordinado 30/07 if (SunatNumberUtils.isLessThanParam(tmp.getMtoDeuda(), total) ){
					if (SunatNumberUtils.isLessOrEqualsThanParam(tmp.getMtoDeuda(), total) ){

						cancelado=true;
					}

				}
				//PAS20155E220200019 RSV se cambia validaci�n del monto cancelado y la garantia
				//if(duaPrecedente.getPago().getPagoDeclaracion()!= null && duaPrecedente.getPago().getPagoDeclaracion() != null && duaPrecedente.getPago().getPagoDeclaracion().getCodgarantia()!= null){
				if(duaPrecedente.getPago().getPagoDeclaracion()!= null && duaPrecedente.getPago().getPagoDeclaracion() != null && SunatStringUtils.isLengthGreaterThanNumber(duaPrecedente.getPago().getPagoDeclaracion().getCodgarantia(), 17)){
					if(!cancelado){
						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31900",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));
					}
					//Declaraci�n precedente {(0)}acogida al Art.160� no se encuentra pagada	
				}

			}	

			//PAS20171U220200005 - mtorralba 20170810 - Inicio
			if( !tieneIndicadorMercanciaVigente ) { 

				//PAS20191U220200026 - mtorralba 20190703 - Este bloque viene de arriba
				if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO)||codcanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) ){
					 //**  1.6.	Que, la declaraci�n precedente registre como incidencia el c�digo F121 correspondiente a Mercanc�as 
					 //**  Vigentes (registrado en la diligencia de despacho), excepto las declaraciones canal verde que hayan solicitado 
					 //**  reconocimiento f�sico con Expediente c�digo 3092 concluido y procedente,
					 
					DetIncidenciaDAO incidenciaDAO = fabricaDeServicios.getService("diligencia.detIncidenciaDAO");
					Map<String, Object> paramsIncidencia = new HashMap<String, Object>();
					paramsIncidencia.put("NUM_CORREDOC", numeroCorreDUAPre.toString());
					paramsIncidencia.put("COD_INCIDENCIA", new String[]{ConstantesDataCatalogo.COD_INCIDENCIA_MERCANCIAS_VIGENTES, "30"});
					List<Map<String, Object>> incidencia = incidenciaDAO.findByIncidencia(paramsIncidencia);
					if(incidencia == null || CollectionUtils.isEmpty(incidencia)){
						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31912",new String[] {numeroSerieDeclaracion.toString(), CDAprece}));
						return erroresDuaSDAPrec;
					}
				}
				
				
				/**
				 * 1.7. 1.7.	Que, la serie de la declaraci�n precedente consignada exista en la declaraci�n que se pretende numerar exista
				 * en el NSIGAD y luego en el ASIGAD
				 */
				Map<String, String> paramsDetDeclaracion = new HashMap<String, String>();
				paramsDetDeclaracion.put("cod_aduana", pcaduregpre);
				paramsDetDeclaracion.put("ann_presen", pfanoregpre);
				paramsDetDeclaracion.put("cod_regimen", codregipre);
				paramsDetDeclaracion.put("num_declaracion", pndclregpre);
				paramsDetDeclaracion.put("num_secserie", pnume_serpr.toString());	
				//PARAMETROS PARA VALDIACION DE FORMATO A Y B
				Long numPartNandi = new Long(0);		
				String codunifides = new String();
				String coduniComercial = new String();
				String codPaisOrigen = new String();
				String codPaisAdquisicion = new String();
				String numFacturaComercial = new String();
				String descripcionMercaderia = new String();
				String descripcionMercaderiaMateCom = new String();
				String descripcionMercaderiaUso = new String();
				String descripcionFormatoAPrese = new String();
				String descripcionMercanOtros = new String();
				String codMoneda = new String();
				String codTipoSeguro = new String();

				DetDeclaraDAO detDeclaraDAO = fabricaDeServicios.getService("detDeclaraDAO");
				List<Map<String, Object>> detalleDuaPrecedente = detDeclaraDAO.findSeriesByDocumento(paramsDetDeclaracion);//gmontoya IoC
				if (!CollectionUtils.isEmpty(detalleDuaPrecedente)) {

					// Obtenemos variables necesarias para la validacion de las reglas
					// del NSIGAD	
					codPaisAdquisicion = detalleDuaPrecedente.get(0).get("COD_PAISADQUI").toString();	
					codPaisOrigen = detalleDuaPrecedente.get(0).get("COD_PAISORIGEN").toString();		
					numPartNandi = SunatNumberUtils.toLong(detalleDuaPrecedente.get(0).get("NUM_PARTNANDI"));
					codunifides = detalleDuaPrecedente.get(0).get("COD_UNIFISICA").toString();
					coduniComercial = detalleDuaPrecedente.get(0).get("COD_UNICOMER").toString();
					descripcionMercaderia = detalleDuaPrecedente.get(0).get("DES_COMER").toString();
					descripcionMercaderiaMateCom = detalleDuaPrecedente.get(0).get("DES_MATECOMP").toString();
					descripcionFormatoAPrese = detalleDuaPrecedente.get(0).get("DES_FORMAPRESEN").toString();
					descripcionMercaderiaUso = detalleDuaPrecedente.get(0).get("DES_USOAPLIC").toString();
					descripcionMercanOtros = detalleDuaPrecedente.get(0).get("DES_OTROSCARAC").toString();
					codMoneda = detalleDuaPrecedente.get(0).get("COD_MONETRANS").toString();
					codTipoSeguro = detalleDuaPrecedente.get(0).get("COD_TIPSEG").toString();
					//seteamos datoSerie de la dua precendente
					seriePrecedente.setNumserie(SunatNumberUtils.toInteger(detalleDuaPrecedente.get(0).get("NUM_SECSERIE")));
					seriePrecedente.setNumcorredoc(SunatNumberUtils.toLong(detalleDuaPrecedente.get(0).get("NUM_CORREDOC")));
					if(seriePrecedente.getNumserie().equals(pnume_serpr)){
						//Obtener datos de los formatos actual y precedente en las variables fbAct y fbPre De la siguiente manera:
						ValItemFB valItemFB = fabricaDeServicios.getService("ValItemFB");
						DatoItem fbDeclaracion = valItemFB.getItemCorrespondiente(serie, declaracion);
						DatoItem fbPrecedente = valItemFB.getItemCorrespondiente(seriePrecedente, declaracionPrecedente);
						for(DatoSerie seriePrecedenteBD: declaracionPrecedente.getDua().getListSeries()){				
							if(seriePrecedenteBD.getNumserie().equals(pnume_serpr)){
								seriePrecedente = seriePrecedenteBD;
							}
						}
						//Obtener datos de la factura actual y precedente en las varianles factAct y factPre
						ValNegocNumeracFormA valNegocNumeracFormA = fabricaDeServicios.getService("ValNegocNumeracFormA");
						DatoFactura factDeclaracion = valNegocNumeracFormA.getFacturaCorrespondiente(serie, declaracion);
						DatoFactura factPrecedente = valNegocNumeracFormA.getFacturaCorrespondiente(seriePrecedente, declaracionPrecedente);
						//Para obtener los datos del proceedor actual y precedente declarar las siguientes variables e instanciarlas de la siguiente manera: 
						Participante proveedorDeclaracion = new Participante();
						Participante proveedorPrecedente = new Participante();
						for (DAV davDeclaracion : declaracion.getListDAVs()) {
							proveedorDeclaracion = davDeclaracion.getProveedor();
							declaracionNaturalezaCarga = davDeclaracion.getCodnatutrans();

						}

						//PAS20165E220200102 - mtorralba 20160713 - Inicio: Modificamos la forma de obtener el proveedor precedente 
						FormBProveedorDAO formBProveedorDAO = (FormBProveedorDAO)fabricaDeServicios.getService("formBProveedorDAO");
						Map<String, Object> formbProveedor = formBProveedorDAO.findByPk(fbPrecedente.getNumcorredoc().toString(), fbPrecedente.getNumsecprove().toString()); 
						if( formbProveedor != null ) {
							proveedorPrecedente.setSecuenciaDeParticipantes(Long.valueOf(formbProveedor.get("num_codsecprove").toString()));
							proveedorPrecedente.setNombreRazonSocial(formbProveedor.get("nom_razonsocial_prv").toString());
							proveedorPrecedente.setDireccion(formbProveedor.get("dir_partic_prv").toString());
							proveedorPrecedente.setCiudad(formbProveedor.get("des_ubigeociudad_prv").toString());
							precedenteNaturalezaCarga = formbProveedor.get("cod_natutrans").toString();
						}
						else { //Si no encuentra en FormBProveedor, busca de la manera antigua
							for(DAV davDeclaracionPrec : declaracionPrecedente.getListDAVs()){
								proveedorPrecedente = davDeclaracionPrec.getProveedor();
								precedenteNaturalezaCarga = davDeclaracionPrec.getCodnatutrans();

							}
						}
						//PAS20165E220200102 - mtorralba 20160713 - Fin

						/**
						 *4. Que, los siguientes datos de la serie de la declaraci�n precedente sean los mismos que los datos de la serie de la 
						 *declaraci�n que se pretende numerar, mostrando la excepci�n
						 * "�[� campo de la declaraci�n precedente�] no coincide con el consignado en la serie [�n�mero de la serie�]�."		
						 */


						/**
						 *4.1 VALIDAMOS FORMATO A
						 */
						//	�tem del Formato B			
						//if(!fbDeclaracion.getNumsecitem().equals(fbPrecedente.getNumsecitem())){
						//	erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"ITEM DEL FORMATO B",numeroSerieDeclaraci�n.toString()}));
						//
						//}

						//	Tipo de Unidad F�sica				
						if(!codunifides.equals(serie.getCodunifis())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"TIPO DE UNIDAD F�SICA", numeroSerieDeclaracion.toString()}));

						}

						//	Tipo de Unidad Comercial
						//					SAU201510002900029-gmontoya 2015
						//					if(!coduniComercial.equals(serie.getCodunicomer())){
						//						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"TIPO DE UNIDAD COMERCIAL", numeroSerieDeclaraci�n.toString()}));
						//						
						//					}

						//	Sub partida Nacional
						if(!numPartNandi.equals(serie.getNumpartnandi())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"SUB PARTIDA NACIONAL", numeroSerieDeclaracion.toString()}));

						}
						//	Pa�s de Origen
						if(!codPaisOrigen.equals(serie.getCodpaisorige())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"PAIS DE ORIGEN", numeroSerieDeclaracion.toString()}));

						}
						//	Pa�s de Adquisici�n
						if(!codPaisAdquisicion.equals(serie.getCodpaisadqui())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"PAIS DE ADQUISICION", numeroSerieDeclaracion.toString()}));

						}
						//	N�mero de la Factura Comercial
						if(!factPrecedente.getNumfactura().equals(factDeclaracion.getNumfactura())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"NUMERO DE LA FACTURA COMERCIAL", numeroSerieDeclaracion.toString()}));

						}
						//	Fecha de la Factura Comercial
						Long diferenciaSegundosFechaFacturaComercial =  SunatDateUtils.getDifference(factPrecedente.getFecfactura(), factDeclaracion.getFecfactura(), Calendar.SECOND);
						if(diferenciaSegundosFechaFacturaComercial>1){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"FECHA DE LA FACTURA COMERCIAL", numeroSerieDeclaracion.toString()}));

						}
						//	Descripci�n de la Mercanc�a
						if(serie.getDescomercial() == null){
							serie.setDescomercial("");					
						}
						if(serie.getDesformapres() == null){
							serie.setDesformapres("");					
						}
						if(serie.getDesmatecomp() == null){
							serie.setDesmatecomp("");					
						}
						if(serie.getDesusoaplica() == null){
							serie.setDesusoaplica("");					
						}
						if(serie.getDesotros() == null){
							serie.setDesotros("");					
						}
						if(!descripcionMercaderia.trim().equals(serie.getDescomercial().trim().replace("'", "`"))|| !descripcionFormatoAPrese.trim().equals(serie.getDesformapres().trim().replace("'", "`"))|| !descripcionMercaderiaMateCom.trim().equals(serie.getDesmatecomp().trim().replace("'", "`"))|| !descripcionMercaderiaUso.trim().equals(serie.getDesusoaplica().trim().replace("'", "`"))|| !descripcionMercanOtros.trim().equals(serie.getDesotros().trim().replace("'", "`"))){//gmontoya 2015 Pase 171
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"DESCRIPCION DE LA MERCANC�A", numeroSerieDeclaracion.toString()}));

						}
						//	C�digo de la Moneda de Transacci�n, 
						if(!codMoneda.equals(serie.getCodmoneda())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"CODIGO DE LA MONEDA DE TRANSACCION", numeroSerieDeclaracion.toString()}));

						}
						//	Tipo de Seguro				
						if(!codTipoSeguro.equals(serie.getCodtiposeg())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"TIPO DE SEGURO", numeroSerieDeclaracion.toString()}));

						}

						if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO)||codcanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA) ){//PAS20155E220200115-VERDES NO TIENEN DILIGENCIA
							paramsDetDeclaracion.put("cnt_unidad", seriePrecedente.getCntunicomer().toString());

							Map<String,Object> paramSerie = new HashMap<String,Object>();
							paramSerie.put("numCorredocDesc",declaracion.getDua().getNumcorredoc());
							paramSerie.put("numSerieDesc", serie.getNumserie());
							paramSerie.put("codTransaccion", codTransaccion);
							paramSerie.put("cnt_unidad", serie.getCntunicomer());
							//inicio gmontoya Pase 62 2015
							DiligenciaService diligenciaService = (DiligenciaService)fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
							Map<String, Object> duadiligenciada = diligenciaService.findDuaDiligenciada(String.valueOf(seriePrecedente.getNumcorredoc()));
							Date fechaDiligencia = (Date)duadiligenciada.get("FEC_DILIGENCIA");
							Calendar fechaInicioVigencia = Calendar.getInstance();
							fechaInicioVigencia.set(2015, 6, 1);
							if(SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaDiligencia, fechaInicioVigencia.getTime(),"COMPARA_SOLO_FECHA" )){
								boolean tieneSaldo = SeriePrecedenteConSaldo(seriePrecedente.getNumcorredoc(), seriePrecedente.getNumserie(), paramsDetDeclaracion, paramSerie, erroresDuaSDAPrec );
							}
							//fin gmontoya Pase 62 2015
						}

						/**
						 *4.2 VALIDAMOS FORMATO B
						 */

						//	Nombre y direcci�n del Proveedor
						if(!proveedorPrecedente.getNombreRazonSocial().equals(proveedorDeclaracion.getNombreRazonSocial())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"NOMBRE DEL PROVEEDOR", numeroSerieDeclaracion.toString()}));

						}
						if(!proveedorPrecedente.getDireccion().equals(proveedorDeclaracion.getDireccion())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"DIRECCION DEL PROVEEDOR", numeroSerieDeclaracion.toString()}));

						}
						//	Ciudad del proveedor
						//					SAU201510002900029-gmontoya 2015
						//					if(!proveedorPrecedente.getCiudad().equals(proveedorDeclaracion.getCiudad())){
						//						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"CIUDAD DEL PROVEEDOR", numeroSerieDeclaraci�n.toString()}));
						//						
						//					}
						//	Pa�s del Proveedor
						//					SAU201510002900029-gmontoya 2015
						//					if(!proveedorPrecedente.getPais().getCodDatacat().equals(proveedorDeclaracion.getPais().getCodDatacat())){
						//						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"PAIS DEL PROVEEDOR", numeroSerieDeclaraci�n.toString()}));
						//						
						//					}
						//	Naturaleza de la Transacci�n
						//					SAU201510002900029-gmontoya 2015
						//					if(declaracionNaturalezaCarga != null){
						//						if(!declaracionNaturalezaCarga.equals(precedenteNaturalezaCarga)){
						//							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"NATURALEZA DE LA TRANSACCION",numeroSerieDeclaraci�n.toString()}));
						//							
						//						}
						//					}

						//	�tem/Total

						if(fbDeclaracion.getListSerieItems().size() != fbPrecedente.getListSerieItems().size()){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"ITEM/ TOTAL",numeroSerieDeclaracion.toString()}));

						}

						//	Incoterm y Ciudad
						if(!factPrecedente.getCodincoterm().equals(factDeclaracion.getCodincoterm())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"INCOTERM", numeroSerieDeclaracion.toString()}));

						}
						if(!factPrecedente.getDeslugtrans().equals(factDeclaracion.getDeslugtrans())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"CIUDAD", numeroSerieDeclaracion.toString()}));

						}
						//	C�digo de moneda
						if(!factPrecedente.getCodmoneda().equals(factDeclaracion.getCodmoneda())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"CODIGO DE MONEDA", numeroSerieDeclaracion.toString()}));

						}
						//	Pa�s de Origen
						if(!fbPrecedente.getCodpaisorige().equals(fbDeclaracion.getCodpaisorige())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"PAIS DE ORIGEN", numeroSerieDeclaracion.toString()}));

						}
						//	FOB Unitario
						if(fbPrecedente.getMtofobunita().compareTo(fbDeclaracion.getMtofobunita())>0){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"FOB UNITARIO", numeroSerieDeclaracion.toString()}));

						}
						//	Tipo de Unidad Comercial
						if(!fbPrecedente.getCodunidcomer().equals(fbDeclaracion.getCodunidcomer())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"TIPO DE UNIDAD COMERCIAL", numeroSerieDeclaracion.toString()}));

						}
						//	Nombre Comercial de la mercanc�a
						if(!fbPrecedente.getDescomercial().equals(fbDeclaracion.getDescomercial().replace("'", "`"))){//gmontoya 2015 Pase 171
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"NOMBRE COMERCIAL DE LA MERCANCIA", numeroSerieDeclaracion.toString()}));

						}
						//	Marca Comercial de la mercanc�a
						if(!fbPrecedente.getDesmarca().equals(fbDeclaracion.getDesmarca())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"MARCA COMERCIAL DE LA MERCANCIA", numeroSerieDeclaracion.toString()}));

						}
						//	Modelo de la mercanc�a  (de haberse consignado) PAS20175E220200088 
						if (fbPrecedente.getDesmodelo() != null){  
							if(!fbPrecedente.getDesmodelo().equals(fbDeclaracion.getDesmodelo())){
								erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"MODELO DE LA MERCANCIA", numeroSerieDeclaracion.toString()}));
							}
						}
						//	Estado de la mercanc�a
						if(!fbPrecedente.getCodestamer().equals(fbDeclaracion.getCodestamer())){
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"ESTADO DE LA MERCANCIA", numeroSerieDeclaracion.toString()}));

						}
						//	A�o de la mercanc�a (de haberse consignados), 
						if( fbDeclaracion.getAnnfabricaAsInteger() != null && fbPrecedente.getAnnfabricaAsInteger()!=null && fbDeclaracion.getAnnfabricaAsInteger().compareTo(0)>0){
							if(!fbPrecedente.getAnnfabricaAsInteger().equals(fbDeclaracion.getAnnfabricaAsInteger())){
								erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"A�O DE LA MERCANCIA", numeroSerieDeclaracion.toString()}));

							}

						}

						/**
					 6.	Cuando la declaraci�n que se pretende numerar consigne una cantidad mayor, el sistema no permitir� continuar, 
					 mostrando el mensaje del caso: �[�dato�] excede la cantidad consignada en la declaraci�n precedente�. 		
						 */

						/**
						 * 5.	El sistema permitir� que la declaraci�n que se pretende numerar consigne una cantidad igual o menor a la de la declaraci�n precedente en los siguientes datos:
						 */
						//5.1.	N�mero de bultos
						/*RSV SE RETIRA LA VALIDACION
					if(sumaSeriePrec.getCntbultosTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntbultosTotal().compareTo(seriePrecedente.getCntbultos())>0){
						sumaSeriePrec.setCntbultosTotal(new BigDecimal(-1E20));
						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"NUMERO DE BULTOS", CDAprece}));

					}
						//5.2.	Peso Bruto
					if(sumaSeriePrec.getCntpesobrutoTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntpesobrutoTotal().compareTo(seriePrecedente.getCntpesobruto())>0){
						sumaSeriePrec.setCntpesobrutoTotal(new BigDecimal(-1E20));
						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"PESO BRUTO", CDAprece}));

					}
						//5.3.	Peso Neto
					if(sumaSeriePrec.getCntpesonetoTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntpesonetoTotal().compareTo(seriePrecedente.getCntpesoneto())>0){
						sumaSeriePrec.setCntpesonetoTotal(new BigDecimal(-1E20));
						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"PESO NETO", CDAprece}));

					}
						 */
						//5.4.	Unidades F�sicas
						//					SAU201510002900029-gmontoya 2015
						//					if(sumaSeriePrec.getCntunifisTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntunifisTotal().compareTo(seriePrecedente.getCntunifis())>0){
						//						sumaSeriePrec.setCntunifisTotal(new BigDecimal(-1E20));
						//						erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"CANTIDAD DE UNIDADES FISICAS", CDAprece}));
						//						
						//					}
						//5.5.	Unidades Comerciales
						if(sumaSeriePrec.getCntunicomerTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntunicomerTotal().compareTo(seriePrecedente.getCntunicomer())>0){
							sumaSeriePrec.setCntunicomerTotal(new BigDecimal(-1E20));
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"CANTIDAD DE UNIDADES COMERCIALES", CDAprece}));

						}
						//5.6.	Valor FOB
						if(sumaSeriePrec.getMtofobdolTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getMtofobdolTotal().compareTo(seriePrecedente.getMtofobdol())>0){
							sumaSeriePrec.setMtofobdolTotal(new BigDecimal(-1E20));
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"VALOR FOB", CDAprece}));

						}
						//5.7.	Flete
						if(sumaSeriePrec.getMtofledolTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getMtofledolTotal().compareTo(seriePrecedente.getMtofledol())>0){
							sumaSeriePrec.setMtofledolTotal(new BigDecimal(-1E20));
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"MONTO FLETE", CDAprece}));

						}
						//5.8.	Seguro
						if(sumaSeriePrec.getMtosegdolTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getMtosegdolTotal().compareTo(seriePrecedente.getMtosegdol())>0){
							sumaSeriePrec.setMtosegdolTotal(new BigDecimal(-1E20));
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"MONTO SEGURO", CDAprece}));

						}
						//5.9.	Ajuste de Valor (cuando se hubiese transmitido)
						if(serie.getMtoajuste() != null){
							if(sumaSeriePrec.getMtoajusteTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getMtoajusteTotal().compareTo(seriePrecedente.getMtoajuste())>0){
								sumaSeriePrec.setMtoajusteTotal(new BigDecimal(-1E20));
								erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"MONTO AJUSTE DE VALOR", CDAprece}));

							}
						}
						//5.10.	Valor en Aduanas (sumatoria de FOB,  Flete, Seguro y Ajuste)
						if(sumaSeriePrec.getMtovaladuanaTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getMtovaladuanaTotal().compareTo(seriePrecedente.getMtovaladuana())>0){
							sumaSeriePrec.setMtovaladuanaTotal(new BigDecimal(-1E20));
							erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"MONTO VALOR EN ADUANAS", CDAprece}));

						}

					}
				}else{
					erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31897",new String[] {numeroSerieDeclaracion.toString(), pnume_serpr.toString(), CDAprece}));
					return erroresDuaSDAPrec;
				}
			} //Fin !tieneIndicadorMercanciaVigente
			else {
				//Verifica que la serie precedente exista
				Elementos<DatoSerie> listaSeries = duaPrecedente.getListSeries();
				boolean existeSeriePrecedente = false;
				for (DatoSerie numserie : listaSeries) {
					if( SunatNumberUtils.isEqual(pnume_serpr,numserie.getNumserie())) {
						existeSeriePrecedente = true;
						break;
					}
				}
				if( !existeSeriePrecedente ) { 
					erroresDuaSDAPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31897",new String[] {numeroSerieDeclaracion.toString(), pnume_serpr.toString(), CDAprece}));
				}
				//Map<String,Object> mapaPrecedente = valMercanciaVigenteService.obtenerIndicadorMercanciaVigente(duaPrecedente.getListIndicadores());
				//Verificar que la declaracion actual y la precedente tienen el mismo tipo de indicador 33 o 34
				Integer numTotalEnvios = mapaPrecedente.isEmpty() ? Integer.valueOf(0) : (mapaPrecedente.get("desIndicador")==null ? Integer.valueOf(0) : Integer.valueOf(mapaPrecedente.get("desIndicador").toString()));
				Integer nroEnvioParcial = valMercanciaVigenteService.obtenerSecuenciaEnvio(pcaduregpre, pfanoregpre, codregipre, pndclregpre);
				String canalDeclaracion = declaracion.getDua().getCodCanal();
				
				if( SunatNumberUtils.isEqual(serie.getNumserie(),1) ) {
					if( SunatNumberUtils.isLessThanParam(numTotalEnvios, nroEnvioParcial) ) {
						String documPrece = pcaduregpre + "-" + pfanoregpre + "-" + codregipre + "-" + pndclregpre;
						valMercanciaVigenteService.grabaTelelog(erroresDuaSDAPrec, "32049", new Object[]{numTotalEnvios.toString(), documPrece} );
					}
					else if( SunatNumberUtils.isEqual(numTotalEnvios, nroEnvioParcial) ) 
						valMercanciaVigenteService.grabaTelelog(erroresDuaSDAPrec, "32051", new Object[]{mapaPrecedente.get("nomIndicador").toString()});
					else						
						if(canalDeclaracion==null || SunatStringUtils.isEmptyTrim(canalDeclaracion)
								|| (canalDeclaracion!=null && canalDeclaracion.equals(ConstantesDataCatalogo.COD_CANAL_VERDE))) {//si es recti automatica pintar, sino en el eval se muestra
							valMercanciaVigenteService.grabaTelelog(erroresDuaSDAPrec, "32050", new Object[]{SunatNumberUtils.getOrdinal(Double.parseDouble(nroEnvioParcial.toString())), mapaPrecedente.get("nomIndicador").toString()});
						}
				}
			}
			//PAS20171U220200005 - mtorralba 20170810 - Fin
		}
		return erroresDuaSDAPrec;
	}

	private List<Map<String, String>> valCabDetalleSeriesDuaAsigadTPN21(Declaracion declaracion, Declaracion declaracionPrecedente, DatoSerie serie, DatoRegPrecedencia precedente,  Date fechaReferencia, Date fecAutLevante, SumDatoSeriePrec sumaSeriePrec) {
		List<Map<String, String>> erroresDuaAsigadPrec = new ArrayList<Map<String, String>>();	
		Map<String, Object> params = new HashMap<String, Object>();
		List<Didocrec> mapRecoFisicoNaranja =  null;	
		Participante consignatarioDeclaracion;
		Participante consignatarioPrecedente;
		DatoSerie seriePrecedente = new DatoSerie();
		String codcanal = new String();	
		Long numeroCorreDUAPre = declaracionPrecedente.getNumeroCorrelativo();
		Integer numeroSerieDeclaraci�n = serie.getNumserie();			
		String codregipre = precedente.getCodregipre();
		String pcaduregpre = precedente.getCodaduapre();
		String pfanoregpre = SunatStringUtils.substring(precedente.getAnndeclpre(), 0, 4);
		String pndclregpre = precedente.getNumdeclpre();
		Integer pnume_serpr = precedente.getNumserpre();
		String CDAprece = pcaduregpre + "-" + pfanoregpre + "-"	+ codregipre + "-" + pndclregpre;
		String precedenteNaturalezaCarga = "";
		String declaracionNaturalezaCarga = "";
		DUA duaPrecedenteAsigad = declaracionPrecedente.getDua();
		ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
		ConsultaDeclaracionComunService consultaDeclaracionComunService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionComunService");
		//validamos datos principales"); 
		/**
		 * 1.1.	Que, el Tipo de Documento y N�mero del Documento de Identificaci�n del consignatario (importador), 
		 * sea el mismo que el de la declaraci�n que se pretende numerar
		 */
		if (declaracionPrecedente != null) {
			codcanal = duaPrecedenteAsigad.getCodCanal();
			consignatarioDeclaracion = declaracion.getDua().getDeclarante();
			consignatarioPrecedente = duaPrecedenteAsigad.getDeclarante(); 	
			if(consignatarioPrecedente.getTipoDocumentoIdentidad().getCodDatacat()== null || consignatarioPrecedente.getNumeroDocumentoIdentidad() == null){			 
				erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31896",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));	
			}else{
				if(!consignatarioPrecedente.getTipoDocumentoIdentidad().getCodDatacat().equals(consignatarioDeclaracion.getTipoDocumentoIdentidad().getCodDatacat())|| !consignatarioPrecedente.getNumeroDocumentoIdentidad().equals(consignatarioDeclaracion.getNumeroDocumentoIdentidad())){
					erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31896",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
				} 
			}

			/**
			 * 1.8.	Que, la fecha de numeraci�n de la declaraci�n precedente no supere los cuatro a�os a la fecha de transmisi�n 
			 * de la declaraci�n que se pretende numerar
			 */
			if( verificarDeclaracionPrescrita(fechaReferencia, duaPrecedenteAsigad.getFecdeclaracion()) ) {
				erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31899",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
				return erroresDuaAsigadPrec;
				//Declaraci�n precedente prescrita
			}
			/**
			 *  1.2 ERROR N3. Que la declaraci�n precedente debe tener levante autorizado
			 */

			if (fecAutLevante==null
					|| SunatDateUtils.isDefaultDate(fecAutLevante)) {					
				erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31890",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
				return erroresDuaAsigadPrec;
				//Declaraci�n precedente{(0)} no cuenta con Levante Autorizado
			}
			/**
			 *  1.3.	Que, cuente con canal de control rojo o canal naranja remitido a reconocimiento f�sico o canal verde que hayan 
			 *  solicitado reconocimiento f�sico con Expediente c�digo 3092 (Solicitud para reconocimiento f�sico) concluido y procedente,
			 */
			if(!codcanal.equals(ConstantesDataCatalogo.COD_CANAL_ROJO)){
				//			inicio gmontoya Pase 436 - 2015
				//			if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)){
				//				params.put("adudua", pcaduregpre);
				//				params.put("anodua", pfanoregpre);
				//				params.put("regdua", codregipre);
				//				params.put("numdua", pndclregpre);						
				//				mapRecoFisicoNaranja =  consultaDeclaracionComunService.obtenerListaDidocrec(params);
				//				if(mapRecoFisicoNaranja == null || CollectionUtils.isEmpty(mapRecoFisicoNaranja)){
				//					erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31898",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
				//					Map<String, Object> paramsIncidencia = new HashMap<String, Object>();			
				//					paramsIncidencia.put("adudua", pcaduregpre);
				//					paramsIncidencia.put("anodua", pfanoregpre.toString().substring(2,4));
				//					paramsIncidencia.put("regdua", codregipre);
				//					paramsIncidencia.put("numdua", pndclregpre);
				//					paramsIncidencia.put("serdua", SunatStringUtils.lpad(pnume_serpr.toString(), 4, ' '));
				//									
				//					 boolean incidencia = consultaDeclaracionComunService.tieneIncidenciaMercanciasVigentes(paramsIncidencia);
				//					 if(!incidencia){
				//						 erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31912",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
				//						 return erroresDuaAsigadPrec;
				//					 }
				//					return erroresDuaAsigadPrec;
				//					//Declaraci�n precedente{(0)} no ha sido objeto de reconocimiento f�sico
				//				}	
				//				/**
				//				 *  1.6.	Que, la declaraci�n precedente registre como incidencia el c�digo F121 correspondiente a Mercanc�as 
				//				 *  Vigentes (registrado en la diligencia de despacho), excepto las declaraciones canal verde que hayan solicitado 
				//				 *  reconocimiento f�sico con Expediente c�digo 3092 concluido y procedente,
				//				*/
				//				if(mapRecoFisicoNaranja != null && !CollectionUtils.isEmpty(mapRecoFisicoNaranja)){
				//					Map<String, Object> paramsIncidencia = new HashMap<String, Object>();			
				//					paramsIncidencia.put("adudua", pcaduregpre);
				//					paramsIncidencia.put("anodua", pfanoregpre.toString().substring(2,4));
				//					paramsIncidencia.put("regdua", codregipre);
				//					paramsIncidencia.put("numdua", pndclregpre);
				//					paramsIncidencia.put("serdua", SunatStringUtils.lpad(pnume_serpr.toString(), 4, ' '));
				//									
				//					 boolean incidencia = consultaDeclaracionComunService.tieneIncidenciaMercanciasVigentes(paramsIncidencia);
				//					 if(!incidencia){
				//						 erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31912",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
				//						 return erroresDuaAsigadPrec;
				//					 }
				//				}
				//			}
				//			fin gmontoya Pase 436 - 2015
				if(codcanal.equals(ConstantesDataCatalogo.COD_CANAL_VERDE)){
					//Se evalua si tiene expediente 3092. Para determinar si un expediente est� concluido como PROCEDENTE, este debe tener tipo de conclusi�n 5. 
					Map<String,Object> paramsExpedi = new HashMap<String,Object>();
					paramsExpedi.put("PROCEDIM", ConstantesDataCatalogo.COD_DUA_RECONO_FISICO);
					paramsExpedi.put("COD_ADUANA", pcaduregpre);
					paramsExpedi.put("COD_REGIMEN", codregipre);
					paramsExpedi.put("ANN_PRESEN",  pfanoregpre);
					paramsExpedi.put("NUM_DECLARACION", pndclregpre);
					paramsExpedi.put("TIPO_CONC", ConstantesDataCatalogo.COD_DUA_RECONO_FISICO_PROCEDENTE_Y_CONCLUIDO);
					//swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + pcaduregpre));
					//List<Map<String,Object>> expedis = expediDAO.findByProdedimiento(paramsExpedi);
					//Estabilizacion SDA Consulta de expedientes
					ExpedienteService expedienteService = (ExpedienteService)fabricaDeServicios.getService("tramite.ExpedienteService");
					List<Map<String,Object>> expedis = expedienteService.findByDocumentoOrigen(paramsExpedi);
					if(CollectionUtils.isEmpty(expedis)){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31898",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
						return erroresDuaAsigadPrec;
						//Declaraci�n precedente{(0)} no ha sido objeto de reconocimiento f�sico
					}
				}

			}
			//Inicio gmontoya Pase 436 - 2015 
			//		else{
			//			/**
			//			 *  1.6.	Que, la declaraci�n precedente registre como incidencia el c�digo F121 correspondiente a Mercanc�as 
			//			 *  Vigentes (registrado en la diligencia de despacho), excepto las declaraciones canal verde que hayan solicitado 
			//			 *  reconocimiento f�sico con Expediente c�digo 3092 concluido y procedente,
			//			*/
			//			Map<String, Object> paramsIncidencia = new HashMap<String, Object>();			
			//			paramsIncidencia.put("adudua", pcaduregpre);
			//			paramsIncidencia.put("anodua", pfanoregpre.toString().substring(2,4));
			//			paramsIncidencia.put("regdua", codregipre);
			//			paramsIncidencia.put("numdua", pndclregpre);
			//			paramsIncidencia.put("serdua", SunatStringUtils.lpad(pnume_serpr.toString(), 4, ' '));
			//							
			//			 boolean incidencia = consultaDeclaracionComunService.tieneIncidenciaMercanciasVigentes(paramsIncidencia);
			//			 if(!incidencia){
			//				 erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31912",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
			//				 return erroresDuaAsigadPrec;
			//			 }
			//		}
			//		Fin gmontoya Pase 436 - 2015

			/**
			 * 1.9.	Que la declaraci�n se encuentre cancelada (pagada) si est� acogida a la garant�a previa del Art�culo 160�
			 */
			if(duaPrecedenteAsigad.getPago()!= null){
				if(duaPrecedenteAsigad.getPago().getPagoDeclaracion()!= null){
					if(duaPrecedenteAsigad.getPago().getPagoDeclaracion().getCodtipopago() == null){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31900",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
						return erroresDuaAsigadPrec;					
					}else{
						if(!duaPrecedenteAsigad.getPago().getPagoDeclaracion().getCodtipopago().equals("P")){
							erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31900",new String[] {numeroSerieDeclaraci�n.toString(), CDAprece}));
							return erroresDuaAsigadPrec;
						}
					}
					//Declaraci�n precedente {(0)}acogida al Art.160� no se encuentra pagada	
				}

			}	
		}

		// validamos detalles
		DiserieFormbItem diserieFormbItem = consultaDeclaracionImpoConsumoService.consultarSerieFormbItemImpo(pfanoregpre.toString().substring(2,4), pcaduregpre, pndclregpre, pnume_serpr.toString(), pcaduregpre);

		//DiserieFormbItem diserieFormbItem = diseriesiDAO.selectDiserieFormbItem(pfanoregpre.toString().substring(2,4), pcaduregpre, pndclregpre, pnume_serpr.toString());
		//DatoSerie datoSeriePrec = damOperativaConsultaService.ObtenerSerieFromDAMOperativa(pcaduregpre, codregipre, new Integer(pfanoregpre.substring(0, 4)), pndclregpre.toString(),pnume_serpr.toString());
		if (diserieFormbItem == null) {
			erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31897",new String[] {numeroSerieDeclaraci�n.toString(), pnume_serpr.toString(), CDAprece}));
			return erroresDuaAsigadPrec;
		} else {
			// Obtenemos variables necesarias para la validacion de las reglas del ASIGAD
			if(diserieFormbItem!=null){
				//seteamos datos a comparar en la validaci�n del TPN21 RIN
				seriePrecedente.setNumserie(new Integer(diserieFormbItem.getNumeSerie().trim()));	
				seriePrecedente.setCntbultos(diserieFormbItem.getCantBulto());
				seriePrecedente.setCntpesobruto(diserieFormbItem.getPesoBruto());
				seriePrecedente.setCntpesoneto(diserieFormbItem.getPesoNeto());				
				seriePrecedente.setCntunicomer(diserieFormbItem.getQunicom());
				seriePrecedente.setCodunicomer(diserieFormbItem.getTunicom()!=null?diserieFormbItem.getTunicom().trim():"");//gmontoya P29
				seriePrecedente.setCntunifis(diserieFormbItem.getUnidFiqty());
				seriePrecedente.setCodunifis(diserieFormbItem.getUnidFides());
				seriePrecedente.setNumpartnandi(diserieFormbItem.getPartNandi());
				seriePrecedente.setMtofobdol(diserieFormbItem.getFobDolpol());
				seriePrecedente.setMtosegdol(diserieFormbItem.getSegDolar());
				seriePrecedente.setMtofledol(diserieFormbItem.getFleDolar());
				seriePrecedente.setCodmoneda(diserieFormbItem.getCodiMoned());
				seriePrecedente.setCodtiposeg(diserieFormbItem.getCseg());
				seriePrecedente.setCodpaisadqui(diserieFormbItem.getPaisAdqui());
				seriePrecedente.setCodpaisorige(diserieFormbItem.getPaisOrige());
				seriePrecedente.setDescomercial(diserieFormbItem.getDescComer()!=null?diserieFormbItem.getDescComer().trim():"NA");//arey PAS20155E220000396
				seriePrecedente.setDesformapres(diserieFormbItem.getDescFopre()!=null?diserieFormbItem.getDescFopre().trim():"NA");//arey PAS20155E220000396
				seriePrecedente.setDesmatecomp(diserieFormbItem.getDescMatco()!=null?diserieFormbItem.getDescMatco().trim():"NA");//arey PAS20155E220000396
				seriePrecedente.setDesusoaplica(diserieFormbItem.getDescUsoap()!=null?diserieFormbItem.getDescUsoap().trim():"NA");//arey PAS20155E220000396
				seriePrecedente.setDesotros(diserieFormbItem.getDescOtros()!=null?diserieFormbItem.getDescOtros().trim():"NA");//arey PAS20155E220000396			


				//obtenemos datos de la factura y proveedor
				FormbFactProv formbFactProv = consultaDeclaracionImpoConsumoService.consultarFormbFactuProvImpo(pfanoregpre.toString().substring(2,4), pcaduregpre, pndclregpre, codregipre, diserieFormbItem.getFbNumSecFactu(), diserieFormbItem.getFbNumSecProveedor(), diserieFormbItem.getFbSerieA(), pcaduregpre);
				if(formbFactProv!=null){
					//Obtener datos de los formatos actual y factura
					ValItemFB valItemFB = fabricaDeServicios.getService("ValItemFB");
					ValNegocNumeracFormA valNegocNumeracFormA = fabricaDeServicios.getService("ValNegocNumeracFormA");
					DatoItem fbDeclaracion = valItemFB.getItemCorrespondiente(serie, declaracion);					
					DatoFactura factDeclaracion = valNegocNumeracFormA.getFacturaCorrespondiente(serie, declaracion);

					//Para obtener los datos del proceedor actual y precedente declarar las siguientes variables e instanciarlas de la siguiente manera: 
					Participante proveedorDeclaracionAsigad = new Participante();
					for (DAV davDeclaracion : declaracion.getListDAVs()) {
						proveedorDeclaracionAsigad = davDeclaracion.getProveedor();
						declaracionNaturalezaCarga = davDeclaracion.getCodnatutrans();

					}
					precedenteNaturalezaCarga = formbFactProv.getNaturaleza();

					/**
					 *4. Que, los siguientes datos de la serie de la declaraci�n precedente sean los mismos que los datos de la serie de la 
					 *declaraci�n que se pretende numerar, mostrando la excepci�n
					 * "�[� campo de la declaraci�n precedente�] no coincide con el consignado en la serie [�n�mero de la serie�]�."		
					 */


					/**
					 *4.1 VALIDAMOS FORMATO A
					 */
					//	�tem del Formato B			
					//if(!fbDeclaracion.getNumsecitem().toString().equals(diserieFormbItem.getNumeItem())){
					//	erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"ITEM DEL FORMATO B",numeroSerieDeclaraci�n.toString()}));
					//	
					//}

					//	Tipo de Unidad F�sica				
					//					SAU201510002900029-gmontoya 2015
					//					if(!seriePrecedente.getCodunifis().equals(serie.getCodunifis())){
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"TIPO DE UNIDAD F�SICA", numeroSerieDeclaraci�n.toString()}));
					//						
					//					}

					//	Tipo de Unidad Comercial
					if(!seriePrecedente.getCodunicomer().equals(serie.getCodunicomer())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"TIPO DE UNIDAD COMERCIAL", numeroSerieDeclaraci�n.toString()}));

					}

					//	Sub partida Nacional
					if(!seriePrecedente.getNumpartnandi().equals(serie.getNumpartnandi())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"SUB PARTIDA NACIONAL", numeroSerieDeclaraci�n.toString()}));

					}
					//	Pa�s de Origen
					if(!seriePrecedente.getCodpaisorige().equals(serie.getCodpaisorige())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"PAIS DE ORIGEN", numeroSerieDeclaraci�n.toString()}));

					}
					//	Pa�s de Adquisici�n
					if(!seriePrecedente.getCodpaisadqui().equals(serie.getCodpaisadqui())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"PAIS DE ADQUISICION", numeroSerieDeclaraci�n.toString()}));

					}
					//	N�mero de la Factura Comercial
					if(!formbFactProv.getNumeFactura().equals(factDeclaracion.getNumfactura())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"NUMERO DE LA FACTURA COMERCIAL", numeroSerieDeclaraci�n.toString()}));

					}
					//	Fecha de la Factura Comercial
					Long diferenciaSegundosFechaFacturaComercial =  SunatDateUtils.getDifference(SunatDateUtils.getDateFromInteger(formbFactProv.getFechFactura()), factDeclaracion.getFecfactura(), Calendar.SECOND);
					if(diferenciaSegundosFechaFacturaComercial>1){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"FECHA DE LA FACTURA COMERCIAL", numeroSerieDeclaraci�n.toString()}));

					}

					//	Descripci�n de la Mercanc�a
					if(serie.getDescomercial() == null){
						serie.setDescomercial("");					
					}
					if(serie.getDesformapres() == null){
						serie.setDesformapres("");					
					}
					if(serie.getDesmatecomp() == null){
						serie.setDesmatecomp("");					
					}
					if(serie.getDesusoaplica() == null){
						serie.setDesusoaplica("");					
					}
					if(serie.getDesotros() == null){
						serie.setDesotros("");					
					}
					//					boolean errordescri=false;//gmontoya 436-2015
					if(!seriePrecedente.getDescomercial().trim().equals(serie.getDescomercial().trim().replace("'", "`"))){//gmontoya 2015 Pase 171
						//						errordescri = true;//gmontoya 436-2015
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"DESCRIPCION DE LA MERCANC�A", numeroSerieDeclaraci�n.toString().concat(". ENVIAR DESCRIPCION COMERCIAL CON EL VALOR DE ").concat(seriePrecedente.getDescomercial())}));//gmontoya 436-2015

					}
					//					Inicio gmontoya 436-2015
					//					if(!seriePrecedente.getDesformapres().trim().equals(serie.getDesformapres().trim()) && !errordescri){
					//						errordescri = true;
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"DESCRIPCION DE LA MERCANC�A", numeroSerieDeclaraci�n.toString() + (seriePrecedente.getDesformapres().equals("NA")?". ENVIAR DESCRIPCION DE FORMA DE PRESENTACION CON EL VALOR DE NA" :"")}));
					//						
					//					}
					//					if(!seriePrecedente.getDesmatecomp().trim().equals(serie.getDesmatecomp().trim()) && !errordescri){
					//						errordescri = true;
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"DESCRIPCION DE LA MERCANC�A", numeroSerieDeclaraci�n.toString() + (seriePrecedente.getDesmatecomp().equals("NA")?". ENVIAR DESCRIPCION DE MATERIAL Y COMPOSICION CON EL VALOR DE NA" :"")}));
					//						
					//					}
					//					if(!seriePrecedente.getDesusoaplica().trim().equals(serie.getDesusoaplica().trim() ) && !errordescri){
					//						errordescri = true;
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"DESCRIPCION DE LA MERCANC�A", numeroSerieDeclaraci�n.toString() + (seriePrecedente.getDesusoaplica().equals("NA")?". ENVIAR DESCRIPCION DE USO Y APLICACION CON EL VALOR DE NA" :"")}));
					//						
					//					}
					//					if(!seriePrecedente.getDesotros().trim().equals(serie.getDesotros().trim()) && !errordescri){
					//						errordescri = true;
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"DESCRIPCION DE LA MERCANC�A", numeroSerieDeclaraci�n.toString() + (seriePrecedente.getDesotros().equals("NA")?". ENVIAR DESCRIPCION DE OTRAS CARACTERISTICAS CON EL VALOR DE NA" :"")}));
					//						
					//					}
					//					Inicio gmontoya 436-2015

					//	C�digo de la Moneda de Transacci�n, 
					if(!seriePrecedente.getCodmoneda().equals(serie.getCodmoneda())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"CODIGO DE LA MONEDA DE TRANSACCION", numeroSerieDeclaraci�n.toString()}));

					}
					//	Tipo de Seguro				
					if(!seriePrecedente.getCodtiposeg().equals(serie.getCodtiposeg())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"TIPO DE SEGURO", numeroSerieDeclaraci�n.toString()}));

					}
					/**
					 *4.2 VALIDAMOS FORMATO B
					 */

					//	Nombre y direcci�n del Proveedor
					if(!formbFactProv.getNombreProv().trim().equals(proveedorDeclaracionAsigad.getNombreRazonSocial().trim())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"NOMBRE DEL PROVEEDOR", numeroSerieDeclaraci�n.toString()}));

					}
					if(!formbFactProv.getDireccionProv().trim().equals(proveedorDeclaracionAsigad.getDireccion().trim())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"DIRECCION DEL PROVEEDOR", numeroSerieDeclaraci�n.toString()}));

					}
					//	Ciudad del proveedor
					//					SAU201510002900029-gmontoya 2015
					//					if(!formbFactProv.getCiudadProv().equals(proveedorDeclaracionAsigad.getCiudad())){
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"CIUDAD DEL PROVEEDOR", numeroSerieDeclaraci�n.toString()}));
					//						
					//					}
					//	Pa�s del Proveedor
					//					SAU201510002900029-gmontoya 2015
					//					if(!formbFactProv.getPaisProv().equals(proveedorDeclaracionAsigad.getPais().getCodDatacat())){
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"PAIS DEL PROVEEDOR", numeroSerieDeclaraci�n.toString()}));
					//						
					//					}
					//	Naturaleza de la Transacci�n
					//					SAU201510002900029-gmontoya 2015
					//					if(declaracionNaturalezaCarga != null){
					//						if(!formbFactProv.getNaturaleza().equals(precedenteNaturalezaCarga)){
					//							erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"NATURALEZA DE LA TRANSACCION",numeroSerieDeclaraci�n.toString()}));
					//							
					//						}
					//					}

					//	�tem/Total

					/*if(fbDeclaracion.getListSerieItems().size() != formbFactProv.getCantidadItem()){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"ITEM/ TOTAL",numeroSerieDeclaraci�n.toString()}));

					}*/

					//	Incoterm y Ciudad
					if(!formbFactProv.getIncoterm().equals(factDeclaracion.getCodincoterm())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"INCOTERM", numeroSerieDeclaraci�n.toString()}));

					}
					/*if(!formbFactProv.getLugar().equals(factDeclaracion.getDeslugtrans())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"CIUDAD", numeroSerieDeclaraci�n.toString()}));

					}*/
					//	C�digo de moneda
					if(!formbFactProv.getCodMoneda().equals(factDeclaracion.getCodmoneda())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"CODIGO DE MONEDA", numeroSerieDeclaraci�n.toString()}));

					}
					//	Pa�s de Origen
					if(!diserieFormbItem.getFbPaisOrigen().equals(fbDeclaracion.getCodpaisorige())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"PAIS DE ORIGEN", numeroSerieDeclaraci�n.toString()}));

					}
					//	FOB Unitario
					if(diserieFormbItem.getFbFobUnitario().compareTo(fbDeclaracion.getMtofobunita())>0){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"FOB UNITARIO", numeroSerieDeclaraci�n.toString()}));

					}
					//	Tipo de Unidad Comercial
					if(!(diserieFormbItem.getTunicom()!=null?diserieFormbItem.getTunicom().trim():"").equals(fbDeclaracion.getCodunidcomer())){//gmontoya P29
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"TIPO DE UNIDAD COMERCIAL", numeroSerieDeclaraci�n.toString()}));

					}
					//					inicio gmontoya 2015 Pase 407
					//					//	Nombre Comercial de la mercanc�a
					//					if(!diserieFormbItem.getFbDesComercial().equals(fbDeclaracion.getDescomercial())){
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"NOMBRE COMERCIAL DE LA MERCANCIA", numeroSerieDeclaraci�n.toString()}));
					//						
					//					}
					//					//	Marca Comercial de la mercanc�a
					//					if(!diserieFormbItem.getFbMarca().equals(fbDeclaracion.getDesmarca())){
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"MARCA COMERCIAL DE LA MERCANCIA", numeroSerieDeclaraci�n.toString()}));
					//						
					//					}
					//					//	Modelo de la mercanc�a
					//					if(!diserieFormbItem.getFbModelo().equals(fbDeclaracion.getDesmodelo())){
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"MODELO DE LA MERCANCIA", numeroSerieDeclaraci�n.toString()}));
					//						
					//					}
					//					fin gmontoya 2015 Pase 407
					//	Estado de la mercanc�a
					if(!diserieFormbItem.getFbEstadoMerc().equals(fbDeclaracion.getCodestamer())){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"ESTADO DE LA MERCANCIA", numeroSerieDeclaraci�n.toString()}));

					}
					//	A�o de la mercanc�a (de haberse consignados), 
					if( fbDeclaracion.getAnnfabrica() != null && fbDeclaracion.getAnnfabricaAsInteger().compareTo(0)>0 ) {
						if( !SunatStringUtils.isEqualTo(diserieFormbItem.getFbAnioMercancia(), fbDeclaracion.getAnnfabricaAsInteger().toString()) ) {
							//if(!diserieFormbItem.getFbAnioMercancia().equals(fbDeclaracion.getAnnfabricaAsInteger())){
							erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31901",new String[] {"A�O DE LA MERCANCIA", numeroSerieDeclaraci�n.toString()}));

						}
					}


					/**
					 6.	Cuando la declaraci�n que se pretende numerar consigne una cantidad mayor, el sistema no permitir� continuar, 
					 mostrando el mensaje del caso: �[�dato�] excede la cantidad consignada en la declaraci�n precedente�. 		
					 */

					/**
					 * 5.	El sistema permitir� que la declaraci�n que se pretende numerar consigne una cantidad igual o menor a la de la declaraci�n precedente en los siguientes datos:
					 */
					//5.1.	N�mero de bultos
					/*RSV SE RETIRA LA VALIDACION	
					if(sumaSeriePrec.getCntbultosTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntbultosTotal().compareTo(seriePrecedente.getCntbultos())>0){
						sumaSeriePrec.setCntbultosTotal(new BigDecimal(-1E20));
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"NUMERO DE BULTOS", CDAprece}));

					}
						//5.2.	Peso Bruto
					if(sumaSeriePrec.getCntpesobrutoTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntpesobrutoTotal().compareTo(seriePrecedente.getCntpesobruto())>0){
						sumaSeriePrec.setCntpesobrutoTotal(new BigDecimal(-1E20));
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"PESO BRUTO", CDAprece}));

					}
						//5.3.	Peso Neto
					if(sumaSeriePrec.getCntpesonetoTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntpesonetoTotal().compareTo(seriePrecedente.getCntpesoneto())>0){
						sumaSeriePrec.setCntpesonetoTotal(new BigDecimal(-1E20));
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"PESO NETO", CDAprece}));

					}
					 */
					//5.4.	Unidades F�sicas
					//					SAU201510002900029-gmontoya 2015
					//					if(sumaSeriePrec.getCntunifisTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntunifisTotal().compareTo(seriePrecedente.getCntunifis())>0){
					//						sumaSeriePrec.setCntunifisTotal(new BigDecimal(-1E20));
					//						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"CANTIDAD DE UNIDADES FISICAS", CDAprece}));
					//						
					//					}
					//5.5.	Unidades Comerciales
					if(sumaSeriePrec.getCntunicomerTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getCntunicomerTotal().compareTo(seriePrecedente.getCntunicomer())>0){
						sumaSeriePrec.setCntunicomerTotal(new BigDecimal(-1E20));
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"CANTIDAD DE UNIDADES COMERCIALES", CDAprece}));

					}
					//5.6.	Valor FOB
					if(sumaSeriePrec.getMtofobdolTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getMtofobdolTotal().compareTo(seriePrecedente.getMtofobdol())>0){
						sumaSeriePrec.setMtofobdolTotal(new BigDecimal(-1E20));
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"VALOR FOB", CDAprece}));

					}
					//5.7.	Flete
					if(sumaSeriePrec.getMtofledolTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getMtofledolTotal().compareTo(seriePrecedente.getMtofledol())>0){
						sumaSeriePrec.setMtofledolTotal(new BigDecimal(-1E20));
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"MONTO FLETE", CDAprece}));

					}
					//5.8.	Seguro
					if(sumaSeriePrec.getMtosegdolTotal().compareTo(BigDecimal.ZERO)>0 && sumaSeriePrec.getMtosegdolTotal().compareTo(seriePrecedente.getMtosegdol())>0){
						sumaSeriePrec.setMtosegdolTotal(new BigDecimal(-1E20));
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {"MONTO SEGURO", CDAprece}));

					}
					//5.9.	Ajuste de Valor (cuando se hubiese transmitido)
					/*if(serie.getMtoajuste() != null){
						if(serie.getMtoajuste().compareTo(seriePrecedente.getMtoajuste())>0){
							erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {numeroSerieDeclaraci�n.toString(),"MONTO AJUSTE DE VALOR", CDAprece}));

						}
					}
						//5.10.	Valor en Aduanas (sumatoria de FOB,  Flete, Seguro y Ajuste)
					if(serie.getMtovaladuana().compareTo(seriePrecedente.getMtovaladuana())>0){
						erroresDuaAsigadPrec.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31902",new String[] {numeroSerieDeclaraci�n.toString(),"MONTO VALOR EN ADUANAS", CDAprece}));
					 */						
				}	  
			}
		}
		return erroresDuaAsigadPrec;
	}

	public boolean esTPN21(Declaracion declaracion){
		boolean esTPN21= false; 	 
		Elementos<DatoSerie> series = declaracion.getDua().getListSeries();		

		for (DatoSerie serie : series) {		
			String serieTPN21 = serie.getCodtratprefe().toString();			
			if(serieTPN21.equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_NACIONAL_TPN21)){
				esTPN21 = true;//basta q una serie sera TPN21 							
			}		
		}	 
		return esTPN21;
	}

	public static String formatearNumeroDeclaracion(String numeroDeclaracionPrecedente){
		Integer numeroManifiestoAsInteger = null;
		try{
			String trimmedString = StringUtils.trimWhitespace(numeroDeclaracionPrecedente); 
			numeroManifiestoAsInteger = new Integer(trimmedString);
		}catch (Exception e) {}
		if(numeroManifiestoAsInteger==null){
			return null;
		}

		int MAX_LENGTH_OF_NUMERO_MANIFIESTO = 6;
		if(String.valueOf(numeroManifiestoAsInteger).length()>=MAX_LENGTH_OF_NUMERO_MANIFIESTO){
			return String.valueOf(numeroManifiestoAsInteger);
		}
		char[] s = new char[MAX_LENGTH_OF_NUMERO_MANIFIESTO-String.valueOf(numeroManifiestoAsInteger).length()];
		Arrays.fill(s, ' ');
		String appendToLeft = String.valueOf(s);
		String newString = appendToLeft+numeroManifiestoAsInteger;
		return newString;
	}
	//fin msancheza TPN21


	//PAS20155E220200012 - mtorralba 20150616 - Inicio
	private boolean SeriePrecedenteConSaldo(Long num_corredocpre, Integer num_seriepre, Map<String, String> paramsDetDeclaracion, Map<String,Object> paramSerie, List<Map<String, String>> listaErrores  ) {

		boolean tieneSaldo = false;
		BigDecimal usadoEnNumeracion = BigDecimal.ZERO;
		String duaPrecedente = "";  
		duaPrecedente = paramsDetDeclaracion.get("cod_aduana").concat("-").concat(paramsDetDeclaracion.get("ann_presen")).concat("-").concat(paramsDetDeclaracion.get("cod_regimen"));
		duaPrecedente = duaPrecedente.concat("-").concat(paramsDetDeclaracion.get("num_declaracion"));

		DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");

		//Validamos si a�n queda Saldo de Unidades Comerciales en la serie precedente declarada
		Map<String,Object> paramCtaCte = new HashMap<String,Object>();
		paramCtaCte.put("numCorredoc", num_corredocpre);
		paramCtaCte.put("numSerie", num_seriepre);

		//Si no es numeracion, se obtiene los datos de la serie precedente asociada en la numeracion, para sumarle lo utilizado en la numeracion antes de disminuir el saldo.
		if( !paramSerie.get("codTransaccion").toString().equals("1001") ) {
			Map<String,Object> declaPreceNumeracion = ctaCteService.obtenerDeclaracionPrecedente((Long)paramSerie.get("numCorredocDesc"), (Integer)paramSerie.get("numSerieDesc"));
			if( declaPreceNumeracion != null && !CollectionUtils.isEmpty(declaPreceNumeracion))//gmontoya P29 2015

				if( SunatNumberUtils.isEqual(Long.valueOf(declaPreceNumeracion.get("NUM_CORREDOCPRE").toString()), num_corredocpre) && 
						SunatNumberUtils.isEqual(Integer.valueOf(declaPreceNumeracion.get("NUM_SECSERIEPRE").toString()), num_seriepre) ) {
					usadoEnNumeracion = (BigDecimal)declaPreceNumeracion.get("CNT_UNICOMER");
				}
		}

		CabCtacteRegimen cabCtacteRegimen = ctaCteService.obtenerSaldoCtaCtePorDeclaracion(paramCtaCte);

		if( cabCtacteRegimen != null ) {
			BigDecimal cntUnidad = (BigDecimal)paramSerie.get("cnt_unidad");
			BigDecimal saldoDisponible =  SunatNumberUtils.sum(cabCtacteRegimen.getCntSaldoUnidad(), usadoEnNumeracion ); 

			if( cntUnidad.compareTo(saldoDisponible) >0 ) { //gmontoya Pase 75
				tieneSaldo = false;	
				listaErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("32014",
						new String[] { paramsDetDeclaracion.get("num_secserie"),  paramSerie.get("cnt_unidad")!=null?paramSerie.get("cnt_unidad").toString():"", cabCtacteRegimen.getCntSaldoUnidad()!=null?cabCtacteRegimen.getCntSaldoUnidad().toString():"", duaPrecedente, num_seriepre!=null?num_seriepre.toString():""}));			
			}
			else {
				tieneSaldo = true;
			}

		}
		else {
			tieneSaldo = false;
			listaErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("32013",
					new String[] { paramsDetDeclaracion.get("num_secserie"), duaPrecedente, num_seriepre.toString()}));			
		}


		return tieneSaldo;
	}
	//PAS20155E220200012 - mtorralba 20150616 - Fin

	//PAS20171U220200005 - mtorralba 20170926
	private boolean verificarDeclaracionPrescrita(Date fechaReferencia, Date fechaDeclaracion) {
		boolean DAMprescrita = false;
		Long mesesTranscurridos = SunatDateUtils.getDifference(fechaReferencia, fechaDeclaracion, Calendar.MONTH);
		if( mesesTranscurridos > 48 ) {
			DAMprescrita = true;
		}
		else if (mesesTranscurridos == 48 ) {
			int diaReferencia = fechaReferencia.getDate();
			int diaDeclaracion = fechaDeclaracion.getDate();
			DAMprescrita = diaDeclaracion < diaReferencia;
		}
		return DAMprescrita;
	}
	
}
