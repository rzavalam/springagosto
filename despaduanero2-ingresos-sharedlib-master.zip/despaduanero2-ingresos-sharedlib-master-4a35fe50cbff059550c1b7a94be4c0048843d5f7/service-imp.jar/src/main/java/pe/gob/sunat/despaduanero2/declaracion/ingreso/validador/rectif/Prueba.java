package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DatoRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DetSolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GrabarRectificacionService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public class Prueba {

	public static void main (String arg[]) throws Exception {/*
		String classpath= "classpath:pe/gob/sunat/despaduanero2/declaracion/ingreso/validador/config/";
		String[] locations= new String[]{classpath+"iavalidacion-datasource-test.xml"
				                         ,classpath+"iavalidarectificacion-service.xml"
				                         ,classpath+"iavalidarectificacion-data.xml"
				                         //,classpath+"iavalidaformatob-service.xml"
				                         ,classpath+"iavalidaformatob-data.xml"
				                         ,classpath+"iagenadeudo-service.xml"
				                         ,classpath+"iagenadeudo-data.xml"
				                         ,"classpath*:catalogo-ayudas-util-data-test.xml"
				                         ,"classpath*:catalogo-ayudas-service-test.xml"
				                         ,"classpath*:manifiesto-service-test.xml"
				                         ,"classpath*:despaduanero2-service-test.xml"
				                         ,"classpath*:despaduanero2-data-test.xml"
				                         };
       ApplicationContext context=new  FileSystemXmlApplicationContext(locations);
       ValRectif valrectif=(ValRectif)context.getBean("ValRectif");
       List<Map<String,?>> errores=new ArrayList<Map<String,?>>();
       Declaracion declaracion=obtenerDeclaracion();
       Map<String,Object>  orquestador=new HashMap<String, Object>();
       orquestador.putAll(valrectif.setupDeclaracion(declaracion, "X", "x", 0, 0L, "x", "x", "x"));
       orquestador.putAll(valrectif.formobjval(declaracion));
       Declaracion declaracionBD=  (Declaracion)orquestador.get("declaracionBD");
       //Declaracion declaracionBD=obtenerDeclaracionBD();
       //errores.add(valrectif.transaccion(declaracion)) ;
       errores.add(valrectif.existedua(declaracion)); 
       errores.add(valrectif.transmitioregul(declaracion, declaracionBD));
       errores.add(valrectif.Solrectieneval(declaracion));
       orquestador.putAll(valrectif.CamposRectiOficio(declaracionBD));
   	 List<DetSolicitudRectificacionBean> rectificacionesOficio=(List<DetSolicitudRectificacionBean>) orquestador.get("rectificacionesOficio");
   	//    orquestador.putAll(valrectif.Compobjvalobjnum(declaracion, declaracionBD));
   	 SolicitudRectificacionBean solicitudRectificacion=(SolicitudRectificacionBean)orquestador.get("solicitudRectificacion");
   	    errores.addAll(valrectif.Complistaconrectioficio(solicitudRectificacion, rectificacionesOficio));
   	    errores.add(valrectif.Tienedudaraz(declaracionBD, solicitudRectificacion));
   	    errores.add(valrectif.Norectifiagente(solicitudRectificacion));
   	    errores.add(valrectif.Tieneformatob(declaracionBD));
   	    Map<String, Object> variablesIngreso=(Map<String,Object>)orquestador.get("variablesIngreso");
   	    errores.add(valrectif.Afectaart15lga(declaracion, variablesIngreso));
   	    errores.add(valrectif.Valtpnvehiculo(declaracion,declaracionBD)) ;
   	     errores.add(valrectif.Estadodatado(declaracionBD)) ;
   	     orquestador.putAll(valrectif.Infoparadatado(declaracion,variablesIngreso));
       //valrectif.registrarDatado(declaracion, declaracionBD);
      //  orquestador.putAll(valrectif.Marcadesdatadodatado(declaracion,solicitudRectificacion,variablesIngreso));
        errores.add(valrectif.Estadoruc(declaracion)) ;
   	    errores.add(valrectif.Cambiomodalidad(declaracion));
   	    //orquestador.putAll(valrectif.Calcadeudo(declaracion, "1000000010102", "us01", "42132", "xxxx"));
   	//orquestador.putAll(deudadiferencial());
   	 Map<String,Object> deudadiferencial=(Map<String,Object>)orquestador.get("deudadiferencial");
   	  //errores.addAll(valrectif.Infoautoliquidacion(declaracion, deudadiferencial,variablesIngreso));
   	//valrectif.probarDaoInterno();
   	//errores.add(valrectif.Imputacion(declaracionBD, deudadiferencial));
   	errores.add(valrectif.Sustento(declaracion));
   	//errores.addAll(valrectif.Afectaart15lgaAnticipado(declaracionBD));
   	orquestador.putAll(valrectif.Solirectiprevia(declaracion,variablesIngreso));
  /* 	errores.addAll(valrectif.Grabacabydetsolicitud(declaracion, declaracionBD, solicitudRectificacion, true));
   	errores.addAll(valrectif.Grabatablanegocio(declaracionBD, solicitudRectificacion));
   	    pintarRectificacioneOfico(rectificacionesOficio);*/
/*   	     pintarRectificacioneDeclaracion(solicitudRectificacion.getListaCambios());
       //errores.addAll(valrectif.validarDesDatado(declaracion, declaracionBD));
   	  pintarerroes(errores);
       
   	GrabarRectificacionService grabar=(GrabarRectificacionService)context.getBean("GrabarRectificacionServiceImpl");
   	grabar.grabarRectificacion(declaracion, solicitudRectificacion, deudadiferencial,variablesIngreso);
*/   
       
	}
	
	
	
	public static Declaracion obtenerDeclaracion() throws Exception{
	       Declaracion declaracion=new Declaracion();
	       declaracion.setNumdeclRef(new NumdeclRef());
	       declaracion.getNumdeclRef().setAnnprese("2009");
	       declaracion.getNumdeclRef().setCodaduana("118");
	       declaracion.getNumdeclRef().setCodregimen("10");
	       declaracion.getNumdeclRef().setNumcorre("1348");
	       declaracion.setDua(new DUA());
	       
	       declaracion.getDua().setAnnpresen(2009);
	       declaracion.getDua().setCodaduanaorden("118");
	       declaracion.getDua().setCodregimen("10");
	       //declaracion.getDua().setCodtipotratamiento("X"); // ATRIBUTO RECTIFICADO
	       declaracion.getDua().setCodmodalidad("04"); // ATRIBUTO MODIFICADO
	       declaracion.setCodtipotrans("1003");
	       declaracion.getDua().setCodlugarecepcion("04");
	       declaracion.getDua().setNumdocumento("1042132573");
	       declaracion.getDua().setCodtipooper("4");
	       declaracion.getDua().setCodanexo("9998");
	       declaracion.getDua().setMtotfobclvta(new BigDecimal(100.10));
	       declaracion.getDua().setCodflete("200"); // ATRIBUTO NUEVO
	       declaracion.getDua().setMtotflecomex(new BigDecimal(100.10));
	       declaracion.getDua().setMtotajustes(new BigDecimal(100.10));
	       declaracion.getDua().setMtotsegotros(new BigDecimal(100.10));
	       declaracion.getDua().setCnttpesobruto(new BigDecimal(120)); // MODIFICADO
	       declaracion.getDua().setCnttpesoneto(new BigDecimal(120));
	       declaracion.getDua().setCnttcantbulto(new BigDecimal(120));
	       
	       Participante declarante=new Participante();
	       declarante.setNumeroDocumentoIdentidad("20338598301");
	       DataCatalogo tipodoc=new DataCatalogo();
	       tipodoc.setCodDatacat("4");
	       declarante.setTipoDocumentoIdentidad(tipodoc);
	       declaracion.getDua().setDeclarante(declarante);
	       
	       declaracion.getDua().setListSeries(new Elementos<DatoSerie>());
	       declaracion.getDua().getListSeries().add(new DatoSerie()) ;
	       declaracion.getDua().getListSeries().get(0).setNumserie(1); // modificado
	       declaracion.getDua().getListSeries().get(0).setCntbultos(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(0).setMtofobdol(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(0).setMtofledol(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(0).setCodtratprefe(196);
	       declaracion.getDua().getListSeries().get(0).setCodpaisorige("JP");
	       declaracion.getDua().getListSeries().get(0).setCntbultos(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(0).setCntpesobruto(new BigDecimal(100.10));
	       

	       
	       declaracion.getDua().getListSeries().get(0).setListSerieDocSoporte(new Elementos<DatoSerieDocSoporte>());
	       DatoSerieDocSoporte dsd= new DatoSerieDocSoporte();
	       declaracion.getDua().getListSeries().get(0).getListSerieDocSoporte().add(dsd);
	       dsd.setCodtipodocsoporte("3");
	       dsd.setNumiddocsoporte(1);

	       
	       DatoDocTransporte ddt=new DatoDocTransporte();
	       ddt.setNumdoctransporte("QUA005950");
	       //ddt.setFecembarque(DateUtil.stringToDate("17/12/2001 09:30:47"));
	       ddt.setFecembarque(new Date("12/17/2001 09:30:47"));
	       ddt.setNumsecdoctrans(1);
	       ddt.setCodpuerto("USMIA");
	       
	       declaracion.getDua().getListSeries().add(new DatoSerie()) ;
	       declaracion.getDua().getListSeries().get(1).setNumserie(3); // nuevo
	       declaracion.getDua().getListSeries().get(1).setCntbultos(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(1).setMtofobdol(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(1).setMtofledol(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(1).setCodtratprefe(196);
	       declaracion.getDua().getListSeries().get(1).setCodpaisorige("JP");
	       declaracion.getDua().getListSeries().get(1).setCntbultos(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(1).setCntpesobruto(new BigDecimal(100.10));
	       
	       
	       declaracion.getDua().setListDocTransporte(new Elementos<DatoDocTransporte>());
	       declaracion.getDua().getListDocTransporte().add(ddt);

	       DatoManifiesto manif=new DatoManifiesto();
	       declaracion.getDua().setManifiesto(manif);
	       manif.setAnnmanif("2009");
	       manif.setNummanif("100349");
	       manif.setCodaduamanif("118");
	       manif.setCodtipomanif("01");
	       manif.setCodmodtransp("1");
	       manif.setFectermino(DateUtil.stringToDate("20/09/2009"));
	       manif.setEmpTransporte(new Participante());
	       manif.getEmpTransporte().setCodigoBasc("20100010136");
	       
	       DatoPago dp=new DatoPago();
	       DatoPagoDecla pagoDeclaracion=new DatoPagoDecla();
	       DatoPagoTrans pagotrans=new DatoPagoTrans();
	       dp.setPagoDeclaracion(pagoDeclaracion);
	       pagotrans.setFeccarcr(DateUtil.stringToDate("20/09/2009"));
	       dp.setPagoTransaccion(pagotrans);
	       declaracion.getDua().setPago(dp);
	       manif.setFectermino(DateUtil.stringToDate("20/09/2009"));
	       
	       DatoProducto producto = new DatoProducto();
	       producto.setCodpantidum("10");
	       declaracion.getDua().getListSeries().get(0).setProducto(producto);
	       
	        Elementos<DatoOtroDocSoporte> listOtrosDocSoporte=new Elementos<DatoOtroDocSoporte>();
	        DatoOtroDocSoporte soporte=new DatoOtroDocSoporte();
	        soporte.setCodtipoproceso("9");
	        soporte.setAnndocasoc("2009");
	        soporte.setNumdocasoc("000553");
	        listOtrosDocSoporte.add(soporte);
	        declaracion.getDua().setListOtrosDocSoporte(listOtrosDocSoporte);
	       
	        declaracion.setListDAVs(new Elementos<DAV>());
	        DAV dav=null;
	        DatoFactura factu=null;
	        dav=new DAV();
	        dav.setNumsecuprov(1);
	        dav.setCntfacturas(40);
	        dav.setIndexisinter("20");
	        dav.setListFacturas(new Elementos<DatoFactura>());
	        factu=new DatoFactura();
	        factu.setNumsecfactu(8010);
	        factu.setNumfactura("8010");
	        factu.setMtofactufob(new BigDecimal(40));
	        factu.setCodtipocomprobante("N");
	        dav.getListFacturas().add(factu);
	        declaracion.getListDAVs().add(dav);

	        factu=new DatoFactura();
	        factu.setNumsecfactu(8030);
	        factu.setNumfactura("8030");
	        factu.setMtofactufob(new BigDecimal(40));
	        dav.getListFacturas().add(factu);
	        declaracion.getListDAVs().add(dav);
	        
	        
	        dav=new DAV();
	        dav.setNumsecuprov(2);
	        dav.setCntfacturas(40);
	        dav.setIndexisinter("30");
	        dav.setListFacturas(new Elementos<DatoFactura>());
	        factu=new DatoFactura();
	        factu.setNumsecfactu(8010);
	        factu.setNumfactura("8010");
	        factu.setMtofactufob(new BigDecimal(40));
	        dav.getListFacturas().add(factu);
	        
	        declaracion.getListDAVs().add(dav);
	        
	        
	        
	       return declaracion;
		
	}
	
	public static Declaracion obtenerDeclaracionBD() throws Exception{
		
	       Declaracion declaracion=new Declaracion();
	       declaracion.setDua(new DUA());
	       declaracion.getDua().setNumcorredoc(40551L);
	       declaracion.getDua().setFecregulariza(DateUtil.stringToDate("01/01/0001"));
	       declaracion.getDua().setFecdeclaracion(DateUtil.stringToDate("01/01/2008"));
	       DatoManifiesto manif=new DatoManifiesto();
	       declaracion.getDua().setManifiesto(manif);
	       manif.setAnnmanif("2009");
	       manif.setNummanif("100349");
	       manif.setCodaduamanif("118");
	       manif.setCodtipomanif("01");
	       manif.setCodmodtransp("1");
	       manif.setFectermino(DateUtil.stringToDate("22/11/2009"));
	       declaracion.getDua().setCodmodalidad("02");
	       declaracion.getDua().setCodtipotratamiento("20"); // ATRIBUTO ELIMINADO
	       declaracion.getDua().setCnttpesobruto(new BigDecimal(100));
	       
	       declaracion.getDua().setListSeries(new Elementos<DatoSerie>());
	       declaracion.getDua().getListSeries().add(new DatoSerie()) ;
	       declaracion.getDua().getListSeries().get(0).setNumserie(1); // modificado
	       declaracion.getDua().getListSeries().get(0).setCntbultos(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(0).setMtofobdol(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(0).setMtofledol(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(0).setCodtratprefe(196);
	       declaracion.getDua().getListSeries().get(0).setCodestamerca("MERCA"); // ATRIBUTO NUEEVO
	       //declaracion.getDua().getListSeries().get(0).setCodpaisorige("JP");  // ATRIBUTO ELIMINADO
	       declaracion.getDua().getListSeries().get(0).setCntbultos(new BigDecimal(50.5)); // ATRIBUTO RECTIFICADO
	       declaracion.getDua().getListSeries().get(0).setCntpesobruto(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().add(new DatoSerie()) ;
	       declaracion.getDua().getListSeries().get(1).setNumserie(2); // eliminado
	       declaracion.getDua().getListSeries().get(1).setCntbultos(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(1).setMtofobdol(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(1).setMtofledol(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(1).setCodtratprefe(196);
	       declaracion.getDua().getListSeries().get(1).setCodpaisorige("JP");
	       declaracion.getDua().getListSeries().get(1).setCntbultos(new BigDecimal(100.10));
	       declaracion.getDua().getListSeries().get(1).setCntpesobruto(new BigDecimal(100.10));
	       

	        declaracion.setListDAVs(new Elementos<DAV>());
	        DAV dav=null;
	        DatoFactura factu=null;
	        dav=new DAV();
	        dav.setNumsecuprov(1);
	        dav.setCntfacturas(40);
	        dav.setIndexisinter("30");
	        dav.setListFacturas(new Elementos<DatoFactura>());
	        factu=new DatoFactura();
	        factu.setNumsecfactu(8010);
	        factu.setNumfactura("8010");
	        factu.setMtofactufob(new BigDecimal(40));
	        factu.setCodtipocomprobante("S");
	        dav.getListFacturas().add(factu);
	        factu=new DatoFactura();
	        factu.setNumsecfactu(8020);
	        factu.setNumfactura("8020");
	        factu.setMtofactufob(new BigDecimal(40));
	        dav.getListFacturas().add(factu);
	        
	        declaracion.getListDAVs().add(dav);
	        
	        dav=new DAV();
	        dav.setNumsecuprov(3);
	        dav.setCntfacturas(40);
	        dav.setIndexisinter("30");
	        dav.setListFacturas(new Elementos<DatoFactura>());
	        factu=new DatoFactura();
	        factu.setNumsecfactu(8010);	        
	        factu.setNumfactura("8010");
	        factu.setMtofactufob(new BigDecimal(40));
	        dav.getListFacturas().add(factu);
	        
	        declaracion.getListDAVs().add(dav);
	       
	       
	       return declaracion;

		
	}
	
	public static void pintarRectificacioneOfico(List<DetSolicitudRectificacionBean> rectificacionesOficio){
		System.out.println("MOSTRANDO RECTIFICACIONES DE OFICIO .....");
		if(!CollectionUtils.isEmpty(rectificacionesOficio)){
			for(DetSolicitudRectificacionBean detsol:rectificacionesOficio){
				System.out.println("tabla "+detsol.getCodtabla());
				System.out.println("key "+detsol.getKey());
				System.out.println("data  "+detsol.getDatosRectificados());
			}
			
		}
	}
	
	public static void pintarRectificacioneDeclaracion(List<DetSolicitudRectificacionBean> rectificacionesOficio){
		System.out.println("MOSTRANDO RECTIFICACIONES DE DECLARACION .....");
		if(!CollectionUtils.isEmpty(rectificacionesOficio)){
			for(DetSolicitudRectificacionBean detsol:rectificacionesOficio){
				System.out.println(" ");
				System.out.println(" ");
				System.out.println("--------------------NUEVA TABLA---------------------------");
				System.out.println("tabla "+detsol.getCodtabla());
				System.out.println("---------------------"+"TIPO REGISTRO "+detsol.getTipoCambio()+"---------------------");
				System.out.println("key "+detsol.getKey());
				//System.out.println("data  "+detsol.getDatosRectificados());
				for(String campo: detsol.getDatosRectificados().keySet()){
					DatoRectificacionBean dr=(DatoRectificacionBean)detsol.getDatosRectificados().get(campo);
				    System.out.println("campo :" + campo);
				    System.out.println("dato nuevo :"+ dr.getDatoNuevo());
				    System.out.println("dato anterior :"+dr.getDatoAntiguo());
				    System.out.println("objetc path :"+dr.getObjectPath() );
				    System.out.println("tipo Rectificacion :"+dr.getTipoRectificacion() );
				}
			}
			
		}
	}	
	
	public static Map<String,BigDecimal> deudadiferencial(){
		Map<String,BigDecimal> deuda =new HashMap<String,BigDecimal>();
		return deuda;
	}
	
	public static void pintarerroes(List<Map<String,?>> error){
		
	    if(!CollectionUtils.isEmpty(error)){
		    for(Map<String,?> ee:error){
		    	System.out.println(ee);
		    }	
			
		}
		
	}
}
