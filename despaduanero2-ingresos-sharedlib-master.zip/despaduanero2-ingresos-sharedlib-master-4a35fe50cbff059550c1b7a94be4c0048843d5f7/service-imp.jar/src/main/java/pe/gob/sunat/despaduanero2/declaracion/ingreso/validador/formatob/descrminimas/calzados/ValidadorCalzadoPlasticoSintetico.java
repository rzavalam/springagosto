package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzados;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoPlasticoSintetico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
/**
 * 
 * @author lalberti
 *
 */

public class ValidadorCalzadoPlasticoSintetico extends ValidadorCalzadoAbstract
{

	private String CAUCHO = "CAU";
	private String PLASTICO = "PLA";
	private String SIN_CATALOGO = "1";
	private String SINTETICO = "CUS";
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

      if (CollectionUtils.isEmpty(lstErrores))
      {
          DatoItem item = obtenerItem(objeto,dua);
          lstErrores.addAll(validarUnidadComercial(objeto, item));
          lstErrores.addAll(validarNombreComercial(objeto, item,dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarModelo(objeto));
//          lstErrores.addAll(validarTallaCalzado(objeto));
          lstErrores.addAll(validarConstruccion(objeto));
          lstErrores.addAll(validarSumaPorcenComp(objeto));
      }

    return lstErrores;
  }
  
  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract object, DatoItem item, Date fechaVigencia){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	  CalzadoPlasticoSintetico calzado = (CalzadoPlasticoSintetico) object;
	  String datoAValidar = calzado.getMaterialParteSuperior().getValtipdescri();
	  lst.addAll(super.validarNombreComercial(object, item,fechaVigencia));	  
	  String primerCompo = calzado.getCompoMaterialSistentico1erComp()!= null?
			  calzado.getCompoMaterialSistentico1erComp().getValtipdescri():new String();
	  String segundoCompo = calzado.getCompoMaterialSistentico2doComp()!=null?
			 calzado.getCompoMaterialSistentico2doComp().getValtipdescri():new String();
	  if(SunatStringUtils.isEqualTo(CAUCHO,datoAValidar)){
		if(!(ArrayUtils.contains(new String[]{"CAN","CAS"}, primerCompo) ||
			ArrayUtils.contains(new String[]{"CAN","CAS"}, segundoCompo))){
			lst.add(obtenerError("31442",calzado.getMaterialParteSuperior()));
		}
	  }
	  Boolean otrosPrimCompo = SIN_CATALOGO.equals(calzado.getCompoMaterialSistentico1erComp().getCodtipvalor());
	  Boolean otrosSecCompo = calzado.getCompoMaterialSistentico2doComp() != null? 
			  				  SIN_CATALOGO.equals(calzado.getCompoMaterialSistentico2doComp().getCodtipvalor()):false;
	  if(SunatStringUtils.isEqualTo(PLASTICO,datoAValidar)){
		  Boolean inArrayPrimCompo = ArrayUtils.contains(new String[]{"EVA","PLT","POL","PVC"}, primerCompo);
		  Boolean inArraySecCompo = ArrayUtils.contains(new String[]{"EVA","PLT","POL","PVC"}, segundoCompo);
		  if(!(inArrayPrimCompo||inArraySecCompo||otrosPrimCompo||otrosSecCompo)){
			  lst.add(obtenerError("31443",calzado.getMaterialParteSuperior()));
		  }
	  }
	  if(SunatStringUtils.isEqualTo(SINTETICO,datoAValidar)){
		  Boolean inArrayPrimCompo = ArrayUtils.contains(new String[]{"PLT","POL","PVC"}, primerCompo);
		  Boolean inArraySecCompo = ArrayUtils.contains(new String[]{"PLT","POL","PVC"}, segundoCompo);
		  if(!(inArrayPrimCompo||inArraySecCompo||otrosPrimCompo||otrosSecCompo)){
			  Object[] argumentos = new Object[] {SINTETICO};
			  lst.add(obtenerError("31444",calzado.getMaterialParteSuperior(), argumentos));
		  }
	  }
	  return lst;
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialSintetico1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialsinteticoPorcen1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialSintetico2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialSinteticoPorcen2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialSintetico3erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarCompoMaterialSinteticoPorcen3erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarSumaPorcenComp(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    CalzadoPlasticoSintetico calzado = (CalzadoPlasticoSintetico) object;
    Integer p1 = 0;
    Integer p2 = 0;
    Integer p3 = 0;
    try{//se corrige la marcianada de try catch PAS20165E220200137
        p1 = calzado.getCompoMaterialSistentico1erComp()!= null &&  
        		!SunatStringUtils.isEmptyTrim(calzado.getCompoMaterialSistenticoPorcen1erComp().getValtipdescri())?
        	             Integer.parseInt(calzado.getCompoMaterialSistenticoPorcen1erComp().getValtipdescri()):0; 
        p2 = calzado.getCompoMaterialSistentico2doComp()!= null &&  
        		!SunatStringUtils.isEmptyTrim(calzado.getCompoMaterialSistenticoPorcen2doComp().getValtipdescri())?
             Integer.parseInt(calzado.getCompoMaterialSistenticoPorcen2doComp().getValtipdescri()):0;
        p3 = calzado.getCompoMaterialSistentico3erComp()!= null &&
        		!SunatStringUtils.isEmptyTrim(calzado.getCompoMaterialSistenticoPorcen3erComp().getValtipdescri())?
                Integer.parseInt(calzado.getCompoMaterialSistenticoPorcen3erComp().getValtipdescri()):0;
      }catch(NumberFormatException e){}
      if((p1 + p2 + p3) != 100){
    	DatoDescrMinima sum = calzado.getCompoMaterialSistenticoPorcen1erComp();
    	sum.setValtipdescri(String.valueOf(p1 + p2 + p3));
        lst.add(obtenerError("31400",sum));
      }
    return lst;
  }
  
}
