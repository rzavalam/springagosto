package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.localanexo;

public class ValidadorLocalAnexoException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2745223256676001949L;

	private String codigoError = null;
	
	private String[] argumentos = new String[]{""};
	
	
	public ValidadorLocalAnexoException(){
		super();
	}
	
	public ValidadorLocalAnexoException(String codigoError){
		super(codigoError);
		this.codigoError = codigoError;
	}
	
	public ValidadorLocalAnexoException(String codigoError, String message) {
		super(codigoError + ":" + message);
		this.codigoError = codigoError;
	}
	
	public ValidadorLocalAnexoException(String codigoError, String[] argumentos) {
		super(codigoError + ": ");
		this.codigoError = codigoError;
		this.argumentos = argumentos;
	}
	
	public ValidadorLocalAnexoException(String codigoError, String[] argumentos, String message) {
		super(codigoError +": "+ message);
		this.codigoError = codigoError;
		this.argumentos = argumentos;
	}

	public ValidadorLocalAnexoException(String codigoError, Throwable paramThrowable) {
		super(paramThrowable);
		this.codigoError = codigoError;
	}

	public ValidadorLocalAnexoException(Throwable paramThrowable) {
		super(paramThrowable);
	}

	public String getCodigoError() {
		return codigoError;
	}
	
	public String[] getArgumentos() {
		return argumentos;
	}

}
