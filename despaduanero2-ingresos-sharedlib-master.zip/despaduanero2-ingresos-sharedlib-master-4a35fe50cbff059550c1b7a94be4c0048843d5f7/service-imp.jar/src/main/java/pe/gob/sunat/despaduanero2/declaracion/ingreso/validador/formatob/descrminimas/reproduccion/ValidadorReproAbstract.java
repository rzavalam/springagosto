package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.reproduccion;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;


/**
 * La Class ValidadorDescrMinimaReproduccion.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class ValidadorReproAbstract extends ValidadorAbstract
{
  public static final String UNIDAD = "U";
  public static final String COD_ASOC_CATA = "018";

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception {
    return null;
  }

  public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract objeto, Declaracion dua)
  {
    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
    DatoItem item = obtenerItem(objeto, dua);

    if(objeto instanceof ReproAbstract)
    {
      ReproAbstract reproduccion = (ReproAbstract) objeto;
      String datoAValidar = item.getCodunidcomer().trim();

      if(!UNIDAD.equals(datoAValidar))
      {
        Object[] demasArgumentosMSJError = new Object[] { reproduccion.getNumsecprove(),reproduccion.getNumsecfact(),
        		reproduccion.getNumsecitem(),"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
      	        ErrorDescrMinima error = obtenerError("31702",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
      	        errorLst.add(error);
      }
    }
    return errorLst;
  }

  public List<ErrorDescrMinima>  validarNombreComercial (ModelAbstract objeto, Declaracion dua)
  {
    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
    DatoItem item = obtenerItem(objeto, dua);

    if(objeto instanceof ReproAbstract)
    {
      ReproAbstract reproduccion = (ReproAbstract) objeto;
      String datoAValidar = reproduccion.getNombreComercial().getValtipdescri().trim();
      String subPartida = item.getNumpartnandi().toString();

      if(noEstaCorrelacionado(datoAValidar, subPartida, COD_ASOC_CATA, dua.getDua().getFecdeclaracion()))
      {
        Object[] demasArgumentosMSJError = new Object[] { subPartida };
        ErrorDescrMinima error = obtenerError("31703", reproduccion.getNombreComercial(), demasArgumentosMSJError );
        errorLst.add(error);

      }
    }
    return errorLst;
  }


  public List<ErrorDescrMinima>  validarMarcaComercial (ModelAbstract objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>  validarModelo (ModelAbstract objeto)
  {
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarDatosEnviadosCorrespondenAltipoDescrMinima(ModelAbstract objeto, Date fechaValidacion) throws Exception
  {
    List<ErrorDescrMinima> errorLst = new ArrayList<ErrorDescrMinima>();
    List<DatoDescrMinima> listaCodigosInvalidos = new ArrayList<DatoDescrMinima>();

    listaCodigosInvalidos = super.obtenerCodigodEnviadosNOCorrespondenTipoDescrMinima(objeto);

    for (DatoDescrMinima datoDescrMinima : listaCodigosInvalidos)
    {
      String codigoCampo = datoDescrMinima.getCodtipdescr()+" "+super.obtenerDescripcionDelCalogo("500",datoDescrMinima.getCodtipdescr(), fechaValidacion);
      String valorCampo = datoDescrMinima.getValtipdescri();
      String nombComercial =  datoDescrMinima.getValtipdescri() +"-"+super.obtenerDescripcionDelCalogo(datoDescrMinima.getValtipdescri(),datoDescrMinima.getPosicion().getCodigoCatalogoParaValidar(), fechaValidacion);

      Object[] demasArgumentosMSJError = new Object[] { codigoCampo, valorCampo, nombComercial };
      ErrorDescrMinima error = obtenerError("31812", datoDescrMinima, demasArgumentosMSJError );
      errorLst.add(error);
    }
    return errorLst;
  }
}



