package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzados;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoTextil;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * 
 * @author lalberti
 *
 */

public class ValidadorCalzadoTextil extends ValidadorCalzadoAbstract
{
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

      if (CollectionUtils.isEmpty(lstErrores))
      {
          DatoItem item = obtenerItem(objeto,dua);
          lstErrores.addAll(validarUnidadComercial(objeto, item));
          lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));
//          lstErrores.addAll(validarTallaCalzado(objeto));
//          lstErrores.addAll(validarPorcentajeTipoTejido(objeto));//arey se comenta por cierre vig del CA0305
          lstErrores.addAll(validarConstruccion(objeto));
      }

    return lstErrores;
  }
  
  public List<ErrorDescrMinima> validarMaterialSuperior(ModelAbstract object){    
    return new ArrayList<ErrorDescrMinima>();
  }
  public List<ErrorDescrMinima> validarTipoTejido(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarPorcentajeTipoTejido(ModelAbstract object){
	  List<ErrorDescrMinima> lst =  new ArrayList<ErrorDescrMinima>();
	  CalzadoTextil calzado = (CalzadoTextil) object;
	  if(!SunatStringUtils.isEmptyTrim(calzado.getCompoMaterialTejidoPorcen1erComp().getValtipdescri())){
		  lst.add(obtenerError("31403",calzado.getCompoMaterialTejidoPorcen1erComp()));
	  }
	  return lst;
  }
  
  public List<ErrorDescrMinima> validarComposicionTejido(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarporcentajeCompoTejido(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
}