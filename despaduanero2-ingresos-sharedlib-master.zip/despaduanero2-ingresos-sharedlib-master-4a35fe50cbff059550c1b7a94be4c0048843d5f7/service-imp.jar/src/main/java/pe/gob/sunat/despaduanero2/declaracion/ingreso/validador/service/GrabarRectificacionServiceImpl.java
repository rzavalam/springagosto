
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

// Inicio erodriguezb RIN10
import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_TIPOS_EXTINCION_DEUDA_ANULACION_LEGAJAMIENTO;

import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.TIENE_VALOR_PROVISIONAL;
import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.TIPO_PAGO_GARANTIA;
import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.COD_INDICADOR_VP;
import static pe.gob.sunat.despaduanero2.ayudas.util.Constantes.INACTIVO_TABLE_INDICADOR_DUA;
import static pe.gob.sunat.estrategico2.aduanero.vuce.util.Constantes.INDICADOR_CERT_ELECTRONICO; //PAS20181U220200056
import static pe.gob.sunat.despaduanero2.declaracion.ingreso.util.Constantes.TABLA_DESCRIP_OTROS;
import java.text.DecimalFormat;

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;

import java.util.Locale;

import pe.gob.sunat.recauda2.garantia.model.dao.MovNGarantiaDAO;





import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.sojo.common.ObjectUtil;
import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.di.model.dao.DipolizaiDAO;
import pe.gob.sunat.despaduanero2.asignacion.service.AsignacionAutomaticaService;
import pe.gob.sunat.despaduanero2.asignacion.util.ListaUtil;//RIN10
import pe.gob.sunat.despaduanero2.asignacion.util.TipoInvocacion;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.bean.DynamicSentenceBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DatoRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DetSolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.RecordBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certiorigen.CertiOrigenElectronicoService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes.GrabarContingentesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciarestringida.MercanciaRestringidaEntidadService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.operadoroea.GrabarRiesgoOeaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.valorprovisional.ValidadorValorProvisionalService;
import pe.gob.sunat.despaduanero2.declaracion.model.CabCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;//RIN10
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;//P28
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;//P28
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetCtacteRegimen;
import pe.gob.sunat.despaduanero2.declaracion.model.DetPagodua;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdiImpoConsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjAtpaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabAdjTransitoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabCertiOrigenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ComprobPagoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CondicionTransaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtpaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiAtreexDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAdiImpoconsuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetAutorizacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetCtacteRegimenDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetPagoDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocAutAsociadoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FactuSuceDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FacturaSerieDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FinUbicacionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBMontoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBProveedorDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DescripOtrosDAO; // GTP
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormaFactuDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ItemFacturaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MontoGastoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.PlazosProcesoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SeriesItemDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VFOBProvisionalDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.VehiCeticoDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionCuentaCorrienteService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.CabManifiestoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.EquipamientoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.MovEquipamientoDAO;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.PrecintoDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DetSolRectiDAO;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.despaduanero2.model.dao.RelacionDocDAO;
import pe.gob.sunat.despaduanero2.model.dao.DocumentoDAO;
import pe.gob.sunat.despaduanero2.model.dao.SolicitudDAO;
import pe.gob.sunat.despaduanero2.service.ParticipanteService;
import pe.gob.sunat.despaduanero2.util.ConstanteSecuencia;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.estrategico2.aduanero.vuce.model.acuerdo.DocCertificadoOrigen;
import pe.gob.sunat.framework.spring.util.conversion.SojoUtil;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.CabDocliq;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
import pe.gob.sunat.recauda2.genadeudo.model.dao.LiquidaDAO;
import pe.gob.sunat.recauda2.genadeudo.service.FuncionesLiquidacionService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionPecoAmazoniaService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
import pe.gob.sunat.servicio2.avisos.service.PublicacionAvisoService;
import pe.gob.sunat.servicio2.registro.service.DdpDAOService;
import pe.gob.sunat.sigad.ingreso.service.ControlarSaldoReposicionService;//P28
import pe.gob.sunat.tecnologia.receptor.bean.EnvioBean;
import pe.gob.sunat.tecnologia.receptor.model.Documento;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioDAO;
import pe.gob.sunat.tecnologia2.auditoria.util.holder.UserNameHolder;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SerieService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;//RIN10

//PAS20175E220200077 - mtorralba 20170623
import pe.gob.sunat.despaduanero2.declaracion.model.CabDeuda;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeudaDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.ErroresOraService;

@SuppressWarnings("unchecked")
public class GrabarRectificacionServiceImpl extends ValDuaAbstract implements GrabarRectificacionService {

	//private CatalogoAyudaService catalogoayudaservice;
	//private LiquidaDeclaracionService liquidaDeclaracionService;	
	//private GrabarDeclaracionService grabarDeclaracionService;
	//private PlazosProcesoDAO plazosprocesodao;
	//private GrabarGeneralService grabarGeneralService;
	//private GeneraRespuestaService genRespuestaService;
	//EnvioDAO envioDAO;
	//private DetPagoDuaDAO detPagoduaDAO;
	//private DeudaDocumDAO deudaDocumDAO;
	//private EspeDocuDAO espeDocuDAO;
	//private CabAdjImpoconsuDAO cabAdjImpoconsuDAO;
	//private CabAdjAtpaDAO cabAdjAtpaDAO;

	//private CabDeclaraDAO cabDeclaraDAO ;
	//private IndicadorDUADAO indicadorDUADAO;
	//private FormBProveedorDAO formBProveedorDAO;
	//private CabAdjTransitoDAO cabAdjTransitoDAO;
	//private FinUbicacionDAO finUbicacionDAO;
	//private DetDeclaraDAO detDeclaraDAO;
	//private DetAdiImpoconsuDAO detAdiImpoconsuDAO;	
	//private DetAdiAtpaDAO detAdiAtpaDAO;
	//private DetAdiAtreexDAO detAdiAtreexDAO;	
	//private VehiCeticoDAO vehiCeticoDAO;
	//private MontoGastoDAO montoGastoDAO;
	//private DetAutorizacionDAO detAutorizacionDAO;
	//private FacturaSerieDAO facturaSerieDAO;
	//private DocAutAsociadoDAO docAutAsociadoDAO;
	//private FormaFactuDAO formaFactuDAO;
	//private DocuPreceDuaDAO docuPreceDuaDAO;
	//private CabCertiOrigenDAO cabCertiOrigenDAO;

	//private CondicionTransaDAO condicionTransaDAO;
	//private FactuSuceDAO factuSuceDAO;
	//private ItemFacturaDAO itemFacturaDAO;
	//private VFOBProvisionalDAO fobProvisionalDAO;
	//private FormBItemDescriDAO formBItemDescriDAO;
	//private ComprobPagoDAO comprobPagoDAO;
	//private SeriesItemDAO seriesItemDAO;
	//private FormBMontoDAO formBMontoDAO;
	/*Inicio ECC 11012011*/
	//private AsignacionAutomaticaService asignacionAutomaticaService;
	//private CabSolrectiDAO cabSolrectiDAO;
	/*Fin ECC 11012011*/
	//PAS20165E220200076 RSERRANO CONTINGENTE PARA LA RECTIFICACION
	//private GrabarContingentesService grabarContingentesService; 
	/* olunar - pase 479 */
	//protected final Log log = LogFactory.getLog(getClass());
	//private PublicacionAvisoService publicacionAvisoService;
	/* fin */	

	//private DdpDAOService ddpDAOService;
	//private FabricaDeServicios fabricaDeServicios; 

	/**
	 * Servicio general de grabado de rectificacions
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @param solicitudRectificacion objeto que representa la solicitud de rectificacion
	 * @param deudadiferencia Map que represental la deuda diferenciasles calculadas 
	 * @param variablesIngreso parametros de transaccion
	 * @author hosorio
	 * @return HashMap<String, Object>
	 */
	@ServicioAnnot(tipo="G",codServicio=3029, descServicio="servicio general de grabado")
	@ServInstDetAnnot(tipoRpta={1,1,1,1,1},nomAtr={"declaracion",
			"solicitudRectificacion","deudadiferencial","variablesIngreso","declaracionBD"})
	@OrquestaDespaAnnot(codServInstancia=3029,numSecEjec=359,nomClase="pe.gob.sunat.tecnologia.receptor.model.Mensaje")
	public Map<String, String> grabarRectificacion(Declaracion declaracion, SolicitudRectificacionBean 
			solicitudRectificacion,Map<String, Object> deudadiferencial,
			Map<String, Object> variablesIngreso, Declaracion declaracionBD ) throws Exception{
		GrabarGeneralService grabarGeneralService = (GrabarGeneralService)fabricaDeServicios.getService("GrabarGeneralService");
		if(UserNameHolder.get()==null) 
			UserNameHolder.set(Constants.NOMBRE_USUARIO_AUDITORIA_ORQUESTADOR);

		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		// RIN16
		//		String resultadoErrorGarantia=null;

		String numeroDocumentoIdentidadSender=(String)variablesIngreso.get("numeroDocumentoIdentidadSender");
		Boolean marcaDesdatadoDatado = variablesIngreso.containsKey("marcaDesdatadoDatado")?(Boolean)variablesIngreso.get("marcaDesdatadoDatado"):false;
		Boolean marcaRealizarDatado = variablesIngreso.containsKey("marcaRealizarDatado")? (Boolean)variablesIngreso.get("marcaRealizarDatado"):false;
		Boolean tieneSoliRecNoatendida = (Boolean)variablesIngreso.get("tieneSoliRecNoatendida");
		String IndAfectaDesafectaCtaCteVehiUsado = (String)variablesIngreso.get("IndAfectaDesafectaCtaCteVehiUsado");
		String tipoDesp=(String)variablesIngreso.get("tipoDesp");
		// RIN16
		// pase 42
		boolean esGarantiaRenovada = false; 
		//		Boolean afectargarantiaLC=(Boolean)variablesIngreso.get("marcaAfectarGarantiaLC");
		//		BigDecimal montoAfectar=(BigDecimal)variablesIngreso.get("montoAfectar");
		//		Boolean desafectarAfectarGarantia=(Boolean)variablesIngreso.get("marcaDesafectarAfectarGarantia");
		String afectaDesafectaRegPreDepo = (String) variablesIngreso.get("indAfectaDesafectaRegPreDepo");
		Map<String,Object> deudadiferencia=(Map<String,Object>)variablesIngreso.get("deudadiferencial");
		String codTransaccion=(String) variablesIngreso.get("codTransaccion");
		Boolean blGrabaRectiDefinitivo=false;

		// Inicio RIN10 3007 erodriguezb

		List<Map<String, String>> listaWarnings = new ArrayList<Map<String, String>>();

		String transmisionValorProvisional = variablesIngreso.containsKey("transmisionValorProvisional")?
				(String) variablesIngreso.get("transmisionValorProvisional"):null;
		// Fin RIN10 3007 erodriguezb

		// obtencion del canal
		Map<String, Object> params =new HashMap<String, Object>();
		params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
		//Map<String,Object> mapDua=   RectificacionServiceImpl.getInstance().getCabdeclaraDAO().findDuaByNumCorreDoc(params);
		Map<String,Object> mapDua=   ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDuaByNumCorreDoc(params);

		String codcanal=(String)mapDua.get("COD_CANAL");
		/*branch ingreso 2011-009 hosorio inicio 04/05/2011*/
		String tipoDocumentoIdentidadSender = (String) variablesIngreso .get("tipoDocumentoIdentidadSender");
		Date fechaConclusionDespa = (Date) variablesIngreso .get("fechaConclusionDespa");
		String numOrden=(String)variablesIngreso.get("numOrden");
		String codUsuario 		= (String) variablesIngreso.get("codUsuario");		
		Map<Object,Object> mapManifiesto=obtenerManifiesto(declaracion);
		// RIN16
		//		Date dtFecNumeracion=declaracion.getDua().getFecdeclaracion();
		Date dtFecLlegada=null;
		Date dtFecPrLlegada=null;
		// RIN16
		//		Date dtFecTerminoDescarga=null;
		Date dtFecLlegadaAux=null;
		// manifiesto
		if(mapManifiesto!=null){
			variablesIngreso.put("mapManifiesto", mapManifiesto); 
			dtFecLlegada=(Date)mapManifiesto.get("fechaEfectivaDeLlegada");
			dtFecPrLlegada=(Date)mapManifiesto.get("fechaProgramadaLlegada");
			// RIN16
			//	     dtFecTerminoDescarga=(Date)mapManifiesto.get("fechaTerminoDeDescarga");

			if(SunatDateUtils.sonIguales(dtFecLlegada, SunatDateUtils.getDefaultDate(), "COMPARA_SOLO_FECHA"))
				dtFecLlegadaAux=dtFecPrLlegada;
			else 
				dtFecLlegadaAux=dtFecLlegada;

		}// Si no tiene CAB MANIFIESTO
		else{
			dtFecLlegadaAux=declaracion.getDua().getManifiesto().getFectermino();
			//PAS20145E220000090 - MATC 20140617  INICIO
			if( dtFecLlegadaAux!=null && SunatDateUtils.sonIguales(dtFecLlegadaAux, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
				dtFecLlegadaAux = declaracion.getDua().getFecLlegada();
			}
			//PAS20145E220000090 - MATC 20140617  FINAL
		}


		/*branch ingreso 2011-009  hosorio fin 04/05/2011*/


		if(tieneSoliRecNoatendida!=null && tieneSoliRecNoatendida){
			anularSolicitudNoAtendida(declaracion);
		}
		// graba en la tabla temporal solrecti y detsolrecti
		if(codTransaccion.endsWith("05"))
			solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA);
		else{
			/*hosorio inicio 28/04/2011 */
			//Si la transmisi�n fue realizada ANTES de la asignaci�n del canal de control
			if(!StringUtils.hasText(codcanal)){
				//aceptando autom�ticamente la rectificaci�n, asign�ndole el estado de la rectificaci�n: �Aceptado autom�ticamente�.
				solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_RECTIFIC_ACEPTADO_AUTOMATICAMENTE);
				blGrabaRectiDefinitivo=true;
			}
			else{
				//cambio de roberto
				/* Otra casos donde puede ser donde es automatica */
				Boolean esCambioAnticipadoAExcepcional = (Boolean)variablesIngreso.get("esCambioAnticipadoAExcepcional");
				Boolean esIndicadorRegularizacion = (Boolean)variablesIngreso.get("esIndicadorRegularizacion");	      		
				Boolean esPuntoLlegadaDepositoTemporal = (Boolean)variablesIngreso.get("esPuntoLlegadaDepositoTemporal");
				Boolean soloRectificaIndicador = (Boolean)variablesIngreso.get("soloRectificaIndicador");
				if (esCambioAnticipadoAExcepcional!=null && esIndicadorRegularizacion!=null && esPuntoLlegadaDepositoTemporal !=null) {
					if ((esCambioAnticipadoAExcepcional && esPuntoLlegadaDepositoTemporal) ||soloRectificaIndicador ||(esIndicadorRegularizacion && esPuntoLlegadaDepositoTemporal)) {
						solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_RECTIFIC_ACEPTADO_AUTOMATICAMENTE);
						blGrabaRectiDefinitivo=true;
					} else {
						/**rtineo M_SNADE278 **/
						//si es cambio de anticipado a diferido solo canal verde es automatico, para todos los demas casos es automatica si es diferido
						Boolean isDAMRegistradaDiferidaSinIca = variablesIngreso.get("isDAMRegistradaDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMRegistradaDiferidaSinIca"):false;
						Boolean isDAMDiferidaSinIca = variablesIngreso.get("isDAMDiferidaSinIca")!=null?(Boolean)variablesIngreso.get("isDAMDiferidaSinIca"):false;
						//Boolean isRectiPermitidoAnticipadoADiferido = (Boolean)variablesIngreso.get("isRectiPermitidoAnticipadoADiferido");
						Boolean isRectificaSoloPuntoLlegada = this.validarSiRectificaSoloPuntoLlegada(solicitudRectificacion); 
						Boolean rectificaSoloModalidadAnticipadoADiferido = isRectificaSoloModalidadAnticipadoADiferido(esCambioAnticipadoAExcepcional,solicitudRectificacion);
						if((rectificaSoloModalidadAnticipadoADiferido && "V".equals(codcanal) && "2".equals(declaracionBD.getDua().getCodlugarecepcion())
								&& isDAMDiferidaSinIca) ||
								(isDAMRegistradaDiferidaSinIca && isRectificaSoloPuntoLlegada)){
							solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_RECTIFIC_ACEPTADO_AUTOMATICAMENTE);
							blGrabaRectiDefinitivo=true;
						/**rtineo M_SNADE278 **/
						}else{
						solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA);
						blGrabaRectiDefinitivo=false;
					}
					}
				} else {
					solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA);
					blGrabaRectiDefinitivo=false;
				}
				//cambio de roberto pase 105 			
			}


			Boolean blTieneDuaMedidaPreve=(Boolean)variablesIngreso.get("blDuaTieneMedPreveDua"); 
			Boolean blTieneManifiestoMedidaPreve=(Boolean)variablesIngreso.get("blTieneMedPreveManif");
			Boolean blTieneAvisoInspencion=(Boolean)variablesIngreso.get("blTieneAvisoInspencion");

			if( (blTieneDuaMedidaPreve!=null && blTieneDuaMedidaPreve.booleanValue()) 
					|| 
					(blTieneManifiestoMedidaPreve!=null && blTieneManifiestoMedidaPreve.booleanValue())
					|| 
					(blTieneAvisoInspencion!=null && blTieneAvisoInspencion.booleanValue())

					){
				// SE GRABA EN TEMPORAL
				blGrabaRectiDefinitivo=false;
				solicitudRectificacion.setCodestarecti(ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA);
			}
			/*hosorio fin 28/04/2011 */
		}

		solicitudRectificacion.setCodtransaccion(ConstantesDataCatalogo.TRANSACCION_RECTIFICACION);
		this.Grabacabydetsolicitud(declaracion,  solicitudRectificacion,ConstantesDataCatalogo.TIPO_SOLICITUD_RECTIFICACION,
				blGrabaRectiDefinitivo?Constants.EST_SOLICITUD_CONCLUIDO:Constants.EST_SOLICITUD_INICIADO);





		//si no tiene canal  se graba en tablas de negocio
		/*hosorio inicio 28/04/2011*/
		/*		if(!StringUtils.hasText(codcanal)){
				blGrabaRectiDefinitivo=true;
			}
		 */		
		/*hosorio fin 28/04/2011*/			
		if(blGrabaRectiDefinitivo){ // SI NO TIENE CANAL ES DEFINITIVO
			GrabarDeclaracionService grabarDeclaracionService = (GrabarDeclaracionService)fabricaDeServicios.getService("grabarDeclaracionService");
			this.grabaTablaNegocio(declaracion, solicitudRectificacion, codTransaccion);	

			//PAS20171U220200005 - colocar el nro de envio parcial
			grabarNroEnvioParcialMercanciaVigente(declaracion, solicitudRectificacion.getListaCambios());
			
			if(IndAfectaDesafectaCtaCteVehiUsado!=null){ // Si no esta vacio , toma los valores A:afecta ,D:Desafecta
				grabarDeclaracionService.afectarCtaCteVehiculosUsados(declaracion, IndAfectaDesafectaCtaCteVehiUsado);
			}

			if(afectaDesafectaRegPreDepo!=null){ // A: afecta , D:Desafecta
				grabarDeclaracionService.afectarCtaCteRegPrecedeDeposito(declaracion, 
						afectaDesafectaRegPreDepo,  numeroDocumentoIdentidadSender);
			}
			
			//RIN25: ATRG201802: PAS20181U220200022 OEA
			//int nroErrores = variablesIngreso.get("nroErrores")== null ? 0 : (Integer)variablesIngreso.get("nroErrores");
			GrabarFormatoAService grabarFormatoAService = (GrabarFormatoAService)fabricaDeServicios.getService("grabarFormatoAService");
			grabarFormatoAService.grabarIndicadorImportadorFrecuente(declaracion, ConstantesDataCatalogo.TRANSACCION_RECTIFICACION);
			
			// SE GENERA LA LIQUIDACION
			Map<String,Object> mapRetornoLiqui=null;
			if(!"70".equals(declaracion.getDua().getCodregimen()))
				mapRetornoLiqui= Grabadocadeudo(declaracion, deudadiferencia,variablesIngreso);

			/*hosorio inicicio 15/05/2011*/
			if (mapRetornoLiqui!=null && "OK".equals(mapRetornoLiqui.get("GRABACION"))) {
				variablesIngreso.put("RESULTADO_LIQ", mapRetornoLiqui);
				if ("10".equals(declaracion.getDua().getCodregimen())) {
					LiquidaDeclaracionService liquidaDeclaracionService = (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
					liquidaDeclaracionService.grabaTrama(variablesIngreso);
				}
				//inicio pase 42
				//PAS20165E220200127
				boolean existeIncidenciaTributariaMayor=false;
				esGarantiaRenovada = mapRetornoLiqui.get("GARANTIA_RENOVADA") != null ? (Boolean)mapRetornoLiqui.get("GARANTIA_RENOVADA") : false;
				DeudaDocum tmpDeudaDocum = new DeudaDocum();
				tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
				ValidaAnexoDeclaracionService validaAnexoDeclaracionService = (ValidaAnexoDeclaracionService)fabricaDeServicios.getService("validaAnexoDeclaracion");
				List<DeudaDocum> listaDeudaDocum=((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
				existeIncidenciaTributariaMayor=validaAnexoDeclaracionService.existeIncidencia( deudadiferencial,listaDeudaDocum);
				variablesIngreso.put("esCuentaCorrienteRectificada", mapRetornoLiqui.get("esCuentaCorrienteRectificada") != null ? (Boolean)mapRetornoLiqui.get("esCuentaCorrienteRectificada") : false );
				variablesIngreso.put("ctacteAnterior", mapRetornoLiqui.get("ctacteAnterior") != null ? mapRetornoLiqui.get("ctacteAnterior").toString():"" );//pase27 MOL
				if (!(existeIncidenciaTributariaMayor && esGarantiaRenovada)) {
					grabarGeneralService.afectaGarantia(declaracion, numeroDocumentoIdentidadSender, tipoDocumentoIdentidadSender, numOrden, codUsuario, "", tipoDesp, fechaConclusionDespa, variablesIngreso);
				}
				//Fin PAS20165E220200127
				//fin pase 42
			}			


			/***** GGRANADOS RIN16PASE3 INI *****/
			DeclaracionService declaracionService =  (DeclaracionService)fabricaDeServicios.getService("declaracion.diligencia.ingreso.declaracionService");
			Map<String, Object> datosCambioModalidad = declaracionService.getDatosParaEvaluarCambioModalidad(declaracion, declaracionBD);

			String cambiaModalidad = declaracionService.procesarCambioModalidadRegularizacion(
					(String)datosCambioModalidad.get("codModalidad"),
					(String)datosCambioModalidad.get("codModalidadActual"),
					(Boolean)datosCambioModalidad.get("tieneIndicadorRegularizable"),
					(Boolean)datosCambioModalidad.get("tieneIndicadorRegularizableActual"));

			if(cambiaModalidad.equals(pe.gob.sunat.despaduanero2.ayudas.util.Constantes.CAMBIA_A_REGULARIZABLE)){
				//Verificar si va
				declaracionService.actualizarDatosRegularizacion(declaracion.getDua());
			}else if(cambiaModalidad.equals(pe.gob.sunat.despaduanero2.ayudas.util.Constantes.CAMBIA_A_NO_REGULARIZABLE)){
				declaracionService.limpiarDatosRegularizacion(declaracion.getDua().getNumcorredoc());
			}
			/***** GGRANADOS RIN16PASE3 FIN *****/	

			actualizacionSaldoFranquicia(declaracion, declaracionBD, codTransaccion,blGrabaRectiDefinitivo);

			if ("SI".equals(transmisionValorProvisional)) {
				listaWarnings = grabarRectificacionVPSinCanal(declaracion, declaracionBD, variablesIngreso);
			}
			actualizarCtaCteRegimen(declaracion, declaracion.getDua().getNumcorredoc());
			actualizarIndicadoresPreferencia(declaracion);
			
			//Verifica si le corresponde mandato electronico y de ser asi registra el indicador del mismo.
			grabarMandatoElectronico(declaracion.getDua(), variablesIngreso);

			//verificar para ciertos casos
			 // PASE PAS20181U220200016
			String codRiesgoOeaArm= declaracion.getDua().getCodRiesgoOea()!=null?declaracion.getDua().getCodRiesgoOea().toString():"00";
			
			if(!SunatStringUtils.isEmptyTrim(codRiesgoOeaArm)){
				CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
				Map<String,Object> mapUpdate=new HashMap<String, Object>();
				mapUpdate.put("COD_RIESGOOEA",  codRiesgoOeaArm);
				mapUpdate.put("NUM_CORREDOC",  declaracion.getNumeroCorrelativo());
				
				cabDeclaraDAO.update(mapUpdate);
			}
		}

		//PAS20165E220200076 RSERRANO CONTINGENTE PARA LA RECTIFICACION
		// Se debe verificar si es definitivo o temporal AFECTA Y DESAFECTA
		GrabarContingentesService grabarContingentesService = (GrabarContingentesService)fabricaDeServicios.getService("declaracion.grabarContingentesService");
		grabarContingentesService.procesarContingenteDiligencia(declaracion, variablesIngreso, blGrabaRectiDefinitivo);
		//PAS20165E220200076 RSERRANO CONTINGENTE PARA LA RECTIFICACION

		/*Se verifica si tiene la marca de desdatadodatado =true*/
		//Por Modificaci�n de Bultos y/o Pesos
		if(blGrabaRectiDefinitivo){// SI NO TIENE CANAL ES DEFINITIVO
			// RIN16
			//			Map resultDatado= new HashMap();
			if(marcaDesdatadoDatado){
				// Al desdatado se va con la Declaracion anterior
				//			grabarGeneralService.registrarDesdatado(declaracionBD,codTransaccion, variablesIngreso);
				// El desdatado lo hara el servicio de registro de datado de ser necesario
				// RIN16
				grabarGeneralService.registrarDatado(declaracion,Constants.COD_DATADO_RECTIFICACION,codTransaccion, variablesIngreso);
				//Si el datado devuelve un Error lanzaremos una e
			} else if(marcaRealizarDatado){ /*Se verifica si existe marca para datado =true*/
				//Por Incorporaci�n de Manifiesto	
				// RIN16
				grabarGeneralService.registrarDatado(declaracion,Constants.COD_DATADO_RECTIFICACION,codTransaccion, variablesIngreso);
			}

			declaracion.getDua().getManifiesto().setFectermino(SunatDateUtils.getDefaultDate());
			if(mapManifiesto != null && mapManifiesto.get("fechaTerminoDeDescarga") != null){
				declaracion.getDua().getManifiesto().setFectermino((Date)mapManifiesto.get("fechaTerminoDeDescarga"));
			}

			//			declaracion.getDua().getManifiesto().setFectermino((Date)mapManifiesto.get("fechaTerminoDeDescarga"));
			grabarGeneralService.grabaFechaVencRegularizacion(declaracion.getDua());
			//Si el servicio de datado devuelve algun error lanzamos una excepcion
			//			if (!resultDatado.isEmpty()){
			//				throw new Exception(resultDatado.get("desError").toString());
			//			}					
		}

		if(!blGrabaRectiDefinitivo)
		{
			actualizacionSaldoFranquicia(declaracion, declaracionBD, codTransaccion, blGrabaRectiDefinitivo);
		}

		if(!blGrabaRectiDefinitivo){
			/* Inicio RIN10 3007 erodriguezb */
			if ("SI".equals(transmisionValorProvisional)) {
				listaWarnings = grabarRectificacionVPConCanal(declaracion, declaracionBD, variablesIngreso);
			}
			/* Fin RIN10 3007 erodriguezb */
			try{

				//RSERRANOV PAS20165E220200124 Contingentes
				if (contingente(declaracion, declaracionBD,solicitudRectificacion) ) {
					AsignacionAutomaticaService asignacionAutomaticaService = (AsignacionAutomaticaService)fabricaDeServicios.getService("asignacion.service.asignacionAutomatica");
					asignacionAutomaticaService.asignaEspeSolRecticacion(solicitudRectificacion.getNumcorredoc(), TipoInvocacion.AUTOMATICA);
				}



			}catch(Exception e)
			{
				log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir la rectificaci�n
			}
		}

		/*hosorio inicio 13/06/2011*/
		if (solicitudRectificacion.getCodestarecti().equals(ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA))
		{
			variablesIngreso.put("codEstadoRecti", ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA); 
			//resultadoError=ResponseMapManager.getWarningResponseMap("09103", "LA SOLICITUD DE RECTIFICACION SE ENCUENTRA COMO PENDIENTE DE EVALUACION Y SERA EVALUADA POR UN FUNCIONARIO ADUANERO"); 	            	
		}
		/*hosorio inicio 13/06/2011*/


		Integer annEnvio 		= (Integer) variablesIngreso.get("annEnvio");
		Long numEnvio 			= (Long) variablesIngreso.get("numEnvio");
		actualizarEnvio(annEnvio, numEnvio, solicitudRectificacion.getNumcorredoc());

		CatalogoAyudaService catalogoayudaservice = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(variablesIngreso.containsKey("cambiarFechaFinValorProvisional"))
			listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_CAMB_FEC, 
					new String[] {SunatDateUtils.getFormatDate((Date) variablesIngreso.get("cambiarFechaFinValorProvisional"),"dd/MM/yyyy")}));//RIN10

		variablesIngreso.put("listaWarnings", listaWarnings);
		/* Inicio erodriguezb RIN10 */
		variablesIngreso.put("numCorreDocSolicitud", solicitudRectificacion.getNumcorredoc());
		GeneraRespuestaService genRespuestaService = (GeneraRespuestaService)fabricaDeServicios.getService("GenRespuestaServiceImpl");
		genRespuestaService.generaRespuestaEnvio(0, variablesIngreso);

		/* olunar 473 - Env�o de Notificaciones */
		// Si no hay errores
		if (CollectionUtils.isEmpty(resultadoError)){
			try{
				grabarNotificacionesRectificacion (declaracion, solicitudRectificacion, variablesIngreso);
			}catch(Exception e)
			{
				log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir la rectificaci�n
			}
		}
		/* fin */


		/*** Inicio Cambio PAS20155E220200192 RSV **/

		if (CollectionUtils.isEmpty(resultadoError)){
			//  RSV PAS20155E220200172 SE CAMBIA DE POSICI�N POR QUE NO ENVIA NOTIFICACI�N /			
			HashMap mapaNotificaLC = new HashMap(); //RIN10
			mapaNotificaLC.put("generaLC", "NO");
			//jenciso RIN05 Inicio
			Map<String,Object> mapNotificaLC15N9 = new HashMap<String, Object>(); 
			mapNotificaLC15N9.put("generaLC15_NO_9", "NO");
			if(variablesIngreso.get("montoTPILC15_NO_9")!=null){
				Map<String,Object>  mapLC15N9 = (Map<String,Object>)variablesIngreso.get("montoTPILC15_NO_9");
				Map<String,Object>  mapLC = (Map<String,Object>)variablesIngreso.get("RESULTADO_LIQ");//VERIFICAR LOS DATOS QUE RETORNA PARA LOS TPIS CORRESPONDIENTES
				if(mapLC.get("numeroLC15N9")!=null){
					String numelc = mapLC.get("numeroLC15N9").toString();
					mapNotificaLC15N9.put("generaLC15_NO_9", "SI");
					mapNotificaLC15N9.put("NumeroLC", numelc);
					mapNotificaLC15N9.put("codigoTPI", mapLC15N9.get("codigoTPI").toString());
					mapNotificaLC15N9.put("CodJefe", mapLC15N9.get("CodJefe").toString());
					mapNotificaLC15N9.put("avisoDias", mapLC15N9.get("avisoDias").toString());
					mapNotificaLC15N9.put("avisoSustento", mapLC15N9.get("avisoSustento").toString());
					//obtener el indicador de garantia
					mapNotificaLC15N9.put("indicadorGarantia", mapLC15N9.get("indicadorGarantia"));
				}
			}

			Map<String,Object> mapNotificaLC15S9 = new HashMap<String, Object>();
			mapNotificaLC15S9.put("generaLC15_SI_9", "NO");
			if(variablesIngreso.get("montoTPILC15_SI_9")!=null){
				Map<String,Object> mapLC15S9 = (Map<String,Object>)variablesIngreso.get("montoTPILC15_SI_9");
				Map<String,Object> mapLC = (Map<String,Object>)variablesIngreso.get("RESULTADO_LIQ");//VERIFICAR LOS DATOS QUE RETORNA PARA LOS TPIS CORRESPONDIENTES
				if(mapLC.get("numeroLC15S9")!=null){
					String numelc = mapLC.get("numeroLC15S9").toString();
					mapNotificaLC15S9.put("generaLC15_SI_9", "SI");
					mapNotificaLC15S9.put("NumeroLC", numelc);
					mapNotificaLC15S9.put("codigoTPI", mapLC15S9.get("codigoTPI").toString());
					mapNotificaLC15S9.put("CodJefe", mapLC15S9.get("CodJefe").toString());
					//mapNotificaLC15S9.put("desTpi", catalogoAyudaService.getDescripcionDataCatalogo(ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, mapLC15S9.get("codigoTPI").toString()));
					mapNotificaLC15S9.put("desTpi", catalogoayudaservice.getDescripcionDataCatalogo("10", mapLC15S9.get("codigoTPI").toString()));
					mapNotificaLC15S9.put("indicadorGarantia", mapLC15S9.get("indicadorGarantia"));
					//faltaba setear variable certiOrigen
					mapNotificaLC15S9.put("certiOrigen", mapLC15S9.get("certiOrigen"));
				}
			}
			
		
			
			
			
			
			//jenciso RIN05 Fin
			try{
				grabarNotificacionesLC0010 (declaracion, mapaNotificaLC,mapNotificaLC15N9, mapNotificaLC15S9);
			}catch(Exception e)
			{
				log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir numeraci�n
			}
		}

		/**  RSV PAS20155E220200172 SE CAMBIA DE POSICI�N POR QUE NO ENVIA NOTIFICACI�N **/

		return resultadoError;

	}
	
	/** PAS20171U220200005 si es registro nuevo acogimiento al impconsumo, se valida para indicarle el nro de envio parcial 
	 * @param declaracion
	 * @param solicitudRectificacion
	 */
	private void grabarNroEnvioParcialMercanciaVigente(Declaracion declaracion, List<DetSolicitudRectificacionBean> detalleSolicitud) {
		
		if(!CollectionUtils.isEmpty(detalleSolicitud)) {
		
			ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService"); 
			Map<String,Object> mapaIndicadorTPN21 = valMercanciaVigenteService.obtenerIndicadorMercanciaVigente(declaracion.getDua().getListIndicadores());  

			for(DetSolicitudRectificacionBean detSolicitud:detalleSolicitud){
				if(detSolicitud.getCodtabla().equals(ConstantesDataCatalogo.TABLA_IMPCONSUMO)) {
				
					if(detSolicitud.getTipoCambio().equals(Constants.IND_REGISTRO_NUEVO) ){
					
						boolean tieneIndicadorMV = !mapaIndicadorTPN21.isEmpty();   
						if( tieneIndicadorMV ){
							boolean esTPN21 = false;
							String numEnvioParcial = "1";//por defecto si es primigenia va 1
						
							for(DatoSerie serie:declaracion.getDua().getListSeries()){
								if(serie.getCodtratprefe()==21){
									esTPN21 = true;
									break;
								}								 						
							}
							if(esTPN21){
								Integer valorSecuenciaNueva = new Integer(0);
								String secuencia = mapaIndicadorTPN21.get("desIndicador")!=null?mapaIndicadorTPN21.get("desIndicador").toString():"";
								if(secuencia.equals("") || !secuencia.equals("1")){ 
									valorSecuenciaNueva = valMercanciaVigenteService.obtenerSecuenciaEnvioPorDeclaracion(declaracion);	
									if(valorSecuenciaNueva>1){
										valorSecuenciaNueva=valorSecuenciaNueva-1;//como ya hizo todos los grabados ya esta contando el acogido
									}
									secuencia = valorSecuenciaNueva.toString();
								}						
								numEnvioParcial = secuencia;								
							}
						
							Map<String,Object> mapDatos=new HashMap<String, Object>();
							mapDatos.put("NUM_ENVIOPARCIAL",  numEnvioParcial);
							mapDatos.put("NUM_CORREDOC",  declaracion.getNumeroCorrelativo());
							CabAdjImpoconsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("cabAdjImpoconsuDAO");
							cabAdiImpoconsuDAO.update(mapDatos);
						}					
					}
				}
			}
		}		
	}
	
	/**
	 * Dependiendo de si se a�ade o retira el Mandato Electr�nico es que se registra el mismo y se prepara el mensaje de rpta al usuario
	 * @param dua
	 * @param variablesIngreso
	 */
	private void grabarMandatoElectronico(DUA dua, Map<String, Object> variablesIngreso){
		GrabarMandatoElectronicoService grabarMandatoElectronicoService = fabricaDeServicios.getService("despaduanero2.ingreso.grabarMandatoElectronicoService");
		String tipoMandatoElectronico = grabarMandatoElectronicoService.grabarMandatoElectronico(dua, dua.getFecdeclaracion(), ConstantesDataCatalogo.TRANSACCION_RECTIFICACION);
		variablesIngreso.put("tipoMandatoElectronico", tipoMandatoElectronico);
		if (SunatStringUtils.isEqualTo(tipoMandatoElectronico, ConstantesDataCatalogo.TIENE_MANDATO_ELECTRONICO)){
			CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
			DataCatalogo datacatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_MENSAJES_AVISOS_TEXTO, ConstantesDataCatalogo.MSG_MANDATO_ELECTRONICO);
			variablesIngreso.put("msgNotif", datacatalogo.getDesDatacat());
		}
		if (SunatStringUtils.isEqualTo(tipoMandatoElectronico, ConstantesDataCatalogo.RETIRA_MANDATO_ELECTRONICO)){
			CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
			DataCatalogo datacatalogo = catalogoAyudaService.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_MENSAJES_AVISOS_TEXTO, ConstantesDataCatalogo.MSG_RETIRA_MANDATO_ELECTRONICO);
			variablesIngreso.put("msgNotif", datacatalogo.getDesDatacat());
		}
	}
	
	
	private void actualizarCtaCteRegimen(Declaracion declaracion, Long numCorreDoc){
		boolean esTPN21 = false;

		for(DatoSerie serie:declaracion.getDua().getListSeries()){		
			if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()!=0){
				esTPN21 = serie.getCodtratprefe()==21;
				break;
			}
		}
		if(esTPN21){
			DetCtacteRegimenDAO detCtacteRegimenDAO = fabricaDeServicios.getService("declaracion.detCtaCteRegimen");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("numCorredocDesc", numCorreDoc);
			params.put("indAnulacion", "1");		  
			List<DetCtacteRegimen> listaDet = detCtacteRegimenDAO.listaByKeyMap(params);

			for(DatoSerie serie:declaracion.getDua().getListSeries()){		
				for(DatoRegPrecedencia prec:serie.getListRegPrecedencia()){
					if( esTPN21 ) {
						fillCabCtacteRegimen(serie, prec, numCorreDoc, listaDet);
					}
				}
			}
		}else{
			SerieService serieService = fabricaDeServicios.getService("diligencia.ingreso.serieService");
			Map pkDocu = new HashMap();
			pkDocu.put("NUM_CORREDOC",numCorreDoc);
			pkDocu.put("COD_CONVENIO","  21");
			pkDocu.put("COD_TIPCONVENIO","T");
			List lista = serieService.obtenerConvenioSerieMap(pkDocu);
			if(!CollectionUtils.isEmpty(lista)){

				DetCtacteRegimenDAO detCtacteRegimenDAO = fabricaDeServicios.getService("declaracion.detCtaCteRegimen");
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("numCorredocDesc", numCorreDoc);
				params.put("indAnulacion", "1");		  
				List<DetCtacteRegimen> listaDet = detCtacteRegimenDAO.listaByKeyMap(params);

				DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
				ctaCteService.quitarTPN21CtacteRegimen(listaDet);
			}
		}	  
	}


	/**
	 * Busca en la tabla de preliquidaci�n, los indicadores de Preferencia Arancelaria
	 * En el caso de una rectificacion autom�tica donde no se reliquida por no existir diferencia tributaria 
	 * @param declaracion
	 */
	private void actualizarIndicadoresPreferencia(Declaracion declaracion){
		FuncionesLiquidacionService funcionesLiquidacionService = fabricaDeServicios.getService("funcionesLiquidacionService");
		LiquidaDeclaracionPecoAmazoniaService liquidaDeclaracionPecoAmazoniaService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionPecoAmazoniaService");

		Map<String,Object> cabDeclaraMap = new HashMap<String,Object>();
		cabDeclaraMap.put("COD_ADUANA",Cadena.padLeft(declaracion.getNumdeclRef().getCodaduana(), 3, '0') );
		cabDeclaraMap.put("ANN_PRESEN",declaracion.getNumdeclRef().getAnnprese());
		cabDeclaraMap.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
		cabDeclaraMap.put("NUM_DECLARACION", Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre(), 6, '0'));
		CabDocliq cabdocliq = funcionesLiquidacionService.obtenerDatosCabDocliq(cabDeclaraMap, true);
		if (cabdocliq != null) {
			MovCabliqdilig movCabliqdilig = funcionesLiquidacionService.obtenerCabeceraPreliquidacion(cabdocliq);
			if (movCabliqdilig != null) {
				liquidaDeclaracionPecoAmazoniaService.grabaIndicadorLiberacion(movCabliqdilig.getIndPoliLiber(), cabdocliq.getIndDocigv(), declaracion.getDua().getNumcorredoc());
			}
		}
	}

	private void fillCabCtacteRegimen(DatoSerie serie, DatoRegPrecedencia prec, Long numCorredoc,List<DetCtacteRegimen> listaDet){

		DeclaracionCuentaCorrienteService ctaCteService = (DeclaracionCuentaCorrienteService) fabricaDeServicios.getService("declaracionCuentaCorrienteService");
		Map<String,Object> paramCtaCte = new HashMap<String,Object>();
		paramCtaCte.put("codAduana", prec.getCodaduapre());
		paramCtaCte.put("annPresen", prec.getAnndeclpre().substring(0, 4));
		paramCtaCte.put("codRegimen", prec.getCodregipre());
		paramCtaCte.put("numDeclaracion", prec.getNumdeclpre());
		paramCtaCte.put("numSecserie", prec.getNumserpre());
		List<CabCtacteRegimen> listaCabCtacteRegimen = ctaCteService.obtenerCabeceraCtaCte(paramCtaCte);
		if( listaCabCtacteRegimen.size()>0 ) {
			CabCtacteRegimen ctacte = listaCabCtacteRegimen.get(0); 
			boolean actualizarRegu = false;
			BigDecimal diferencia = BigDecimal.ZERO;
			for(DetCtacteRegimen detCtaCte : listaDet){
				if(detCtaCte.getNumCtacte().equals(ctacte.getNumCtacte()) && 
						detCtaCte.getNumSerieDesc().equals(serie.getNumserie())){
					diferencia = SunatNumberUtils.diference(serie.getCntunicomer(), detCtaCte.getCntDescargada());
					actualizarRegu = true;
					break;
				}
			}
			if(actualizarRegu && diferencia.compareTo(BigDecimal.ZERO)!=0){
				ctaCteService.actualizaReguCtacteRegimen(ctacte, serie, numCorredoc,diferencia);
			}else{
				if(!actualizarRegu){
					ctaCteService.actualizaCtacteRegimen(ctacte, serie, numCorredoc);
				}
			}
		}

		return;
	}
	//gmontoya P29 Pase 15 2015 fin 
	/*INICIO-P28 FSW AFMA*/
	private void actualizacionSaldoFranquicia(Declaracion declaracion, Declaracion declaracionBD, String codTransaccion, boolean transmisionDefinitiva) throws Exception
	{
		if(codTransaccion.endsWith("03") || codTransaccion.endsWith("07")){

			if(transmisionDefinitiva){

				List<String> lstSeriesTPN93Eliminadas = obtenerSeriesConTPN93Eliminados(declaracion,declaracionBD);

				if(!CollectionUtils.isEmpty(lstSeriesTPN93Eliminadas)){
					ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");
					//se elimina con la data registrada comparandola con
					controlarSaldoReposicionService.eliminarReservaCtaCteTPN93Eliminadas(declaracion,codTransaccion,lstSeriesTPN93Eliminadas);
				}
			}

			// para automatica o no es lo mismo despues o antes de la diligencia en todos los casos se actualiza el saldo.

			List<DatoSerie> lstSeriesTPN93Adicionadas = obtenerSeriesConTPN93Adicionadas(declaracion,declaracionBD);

			//observacion de calidad solo es definitava despues de la dilgencia



			boolean tieneDiligencia = transmisionDefinitiva;//P28-PAS20155E410000032 - bug 24010

			if(!CollectionUtils.isEmpty(lstSeriesTPN93Adicionadas)){
				ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");                                               
				controlarSaldoReposicionService.actualizarCtaCte(declaracion,codTransaccion,tieneDiligencia,lstSeriesTPN93Adicionadas);
			}

			List<DatoSerie> lstSeriesTPN93Modificados = obtenerSeriesConDatosAsociadosTPN93Modificados(declaracion,declaracionBD);

			if(!CollectionUtils.isEmpty(lstSeriesTPN93Modificados)){
				ControlarSaldoReposicionService controlarSaldoReposicionService = fabricaDeServicios.getService("sigad.ingreso.ControlarSaldoReposicionService");
				controlarSaldoReposicionService.actualizarCtaCte(declaracion,codTransaccion,tieneDiligencia,lstSeriesTPN93Modificados);
			}
		}
	}





	private List<String> obtenerSeriesConTPN93Eliminados(Declaracion declaracion, Declaracion declaracionBD)
	{
		List<String> lstSeriesTPN93Eliminadas = new ArrayList<String>();
		//boolean esTPN93eliminado = false;
		for(DatoSerie datoSerieBD: declaracionBD.getDua().getListSeries()){

			//verifica si se ha eliminado un TPN
			if (ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93.equals(datoSerieBD.getCodtratprefe())){
				for(DatoSerie datoSerie: declaracion.getDua().getListSeries()){
					if(datoSerieBD.getNumserie().toString().equals(datoSerie.getNumserie().toString())){
						if (!ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93.equals(datoSerie.getCodtratprefe())){                        	
							lstSeriesTPN93Eliminadas.add(datoSerieBD.getNumserie().toString());
						}
					}
				}
			}

		}
		//return esTPN93eliminado;
		return lstSeriesTPN93Eliminadas;
	}



	private List<DatoSerie> obtenerSeriesConTPN93Adicionadas(Declaracion declaracion, Declaracion declaracionBD)
	{
		List<DatoSerie> lstSeriesTPN93Adicionadas = new ArrayList<DatoSerie>();
		for(DatoSerie datoSerie: declaracion.getDua().getListSeries()){

			if (ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93.equals(datoSerie.getCodtratprefe())){

				boolean serieEsNueva = true;
				for(DatoSerie datoSerieBD: declaracionBD.getDua().getListSeries()){
					if(datoSerieBD.getNumserie().toString().equals(datoSerie.getNumserie().toString())){
						serieEsNueva = false;
						if (!ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93.equals(datoSerieBD.getCodtratprefe())){
							lstSeriesTPN93Adicionadas.add(datoSerie);
						}
					}
				}

				if(serieEsNueva){
					lstSeriesTPN93Adicionadas.add(datoSerie);
				}
			}
		}
		return lstSeriesTPN93Adicionadas;
	}


	private List<DatoSerie> obtenerSeriesConDatosAsociadosTPN93Modificados(Declaracion declaracion, Declaracion declaracionBD)
	{
		List<DatoSerie> lstSeriesTPN93Modificados = new ArrayList<DatoSerie>();
		for(DatoSerie datoSerieBD: declaracionBD.getDua().getListSeries()){			
			if (ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93.equals(datoSerieBD.getCodtratprefe())){

				DatoSerie serieNew = null;
				String codAduanaXMLOld = "";
				String anioCertificadoXMLOld = "";
				String numCertificadoXMLOld = "";
				String numItemXMLOld = "";
				String cntFisicaXMLOld = "";
				String undFisicaXMLOld = "";						
				String undEquivalentesXMLOld = "";
				String cntEquivalenteXMLOld = "";

				String codAduanaXMLNew = "";
				String anioCertificadoXMLNew = "";
				String numCertificadoXMLNew = "";
				String numItemXMLNew = "";
				String cntFisicaXMLNew = "";
				String undFisicaXMLNew = "";						
				String undEquivalentesXMLNew = "";
				String cntEquivalenteXMLNew = "";

				if(!CollectionUtils.isEmpty(datoSerieBD.getListRegPrecedencia()))
				{
					for(DatoRegPrecedencia regPrece: datoSerieBD.getListRegPrecedencia() ){
						if(regPrece.getCodregipre().equals(ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION)){			

							codAduanaXMLOld = regPrece.getCodaduapre();
							anioCertificadoXMLOld = SunatStringUtils.substringFox(regPrece.getAnndeclpre(), 1,4);
							numCertificadoXMLOld = regPrece.getNumdeclpre();
							numItemXMLOld = regPrece.getNumserpre().toString();
							cntFisicaXMLOld = datoSerieBD.getCntunifis().toString();
							undFisicaXMLOld = datoSerieBD.getCodunifis().toString();						
//OMA PAS20181U220200004						
							undEquivalentesXMLOld = datoSerieBD.getProducto()!=null?datoSerieBD.getProducto().getCodtipoequi():"";
							cntEquivalenteXMLOld = datoSerieBD.getProducto()!=null?datoSerieBD.getProducto().getCntunimedidaequi().toString():"";
							break;

						}
					}

					for(DatoSerie datoSerie: declaracion.getDua().getListSeries()){
						if(datoSerieBD.getNumserie().toString().equals(datoSerie.getNumserie().toString())){
							if (ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93.equals(datoSerie.getCodtratprefe())){

								if(!CollectionUtils.isEmpty(datoSerie.getListRegPrecedencia())){
									for(DatoRegPrecedencia regPrece: datoSerie.getListRegPrecedencia() ){
										if(regPrece.getCodregipre().equals(ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION)){			

											codAduanaXMLNew = regPrece.getCodaduapre();
											anioCertificadoXMLNew = SunatStringUtils.substringFox(regPrece.getAnndeclpre(), 1,4);
											numCertificadoXMLNew = regPrece.getNumdeclpre();
											numItemXMLNew = regPrece.getNumserpre().toString();
											cntFisicaXMLNew = datoSerie.getCntunifis().toString();
											undFisicaXMLNew = datoSerie.getCodunifis().toString();
//OMA PAS20181U220200004
//											undEquivalentesXMLNew = (datoSerie.getDatoProductoTmp()!=null && datoSerie.getDatoProductoTmp().getCodtipoequi()!=null)?datoSerie.getDatoProductoTmp().getCodtipoequi():"";
//											cntEquivalenteXMLNew = (datoSerie.getDatoProductoTmp()!=null && datoSerie.getDatoProductoTmp().getCntunimedidaequi()!=null)?datoSerie.getDatoProductoTmp().getCntunimedidaequi().toString():"";
											undEquivalentesXMLNew = (datoSerie.getProducto()!=null && datoSerie.getProducto().getCodtipoequi()!=null)?datoSerie.getProducto().getCodtipoequi():"";
											cntEquivalenteXMLNew = (datoSerie.getProducto()!=null && datoSerie.getProducto().getCntunimedidaequi()!=null)?datoSerie.getProducto().getCntunimedidaequi().toString():"";

											serieNew = datoSerie;
											break;

										}
									}
								}							
							}
						}
					}
				}
				//se compara
				if(serieNew!=null && (!StringUtils.isEmpty(codAduanaXMLNew) && !StringUtils.isEmpty(codAduanaXMLOld) && !codAduanaXMLNew.equals(codAduanaXMLOld))
						|| (!StringUtils.isEmpty(anioCertificadoXMLNew) && !StringUtils.isEmpty(anioCertificadoXMLOld) && !anioCertificadoXMLNew.equals(anioCertificadoXMLNew))
						|| (!StringUtils.isEmpty(numCertificadoXMLNew) && !StringUtils.isEmpty(numCertificadoXMLOld) && !numCertificadoXMLNew.equals(numCertificadoXMLOld))
						|| (!StringUtils.isEmpty(numItemXMLNew) && !StringUtils.isEmpty(numItemXMLOld) && !numItemXMLNew.equals(numItemXMLOld))
						|| (!StringUtils.isEmpty(cntFisicaXMLNew) && !StringUtils.isEmpty(cntFisicaXMLOld) && !cntFisicaXMLNew.equals(cntFisicaXMLOld))
						|| (!StringUtils.isEmpty(undFisicaXMLNew) && !StringUtils.isEmpty(undFisicaXMLOld) && !undFisicaXMLNew.equals(undFisicaXMLOld))
						|| (!StringUtils.isEmpty(undEquivalentesXMLNew) && !StringUtils.isEmpty(undEquivalentesXMLOld) && !undEquivalentesXMLNew.equals(undEquivalentesXMLOld))
						|| (!StringUtils.isEmpty(cntEquivalenteXMLNew) && !StringUtils.isEmpty(cntEquivalenteXMLOld) && !cntEquivalenteXMLNew.equals(cntEquivalenteXMLOld))
						){

					//	esTPN93Modificado = true;
					//basta que se agrege 1 se debe reservar por la diferencia
					//	break;

					lstSeriesTPN93Modificados.add(serieNew);
				}

			}
		}
		return lstSeriesTPN93Modificados;
	}
	/*FIN-P28 FSW AFMA*/
	/**
	 * Grabar Notificaciones producto de la rectificaci�n
	 * 
	 * @author olunar - 11/07/2012
	 * 
	 * @param declaracion
	 * @param solicitudRectificacion
	 * @param variablesIngreso
	 */
	private void grabarNotificacionesRectificacion(Declaracion declaracion, SolicitudRectificacionBean solicitudRectificacion, Map<String, Object> variablesIngreso) {
		// Rectificacion es aceptada autom�ticamente
		CatalogoAyudaService catalogoayudaservice = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService) fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		if(solicitudRectificacion.getCodestarecti().equals(ConstantesDataCatalogo.COD_EST_RECTIFIC_ACEPTADO_AUTOMATICAMENTE))
		{
			// Existe incidencia tributaria
			Map<String, Object> deudadiferencial = (Map<String,Object>)variablesIngreso.get("deudadiferencial");
			//PAS20165E220200127
			//if(variablesIngreso.get("deudadiferencial")!=null && deudadiferencial.get("tieneIncTribByTrib").toString().equals(Constants.CODIGO_VERDADERO))
			//{
			Map<String,Object> mapRetornoLiqui=(Map<String, Object>) variablesIngreso.get("RESULTADO_LIQ");
			if(mapRetornoLiqui!=null)
			{
				List<HashMap> lstDeudas = (List<HashMap>)mapRetornoLiqui.get("LISTADEUDASGENERADAS");
				if(!CollectionUtils.isEmpty(lstDeudas))
				{
					FechaBean fechaActual = new FechaBean();
					FechaBean fechaVigencia = new FechaBean();
					fechaVigencia.setFecha("31/12/9999");
					Map<String, Object> mapMensaje = new HashMap<String, Object>();
					String descAduana = "";
					descAduana = catalogoayudaservice.getDescripcionDataCatalogo(Constants.COD_CATALOG_ADUANA, declaracion.getDua().getCodaduanaorden());
					FechaBean fechaDeclara = new FechaBean();
					fechaDeclara.setFecha(declaracion.getDua().getFecdeclaracion());
					String strNumeroDeclaracion=declaracion.getNumeroDeclaracion().toString().trim();
					int j=strNumeroDeclaracion.length();
					for(int i=0; i<6-j ;i++)
					{
						strNumeroDeclaracion="0"+strNumeroDeclaracion;
					}

					//lmvr - Inicio pase 105 - Agregado
					Map parametroParticip = new HashMap();
					parametroParticip.put("numeroCorrelativo", declaracion.getDua().getNumcorredoc());
					parametroParticip.put("codTippartic", new String [] {"41","45"});
					ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
					List<Participante> listadoParticipante = participanteService.obtenerTipoParticipanteAutorizadoByCriterios(parametroParticip);
					List lstOperadores   = new ArrayList();	
					String datosAgente="-";
					String datosUsuarioA="-";
					String datosUsuarioI="-";
					String datosImportador="-";
					for (int i=0; i<listadoParticipante.size(); i++) {
						Participante participante = listadoParticipante.get(i);
						lstOperadores.add(participante.getNumeroDocumentoIdentidad());
						if ("41".equals(participante.getTipoParticipante().getCodDatacat()) ) {
							// datosAgente=(String)( participante.getNumeroDocumentoIdentidad() + "-" + participante.getNombreRazonSocial());     
							datosAgente=(String)(participante.getNombreRazonSocial());   
							datosUsuarioA=(String)( participante.getNumeroDocumentoIdentidad());     
						}
						if ("45".equals(participante.getTipoParticipante().getCodDatacat()) ) {
							// datosImportador=(String)( participante.getNumeroDocumentoIdentidad() + "-" + participante.getNombreRazonSocial());     
							datosImportador=(String)(participante.getNombreRazonSocial()); 
							datosUsuarioI=(String)( participante.getNumeroDocumentoIdentidad()); 
						}
					}
					mapMensaje.put("agente_aduana", datosAgente);
					mapMensaje.put("consignatario", datosImportador);
					//lmvr - Fin pase 105 - Agregado

					// Notificaci�n al Despachador de Aduana por Rectificaci�n de Dua
					mapMensaje.put("tip_usuario", "1");
					//PAS20165E220200127
					//mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
					mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
					mapMensaje.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
					mapMensaje.put("des_intendencia", descAduana);
					mapMensaje.put("ann_presen", fechaDeclara.getAnho().toString());
					mapMensaje.put("cod_regimen", declaracion.getDua().getCodregimen().toString());
					mapMensaje.put("num_declaracion", strNumeroDeclaracion);

					mapMensaje.put("Formc_CDA", "-");
					mapMensaje.put("LC_tribnro", "-");
					mapMensaje.put("Formc_mto", "-");
					mapMensaje.put("LC_perCDA", "-");
					mapMensaje.put("LC_perNro", "-");
					mapMensaje.put("LC_permto", "-");
					mapMensaje.put("LC_iscCDA", "-");
					mapMensaje.put("LC_iscNro", "-");
					mapMensaje.put("LC_iscmto", "-");

					StringBuffer strNumLiq=null; 
					String strMonedaDesc="";
					String strMontoMoneda="";

					for(HashMap deudaDUA:lstDeudas) 
					{
						strNumLiq=new StringBuffer("");
						strNumLiq.append(deudaDUA.get("COD_ADULIQUIDA").toString().trim());
						strNumLiq.append("-");
						strNumLiq.append(deudaDUA.get("ANN_LIQUIDA").toString().equals("0")?"":deudaDUA.get("ANN_LIQUIDA"));
						strNumLiq.append("-");
						strNumLiq.append(deudaDUA.get("NUM_LIQUIDA").toString().trim());
						if(strNumLiq.toString().equals("--"))strNumLiq=new StringBuffer("-");

						strMonedaDesc=deudaDUA.get("MONEDA").toString();
						if(!strMonedaDesc.equals(""))
						{
							/* Ver otra forma de obtener */
							if(strMonedaDesc.equals("S"))strMonedaDesc="PEN";
							if(strMonedaDesc.equals("D"))strMonedaDesc="USD";
							DataCatalogo  datacat= catalogoayudaservice.getDataCatalogo("J1", strMonedaDesc);
							strMonedaDesc = datacat.getDesDatacat();
						}
						else
							strMonedaDesc="";

						strMontoMoneda = deudaDUA.get("MONTO").toString()+" "+strMonedaDesc; 	

						if(deudaDUA.get("TIPO").equals("DUA"))
						{
							mapMensaje.put("Formc_CDA", deudaDUA.get("CDA").toString().trim().equals("")?"-":deudaDUA.get("CDA"));
							mapMensaje.put("LC_tribnro", strNumLiq.toString());
							mapMensaje.put("Formc_mto", strMontoMoneda);
						}
						else if(deudaDUA.get("TIPO").equals("LC") && deudaDUA.get("TIPOLC").toString().equals("0010"))
						{
							mapMensaje.put("Formc_CDA", deudaDUA.get("CDA").toString().trim().equals("")?"-":deudaDUA.get("CDA"));
							mapMensaje.put("LC_tribnro", strNumLiq.toString());
							mapMensaje.put("Formc_mto", strMontoMoneda);
						}
						else if(deudaDUA.get("TIPO").equals("LC") && deudaDUA.get("TIPOLC").toString().equals("0038"))
						{
							mapMensaje.put("LC_perCDA", deudaDUA.get("CDA").toString().trim().equals("")?"-":deudaDUA.get("CDA"));
							mapMensaje.put("LC_perNro", strNumLiq.toString());
							mapMensaje.put("LC_permto", strMontoMoneda);
						}
						else if(deudaDUA.get("TIPO").equals("LC") && deudaDUA.get("TIPOLC").toString().equals("0022"))
						{
							mapMensaje.put("LC_iscCDA", deudaDUA.get("CDA").toString().trim().equals("")?"-":deudaDUA.get("CDA"));
							mapMensaje.put("LC_iscNro", strNumLiq.toString());
							mapMensaje.put("LC_iscmto", strMontoMoneda);
						}
					}						
					// Con Garant�a 160
					if(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia()!=null && !declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia().trim().equals(""))
					{
						mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()}); //PAS20165E220200127
						mapMensaje.put("des_asunto", Constants.ASUNTO_NOTIF_RECTIF_ACEPTA_AUTO_CON_INCID_TRIBUT_AFECTA_CTA_CTE);
						StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
						publicacionAvisoService.insert(Constants.COD_NOTIF_RECTIF_ACEPTA_AUTO_CON_INCID_TRIBUT_AFECTA_CTA_CTE, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
								fechaActual.getTimestamp(), fechaVigencia.getTimestamp());

						//notificacion al consignatario
						// PAS20165E220200127
						mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()});
						mapMensaje.put("agente_aduana", datosImportador);
						mapMensaje.put("des_asunto", Constants.ASUNTO_NOTIF_RECTIF_ACEPTA_AUTO_CON_INCID_TRIBUT_AFECTA_CTA_CTE);
						StringBuffer data2 = new StringBuffer(SojoUtil.toJson(mapMensaje));
						publicacionAvisoService.insert(Constants.COD_NOTIF_RECTIF_ACEPTA_AUTO_CON_INCID_TRIBUT_AFECTA_CTA_CTE, data2, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
								fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
						//Fin PAS20165E220200127
					}
					else 
					{// Sin Garant�a 160
						mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()}); //PAS20165E220200127
						mapMensaje.put("des_asunto", Constants.ASUNTO_NOTIF_RECTIF_ACEPTA_AUTO_CON_INCID_TRIBUT);
						StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
						publicacionAvisoService.insert(Constants.COD_NOTIF_RECTIF_ACEPTA_AUTO_CON_INCID_TRIBUT, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
								fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
						//PAS20165E220200127
						//notificacion al consignatario
						// PAS20165E220200127
						mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()});
						mapMensaje.put("agente_aduana", datosImportador);
						mapMensaje.put("des_asunto", Constants.ASUNTO_NOTIF_RECTIF_ACEPTA_AUTO_CON_INCID_TRIBUT);
						StringBuffer data2 = new StringBuffer(SojoUtil.toJson(mapMensaje));
						publicacionAvisoService.insert(Constants.COD_NOTIF_RECTIF_ACEPTA_AUTO_CON_INCID_TRIBUT, data2, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
								fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
					}
				}			
				List<HashMap> LcAnuladas = (List<HashMap>)mapRetornoLiqui.get("LISTALCANULADA");

				if(!CollectionUtils.isEmpty(LcAnuladas))
				{
					FechaBean fechaActual = new FechaBean();
					FechaBean fechaVigencia = new FechaBean();
					fechaVigencia.setFecha("31/12/9999");
					Map<String, Object> mapMensaje = new HashMap<String, Object>();
					String descAduana = "";
					descAduana = catalogoayudaservice.getDescripcionDataCatalogo(Constants.COD_CATALOG_ADUANA, declaracion.getDua().getCodaduanaorden());
					FechaBean fechaDeclara = new FechaBean();
					fechaDeclara.setFecha(declaracion.getDua().getFecdeclaracion());
					String strNumeroDeclaracion=declaracion.getNumeroDeclaracion().toString().trim();
					int j=strNumeroDeclaracion.length();
					for(int i=0; i<6-j ;i++)
					{
						strNumeroDeclaracion="0"+strNumeroDeclaracion;
					}
					//lmvr - Inicio pase 105 - Agregado
					Map parametroParticip = new HashMap();
					parametroParticip.put("numeroCorrelativo", declaracion.getDua().getNumcorredoc());
					parametroParticip.put("codTippartic", new String [] {"41","45"});
					ParticipanteService participanteService = fabricaDeServicios.getService("despaduanero2.participanteService");
					List<Participante> listadoParticipante = participanteService.obtenerTipoParticipanteAutorizadoByCriterios(parametroParticip);
					List lstOperadores   = new ArrayList();	
					String datosAgente="-";
					String datosUsuarioA="-";
					String datosUsuarioI="-";
					String datosImportador="-";
					for (int i=0; i<listadoParticipante.size(); i++) {
						Participante participante = listadoParticipante.get(i);
						lstOperadores.add(participante.getNumeroDocumentoIdentidad());
						if ("41".equals(participante.getTipoParticipante().getCodDatacat()) ) {
							// datosAgente=(String)( participante.getNumeroDocumentoIdentidad() + "-" + participante.getNombreRazonSocial());     
							datosAgente=(String)(participante.getNombreRazonSocial());   
							datosUsuarioA=(String)( participante.getNumeroDocumentoIdentidad());     
						}
						if ("45".equals(participante.getTipoParticipante().getCodDatacat()) ) {
							// datosImportador=(String)( participante.getNumeroDocumentoIdentidad() + "-" + participante.getNombreRazonSocial());     
							datosImportador=(String)(participante.getNombreRazonSocial()); 
							datosUsuarioI=(String)( participante.getNumeroDocumentoIdentidad()); 
						}
					}
					mapMensaje.put("agente_aduana", datosAgente);
					mapMensaje.put("consignatario", datosImportador);
					//lmvr - Fin pase 105 - Agregado
					// Notificaci�n al Despachador de Aduana por Rectificaci�n de Dua
					mapMensaje.put("fecha_solirectielectronica", fechaActual.getFormatDate("dd/MM/yyyy").toString());
					mapMensaje.put("tip_usuario", "1");
					//PAS20165E220200127
					//mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
					mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
					mapMensaje.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
					mapMensaje.put("des_intendencia", descAduana);
					mapMensaje.put("ann_presen", fechaDeclara.getAnho().toString());
					mapMensaje.put("cod_regimen", declaracion.getDua().getCodregimen().toString());
					mapMensaje.put("num_declaracion", strNumeroDeclaracion);

					mapMensaje.put("LC_perCDA", "-");
					StringBuffer strNumLiq=null; 
					String strMonedaDesc="";
					String strMontoMoneda="";
					for(HashMap lc:LcAnuladas) 
					{
						strNumLiq=new StringBuffer("");
						strNumLiq.append(lc.get("COD_ADULIQUIDA").toString().trim());
						strNumLiq.append("-");
						strNumLiq.append(lc.get("ANN_LIQUIDA").toString().equals("0")?"":lc.get("ANN_LIQUIDA"));
						strNumLiq.append("-");
						strNumLiq.append(lc.get("NUM_LIQUIDA").toString().trim());
						if(strNumLiq.toString().equals("--"))strNumLiq=new StringBuffer("-");

						strMonedaDesc=lc.get("MONEDA").toString();
						if(!strMonedaDesc.equals(""))
						{
							/* Ver otra forma de obtener */
							if(strMonedaDesc.equals("S"))strMonedaDesc="PEN";
							if(strMonedaDesc.equals("D"))strMonedaDesc="USD";
							DataCatalogo  datacat= catalogoayudaservice.getDataCatalogo("J1", strMonedaDesc);
							strMonedaDesc = datacat.getDesDatacat();
						}
						else
							strMonedaDesc="";

						strMontoMoneda = lc.get("MONTO").toString()+" "+strMonedaDesc; 

						if(lc.get("TIPO").equals("LC") && lc.get("TIPOLC").toString().equals("0038"))
						{	
							mapMensaje.put("LC_perCDA", lc.get("CDA").toString().trim().equals("")?"-":lc.get("CDA"));
							mapMensaje.put("LC_perNro", strNumLiq.toString());
							mapMensaje.put("LC_permto", strMontoMoneda);
						}

					}
					mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
					mapMensaje.put("des_asunto", "AVISO DE ANULACION DE PERCEPCION");
					StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
					publicacionAvisoService.insert(Constants.COD_NOTIF_RECTIF_ACEPTA_AUTO_CON_ANULACION_PERCEPCION, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
							fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
					//PAS20165E220200127
					// consignatario 
					mapMensaje.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()});
					mapMensaje.put("agente_aduana", datosImportador);
					mapMensaje.put("des_asunto", "AVISO DE ANULACION DE PERCEPCION");
					StringBuffer data2 = new StringBuffer(SojoUtil.toJson(mapMensaje));
					publicacionAvisoService.insert(Constants.COD_NOTIF_RECTIF_ACEPTA_AUTO_CON_ANULACION_PERCEPCION, data2, Constants.CODIGO_TIPO_AVISO_NOTIFICACION,
							fechaActual.getTimestamp(), fechaVigencia.getTimestamp());


				}

			}


			//	} //PAS20165E220200127


		}
	}


	/*** Inicio Cambio PAS20155E220200192 RSV **/
	/**
	 * Grabar notificaciones desp�es de la grabaci�n de la declaraci�n
	 * 
	 * @author olunar - 2012-06-25
	 * @param declaracion
	 */
	private void grabarNotificacionesLC0010(Declaracion declaracion, HashMap mapaNotificaLC, Map<String,Object> mapNotificaLC15N9, Map<String,Object> mapNotificaLC15S9) {
		PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService) fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		DdpDAOService ddpDAOService = (DdpDAOService)fabricaDeServicios.getService("Ayuda.ddpService");
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");
		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		//	String descAduana = "";
		//	String strNumeroDeclaracion="";
		///descAduana = catalogoyudaService.getDescripcionDataCatalogo(Constants.COD_CATALOG_ADUANA, declaracion.getDua().getCodaduanaorden());
		FechaBean fechaDeclara = new FechaBean();
		fechaDeclara.setFecha(declaracion.getDua().getFecdeclaracion());
		String strNumeroDeclaracion=Cadena.padLeft(declaracion.getNumeroDeclaracion().toString().trim(), 6, '0'); //declaracion.getNumeroDeclaracion().toString().trim();

		//	mapMensaje.put("des_intendencia", descAduana);
		Map params=new HashMap();
		params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
		mapMensaje.put("fechahoy", fechaActual.getFormatDate("dd/MM/yyyy"));
		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));

		if(mapNotificaLC15N9.get("generaLC15_NO_9")!=null && mapNotificaLC15N9.get("generaLC15_NO_9").toString().equals("SI")){
			//Notifica a Agente de Aduana
			Map<String, Object> mapMsgLC15_NO_9 = new HashMap<String, Object>();
			mapMsgLC15_NO_9.put("tip_usuario", "1");
			mapMsgLC15_NO_9.put("cod_usuario", new String[]{declaracion.getDua().getNumdocumento()});
			mapMsgLC15_NO_9.put("des_asunto", Constants.ASUNTO_NOTIF_LC_15 );
			mapMsgLC15_NO_9.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
			mapMsgLC15_NO_9.put("tpi", mapNotificaLC15N9.get("codigoTPI").toString());
			mapMsgLC15_NO_9.put("numruc_agente", declaracion.getDua().getNumdocumento());
			mapMsgLC15_NO_9.put("dias", mapNotificaLC15N9.get("avisoDias").toString());
			mapMsgLC15_NO_9.put("sustento", mapNotificaLC15N9.get("avisoSustento").toString());
			//params=ddpDAO.findByPK(declaracion.getDua().getNumdocumento());
			params=ddpDAOService.findByPK(declaracion.getDua().getNumdocumento());
			if (params!=null) mapMsgLC15_NO_9.put("nombre_agente", params.get("ddp_nombre").toString().trim());
			else mapMsgLC15_NO_9.put("nombre_agente", " ");


			String dua = declaracion.getDua().getCodaduanaorden() + "-" +fechaDeclara.getAnho().toString() + "-" + declaracion.getDua().getCodregimen().toString() + "-" + strNumeroDeclaracion;
			String lc  = declaracion.getDua().getCodaduanaorden() + "-" +fechaDeclara.getAnho().toString()  + "-" + mapNotificaLC15N9.get("NumeroLC").toString(); 
			mapMsgLC15_NO_9.put("dua", dua);
			mapMsgLC15_NO_9.put("lc", lc);

			//Notifica a consignatario y agente de aduana.
			mapMsgLC15_NO_9.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad(),declaracion.getDua().getNumdocumento()});
			mapMsgLC15_NO_9.put("numruc_consigna", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (params!=null) mapMsgLC15_NO_9.put("nombre_consigna", params.get("ddp_nombre").toString().trim());
			else mapMsgLC15_NO_9.put("nombre_consigna", " ");
			data = new StringBuffer(SojoUtil.toJson(mapMsgLC15_NO_9));

			if (mapNotificaLC15N9.get("indicadorGarantia").toString().equals("G")){
				publicacionAvisoService.insert(Constants.COD_NOTIF_LC_15_N_9_G, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}else{
				publicacionAvisoService.insert(Constants.COD_NOTIF_LC_15_N_9, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}

			// Notificaci�n al Jefe del Area de Despacho
			if( !mapNotificaLC15N9.get("CodJefe").toString().equals("") ) {
				mapMsgLC15_NO_9.put("tip_usuario", "3");
				mapMsgLC15_NO_9.put("cod_usuario", new String[]{mapNotificaLC15N9.get("CodJefe").toString()});
				mapMsgLC15_NO_9.put("des_asunto",Constants.ASUNTO_AVISO_LC_15);
				data = new StringBuffer(SojoUtil.toJson(mapMsgLC15_NO_9));
				if (mapNotificaLC15N9.get("indicadorGarantia").toString().equals("G")){
					publicacionAvisoService.insert(Constants.COD_AVISO_LC_15_N_9_G, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
				}else{
					publicacionAvisoService.insert(Constants.COD_AVISO_LC_15_N_9, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
				}

			}

		}

		if(mapNotificaLC15S9.get("generaLC15_SI_9")!=null && mapNotificaLC15S9.get("generaLC15_SI_9").toString().equals("SI")){
			//Notifica a Agente de Aduana
			Map<String, Object> mapMsgLC15_SI_9 = new HashMap<String, Object>();
			mapMsgLC15_SI_9.put("tip_usuario", "1");
			mapMsgLC15_SI_9.put("des_asunto", Constants.ASUNTO_NOTIF_LC_15 );
			mapMsgLC15_SI_9.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
			mapMsgLC15_SI_9.put("tpi", mapNotificaLC15S9.get("codigoTPI").toString());
			mapMsgLC15_SI_9.put("numruc_agente", declaracion.getDua().getNumdocumento());
			mapMsgLC15_SI_9.put("desTpi", StringEscapeUtils.escapeHtml(mapNotificaLC15S9.get("desTpi").toString()));
			mapMsgLC15_SI_9.put("certiOrigen", mapNotificaLC15S9.get("certiOrigen").toString());

			params=ddpDAOService.findByPK(declaracion.getDua().getNumdocumento());
			if (params!=null) mapMsgLC15_SI_9.put("nombre_agente", params.get("ddp_nombre").toString().trim());
			else mapMsgLC15_SI_9.put("nombre_agente", " ");

			String dua = declaracion.getDua().getCodaduanaorden() + "-" + fechaDeclara.getAnho().toString() + "-" + declaracion.getDua().getCodregimen().toString() + "-" + strNumeroDeclaracion;
			String lc  = declaracion.getDua().getCodaduanaorden() + "-" + fechaDeclara.getAnho().toString()  + "-" + mapNotificaLC15S9.get("NumeroLC").toString(); 
			mapMsgLC15_SI_9.put("dua", dua);
			mapMsgLC15_SI_9.put("lc", lc);

			//Notifica a consignatario y agente
			mapMsgLC15_SI_9.put("cod_usuario", new String[]{declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad(),declaracion.getDua().getNumdocumento()});
			mapMsgLC15_SI_9.put("numruc_consigna", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			params=ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (params!=null) mapMsgLC15_SI_9.put("nombre_consigna", params.get("ddp_nombre").toString().trim());
			else mapMsgLC15_SI_9.put("nombre_consigna", " ");			
			data = new StringBuffer(SojoUtil.toJson(mapMsgLC15_SI_9));

			if (mapNotificaLC15S9.get("indicadorGarantia").toString().equals("G")){
				publicacionAvisoService.insert(Constants.COD_NOTIF_LC_15_S_9_G, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}else{
				publicacionAvisoService.insert(Constants.COD_NOTIF_LC_15_S_9, data, Constants.CODIGO_TIPO_AVISO_NOTIFICACION, 
						fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
			}


			// Notificaci�n al Jefe del Area de Despacho
			if( !mapNotificaLC15S9.get("CodJefe").toString().equals("") ) {
				mapMsgLC15_SI_9.put("tip_usuario", "3");
				mapMsgLC15_SI_9.put("cod_usuario", new String[]{mapNotificaLC15S9.get("CodJefe").toString()});
				mapMsgLC15_SI_9.put("des_asunto",Constants.ASUNTO_AVISO_LC_15);
				data = new StringBuffer(SojoUtil.toJson(mapMsgLC15_SI_9));
				if (mapNotificaLC15S9.get("indicadorGarantia").toString().equals("G")){
					publicacionAvisoService.insert(Constants.COD_AVISO_LC_15_S_9_G, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
				}else{
					publicacionAvisoService.insert(Constants.COD_AVISO_LC_15_S_9, data, "0", fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
				}

			}

		}



	}	
	/*** Fin Cambio PAS20155E220200192 RSV **/


	private void anularSolicitudNoAtendida(Declaracion declaracion){
		// si tiene solict rectificacion no atendida se las anula
		Map<String,Object> params=new HashMap<String, Object>();
		params.put("codestarecti", ConstantesDataCatalogo.COD_EST_RECTIFIC_ANULADA); // anulada
		params.put("numcorredocpre", declaracion.getDua().getNumcorredoc());
		// actualizo las que esten no atendidas 02,03,04
		params.put("estadosrecti", new String[]{ConstantesDataCatalogo.COD_EST_RECTIFIC_PARA_ASIG_ESPECIALISTA,
				ConstantesDataCatalogo.COD_EST_RECTIFIC_ASIGNADA_ESPECIALISTA,
				ConstantesDataCatalogo.COD_EST_RECTIFIC_EN_PROCESO_EVALUACION});
		params.put("codtransaccion",new String[] {ConstantesDataCatalogo.TRANSACCION_SOLICITUD_RECTIFICACION,
				SunatStringUtils.toNotNull(declaracion.getDua().getCodregimen()).concat(ConstantesDataCatalogo.TRANSACCION_SOLICITUD_RECTIFICACION)}); 		
		//RectificacionServiceImpl.getInstance().getSolirectificaDAO().updateByDocumento(params);
		((CabSolrectiDAO)fabricaDeServicios.getService("solirectificaDAO")).updateByDocumento(params);

	}

	//Se debe invocara a las funciones de Grabado  de adeudo para grabar 

	public Map<String, Object> Grabadocadeudo( Declaracion declaracion ,Map deudadiferencial,

			Map<String, Object> variablesIngreso) throws Exception{


		java.util.Map<String, String> resultadoError = new HashMap<String, String>();
		Map<String,Object> mapRetorno=null;
		HashMap paramDocLiq=new HashMap();

		//PAS20175E220200077 - mtorralba 20170623 - Para saber si la Garant�a fue incluida en la Rectificaci�n
		String incluyeGarantiaEnRecti = variablesIngreso.get("incluyeGarantiaEnRecti")==null ? "N" : variablesIngreso.get("incluyeGarantiaEnRecti").toString();
		
		if(!CollectionUtils.isEmpty(deudadiferencial)){

			//PAS20171U220200005 - mtorralba 20171113 - INICIO- Determina si es TPN21 
			boolean esTPN21 = false;
			for(DatoSerie serie:declaracion.getDua().getListSeries()){		
				if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()!=0){
					esTPN21 = serie.getCodtratprefe()==21;
					break;
				}
			}
			
			paramDocLiq.put("esTPN21",esTPN21); 
			//PAS20171U220200005 - mtorralba 20171113 - FIN 
			
			MovCabliqdilig tmpMovCabliqdilig = (MovCabliqdilig)deudadiferencial.get("movCabliqdilig");
			paramDocLiq.put("codTipLiqui",tmpMovCabliqdilig.getCodTipLiqui()); // Para la numeraci�n en L, para la Rectificaci�n es: E, para la regularizaci�n es G
			paramDocLiq.put("codAduDocliq",tmpMovCabliqdilig.getCodAduDocliq());
			paramDocLiq.put("annDocliq",tmpMovCabliqdilig.getAnnDocliq());
			paramDocLiq.put("codRegDocliq",tmpMovCabliqdilig.getCodRegDocliq());
			paramDocLiq.put("numDocliq",tmpMovCabliqdilig.getNumDocliq());
			paramDocLiq.put("numReliq",tmpMovCabliqdilig.getNumReliq()); // para rectificacion es ustedes es "0" (cero) 
			paramDocLiq.put("codTipdiligencia", tmpMovCabliqdilig.getCodTipdiligencia()); //
			paramDocLiq.put("numCorreDoc", declaracion.getDua().getNumcorredoc()); //
			paramDocLiq.put("annOrden", tmpMovCabliqdilig.getAnnOrden());
			paramDocLiq.put("numOrden", tmpMovCabliqdilig.getNumOrden());
			paramDocLiq.put("codAgente", tmpMovCabliqdilig.getCodAgente());


			HashMap mapCabDeclaraActual=new HashMap();
			mapCabDeclaraActual.put("COD_ADUANA", declaracion.getNumdeclRef().getCodaduana());
			mapCabDeclaraActual.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
			mapCabDeclaraActual.put("NUM_DECLARACION", declaracion.getNumdeclRef().getNumcorre());
			mapCabDeclaraActual.put("caduana", declaracion.getNumdeclRef().getCodaduana());
			mapCabDeclaraActual.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
			mapCabDeclaraActual.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());

			List listaAutoliquidaciones=(List)variablesIngreso.get("lstAutoliquidaciones");

			paramDocLiq.put("diferenciaTributos", deudadiferencial);
			paramDocLiq.put("lstAutoliquidaciones", listaAutoliquidaciones);
			paramDocLiq.put("mapCabDeclaraActual",mapCabDeclaraActual); 
			/*branch ingreso-2011-009 hosorio inicio 22/06/2011*/
			paramDocLiq.put("mapManifiesto",(Map)variablesIngreso.get("mapManifiesto"));
			paramDocLiq.put("existeSaldoGarantiaDiferencialdePercepcion",(Boolean)variablesIngreso.get("existeSaldoGarantiaDiferencialdePercepcion"));
			paramDocLiq.put("declaracion", variablesIngreso.get("declaracion"));
			paramDocLiq.put("declaracionBD", variablesIngreso.get("declaracionBD"));
			paramDocLiq.put("conceptosImputadosRectificacion", variablesIngreso.get("conceptosImputadosRectificacion"));
			/*branch ingreso-2011-009 hosorio fin 22/06/2011*/

			//RPH Rectificacion LC TPI 100 inicio 01/04/2014

			Map montoTPI100 = (Map)variablesIngreso.get("MontoTPI100");
			paramDocLiq.put("MontosTPI100", montoTPI100);
			//RPH Rectificacion LC TPI 100 inicio 01/04/2014

			//INICIO RIN 08 - PECO-Amazonia - Corresponde generar LC 0006
			Map montoLC0006 = (Map)variablesIngreso.get("MontoLC0006");

			//20150214 - Se valida que no sea nulo el mapa //RIN08
			if(montoLC0006 != null && variablesIngreso.get("esPecoAmazonia")!=null){
				montoLC0006.put("esPecoAmazonia",variablesIngreso.get("esPecoAmazonia").toString());
			}
			paramDocLiq.put("MontosLC0006", montoLC0006);
			//MATC 20150331
			paramDocLiq.put("tienePERCEPCION", variablesIngreso.get("tienePERCEPCION"));
			paramDocLiq.put("MontoPercepcion", variablesIngreso.get("MontoPercepcion"));
			//Fin RIN 08

			//Inicio de cambios del PAS20155E220200172 LC con indicador 15 y margen 9
			paramDocLiq.put("montoLC15S9",variablesIngreso.get("montoTPILC15_SI_9"));
			paramDocLiq.put("montoLC15N9",variablesIngreso.get("montoTPILC15_NO_9"));
			//Fin de cambios del PAS20155E220200172

			// funcion de grabacion de adeudo
			LiquidaDeclaracionService liquidaDeclaracionService = (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
			mapRetorno= liquidaDeclaracionService.grabaLiquidacion(paramDocLiq);


			// la impugnacion por ley de emergencia es validado en el servicio de grabaLiquidacion

			//La generacion del LC, segun correspinda ,es generado por el servicio de grabaLiquidacion
		}
		else {
			//PAS20175E220200077 - mtorralba 20170623 - Si la liquidaci�n no ha variado respecto a los montos liquidados previamente, pero reci�n 
			//se est� incluyendo la Garant�a en la rectificaci�n, se cambia la condici�n de la deuda a Garantizada, y se incluyen los documentos 
			//en la cuenta corriente de la Garant�a
			if(incluyeGarantiaEnRecti.equals("S") ) {
				afectarGarantiaEnRectificacion(declaracion);
			}
		}
		return mapRetorno;


	}

	//PAS20175E220200077 - mtorralba 20170623 - Inicio
    private void afectarGarantiaEnRectificacion(Declaracion declaracion) {
    	
		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
		tmpDeudaDocum.setCodEstpago("E");
		DeudaDocumDAO deudaDocumDAO = fabricaDeServicios.getService("deudaDocumDef");
		List<DeudaDocum> listaDeudaDocum= deudaDocumDAO.selectByDocumento(tmpDeudaDocum);

		for( DeudaDocum deudaDocum : listaDeudaDocum ) {
			tmpDeudaDocum = new DeudaDocum();
			tmpDeudaDocum.setNumCorredoc(deudaDocum.getNumCorredoc());
			tmpDeudaDocum.setNumIdentdeuda(deudaDocum.getNumIdentdeuda());
			tmpDeudaDocum.setCodEstadmin("G");
			tmpDeudaDocum.setMtoGarant(deudaDocum.getMtoDeuda());
			deudaDocumDAO.updateByPrimaryKeySelective(tmpDeudaDocum);
		
			String tipoLiquidacion = determinaTipoLiquidacion(deudaDocum);
			Integer fechaExigibilidad = determinaFechaExigibilidad(tipoLiquidacion, deudaDocum );
			Map<String,Object> params = new HashMap<String,Object>();
			String numcda = deudaDocum.getNumCda();
			String codAduana = "";
			String anoPresen = "";
			String codRegimen = "";
			String numDeclaracion = "";
			String numRef = "";
			
			if( !tipoLiquidacion.equals("") ) {
				if( tipoLiquidacion.equals("0000") ) {
					codAduana = declaracion.getNumdeclRef().getCodaduana();
					anoPresen  = declaracion.getNumdeclRef().getAnnprese().substring(2);
					codRegimen = declaracion.getDua().getCodregimen();
					numDeclaracion = String.valueOf(declaracion.getNumeroDeclaracion());
					numRef = declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
					tipoLiquidacion = " ";
				}
				else {
					codAduana = deudaDocum.getCodAduliquida();
					anoPresen  = String.valueOf(deudaDocum.getAnnLiquida()).trim().substring(2);
					codRegimen = "96";
					numDeclaracion = deudaDocum.getNumLiquida();
					numRef = numcda.substring(0, 3).concat("20").concat(numcda.substring(3,13));
				}
					
				params.put("cRUC", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()); // RUC del beneficiario
				params.put("cADUANA",codAduana);
				params.put("cANO", anoPresen);
				params.put("cREGIMEN",codRegimen);
				params.put("cNUMERO",Cadena.padLeft(numDeclaracion, 6, '0'));
				params.put("cNUMREF",numRef);
				params.put("cCDA",numcda);
				params.put("cRUCAGENTE", declaracion.getDua().getNumdocumento() ); // RUC del agente
				params.put("cORDEN",declaracion.getNumorden());
				params.put("nMONTOA", deudaDocum.getMtoDeuda()); // soles  + dolares
				params.put("cMONEDAA", deudaDocum.getCodMoneda().equals("PEN") ? "S" : "D");
				params.put("nFECHA1",fechaExigibilidad);
				params.put("cMODULO","TE");
				params.put("cTRANS","015");
				params.put("nFECNUMERA",SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion()));
				params.put("nFECRECTI",SunatDateUtils.getCurrentIntegerDate());
				params.put("cTIPOLIQ", tipoLiquidacion);
				String resultado = (String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarAfectaCtaCte(params);
				if( resultado!=null && resultado.length()>1 && resultado.substring(0,1).equals("0")) {
					Map<String,Object> erroresOraparams = new HashMap<String,Object>();
					erroresOraparams.put("nombreProcedimiento","PAGARANTIA-GrabarRectificacion");
					erroresOraparams.put("codigoAduana","000");
					erroresOraparams.put("mensajeError","Resultado: " + resultado + " - Parametros: " + params);
					erroresOraparams.put("codigoError","1");
					ErroresOraService erroresOraService = fabricaDeServicios.getService("catalogo.erroresOraService");
					erroresOraService.grabaErroresOra(erroresOraparams);  
				}
			}

		} ///final FOR

		return;
    }

    
    private String determinaTipoLiquidacion(DeudaDocum auxDeudaDocum) {
    	String tipoLC = "";
    	
    	if( auxDeudaDocum.getCodTipdeuda().equals("01") )  tipoLC = "0000";
    	if( auxDeudaDocum.getCodTipdeuda().equals("02") ) {
    		CabDeuda paramsCabDeuda = new CabDeuda();
    		paramsCabDeuda.setNumCorredoc(auxDeudaDocum.getNumCorredoc());
    		paramsCabDeuda.setNumIdentdeuda(auxDeudaDocum.getNumIdentdeuda());

    		CabDeudaDAO cabDeudaDAO = fabricaDeServicios.getService("cabDeudaDef");
    		List<CabDeuda> listaCabDeuda= cabDeudaDAO.selectByDeuda(paramsCabDeuda);
    		
    		for(CabDeuda cabDeuda : listaCabDeuda) {
    			if( cabDeuda.getCodTributo().equals("0096")) {  //Percepcion
    				tipoLC = "0038";
    				break;
    			}
    			if( cabDeuda.getCodTributo().equals("0003")) {  //ISC
    				tipoLC = "0022";
    				break;
    			}

    		} //final FOR
    	} //final codTipDeuda=02 
    	
    	return tipoLC;
    }
    
	private Integer determinaFechaExigibilidad(String tipoLiquidacion, DeudaDocum deudaDocum ) {
		Integer fecha = Integer.valueOf("40000101");
		Integer fechaBase = SunatDateUtils.getIntegerFromDate(deudaDocum.getFecVenc());
		if( !tipoLiquidacion.equals("0038") ) {  //Si no es percepcion
			if( !SunatNumberUtils.isEqual(fechaBase, Integer.valueOf("29991231")) && !SunatNumberUtils.isEqual(fechaBase, Integer.valueOf("39991231")) ) {
				int mes  = Integer.valueOf(String.valueOf(fechaBase).substring(4,6)).intValue();
				int anio = Integer.valueOf(String.valueOf(fechaBase).substring(0,4)).intValue();
				if( mes==12 ) {
					mes = 1;
					anio = anio + 1;
				}
				else mes = mes + 1;
				fecha = Integer.valueOf(String.valueOf(anio).concat(Cadena.padLeft(String.valueOf(mes),2,'0')).concat("21"));
			}
		}
		return fecha;
	}
	//PAS20175E220200077 - mtorralba 20170623 - Final

/*
	public CatalogoAyudaService getCatalogoayudaservice() {
		return catalogoayudaservice;
	}


	public void setCatalogoayudaservice(CatalogoAyudaService catalogoayudaservice) {
		this.catalogoayudaservice = catalogoayudaservice;
	}


	public LiquidaDeclaracionService getLiquidaDeclaracionService() {
		return liquidaDeclaracionService;
	}


	public void setLiquidaDeclaracionService(
			LiquidaDeclaracionService liquidaDeclaracionService) {
		this.liquidaDeclaracionService = liquidaDeclaracionService;
	}

*/
	/*private Object formatearObjeto(Object input) throws Exception{
		if(input instanceof BigDecimal){
			return new Double(((BigDecimal)input).doubleValue()*1000/1000);
		}
		else if(input instanceof java.util.Date){
			return DateUtil.dateToString((Date)input, "dd/MM/yyyy");
		}
		else return input;

	}


	public GrabarDeclaracionService getGrabarDeclaracionService() {
		return grabarDeclaracionService;
	}


	public void setGrabarDeclaracionService(
			GrabarDeclaracionService grabarDeclaracionService) {
		this.grabarDeclaracionService = grabarDeclaracionService;
	}*/


	public String invocarAfectarGarantia(Declaracion declaracion,BigDecimal montoAcumuladoDolares, String cda,Integer fechaConclusionDespacho, 
			String numeroDocumentoIdentidadSender, 
			String modulo, String ctrans,String numref,String numero){

		Map params = new HashMap();
		// RIN16
		//		Map<String, Object> param = new HashMap();
		//		List<Map<String,String>> lstErrores=null;

		params.put("cRUC",declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad()); // RUC del beneficiario
		params.put("cADUANA",declaracion.getNumdeclRef().getCodaduana());
		params.put("cANO",declaracion.getNumdeclRef().getAnnprese().substring(2));
		params.put("cREGIMEN",declaracion.getDua().getCodregimen());
		params.put("cNUMERO",Cadena.padLeft(numero.trim(), 6, '0'));
		params.put("cNUMREF",numref);
		params.put("cCDA",cda);
		params.put("cRUCAGENTE",numeroDocumentoIdentidadSender); // RUC del agente
		//KIB verificar el llenado del campo numOrden
		params.put("cORDEN",declaracion.getNumorden());
		params.put("nMONTOA",montoAcumuladoDolares); // soles  + dolares
		params.put("cMONEDAA","D");
		params.put("nFECHA1",fechaConclusionDespacho);
		params.put("cMODULO",modulo);
		params.put("cTRANS",ctrans);
		/*hosorio inicio 15/05/2011*/
		params.put("nFECNUMERA",SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion()));
		params.put("nFECRECTI",SunatDateUtils.getCurrentIntegerDate());
		/*hosorio fin 15/05/2011*/

		//String resultado=(String)NumeracionServiceImpl.getInstance().getPagarantiaDAO().procesarAfectaCtaCte(params);
		String resultado=(String)((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarAfectaCtaCte(params);
		return resultado;


	}	

	private Integer obtenerFechaGarantiaAdminsioTemporal(Declaracion declaracion){

		/*campo fec_fin de la tabla plazosprocesos pata el cod_tipplz =01 
		y buscar el ultimo para esa dua*/

		Integer fechaConclusionDespacho = null;
		Map<String,Object> params=null;

		if(declaracion.getDua().getCodregimen().equals(Constants.REGIMEN_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO.toString())
				|| declaracion.getDua().getCodregimen().equals(Constants.REGIMEN_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO.toString())
				){
			/*campo fec_fin de la tabla plazosprocesos pata el cod_tipplz =01 
			y buscar el ultimo para esa dua*/
			params=new HashMap<String, Object>();
			params.put("numcorredoc", declaracion.getDua().getNumcorredoc());
			params.put("codtipplz", ConstantesDataCatalogo.PLAZO_AUT_REGIMEN);
			params.put("orderByClauseDesc", "FEC_REGIS");
			PlazosProcesoDAO plazosprocesodao = (PlazosProcesoDAO) fabricaDeServicios.getService("plazosprocesoDAO");
			List<Map<String,Object>> lstResultado=plazosprocesodao.findPlazosProcesoByParams(params);
			if(!CollectionUtils.isEmpty(lstResultado)){
				Map<String,Object> plazoMap=lstResultado.get(0);
				fechaConclusionDespacho= SunatDateUtils.getIntegerFromDate((Date)plazoMap.get("fecFin")) ;
			}				
		}

		return fechaConclusionDespacho;
	}
/*
	public PlazosProcesoDAO getPlazosprocesodao() {
		return plazosprocesodao;
	}


	public void setPlazosprocesodao(PlazosProcesoDAO plazosprocesodao) {
		this.plazosprocesodao = plazosprocesodao;
	}

*/

	public Map<String, String> Grabacabydetsolicitud(Declaracion declaracion
			, SolicitudRectificacionBean solicitudRectificacion,String tipoSolicitud,String estadoSolicitud) throws Exception{

		java.util.Map<String, String> resultadoError = new HashMap<String, String>();// RIN16
		//			List<DetSolicitudRectificacionBean> detalleSolicitud=solicitudRectificacion.getListaCambios();

		Long numcorredoc=declaracion.getDua().getNumcorredoc();
		// grabar el documento

		//Long numCorreDocSolicitud=RectificacionServiceImpl.getInstance().getSequenceDAO().getNextSequence(ConstanteSecuencia.SECUENCIA_CORRELATIVODOCUMENTO);
		Long numCorreDocSolicitud=((SequenceDAO)fabricaDeServicios.getService("sequenceDAO")).getNextSequence(ConstanteSecuencia.SECUENCIA_CORRELATIVODOCUMENTO);

		FechaBean fechaBean = new FechaBean();
		Documento documento=new Documento();
		documento.setNumeroCorrelativo(numCorreDocSolicitud);

		documento.setEstado("00");
		documento.setTipoDocumento(Constants.COD_TIPO_DOC_SOLICITUD_ELECTRONICA); // 3: solicitudes electronicas
		documento.setCodAduana(declaracion.getDua().getCodaduanaorden());
		documento.setFechaGeneracion(fechaBean.getTimestamp());
		//RectificacionServiceImpl.getInstance().getDocumentoDAO().insertSelective(documento);
		((DocumentoDAO)fabricaDeServicios.getService("documentoDAO")).insertSelective(documento);


		// grabar solicitud

		// generar el sequencial de solicitud campo NUMSOL
		String nombreseq="SESOLICITUD"+declaracion.getNumdeclRef().getCodaduana().concat(tipoSolicitud);  // 01 =rectificacion, 11=Regularizacion
		//Long sequenceNumSolicitud = RectificacionServiceImpl.getInstance().getSequenceDAO() 
		Long sequenceNumSolicitud = ((SequenceDAO)fabricaDeServicios.getService("sequenceDAO"))
				.getNextSequence(nombreseq); 
		String secNumSolicitud = sequenceNumSolicitud.toString();

		/*
			01 Iniciado
			02 En Proceso
			03 Concluido*/			
		Map<String, Object> paramsInsert = new HashMap<String, Object>();
		paramsInsert.put("NUMCORREDOC", numCorreDocSolicitud);
		paramsInsert.put("ANNSOL", fechaBean.getAnho());
		paramsInsert.put("NUMSOL", secNumSolicitud);   
		paramsInsert.put("CODREGIMEN", declaracion.getDua().getCodregimen());
		paramsInsert.put("FECSOLICITUD", fechaBean.getTimestamp());

		paramsInsert.put("CODTIPSOL", tipoSolicitud);// 01: Rectificacion, 11: Regularizacion
		paramsInsert.put("CODESTSOL", estadoSolicitud); // 00:Rectificacion Tipos de estados de la solicitud
		paramsInsert.put("CODADUANA", declaracion.getDua().getCodaduanaorden());
		//RectificacionServiceImpl.getInstance().getSolicitudDAO().insertSelectivoSolicitud(paramsInsert);		
		((SolicitudDAO)fabricaDeServicios.getService("solicitudDAO")).insertSelectivoSolicitud(paramsInsert);

		solicitudRectificacion.setNumcorredoc(numCorreDocSolicitud);

		// grabar relacion doc

		Map<String,Object> maprelaciondoc=new HashMap<String, Object>();
		maprelaciondoc.put("numCorredoc", numCorreDocSolicitud);
		maprelaciondoc.put("numCorredocPre", numcorredoc);
		maprelaciondoc.put("annPresen", declaracion.getNumdeclRef().getAnnprese());
		maprelaciondoc.put("codRegimen", declaracion.getNumdeclRef().getCodregimen());
		maprelaciondoc.put("numDeclaracion", declaracion.getNumdeclRef().getNumcorre());
		maprelaciondoc.put("codAduana", declaracion.getDua().getCodaduanaorden());
		// RectificacionServiceImpl.getInstance().getRelaciondocDAO().insertMapSelective(maprelaciondoc);
		((RelacionDocDAO)fabricaDeServicios.getService("relaciondocDAO")).insertMapSelective(maprelaciondoc);


		// grabar solirectifica
		insertCabSolRecti(solicitudRectificacion, declaracion,tipoSolicitud);	    


		//grabar detsolrectifica

		insertDetSolRecti(solicitudRectificacion);

		return resultadoError;
	}


	private void insertCabSolRecti(SolicitudRectificacionBean solicitudRectificacion,Declaracion declaracion,String tipoSolicitud) throws Exception{
		// grabar solirectifica
		Map<String,Object> mapsolirectifica=new HashMap<String, Object>();
		mapsolirectifica.put("numCorredoc", solicitudRectificacion.getNumcorredoc());
		// se obtiene el motivo de la rectificacion , de la seccion de observaciones de la declaracion
		Observacion obsrecti= getObservacionbyTipo(declaracion.getDua(),Constants.COD_TIP_OBSERV_RECTIFICACION);
		String motivoRectificacion=null;
		if(obsrecti!=null)
			motivoRectificacion=obsrecti.getObsdeclaracion();

		mapsolirectifica.put("desMotivrecti", motivoRectificacion); 
		mapsolirectifica.put("codEstarecti", solicitudRectificacion.getCodestarecti());   // 02 PARA ASIGNAR A ESPECIALISTA
		// por ser automatico , la fecha de evaluacion es la fecha actual
		/*hosorio inicio 13/05/2011*/
		//mapsolirectifica.put("fecEvaluacion", SunatDateUtils.getCurrentDate());
		// solo si es automatico la fecha de evaluacion es la Fecha de Procesamiento
		if(SunatStringUtils.isEqualTo(solicitudRectificacion.getCodestarecti(), ConstantesDataCatalogo.COD_EST_RECTIFIC_ACEPTADO_AUTOMATICAMENTE))
		{
			mapsolirectifica.put("fecEvaluacion", SunatDateUtils.getCurrentDate());
		}
		/*hosorio fin 13/05/2011*/
		mapsolirectifica.put("fecSolicitud", SunatDateUtils.getCurrentDate());
		mapsolirectifica.put("codTransaccion", solicitudRectificacion.getCodtransaccion());  // C�digo de transacci�n 03: Rectificaci�n 04: Regularizaci�n Cat�logo 305

		if (tipoSolicitud.equals("01")){//Rectificacion
			mapsolirectifica.put("codcatestado", Constants.COD_CATALOG_ESTADO_SOLI_RECTIFICA);  // cod_catestado  en este caso ponle por default Siempre el valor 363
		}else{// Regularizacion
			mapsolirectifica.put("codcatestado", Constants.COD_CATALOG_ESTADO_SOLI_REGULARIZACION);  // cod_catestado  en este caso ponle por default Siempre el valor 329
		}	    
		//RectificacionServiceImpl.getInstance().getSolirectificaDAO().insertMapSelective(mapsolirectifica);
		((CabSolrectiDAO)fabricaDeServicios.getService("solirectificaDAO")).insertMapSelective(mapsolirectifica);


	}	


	private void insertDetSolRecti(SolicitudRectificacionBean solicitudRectificacion) throws Exception{
		List<DetSolicitudRectificacionBean> detalleSolicitud=solicitudRectificacion.getListaCambios();
		if(!CollectionUtils.isEmpty(detalleSolicitud)){
			int secCambio=0;

			JsonSerializer serializer = new JsonSerializer();
			ObjectUtil util = serializer.getObjectUtil();
			util.addFormatterForType(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"), Date.class);


			// por cada registro(cambio)
			for(DetSolicitudRectificacionBean detalle: detalleSolicitud ){
				secCambio++;
				Map<String,Object> mapDetSolRecti=new HashMap<String, Object>();
				mapDetSolRecti.put("numCorredoc",solicitudRectificacion.getNumcorredoc() );
				mapDetSolRecti.put("numSeccambio", secCambio);
				mapDetSolRecti.put("codTabla",detalle.getCodtabla() );
				Map<String,Object> mpClave=new HashMap<String, Object>();
				Map<String,Object> mpDatos=new HashMap<String, Object>();
				Map<String,Object> mpDatosAnterior=new HashMap<String, Object>();

				mpClave.putAll(detalle.getKey());
				mapDetSolRecti.put("desClave", SojoUtil.toJson(mpClave));
				// generando el json del desdata1 y desAntdata1
				for(String campo: detalle.getDatosRectificados().keySet()){
					// no considerar los datos bloqueados
					DatoRectificacionBean drRec=(DatoRectificacionBean)detalle.getDatosRectificados().get(campo);
					if(StringUtils.hasText(drRec.getFlagBloqueo())){
						continue;
					}
					else{
						Object datoNuevo=formatearObjeto(drRec.getDatoNuevo());
						Object datoAntiguo=formatearObjeto(drRec.getDatoAntiguo());
						mpDatos.put(campo, datoNuevo);
						mpDatosAnterior.put(campo, datoAntiguo);
					}
				}

				//SojoUtil.toJson(mapPkCabDeclaraR)
				if(!mpDatos.isEmpty()){
					//mapDetSolRecti.put("desData1", SojoUtil.toJson(mpDatos));
					mapDetSolRecti.put("desData1", (String) serializer.serialize(util.makeSimple(mpDatos)));
				}
				if(!mpDatosAnterior.isEmpty()){
					//mapDetSolRecti.put("desAntdata1", SojoUtil.toJson(mpDatosAnterior));
					mapDetSolRecti.put("desAntdata1", (String) serializer.serialize(util.makeSimple(mpDatosAnterior)));
				}

				mapDetSolRecti.put("fecIngreso", SunatDateUtils.getCurrentDate());
				// Codigo de el estado del Cambio 00 registrado, 01 aceptado 02 aceptado parcialmenet 03 aceptado totalmente
				mapDetSolRecti.put("codEstcambio", Constants.COD_ESTADO_CAMBIO_REGISTRADO); 
				mapDetSolRecti.put("indRectifica", detalle.getTipoCambio());

				//RectificacionServiceImpl.getInstance().getDetsolrectiDAO().insertMapSelective(mapDetSolRecti);
				((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).insertMapSelective(mapDetSolRecti);

			}
		}	
	}	

	/**
	 * Metodo que ejecuta la actualizacion de los datos de la solicitud de rectificacion , en tablas definitivas
	 * @param declaracion objeto que representa la declaracion rectificada
	 * @param solicitudRectificacion objeto que representa la solicitud de rectificacion
	 * @author hosorio
	 * @return HashMap<String, Object>
	 */
	public Map<String, String> grabaTablaNegocio( Declaracion declaracion,
			SolicitudRectificacionBean solicitudRectificacion, String codTransaccion) throws Exception{

		CatalogoAyudaService catalogoayudaservice = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> resultadoError = new HashMap<String, String>();
		List<DetSolicitudRectificacionBean> detalleSolicitud=solicitudRectificacion.getListaCambios();
		/*- Grabar informaci�n rectificada a las tablas Definitivas*/ 
		if(!CollectionUtils.isEmpty(detalleSolicitud)){
			// por cada detalle de la solicitud
			Collections.sort(detalleSolicitud, new Comparator<DetSolicitudRectificacionBean>() {

				@Override
				public int compare(DetSolicitudRectificacionBean p1, DetSolicitudRectificacionBean p2) {
					return p1.getTipoCambio().compareTo(p2.getTipoCambio());
				}
			});
			for(DetSolicitudRectificacionBean detSolicitud:detalleSolicitud){

				DataCatalogo  datacat= catalogoayudaservice.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_CODIFICACION_TABLAS, detSolicitud.getCodtabla());
				/*  //pase 548 adicionado para DESCRMINIMAS
	       if(detSolicitud.getKey().get("COD_MERCANCIA")!=null && detSolicitud.getKey().get("COD_MERCANCIA").equals("**")){
	    	   detSolicitud.getKey().remove("COD_MERCANCIA");//adicionado por DESCRMINIMAS
	       }*/
				// PAS20191U220500009 20190401 GTP: Se cambia en map key el COD_TABLA de T9833 por T0070 para actualizar en Descrip_otros
				if (detSolicitud.getCodtabla().equals("T9833") && detSolicitud.getKey() != null && detSolicitud.getKey().get("COD_TABLA") != null 
						&& detSolicitud.getKey().get("COD_TABLA").equals("T9833"))
					detSolicitud.getKey().put("COD_TABLA", "T0070");
				
				int countRegAfectado=executeCount(datacat.getDesDatacat().trim(), detSolicitud.getKey());
				if(detSolicitud.getTipoCambio().equals(Constants.IND_REGISTRO_RECTIFICADO)){
					if(countRegAfectado==1  ){
						// realizar update
						Map<String,Object> mapDatos=new HashMap<String, Object>();
						for(String campo:detSolicitud.getDatosRectificados().keySet()){
							DatoRectificacionBean dato=(DatoRectificacionBean)detSolicitud.getDatosRectificados().get(campo);
							mapDatos.put(campo, dato.getDatoNuevo());
						}

						/*branch ingreso 2011 -009 hosorio inicio 14/05/2011*/
						//int rowupdated=executeUpdate(datacat.getDesDatacat().trim(),detSolicitud.getCodtabla(), detSolicitud.getKey(), mapDatos);
						// RIN16
						grabaActualizacion(datacat.getDesDatacat().trim(),detSolicitud.getCodtabla(), detSolicitud.getKey(), mapDatos,declaracion, codTransaccion); //PAS20181U220200056
						/*branch ingreso 2011 -009 hosorio fin 14/05/2011*/
					} 	       
				}
				else if (detSolicitud.getTipoCambio().equals(Constants.IND_REGISTRO_NUEVO)){
					/*Inicio de ajustes por pase42 - bug 21726*/
					int countRegAfectadoItemD = 0;
					if(countRegAfectado==0 && datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_FORMBITEMDESCRI)){
						//se arregla esta parte del codigo mordonezl
						//se  crea el objeto detSolicitudBuscar = new HashMap<String, Object>() para que no afecte a detSolicitud.getKey()
						Map<String,Object> detSolicitudBuscar = new HashMap<String, Object>();
						detSolicitudBuscar.putAll(detSolicitud.getKey()); 
						detSolicitudBuscar.remove("NUM_SECFACT");
						detSolicitudBuscar.remove("NUM_SECPROVE");
						countRegAfectadoItemD=executeCount(datacat.getDesDatacat().trim(), detSolicitudBuscar);
					}
					
					if(countRegAfectado==0 &&  countRegAfectadoItemD==0){
						/*Fin de ajustes por pase42 - bug 21726*/   
						List<String> columns=new ArrayList<String>();
						List<Object> values=new ArrayList<Object>();
						Map<String,Object> mapDatos=new HashMap<String, Object>();
						//agregando la seccion key al insert
						for(String campo:detSolicitud.getKey().keySet()){
							columns.add(campo);
							values.add(detSolicitud.getKey().get(campo));
						}

						// agregando la seccion datos al insert
						for(String campo:detSolicitud.getDatosRectificados().keySet()){
							DatoRectificacionBean dato=(DatoRectificacionBean)detSolicitud.getDatosRectificados().get(campo);
							columns.add(campo);
							values.add(dato.getDatoNuevo());
							mapDatos.put(campo, dato.getDatoNuevo());
						}										
					
						grabaInsercion(datacat.getDesDatacat().trim()
								, detSolicitud.getCodtabla()
								, detSolicitud.getKey()
								, mapDatos, columns, values,declaracion, codTransaccion); //PAS20181U220200056
						actualizarReferencias(detSolicitud);
					}								
					/**Inicio de cambios por bug 19850 pase 548, es nuevo pero existe en bd, se actualiza el indicador**/
					/** r2bz deberia ser para todas las tablas, analizar, por lo pronto se agregar certificados, doc_asociados, convenios, det_autoriz serie**/
					else if(countRegAfectado==1 ) { //&& 
							/*(datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_FORMBITEMDESCRI) || 
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL) || 
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_SERIES_ITEM ) ||
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_ITEMFACTURA ) ||
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_CONVENIOSERIE) ||
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_CERTORIGEN )||
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION) ||
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_DOCASOCIADO) ||
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_SERIES_ITEM ) || 
									datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_INDICADORDUA)
									) ||
							(countRegAfectadoItemD==1 && datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_FORMBITEMDESCRI)) ){//modificado por pase42 - bug 21726 
							*/
						if(countRegAfectadoItemD==0 && datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_FORMBITEMDESCRI)){
							continue;
							//PAS20171U220200005 - desestresando este proceso
							//cuando es nuevo o anulado para esta tabla parte del pk es el NUM_SECFACT y el NUM_SECPROVE
						}
						
						if(!datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL)){
							Map<String,Object> mapDatoExist=new HashMap<String, Object>();							
							if(datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_INDICADORDUA)) {//P_SNADE054-1696 reviviendo indicadores desde el mas alla
								mapDatoExist.put("IND_ACTIVO", Constants.INDICADOR_ACTIVO);
							}else {
								mapDatoExist.put("IND_DEL", Constants.INDICADOR_NO_ELIMINADO);
							}
							//se actualiza a 0 reusando el proceso de eliminacionlogica						
							eliminacionLogica(datacat.getDesDatacat().trim(), detSolicitud.getKey(), mapDatoExist);	
						}
						/*adicionado por bug 19850 - si tiene cambios aparte de que est� eliminado logicamente*/
						Map<String,Object> mapDatosRecti=new HashMap<String, Object>();
						for(String campo:detSolicitud.getDatosRectificados().keySet()){
							DatoRectificacionBean dato=(DatoRectificacionBean)detSolicitud.getDatosRectificados().get(campo);
							mapDatosRecti.put(campo, dato.getDatoNuevo());
						}
						if (!CollectionUtils.isEmpty(mapDatosRecti)) {
							grabaActualizacion(datacat.getDesDatacat().trim(),detSolicitud.getCodtabla(), detSolicitud.getKey(), mapDatosRecti,declaracion, codTransaccion); //PAS20181U220200056
						}
						/*adicionado por bug 19850 - si tiene cambios aparte de que est� eliminado logicamente*/				
					}
					/**Fin de cambios por bug 19850 pase 548**/					

				}
				else if (detSolicitud.getTipoCambio().equals(Constants.IND_REGISTRO_ANULADO)){
					if(countRegAfectado==1  ){
						Map<String,Object> mapDatos=new HashMap<String, Object>();
						if (datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_INDICADORDUA))
							mapDatos.put("IND_ACTIVO", Constants.INDICADOR_NO_ACTIVO);									
						else{
							mapDatos.put("IND_DEL", Constants.INDICADOR_ELIMINADO);
						}// RIN16
						if (!datacat.getCodDatacat().equals(ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL))
							eliminacionLogica(datacat.getDesDatacat().trim(), detSolicitud.getKey(), mapDatos);
					} 	       


				}
			} // fin de for

			// LA SECCION DE INDICADORES SE INGRESA DIRECTAMENTE 
			IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
			//insert indicador_dua
			Map<String,Object> mapIndicadorDUA=new HashMap<String,Object>();
			for(DatoIndicadores indicador:declaracion.getDua().getListIndicadores()){
				//						if(indicador.getCodtipoindica()!= null){
				if(!SunatStringUtils.isEmptyTrim(indicador.getCodtipoindica())){
					//PAS20155E220200155 solo se marca el indicador de importador frecuente en la numeraci�n
					// y cuando se encuentra en el cat�logo de la SUNAT de importadores frecuentes TODO: AFMA eso NO ES CORRECTO
					//region amancillaa SDA2-RIN18-PAS20171U220200035
					if(indicador.getCodtipoindica().equals(ConstantesDataCatalogo.INDICADOR_IMPORTADOR_FRECUENTE)
							|| ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA.equals(indicador.getCodtipoindica())){
						continue;
					}
					//endregion amancillaa

					fillIndicadorDUA(mapIndicadorDUA,declaracion,indicador,declaracion.getDua().getNumcorredoc());
					Map<String,Object> params=new HashMap<String, Object>();
					params.put("num_corredoc", declaracion.getDua().getNumcorredoc());
					params.put("cod_indicador", indicador.getCodtipoindica());
					int existeIndicador = ((BigDecimal) indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(params).get("CANT")).intValue();
					if(existeIndicador==0){
						indicadorDUADAO.insertMapSelective(mapIndicadorDUA);
					}else{
                        //si envian indicador 29 como transmitido debe chancar al indicador 29 Automatico
						if(ConstantesDataCatalogo.INDICADOR_NO_REQUIERE_VALIDACION_MANIFIESTO.equals(indicador.getCodtipoindica())){
							Map<String,Object> mapIndicadoresDUA=new HashMap<String, Object>();
							mapIndicadoresDUA.put("numCorredoc", declaracion.getDua().getNumcorredoc());
							mapIndicadoresDUA.put("codIndicador", indicador.getCodtipoindica());
							mapIndicadoresDUA.put("codTiporegistro", "T");
							mapIndicadoresDUA.put("indActivo", "1");
							indicadorDUADAO.update(mapIndicadoresDUA);
						}
					}								
				}
			}
			
			/**
			 * PAS20181U220200022: 
			 * Se va a comentar todo esto para que sea un metodo externo, mucho codigo que se puede reusar:
			 * usar grabarIndicadorImportadorFrecuente que ahora se puede invocar desde cualquier metodo
			 */
			/*String tipoDocum = "";
            String numeDocum = "";
            boolean indImpFrecuente = false;
			Map<String, Object> MapaModImporFrec =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat("380", "0034",declaracion.getDua().getFecNumeracion());
			if (!CollectionUtils.isEmpty(MapaModImporFrec)){
	            if (SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getTipoParticipante().getCodDatacat(),
	               ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
	             tipoDocum = declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
	             numeDocum = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
	            }
	            if(((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isImportadorFrecuente(declaracion.getDua().getCodregimen().toString(),tipoDocum, numeDocum)){
	            	indImpFrecuente = true;
	            }else {
	    			Map<String, Object> MapaInvitadoOEA =((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat(ConstantesDataCatalogo.CATALOGO_INVITADO_OEA, numeDocum,declaracion.getDua().getFecNumeracion());
	    			if (!CollectionUtils.isEmpty(MapaInvitadoOEA)){
	    				indImpFrecuente = true;
				}					
	         }
			Map<String,Object> mapIndicadoresDUA=new HashMap<String, Object>();
			mapIndicadoresDUA.put("num_corredoc", declaracion.getDua().getNumcorredoc());
			mapIndicadoresDUA.put("cod_indicador", "05");
			int existeIndicador = ((BigDecimal) indicadorDUADAO.existsIndicadorByDocumentoAndCodigo(mapIndicadoresDUA).get("CANT")).intValue();
	            if (indImpFrecuente && declaracion.getDua().getCodmodalidad().equals( ConstantesDataCatalogo.MODA_ANTICIPADA ) ) {
					if(existeIndicador==0){
			            mapIndicadoresDUA.put("numCorredoc", declaracion.getDua().getNumcorredoc());
			            mapIndicadoresDUA.put("codIndicador", "05");
						mapIndicadoresDUA.put("codTiporegistro", "A");
						indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
					}								
	            } else {
					if(existeIndicador > 0){
			            mapIndicadoresDUA.put("numCorredoc", declaracion.getDua().getNumcorredoc());
			            mapIndicadoresDUA.put("codIndicador", "05");
						mapIndicadoresDUA.put("codTiporegistro", "A");
						mapIndicadoresDUA.put("indActivo", "0");
						indicadorDUADAO.update(mapIndicadoresDUA);
					}								
			}	
	            }*/

		} // fin de if
		

		//region amancillaa SDA2-RIN18-PAS20171U220200035
		verificarCambioImportadorOEA(declaracion);
		//endregion amancillaa

		return resultadoError;
	}


	protected void actualizarEnvio(Integer annEnvio, Long numEnvio, Long num_corredoc)
	{
		EnvioDAO envioDAO =  (EnvioDAO)fabricaDeServicios.getService("manifiesto.envioDAO");
		EnvioBean envio = new EnvioBean();
		envio.setAnioEnvio(annEnvio);
		envio.setNumeroEnvio(numEnvio);
		envio.setNumeroCorrelativo(num_corredoc);

		try {
			envioDAO.actualizarEnvio(envio);	
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}


	private void actualizarReferencias(DetSolicitudRectificacionBean detSolicitud){
		CatalogoAyudaService catalogoayudaservice = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if(!CollectionUtils.isEmpty(detSolicitud.getListaReferencias())){
			for(RecordBean r:detSolicitud.getListaReferencias()){

				DataCatalogo  datacat= catalogoayudaservice.getDataCatalogo(ConstantesTipoCatalogo.CATALOGO_TIPO_CODIFICACION_TABLAS, r.getCodtabla());
				Map<String,Object> datos=new HashMap<String, Object>();
				for(String campo:r.getDatos().keySet()){
					String campoRef=(String)r.getDatos().get(campo);
					Object valueRef=detSolicitud.getKey().get(campo);
					datos.put(campoRef, valueRef);
				}
				executeUpdate(datacat.getDesDatacat().trim(), r.getKey(), datos);
			}


		}

	}

	private Object formatearObjeto(Object input) throws Exception{
		/*branch ingreso-2011-009 hosorio 17/06/2011*/
		/*
		if(input instanceof BigDecimal){
			return new Double(((BigDecimal)input).doubleValue()*1000/1000);
		}
		else return input;*/
		return input;
		/*branch ingreso-2011-009 hosorio 17/06/2011*/

	}

	private int executeUpdate(String tableName,Map<String,Object> key , Map<String,Object> datos){
		int rowupdated=0;
		DynamicSentenceBean dynamic=new DynamicSentenceBean(tableName);
		dynamic.getWhereCriteria().addColumValueCriterion(key);
		dynamic.getDataCriteria().addColumValueCriterion(datos);
		//rowupdated=RectificacionServiceImpl.getInstance().getDetsolrectiDAO().updateByDynamicBean(dynamic);
		rowupdated=((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).updateByDynamicBean(dynamic);
		return rowupdated;
	}

	/*hosorio inicio 14/05/2011*/
	//private int executeUpdate(String tableName,String codTabla, Map<String,Object> key , Map<String,Object> datos){
	private int grabaActualizacion(String tableName,String codTabla, Map<String,Object> key , 
			Map<String,Object> datos,Declaracion declaracion, String codTransaccion) //PAS20181U220200056
	{
		DdpDAOService ddpDAOService = (DdpDAOService)fabricaDeServicios.getService("Ayuda.ddpService");
		boolean actualizacionDinamica=false;
		/*branch ingreso 2011-029 hosorio fin 14/05/2011*/
		int rowupdated=0;

		if(codTabla.equals(ConstantesDataCatalogo.TABLA_CAB_DECLARA)){
			executeUpdateCabDeclara(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_IMPCONSUMO)){
			executeUpdateCabAdiImpoConsu(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_CAB_ADI_TRANSITO)){
			//executeUpdateCabAdiTransito(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_CAB_ADI_ADMTEM)){
			executeUpdateCabAdiAmTem(key, datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FINYUBICACION)){
			executeUpdateFinUbicacion(key,datos);
		}			
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DET_DECLARA)){
			executeUpdateDetDeclara(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DETIMPCONSUMO)){
			executeUpdateDetAdiImpoConsu(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DET_ADI_ATREEX)){
			executeUpdateDetAdiAtReex(key, datos);
		}	
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DET_ADI_ATPA)){
			executeUpdateDetAdiAtpa(key, datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_VEHI_CETICO)){
			executeUpdateVehiCetico(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_MONTOGASTO)){
			executeUpdateMontoGasto(key,datos);
		}				
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION)){
			executeUpdateDetAutorizacion(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FACTURA_SERIE)){
			executeUpdateFacturaSerie(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DOCASOCIADO)){
			executeUpdateDocAutAsociado(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FORMA_FACTU)){
			executeUpdateFormAFactu(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DOCUPRECE_DUA)){
			executeUpdateDocuPrecedeDua(key, datos);
		}				
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_CERTORIGEN)){
			executeUpdateCabCertiOrigen(key, datos);
			RegistroUsoCertificadoOrigenElectronico(datos, declaracion, codTransaccion);//PAS20181U220200056
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_COMPROBPAGO)){
			executeUpdateComprobPago(key, datos);
		}

		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBPROVEEDOR)){
			executeUpdateFormbProveedor(key, datos);
		}		
		else if(codTabla.equals(TABLA_DESCRIP_OTROS)){ // PAS20191U220500009 JCV
			executeUpdateDescrip_otros(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_CONDICION_TRANSA)){
			executeUpdateCondicionTransa(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FACTUSUCE)){
			executeUpdateFactuSuce(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_ITEMFACTURA)){
			executeUpdateItemFactura(key,datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL)){
			executeUpdateFobProvisional(key,datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBITEMDESCRI)){
			executeUpdateFormBItemDescri(key, datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_SERIES_ITEM)){
			executeUpdateSeriesItem(key,datos);
		}			
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBMONTO)){
			executeUpdateFormBMonto(key,datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_EQUIPAMIENTO)){
			executeUpdateEquipamiento(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_MOVEQUIPAMIENTO)){
			executeUpdateMovEquipamiento(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_PRECINTO)){
			executeUpdatePrecinto(key,datos);
		}


		/*branch ingreso 2011-009 hosorio 21/07/2011*/
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC)){
			actualizacionDinamica=true;

			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "31")){
				datos.put("COD_TIPDOC","4"); 
				Map rptaRuc=new HashMap();
				//r2bz rptaRuc=RectificacionServiceImpl.getInstance().getDdpDAO().findByPK((String)key.get("NUM_DOCIDENT"));					
				//					rptaRuc=RectificacionServiceImpl.getInstance().getDdpDAO().findByPK((String)datos.get("NUM_DOCIDENT"));
				rptaRuc=ddpDAOService.findByPK((String)datos.get("NUM_DOCIDENT"));
				if (rptaRuc!=null){
					datos.put("NOM_RAZONSOCIAL",rptaRuc.get("ddp_nombre").toString());
				}	
				else
					datos.put("NOM_RAZONSOCIAL"," ");
			}

			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "32")){
				datos.put("COD_TIPDOC","4"); 
				Map rptaRuc=new HashMap();
				//r2bz rptaRuc=RectificacionServiceImpl.getInstance().getDdpDAO().findByPK((String)key.get("NUM_DOCIDENT"));
				//					rptaRuc=RectificacionServiceImpl.getInstance().getDdpDAO().findByPK((String)datos.get("NUM_DOCIDENT"));
				rptaRuc=ddpDAOService.findByPK((String)datos.get("NUM_DOCIDENT"));
				if (rptaRuc!=null){
					datos.put("NOM_RAZONSOCIAL",rptaRuc.get("ddp_nombre").toString());
				}	
				else
					datos.put("NOM_RAZONSOCIAL"," ");

			}
			FormBProveedorDAO formBProveedorDAO = (FormBProveedorDAO) fabricaDeServicios.getService("formBProveedorDAO");
			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "92")){
				actualizacionDinamica=true;
				for(DAV dav:declaracion.getListDAVs()){
					if(dav.getPersonaDecl().getNumeroDocumentoIdentidad() !=null && SunatStringUtils.isEqualTo(dav.getPersonaDecl().getNumeroDocumentoIdentidad(), 
							(String)datos.get("NUM_DOCIDENT"))){//corregido arey SAU201510002900041 

						Map<String,Object> params=new HashMap<String, Object>();
						params.put("NUM_CORREDOC",key.get("NUM_CORREDOC").toString());//corregido arey SAU201510002900041 
						params.put("NUM_SECPROVE",dav.getNumsecuprov());
						List<Map<String,Object>> lstFormPrB= formBProveedorDAO.select(params);
						Map<String,Object> mpFormProb=lstFormPrB.get(0);

						key.put("NUM_SECPARTIC", mpFormProb.get("NUM_SECDECLARANTE").toString());


					}
				}

			}

			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "90")){
				actualizacionDinamica=true;
				for(DAV dav:declaracion.getListDAVs()){
					if(dav.getIntermediario().getNumeroDocumentoIdentidad() !=null && SunatStringUtils.isEqualTo(dav.getIntermediario().getNumeroDocumentoIdentidad(), 
							(String)key.get("NUM_DOCIDENT"))){

						Map<String,Object> params=new HashMap<String, Object>();
						params.put("NUM_CORREDOC",(String)key.get("NUM_CORREDOC"));
						params.put("NUM_SECPROVE",dav.getNumsecuprov());
						List<Map<String,Object>> lstFormPrB= formBProveedorDAO.select(params);
						Map<String,Object> mpFormProb=lstFormPrB.get(0);

						key.put("NUM_SECPARTIC", mpFormProb.get("NUM_SECINTERMEDIARIO").toString());


					}
				}

			}

			/**ADICIONADO POR SAU20153K005000016**/
			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "45")){
				datos.put("COD_TIPDOC","4"); 
				Map rptaRuc=new HashMap();
				String direccion=" ";
				rptaRuc=ddpDAOService.findByPK((String)datos.get("NUM_DOCIDENT"));
				if (rptaRuc!=null){
					datos.put("NOM_RAZONSOCIAL",rptaRuc.get("ddp_nombre").toString());
					direccion=ddpDAOService.getDomicilioLegal((String)rptaRuc.get("ddp_numruc"));

					//actualizacion de direccion en tab_participante
					if(direccion==null){
						datos.put("NOM_RAZONSOCIAL"," ");
					}else{
						if (!SunatStringUtils.isEmptyTrim(direccion)){
							direccion=direccion.trim();
							if (SunatStringUtils.length(direccion)>60){
								direccion=direccion.substring(0, 60);
							}
							datos.put("DIR_PARTIC", direccion);			
						}else{
							datos.put("DIR_PARTIC", " ");	
						}
					}

					//region amancillaa SDA2-RIN18-PAS20171U220200035
					//se cambia de sitio quieren que se verifique si es oea siempre verificarCambioImportadorOEA(datos, declaracion);
					//endregion amancillaa

				}
			}
			/**ADICIONADO POR SAU20153K005000016**/

			/**PAS20165E220200148**/
			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "12")){
				datos.put("COD_TIPDOC","4"); 
				Map rptaRuc=new HashMap();
				String direccion=" ";
				rptaRuc=ddpDAOService.findByPK((String)datos.get("NUM_DOCIDENT"));
				if (rptaRuc!=null){
					datos.put("NOM_RAZONSOCIAL",rptaRuc.get("ddp_nombre").toString());
					direccion=ddpDAOService.getDomicilioLegal((String)rptaRuc.get("ddp_numruc"));

					//actualizacion de direccion en tab_participante
					if(direccion==null){
						datos.put("NOM_RAZONSOCIAL"," ");
					}else{
						if (!SunatStringUtils.isEmptyTrim(direccion)){
							direccion=direccion.trim();
							if (SunatStringUtils.length(direccion)>60){
								direccion=direccion.substring(0, 60);
							}
							datos.put("DIR_PARTIC", direccion);			
						}else{
							datos.put("DIR_PARTIC", " ");	
						}
					}
				}
			}

			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "93")){

			}


		}
		else {
			actualizacionDinamica=true;
		}


		//else{
		if(actualizacionDinamica){
			/*branch ingreso 2011-009 hosorio 21/07/2011*/	
			DynamicSentenceBean dynamic=new DynamicSentenceBean(tableName);
			dynamic.getWhereCriteria().addColumValueCriterion(key);
			dynamic.getDataCriteria().addColumValueCriterion(datos);
			//rowupdated=RectificacionServiceImpl.getInstance().getDetsolrectiDAO().updateByDynamicBean(dynamic);
			rowupdated=((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).updateByDynamicBean(dynamic);
		}
		return rowupdated;
	}	

	//private void verificarCambioImportadorOEA(Map<String, Object> datos, Declaracion declaracion) {
	private void verificarCambioImportadorOEA(Declaracion declaracion) {
		//String numRuc  = (String)datos.get("NUM_DOCIDENT");
		String numRuc  = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
		Map<String,Object> filter = new HashMap<String, Object>();
		filter.put("num_corredoc", declaracion.getDua().getNumcorredoc());
		filter.put("cod_indicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);

		//solo activo regimen 10,20,21 igual que importador frecuente
		if("70".equals(declaracion.getDua().getCodregimen())){
		 return;
		}
		
		IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
		DatoIndicadores indicador = indicadorDUADAO.obtenerIndicadorDeclaracion(filter);

		if(((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).isOEA(numRuc,declaracion.getDua().getFecdeclaracion())){

            if(indicador==null ){
                Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
                mapIndicadoresDUA.put("numCorredoc", declaracion.getDua().getNumcorredoc());
                mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
                mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_AUTOMATICO);

                indicadorDUADAO.insertMapSelective(mapIndicadoresDUA);
            }else{
				if (ConstantesDataCatalogo.IND_INACTIVO.equals(indicador.getIndicadorActivo())){

					Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
					mapIndicadoresDUA.put("numCorredoc",declaracion.getDua().getNumcorredoc());
					mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
					mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_AUTOMATICO);
					mapIndicadoresDUA.put("indActivo",ConstantesDataCatalogo.IND_ACTIVO);
					indicadorDUADAO.update(mapIndicadoresDUA);
				}
            }
        }else{
			if(indicador!=null && ConstantesDataCatalogo.IND_ACTIVO.equals(indicador.getIndicadorActivo())){

				Map<String,Object> mapIndicadoresDUA = new HashMap<String, Object>();
				mapIndicadoresDUA.put("numCorredoc",declaracion.getDua().getNumcorredoc());
				mapIndicadoresDUA.put("codIndicador", ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA);
				mapIndicadoresDUA.put("codTiporegistro", ConstantesDataCatalogo.COD_TIPOREGISTRO_AUTOMATICO);
				mapIndicadoresDUA.put("indActivo",ConstantesDataCatalogo.IND_INACTIVO);
				indicadorDUADAO.update(mapIndicadoresDUA);
			}
		}
	}


	private int executeCount(String tableName,Map<String,Object> key ){
		DynamicSentenceBean dynamic=new DynamicSentenceBean(tableName);
		dynamic.getWhereCriteria().addColumValueCriterion(key);
		//int countRegAfectado=RectificacionServiceImpl.getInstance().getDetsolrectiDAO().countByDinamicBean(dynamic);
		int countRegAfectado=((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).countByDinamicBean(dynamic);
		return countRegAfectado;

	}


	private void executeInsert(String tableName,List<String> columns,List<Object> values ){
		DynamicSentenceBean dynamic=new DynamicSentenceBean(tableName);
		for (int i = 0; i < columns.size(); i++) {
			dynamic.getIntoCriteria().addCriterion("column",columns.get(i));
			dynamic.getValuesCriteria().addCriterion("value",values.get(i));
		}

		// se ejecuta el insert de la solicitud
		//RectificacionServiceImpl.getInstance().getDetsolrectiDAO().insertByDinamicBean(dynamic);((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO"))
		((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).insertByDinamicBean(dynamic);
	}
/*
	public GeneraRespuestaService getGenRespuestaService() {
		return genRespuestaService;
	}


	public void setGenRespuestaService(GeneraRespuestaService genRespuestaService) {
		this.genRespuestaService = genRespuestaService;
	}


	public GrabarGeneralService getGrabarGeneralService() {
		return grabarGeneralService;
	}


	public void setGrabarGeneralService(GrabarGeneralService grabarGeneralService) {
		this.grabarGeneralService = grabarGeneralService;
	}


	public EnvioDAO getEnvioDAO() {
		return envioDAO;
	}


	public void setEnvioDAO(EnvioDAO envioDAO) {
		this.envioDAO = envioDAO;
	}*/


	private int eliminacionLogica(String tableName,Map<String,Object> key , Map<String,Object> datos){
		int rowupdated=0;
		try {
			rowupdated=executeUpdate(tableName,key, datos);

		} catch (Exception e) {
			// TODO: handle exception
			// posible error por la no existencia del indicador IND_DEL de eliminacion
			e.printStackTrace();
		}
		return rowupdated;

	}

	private void grabarPagoAutoliquidacion(Declaracion declaracion, Map<String, Object> variablesIngreso){

		DatoOtroDocSoporte soporteLiqui= getDocSoporteByTypoProceso(declaracion.getDua(), ConstantesDataCatalogo.TIPO_DOC_AUTOLIQUIDACION);
		Liquida tmpLiquida = new Liquida();
		tmpLiquida.setRladuana(declaracion.getDua().getCodaduanaorden());
		tmpLiquida.setRlano(soporteLiqui.getAnndocasoc().toString().substring(2, 4));
		tmpLiquida.setRlnroliq(soporteLiqui.getNumdocasoc());
		tmpLiquida.setRltipliq("0026");

		//List<Liquida>  lstAutoliquidacion =RectificacionServiceImpl.getInstance().getLiquidaDAO().selectSelectivo(tmpLiquida);
		List<Liquida>  lstAutoliquidacion =((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).selectSelectivo(tmpLiquida);
		if(!CollectionUtils.isEmpty(lstAutoliquidacion)){
			DetPagoDuaDAO detPagoduaDAO = (DetPagoDuaDAO)fabricaDeServicios.getService("detPagoDuaDef");
			Liquida liquida=lstAutoliquidacion.get(0);

			DetPagodua tmpDetPagodua = new DetPagodua();
			tmpDetPagodua.setNumCorredoc(declaracion.getDua().getNumcorredoc());
			Long secPagos = Long.valueOf("1").longValue();
			List lstPagos = detPagoduaDAO.selectByDocumento(tmpDetPagodua);
			if (lstPagos!=null) {
				Integer sec = lstPagos.size()+1;
				secPagos = Long.valueOf(sec.toString()).longValue();
			}

			// Se obtiene secuencia de deuda.
			DeudaDocum tmpDeudaDocum = new DeudaDocum();
			tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
			//List<DeudaDocum> tmpListDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
			List<DeudaDocum> tmpListDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDAO")).selectByDocumento(tmpDeudaDocum);
			Integer lnNum_identDeuda = 1;
			lnNum_identDeuda = tmpListDeudaDocum.size()+1;



			DetPagodua detPagodua = new DetPagodua();
			detPagodua.setNumSecpago(secPagos);
			detPagodua.setNumCorredoc(declaracion.getDua().getNumcorredoc());
			detPagodua.setNumIdentdeuda(lnNum_identDeuda);
			detPagodua.setCodTipodocpag("03"); // autoliquidacion
			detPagodua.setCodFormpago(liquida.getRlformcan());
			detPagodua.setMtoPagado(liquida.getRlcodmon().equals("S")?liquida.getRlsmontot():liquida.getRldmontot());
			detPagodua.setFecPago(new FechaBean(liquida.getRlfeccan().toString(), "yyyyMMdd").getSQLDate());
			detPagodua.setCodMoneda(liquida.getRlcodmon().equals("S")?"PEN":"USD");
			detPagodua.setCodBcopago(liquida.getRlbcocan());
			detPagodua.setCodTipcance(liquida.getRltipcan().toString());
			if (liquida.getRlfeccon()>0) {
				detPagodua.setFecConta(new FechaBean(liquida.getRlfeccon().toString(), "yyyyMMdd").getSQLDate());
			} else {
				detPagodua.setFecConta(new FechaBean("00010101", "yyyyMMdd").getSQLDate());
			}
			detPagodua.setFecExtorno(new FechaBean("00010101", "yyyyMMdd").getSQLDate());
			detPagodua.setAnnLiquida(Integer.valueOf("20"+liquida.getRlano()));
			detPagodua.setCodAduliquida(liquida.getRladuana());
			detPagodua.setNumLiquida(liquida.getRlnroliq());

			String lcUsu_modif=(String)variablesIngreso.get("codUsuario");
			detPagodua.setCodUsuregis(lcUsu_modif);
			detPagodua.setFecRegis(new FechaBean().getSQLDate());
			detPagodua.setCodUsumodif(lcUsu_modif);
			detPagodua.setFecModif(new FechaBean().getSQLDate());
			DetPagodua tmpDetPagodua2 = detPagoduaDAO.selectByPrimaryKey(secPagos);
			if (tmpDetPagodua2==null) {
				detPagoduaDAO.insert(detPagodua);
			} else {
				detPagoduaDAO.updateByPrimaryKey(detPagodua);
			}


		}

	}

/*
	public DetPagoDuaDAO getDetPagoduaDAO() {
		return detPagoduaDAO;
	}


	public void setDetPagoduaDAO(DetPagoDuaDAO detPagoduaDAO) {
		this.detPagoduaDAO = detPagoduaDAO;
	}


	public DeudaDocumDAO getDeudaDocumDAO() {
		return deudaDocumDAO;
	}


	public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
		this.deudaDocumDAO = deudaDocumDAO;
	}*/

	private void executeUpdateCabDeclara(Map<String,Object> key , Map<String,Object> datos){
		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		cabDeclaraDAO.update(mapUpdate);

	}

	private void executeUpdateCabAdiImpoConsu(Map<String,Object> key , Map<String,Object> datos){
		CabAdjImpoconsuDAO cabAdjImpoconsuDAO = (CabAdjImpoconsuDAO)fabricaDeServicios.getService("cabAdjImpoconsuDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		cabAdjImpoconsuDAO.update(mapUpdate);


	}
/*
	private void executeUpdateCabAdiTransito(Map<String,Object> key , Map<String,Object> datos){		
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		cabAdjTransitoDAO.updateSelective(mapUpdate);
	}	
*/
	private void executeUpdateCabAdiAmTem(Map<String,Object> key , Map<String,Object> datos){
		CabAdjAtpaDAO cabAdjAtpaDAO = (CabAdjAtpaDAO) fabricaDeServicios.getService("cabAdjAtpaDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		cabAdjAtpaDAO.update(mapUpdate);
	}		


	private void executeUpdateFinUbicacion(Map<String,Object> key , Map<String,Object> datos){
		FinUbicacionDAO finUbicacionDAO = (FinUbicacionDAO) fabricaDeServicios.getService("finUbicacionDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		finUbicacionDAO.update(mapUpdate);
	}			

	private void executeUpdateDetDeclara(Map<String,Object> key , Map<String,Object> datos){
		DetDeclaraDAO detDeclaraDAO = (DetDeclaraDAO) fabricaDeServicios.getService("detDeclaraDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		detDeclaraDAO.update(mapUpdate);

	}	

	private void executeUpdateDetAdiImpoConsu(Map<String,Object> key , Map<String,Object> datos){
		DetAdiImpoconsuDAO detAdiImpoconsuDAO = (DetAdiImpoconsuDAO) fabricaDeServicios.getService("detAdiImpoconsuDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		detAdiImpoconsuDAO.update(mapUpdate);
	}		

	private void executeUpdateDetAdiAtReex(Map<String,Object> key , Map<String,Object> datos){
		DetAdiAtreexDAO detAdiAtreexDAO = (DetAdiAtreexDAO) fabricaDeServicios.getService("detAdiAtreexDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		detAdiAtreexDAO.update(mapUpdate);
	}		

	private void executeUpdateDetAdiAtpa(Map<String,Object> key , Map<String,Object> datos){
		DetAdiAtpaDAO detAdiAtpaDAO = (DetAdiAtpaDAO) fabricaDeServicios.getService("detAdiAtpaDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		detAdiAtpaDAO.updateSelective(mapUpdate);
	}			

	private void executeUpdateVehiCetico(Map<String,Object> key , Map<String,Object> datos){
		VehiCeticoDAO vehiCeticoDAO = (VehiCeticoDAO) fabricaDeServicios.getService("vehiCeticoDAO"); 
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		String perPubli=(String) datos.get("PER_PUBLI");
		if (perPubli == null || perPubli.trim().isEmpty()){
			mapUpdate.put("PER_PUBLI", 0);
		}
		vehiCeticoDAO.updateSelective(mapUpdate);
	}

	private void executeUpdateMontoGasto(Map<String,Object> key , Map<String,Object> datos){
		MontoGastoDAO montoGastoDAO = (MontoGastoDAO) fabricaDeServicios.getService("montoGastoDAO"); 
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		montoGastoDAO.updateSelective(mapUpdate);
	}			

	private void executeUpdateDetAutorizacion(Map<String,Object> key , Map<String,Object> datos){
		DetAutorizacionDAO detAutorizacionDAO = (DetAutorizacionDAO) fabricaDeServicios.getService("detAutorizacionDAO"); 
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).
		actualizarDocAutRectificacion(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, key, datos, Constants.IND_REGISTRO_ANULADO);
		detAutorizacionDAO.update(mapUpdate);
		((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).
		actualizarDocAutRectificacion(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, key, datos, Constants.IND_REGISTRO_NUEVO);

	}		

	private void executeUpdateFacturaSerie(Map<String,Object> key , Map<String,Object> datos){
		FacturaSerieDAO facturaSerieDAO = (FacturaSerieDAO) fabricaDeServicios.getService("facturaSerieDAO"); 
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		facturaSerieDAO.updateSelective(mapUpdate) ;
	}

	private void executeUpdateDocAutAsociado(Map<String,Object> key , Map<String,Object> datos){
		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).
		actualizarDocAutRectificacion(ConstantesDataCatalogo.TABLA_DOCASOCIADO, key, datos, Constants.IND_REGISTRO_ANULADO);
		((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).
		actualizarDocAutRectificacion(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, key, datos, Constants.IND_REGISTRO_ANULADO);
		docAutAsociadoDAO.update(mapUpdate);
		((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).
		actualizarDocAutRectificacion(ConstantesDataCatalogo.TABLA_DOCASOCIADO, key, datos, Constants.IND_REGISTRO_NUEVO);
		((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).
		actualizarDocAutRectificacion(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, key, datos, Constants.IND_REGISTRO_NUEVO);

	}


	private void executeUpdateDocuPrecedeDua(Map<String,Object> key , Map<String,Object> datos){
		DocuPreceDuaDAO docuPreceDuaDAO = (DocuPreceDuaDAO) fabricaDeServicios.getService("docuPreceDuaDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		docuPreceDuaDAO.update(mapUpdate);
	}

	private void executeUpdateCabCertiOrigen(Map<String,Object> key , Map<String,Object> datos){
		CabCertiOrigenDAO cabCertiOrigenDAO = (CabCertiOrigenDAO) fabricaDeServicios.getService("cabCertiOrigenDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		cabCertiOrigenDAO.update(mapUpdate);
		//r2bz PASE 459	 descomentado bug 20605 pas 399 //NOOO DESCOMENTAR, GENERA ERRORES 24 verificar comparador para actualizar docAutAsociado PASE 490
		//		mapUpdate.put("COD_TIPDOCASO", datos.get("COD_TIPDOCASO"));
		//
		//		Integer annDoc=SunatDateUtils.getAnho((Date)datos.get("FEC_CERTIFICADO"));
		//		if (annDoc.intValue()!=0)
		//			mapUpdate.put("ANN_DOC", annDoc);
		//		mapUpdate.put("NUM_DOC", datos.get("NUM_CERTIFICADO"));
		//		mapUpdate.put("FEC_EMIS", datos.get("FEC_CERTIFICADO"));
		//		docAutAsociadoDAO.update(mapUpdate);
		//fin bug 20605 pas 399
	}		

	private void executeUpdateComprobPago(Map<String,Object> key , Map<String,Object> datos){
		ComprobPagoDAO comprobPagoDAO = (ComprobPagoDAO) fabricaDeServicios.getService("comprobPagoDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		comprobPagoDAO.updateSelective(mapUpdate);
	}		



	private void executeUpdateFormAFactu(Map<String,Object> key , Map<String,Object> datos){
		FormaFactuDAO formaFactuDAO = (FormaFactuDAO) fabricaDeServicios.getService("formaFactuDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		formaFactuDAO.update(mapUpdate) ;
	}		


	private void executeUpdateFormbProveedor(Map<String,Object> key , Map<String,Object> datos){
		FormBProveedorDAO formBProveedorDAO = (FormBProveedorDAO) fabricaDeServicios.getService("formBProveedorDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		formBProveedorDAO.updateSelective(mapUpdate);
	}

	// PAS20191U220500009 20190327 GTP
	private void executeUpdateDescrip_otros(Map<String,Object> key , Map<String,Object> datos){
		DescripOtrosDAO descripOtrosDAO = (DescripOtrosDAO) fabricaDeServicios.getService("descripOtrosDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		descripOtrosDAO.updateSelective(mapUpdate);
	}

	private void executeUpdateCondicionTransa(Map<String,Object> key , Map<String,Object> datos){
		CondicionTransaDAO condicionTransaDAO = (CondicionTransaDAO) fabricaDeServicios.getService("condicionTransaDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		condicionTransaDAO.updateSelective(mapUpdate);
	}		

	private void executeUpdateFactuSuce(Map<String,Object> key , Map<String,Object> datos){
		FactuSuceDAO factuSuceDAO = (FactuSuceDAO) fabricaDeServicios.getService("factuSuceDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		factuSuceDAO.updateSelective(mapUpdate);
	}

	private void executeUpdateItemFactura(Map<String,Object> key , Map<String,Object> datos){
		ItemFacturaDAO itemFacturaDAO = (ItemFacturaDAO) fabricaDeServicios.getService("itemFacturaDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		itemFacturaDAO.update(mapUpdate);
	}

	private void executeUpdateFobProvisional(Map<String,Object> key , Map<String,Object> datos){
		VFOBProvisionalDAO fobProvisionalDAO = (VFOBProvisionalDAO) fabricaDeServicios.getService("fobProvisionalDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		fobProvisionalDAO.updateMapSelective(mapUpdate);
	}				

	private void executeUpdateFormBItemDescri(Map<String,Object> key , Map<String,Object> datos){
		FormBItemDescriDAO formBItemDescriDAO = (FormBItemDescriDAO) fabricaDeServicios.getService("formBItemDescriDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		mapUpdate.put("rectificacion", "SI");//PAS20171U220200016: para que no tome NUM_SECFACT ni NUM_SECPROVE de Pk, porque no lo son
		formBItemDescriDAO.updateSelective(mapUpdate);
	}		

	private void executeUpdateSeriesItem(Map<String,Object> key , Map<String,Object> datos){
		SeriesItemDAO seriesItemDAO = (SeriesItemDAO) fabricaDeServicios.getService("seriesItemDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		seriesItemDAO.update(mapUpdate);
	}

	private void executeUpdateFormBMonto(Map<String,Object> key , Map<String,Object> datos){
		FormBMontoDAO formBMontoDAO = (FormBMontoDAO) fabricaDeServicios.getService("formBMontoDAO");
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		formBMontoDAO.updateSelective(mapUpdate);
	}

	private void executeUpdateEquipamiento(Map<String,Object> key , Map<String,Object> datos){
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		EquipamientoDAO equipamientoDAO = (EquipamientoDAO)fabricaDeServicios.getService("manifiesto.equipamientoDAO");	
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		equipamientoDAO.updateSelective(mapUpdate);
	}		

	private void executeUpdateMovEquipamiento(Map<String,Object> key , Map<String,Object> datos){
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		MovEquipamientoDAO movEquipamientoDAO = (MovEquipamientoDAO)fabricaDeServicios.getService("manifiesto.movEquipamientoDAO");
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		movEquipamientoDAO.updateSelective(mapUpdate);
	}		

	private void executeUpdatePrecinto(Map<String,Object> key , Map<String,Object> datos){
		Map<String,Object> mapUpdate=new HashMap<String, Object>();
		PrecintoDAO precintoDAO = (PrecintoDAO)fabricaDeServicios.getService("manifiesto.precintoDAO");
		mapUpdate.putAll(key);
		mapUpdate.putAll(datos);
		precintoDAO.updateSelective(mapUpdate);
	}		

	private void executeInsertComprobPago(Map<String,Object> key , Map<String,Object> datos){
		ComprobPagoDAO comprobPagoDAO = (ComprobPagoDAO) fabricaDeServicios.getService("comprobPagoDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		comprobPagoDAO.insertSelective(mapInsert);
	}		


	private void executeInsertSerieItem(Map<String,Object> key , Map<String,Object> datos){
		SeriesItemDAO seriesItemDAO = (SeriesItemDAO) fabricaDeServicios.getService("seriesItemDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		seriesItemDAO.insertSelective(mapInsert);
	}		

	private void executeInsertFormBMonto(Map<String,Object> key , Map<String,Object> datos){
		FormBMontoDAO formBMontoDAO = (FormBMontoDAO) fabricaDeServicios.getService("formBMontoDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		formBMontoDAO.insertSelective(mapInsert);
	}

	private void executeInsertEquipamiento(Map<String,Object> key , Map<String,Object> datos, Declaracion declaracion){
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		EquipamientoDAO equipamientoDAO = (EquipamientoDAO)fabricaDeServicios.getService("manifiesto.equipamientoDAO");		
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		mapInsert.put("ANN_MANIFIESTO", declaracion.getDua().getManifiesto().getAnnmanif().substring(0,4));
		mapInsert.put("COD_ADUANA", declaracion.getDua().getManifiesto().getCodaduamanif());
		mapInsert.put("NUM_MANIFIESTO", SunatStringUtils.lpad(declaracion.getDua().getManifiesto().getNummanif(),6,' '));
		mapInsert.put("COD_TIP_MANIFIESTO", declaracion.getDua().getManifiesto().getCodtipomanif());
		mapInsert.put("COD_VIA", declaracion.getDua().getManifiesto().getCodmodtransp());
		equipamientoDAO.insertSelective(mapInsert);
	}		

	private void executeInsertMovEquipamiento(Map<String,Object> key , Map<String,Object> datos){
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		MovEquipamientoDAO movEquipamientoDAO = (MovEquipamientoDAO)fabricaDeServicios.getService("manifiesto.movEquipamientoDAO");		
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		movEquipamientoDAO.insertSelective(mapInsert);
	}		

	private void executeInsertPrecinto(Map<String,Object> key , Map<String,Object> datos){
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		PrecintoDAO precintoDAO = (PrecintoDAO)fabricaDeServicios.getService("manifiesto.precintoDAO");		
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		precintoDAO.insertSelective(mapInsert);
	}		


	private void executeInsertFormBItemDescri(Map<String,Object> key , Map<String,Object> datos){
		FormBItemDescriDAO formBItemDescriDAO = (FormBItemDescriDAO) fabricaDeServicios.getService("formBItemDescriDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		formBItemDescriDAO.insertSelective(mapInsert);
	}				


	private void executeInsertDetDeclara(Map<String,Object> key , Map<String,Object> datos){
		DetDeclaraDAO detDeclaraDAO = (DetDeclaraDAO) fabricaDeServicios.getService("detDeclaraDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		detDeclaraDAO.insertSelective(mapInsert);

	}	

	private void executeInsertFobProvisional(Map<String,Object> key , Map<String,Object> datos){
		VFOBProvisionalDAO fobProvisionalDAO = (VFOBProvisionalDAO) fabricaDeServicios.getService("fobProvisionalDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		fobProvisionalDAO.insertMapSelective(mapInsert);

	}		

	/*inicio PAS20171U220200005*/
	private void executeInsertCabAdiImpoConsu(Map<String,Object> key , Map<String,Object> datos){
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		CabAdiImpoConsuDAO cabAdiImpoconsuDAO = fabricaDeServicios.getService("diligencia.rectificacion.cabAdiImpoConsuDef_xa");    	  
		cabAdiImpoconsuDAO.insertMapSelective(mapInsert); 
	}
	/*fin PAS20171U220200005*/
	private void executeInsertDetAdiImpoConsu(Map<String,Object> key , Map<String,Object> datos){
		DetAdiImpoconsuDAO detAdiImpoconsuDAO = (DetAdiImpoconsuDAO) fabricaDeServicios.getService("detAdiImpoconsuDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		detAdiImpoconsuDAO.insertSelective(mapInsert);
	}


	private void executeInsertDetAdiAtpa(Map<String,Object> key , Map<String,Object> datos){
		DetAdiAtpaDAO detAdiAtpaDAO = (DetAdiAtpaDAO) fabricaDeServicios.getService("detAdiAtpaDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		detAdiAtpaDAO.insertSelective(mapInsert);
	}		

	private void executeInsertDetAdiAttReex(Map<String,Object> key , Map<String,Object> datos){
		DetAdiAtreexDAO detAdiAtreexDAO = (DetAdiAtreexDAO) fabricaDeServicios.getService("detAdiAtreexDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		detAdiAtreexDAO.insertSelective(mapInsert);
	}		

	private void executeInsertVehiCetico(Map<String,Object> key , Map<String,Object> datos){
		VehiCeticoDAO vehiCeticoDAO = (VehiCeticoDAO) fabricaDeServicios.getService("vehiCeticoDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		vehiCeticoDAO.insertSelective(mapInsert);
	}		


	private void executeInsertDetAutorizacion(Map<String,Object> key , Map<String,Object> datos){
		DetAutorizacionDAO detAutorizacionDAO = (DetAutorizacionDAO) fabricaDeServicios.getService("detAutorizacionDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		detAutorizacionDAO.insertSelective(mapInsert);
		((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).
		actualizarDocAutRectificacion(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION, key, datos, Constants.IND_REGISTRO_NUEVO);
	}

	private void executeInsertFacturaSerie(Map<String,Object> key , Map<String,Object> datos){
		FacturaSerieDAO facturaSerieDAO = (FacturaSerieDAO) fabricaDeServicios.getService("facturaSerieDAO"); 
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		facturaSerieDAO.insertSelective(mapInsert);
	}		

	private void executeInsertDocAutAsociado(Map<String,Object> key , Map<String,Object> datos){
		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		docAutAsociadoDAO.insertSelective(mapInsert);
		((MercanciaRestringidaEntidadService)fabricaDeServicios.getService("mercanciaRestringidaEntidadService")).
		actualizarDocAutRectificacion(ConstantesDataCatalogo.TABLA_DOCASOCIADO, key, datos, Constants.IND_REGISTRO_NUEVO); 
	}

	private void executeInsertFormaFactu(Map<String,Object> key , Map<String,Object> datos){
		FormaFactuDAO formaFactuDAO = (FormaFactuDAO) fabricaDeServicios.getService("formaFactuDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		formaFactuDAO.insertSelective(mapInsert);
	}	


	private void executeInsertDocuPrecedDua(Map<String,Object> key , Map<String,Object> datos){
		DocuPreceDuaDAO docuPreceDuaDAO = (DocuPreceDuaDAO) fabricaDeServicios.getService("docuPreceDuaDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		docuPreceDuaDAO.insertRegPrecedencia(mapInsert);
	}

	private void executeInsertCabCertiOrigen(Map<String,Object> key , Map<String,Object> datos, Declaracion declaracion){
		DocAutAsociadoDAO docAutAsociadoDAO = (DocAutAsociadoDAO) fabricaDeServicios.getService("docAutAsociadoDAO");
		CabCertiOrigenDAO cabCertiOrigenDAO = (CabCertiOrigenDAO) fabricaDeServicios.getService("cabCertiOrigenDAO");
		Map<String,Object> mapDocAutAsociado=new HashMap<String,Object>();
		mapDocAutAsociado.putAll(key);

		mapDocAutAsociado.put("COD_TIPDOCASO", datos.get("COD_TIPDOCASO"));

		Integer annDoc=SunatDateUtils.getAnho((Date)datos.get("FEC_CERTIFICADO"));
		if (annDoc.intValue()!=0)
			mapDocAutAsociado.put("ANN_DOC", annDoc);
		mapDocAutAsociado.put("NUM_DOC", datos.get("NUM_CERTIFICADO"));
		mapDocAutAsociado.put("FEC_EMIS", datos.get("FEC_CERTIFICADO"));
		Date fecVencimiento=SunatDateUtils.getDate("31/12/9999", "dd/MM/yyyy");
		mapDocAutAsociado.put("FEC_VENC", fecVencimiento);
		//Se adiciono try catch por PAS20165E220200118
		try{
			docAutAsociadoDAO.insertSelective(mapDocAutAsociado);
		}
		catch(Exception e){
			docAutAsociadoDAO.update(mapDocAutAsociado);
		}

		Map<String,Object> mapInsert=new HashMap<String, Object>();
		for( DAV dav: declaracion.getListDAVs()){
			if(dav.getProveedor()!=null)
				mapInsert.put("NOM_PROVE", dav.getProveedor().getNombreRazonSocial());
		}
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		cabCertiOrigenDAO.insertSelective(mapInsert);
	}			

	private void executeInsertFinUbicacion(Map<String,Object> key , Map<String,Object> datos){
		FinUbicacionDAO finUbicacionDAO = (FinUbicacionDAO) fabricaDeServicios.getService("finUbicacionDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		finUbicacionDAO.insertSelective(mapInsert);
	}		

	private void executeInsertFormbProveedor(Map<String,Object> key , Map<String,Object> datos){
		FormBProveedorDAO formBProveedorDAO = (FormBProveedorDAO) fabricaDeServicios.getService("formBProveedorDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		formBProveedorDAO.insertSelective(mapInsert);

	}

	private void executeInsertCondicionTransa(Map<String,Object> key , Map<String,Object> datos){
		CondicionTransaDAO condicionTransaDAO = (CondicionTransaDAO) fabricaDeServicios.getService("condicionTransaDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		condicionTransaDAO.insertSelective(mapInsert);

	}	

	private void executeInsertFactuSuce(Map<String,Object> key , Map<String,Object> datos){
		FactuSuceDAO factuSuceDAO = (FactuSuceDAO) fabricaDeServicios.getService("factuSuceDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		factuSuceDAO.insertSelective(mapInsert);
	}

	private void executeInsertItemFactura(Map<String,Object> key , Map<String,Object> datos){
		ItemFacturaDAO itemFacturaDAO = (ItemFacturaDAO) fabricaDeServicios.getService("itemFacturaDAO");
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		itemFacturaDAO.insertSelective(mapInsert);
	}


	private void grabaInsercion(String tableName,String codTabla, Map<String,Object> key ,
			Map<String,Object> datos,List<String> columns,List<Object> values,Declaracion declaracion){
		grabaInsercion(tableName, codTabla, key , datos, columns, values, declaracion, null);
	}
	//private void executeInsert(String tableName,String codTabla, Map<String,Object> key , Map<String,Object> datos,List<String> columns,List<Object> values){
	/*hosorio inicio 14/05/2011*/
	private void grabaInsercion(String tableName,String codTabla, Map<String,Object> key , Map<String,Object> datos,List<String> columns,List<Object> values,Declaracion declaracion, String codTransaccion){
		boolean insercionDinamica=false;
		/*hosorio fin 14/05/2011*/
		int rowupdated=0;

		if(codTabla.equals(ConstantesDataCatalogo.TABLA_CAB_DECLARA)){

		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FINYUBICACION)){
			executeInsertFinUbicacion(key,datos);
		}				
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DET_DECLARA)){
			executeInsertDetDeclara(key,datos);
		}
		/*inicio PAS20171U220200005*/
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_IMPCONSUMO)){
			executeInsertCabAdiImpoConsu(key, datos);
		}
		/*fin PAS20171U220200005*/

		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DETIMPCONSUMO)){
			executeInsertDetAdiImpoConsu(key, datos);

		}		
		//		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DETIMPCONSUMO)){
		//			executeInsertDetAdiImpoConsu(key, datos);
		//		}			ESTA REPETIDOOO anita rey
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DET_ADI_ATPA)){
			executeInsertDetAdiAtpa(key,datos);
		}				
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DET_ADI_ATREEX)){
			executeInsertDetAdiAttReex(key,datos);	
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_VEHI_CETICO)){
			executeInsertVehiCetico(key,datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_MONTOGASTO)){
			executeInsertMontoGasto(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DET_AUTORIZACION)){
			executeInsertDetAutorizacion(key, datos);
		}				
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FACTURA_SERIE)){
			executeInsertFacturaSerie(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DOCASOCIADO)){
			executeInsertDocAutAsociado(key, datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FORMA_FACTU)){
			executeInsertFormaFactu(key, datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_DOCUPRECE_DUA)){
			executeInsertDocuPrecedDua(key,datos);
		}				
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_CERTORIGEN)){
			executeInsertCabCertiOrigen(key,datos, declaracion); 
			
			if(codTransaccion!=null)RegistroUsoCertificadoOrigenElectronico(datos, declaracion, codTransaccion);//PAS20181U220200056
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBPROVEEDOR)){
			executeInsertFormbProveedor(key,datos);
		}

		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_COMPROBPAGO)){
			executeInsertComprobPago(key, datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_CONDICION_TRANSA)){
			executeInsertCondicionTransa(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FACTUSUCE)){
			executeInsertFactuSuce(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_ITEMFACTURA)){
			executeInsertItemFactura(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_VFOBPROVISIONAL)){
			executeInsertFobProvisional(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBITEMDESCRI)){
			executeInsertFormBItemDescri(key,datos);
		}		
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_SERIES_ITEM)){
			executeInsertSerieItem(key,datos);
		}	
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_FORMBMONTO)){
			executeInsertFormBMonto(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_EQUIPAMIENTO)){
			executeInsertEquipamiento(key,datos,declaracion);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_MOVEQUIPAMIENTO)){
			executeInsertMovEquipamiento(key,datos);
		}
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_PRECINTO)){
			executeInsertPrecinto(key,datos);
		}

		/*branch ingreso 2011-009 hosorio inicio 21/07/2011*/
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_PARTICIPANTEDOC)){


			//Long numSecParticipante= RectificacionServiceImpl.getInstance().getSequenceDAO().getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);
			Long numSecParticipante= ((SequenceDAO)fabricaDeServicios.getService("sequenceDAO")).getNextSequence(ConstanteSecuencia.SECUENCIA_PARTICIPANTE);

			//ES Si el NUM_SEC_PARTIC estuviera en la lista de columnas la eliminamos y tambien el valor correspondiente
			int idx = columns.indexOf("NUM_SECPARTIC");
			if (idx>-1){
				columns.remove(idx);
				values.remove(idx);
			}
			//Agregamos la secuencia del participante 
			columns.add("NUM_SECPARTIC"); values.add(numSecParticipante);
			key.put("NUM_SECPARTIC", numSecParticipante);



			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "31")){
				columns.add("COD_TIPDOC"); values.add("4");
				Map<String, Object> rptaRuc=new HashMap<String,Object>();
				//rptaRuc = RectificacionServiceImpl.getInstance().getSoporteService().obtenerPerNatJur("4", (String)key.get("NUM_DOCIDENT"));
				rptaRuc =  ((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).obtenerPerNatJur("4", (String)key.get("NUM_DOCIDENT"));
				//rptaRuc=RectificacionServiceImpl.getInstance().getDdpDAO().findByPK((String)key.get("NUM_DOCIDENT"));
				//	if (rptaRuc!=null){
				columns.add("NOM_RAZONSOCIAL"); values.add(rptaRuc.get("nombre").toString().trim());
				columns.add("DIR_PARTIC"); values.add(rptaRuc.get("direccion").toString().trim());
				//}	
				ejecutaInsertDinamico(tableName,columns,values);

			}		
			FormBProveedorDAO formBProveedorDAO = (FormBProveedorDAO) fabricaDeServicios.getService("formBProveedorDAO");
			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "91")){

				// ejecuta la grabacion en la tabla participante doc
				ejecutaInsertDinamico(tableName,columns,values);

				for(DAV dav:declaracion.getListDAVs()){
					if (dav.getProveedorLocal().getNumeroDocumentoIdentidad()!=null){

						Map<String,Object> mapUpdate=new HashMap<String, Object>();
						mapUpdate.put("NUM_CORREDOC", dav.getNumcorredoc());
						//mapUpdate.put("NUM_SECPROVE", dav.getNumcodsecprove());
						mapUpdate.put("NUM_SECPROVE", dav.getNumsecuprov());
						mapUpdate.put("COD_DOCPROVLOCAL", dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat());
						mapUpdate.put("COD_DOCIDENTPROVLOC", dav.getProveedorLocal().getNumeroDocumentoIdentidad());
						formBProveedorDAO.updateSelective(mapUpdate);


					}
				}
			}
			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "11")){
				//PAS20191U220200019 - mtorralba 20190412
				//Si el campo NOM_RAZONSOCIAL y DIR_PARTIC estuviera en la lista de columnas, lo eliminamos con su valor correspondiente
				int idxaux = columns.indexOf("NOM_RAZONSOCIAL");
				if (idxaux>-1){
					columns.remove(idxaux);
					values.remove(idxaux);
				}

				idxaux = columns.indexOf("DIR_PARTIC");
				if (idxaux>-1){
					columns.remove(idxaux);
					values.remove(idxaux);
				}
		
				Map<String, Object> rptaRuc=new HashMap<String,Object>();
				//rptaRuc = RectificacionServiceImpl.getInstance().getSoporteService().obtenerPerNatJur("4", (String)datos.get("NUM_DOCIDENT"));
				rptaRuc = ((SoporteService)fabricaDeServicios.getService("soporteServiceDef")).obtenerPerNatJur("4", (String)datos.get("NUM_DOCIDENT"));
				if(!columns.contains("NOM_RAZONSOCIAL")){ //csantillan PAS20181U220200054 agregado por bug P_SNAA0004-17051
				columns.add("NOM_RAZONSOCIAL"); values.add(rptaRuc.get("nombre").toString().trim());
				}
				if(!columns.contains("DIR_PARTIC")){ //csantillan PAS20181U220200054 agregado por bug  P_SNAA0004-17051
				columns.add("DIR_PARTIC"); values.add(rptaRuc.get("direccion").toString().trim());
				}
				//Map rptaRuc=new HashMap();
				//rptaRuc=RectificacionServiceImpl.getInstance().getDdpDAO().findByPK((String)datos.get("NUM_DOCIDENT"));
				//if (rptaRuc!=null){
				//columns.add("NOM_RAZONSOCIAL"); values.add(rptaRuc.get("ddp_nombre").toString());
				//}	

				ejecutaInsertDinamico(tableName,columns,values);

			}		

			if(SunatStringUtils.isEqualTo((String)key.get("COD_TIPPARTIC"), "90")){					
				ejecutaInsertDinamico(tableName,columns,values);				   
			}	


		}
		/*inicio cambios para bug 18605 arey*/
		else if(codTabla.equals(ConstantesDataCatalogo.TABLA_INDICADORDUA)){
			columns.add("COD_TIPOREGISTRO");
			values.add("T");
			boolean grabaIndicador = true;

			//region amancillaa SDA2-RIN18-PAS20171U220200035
			//PAS20155E220200155 solo se marca el indicador de importador frecuente en la numeraci�n
			// y Cuando importador este registrado en la tabla. TODO: amancilla no es correcto para OEA corregido
			for (int i = 0; i < columns.size(); i++) {
				if ( ConstantesDataCatalogo.INDICADOR_IMPORTADOR_FRECUENTE.equals(values.get(i))
						|| ConstantesDataCatalogo.INDICADOR_IMPORTADOR_OEA.equals(values.get(i))) {
					grabaIndicador = false;
				}
			}
			//endregion amancillaa

			if ( grabaIndicador ) 
				ejecutaInsertDinamico(tableName,columns,values);
		}/*fin cambios para bug 18605 arey*/		
		else { 
			ejecutaInsertDinamico(tableName,columns,values);

			/*
			DynamicSentenceBean dynamic=new DynamicSentenceBean(tableName);
			for (int i = 0; i < columns.size(); i++) {
				dynamic.getIntoCriteria().addCriterion("column",columns.get(i));
				dynamic.getValuesCriteria().addCriterion("value",values.get(i));
			}

			// se ejecuta el insert de la solicitud
			RectificacionServiceImpl.getInstance().getDetsolrectiDAO().insertByDinamicBean(dynamic);
			 */
			/*branch ingreso 2011-009 hosorio fin 21/07/2011*/	
		}


	}

	private void executeInsertMontoGasto(Map<String,Object> key , Map<String,Object> datos){
		MontoGastoDAO montoGastoDAO = (MontoGastoDAO) fabricaDeServicios.getService("montoGastoDAO"); 
		Map<String,Object> mapInsert=new HashMap<String, Object>();
		mapInsert.putAll(key);
		mapInsert.putAll(datos);
		montoGastoDAO.insertSelective(mapInsert);
	}	
/*
	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}


	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}


	public DetDeclaraDAO getDetDeclaraDAO() {
		return detDeclaraDAO;
	}


	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}
*/

	private void fillIndicadorDUA(Map<String,Object> mapIndicadoresDUA,Declaracion declaracion, DatoIndicadores indicador, Long numCorreDoc){
		mapIndicadoresDUA.put("numCorredoc", numCorreDoc);
		mapIndicadoresDUA.put("codIndicador", indicador.getCodtipoindica());
		mapIndicadoresDUA.put("codTiporegistro",'T' );//adicionado por bug 18605 arey
		//mapIndicadoresDUA.put("codUsuregis", );
		//mapIndicadoresDUA.put("fecRegis", );
		//mapIndicadoresDUA.put("codUsumodif", );
		//mapIndicadoresDUA.put("fecModif", );
	}

	/*
	private void asignacionEspecialista(Declaracion declaracion,String numCorreRecti){
	Map<String,Object> params=new HashMap<String, Object>();
	params.put("numcorredoc", declaracion.getDua().getNumcorredoc());
	 List<Espedocu> lstEspe=	( List<Espedocu>)espeDocuDAO.listEspeByParams(params);
	 if(!CollectionUtils.isEmpty(lstEspe)){
		 Espedocu asigEspe=lstEspe.get(0);
		 asigEspe.setNumCorredoc(Long.valueOf(numCorreRecti) );
		 espeDocuDAO.insertSelective(asigEspe);
	 }
	}
	 */
	/*
	public EspeDocuDAO getEspeDocuDAO() {
		return espeDocuDAO;
	}


	public void setEspeDocuDAO(EspeDocuDAO espeDocuDAO) {
		this.espeDocuDAO = espeDocuDAO;
	}


	public IndicadorDUADAO getIndicadorDUADAO() {
		return indicadorDUADAO;
	}


	public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
		this.indicadorDUADAO = indicadorDUADAO;
	}


	public FormBProveedorDAO getFormBProveedorDAO() {
		return formBProveedorDAO;
	}


	public void setFormBProveedorDAO(FormBProveedorDAO formBProveedorDAO) {
		this.formBProveedorDAO = formBProveedorDAO;
	}



	public CabAdjTransitoDAO getCabAdjTransitoDAO() {
		return cabAdjTransitoDAO;
	}


	public void setCabAdjTransitoDAO(CabAdjTransitoDAO cabAdjTransitoDAO) {
		this.cabAdjTransitoDAO = cabAdjTransitoDAO;
	}

	public CabAdjImpoconsuDAO getCabAdjImpoconsuDAO() {
		return cabAdjImpoconsuDAO;
	}


	public void setCabAdjImpoconsuDAO(CabAdjImpoconsuDAO cabAdjImpoconsuDAO) {
		this.cabAdjImpoconsuDAO = cabAdjImpoconsuDAO;
	}
*/

	private Date obtenerFechaConclusion(Declaracion declaracion){
		Date fechaConclusion=SunatDateUtils.addMonth(declaracion.getDua().getFecdeclaracion(),3);
		String resultadoDias="";

		Map<String,Object> params = new HashMap<String,Object>();
		params.put("FECHADESDE", SunatDateUtils.getIntegerFromDate(fechaConclusion));
		params.put("FECHAHASTA", 1);
		params.put("TIPO", 2);
		params.put("INCLUYE", "S");
		params.put("SUSPENDE", "S");
		//resultadoDias=(String)NumeracionServiceImpl.getInstance().getDiasUtilesDAO().getSPDiasUtiles(params);
		resultadoDias=(String)((DiasUtilesDAO)fabricaDeServicios.getService("diasUtilesDAO")).getSPDiasUtiles(params);


		fechaConclusion=SunatDateUtils.getDateFromInteger(SunatNumberUtils.toInteger(resultadoDias));

		return fechaConclusion;
	}

/*
	public CabAdjAtpaDAO getCabAdjAtpaDAO() {
		return cabAdjAtpaDAO;
	}


	public void setCabAdjAtpaDAO(CabAdjAtpaDAO cabAdjAtpaDAO) {
		this.cabAdjAtpaDAO = cabAdjAtpaDAO;
	}


	public FinUbicacionDAO getFinUbicacionDAO() {
		return finUbicacionDAO;
	}


	public void setFinUbicacionDAO(FinUbicacionDAO finUbicacionDAO) {
		this.finUbicacionDAO = finUbicacionDAO;
	}


	public DetAdiImpoconsuDAO getDetAdiImpoconsuDAO() {
		return detAdiImpoconsuDAO;
	}


	public void setDetAdiImpoconsuDAO(DetAdiImpoconsuDAO detAdiImpoconsuDAO) {
		this.detAdiImpoconsuDAO = detAdiImpoconsuDAO;
	}


	public DetAdiAtpaDAO getDetAdiAtpaDAO() {
		return detAdiAtpaDAO;
	}


	public void setDetAdiAtpaDAO(DetAdiAtpaDAO detAdiAtpaDAO) {
		this.detAdiAtpaDAO = detAdiAtpaDAO;
	}


	public DetAdiAtreexDAO getDetAdiAtreexDAO() {
		return detAdiAtreexDAO;
	}


	public void setDetAdiAtreexDAO(DetAdiAtreexDAO detAdiAtreexDAO) {
		this.detAdiAtreexDAO = detAdiAtreexDAO;
	}


	public VehiCeticoDAO getVehiCeticoDAO() {
		return vehiCeticoDAO;
	}


	public void setVehiCeticoDAO(VehiCeticoDAO vehiCeticoDAO) {
		this.vehiCeticoDAO = vehiCeticoDAO;
	}


	public MontoGastoDAO getMontoGastoDAO() {
		return montoGastoDAO;
	}


	public void setMontoGastoDAO(MontoGastoDAO montoGastoDAO) {
		this.montoGastoDAO = montoGastoDAO;
	}


	public DetAutorizacionDAO getDetAutorizacionDAO() {
		return detAutorizacionDAO;
	}


	public void setDetAutorizacionDAO(DetAutorizacionDAO detAutorizacionDAO) {
		this.detAutorizacionDAO = detAutorizacionDAO;
	}


	public FacturaSerieDAO getFacturaSerieDAO() {

		return facturaSerieDAO;
	}


	public void setFacturaSerieDAO(FacturaSerieDAO facturaSerieDAO) {
		this.facturaSerieDAO = facturaSerieDAO;
	}


	public DocAutAsociadoDAO getDocAutAsociadoDAO() {
		return docAutAsociadoDAO;
	}


	public void setDocAutAsociadoDAO(DocAutAsociadoDAO docAutAsociadoDAO) {
		this.docAutAsociadoDAO = docAutAsociadoDAO;
	}


	public FormaFactuDAO getFormaFactuDAO() {
		return formaFactuDAO;
	}


	public void setFormaFactuDAO(FormaFactuDAO formaFactuDAO) {
		this.formaFactuDAO = formaFactuDAO;
	}


	public DocuPreceDuaDAO getDocuPreceDuaDAO() {
		return docuPreceDuaDAO;
	}


	public void setDocuPreceDuaDAO(DocuPreceDuaDAO docuPreceDuaDAO) {
		this.docuPreceDuaDAO = docuPreceDuaDAO;
	}


	public CabCertiOrigenDAO getCabCertiOrigenDAO() {
		return cabCertiOrigenDAO;
	}


	public void setCabCertiOrigenDAO(CabCertiOrigenDAO cabCertiOrigenDAO) {
		this.cabCertiOrigenDAO = cabCertiOrigenDAO;
	}


	public CondicionTransaDAO getCondicionTransaDAO() {
		return condicionTransaDAO;
	}


	public void setCondicionTransaDAO(CondicionTransaDAO condicionTransaDAO) {
		this.condicionTransaDAO = condicionTransaDAO;
	}


	public FactuSuceDAO getFactuSuceDAO() {
		return factuSuceDAO;
	}


	public void setFactuSuceDAO(FactuSuceDAO factuSuceDAO) {
		this.factuSuceDAO = factuSuceDAO;
	}


	public ItemFacturaDAO getItemFacturaDAO() {
		return itemFacturaDAO;
	}


	public void setItemFacturaDAO(ItemFacturaDAO itemFacturaDAO) {
		this.itemFacturaDAO = itemFacturaDAO;
	}


	public VFOBProvisionalDAO getFobProvisionalDAO() {
		return fobProvisionalDAO;
	}


	public void setFobProvisionalDAO(VFOBProvisionalDAO fobProvisionalDAO) {
		this.fobProvisionalDAO = fobProvisionalDAO;
	}


	public FormBItemDescriDAO getFormBItemDescriDAO() {
		return formBItemDescriDAO;
	}


	public void setFormBItemDescriDAO(FormBItemDescriDAO formBItemDescriDAO) {
		this.formBItemDescriDAO = formBItemDescriDAO;
	}


	public ComprobPagoDAO getComprobPagoDAO() {
		return comprobPagoDAO;
	}


	public void setComprobPagoDAO(ComprobPagoDAO comprobPagoDAO) {
		this.comprobPagoDAO = comprobPagoDAO;
	}


	public SeriesItemDAO getSeriesItemDAO() {
		return seriesItemDAO;
	}


	public void setSeriesItemDAO(SeriesItemDAO seriesItemDAO) {
		this.seriesItemDAO = seriesItemDAO;
	}


	public FormBMontoDAO getFormBMontoDAO() {
		return formBMontoDAO;
	}


	public void setFormBMontoDAO(FormBMontoDAO formBMontoDAO) {
		this.formBMontoDAO = formBMontoDAO;
	}


	public CabSolrectiDAO getCabSolrectiDAO() {
		return cabSolrectiDAO;
	}

	public void setCabSolrectiDAO(CabSolrectiDAO cabSolrectiDAO) {
		this.cabSolrectiDAO = cabSolrectiDAO;
	}

	public AsignacionAutomaticaService getAsignacionAutomaticaService() {
		return asignacionAutomaticaService;
	}

	public void setAsignacionAutomaticaService(
			AsignacionAutomaticaService asignacionAutomaticaService) {
		this.asignacionAutomaticaService = asignacionAutomaticaService;
	}	
	
	public void setGrabarContingentesService(
			GrabarContingentesService grabarContingentesService) {
		this.grabarContingentesService = grabarContingentesService;
	}

*/
	private Date obtenerFechaVencimientoDespacho(Declaracion declaracion,Map<Object,Object> mapManifiesto){

		Date dtFecVencimientoDespacho=null;
		String codGarantia =null;

		Date dtFecNumeracion=declaracion.getDua().getFecdeclaracion();
		Date dtFecLlegadaAux=null;
		Date dtFecLlegada=null;
		Date dtFecPrLlegada=null;
		Date dtFecTerminoDescarga=null;
		String codModalidad= declaracion.getDua().getCodmodalidad();

		// SI tien cab Manifiesto
		if (mapManifiesto!=null){
			dtFecLlegada=(Date)mapManifiesto.get("fechaEfectivaDeLlegada");
			dtFecPrLlegada=(Date)mapManifiesto.get("fechaProgramadaLlegada");
			dtFecTerminoDescarga=(Date)mapManifiesto.get("fechaTerminoDeDescarga");
			if(SunatDateUtils.sonIguales(dtFecLlegada, SunatDateUtils.getDefaultDate(), "COMPARA_SOLO_FECHA"))
				dtFecLlegadaAux=dtFecPrLlegada;
			else 
				dtFecLlegadaAux=dtFecLlegada;
		}
		else{
			dtFecLlegadaAux=declaracion.getDua().getManifiesto().getFectermino();
			//PAS20145E220000090 - MATC 20140617  INICIO
			if( dtFecLlegadaAux!=null && SunatDateUtils.sonIguales(dtFecLlegadaAux, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
				dtFecLlegadaAux = declaracion.getDua().getFecLlegada();
			}
			//PAS20145E220000090 - MATC 20140617  FINAL
		}

		try {
			codGarantia=declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
		} catch (Exception e) {
			// TODO: handle exception
		}
		// Exceptcional sin garantia
		if (SunatStringUtils.isEmpty(codGarantia) &&
				SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)){
			dtFecVencimientoDespacho=dtFecNumeracion;
		}
		// Excpecional con garantai
		if (!SunatStringUtils.isEmpty(codGarantia) &&
				SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)){

			Date result=SunatDateUtils.addMonth(dtFecNumeracion, 1);
			Calendar c=Calendar.getInstance();
			c.setTime(result);
			c.set(Calendar.DAY_OF_MONTH, 20);
			dtFecVencimientoDespacho =c.getTime();


		}

		//la fecha de vencimiento de pago en el despacho anticipado y urgente antes de la llegada, para la DUA que no cuenta con la garant�a 160� es la fecha del t�rmino de la descarga
		if(SunatStringUtils.isEmpty(codGarantia)
				&& 		(  SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) 
						||
						(
								SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
								&&  SunatDateUtils.esFecha1MayorIgualQueFecha2(dtFecLlegadaAux, dtFecNumeracion, "COMPARA_SOLO_FECHA")  // antes de la llegada
								)
						)

				){

			if(dtFecTerminoDescarga!=null && 
					!SunatDateUtils.isDefaultDate(dtFecTerminoDescarga)){
				dtFecVencimientoDespacho=dtFecTerminoDescarga;	
			}
			else{
				//(si no se tiene la fecha del t�rmino de la descarga a la fecha de la rectificaci�n, se consignar� el 31.12.2999).
				dtFecVencimientoDespacho=SunatDateUtils.getDateFromInteger(29991231);
			}

		}

		//y para la DUA que cuenta con garant�a 160� es el d�a 20 calendario del mes siguiente a la fecha del t�rmino de la descarga.
		if(!SunatStringUtils.isEmpty(codGarantia)
				&& 		(  	SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) 
						|| 
						(
								SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
								&&  SunatDateUtils.esFecha1MayorIgualQueFecha2(dtFecLlegadaAux, dtFecNumeracion, "COMPARA_SOLO_FECHA")  // antes de la llegada
								)
						)

				){


			if(dtFecTerminoDescarga!=null && 
					!SunatDateUtils.isDefaultDate(dtFecTerminoDescarga)){
				Date result=SunatDateUtils.addMonth(dtFecTerminoDescarga, 1);
				Calendar c=Calendar.getInstance();
				c.setTime(result);
				c.set(Calendar.DAY_OF_MONTH, 20);
				dtFecVencimientoDespacho =c.getTime();

			}
			else{
				//(si no se tiene la fecha del t�rmino de la descarga a la fecha de la rectificaci�n, se consignar� el 31.12.3999).
				dtFecVencimientoDespacho=SunatDateUtils.getDateFromInteger(39991231);
			}


		}	



		//Tener en cuenta que la fecha de vencimiento de pago en el despacho urgente despu�s de la llegada, 
		//para la DUA que no cuenta con la garant�a 160� es la fecha de numeraci�n de la DUA 


		if(SunatStringUtils.isEmpty(codGarantia)
				&& 	SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) 
				&&  SunatDateUtils.esFecha1MayorIgualQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // antes de la llegada
				){
			dtFecVencimientoDespacho=dtFecNumeracion; 
		}
		//y para la DUA que cuenta con garant�a 160� es el d�a 20 calendario del mes siguiente a la fecha de numeraci�n de la DUA.
		if(!SunatStringUtils.isEmpty(codGarantia)
				&& 	SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) 
				&&  SunatDateUtils.esFecha1MayorIgualQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // antes de la llegada
				){

			Date result=SunatDateUtils.addMonth(dtFecNumeracion, 1);
			Calendar c=Calendar.getInstance();
			c.setTime(result);
			c.set(Calendar.DAY_OF_MONTH, 20);
			dtFecVencimientoDespacho =c.getTime();


		}	


		//6.3.2. En excepcional y urgente despu�s de la llegada: El vencimiento de pago es el d�a 20 calendario del mes siguiente a la fecha de numeraci�n de la DUA.
		if(!SunatStringUtils.isEmpty(codGarantia)
				&& 	(SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
						||
						(
								SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)
								&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // despues de la llegada						 
								)
						) 

				){

			Date result=SunatDateUtils.addMonth(dtFecNumeracion, 1);
			Calendar c=Calendar.getInstance();
			c.setTime(result);
			c.set(Calendar.DAY_OF_MONTH, 20);
			dtFecVencimientoDespacho =c.getTime();


		}	

		//9.0 tener en cuenta que la fecha de vencimiento de pago en el despacho urgente despu�s de la llegada, 
		//para la DUA que no cuenta con la garant�a 160� es la fecha de numeraci�n de la DUA 
		if(SunatStringUtils.isEmpty(codGarantia)
				&& 	 (SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_URGENTE) || SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL))
				&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // despues de la llegada
				){
			dtFecVencimientoDespacho=dtFecNumeracion;
		}	


		return dtFecVencimientoDespacho;

	}

	private void actualizaDocumentosDeudaporGarantia(Declaracion declaracion,List<HashMap> lstDeudasAAfectar,Map<Object,Object> mapManifiesto){
		//y se marcan con el tipo de cancelaci�n 74, consignando o actualizando en la DUA y LC 
		//Complementarias, la fecha de vencimiento para el pago, seg�n el tipo de despacho 			
		Date dtFecVencimientoDespacho=obtenerFechaVencimientoDespacho(declaracion,mapManifiesto);
		if(!CollectionUtils.isEmpty(lstDeudasAAfectar)){
			for(Map mpLCDeuda:lstDeudasAAfectar){
				// RIN16
				//			String cda =mpLCDeuda.get("CDA").toString(); 
				String strLC=mpLCDeuda.get("LC").toString();
				String strAduanaLiqu=SunatStringUtils.substring(strLC, 0,3) ;
				String strAnnioLiq=SunatStringUtils.substring(strLC, 3,2) ;
				String strNumLiq=SunatStringUtils.substring(strLC, 7,5) ;

				// tabla liquida
				/*ya lo hace el liquidador*/
				/*
			Liquida tmpLiqui=new Liquida();
			tmpLiqui.setRladuana(strAduanaLiqu);
			tmpLiqui.setRlano(strAnnioLiq);
			tmpLiqui.setRlnroliq(strNumLiq);
			tmpLiqui.setRltipcan(74);
			RectificacionServiceImpl.getInstance().getLiquidaDAO().updateByPrimaryKey(tmpLiqui);
				 */
				// tabla poliza de dua actualiza tipo cancelacion y fecha de vencimiento
				Map<String,Object> param=new HashMap<String, Object>();
				param.put("tabla", "DI"+SunatStringUtils.substring(declaracion.getNumdeclRef().getAnnprese(), 2) +"POLIZAI");
				param.put("TIPO_CANCE", "74");
				param.put("ULTD_PAGO", dtFecVencimientoDespacho);
				param.put("NUME_CORRE", declaracion.getNumdeclRef().getNumcorre());
				param.put("ANO_PRESE", declaracion.getNumdeclRef().getAnnprese());
				param.put("CODI_ADUAN", declaracion.getNumdeclRef().getCodaduana());

				//RectificacionServiceImpl.getInstance().getDiPolizaDAO().actualizaDua(param);
				((DipolizaiDAO)fabricaDeServicios.getService("diPolizaDAO")).actualizaDua(param);

				//La fecha de vencimiento de pago de los documentos de pago para el formato C y Liquidaciones de Cobranza se graba en el campo FEC_VENC de la tabla  DEUDA_DOCUM.  Adicionalmente en el ASIGAD, en el caso del formato C tambi�n se actualiza este dato en el campo ULTD_PAGO de la tabla DIXXPOLIZAI y 
				//en el caso de las LCs se actualiza el campo RLVENCIM de la tabla LIQUIDA, respectivamente. Tambi�n en el ASIGAD, se 
				DeudaDocum tmpDeu=new DeudaDocum();
				tmpDeu.setNumCorredoc(declaracion.getDua().getNumcorredoc());
				tmpDeu.setCodTipdeuda("02") ; // LC
				tmpDeu.setCodAduliquida(strAduanaLiqu);
				tmpDeu.setAnnLiquida(Integer.parseInt(strAnnioLiq));
				tmpDeu.setNumLiquida(strNumLiq);
				tmpDeu.setFecVenc(dtFecVencimientoDespacho);
				//RectificacionServiceImpl.getInstance().getDeudaDocumDAO().updateDeudaDocumByParams(tmpDeu);
				((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).updateDeudaDocumByParams(tmpDeu);

			}
		}
	}

	/*Pase 580*/
	public void actualizaFechaVencimientoDocumentosDeuda(Declaracion declaracion, Declaracion declaracionBD,Map<Object,Object> mapManifiesto
			,List<HashMap> lstDeudas)
	{


		Date dtFecNumeracion=declaracion.getDua().getFecdeclaracion();
		Date dtFecLlegada=null;
		Date dtFecPrLlegada=null;
		Date dtFecTerminoDescarga=null;
		Date dtFecLlegadaAux=null;
		// manifiesto
		if(mapManifiesto!=null){
			dtFecLlegada=(Date)mapManifiesto.get("fechaEfectivaDeLlegada");
			dtFecPrLlegada=(Date)mapManifiesto.get("fechaProgramadaLlegada");
			dtFecTerminoDescarga=(Date)mapManifiesto.get("fechaTerminoDeDescarga");

			if(SunatDateUtils.sonIguales(dtFecLlegada, SunatDateUtils.getDefaultDate(), "COMPARA_SOLO_FECHA"))
				dtFecLlegadaAux=dtFecPrLlegada;
			else 
				dtFecLlegadaAux=dtFecLlegada;

		}// Si no tiene CAB MANIFIESTO
		else{
			dtFecLlegadaAux=declaracion.getDua().getManifiesto().getFectermino();
			//PAS20145E220000090 - MATC 20140617  INICIO
			if( dtFecLlegadaAux!=null && SunatDateUtils.sonIguales(dtFecLlegadaAux, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
				dtFecLlegadaAux = declaracion.getDua().getFecLlegada();
			}
			//PAS20145E220000090 - MATC 20140617  FINAL
		}


		//7. Si hay cambio de modalidad de anticipado (1-0) � urgente (0-1) a excepcional (00), el NSIGAD actualiza la fecha de vencimiento de pago de la DUA
		String codModalidaBD=declaracionBD.getDua().getCodmodalidad();
		if(declaracion.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)
				&& 	SunatStringUtils.isStringInList(codModalidaBD, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO+","+ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
				){
			actualizaFechaVencimientoDocumentosDeuda(declaracion,lstDeudas,mapManifiesto);	
		}	



		//Si al momento de la rectificaci�n se cuenta con la fecha real del t�rmino de la descarga 
		//(en los casos de despacho anticipado y urgente antes de la llegada),
		if (dtFecTerminoDescarga!=null && !SunatDateUtils.isDefaultDate(dtFecTerminoDescarga) 
				&&	(  SunatStringUtils.isEqualTo(declaracion.getDua().getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO) 
						||
						(
								SunatStringUtils.isEqualTo(declaracion.getDua().getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
								&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecLlegadaAux, dtFecNumeracion, "COMPARA_SOLO_FECHA")  // antes de la llegada
								)
						)
				){
			actualizaFechaVencimientoDocumentosDeuda(declaracion,lstDeudas,mapManifiesto);
		}


		//Si al momento de la rectificaci�n se cuenta con la fecha real de la llegada del medio de transporte y/o del t�rmino de la descarga 
		//(en el caso de despacho urgente despu�s de la llegada), el NSIGAD actualiza la fecha de vencimiento de pago de la DUA (Formato C cancelado o no cancelado y LC complementarias no canceladas)
		if (   (
				(dtFecTerminoDescarga!=null && !SunatDateUtils.isDefaultDate(dtFecTerminoDescarga)) 
				|| 
				(dtFecLlegada!=null && !SunatDateUtils.isDefaultDate(dtFecLlegada))
				)
				&& 	SunatStringUtils.isEqualTo(declaracion.getDua().getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
				&&  SunatDateUtils.esFecha1MayorQueFecha2(dtFecNumeracion, dtFecLlegadaAux, "COMPARA_SOLO_FECHA")  // despues de la llegada


				){
			actualizaFechaVencimientoDocumentosDeuda(declaracion,lstDeudas,mapManifiesto);
		}



	}

	private void actualizaFechaVencimientoDocumentosDeuda(Declaracion declaracion,List<HashMap> lstDeudas,Map<Object,Object> mapManifiesto){
		Date dtFecVencimientoDespacho=obtenerFechaVencimientoDespacho(declaracion,mapManifiesto);

		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
		//List<DeudaDocum> lstDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);
		List<DeudaDocum> lstDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
		String codGarantia =null;
		try {
			codGarantia=declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();	
		} catch (Exception e) {
			// TODO: handle exception
		}


		if(!CollectionUtils.isEmpty(lstDeudaDocum)){
			for (DeudaDocum deudadoc:lstDeudaDocum){
				DeudaDocum tmpDeu=new DeudaDocum();

				tmpDeu.setNumCorredoc(deudadoc.getNumCorredoc());
				tmpDeu.setNumIdentdeuda(deudadoc.getNumIdentdeuda());
				tmpDeu.setFecVenc(dtFecVencimientoDespacho);

				if(SunatStringUtils.isEqualTo(deudadoc.getCodTipdeuda(), "02") ){
					Liquida tmpLiquida = new Liquida();
					tmpLiquida.setRladuana(deudadoc.getCodAduliquida());
					tmpLiquida.setRlano(SunatStringUtils.substring(deudadoc.getAnnLiquida().toString(), 2, 4));
					tmpLiquida.setRlnroliq(deudadoc.getNumLiquida());
					//Liquida tmpliq  =RectificacionServiceImpl.getInstance().getLiquidaDAO().selectByPrimaryKey(tmpLiquida);
					Liquida tmpliq  =((LiquidaDAO)fabricaDeServicios.getService("diligencia.ingreso.liquidaDef")).selectByPrimaryKey(tmpLiquida);
					//percepcion
					if(tmpliq!=null && SunatStringUtils.isEqualTo("0038", tmpliq.getRltipliq())){
						if(SunatStringUtils.isEmpty(codGarantia))
							tmpDeu.setFecVenc(new FechaBean("31/12/2999","dd/MM/yyyy").getSQLDate());
						else
							tmpDeu.setFecVenc(new FechaBean("31/12/3999","dd/MM/yyyy").getSQLDate());
					}

				}

				//RectificacionServiceImpl.getInstance().getDeudaDocumDAO().updateDeudaDocumByParams(tmpDeu);
				((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).updateDeudaDocumByParams(tmpDeu);



			}

		}


		if(!CollectionUtils.isEmpty(lstDeudas)){
			for(Map mpLCDeuda:lstDeudas){
				String cda =mpLCDeuda.get("CDA").toString();
				//NO SE CONSIDERA ACTUALIZAR PERCECPCION BUG 20275
				String cda1 = SunatStringUtils.substringFox(cda, 14, 2);
				if(!"25".equals(cda1) && !"97".equals(cda1))  
				{
					// Actualizacion del Deuda Docum
					DeudaDocum tmpDeu=new DeudaDocum();
					tmpDeu.setNumCorredoc(declaracion.getDua().getNumcorredoc());
					tmpDeu.setNumCda(cda);
					tmpDeu.setFecVenc(dtFecVencimientoDespacho);
					//RectificacionServiceImpl.getInstance().getDeudaDocumDAO().updateDeudaDocumByParams(tmpDeu);
					((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).updateDeudaDocumByParams(tmpDeu);
				}


				/*
			Liquida tmpLiqui=new Liquida();
			tmpLiqui.setRladuana(tmpDeu.getCodAduliquida());
			tmpLiqui.setRlano(tmpDeu.getAnnLiquida().toString());
			tmpLiqui.setRlnroliq(tmpDeu.getNumLiquida());
			tmpLiqui.setRlvencim(SunatDateUtils.getIntegerFromDate(dtFecVencimientoDespacho));
			RectificacionServiceImpl.getInstance().getLiquidaDAO().updateByPrimaryKey(tmpLiqui);
				 */
			}
		}
	}

	private void actualizaFechaVencimientoDocumentosDeuda(Declaracion declaracion,Map<Object,Object> mapManifiesto){

		//actualiza la fecha de vencimiento de pago de la DUA (Formato C cancelado o no cancelado) 
		Date dtFecVencimientoDespacho=obtenerFechaVencimientoDespacho(declaracion,mapManifiesto);
		DeudaDocum tmpDeu=new DeudaDocum();
		tmpDeu.setNumCorredoc(declaracion.getDua().getNumcorredoc());
		tmpDeu.setCodTipdeuda("01") ; // formato c
		tmpDeu.setFecVenc(dtFecVencimientoDespacho);
		//RectificacionServiceImpl.getInstance().getDeudaDocumDAO().updateDeudaDocumByParams(tmpDeu);
		((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).updateDeudaDocumByParams(tmpDeu);
		//y LC complementarias no canceladas)


		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
		tmpDeudaDocum.setCodTipdeuda("02");// Tipo De Deuda LC
		tmpDeudaDocum.setCodEstpago("P");// no cancelado            

		//List<DeudaDocum> lstDeudaDocum = RectificacionServiceImpl.getInstance().getDeudaDocumDAO().selectByDocumento(tmpDeudaDocum);
		List<DeudaDocum> lstDeudaDocum = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).selectByDocumento(tmpDeudaDocum);
		if(!CollectionUtils.isEmpty(lstDeudaDocum)){
			for (DeudaDocum deudaDocum:lstDeudaDocum) {

				// Actualizacion del Deuda Docum
				tmpDeu=new DeudaDocum();
				tmpDeu.setNumCorredoc(declaracion.getDua().getNumcorredoc());
				tmpDeu.setNumIdentdeuda(deudaDocum.getNumIdentdeuda());
				tmpDeu.setFecVenc(dtFecVencimientoDespacho);
				//RectificacionServiceImpl.getInstance().getDeudaDocumDAO().updateDeudaDocumByParams(tmpDeu);
				((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).updateDeudaDocumByParams(tmpDeu);


				// Actualizacion de Liquida
				Liquida tmpLiqui=new Liquida();
				tmpLiqui.setRladuana(tmpDeu.getCodAduliquida());
				tmpLiqui.setRlano(tmpDeu.getAnnLiquida().toString());
				tmpLiqui.setRlnroliq(tmpDeu.getNumLiquida());
				tmpLiqui.setRlvencim(SunatDateUtils.getIntegerFromDate(dtFecVencimientoDespacho));
				//RectificacionServiceImpl.getInstance().getLiquidaDAO().updateByPrimaryKey(tmpLiqui);
				((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).updateByPrimaryKey(tmpLiqui);


			}								
		}	


	}


	public Map<Object, Object> obtenerManifiesto(Declaracion declaracion) {

		Map<Object, Object> manifiestoMap=null;
		if (declaracion.getDua().getManifiesto() != null) {
			Map<String, Object> paramsMap = new HashMap<String, Object>();
			String annManif = "0";
			if (SunatStringUtils.length(declaracion.getDua().getManifiesto().getAnnmanif()) > 3)
				annManif = declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4);
			paramsMap.put("anioManifiesto", annManif);
			paramsMap.put("numeroManifiesto", SunatStringUtils.lpad(declaracion.getDua().getManifiesto().getNummanif(), 6, ' '));
			paramsMap.put("aduana", declaracion.getDua().getManifiesto().getCodaduamanif());
			paramsMap.put("tipoManifiesto", declaracion.getDua().getManifiesto().getCodtipomanif());
			paramsMap.put("viaTransporte", declaracion.getDua().getManifiesto().getCodmodtransp());

			//		 manifiestoMap = RectificacionServiceImpl.getInstance().getManifiestoDAO().getByNumeroAnioAduanaTipoManifTipoVia(
			//				paramsMap);
			manifiestoMap = ((CabManifiestoDAO)fabricaDeServicios.getService("manifiesto.manifiestoDAO")).getByNumeroAnioAduanaTipoManifTipoVia(
					paramsMap);

		}

		return manifiestoMap;
	}

	public void ejecutaInsertDinamico(String tableName,List<String> columns,List<Object> values){

		DynamicSentenceBean dynamic=new DynamicSentenceBean(tableName);
		for (int i = 0; i < columns.size(); i++) {
			dynamic.getIntoCriteria().addCriterion("column",columns.get(i));
			dynamic.getValuesCriteria().addCriterion("value",values.get(i));
		}
		// se ejecuta el insert de la solicitud
		//RectificacionServiceImpl.getInstance().getDetsolrectiDAO().insertByDinamicBean(dynamic);((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO"))
		((DetSolRectiDAO)fabricaDeServicios.getService("detsolrectiDAO")).insertByDinamicBean(dynamic);


	}



	/*hosorio fin 04/04/2011*/

	/* Inicio RIN10 3007 erodriguezb */
	/**
	 * Description:
	 * 
	 * @param declaracion
	 * @param declaracionBD
	 * @param variablesIngreso
	 * @throws Exception
	 */

	private List<Map<String, String>> grabarRectificacionVPSinCanal(Declaracion declaracion, Declaracion declaracionBD,	Map<String, Object> variablesIngreso) 
			throws Exception {
		CatalogoAyudaService catalogoayudaservice = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listaWarnings = new ArrayList<Map<String, String>>();

		DatoPago pago = declaracion.getDua().getPago();
		DatoPagoDecla decla = pago != null ? pago.getPagoDeclaracion() : null;

		Boolean tieneIndicadorVP = variablesIngreso.containsKey("tieneIndicadorVP") ? (Boolean) variablesIngreso.get("tieneIndicadorVP") : false;
		Boolean transmiteItemVP = variablesIngreso.containsKey("transmiteItemVP") ? (Boolean) variablesIngreso.get("transmiteItemVP") : false;
		Boolean todosItemsValorDefinitivo = variablesIngreso.containsKey("todosItemsValorDefinitivo") ? (Boolean) variablesIngreso.get("todosItemsValorDefinitivo") : false;
		Boolean tieneGarantia160 = variablesIngreso.containsKey("tieneGarantia160") ? (Boolean) variablesIngreso.get("tieneGarantia160") : false;
		Boolean modificarLC = variablesIngreso.containsKey("modificarLC") ? (Boolean) variablesIngreso.get("modificarLC") : false;
		Boolean acogerGarantia160 = variablesIngreso.containsKey("acogerGarantia160") ? (Boolean) variablesIngreso.get("acogerGarantia160") : false;

		// buscar si tiene garant�a 159		
		List<Map<String, Object>> resultGarantia159 = new ArrayList<Map<String,Object>>();
		//obtener la LC					
		Map<String, Object> paramsGetLCVP = new HashMap<String, Object>();
		paramsGetLCVP.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc());
		paramsGetLCVP.put("COD_REGIMEN",declaracionBD.getDua().getCodregimen());
		paramsGetLCVP.put("COD_ADUANA", declaracionBD.getCodaduana());
		paramsGetLCVP.put("ANN_PRESEN", declaracionBD.getDua().getAnnpresen().toString().substring(2));//en liquida el a�o solo tiene dos digitos);
		paramsGetLCVP.put("NUM_DECLARACION", SunatStringUtils.lpad(declaracionBD.getNumeroDeclaracion().toString(), 6, '0'));//en liquida el num_decla tiene 6 digitos
		LiquidaDeclaracionService liquidaDeclaracionService = (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
		if (liquidaDeclaracionService.verificarDeclaracionConLCGenerada(paramsGetLCVP)){//Si la DUA tiene una LC(VP)
			Map<String, Object> paramsCtaCte159 = new HashMap<String, Object>();
			//LC(VP) con garantia 159�
			paramsCtaCte159.put("PADUANA", declaracionBD.getCodaduana());
			paramsCtaCte159.put("PANO", declaracionBD.getDua().getAnnpresen());
			paramsCtaCte159.put("PREGIMEN", " ");
			paramsCtaCte159.put("PNUMERO", paramsGetLCVP.get("NUM_LIQUIDA_LCVP"));

			MovNGarantiaDAO movNGarantiaDAO = fabricaDeServicios.getService("movNGarantiaDefRead");
			resultGarantia159 = movNGarantiaDAO.buscarGarantia159(paramsCtaCte159);
		}


		HashMap<String, String> datosNotificacion = new HashMap<String, String>();
		HashMap<String, String> resultadoTmp = new HashMap<String, String>();
		// 1. Para una Declaraci�n SIN Valor Provisional
		if (!tieneIndicadorVP) {
			if (transmiteItemVP) {
				GrabarDeclaracionService grabarDeclaracionService = (GrabarDeclaracionService)fabricaDeServicios.getService("grabarDeclaracionService");

				//amancilla PAS20155E220200167 grabarDeclaracionService.grabarIndicadorPlazoNumeracion(declaracion, declaracionBD.getDua().getNumcorredoc());//RIN10-BUG
				grabarDeclaracionService.grabarIndicadorPlazoNumeracion(declaracion, declaracionBD.getDua().getNumcorredoc(),"1003");

				datosNotificacion = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);

				listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_GEN_LC));//RIN10 

				if (TIPO_PAGO_GARANTIA.equals(decla.getCodtipopago()) && decla.getCodgarantia() != null) {
					datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_LCVP_GARANTIA160);
					datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_01);
				} else {
					datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_LCVP_SINGARANTIA160);
					//Inicio RIN10 mpoblete BUG 22094
					//datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_24);					
					datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_06);
					//Fin RIN10 mpoblete BUG 22094
				}
			}
		}
		// 2. Declaraci�n con Valor Provisional
		else {

			// 2.1 Modifica todos los �tems a Valor Definitivo
			if (todosItemsValorDefinitivo) {
				// si existe una lc asociada a la declaracion, se procede a anular
				resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
				datosNotificacion.putAll(resultadoTmp);
				// Se retira el indicador de valor provisional
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
				params.put("COD_INDICADOR", COD_INDICADOR_VP);
				params.put("IND_ACTIVO", INACTIVO_TABLE_INDICADOR_DUA);
				IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
				indicadorDUADAO.updateByRectificacion(params);

				listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_VAL_DEF));
				// 2.1.1 Duan con garant�a art. 160
				if (tieneGarantia160) {
					// liquidaDeclaracionService.
					declaracionBD.getDua().setNumdocumento(declaracion.getNumeroDeclaracion().toString().trim());// DUA trae dato err�neo
					desafectarGarantia(declaracionBD.getDua(), resultadoTmp,variablesIngreso);

					listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_ANUL_LC_DESAF_CTA_160));

					datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC);
					datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_02);
				}
				// 2.1.2 Duan sin garant�a art. 160
				else {
					if (!ListaUtil.isBlankOrNull(resultGarantia159)) {//con garantia 159
						listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_ANUL_LC_DEVOL_GAR_159));
						datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC_VP);
						datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_25);
					} else {
						listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_ANUL_LC));
						datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC_VP);
						//Inicio RIN10 mpoblete BUG 21937
						datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_04);
						//Fin RIN10 mpoblete BUG 21937

					}
				}
			}
			// 2.2
			else if (transmiteItemVP) {
				// 2.2.1 Duan con garant�a art. 160
				if (tieneGarantia160) {
					if (modificarLC) {
						// si existe una lc asociada a la declaracion, se
						// procede a anular
						resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
						datosNotificacion.putAll(resultadoTmp);

						// liquidaDeclaracionService.
						declaracionBD.getDua().setNumdocumento(declaracion.getNumeroDeclaracion().toString().trim());// DUA trae dato err�neo
						desafectarGarantia(declaracionBD.getDua(), resultadoTmp, variablesIngreso);

						listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_ANUL_LC_RECTI));
						resultadoTmp = new HashMap<String, String>();

						resultadoTmp = liquidaDeclaracionService.generarLCVP(declaracion,variablesIngreso);

						datosNotificacion.putAll(resultadoTmp);

						datosNotificacion.put("des_asunto", Constants.ASUNTO_NOTIF_ANULACION_EMISION_LC);
						datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_07);
					}
				}
				// 2.2.2. DUA sin Garant�a del Art�culo 160� para acogerse a la
				// Garant�a Art�culo 160� LGA
				else if (acogerGarantia160) {
					// si existe una lc asociada a la declaracion, se procede a anular
					resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
					datosNotificacion.putAll(resultadoTmp);

					resultadoTmp = new HashMap<String, String>();
					resultadoTmp = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);
					datosNotificacion.putAll(resultadoTmp);

					if (!ListaUtil.isBlankOrNull(resultGarantia159)) {
						listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_ANUL_LC_DEVOL_GAR_159_ACOG_160));
					} else {
						listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_ANUL_LC_SIN_GAR));
					}

					datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_ANULACION_LC_ACOGIMIENTO);
					datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_05);
				}
				// DUA SIN Garant�a del Art�culo 160� y SIN acogerse a la
				// Garant�a Art�culo 160� LGA
				else {
					if (modificarLC) {
						// si existe una lc asociada a la declaracion, se procede a anular
						resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
						datosNotificacion.putAll(resultadoTmp);
						resultadoTmp = new HashMap<String, String>();
						resultadoTmp = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);
						datosNotificacion.putAll(resultadoTmp);
						datosNotificacion.put("des_asunto", Constants.ASUNTO_NOTIF_ANULACION_GENERACION);
						datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_08);
					}
				}
			}
		}
		if (datosNotificacion.containsKey("codigo_plantilla")) {
			// Notificamos al buz�n del importador

			datosNotificacion.put("cod_usuario", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			//			<EHR>
			DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
			String razonSocial = "NO SE ENCUENTRA EN PARTICIPANTE_DOC";

			razonSocial = diligenciaService.obtenerAgentesBeneficiarios(declaracion.getDua().getNumcorredoc().toString(), Constantes.CODIGO_TIPO_PARTICIPANTE);

			datosNotificacion.put("des_ruc_razon_social", Utilidades.retirarTildeParaAsuntoNotificacion(razonSocial));
			//			</EHR>
			//datosNotificacion.put("des_ruc_razon_social",declaracion.getDua().getDeclarante().getNombreRazonSocial());
			try{
				grabarNotificacionesVP(declaracionBD, datosNotificacion);
			}catch(Exception e){
				log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir la rectificaci�n
			}

			// Notificamos al buz�n del agente aduanero
			String codUsuario = declaracion.getDua().getAgenteAduanas().getNumeroDocumentoIdentidad()!=null?declaracion.getDua().getAgenteAduanas().getNumeroDocumentoIdentidad():declaracion.getDua().getNumdocumento();
			datosNotificacion.put("cod_usuario", codUsuario);

			//			<EHR RIN 10>
			razonSocial = diligenciaService.obtenerAgentesBeneficiarios(declaracion.getDua().getNumcorredoc().toString(), Constantes.CODIGO_TIPO_PARTICIPANTE_AGENCIA);
			datosNotificacion.put("des_ruc_razon_social", razonSocial);

			//			</EHR>
			//datosNotificacion.put("des_ruc_razon_social",declaracion.getDua().getAgenteAduanas().getNombreRazonSocial());
			if(codUsuario!=null){
				try{
					grabarNotificacionesVP(declaracionBD, datosNotificacion);
				}catch(Exception e){
					log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir la rectificaci�n
				}
			}
		}

		return listaWarnings;
	}

	private List<Map<String, String>> grabarRectificacionVPConCanal(Declaracion declaracion, Declaracion declaracionBD, Map<String, Object> variablesIngreso) 
			throws Exception {
		CatalogoAyudaService catalogoayudaservice = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		LiquidaDeclaracionService liquidaDeclaracionService = (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
		List<Map<String, String>> listaWarnings = new ArrayList<Map<String, String>>();

		DatoPago pago = declaracion.getDua().getPago();
		DatoPagoDecla decla = pago != null ? pago.getPagoDeclaracion() : null;

		Boolean tieneIndicadorVP = variablesIngreso.containsKey("tieneIndicadorVP") ? (Boolean) variablesIngreso.get("tieneIndicadorVP") : false;
		Boolean transmiteItemVP = variablesIngreso.containsKey("transmiteItemVP") ? (Boolean) variablesIngreso.get("transmiteItemVP") : false;
		Boolean todosItemsValorDefinitivo = variablesIngreso.containsKey("todosItemsValorDefinitivo") ? (Boolean) variablesIngreso.get("todosItemsValorDefinitivo") : false;
		Boolean tieneGarantia160 = variablesIngreso.containsKey("tieneGarantia160") ? (Boolean) variablesIngreso.get("tieneGarantia160") : false;
		Boolean modificarLC = variablesIngreso.containsKey("modificarLC") ? (Boolean) variablesIngreso.get("modificarLC") : false;
		Boolean acogerGarantia160 = variablesIngreso.containsKey("acogerGarantia160") ? (Boolean) variablesIngreso.get("acogerGarantia160") : false;
		Boolean declaracionDiligenciada = variablesIngreso.containsKey("declaracionDiligenciada") ? (Boolean) variablesIngreso.get("declaracionDiligenciada") : false;
		declaracion.getDua().setAnnpresen(declaracionBD.getDua().getAnnpresen());// para bug cambio mol
		HashMap<String, String> datosNotificacion = new HashMap<String, String>();

		// 1. Para una Declaraci�n SIN Valor Provisional
		if (!tieneIndicadorVP) {
			if (transmiteItemVP && !tieneGarantia160) { //erodriguezb (se agrega !tieneGarantia160 - Error en F2)
				//Ya no se generan indicdores, porque no est� en el RIN erodriguezb	
				//grabarDeclaracionService.grabarIndicadorPlazoNumeracion(declaracion, declaracionBD.getDua().getNumcorredoc());//RIN10-BUG

				datosNotificacion = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);

				listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_GEN_LC));
				if (TIPO_PAGO_GARANTIA.equals(decla.getCodtipopago()) && decla.getCodgarantia() != null) {
					datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_LCVP_GARANTIA160);
					datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_01);
				} else {
					datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_LCVP_SINGARANTIA160);
					//Inicio RIN10 mpoblete BUG 22094
					//datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_24);
					datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_06);
					//Fin RIN10 mpoblete BUG 22094
				}
			}
		}
		// 2. Declaraci�n con Valor Provisional
		else {
			// 2.1 Modifica todos los �tems a Valor Definitivo
			if (todosItemsValorDefinitivo) {
				if (!declaracionDiligenciada) {
					// Verificar en comparacionVP()
				} else {
					if(SunatDateUtils.esFecha1MayorQueFecha2(SunatDateUtils.getCurrentDate(), 
							declaracionBD.getDua().getFecfinprovsional(), "COMPARA_SOLO_FECHA")){
						listaWarnings.add(catalogoayudaservice.getError(Constants.COD_NOTIF_SEIDA_REGUL_VP_EXTEM));
					}

				}

			}
			// 2.2
			else if (transmiteItemVP) {
				// 2.2.1 Duan sin garant�a art. 160 y sin acogerse a garant�a
				// art. 160

				//mol para solucionar bug // PAS20171U220200048 - La anulacion - generacion de LCs se realiza al momento de evaluar la Solicitud de Rectificacion 
//				if (!tieneGarantia160 && !acogerGarantia160) {
//					ValidadorValorProvisionalService validadorValorProvisionalService = (ValidadorValorProvisionalService)fabricaDeServicios.getService("ingreso.validadorValorProvisionalService");
//					BigDecimal mtoSaldoPorCubrir = validadorValorProvisionalService.obtenerSaldoPorCubrir(declaracion);
//					BigDecimal montoLC = obtenerMontoLCGeneradaVP(declaracion);
//					//fix INC 2016-102203 amancilla se anula y genera LC por las puras la diferencia son por decimales
//					//if(tieneLCVPGenerado(montoLC) &&  mtoSaldoPorCubrir.compareTo(montoLC) == 1){
//					BigDecimal diferenciaAjuste = SunatNumberUtils.absoluteDiference(mtoSaldoPorCubrir, montoLC);
//					BigDecimal tolerancia = new BigDecimal(1);  //1 dolar ojo que esta tolerancia se deberia coordinar con nromativa
//					if(tieneLCVPGenerado(montoLC) &&  diferenciaAjuste.compareTo(tolerancia) == 1){
//						//fin INC 2016-10220 amancilla
//						LiquidaDeclaracionService liquidaDeclaracionService =  (LiquidaDeclaracionService)fabricaDeServicios.getService("liquidaDeclaracionService");
//						// si existe una lc asociada a la declaracion, se procede a anular
//						Map<String, String> resultadoTmp = liquidaDeclaracionService.anularLiquidacionCobranza(declaracionBD);
//						datosNotificacion = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);
//						datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_LCVP_SINGARANTIA160);
//						datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_06);
//
//					}else{
//						if(!tieneLCVPGenerado(montoLC)){
//							datosNotificacion = liquidaDeclaracionService.generarLCVP(declaracion, variablesIngreso);
//							datosNotificacion.put("des_asunto",	Constants.ASUNTO_NOTIF_LCVP_SINGARANTIA160);
//							datosNotificacion.put("codigo_plantilla", Constants.COD_NOTIF_RECTIF_06);
//						}
//					}
//					// fin mol
//				}
			}
		}
		if (datosNotificacion.containsKey("codigo_plantilla")) {
			// Notificamos al buz�n del importador
			datosNotificacion.put("cod_usuario", declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			//			<EHR>
			DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
			String razonSocial = "RAZON SOCIAL NO UBICADO EN LA TABLA PARTICIPANTE_DOC";

			razonSocial = diligenciaService.obtenerAgentesBeneficiarios(declaracion.getDua().getNumcorredoc().toString(), Constantes.CODIGO_TIPO_PARTICIPANTE);

			datosNotificacion.put("des_ruc_razon_social", Utilidades.retirarTildeParaAsuntoNotificacion(razonSocial));
			//			</EHR>
			//datosNotificacion.put("des_ruc_razon_social",declaracion.getDua().getDeclarante().getNombreRazonSocial());
			try{
				grabarNotificacionesVP(declaracionBD, datosNotificacion);
			}catch(Exception e){
				log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir la rectificaci�n
			}

			// Notificamos al buz�n del agente aduanero
			String codUsuario = declaracion.getDua().getAgenteAduanas().getNumeroDocumentoIdentidad()!=null?
					declaracion.getDua().getAgenteAduanas().getNumeroDocumentoIdentidad():
						declaracion.getDua().getNumdocumento();
					datosNotificacion.put("cod_usuario", codUsuario);
					//			<EHR RIN 10>
					razonSocial = diligenciaService.obtenerAgentesBeneficiarios(declaracion.getDua().getNumcorredoc().toString(), Constantes.CODIGO_TIPO_PARTICIPANTE_AGENCIA);
					datosNotificacion.put("des_ruc_razon_social", Utilidades.retirarTildeParaAsuntoNotificacion(razonSocial));

					//			</EHR>
					//datosNotificacion.put("des_ruc_razon_social",declaracion.getDua().getAgenteAduanas().getNombreRazonSocial());

					try{
						if(codUsuario!=null)
							grabarNotificacionesVP(declaracionBD, datosNotificacion);
					}catch(Exception e){
						log.error(e.getStackTrace()); //Si existe error en grabado de notificaciones, no se debe impedir la rectificaci�n
					}
		}
		return listaWarnings;
	}
	//mol
	private static boolean tieneLCVPGenerado(BigDecimal montoLC) {
		return montoLC.compareTo(BigDecimal.ZERO)==1;
	}
	public BigDecimal obtenerMontoLCGeneradaVP(Declaracion declaracion)
	{

		// Obtener n�mero de liquidaci�n
		DeudaDocum tmpDeudaDocum = new DeudaDocum();
		tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
		tmpDeudaDocum.setCodTipdeuda(ConstantesDataCatalogo.DEUDA_TIPO_LIQ_COBR);
		// tmpDeudaDocum.setMtoGarant(BigDecimal.ZERO); NO DESCOMENTAR


		List<DeudaDocum> result = ((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDAO")).obtenerLiquidacion(tmpDeudaDocum);

		BigDecimal montoLC = BigDecimal.ZERO;
		if (!CollectionUtils.isEmpty(result)){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("rlarea", declaracion.getDua().getCodregimen());
			params.put("rladuaso", declaracion.getCodaduana());
			params.put("rlanoaso", declaracion.getDua().getAnnpresen().toString().substring(2));
			String numAso = declaracion.getNumeroDeclaracion().toString();
			numAso = SunatStringUtils.lpad(numAso, 6, '0');
			params.put("rlnumaso", numAso);
			params.put("LIST_RLNROLIQ", result);
			params.put("indValprov", TIENE_VALOR_PROVISIONAL);
			params.put("rlfeceli","0");

			Liquida record = ((LiquidaDAO)fabricaDeServicios.getService("liquidaDef")).getLCbyDeclaAndNumLiquida(params);
			montoLC = "S".equals(record.getRlcodmon())?record.getRlsmontot():record.getRldmontot();
			montoLC = montoLC != null? montoLC : BigDecimal.ZERO;

		}
		return montoLC;
	}
	// fin mol
	/*INICIO-RIN10 FSW AFMA*/
	//private void grabarNotificacionesVP(Declaracion declaracion, Map<String, String> variablesIngreso) {
	public void grabarNotificacionesVP(Declaracion declaracion, Map<String, String> variablesIngreso) {
		/*FIN-RIN10 FSW AFMA*/
		CatalogoAyudaService catalogoayudaservice = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DdpDAOService ddpDAOService = (DdpDAOService)fabricaDeServicios.getService("Ayuda.ddpService");
		FechaBean fechaActual = new FechaBean();
		FechaBean fechaVigencia = new FechaBean();
		fechaVigencia.setFecha("31/12/9999");

		FechaBean fechaDeclara = new FechaBean();
		fechaDeclara.setFecha(declaracion.getDua().getFecdeclaracion());

		Map<String, Object> mapMensaje = new HashMap<String, Object>();
		String descAduana = "";
		descAduana = catalogoayudaservice.getDescripcionDataCatalogo(
				Constants.COD_CATALOG_ADUANA, declaracion.getDua().getCodaduanaorden());

		String strNumeroDeclaracion = declaracion.getNumeroDeclaracion().toString().trim();

		int j = strNumeroDeclaracion.length();
		for (int i = 0; i < 6 - j; i++) {
			strNumeroDeclaracion = "0" + strNumeroDeclaracion;
		}

		// Notificaci�n al Despachador de Aduana por Rectificaci�n de Dua
		mapMensaje.put("tip_usuario", variablesIngreso.get("tip_usuario") != null ? variablesIngreso.get("tip_usuario") : "1"); // default contribuyente
		String codUsuario = variablesIngreso.get("cod_usuario");
		mapMensaje.put("cod_usuario", new String[] { codUsuario!=null? codUsuario:"" });

		// Busco raz�n social si no se recibe este dato
		if(variablesIngreso.get("des_ruc_razon_social")==null){
			Map razonSocial = new HashMap();
			razonSocial = ddpDAOService.findByPK(declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			if (!CollectionUtils.isEmpty(razonSocial))
				mapMensaje.put("des_ruc_razon_social", Utilidades.reemplazaCaracterEspecialEnHtml(razonSocial.get("ddp_nombre").toString().trim()));
		}else{
			mapMensaje.put("des_ruc_razon_social",Utilidades.reemplazaCaracterEspecialEnHtml(variablesIngreso.get("des_ruc_razon_social")));
		}

		mapMensaje.put("fecha_emision", fechaActual.getFormatDate("dd/MM/yyyy").toString());
		mapMensaje.put("cod_aduana", declaracion.getDua().getCodaduanaorden());
		mapMensaje.put("des_intendencia", descAduana);
		mapMensaje.put("ann_presen", fechaDeclara.getAnho().toString());
		mapMensaje.put("cod_regimen", declaracion.getDua().getCodregimen().toString());
		mapMensaje.put("num_declaracion", strNumeroDeclaracion);
		mapMensaje.put("numruc", variablesIngreso.get("cod_usuario"));
		String dua = declaracion.getDua().getCodaduanaorden() + "-"
				+ declaracion.getDua().getAnnpresen().toString() + "-"
				+ declaracion.getDua().getCodregimen().toString() + "-"
				+ declaracion.getNumeroDeclaracion().toString();

		mapMensaje.put("dua", dua);

		String strMonedaDesc = "";
		String strMontoMoneda = "";

		// VARIABLES DE NUEVA LC
		mapMensaje.put("lc", variablesIngreso.get("lc"));
		mapMensaje.put("aduana_lc", variablesIngreso.get("aduana_lc"));
		mapMensaje.put("anno_lc", variablesIngreso.get("anno_lc"));
		mapMensaje.put("numero_lc", variablesIngreso.get("numero_lc"));
		mapMensaje.put("porcentaje_bivp", variablesIngreso.get("bivp"));
		mapMensaje.put("bivp",variablesIngreso.get("bivp"));//BUG RIN10 KAH
		mapMensaje.put("monto_lc", variablesIngreso.get("monto_lc"));

		// VARIABLES DE LC ANTERIOR
		mapMensaje.put("lc_anul", variablesIngreso.get("lc_anul"));
		mapMensaje.put("aduana_lc_anul", variablesIngreso.get("aduana_lc_anul"));
		mapMensaje.put("anno_lc_anul", variablesIngreso.get("anno_lc_anul"));
		mapMensaje.put("numero_lc_anul", variablesIngreso.get("numero_lc_anul"));
		mapMensaje.put("monto_lc_anul", variablesIngreso.get("monto_lc_anul"));
		mapMensaje.put("des_asunto", variablesIngreso.get("des_asunto"));
		String unidadRemitente = ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(declaracion.getDua().getCodaduanaorden())?Constants.EMITE_NOTIF_DIV_IMP_IAMC : Constants.EMITE_NOTIF_DEP_TEC_ADUA;
		mapMensaje.put("des_unidad_organica", unidadRemitente);

		Integer codigoNotifLCVP = Integer.parseInt(variablesIngreso.get("codigo_plantilla"));

		/*INICIO-P34 FSW AFMA*/

		String nroSolicitud = variablesIngreso.get("nroSolicitud")!=null?variablesIngreso.get("nroSolicitud").toString():"";
		if(!StringUtils.isEmpty(nroSolicitud)){
			mapMensaje.put("numero_solicitud_rectificacion", nroSolicitud);
		}
		/*FIN-P34 FSW AFMA*/

		for (Map.Entry<String, Object> entry : mapMensaje.entrySet()) {
			if (entry.getValue() == null || entry.equals(""))
				mapMensaje.put(entry.getKey(), "-");
		}

		StringBuffer data = new StringBuffer(SojoUtil.toJson(mapMensaje));
		PublicacionAvisoService publicacionAvisoService = (PublicacionAvisoService) fabricaDeServicios.getService("servicio.avisos.service.publicacionAvisoService");
		publicacionAvisoService.insert(codigoNotifLCVP, data,Constants.CODIGO_TIPO_AVISO_NOTIFICACION,fechaActual.getTimestamp(), fechaVigencia.getTimestamp());
	}

	/*RIN10 FSW AFMA 3007*/
	public String desafectarGarantia(DUA dua, HashMap<String, String> datosLiquidacion, Map<String, Object> variablesIngreso)
			throws Exception {

		String numCtaCte = dua.getPago().getPagoDeclaracion().getCodgarantia();
		if (StringUtils.isEmpty(numCtaCte))	return "";	
		String rucImportador = dua.getDeclarante().getNumeroDocumentoIdentidad();
		String tipoMoneda = datosLiquidacion.get("cod_moneda_lc_anul");
		String mtoAfectado = datosLiquidacion.get("monto_lc_anul");
		String numLC = datosLiquidacion.get("numero_lc_anul");
		mtoAfectado = mtoAfectado != null ? mtoAfectado : "0";
		BigDecimal monto = BigDecimal.valueOf(DecimalFormat.getInstance(Locale.US).parse(mtoAfectado).doubleValue());
		monto = monto.setScale(0, BigDecimal.ROUND_HALF_UP);
		String cRegimen = "96";
		BigDecimal nTipoCamnio = BigDecimal.ZERO;
		String tipoExtincion = COD_TIPOS_EXTINCION_DEUDA_ANULACION_LEGAJAMIENTO;
		String cda = datosLiquidacion.get("cda_lc_anul");

		String resp = "";

		if (!"0".equals(mtoAfectado)) {
			//			GrabarGeneralService grabarGeneralService = (GrabarGeneralService) fabricaDeServicios.getService("GrabarGeneralService");
			//			resp = grabarGeneralService.desafectaGarantiaDocumento(
			//					rucImportador, tipoExtincion, numCtaCte, nTipoCamnio, dua,
			//					cda, monto, tipoMoneda, tipoDeuda, variablesIngreso);
			//erodriguezb RIN10 bug 21089
			Map<String, Object> params = new HashMap <String, Object>();
			params.put("cRUC", rucImportador); // RUC del beneficiario
			params.put("cTIPOEXTIN", tipoExtincion); 
			params.put("cADUANA", dua.getCodaduanaorden());
			params.put("cANO", dua.getAnnpresen().toString().substring(2, 4));
			params.put("cREGIMEN", cRegimen);
			params.put("cNUMERO", numLC);
			params.put("cCDA", cda);
			params.put("nMONTOA", monto); 
			params.put("cMONEDAA", tipoMoneda);
			params.put("nTIPOCAM", nTipoCamnio);
			params.put("nFECHA", SunatDateUtils.getCurrentIntegerDate());
			params.put("cDOCUMENTO",numCtaCte);
			params.put("cTRANS", " ");

			resp = (String) ((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarDesafectarGarantia(params);
		}
		return resp;


	}
/*
	public void setPublicacionAvisoService(
			PublicacionAvisoService publicacionAvisoService) {
		this.publicacionAvisoService = publicacionAvisoService;
	}


	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

*/
	//@Override
	//lmvr - pase105 - Inicio
	public void actualizaFechaVencimientoDocumentosDeudaSinIndicencia(
			Declaracion declaracion,Declaracion declaracionBD, Map<Object, Object> mapManifiesto) {	
		/*String codModalidaBD=declaracionBD.getDua().getCodmodalidad();
		if(declaracion.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL)
		    && 	SunatStringUtils.isStringInList(codModalidaBD, ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO+","+ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
		    ){*/

		//actualiza la fecha de vencimiento de pago de la DUA (Formato C cancelado o no cancelado) 
		Date dtFecVencimientoDespacho=obtenerFechaVencimientoDespacho(declaracion,mapManifiesto);
		//Date dtFecVencimientoDespachoFormat= Date() SunatDateUtils.getFormatDate(dtFecVencimientoDespacho, "dd/MM/yyyy");
		Date dtFecVencimientoDespachoFormat=SunatDateUtils.getOnlyDateFrom(dtFecVencimientoDespacho);

		DeudaDocum tmpDeu=new DeudaDocum();
		tmpDeu.setNumCorredoc(declaracion.getDua().getNumcorredoc());
		tmpDeu.setCodTipdeuda("01") ; // formato c
		tmpDeu.setFecVenc(dtFecVencimientoDespachoFormat);
		//RectificacionServiceImpl.getInstance().getDeudaDocumDAO().updateDeudaDocumByParams(tmpDeu);
		((DeudaDocumDAO)fabricaDeServicios.getService("deudaDocumDef")).updateDeudaDocumByParams(tmpDeu);
		/*	}*/
	}

	//lmvr - pase105 - Fin

	private boolean contingente(Declaracion declaracion,Declaracion declaracionBD,  SolicitudRectificacionBean solicitudRectificacion) throws Exception{ 	
		List<DetSolicitudRectificacionBean> detalleSolicitud=solicitudRectificacion.getListaCambios();
		if(!CollectionUtils.isEmpty(detalleSolicitud)){
			int secCambio=0;

			JsonSerializer serializer = new JsonSerializer();
			ObjectUtil util = serializer.getObjectUtil();
			util.addFormatterForType(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"), Date.class);


			// por cada registro(cambio)
			for(DetSolicitudRectificacionBean detalle: detalleSolicitud ){
				secCambio++;
				Map<String,Object> mapDetSolRecti=new HashMap<String, Object>();
				mapDetSolRecti.put("numCorredoc",solicitudRectificacion.getNumcorredoc() );
				mapDetSolRecti.put("numSeccambio", secCambio);
				mapDetSolRecti.put("codTabla",detalle.getCodtabla() );
				Map<String,Object> mpClave=new HashMap<String, Object>();
				Map<String,Object> mpDatos=new HashMap<String, Object>();
				Map<String,Object> mpDatosAnterior=new HashMap<String, Object>();
				mpClave.putAll(detalle.getKey());
				mapDetSolRecti.put("desClave", SojoUtil.toJson(mpClave));

				if ("T0060".equals(detalle.getCodtabla() ) ) {
					if ( "16".equals(  mpClave.get("COD_INDICADOR").toString().trim()) ) {
						return false;
					}

				}


				if ("T0052".equals(detalle.getCodtabla() ) ) {
					// generando el json del desdata1 y desAntdata1
					for(String campo: detalle.getDatosRectificados().keySet()){
						// no considerar los datos bloqueados

						if ("COD_TIPMARGEN".equals(campo.trim()) ) {
							DatoRectificacionBean drRec=(DatoRectificacionBean)detalle.getDatosRectificados().get(campo);
							if(StringUtils.hasText(drRec.getFlagBloqueo())){
								continue;
							}
							else{
								Object datoNuevo=formatearObjeto(drRec.getDatoNuevo());

								if ("5".equals(datoNuevo.toString().trim() ) ) {

									DatoIndicadores indicador = new DatoIndicadores();
									indicador.setNumeroCorrelativo(declaracion.getDua().getNumcorredoc());
									indicador.setCodigoIndicador("16");
									indicador.setIndicadorActivo(Constantes.IND_ACTIVO);
									IndicadorDUADAO indicadorDUADAO = (IndicadorDUADAO) fabricaDeServicios.getService("indicadorDUADAO");
									if(indicadorDUADAO.existeIndicadorByParams(indicador).compareTo(Constantes.INT_UNO) == 0){
										return false;		
									}								


								}
							}
						}
					}
				}

			}
		}
		return true;
	}
	private boolean validarSiRectificaSoloPuntoLlegada(SolicitudRectificacionBean solicitudRectificacion){
		List<DetSolicitudRectificacionBean> detalleSolicitud=solicitudRectificacion.getListaCambios();
		boolean otrosDatos = false;
		for(DetSolicitudRectificacionBean detalle: detalleSolicitud){
			if("T0051".equals(detalle.getCodtabla())) {
				for(String campo: detalle.getDatosRectificados().keySet()){
					//RECTIFICACION CODIGO PUNTO LLEGADA, RUC
					if (!"COD_LUGARRECEP".equals(campo.trim()) && !"COD_RUCLUGRECEP".equals(campo.trim())
							&&!"COD_LOCALANEXO".equals(campo.trim())){
						otrosDatos = true;
						break;
					}
				}
			}else{
				if(!"T0083".equals(detalle.getCodtabla()) && !"T0087".equals(detalle.getCodtabla())) {
					otrosDatos = true;
					break;
					
				}
			}
		}
		return !otrosDatos;
	}

	private Boolean isRectificaSoloModalidadAnticipadoADiferido(Boolean rectificaAnticipadoADiferido,SolicitudRectificacionBean solicitudRectificacion){
		List<DetSolicitudRectificacionBean> detalleSolicitud=solicitudRectificacion.getListaCambios();
		boolean otrosDatos = false;
		if(rectificaAnticipadoADiferido) {
			for (DetSolicitudRectificacionBean detalle : detalleSolicitud) {
				if ("T0051".equals(detalle.getCodtabla())) {
					for (String campo : detalle.getDatosRectificados().keySet()) {
						//RECTIFICACION modalidad y obligatoriamente para diferidas elimina el lugar de recepcion
						if (!"COD_MODALIDAD".equals(campo.trim()) && !"COD_TIPLUGARRECEP".equals(campo.trim())) {
							otrosDatos = true;
							break;
						}
					}
				}
			}
		}
		return !otrosDatos;
	}
	
	//PAS20181U220200056
	private void RegistroUsoCertificadoOrigenElectronico(Map<String,Object> datos, Declaracion declaracion, String codTransaccion) {
		Boolean esValidoVUCECO = ((CertiOrigenElectronicoService)fabricaDeServicios.getService("certiOrigenElectronicoService"))
	    		  .esValidoCambiosDiligVUCECO(SunatDateUtils.getCurrentDate());
		if(esValidoVUCECO) { //Correccion al pase 56
			final String URL_VUCE_CERT_ELECT = "http://api.sunat.peru/v1/estrategico/vuce/e/certificadoorigenelectronico";
			//final String URL_VUCE_CERT_ELECT = "http://localhost:7001/ol-ad-aduanerovucews/certificadoorigenelectronico";		
			String codTipoElect = datos.get("IND_ELECTRONICO") != null ? datos.get("IND_ELECTRONICO").toString(): null;
			String numCertificado = datos.get("NUM_CERTIFICADO")!=null? datos.get("NUM_CERTIFICADO").toString():null;
			if(!codTransaccion.endsWith("01") && numCertificado!=null) { 
					  DocCertificadoOrigen  docCertificadoOExiste = new DocCertificadoOrigen();
					  docCertificadoOExiste = ((CertiOrigenElectronicoService)fabricaDeServicios.getService("certiOrigenElectronicoService"))
							  .consultarCertificadoElectronico("0", numCertificado);
				if( docCertificadoOExiste !=null && docCertificadoOExiste.getNumeroCertificadoOrigen()!=null) {
					codTipoElect = INDICADOR_CERT_ELECTRONICO;
				}
					
			}
			if(INDICADOR_CERT_ELECTRONICO.equalsIgnoreCase(codTipoElect)) {
				try{
					numCertificado = datos.get("NUM_CERTIFICADO").toString();
					DocCertificadoOrigen docCertificadoOrigen = new DocCertificadoOrigen();
					docCertificadoOrigen.setNumeroCertificadoOrigen(numCertificado);
					docCertificadoOrigen.setNumeroCorrelativoDAMUso(declaracion.getNumeroCorrelativo());
					docCertificadoOrigen.setCodTransaccionUso(codTransaccion);
					docCertificadoOrigen.setNumeroDAMUso(declaracion.getNumeroDeclaracion().toString());				
					RestTemplate restTemplate = new RestTemplate();
					String responseUpdate = restTemplate.postForObject(URL_VUCE_CERT_ELECT, docCertificadoOrigen, String.class);
	                log.info("RegistroUsoCertificadoOrigenElectronicio " + responseUpdate);
				}
				catch(Exception e){
					log.info("Error RegistroUsoCertificadoOrigenElectronicio : " + e.getMessage());
				}
			}
		}
			
		}
}
