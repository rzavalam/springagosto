package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.exception;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
/**
 * Created by amancillaa on 08/05/14.
 */
public class DescrMinimaException extends ServiceException {

    private ErrorDescrMinima error;

    public ErrorDescrMinima getError() {
        return error;
    }

    public DescrMinimaException(Object origen, ErrorDescrMinima error) {

        super();
        this.error = error;
        Log log = LogFactory.getLog(origen.getClass());
        log.error(origen.getClass().getName() + "|" +error.getDetalle());
        log.debug("Error", this);
    }


}
