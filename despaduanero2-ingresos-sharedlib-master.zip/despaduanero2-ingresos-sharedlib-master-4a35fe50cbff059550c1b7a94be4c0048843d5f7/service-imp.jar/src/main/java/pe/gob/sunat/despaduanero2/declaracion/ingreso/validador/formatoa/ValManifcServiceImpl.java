/*
 * Clase que define el servicio de validaciones de la seccion del Manifiesto.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorValidaService;
import pe.gob.sunat.despaduanero2.declaracion.model.*;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.manifiesto.model.DocumentoDeTransporte;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.manifiesto.model.Mcdeta;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.DocuTransDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.model.dao.ParticipanteDocDAO;
import pe.gob.sunat.despaduanero2.util.ConstantesAsociacionCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;//PAS20181U220200049

import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValManifc. Clase que define el servicio de validaciones de la
 * seccion del Manifiesto.
 */
public class ValManifcServiceImpl extends ValDuaAbstract implements ValManifc {

	// private ProveedorFuncionesService funcionesService;
	// private ValParticipante valParticipante;
	// private FabricaDeServicios fabricaDeServicios;

	/**
	 * Valida el Codigo de la modalida de transporte o via de transporte.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codmodtransp String. Codigo de la modalida de transporte o via de transporte.
	 * @return Map
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2074)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "codmodtransp" })
	@OrquestaDespaAnnot(codServInstancia = 2074, numSecEjec = 74, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> codmodtransp(String codmodtransp, Date fechaReferencia, String codaduamanif) {

		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			DataGrupoCat datosGrupoUnece = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataGrupoCat(
							ConstantesGrupoCatalogo.GRUPO_CATALOGO_VIA_MANIF_SIGAD_PARA_SDA, codmodtransp,fechaReferencia);

			// busca en la 227:
			Map<String, Object> mapCatalogo = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoCat(
					ConstantesDataCatalogo.COD_CATALOGO_VIA_TRANSPORTE_UNECE, codmodtransp, fechaReferencia);

			if (mapCatalogo == null && datosGrupoUnece == null || CollectionUtils.isEmpty(mapCatalogo) && datosGrupoUnece == null) {
				//TIPO DE VIA DEL MANIFIESTO INVALIDA, CONSIGNE UNA VIA DE TRANSPORTE DEL CATALOGO 227
				return getDUAError("50112", "Error catalogo codmodtransp");
			} else {
				// busca en sda vc unece (10 vs 227):
				
				Map<String, Object> mapAsocAduanaVia = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getElementoAsoc(ConstantesAsociacionCatalogo.CATALOGO_ASOCIACION_ADUANA_VIA_TRANSPORTE, codaduamanif,codmodtransp, fechaReferencia);
				if (mapAsocAduanaVia == null && datosGrupoUnece == null || mapAsocAduanaVia.isEmpty() && datosGrupoUnece == null) {
					//TIPO DE VIA DEL MANIFIESTO INVALIDA PARA LA ADUANA
					return getDUAError("50113", "Error catalogo codmodtransp");
				}
			}
		}

		return new HashMap<String, String>();
	}

	/**
	 * Valida el codigo del puerto del manifiesto.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codpuermanif String. Codigo del puerto del manifiesto.
	 * @return Map
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2075)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "codpuermanif" })
	@OrquestaDespaAnnot(codServInstancia = 2075, numSecEjec = 75, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> codpuermanif(String codpuermanif) {
		// Se reemplazo por codpuerto
		return new HashMap<String, String>();
	}

	/**
	 * Valida el codigo de la aduana del manifiesto.<br>
	 * Valida que este lleno y el valor sea diferente de '000'.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codaduamanif String. Codigo de la aduana del manifiesto.
	 * @return Map
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2076)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "codaduamanif" })
	@OrquestaDespaAnnot(codServInstancia = 2076, numSecEjec = 76, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> codaduamanif(String codaduamanif) {
		// SPTD_ADUAHDR1 46
		if (!SunatStringUtils.isEmptyTrim(codaduamanif)) {
			// if (FormatoAServiceImpl.getInstance().isValidCatalogo("00", codaduamanif))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService) fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("00", codaduamanif, SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String, String>();
			else
				return getDUAError("00014", "Error catalogo codaduamanif");
		} else {
			return new HashMap<String, String>();
		}
	}

	/**
	 * Valida el codigo del tipo de manifiesto.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipomanif String. Codigo del tipo de manifiesto.
	 * @return Map
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2077)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "codtipomanif" })
	@OrquestaDespaAnnot(codServInstancia = 2077, numSecEjec = 77, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> codtipomanif(String codtipomanif) {
		// if (FormatoAServiceImpl.getInstance().isValidCatalogo("202", codtipomanif))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService) fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("202", codtipomanif, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo && ConstantesDataCatalogo.TIPO_MANIFIESTO_INGRESO.equals(codtipomanif))
			return new HashMap<String, String>();
		else
			return getDUAError("30025", "Error catalogo codtipomanif");
	}

	/**
	 * Valida el a�o del manifiesto.<br>
	 * Valida que el par&aacute;metro sea una cadena de cuatro d&iacute;gitos.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param annmanif String. A�o del manifiesto.
	 * @return Map
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2078)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "annmanif" })
	@OrquestaDespaAnnot(codServInstancia = 2078, numSecEjec = 78, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> annmanif(String annmanif) {
		// SPTD_ADUAHDR1 47
		if (!SunatStringUtils.isEmptyTrim(annmanif)) {
			String anho = annmanif.substring(0, 4);
			return (SunatStringUtils.isNumeric(anho) && anho.length() == 4) ? new HashMap<String, String>() : getDUAError("00015", "ANNO_MANIF - NO TRANSMITIO");
			// return (SunatStringUtils.isNumeric(annmanif) && annmanif.length()==4)?new
			// HashMap<String,String>():getDUAError("8505","ANNO_MANIF - NO TRANSMITIO");
		} else
			return new HashMap<String, String>();
	}

	/**
	 * Valida el numero de manifiesto.<br>
	 * Valida que el par&aacute;metro no sea vacio.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param nummanif String. Numero de manifiesto.
	 * @return Map
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2079)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "nummanif" })
	@OrquestaDespaAnnot(codServInstancia = 2079, numSecEjec = 79, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> nummanif(String nummanif) {
		if ((!SunatStringUtils.isEmptyTrim(nummanif) && !"0".equals(nummanif))) {
			if (nummanif.length() <= 5)
				return new HashMap<String, String>();
			else
				return getDUAError("00016", "NUME_MANIF - NO TRANSMITIO NUMERO DEl MANIFIESTO - " + nummanif);
		} else {
			return new HashMap<String, String>();
		}

	}

	/**
	 * Valida la fecha de llegada excepcional.<br>
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fectermino Date. Fecha de llegada excepcional.
	 * @param variablesIngreso Map<String,Object>
	 * @param fechaReferencia Date
	 * @return Map
	 */

	@ServicioAnnot(tipo = "V", codServicio = 2080)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "fectermino" })
	@OrquestaDespaAnnot(codServInstancia = 2080, numSecEjec = 80, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> fectermino(Date fectermino, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		ValModalidadService valModalidadService = (ValModalidadService) fabricaDeServicios.getService("ingreso.ValModalidad");
		ProveedorFuncionesService funcionesService = (ProveedorFuncionesService) fabricaDeServicios.getService("funcionesService");
		String codModalidad = (String) variablesIngreso.get("codModalidad");
		Declaracion declaracion = (Declaracion) variablesIngreso.get("declaracion");
		boolean buscarManifiestoSigadActual = false;
		// buscarManifiestoSigadActual = ("4".equals(declaracion.getDua().getManifiesto().getCodmodtransp()) || "7".equals(declaracion.getDua().getManifiesto().getCodmodtransp()));
		buscarManifiestoSigadActual = (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(declaracion.getDua().getManifiesto().getCodmodtransp()) || ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO.equals(declaracion.getDua().getManifiesto().getCodmodtransp()));

		DatoManifiesto manif = declaracion.getDua().getManifiesto();
		String codaduamanif = manif.getCodaduamanif();
		String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
		String nummanif = manif.getNummanif();
		String codmodtransp = manif.getCodmodtransp();
		String codtipmanif = manif.getCodtipomanif();
		Manifiesto manifiesto = null;
		/** PAS20181U220200049 inicio ***/
		List<Map<String, String>> listaOMA = ((CatalogoValidaService) fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380", "0043", fechaReferencia);
		if (!ResponseListManager.responseListHasErrors(listaOMA)) {
			boolean evaluarEER = declaracion.getDua().getCodlugarecepcion() != null && declaracion.getDua().getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR) ? true : false;
			buscarManifiestoSigadActual = true;// que busque en bdsigad y en sigad
			manifiesto = ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif,SunatNumberUtils.toInteger(annmanif), nummanif, true, fechaReferencia, evaluarEER);
		} else {/** PAS20181U220200049 fin ***/
			manifiesto = ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService")).findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif,SunatNumberUtils.toInteger(annmanif), nummanif, buscarManifiestoSigadActual);
		}
		/* Fin SAU20153K004000335 */

		String codTransaccion = (String) variablesIngreso.get("codTransaccion");
		boolean isTxDilig = funcionesService.isTransaccionDiligencia(codTransaccion);
		boolean isTxDiligDespacho = (codTransaccion.endsWith(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_DESPACHO_VALIDACION) ? true : false);

		if (fectermino != null) {
			Integer iFechaReferencia = SunatDateUtils.getIntegerFromDate(fechaReferencia);
			Integer iFecTermino = SunatDateUtils.getIntegerFromDate(fectermino);
			Date fechaNumeracionDeclaracion = null;
			Date fechaLlegadaManifiesto = null;
			int numManifDUA = 0;// adicionado por correccion arey
			if (codTransaccion.endsWith("03") || isTxDilig) {
				Map<String, Object> declaracionBDMap = null;
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("codigoAduana", declaracion.getNumdeclRef().getCodaduana());
				params.put("annoPresentacion", declaracion.getNumdeclRef().getAnnprese());
				params.put("codigoRegimen", declaracion.getNumdeclRef().getCodregimen());
				params.put("numeroDeclaracion", declaracion.getNumdeclRef().getNumcorre());
				List<Map<String, Object>> lstdua = ((CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO")).listCabDeclaraMapByParameterMap(params);

				if (!CollectionUtils.isEmpty(lstdua)) {
					declaracionBDMap = lstdua.get(0);
					fechaNumeracionDeclaracion = (Date) declaracionBDMap.get("fecdeclaracion");
					// PAS20165E220200071 RSERRANOV M_SNADE279 - Adecuaciones en la Regularizaci�n
					numManifDUA = declaracionBDMap.get("nummanif") != null? new Integer(declaracionBDMap.get("nummanif").toString().trim().equals("") ? "0" : declaracionBDMap.get("nummanif").toString()) : 0;// adicionado por correccion arey
				}
			}

			// PAS20145E220000090 - MATC 20140627 - INICIO
			if (SunatDateUtils.isDefaultDate(fectermino)) {
				fectermino = declaracion.getDua().getFecLlegada();
				iFecTermino = SunatDateUtils.getIntegerFromDate(fectermino);
			}

			if (manifiesto != null) {
				if ((Date) manifiesto.getFechaEfectivaDeLlegada() != null && SunatDateUtils.isDefaultDate((Date) manifiesto.getFechaEfectivaDeLlegada())) {
					fechaLlegadaManifiesto = (Date) manifiesto.getFechaProgramadaLlegada();
				} else {
					fechaLlegadaManifiesto = (Date) manifiesto.getFechaEfectivaDeLlegada();
				}
			}

			if (MODALIDAD_ANTICIPADA.equals(codModalidad)) {
				// Integer
				// iFechaMas15dias=SunatDateUtils.getIntegerFromDate(SunatDateUtils.addDay(fechaReferencia,
				// 15));
				if ((codTransaccion.endsWith("03") || isTxDilig)) {
					if (!SunatDateUtils.sonIguales(fectermino, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)) {// PASE 399 EN TXdILIG Entra en default
						if (SunatDateUtils.esFecha1MayorQueFecha2(fechaNumeracionDeclaracion, fectermino, SunatDateUtils.COMPARA_SOLO_FECHA)) {
							return getDUAError("35000","En la modalidad anticipada no puede numerarse despu�s de la fecha de llegada");
						}
					}

					// if( CollectionUtils.isEmpty(mapManifiesto) ) { SAU20153K004000335
					if (manifiesto == null) {
						// para el 03 se saco en otro metodo la validacion del plazo en
						// validarPlazoDuaAnticipadoYUrgenteAnticipado
						if (isTxDilig) {
							if (!valModalidadService.correspondeModalidadAnticipada(fechaNumeracionDeclaracion, fectermino)) {
								// if(SunatDateUtils.esFecha1MenorQueFecha2(SunatDateUtils.addDay(fechaNumeracionDeclaracion, // 15), fectermino, SunatDateUtils.COMPARA_SOLO_FECHA)){
								return getDUAError("35004", "Declaraci�n se encuentra fuera del plazo establecido para la modalidad de despacho anticipado");
							}
						}
					} else {
						// PAS20145E220000195 - 20140707 - P06 Correcci�n Fecha Llegada
						if (!isTxDiligDespacho && !codTransaccion.endsWith("03") && !isTxDilig) {// se incorpora filtro para trx03 debido a que se repite en validarManifiestoCarga bug 18794)
							if (!SunatDateUtils.sonIguales(fechaLlegadaManifiesto, fectermino, SunatDateUtils.COMPARA_SOLO_FECHA)) {
								// return getDUAError("35002","Fecha de llegada consignada en la declaraci�n no corresponde a la consignada en el manifiesto de carga");
								String fechaLlegadaManifiestoActual = SunatDateUtils.getFormatDate(fechaLlegadaManifiesto, "dd/MM/yyyy");
								String fechaLlegadaDUA = SunatDateUtils.getFormatDate(fectermino, "dd/MM/yyyy");
								return getDUAError("35002",new String[] { fechaLlegadaDUA, fechaLlegadaManifiestoActual });
							}
						}
					}
				} else {
					// if(CollectionUtils.isEmpty(mapManifiesto)) { SAU20153K004000335
					if (manifiesto == null) {
						if (!valModalidadService.correspondeModalidadAnticipada(fechaReferencia, fectermino)) {
							// if (iFechaMas15dias < iFecTermino) {
							// pase548
							return getDUAError("35004","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de despacho anticipado");
						}

						if (iFecTermino < iFechaReferencia) {
							return getDUAError("35000","En la modalidad anticipada no puede numerarse despu�s de la fecha de llegada");
						}
					} else {
						if (iFecTermino.intValue() < iFechaReferencia) {
							return getDUAError("35001","Declaraci�n excede el plazo establecido para la modalidad de despacho anticipado");
						}
						/* adicionado por bug 18920 */
						if (!valModalidadService.correspondeModalidadAnticipada(fechaReferencia, fectermino)) {
							// if(iFechaMas15dias!=iFecTermino)
							return getDUAError("35004","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de despacho anticipado");
						}
						/* adicionado por bug 18911 */
						if (manifiesto.getFechaTerminoDeDescarga() != null && !SunatDateUtils.isDefaultDate((Date) manifiesto.getFechaTerminoDeDescarga())) {
							return getDUAError("35003","MERCANCIAS YA SE ENCUENTRAN ARRIBADAS, LA MODALIDAD DE DESPACHO ANTICIPADO SE NUMERA ANTES DEL ARRIBO DEL MEDIO DE TRANSPORTE");
						}

						// PAS20181U220200049 parchada, si se tiene manif, la fecha efectiva de llegada
						// de tener, debe validarse contra la de numeracion
						// el usuario puede haber indicado que llega despues, cuando la nave ya llego
						if ((Date) manifiesto.getFechaEfectivaDeLlegada() != null && !SunatDateUtils.isDefaultDate((Date) manifiesto.getFechaEfectivaDeLlegada())) {
							if (!valModalidadService.correspondeModalidadAnticipada(fechaReferencia, (Date) manifiesto.getFechaEfectivaDeLlegada())) {
								return getDUAError("35004","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de despacho anticipado");
							}
						}

					}
				}
			}
			if (MODALIDAD_EXCEPCIONAL.equals(codModalidad)) {
				// Integer
				// iFechaMas15dias=SunatDateUtils.getIntegerFromDate(SunatDateUtils.addDay(fechaReferencia,
				// 15));
				if (codTransaccion.endsWith("03") || isTxDilig) {
					Declaracion decla = (Declaracion) variablesIngreso.get("declaracion");
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("codigoAduana", decla.getNumdeclRef().getCodaduana());
					params.put("annoPresentacion", decla.getNumdeclRef().getAnnprese());
					params.put("codigoRegimen", decla.getNumdeclRef().getCodregimen());
					params.put("numeroDeclaracion", decla.getNumdeclRef().getNumcorre());
					// List<Map<String,Object>> lstdua=
					// FormatoAServiceImpl.getInstance().getCabDeclaraDAO().listCabDeclaraMapByParameterMap(params);
					List<Map<String, Object>> lstdua = ((CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO")).listCabDeclaraMapByParameterMap(params);
					Map<String, Object> declaracionMap = null;
					if (!CollectionUtils.isEmpty(lstdua)) {
						declaracionMap = lstdua.get(0);
					}
					String modalidadBd = (String) declaracionMap.get("codmodalidad");

					if (MODALIDAD_ANTICIPADA.equals(modalidadBd) && (manifiesto != null)) {

						// rtineo M_SNADE278-1
						Boolean isRectiPermitidoAnticipadoADiferido = variablesIngreso.get("isRectiPermitidoAnticipadoADiferido") != null ? (Boolean) variablesIngreso.get("isRectiPermitidoAnticipadoADiferido") : false;
						// rtineo M_SNADE278-1
						if (!isRectiPermitidoAnticipadoADiferido) {
							// Integer iFecLlegadaReal = SunatDateUtils.getIntegerFromDate((Date)
							// manifiesto.getFechaEfectivaDeLlegada());
							if (valModalidadService.correspondeModalidadAnticipada(fechaReferencia, manifiesto.getFechaEfectivaDeLlegada())) {
								// if (SunatNumberUtils.isGreaterThanParam(iFecLlegadaReal, iFechaReferencia)) {

								// if (SunatNumberUtils.isGreaterOrEqualsThanParam(iFechaMas15dias, iFecLlegadaReal)) {
								return getDUAError("30268", "");
								// return error30268;
								// }
							}
						}
					}
				} else {
					if (iFechaReferencia < iFecTermino) {
						return getDUAError("30026", "");
					}
				}
			}
			if (MODALIDAD_URGENTE.equals(codModalidad)) {
				if ((codTransaccion.endsWith("03") || isTxDilig)) {
					if(manifiesto==null || numManifDUA<1){// si se acoge por primera vez al manifiesto es anticipado. AJUSTES AREY
						if (SunatDateUtils.esFecha1MenorQueFecha2(fectermino, fechaNumeracionDeclaracion, SunatDateUtils.COMPARA_SOLO_FECHA) && manifiesto == null) {
							return getDUAError("35005","Despacho Urgente numerado despu�s de la fecha de llegada debe consignar n�mero de manifiesto de carga");
						}

						// gg lga revisar //PAS20165E220200127
						if (!valModalidadService.correspondeModalidadUrgente(fechaNumeracionDeclaracion, fectermino, null)) {
							// if(SunatDateUtils.esFecha1MenorQueFecha2(SunatDateUtils.addDay(fechaNumeracionDeclaracion, 15), fectermino, SunatDateUtils.COMPARA_SOLO_FECHA)){
							return getDUAError("35007","Declaraci�n se encuentra fuera del plazo establecido para la modalidad de Despacho Urgente");
						}
					} else {
						Date fechaTerminoDescargaManifiesto = (Date) manifiesto.getFechaTerminoDeDescarga();
						if (fechaTerminoDescargaManifiesto != null && !SunatDateUtils.isDefaultDate(fechaTerminoDescargaManifiesto)) {
							if (!SunatDateUtils.sonIguales(fechaTerminoDescargaManifiesto, fectermino, SunatDateUtils.COMPARA_SOLO_FECHA)) {
								String fechaDescargaManifiestoActual = SunatDateUtils.getFormatDate(fechaTerminoDescargaManifiesto, "dd/MM/yyyy");
								String fechaDescargaDUA = SunatDateUtils.getFormatDate(fectermino, "dd/MM/yyyy");
								return getDUAError("35006",new String[] { fechaDescargaDUA, fechaDescargaManifiestoActual });
							}
						} else {
							// PAS20145E220000195 - 20140707 - P06 Correcci�n Fecha Llegada
							if (!isTxDiligDespacho && !codTransaccion.endsWith("03")) {// se incorpora filtro para trx03 debido a que se repite en validarManifiestoCarga bug 18794
								if (fechaLlegadaManifiesto != null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaLlegadaManifiesto, fechaNumeracionDeclaracion, SunatDateUtils.COMPARA_SOLO_FECHA)) {
									if (!SunatDateUtils.sonIguales(fectermino, fechaLlegadaManifiesto, SunatDateUtils.COMPARA_SOLO_FECHA)) {

										String fechaLlegadaManifiestoActual = SunatDateUtils.getFormatDate(fechaLlegadaManifiesto, "dd/MM/yyyy");
										String fechaLlegadaDUA = SunatDateUtils.getFormatDate(fectermino, "dd/MM/yyyy");
										return getDUAError("35002", new String[] { fechaLlegadaDUA, fechaLlegadaManifiestoActual });

										// return getDUAError("35002","Fecha de llegada consignada en la declaraci�n no corresponde a la consignada en el manifiesto de carga");
									}
								}
							}
						}
					}
				} else {
					// Integer iFechaMas15dias=SunatDateUtils.getIntegerFromDate(SunatDateUtils.addDay(fechaReferencia, 15));
					// if(mapManifiesto == null) { //SAU20153K004000335
					if (manifiesto == null) {
						if (SunatNumberUtils.isLessThanParam(iFecTermino, iFechaReferencia)) {
							return getDUAError("35005", "Despacho Urgente numerado despu�s de la fecha de llegada debe consignar n�mero de manifiesto de carga");
						}

					}
					// if(!valModalidadService.correspondeModalidadUrgente(fechaReferencia,
					// fectermino, manifiesto.getFechaTerminoDeDescarga())){
					// if(SunatNumberUtils.isGreaterThanParam(iFecTermino, iFechaMas15dias)) {
					if (!valModalidadService.correspondeModalidadUrgente(fechaReferencia,
							fectermino, manifiesto != null ? manifiesto.getFechaTerminoDeDescarga() : SunatDateUtils.getDefaultDate())) { // PAS20165E220200080
						return getDUAError("35007", "Declaraci�n se encuentra fuera del plazo establecido para la modalidad de Despacho Urgente");
					}

				}
			}
			return new HashMap<String, String>();
		} else {
			return getDUAError("30026", "");
		}
	}

	/**
	 * Valida el numero de viaje.<br>
	 * Valida que el par&aacute;metro sea alfanum&eacute;rico.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numviaje String. Numero de viaje.
	 * @return Map
	 */
	@ServicioAnnot(tipo="V",codServicio=2081)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"numviaje"})
	@OrquestaDespaAnnot(codServInstancia=2081,numSecEjec=81,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> numviaje(String numviaje, Declaracion declaracion){
		if(!SunatStringUtils.isEmptyTrim(numviaje)){
			//return SunatStringUtils.isAlphanumeric(numviaje)?new HashMap<String,String>():getDUAError("30027","");
			String patronNumviaje ="([0-9a-zA-Z&/\\-]{1,17})?";
			if(!SunatStringUtils.parseFormat(patronNumviaje, numviaje)){
				return getDUAError("30027","");
			}
			/**
			 * Se debe verificar que el numero de viaje coincida con el del manifiesto, de existir
			 */
			//Map<Object,Object> mapManifiesto= NumeracionServiceImpl.getInstance().getFuncionesService().getManifiestoMap(declaracion);
			Map<Object,Object> mapManifiesto= ((ProveedorFuncionesService)fabricaDeServicios.getService("funcionesService")).getManifiestoMap(declaracion);
			if (mapManifiesto!= null){
				String numViajeManif = mapManifiesto.get("numeroDeViaje").toString();
				if (!numViajeManif.equals(numviaje)){
					return getDUAError("30541",new String[] {numviaje,numViajeManif});   		    		
				}
			} 
		}
		return new HashMap<String,String>();
	}
	
	/**
	 * Valida la fecha de inicio de embarque.<br>
	 * Valida que el par&aacute;metro siempre tenga valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param feciniembarque Date. Fecha de inicio de embarque.
	 * @return Map
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2082)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "feciniembarque" })
	@OrquestaDespaAnnot(codServInstancia = 2082, numSecEjec = 82, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public Map<String, String> feciniembarque(Date feciniembarque) {
		return feciniembarque != null ? new HashMap<String, String>() : getDUAError("30028", "");
	}

	public List<Map<String, ?>> validarTransportistaoRepresentanteEER(String tipoParticipante,
			String numeroDocumentoParticipante, 
			String viaTransporte) {
		OperadorValidaService operadorValidaService = fabricaDeServicios.getService("Ayuda.operadorValidaService");
		List<Map<String, ?>> listError = new ArrayList<Map<String, ?>>();

		if (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(viaTransporte) && 
			ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA.equals(tipoParticipante)) {
			List<Map<String, String>> listaErrores = operadorValidaService.validarOperador(numeroDocumentoParticipante, tipoParticipante);
			if (!listaErrores.isEmpty()) {
				listError.add(listaErrores.get(0));
			}
		}

		return listError;
	}

	/**
	 * Valida los datos de la Emp transporte.<br>
	 * 
	 * @param empTransporte Participante. Emp transporte
	 * @param codTransaccion String. Codigo de Transaccion.
	 * @param variablesIngreso Map<String,Object>
	 * @return el list
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2091)
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "empTransporte" })
	@OrquestaDespaAnnot(codServInstancia = 2091, numSecEjec = 91, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	public List<Map<String, String>> empTransporte(Participante empTransporte, String codTransaccion, Map<String, Object> variablesIngreso) {
		ValParticipante valParticipante = (ValParticipante) fabricaDeServicios.getService("ValParticipante");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		List<Map<String, String>> resuVal11 = new ArrayList<Map<String, String>>();
		Declaracion decla = (Declaracion) variablesIngreso.get("declaracion");
		String codAduana = decla.getDua().getCodaduanaorden();

		String viaTransporte=(String)variablesIngreso.get("viaTransp");
		String codModalidad=(String)variablesIngreso.get("codModalidad");
		String codTipoOper=null;
		String codErrorOper=null;
		//Pase PAS20191U220200002
		//List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		//listError=ValidadorPuntoLlegadaMercanciaModalidadExcepcional.ValidarEquipajeInternacionalPrecedencia(decla);
		//listError.removeIf(p -> p.isEmpty());
		boolean tienePrecedencia = false;

		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaHoy = SunatDateUtils.getCurrentDate();
		boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;

		String codigoPuntoLLegadaMercancia =decla.getDua().getCodlugarecepcion()!=null?decla.getDua().getCodlugarecepcion().toString():"";
		if (SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL)) {
			List<DatoSerie> listSeries = decla.getDua().getListSeries();
			for (DatoSerie datoSerieActual : listSeries) {
				if(esVigenteRIN31){
				tienePrecedencia = tienePrecedenciaParam(datoSerieActual, new String[]{pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.ACTA_RETENCION, pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.ACTA_INCAUTACION, pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.COMPROBANTE_CUSTODIA, pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.REG_DUTY_FREE, pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.REG_DMUA});
				}
				if (!tienePrecedencia) {

					if (empTransporte != null && empTransporte.getNumeroDocumentoIdentidad() != null) { //PAS20181U220200049
						//                  ValParticipante val=new ValParticipante();
						listError.add(valParticipante.numeroDocumentoIdentidad(empTransporte.getNumeroDocumentoIdentidad(), "30234", empTransporte.getTipoDocumentoIdentidad()));

						if (ConstantesDataCatalogo.VIA_TRANSPORTE_MARITIMA.equals(viaTransporte)) {
							codTipoOper = ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA;
						} else if (ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(viaTransporte)) {
							codTipoOper = ConstantesDataCatalogo.TIPO_OPERADOR_TRANSPORTISTA;
						} else {
							codTipoOper = ConstantesDataCatalogo.TIPO_OPERADOR_REPRESENTANTE_TRANSPORTISTA;
						}

			if (!viaTransporte.equals("7") && empTransporte.getNumeroDocumentoIdentidad()!=null){
				// PAS20124E600000024 LSG 20120206 Se v�lida para via postal con los tipo de operador 11 � 12
				if (ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL.equals(viaTransporte) && MODALIDAD_EXCEPCIONAL.equals(codModalidad)){
					for(int cont = 11; cont < 13; cont ++){  
						codTipoOper=String.valueOf(cont);
						//List<Map<String, String>> resultOpe= FormatoAServiceImpl.getInstance().getOperadorValidaService().validarOperador(empTransporte.getNumeroDocumentoIdentidad()
						List<Map<String, String>> resultOpe= ((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(empTransporte.getNumeroDocumentoIdentidad()
								, codTipoOper, codAduana, SunatDateUtils.getCurrentDate());
						if (resultOpe.size() > 0){
							for (Map<String, String> map : resultOpe) {
								codErrorOper = map.get("codError");
								// PAS20124E600000024 Normativo indico que para la via postal no se debe validar que el RUC de la empresa que se 
								// consigna como transportista en la DUA tenga jurisdicci�n para operar en la aduana que se esta numerando la DUA.
								// Por lo tanto no se considera el error 20020
								if (codErrorOper.equals("20020"))
									break;
								if ( cont == 12 ) {
									listError.addAll(resultOpe);
									listError.addAll(resuVal11);
								} else {
									resuVal11 = resultOpe;
								}
							}
							if (codErrorOper.equals("20020"))
								break;
						} else
							break;
					}
				} else {
					/*
					 * //List<Map<String, String>> resultOpe=
					 * FormatoAServiceImpl.getInstance().getOperadorValidaService().validarOperador(
					 * empTransporte.getNumeroDocumentoIdentidad() List<Map<String, String>>
					 * resultOpe= ((OperadorValidaService)fabricaDeServicios.getService(
					 * "Ayuda.operadorValidaService")).validarOperador(empTransporte.
					 * getNumeroDocumentoIdentidad() , codTipoOper, codAduana,
					 * SunatDateUtils.getCurrentDate()); if (!CollectionUtils.isEmpty(resultOpe) ||
					 * !empTransporte.getTipoDocumentoIdentidad().getCodDatacat().equals(
					 * ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC)){
					 *
					 * String numeroRUCempresaTrans = empTransporte.getNumeroDocumentoIdentidad();
					 * SoporteService soporteService =
					 * fabricaDeServicios.getService("soporteServiceDef"); Map<String, Object>
					 * rptaRuc = soporteService.obtenerPerNatJur("4",numeroRUCempresaTrans); String
					 * estadoRUC = (String) rptaRuc.get("estadoRUC");
					 * if(!codTransaccion.endsWith("03") && "00".equals(estadoRUC)){
					 * listError.add(getDUAError(
					 * "30557","TRANSPORTISTA NO REGISTRADO COMO OPERADOR AUTORIZADO. SE CONSIDERA COMO MERCANCIAS ARRIBADAS POR SUS PROPIOS MEDIOS"
					 * )); } } //listError.addAll(resultOpe);
					 */
					// Lo anterior se pasa a un m�todo y se usa el control de vigencia de estas validaciones
					Date fechaNumeracion = SunatStringUtils.isEqualTo(codTransaccion, ConstantesDataCatalogo.TRANSACCION_NUMERACION) ? new Date() : decla.getDua().getFecNumeracion();
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					Map<String, Object> mapVigenciaAjustesEmpTransporte = catalogoAyudaService.getElementoCat("380","0045", fechaNumeracion);
					String numeroRUCempresaTrans = empTransporte.getNumeroDocumentoIdentidad();
					if (CollectionUtils.isEmpty(mapVigenciaAjustesEmpTransporte)) {
						listError.addAll(validarRucTransportista(empTransporte, codTransaccion, codTipoOper, codAduana,numeroRUCempresaTrans));
					}
				   /*
						 * else{ // consideraci�n para manifiesto a�reo R1776 evaluaci�n si tiene o no
						 * c�digo de operador se ve en el servicio valManifiestoAereoParaDam
						 * if(!ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA.equals(viaTransporte)){
						 * listError.addAll(validarRucTransportista (empTransporte, codTransaccion,
						 * codTipoOper, codAduana, numeroRUCempresaTrans)); } }
						 */
				}
				if (empTransporte.getNumeroDocumentoIdentidad() == null) {
					listError.add(getDUAError("30332", "No existe en opecomext"));
				} else {
					// PAS20112A600000721 Se permite insertar numero de documento de empresa de
					// transporte sin el tipo de documento
					if (empTransporte.getTipoDocumentoIdentidad().getCodDatacat() == null) {
						listError.add(getDUAError("30235", "No existe en opecomext"));
					} else {
						listError.add(valParticipante.tipoDocumentoIdentidad(empTransporte.getTipoDocumentoIdentidad(),"30235"));
					}
				}
			}
		}
				}
			}
		}
		return listError;
	}

	/**
	 * PAS20181U220200049
	 * Los documentos de transporte consignados en la declaraci�n que correspondan a una gu�a EER,  
	 * deben estar registrados en el manifiesto de carga, v�a de transporte a�reo, con la categor�a 4, 
	 * caso contrario se devuelve error. - PAS20181U220200049 -   
	 * @param declaracion Declaracion
	 * @return el list
	 */
	  @ServicioAnnot(tipo="V",codServicio=2546)
	  @ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	  @OrquestaDespaAnnot(codServInstancia=2546,numSecEjec=92,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")	
	  public Map<String,String> validarManifiestoEERParaDam(Declaracion declaracion){	
		//Cargamos los datos del manifiesto de la dua en la variable manif
		DUA dua = declaracion.getDua();
		DatoManifiesto manif=dua.getManifiesto();		    
		String codaduamanif = manif.getCodaduamanif();
		String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
		String nummanif = manif.getNummanif();
		String codmodtransp = manif.getCodmodtransp();
		String codtipmanif = manif.getCodtipomanif();
		// Tipo-via-aduana-a�o-numero
		if (ConstantesDataCatalogo.VIA_TRANSPORTE_EER_UNECE.equals(codmodtransp)) {
			Map<String, Object> dataManif = new HashMap<String, Object>();
			dataManif.put("anioManifiesto", annmanif);
			dataManif.put("codigoAduana", codaduamanif);
			dataManif.put("codigoTipoManifiesto", codtipmanif);
			dataManif.put("codigoViaTransporte", codmodtransp);
			boolean buscarManifiestoSigadActual = true;//cambio pase 64
			Date fechaDeclaracion = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():new Date();//cambio pase 64
			boolean considerarEER = dua.getCodlugarecepcion()!=null && dua.getCodlugarecepcion().equals(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR)?true:false;
			//buscar el manifiesto considerando la conversion de catalogo 10 - 227 : (datacatasoc441)
			Manifiesto manifiesto = ((ManifiestoService) fabricaDeServicios.getService("manifiesto.manifiestoService"))
					.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif,
							SunatNumberUtils.toInteger(annmanif), nummanif, buscarManifiestoSigadActual,fechaDeclaracion, considerarEER);//cambio pase 64
			 
				String manifiestoMensaje = codtipmanif.concat("-").concat(codmodtransp).concat("-").concat(codaduamanif)
						.concat("-").concat(this.lpad(nummanif != null ? nummanif : "", 6, " "));
		
			if (manifiesto != null) {
			
				if(manifiesto.isEsSigad()) {
					//logica para SIGAD:
					String codigoViaTransporte = manifiesto.getViaTransporte().getCodDatacat();
//					if(ConstantesDataCatalogo.VIA_TRANSPORTE_EER.equals(codigoViaTransporte)){
//					Integer anioManifiesto = manifiesto.getAnioManifiesto();
//					String numeroManifiesto = manifiesto.getNumeroManifiesto();
//					String codigoAduana = manifiesto.getAduana().getCodDatacat();
//					 
//					int contador = 0;
//					boolean tieneTarja = false;
//					String mcdetabase = ""; 
//					ManifiestoSigadService manifiestoSigadService = fabricaDeServicios.getService("manifiesto.manifiestoSigadService");
//					List<Mcdeta> listMcdeta = new ArrayList<Mcdeta>();
//					Elementos<DatoDocTransporte> docsTransp  = declaracion.getDua().getListDocTransporte();
//					if(docsTransp!=null) {
//						
//						
//						for(DatoDocTransporte docTransp: docsTransp ) {
//							boolean tieneCat4D1 = false;
//							String puertoEmbarque = docTransp.getCodpuerto();
//							listMcdeta =  manifiestoSigadService.getListMcdetaByClaveDeNegocio(
//									codigoViaTransporte, codigoAduana, anioManifiesto, numeroManifiesto, docTransp.getNumdoctransporte(), puertoEmbarque,"A");
//							
//							if (listMcdeta!=null && listMcdeta.size() > 0) {
//								for( Mcdeta mcdeta :listMcdeta) {
//									if(ConstantesDataCatalogo.CATEGORIA_EER_4D1_DOCTRANS.equals(mcdeta.getDocumentoDeTransporte().getCodCategoria().getCodDatacat())) {
//										tieneCat4D1 = true;
//									} 
//								}
//							}
//							if(!tieneCat4D1) {
//								return getDUAError("70378",
//										new String[] { docTransp.getNumdoctransporte(), manifiestoMensaje });
//								//EL DOCUMENTO DE TRANSPORTE {0} DEL MANIFIESTO {1} NO TIENE REGISTRADO LA CATEGORIA 4D1
//							}
//						}
//						
//					}
//					  
//				}
					
				}else {
					 
					//logica para SDA:
					DocuTransDAO docuTransDAO = fabricaDeServicios.getService("manifiesto.gralDocTranporteDAO");
					Map<String, Object> parameterMap = new HashMap<String, Object>();
					parameterMap.put("viaTransporte", codmodtransp);
					parameterMap.put("aduana", codaduamanif);
					parameterMap.put("anioManifiesto", annmanif);
					parameterMap.put("numeroManifiesto", this.lpad(nummanif, 6, " "));
					List<DocumentoDeTransporte> docsTransporte = docuTransDAO.getByManifDocu(parameterMap);
					// si no localiza el codcategoria, hacer consulta al docutrans con los datos del
					// manifiesto para traer dicho dato.
					for (DatoDocTransporte docTranspXML : declaracion.getDua().getListDocTransporte()) {
						for (DocumentoDeTransporte docTransp : docsTransporte) {
							// se verifica que exista en el docutrans y que el participante sea del tipo 50 -EER
							if (docTranspXML.getNumdoctransporte().equalsIgnoreCase(docTransp.getNumeroDocumentoTransporte()) && ConstantesDataCatalogo.COD_OPERADOR_ESER.equalsIgnoreCase(docTransp.getEmpresaDeTransporte().getTipoParticipante().getCodDatacat())) {
								if (!ConstantesDataCatalogo.CODIGO_CATEGORIA_EER_04.equals(docTransp.getCodCategoria().getCodDatacat())) {
									return getDUAError("70148",new String[] { docTransp.getNumeroDocumentoTransporte(), manifiestoMensaje });
								}
							}
						}
					}
				}//fin else
			}
		}
		return new HashMap<String, String>();
	}

	/**
	 * PAS20181U220200049
	 * Si la v�a de transporte del manifiesto es a�reo (c�digo 4) adicionalmente verificar� lo siguiente:
	 * Si la declaraci�n est� asociada a un manifiesto con transportista que no tiene asignado c�digo de operador 
	 * Select al participante_doc del numcorredoc del manifiesto, verificar con el ruc del participante el tipo de participante y el tipo de operador de la via aerea.
	 * @param empTransporte Participante. Emp transporte
	 * @param codTransaccion String. Codigo de Transaccion.
	 * @param variablesIngreso Map<String,Object>
	 * @return el list
	 */
	@ServicioAnnot(tipo="V",codServicio=2547)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2547,numSecEjec=93,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto")
	  public List<Map<String,String>> validarManifiestoAereoParaDam(Participante empTransporte, Declaracion declaracion, String codTransaccion){	
		//Cargamos los datos del manifiesto de la dua en la variable manif
		DUA dua = declaracion.getDua();
		DatoManifiesto manif=dua.getManifiesto();		    
		String codaduamanif = manif.getCodaduamanif();
		String annmanif = SunatStringUtils.length(manif.getAnnmanif()) > 3 ? manif.getAnnmanif().substring(0, 4) : null;
		String nummanif = manif.getNummanif();
		String codmodtransp = manif.getCodmodtransp();
		String codtipmanif = manif.getCodtipomanif();
		
		List<Map<String,String>> listError = new ArrayList<Map<String,String>>();

		if(codmodtransp.equals(ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA)){
			Manifiesto listManifiesto = null;
			ManifiestoService manifiestoService = fabricaDeServicios.getService("manifiesto.manifiestoService");
			listManifiesto =  manifiestoService.findManifiestoByClaveDeNegocio(codtipmanif, codmodtransp, codaduamanif, SunatNumberUtils.toInteger(annmanif), nummanif,true);
			if(listManifiesto!=null) {
				HashMap mapParti = new HashMap();
				String num_corredoc_manif = listManifiesto.getNumeroCorrelativo().toString();
				mapParti.put("NUM_CORREDOC", num_corredoc_manif);
				ParticipanteDocDAO participanteDocDAO = fabricaDeServicios.getService("despaduanero2.participanteDocDAO");
				List listParticipanteDoc = participanteDocDAO.findByNumCorredoc(mapParti);
				boolean validarRuc = false;
				String tipoParticipante = " ";
				if (listParticipanteDoc!=null  && listParticipanteDoc.size()>0) {
					Participante participante;
					for (int i = 0; i<listParticipanteDoc.size(); i++) {
						participante = (Participante)listParticipanteDoc.get(i);
						if(participante.getTipoParticipante().getCodDatacat().equals("11") || participante.getTipoParticipante().getCodDatacat().equals("13")
								|| participante.getTipoParticipante().getCodDatacat().equals("14")) { //refactorizar el IF
							validarRuc = true;
							tipoParticipante = participante.getTipoParticipante().getCodDatacat();
							break;
						}
					}
				}
				if(validarRuc) {
					String numeroRUCempresaTrans = empTransporte.getNumeroDocumentoIdentidad();
					listError.addAll(validarRucTransportista(empTransporte, codTransaccion, tipoParticipante, codaduamanif, numeroRUCempresaTrans));					
				}
				
			}
		}		
		return listError;
	}	

	//PAS20181U220200049
	public List<Map<String,String>> validarRucTransportista (Participante empTransporte, String codTransaccion, String codTipoOper, String  codAduana, String numeroRUCempresaTrans){
		List<Map<String,String>> listError = new ArrayList<Map<String,String>>();
		List<Map<String, String>> resultOpe= ((OperadorValidaService)fabricaDeServicios.getService("Ayuda.operadorValidaService")).validarOperador(empTransporte.getNumeroDocumentoIdentidad(), codTipoOper, codAduana, SunatDateUtils.getCurrentDate());
		//if (!CollectionUtils.isEmpty(resultOpe) ||!empTransporte.getTipoDocumentoIdentidad().getCodDatacat().equals(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC)){
		if (!CollectionUtils.isEmpty(resultOpe) ||!ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(empTransporte.getTipoDocumentoIdentidad().getCodDatacat())){
			SoporteService soporteService = fabricaDeServicios.getService("soporteServiceDef");
			String estadoRUC = "00";
			if (numeroRUCempresaTrans != null) {
				Map<String, Object> rptaRuc = soporteService.obtenerPerNatJur("4", numeroRUCempresaTrans);
				estadoRUC = (String) rptaRuc.get("estadoRUC");
			}
			if (!codTransaccion.endsWith("03") && "00".equals(estadoRUC)) {
				listError.add(getDUAError("30557","TRANSPORTISTA NO REGISTRADO COMO OPERADOR AUTORIZADO. SE CONSIDERA COMO MERCANCIAS ARRIBADAS POR SUS PROPIOS MEDIOS"));
			}
		}
		return listError;
	}


        private boolean tienePrecedenciaParam(DatoSerie datoSerieActual, String[] catprecedencia){
		boolean tienePrecedencia=false;
		if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
			for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
				if(SunatStringUtils.include(datoRegPreActual.getCodregipre(), catprecedencia)){
					tienePrecedencia=true;
					break;
				}
			}
		}
		return tienePrecedencia;
	}
	/**
	 * Valida el C�digo de puerto/aeropuerto embarque.
	 * 
	 * @param codpuerto String. C�digo de puerto/aeropuerto embarque.
	 * @return el mapa de errores
	 */
	public Map<String, String> codpuerto(String codpuerto) {
		return new HashMap<String, String>();
	}

	// PAS20181U220200049
	private String lpad(String s, Integer n, String c) {
		String result = "";
		if (s.length() >= n) {
			return s;
		} else {
			for (int i = 0; i < (n - s.length()); i++) {
				result += c;
			}
			result += s;
			return result;
		}
	}

}
