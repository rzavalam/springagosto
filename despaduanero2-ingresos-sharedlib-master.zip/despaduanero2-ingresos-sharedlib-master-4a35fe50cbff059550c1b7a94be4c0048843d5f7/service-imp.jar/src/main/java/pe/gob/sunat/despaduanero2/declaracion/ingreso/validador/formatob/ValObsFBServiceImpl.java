package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoObserv;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ObservacionDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public class ValObsFBServiceImpl extends ValDuaAbstract implements ValObsFB{

	//private FabricaDeServicios fabricaDeServicios;

	/** Validar Que la secuencia de la observacion no se repita a nivel del Item */
	
	/*public Map<String, String> numsecuencia(DatoItem item) {
		java.util.Map<String, String> result = new HashMap<String, String>();
		
		List<String> secuencias = new ArrayList<String>();
		for (Observacion observ : item.getListObservaciones()) {
			
			if(secuencias.contains( observ.getNumsecuencia() ))
			{
				result = catalogoHelper.getErrorMap("");
			}else{
				secuencias.add( observ.getNumsecuencia() );
			}
			
			if (!SunatStringUtils.isNumeric(observ.getNumsecuencia())){
				result = catalogoHelper.getErrorMap("30084");	
			}
		}
		return result;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

	/**
	 * Se valida que la secuencia de la observacion sea de 1..n para todos los items del formato B 
	 * Se cambia parametro de servicio en la tabla servinstdet y orquestadespa
	 * y adicionalmente se incorpora la regla de validaci�n a la rectificaci�n
	 * @author rbegazo
	 */
	public Map<String, String> numsecuencia(Declaracion declaracion) {
		Map<String, String> result = new HashMap<String, String>();
		
		if(declaracion.isExoneradoFB()){
		    return result;
		}
		
		List<Integer> repetidos = new ArrayList<Integer>();
		Integer secuencia = 1;
		
		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura davfactura : dav.getListFacturas()){
				for (DatoItem davitem : davfactura.getListItems()){
					for (Observacion observ : davitem.getListObservaciones()){
						int numsecuencia = SunatNumberUtils.toInteger(observ.getNumsecuencia());
						if (!SunatNumberUtils.isGreaterThanZero(numsecuencia) || 
							repetidos.contains( numsecuencia)  ||
							!SunatNumberUtils.isEqual(numsecuencia, secuencia)) {
							result = getErrorMap("30084", new Object[]{
									davitem.getNumsecitem(),									
									observ.getNumsecuencia()}); 
						}
						secuencia++;
						repetidos.add(numsecuencia);
					}
				}
			}
		}
		return result;
	}
	
	public List<Map<String, String>>  numsecuencia(Declaracion declaracion, String codTransaccion) {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		
		if(declaracion.isExoneradoFB()){
		    return result;
		}
		
		if(!codTransaccion.equals("1001")){			
			List<Observacion> lstObservacionNuevos = new ArrayList<Observacion>();
			Integer numsecuenciaaux = 0;
			Integer numsecuenciaMax = 0;	
			Observacion observacionBD = new Observacion();
			ObservacionDAO observacionDao = (ObservacionDAO)fabricaDeServicios.getService("observacionDAO");
				for (DAV dav : declaracion.getListDAVs()) {
					for (DatoFactura davfactura : dav.getListFacturas()){
						for (DatoItem davitem : davfactura.getListItems()){
							for (Observacion observ : davitem.getListObservaciones()){
								int numsecuencia = SunatNumberUtils.toInteger(observ.getNumsecuencia());
								    observ.setNumsecitem(davitem.getNumsecitem()); // es null por eso se setea el numero de serie que corresponde la observacion
								if (SunatNumberUtils.isGreaterThanZero(numsecuencia) ) {
								
									Map<String,Object> params = new HashMap<String, Object>();
									params.put("numcorredoc",declaracion.getNumeroCorrelativo());
									params.put("numsecuencia", observ.getNumsecuencia());
									params.put("codtipobs", observ.getCodtipobserva());
									
									List<Observacion> lstObservacion= (List<Observacion>)observacionDao.findObservcionByMap(params);
									if(lstObservacion!=null && !lstObservacion.isEmpty()){//BUSCAR SI LA OBSERVACION EXISTE POR NUMERO DE SECUENCIA 
										for(int j=0;j<lstObservacion.size();j++){
										observacionBD =lstObservacion.get(j);
										if(observacionBD !=null && !observacionBD.getNumsecitem().equals(observ.getNumsecitem())){
											numsecuenciaaux++;
											params.put("NUM_CORREDOC",declaracion.getNumeroCorrelativo());
											params.put("COD_TIPOBS", observ.getCodtipobserva());
											numsecuenciaMax =observacionDao.getMaxNumSecObs(params);
											Integer numsecuenciaNuevo =numsecuenciaMax+numsecuenciaaux;
											lstObservacionNuevos.add(observ);
											result.add(getErrorMap("37000", new Object[]{
													davitem.getNumsecitem(),									
													observ.getNumsecuencia(),observ.getNumsecitem(),numsecuenciaNuevo})); 
											
										}
										}
										
									}else{// BUSCA SI EXISTE OBSERVACION PARA LA SERIE (NUMERO DE ITEM) EN BASE DE DATOS
										Map<String,Object> params2 = new HashMap<String, Object>();
										params2.put("numcorredoc",declaracion.getNumeroCorrelativo());
										params2.put("numsecitem", observ.getNumsecitem());
										params2.put("codtipobs", observ.getCodtipobserva());
									    List<Observacion> lstObservacion2= (List<Observacion>)observacionDao.findObservcionByMap(params2);
										if(lstObservacion2!=null && !lstObservacion2.isEmpty()){
										  for(int j=0;j<lstObservacion2.size();j++){
											observacionBD =lstObservacion2.get(j);
											if(observacionBD !=null && !observacionBD.getNumsecuencia().equals(observ.getNumsecuencia())){
												result.add(getErrorMap("37002", new Object[]{
														davitem.getNumsecitem(),									
														observ.getNumsecuencia(),observacionBD.getNumsecitem(),observacionBD.getNumsecuencia()})); 
											}
										  }
											
										}else{
											lstObservacionNuevos.add(observ); // si agrega observaciones para series nuevas y numsecuencia no existe en bd
										}
										
									}
									
								}
								
							}
						}
					}
				}
				if(lstObservacionNuevos.size()>0){
					Integer numsecuenciaNuevo =0;
					Map<String,Object> params = new HashMap<String, Object>();
					for(int j=0;j<lstObservacionNuevos.size();j++){
						Observacion observ=lstObservacionNuevos.get(j);
						params.put("NUM_CORREDOC",declaracion.getNumeroCorrelativo());
						params.put("COD_TIPOBS", observ.getCodtipobserva());
						numsecuenciaMax =observacionDao.getMaxNumSecObs(params);
						 numsecuenciaNuevo = numsecuenciaMax+j+1;
						if(!numsecuenciaNuevo.toString().equals(observ.getNumsecuencia().toString())){
							result.add(getErrorMap("37001", new Object[]{
									observ.getNumsecitem(),									
									observ.getNumsecuencia(),numsecuenciaNuevo})); 
						}
					}				
				}
		}
		return result;
	}
	
	/**
	 * Validar en funcion del Catalogo, la clase debe heredar las funciones del
	 * Aparte de validar con el cat�logo, solo deber� de indicarse el tipo 03
	 * 
	 * Validar codigo del tipo de observacion del �tem, Validar opcionalmente que se haya transmitido 
	 * el c�digo de tipo de observaci�n del formato B
	 * @param listObservaciones
	 * @return map
	 * @pase PAS20134E610000270 FORMATO B 
	 */
	public List<Map<String, String>>  codtipobserva(Elementos<Observacion> listObservaciones) {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();

                if (CollectionUtils.isEmpty(listObservaciones)) {
                     return result;
                }

                if (((Declaracion) listObservaciones.get(0).getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
                     return result;
                }

		for(Observacion observ:listObservaciones){
			String codTipoObserva=observ.getCodtipobserva();
                        if (codTipoObserva == null) {
                              continue;
                        }  
			//if (!FormatoAServiceImpl.getInstance().isValidCatalogo("369", codTipoObserva))
			boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("369", codTipoObserva,SunatDateUtils.getCurrentDate()));
			if (!validaCatalogo || !codTipoObserva.equals("03")){
				result.add(getErrorMap(
                        "30085",
                        new Object[] { ((DAV) observ.getPadre().getPadre().getPadre()).getNumsecuprov(),
                                ((DatoFactura) observ.getPadre().getPadre()).getNumsecfactu(),
                                ((DatoItem) observ.getPadre()).getNumsecitem(), observ.getCodtipobserva() }));
            }
        }
			
        return result;
			}
		
    /**
     * Validar que se transmita un valor en la descripci�n de la observaci�n con longitud mayor a cero.
     * @param observacion
     * @return
     * @PASE PAS20134E610000270 FORMATO B 
     */
    //GGRANADOS FORMB
	public Map<String, String> obsdeclaracion(Elementos<Observacion> listObservaciones) {
		
		Map<String, String> result = new HashMap<String, String>();
		 
		if (CollectionUtils.isEmpty(listObservaciones)) {
	            return result;
		}		
		
		
        if (((Declaracion) listObservaciones.get(0).getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
		return result;
	}

        
        for (Observacion observ : listObservaciones) {
        	
            if (!SunatStringUtils.isEmpty(observ.getCodtipobserva())) {
        	            if(!SunatStringUtils.isLengthGreaterThanNumber(observ.getObsdeclaracion(), 0)){
			                result = getErrorMap("01150", 
			                        new Object[]{
			                        ((DatoItem) observ.getPadre()).getNumsecitem(),
			                        observ.getNumsecuencia(),  
			                        observ.getObsdeclaracion()});
			            }
	}

                
        }   
       
        return result; 
	}
	

}
