package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.util.Constantes;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FormatoBServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.FormatoBUtils;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoCondTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactSuce;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoProv;
//import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
//import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DocumentoSoporteFormatoB;
import pe.gob.sunat.despaduanero2.declaracion.model.NumdeclRef;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.Manifiesto;
import pe.gob.sunat.despaduanero2.model.Participante;
//import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_NUMERACION_IMPORTACION_DEFINITIVA;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_NUMERACION_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_NUMERACION_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI;

public class  ValCabdavServiceImpl   extends ValDuaAbstract implements  ValCabdav {

	//protected final Log log = LogFactory.getLog(getClass());

	//private ValItemFB  valItemFB;
	//private ValProveFB valProveFB;
	//private ValIntermediarioFB valIntermediarioFB;
	//private ValProveLocFB valProveLocFB;
	//private ValDeclaranteFB valDeclaranteFB;
	//private ValFactSuc valFactSuc;

	/*
	public void setValProveFB(ValProveFB valProveFB) {
		this.valProveFB = valProveFB;
	}

	public void setValItemFB(ValItemFB valItemFB) {
		this.valItemFB = valItemFB;
	}


	public void setValIntermediarioFB(ValIntermediarioFB valIntermediarioFB) {
		this.valIntermediarioFB = valIntermediarioFB;
	}


	public void setValProveLocFB(ValProveLocFB valProveLocFB) {
		this.valProveLocFB = valProveLocFB;
	}


	public void setValDeclaranteFB(ValDeclaranteFB valDeclaranteFB) {
		this.valDeclaranteFB = valDeclaranteFB;
	}
	 */
	/** Validar Que la secuencia de Proveedores no se repita y seha unica */
	@ServicioAnnot(tipo="V",codServicio=2234,descServicio="valida numsecuprov")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"this"})
	@OrquestaDespaAnnot(codServInstancia=2234,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.Declaracion")	
	public Map<String, String> numsecuprov(Declaracion declaracion){        

		if( log.isInfoEnabled() )
			log.info("numsecuprov");

		java.util.Map<String, String> result = new HashMap<String, String>();
		if(declaracion.isExoneradoFB()){
			return result;
		}

		int secuencia = 1;

		//amancilla inicio PAS20165E220200126
		if(!CollectionUtils.isEmpty(declaracion.getListDAVs())) {
			/** @pase PAS20134E610000270 FORMATO B*/
			for (DAV dav : declaracion.getListDAVs()) {
				if (dav.getNumsecuprov() == null || dav.getNumsecuprov() != secuencia) {
					//glazaror... evitamos el uso de catalogoHelper.getErrorMap
					/*result = catalogoHelper.getErrorMap("05504", new Object[] {
                		dav.getNumsecuprov()!=null?dav.getNumsecuprov():" "});*/

					//glazaror... hacemos uso de catalogoAyudaService.getError
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
					result = catalogoAyudaService.getError("05504", new String[] { numeroSecuenciaProveedor});//gmontoya Pase 153
				}
				secuencia++;
			}
		}
		//amancilla fin PAS20165E220200126
		return result;
	}

	/**
	 * Validar el codigo de proveedor en la tabla CAT_PROVEE, si el campo tiene
	 * valor y no existe en la tabla generar el mensaje de advertencia 9074, si
	 * no tiene valor generar el mensaje de advertencia 9509
	 * 
	 * Validar opcionalmente que se haya transmitido el c�digo del proveedor 99
	 * @return map*/
	/*PAR QUE PASE*/    

	@ServicioAnnot(tipo="V",codServicio=2235,descServicio="valida codproveedor")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codproveedor"})
	@OrquestaDespaAnnot(codServInstancia=2235,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DAV")
	//actualizado pase 270
	public List<Map<String, String>> codproveedor(DAV dav){
		OperadorAyudaService operadorAyudaService = (OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();

		if(((Declaracion)dav.getPadre()).isExoneradoFB()){
			return listError;
		}

		if (StringUtils.isNotEmpty(dav.getCodproveedor())) {
			Map<String, Object> proveedor = operadorAyudaService.getCatprovee(dav.getCodproveedor());
			if (CollectionUtils.isEmpty(proveedor)){
				listError.add(getErrorMap("09074", new Object[] { dav.getNumsecuprov(), dav.getCodproveedor() }));        		
			}
			else{
				if (!((String) proveedor.get("ccodi_prov")).trim().substring(0, 2).equals(dav.getProveedor().getPais().getCodDatacat())) {
					listError.add(getErrorMap("30600", new Object[] { dav.getNumsecuprov(),
							dav.getCodproveedor(),
							dav.getProveedor().getPais().getCodDatacat()}));
				}

				if (!((String) proveedor.get("cnomb_prov")).trim().equals(dav.getProveedor().getNombreRazonSocial())) {
					listError.add(getErrorMap("30601", new Object[] { dav.getNumsecuprov(),
							dav.getProveedor().getNombreRazonSocial(),
							((String) proveedor.get("cnomb_prov")).trim()}));
				}
				dav.setFlag("1");
				dav.getProveedor().setNumeroDocumentoIdentidad(dav.getCodproveedor());        		
			}	
		}else{

			//OperadorAyudaService operadorAyudaService = fabricaDeServicios.getService("Ayuda.operadorAyudaService");
			//            Map<String, Object> proveedor = catalogoHelper.getOperadorAyudaService().getCatprovee(
			//                    dav.getProveedor().getPais().getCodDatacat(),
			//                    dav.getProveedor().getNombreRazonSocial());
			Map<String, Object> proveedor = operadorAyudaService.getCatprovee(
					dav.getProveedor().getPais().getCodDatacat(),
					dav.getProveedor().getNombreRazonSocial());
			if(!CollectionUtils.isEmpty(proveedor)){
				dav.setFlag("2");
				dav.setCodproveedor(proveedor.get("ccodi_prov").toString());
				dav.getProveedor().setNumeroDocumentoIdentidad(proveedor.get("ccodi_prov").toString());
				listError.add(getErrorMap("30668", new Object[] { 
						dav.getNumsecuprov(),
						dav.getProveedor().getNombreRazonSocial(),
						((String) proveedor.get("ccodi_prov")).trim()}));
			}else{
				dav.setFlag("3");                
			}

		}

		return listError;
	}


	/**
	 * Validar el codigo del nivel comercial del proveedor contra el catalogo 85.
	 * @param dav
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=2236,descServicio="valida codnivcomer")
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codnivcomer"})
	@OrquestaDespaAnnot(codServInstancia=2236,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DAV")
	public Map<String, String> codnivcomer(DAV dav){
		Map<String, String> result = new HashMap<String, String>();
		if(((Declaracion)dav.getPadre()).isExoneradoFB()){
			return result;
		}

		/** @pase PAS20134E610000270 FORMATO B */
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("85", dav.getCodnivcomer()));
		//if (!catalogoHelper.isValid(dav.getCodnivcomer(), "85")) {
		if (!validaCatalogo) {
			result = getErrorMap("05507", new Object[] { dav.getNumsecuprov(), dav.getCodnivcomer()!=null?dav.getCodnivcomer():" "});
		}

		return result;
	}


	@ServicioAnnot(tipo = "V", codServicio = 3502, descServicio = "Valida el nivel comercial del importador, cuando se declare como otros")
	@Override
    public Map<String, String> codNivComerOtros(DAV dav){
        Map<String, String> result = new HashMap<String, String>();
        
        if(((Declaracion)dav.getPadre()).isExoneradoFB()){
            return result;
        }
        
        if (!SunatStringUtils.isEmptyTrim(dav.getCodnivcomer()) && dav.getCodnivcomer().equals("5") && 
        		SunatStringUtils.isEmptyTrim(dav.getDesNivComer())) {
        	result =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
        			"37099", new String[] {dav.getNumsecuprov().toString()});
        }

        return result;
    }

	/**
	 * Validar la Naturaleza de la transaccion contra el catalogo 81.
	 * @param dav
	 * @return
	 * @Error 05520
	 */
	@ServicioAnnot(tipo="V",codServicio=2237,descServicio="valida codnatutrans")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "codnatutrans" })
	@OrquestaDespaAnnot(codServInstancia=2237,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DAV")
	public Map<String, String> codnatutrans(DAV dav){
		//glazaror... invocamos al nuevo metodo para mantener la logica en un solo metodo
		return codnatutrans(dav, null);

	}

	//glazaror... metodo codnatutrans optimizado
	@ServicioAnnot(tipo="V",codServicio=2237,descServicio="valida codnatutrans")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "codnatutrans" })
	@OrquestaDespaAnnot(codServInstancia=9146,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DAV")
	public Map<String, String> codnatutrans(DAV dav, Map<String, Object> variablesIngreso){
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}

		/** @pase PAS20134E610000270 FORMATO B*/
		//glazaror... verificamos si es que podemos trabajar con variablesIngreso
		if (variablesIngreso == null) {
			//entonces trabajamos de la forma no optimizada
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("81",dav.getCodnatutrans()));
			//if (!catalogoHelper.isValid(dav.getCodnatutrans(), "81")) {
			if (!validaCatalogo) {
				result = getErrorMap("05520", new Object[] { dav.getNumsecuprov(), dav.getCodnatutrans()!=null?dav.getCodnatutrans():" "}); }
		} else {
			//glazaror... entonces trabajamos de la forma optimizada
			if (!IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, "81", dav.getCodnatutrans(), variablesIngreso)) {
				//entonces asignamos el error desde catalogoAyudaService.getError
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
				String codigoNatuTrans = (dav.getCodnatutrans() != null) ? dav.getCodnatutrans().toString() : " ";
				result = catalogoAyudaService.getError("05520", new String[] { numeroSecuenciaProveedor, codigoNatuTrans});
			}
		}

		return result;

	}


	@ServicioAnnot(tipo = "V", codServicio = 3504, descServicio = "Valida la naturaleza de la transacci�n, cuando se declare como otros")
	@Override
	public Map<String, String> codNatuTransOtros(DAV dav){
		Map<String, String> result = new HashMap<String, String>();
		
		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
        }
		
		if (!SunatStringUtils.isEmptyTrim(dav.getCodnatutrans()) && dav.getCodnatutrans().equals("28") && 
        		SunatStringUtils.isEmptyTrim(dav.getDesNatuTrans())) {
        	result =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
        			"37101", new String[] {dav.getNumsecuprov().toString()});
        }
		
		return result;
	}
	
    
   
	/**
	 * Validar el codigo de la forma de envio de la mercancia contra el catalogo 84
	 * @param dav
	 * @return
	 */
	@ServicioAnnot(tipo = "V", codServicio = 2238, descServicio = "valida codformenvio")
	@ServInstDetAnnot(tipoRpta = { 0 }, nomAtr = { "codformenvio" })
	@OrquestaDespaAnnot(codServInstancia = 2238, numSecEjec = 1, nomClase = "pe.gob.sunat.despaduanero2.declaracion.model.DAV")
	public Map<String, String> codformenvio(DAV dav) {
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("84",dav.getCodformenvio()));
		//if (!catalogoHelper.isValid(dav.getCodformenvio(), "84")) {
		if (!validaCatalogo) {
			result = getErrorMap("05521", 
					new Object[] { 
							dav.getNumsecuprov(), 
							dav.getCodformenvio()!=null?dav.getCodformenvio():" "});
		}
		return result;
	}

	/**
	 * Verificar que sea un dato numerico mayor a Cero, si codformenvio='2'
	 * numenvio tiene que ser > 1
	 * 
	 * @param dav
	 * @return
	 */
	public Map<String, String> numenvio(DAV dav){

		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}

		if ((dav.getNumenvio() == null) || (!SunatNumberUtils.isGreaterThanZero(dav.getNumenvio()))) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result = catalogoHelper.getErrorMap("05522", 
                    new Object[] { 
                    dav.getNumsecuprov(),
                    dav.getNumenvio()!=null?dav.getNumenvio():" "});*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String numeroEnvio = (dav.getNumenvio() != null) ? dav.getNumenvio().toString() : " ";
			result = catalogoAyudaService.getError("05522", new String[] {numeroSecuenciaProveedor, numeroEnvio});
		}

		if (dav.getCodformenvio().equals("2") && (SunatNumberUtils.isLessOrEqualsThanParam(dav.getNumenvio(), 1))) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result = catalogoHelper.getErrorMap("30603", 
                    new Object[] { 
                    dav.getNumsecuprov(), 
                    dav.getNumenvio() });*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String numeroEnvio = (dav.getNumenvio() != null) ? dav.getNumenvio().toString() : " ";
			result = catalogoAyudaService.getError("30603", new String[] {numeroSecuenciaProveedor, numeroEnvio});

		}
		return result;
	}

	/**
	 * Indicador de existencia de intermediarios, se declara en secci�n de
	 * partys. 1: Afirmativo 2 Negativo
	 * 
	 * @param dav
	 * @return
	 */
	public Map<String, String> indexisinter(DAV dav){

		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}

		if (StringUtils.isEmpty(dav.getIndexisinter()) || 
				!SunatStringUtils.isStringInList(dav.getIndexisinter(), "1,2")) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result = catalogoHelper.getErrorMap("05523", 
                    new Object[] { 
                    dav.getNumsecuprov(), 
                    dav.getIndexisinter()!=null?dav.getIndexisinter():" " });*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String indexisinter = (dav.getIndexisinter() != null) ? dav.getIndexisinter().toString() : " ";
			result = catalogoAyudaService.getError("30614", new String[] { numeroSecuenciaProveedor, indexisinter});
		}

		return result;
	}

	/**
	 * Verificar que sea un dato numerico mayor a cero y que el numero coincida
	 * con el total del facturas asociadas
	 * @param dav
	 * @return
	 */
	public Map<String, String> cntfacturas(DAV dav) {
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}

		if (!SunatNumberUtils.isGreaterThanZero(dav.getCntfacturas()) || dav.getListFacturas().size() != dav.getCntfacturas()) {
			result = getErrorMap("30111", new Object[] { dav.getNumsecuprov(), dav.getCntfacturas() });	
		}
		return result;		
	}


	/**
	 * Se valida obligatoriamente que se haya transmitido la condicion del proveedor y 
	 * este contenido en el catalogo 86.
	 * @param dav
	 * @return
	 */
	public Map<String, String> codcondprov(DAV dav) {							   
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("86",dav.getCodcondprov()));
		//if (StringUtils.isEmpty(dav.getCodcondprov()) || (!catalogoHelper.isValid(dav.getCodcondprov(), "86"))) {
		if (StringUtils.isEmpty(dav.getCodcondprov()) || !validaCatalogo) {
			result = getErrorMap("30112", new Object[] { 
					dav.getNumsecuprov(),  
					dav.getCodcondprov()!=null?dav.getCodcondprov():" "});
		}
		return result;
	}
	

	@ServicioAnnot(tipo = "V", codServicio = 3503, descServicio = "Valida la condici�n del proveedor, cuando se declare como otros")
	@Override
	public Map<String, String> codCondProvOtros(DAV dav) {							   
		Map<String, String> result = new HashMap<String, String>();
		
        if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
            return result;
        }
		
        if (!SunatStringUtils.isEmptyTrim(dav.getCodcondprov()) && dav.getCodcondprov().equals("4") && 
        		SunatStringUtils.isEmptyTrim(dav.getDesCondProv())) {
        	result =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
        			"37100", new String[] {dav.getNumsecuprov().toString()});
        }
        
		return result;
	}

	/**
	 *  Validar C�digo Tipo de Intermediario
	 * @param dav
	 * @return
	 * @pase PAS20134E610000270  FORMATO B 
	 */

	public Map<String, String> codtipinter(DAV dav) {

		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("87",dav.getCodtipinter()));
		//if (SunatStringUtils.isEmpty(dav.getCodtipinter()) || !catalogoHelper.isValid(dav.getCodtipinter(), "87")) {
		if (SunatStringUtils.isEmpty(dav.getCodtipinter()) || !validaCatalogo) {
			result = getErrorMap("05528", new Object[] { 
					dav.getNumsecuprov(),
					dav.getCodtipinter()!=null?dav.getCodtipinter():" "});


		}

		return result;
	}
	

	@ServicioAnnot(tipo = "V", codServicio = 3505, descServicio = "Valida el tipo de intermediario, cuando se declare como otros")
	@Override
	public Map<String, String> codTipInterOtros(DAV dav){
		Map<String, String> result = new HashMap<String, String>();
		
		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
        }
		
		if (!SunatStringUtils.isEmptyTrim(dav.getCodtipinter()) && dav.getCodtipinter().equals("5") && 
        		SunatStringUtils.isEmptyTrim(dav.getDesTipInter())) {
        	result =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
        			"37102", new String[] {dav.getNumsecuprov().toString()});
        }
		
		return result;
	}

	/** Verificar que se envie un texto de longitud mayor de 3 caracteres 
	 * se reemplaza por ValDeclaranteFB.validarCargoDeclarante*/
	@Deprecated
	public Map<String, String> nomcargdecla(String arg) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		java.util.Map<String, String> result = new HashMap<String, String>();

		if (!SunatStringUtils.isLengthGreaterThanNumber(arg, 3)) {
			result = catalogoAyudaService.getError("30113");
		}

		return result;
	}


	/**
	 * Validar que el ajuste Total US$ no difiera a la sumatoria del ajuste unitario multiplicado por la 
	 * cantidad de unidades en mas de 3 d�lares de cada uno de los items declarados*
	 * Validar que los ajustes en el formato A de la dua sean iguales a los montos de los
	 *  ajustes efectuados en el formato b con una diferencia no mayor de US$1.  
	 * @param  dav
	 * @return list map
	 * @pase PAS20134E610000270  FORMATO B*/		
	public List<Map<String, String>> validarDiferenciaAjustesFormatoBconA(Declaracion declaracion){

		List<Map<String, String>> result = new ArrayList<Map<String, String>>();

		BigDecimal tajustes = declaracion.getDua().getMtotajustes();

		if (declaracion.isExoneradoFB()) {
			return result;
		}

		BigDecimal totalAjustesFormatosB = BigDecimal.ZERO;

		for (DAV dav : declaracion.getListDAVs()) {
			BigDecimal totalAjustes = FormatoBUtils.obtenerAjusteTotalFormatoB(dav);
			totalAjustesFormatosB = SunatNumberUtils.sum(totalAjustesFormatosB, totalAjustes);
		}

		/* CALCULO DEL AJUSTE TOTAL FORMATO B */
		BigDecimal absDiffTotalFormatoB = SunatNumberUtils.absoluteDiference(totalAjustesFormatosB, tajustes);
		if (absDiffTotalFormatoB == null || (absDiffTotalFormatoB != null && absDiffTotalFormatoB.doubleValue() > 1D)) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result.add(catalogoHelper.getErrorMap("05652",
                    new Object[] { absDiffTotalFormatoB != null ? absDiffTotalFormatoB : " " }));*/

			//glazaror... hacemos uso de catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String absDiffTotalFormatoBAsString = (absDiffTotalFormatoB != null) ? absDiffTotalFormatoB.toString() : " ";
			result.add(catalogoAyudaService.getError("05652", new String[] {absDiffTotalFormatoBAsString}));

		}
		return result;

	}

	public Map<String, String> validarDiferenciaAjustesFormatoBconItems(DAV dav){
		Map<String, String> result = new HashMap<String, String>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}

		BigDecimal totalAjustes = FormatoBUtils.obtenerAjusteTotalFormatoB(dav);

		BigDecimal totalAjustesItems = BigDecimal.ZERO;
		for (DatoFactura factura : dav.getListFacturas()) {
			for (DatoItem item : factura.getListItems()) {
				BigDecimal mtoAjusteUnitItem = item.getMtoajusunita()!=null?item.getMtoajusunita():new BigDecimal(0);//mtoAjusteUnitItem es condicionado ajuste por SAU20153D211400039
				totalAjustesItems = totalAjustesItems.add(mtoAjusteUnitItem.multiply(item.getCntcantcomer()));//ajuste por SAU20153D211400039
			}
		}

		BigDecimal absDiff = SunatNumberUtils.absoluteDiference(totalAjustes, totalAjustesItems);

		if (absDiff != null && absDiff.doubleValue() > 3D) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*return catalogoHelper.getErrorMap("30628", new Object[] { dav.getNumsecuprov(), totalAjustes,
                    totalAjustesItems });*/
			//glazaror... hacemos uso de catalogoAyudaService.getError
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
			String totalAjustesAsString = (totalAjustes != null) ? totalAjustes.toString() : " ";
			String totalAjustesItemsAsString = (totalAjustesItems != null) ? totalAjustesItems.toString() : " ";
			return catalogoAyudaService.getError("30628", new String[] { numeroSecuenciaProveedor, totalAjustesAsString, totalAjustesItemsAsString});
		}

		return result;
	}

	public Map<String, String> validarIncotermUnicoXFactura(DAV dav){
		Map<String, String> result = new HashMap<String, String>();
		Elementos<DatoFactura> facturas = dav.getListFacturas();

		String codincoterm = facturas.size() > 0 ? facturas.get(0).getCodincoterm() : "";

		for (DatoFactura datoFactura : facturas) {
			if (!SunatStringUtils.isEqualTo(codincoterm, datoFactura.getCodincoterm())) {
				//glazaror... evitamos el uso de catalogoHelper.getErrorMap
				//return catalogoHelper.getErrorMap("05665", new Object[] { dav.getNumsecuprov() });
				//glazaror... hacemos uso de catalogoAyudaService.getError
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
				result = catalogoAyudaService.getError("05665", new String[] { numeroSecuenciaProveedor});
			}
		}
		return result;

	}

	/**
	 * gc_fech_ingsi=<fecha actual de proceso en formato AAAAMMDD> Exonerado =
	 * Falso Buscar en el segmento Datosdeclarante el codtipparticipante='02'
	 * para obtener los datos del declarante, luego select reso_simpl from
	 * res_spim where tipo_docum='"+
	 * Datosdeclarante.codtipdocparticipante+"' and nume_docum='"+
	 * ALLT(Datosdeclarante.numdocparticipante)+"' and "+gc_fech_ingsi+
	 * " Between fech_inire and fech_finre and tipo_uso='TD'" Si encuentra
	 * informaci�n entonces: Exonerado = Verdadero
	 * 
	 * Si no esta exonerado de presentaci�n de las facturas e items
	 * (Exonerado=Falso) Verificar que el incoterm enviado sea el mismo para
	 * todas las facturas del proveedor incoterm=DatosFactura.codincoterm Sacar
	 * el valor fob en base al incoterm enviado prec_factu=DAVs.mtonetofact
	 * vgas_tremb=DAVs.mtogasttransp masdscto=DAVs.mtomasdesc
	 * monvtasuce=DAVs.mtovtasuce vint_deven=DAVs.mtointdeven
	 * votr_gasto=DAVs.mtootrgasto vgas_trimp=DAVs.mtogastrimp
	 * vgas_segur=DAVs.mtogassegur vgas_carde=DAVs.mtogascarde
	 * vtot_deduc=DAVs.mtototdeduc
	 * 
	 * @param dav
	 * @param dua
	 * @return
	 */



	public List<Map<String, String>> validarDiferenciaFOBYAjustesItemsProveedor(DAV dav){

		List<Map<String, String>> result = new ArrayList<Map<String, String>>();


		Declaracion declaracion = (Declaracion) dav.getPadre();

		if(declaracion.isExoneradoFB()){
			return result;
		}        

		BigDecimal tfob = BigDecimal.ZERO;
		BigDecimal taju = BigDecimal.ZERO;

		tfob = FormatoBUtils.obtenerFOBTotalFormatoB(dav);
		taju = FormatoBUtils.obtenerAjusteTotalFormatoB(dav);

		BigDecimal tot_fob = BigDecimal.ZERO;
		BigDecimal tot_aju = BigDecimal.ZERO;		

		for (DatoFactura factura : dav.getListFacturas()) {
			for (DatoItem item : factura.getListItems()) {
				tot_fob = SunatNumberUtils.sum(tot_fob, SunatNumberUtils.multiply(item.getMtofobunita(), item.getCntcantcomer()));
				tot_aju = SunatNumberUtils.sum(tot_aju,	SunatNumberUtils.multiply(item.getMtoajusunita(),item.getCntcantcomer()) );		
			}
		}    


		boolean tieneHojaDeGastos = hasHojaDeGastos(declaracion);
		if (!tieneHojaDeGastos)
		{
			BigDecimal diferenciaAbs = SunatNumberUtils.absoluteDiference(tfob, tot_fob);
			CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
			String diferenciaAbsAsString = (diferenciaAbs != null) ? diferenciaAbs.toString() : " ";
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";

			if (diferenciaAbs != null && diferenciaAbs.doubleValue() > 20D) {
				//result.add(catalogoHelper.getErrorMap("05666",  new Object[] { diferenciaAbs, dav.getNumsecuprov() }));
				//glazaror... evitar uso de metodo getErrorMap
				result.add(catalogoAyudaService.getError("05666",  new String[] { diferenciaAbsAsString, numeroSecuenciaProveedor }));
			}

			diferenciaAbs = SunatNumberUtils.absoluteDiference(taju, tot_aju);
			if( diferenciaAbs != null && diferenciaAbs.doubleValue()  > 3D) {			
				//result.add(catalogoHelper.getErrorMap("05667", new Object[]{ diferenciaAbs, dav.getNumsecuprov() }));
				//glazaror... evitar uso de metodo getErrorMap
				result.add(catalogoAyudaService.getError("05667",  new String[] { diferenciaAbsAsString, numeroSecuenciaProveedor }));
			}


		}
		return result;
	}

	/**
	 * Valida si la cantidad de facturas en indicadas corresponde a la lista de
	 * facturas enviadas 
	 * @param dav
	 * @return
	 */	
	public Map<String, String> valgralfb3(DAV dav) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> result = new HashMap<String, String>();

		if(((Declaracion)dav.getPadre()).isExoneradoFB()){
			return result;
		}

		int facturasDAV = dav.getCntfacturas();
		int cantidadFacturas = dav.getListFacturas().size();

		if (!SunatNumberUtils.isEqual(facturasDAV, cantidadFacturas)){
			result = catalogoAyudaService.getError("05605");
		}

		return result;
	}

	private boolean hasHojaDeGastosOld(Declaracion declaracion) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		boolean pn_fhojgastve3 = false;
		Integer fecReferenciaSistema = SunatNumberUtils.getTodayAsInteger();

		boolean vigHojaGastos = funcionesService.hasVigenciaCriterio("VEHA", fecReferenciaSistema);

		for (DatoSerie serie : declaracion.getDua().getListSeries()) {
			if (vigHojaGastos) {
				boolean pn_fechamb = funcionesService.hasVigenciaCriterio("VEMB", fecReferenciaSistema);
				boolean pn_fhojgastve2 = funcionesService.hasVigenciaCriterio("TD49", fecReferenciaSistema);

				if (pn_fechamb) {
					for (DatoRegPrecedencia regPrecedencia : serie.getListRegPrecedencia()) {
						if (SunatStringUtils.isEqualTo(regPrecedencia.getCodregipre(), "91")
								&& SunatStringUtils.isStringInList(regPrecedencia.getCodaduapre(), "046,145,163,172")) {
							if (serie.getNumpartnandi() == 8701200000L	|| SunatStringUtils.isStringInList(SunatStringUtils.substringFox(serie.getNumpartnandi().toString(), 1, 4),"8702,8703,8704,8705")) {
								ValItemFB valItemFB =   fabricaDeServicios.getService("ValItemFB");
								DatoItem item = valItemFB.getItemCorrespondiente(serie,declaracion);

								if (pn_fhojgastve2	&& SunatStringUtils.isStringInList(item.getCodestamer(), "20,21,22,23,24,25,27,28")) {
									pn_fhojgastve3 = true;
								}
							}
						}
					}
				}
			}
		}
		return pn_fhojgastve3;
	}

	/**
	 * Metodo optimizado... Modificado por glazaror: si es que una dua tiene 1000 series y se cumple el criterio VEHA entonces se ejecutarian 1000 veces el metodo funciones.hasVigenciaCriterio
	 * innecesariamente. Se modifico el metodo para que a lo mucho se ejecuten 3 invocaciones al metodo funciones.hasVigenciaCriterio. Internamente este metodo
	 * realiza invocaciones rest en caso de ser una aplicacion web.
	 * 
	 * @param declaracion
	 * @return
	 * @ERRORR 00341
	 */
	private boolean hasHojaDeGastos(Declaracion declaracion) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		boolean pn_fhojgastve3 = false;
		Integer fecReferenciaSistema = SunatNumberUtils.getTodayAsInteger();

		boolean vigHojaGastos = funcionesService.hasVigenciaCriterio("VEHA", fecReferenciaSistema);
		if (vigHojaGastos) {
			boolean pn_fechamb = funcionesService.hasVigenciaCriterio("VEMB", fecReferenciaSistema);

			if (pn_fechamb) {
				boolean pn_fhojgastve2 = funcionesService.hasVigenciaCriterio("TD49", fecReferenciaSistema);

				for (DatoSerie serie : declaracion.getDua().getListSeries()) {
					if (serie.getListRegPrecedencia()!=null && serie.getListRegPrecedencia().size()>0){ //PAS20165E220200059-INC 2016-053883
						for (DatoRegPrecedencia regPrecedencia : serie.getListRegPrecedencia()) {
							if (SunatStringUtils.isEqualTo(regPrecedencia.getCodregipre(), "91")
									&& SunatStringUtils.isStringInList(regPrecedencia.getCodaduapre(),
											"046,145,163,172")) {
								if (serie.getNumpartnandi() == 8701200000L	|| SunatStringUtils.isStringInList(
										SunatStringUtils.substringFox(serie.getNumpartnandi().toString(), 1, 4),"8702,8703,8704,8705")) {
									ValItemFB valItemFB =   fabricaDeServicios.getService("ValItemFB");
									DatoItem item = valItemFB.getItemCorrespondiente(serie,declaracion);

									if (pn_fhojgastve2	&& SunatStringUtils.isStringInList(item.getCodestamer(), "20,21,22,23,24,25,27,28")) {
										pn_fhojgastve3 = true;
									}
								}
							}
						}						
					}
				}
			}
		}

		return pn_fhojgastve3;
	}

	/**
	 * Validacion envio complementario de Formato B Valida que la declaracion de
	 * referncia exista en la base de datos.
	 * 
	 * @param declaracion
	 * @return
	 * @ERRORR 00341
	 */
	// AC
	public List<Map<String, String>> validarDeclaracionExista(Declaracion declaracion) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
		DUA duaGrabada = new DUA();

		String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
		String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
		String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
		String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;
		duaGrabada = funcionesService.getDeclaracionReferencia(codaduanaref, codregimenref, 
				SunatNumberUtils.toLong(numcorreref), SunatNumberUtils.toInteger(annprese));

		if (duaGrabada == null){
			listErr.add(getErrorMap("00341", new Object[] {
					numcorreref, annprese, codregimenref, codaduanaref }));
			listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());			
		} else {
			duaGrabada.setPadre(declaracion);
			declaracion.setDua(duaGrabada);
		}

		return listErr;
	}

	/**
	 * Validacion envio complementario de Formato B Verificar que el a�o y
	 * n�mero de orden enviado (se obtiene de la variable del orquestador
	 * numOrden que contiene el a�o y n�mero concatenado) sea el mismo al
	 * declarado en la numeraci�n (cab_declara.ann_orden y
	 * cab_declara.num_orden), sino se genera el error 0338
	 * 
	 * @param declaracion
	 * @param numOrden
	 * @return
	 */

	public List<Map<String, String>> validarAnnNumOrden(Declaracion declaracion,
			String numOrden) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();		

		NumdeclRef numdeclRef = new NumdeclRef();
		DUA duaGrabada = new DUA();
		String annOrdenEnviada = "";
		String numOrdenEnviada = "";

		numdeclRef = declaracion.getNumdeclRef();
		String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
		String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
		String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
		String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;

		duaGrabada = funcionesService.getDeclaracionReferenciaResumida(codaduanaref,codregimenref, 
				SunatNumberUtils.toLong(numcorreref),SunatNumberUtils.toInteger(annprese));

		if (duaGrabada == null) {
			listErr.add(getErrorMap("00341", new Object[] {
					numcorreref, annprese, codregimenref, codaduanaref }));
			/*FORMB*/
			listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
		} else {
			annOrdenEnviada = numOrden.substring(0, 4);
			numOrdenEnviada = numOrden.substring(4);
			if (!SunatNumberUtils.isEqual(duaGrabada.getAnnorden(),	new Integer(annOrdenEnviada))
					|| !SunatStringUtils.isEqualTo(duaGrabada.getNumorden(), numOrdenEnviada)) {

				listErr.add(catalogoAyudaService.getError("00338"));
				/*FORMB*/
				listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());

			}

		}

		return listErr;
	}

	/**
	 * Validacion envio complementario de Formato B Verificar que la declaraci�n
	 * no este legajada (cab_declara.cod_estdua='por definir'), de estarlo se
	 * genera el error 0332
	 * 
	 * @param declaracion
	 * @return
	 */
	public List<Map<String, String>> validarEstadoLegajado(Declaracion declaracion){
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		//java.util.Map<String, String> result = new HashMap<String, String>();
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		DUA duaGrabada= new DUA();
		NumdeclRef numdeclRef= declaracion.getNumdeclRef();
		String codaduanaref=numdeclRef!=null?numdeclRef.getCodaduana():null;
		String codregimenref=numdeclRef!=null?numdeclRef.getCodregimen():null;
		String numcorreref=numdeclRef!=null?numdeclRef.getNumcorre():null;
		String annprese=numdeclRef!=null?numdeclRef.getAnnprese():null;
		duaGrabada = funcionesService.getDeclaracionReferenciaResumida(codaduanaref,codregimenref, 
				SunatNumberUtils.toLong(numcorreref), SunatNumberUtils.toInteger(annprese));
		if (duaGrabada!=null){
			if (duaGrabada.getCodEstdua().equals(ConstantesDataCatalogo.COD_DUA_LEGAJADA)) {// estado legajado
				CatalogoAyudaService catalogoAyudaService =  (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				result.add(catalogoAyudaService.getError("00332", new String[]{codaduanaref, annprese, codregimenref,numcorreref}));
				result.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());

			}
		}
		return result;
	}
	/**
	 * Validacion envio complementario de Formato B Verificar que las series
	 * enviadas por cada item del formato de valor (DatoSerieItem.numserie)
	 * correspondan a la totalidad de series de datos generales
	 * (cab_declar.cnt_totseries), sino se genera el error 0343
	 * 
	 * @param declaracion
	 * @return
	 */
	@Deprecated
	/*pendiente de eliminacion, verificar que realiza lo mismo que ValSerieItemFB.verificarSerieFormatoAEstaEnFormatoB*/
	public Map<String, String> validarSeriesEnviadas(Declaracion declaracion){
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		ValItemFB valItemFB =   fabricaDeServicios.getService("ValItemFB");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String> result = new HashMap<String, String>();
		DUA duaGrabada= new DUA();
		List<DatoSerie> seriesgrabadas =new ArrayList<DatoSerie>();
		Map<String, Object> params = new HashMap<String, Object>();		
		NumdeclRef numdeclRef= declaracion.getNumdeclRef();
		String codaduanaref=numdeclRef!=null?numdeclRef.getCodaduana():null;
		String codregimenref=numdeclRef!=null?numdeclRef.getCodregimen():null;
		String numcorreref=numdeclRef!=null?numdeclRef.getNumcorre():null;
		String annprese=numdeclRef!=null?numdeclRef.getAnnprese():null;
		duaGrabada=funcionesService.getDeclaracionReferencia(codaduanaref,codregimenref,SunatNumberUtils.toLong(numcorreref),SunatNumberUtils.toInteger(annprese));

		if (duaGrabada!=null){
			params.put("numcorredoc",duaGrabada.getNumcorredoc());

			seriesgrabadas=funcionesService.getSeriesReferencia(params);

			if (duaGrabada!=null && seriesgrabadas!=null && !seriesgrabadas.isEmpty()){

				if (duaGrabada.getCntnumseries().equals(seriesgrabadas.size())){ // la cantidad de series en la cabecera debe de ser igual a la cantidad de series de la consulta

					if (seriesgrabadas!=null && seriesgrabadas.size()>0){
						for(DatoSerie serieActual:seriesgrabadas){
							DatoItem item = valItemFB.getItemCorrespondiente(serieActual, declaracion);
							if (item==null)
								result = catalogoAyudaService.getError("00343");
						}
					}
				}else{
					result = catalogoAyudaService.getError("00343");
				}
			}else{

				result = getErrorMap("00341", new Object[] {
						numcorreref, annprese, codregimenref, codaduanaref });
			}
		}	
		return result;
	}

	/**
	 * Validacion envio complementario de Formato B Verificar si tiene
	 * registrado formato del valor
	 * 
	 * @param declaracion
	 * @return
	 */
	public List<Map<String, String>> verificarTieneFormatoBRegistrado(
			Declaracion declaracion) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");

		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		List<DatoFactura> listFacturas = new ArrayList<DatoFactura>();
		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
		DUA duaGrabada = new DUA();

		String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
		String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
		String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
		String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;

		duaGrabada = funcionesService.getDeclaracionReferenciaResumida(codaduanaref,
				codregimenref, SunatNumberUtils.toLong(numcorreref), SunatNumberUtils.toInteger(annprese));
		if (duaGrabada != null) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("numcorredoc", duaGrabada.getNumcorredoc());

			listFacturas = funcionesService.getListComprobPago(params);

			if (!CollectionUtils.isEmpty(listFacturas)) {
				listErr.add(catalogoAyudaService.getError("05722"));
				/*RZAVALA FORMB*/
				listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
			}
		}
		return listErr;
	}

	/**
	 * Validacion envio complementario de Formato B Verificar que el c�digo del
	 * agente sea el mismo al declarado en la numeraci�n, sino se genera el
	 * error 0337
	 * 
	 * @param declaracion
	 * @param numeroDocumentoIdentidadSender
	 * @param tipoDocumentoIdentidadSender
	 * @return
	 */
	public List<Map<String, String>> validarCodigoAgente(Declaracion declaracion,
			String numeroDocumentoIdentidadSender,
			String tipoDocumentoIdentidadSender, String tipoSender) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		Map<String, Object> params = new HashMap<String, Object>();

		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
		List<Participante> listParticipante = new ArrayList<Participante>();
		DUA duaGrabada = new DUA();

		String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
		String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
		String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
		String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;

		duaGrabada = funcionesService.getDeclaracionReferenciaResumida(codaduanaref,codregimenref, 
				SunatNumberUtils.toLong(numcorreref), SunatNumberUtils.toInteger(annprese));
		if (duaGrabada != null) {
			params.put("numeroCorrelativo", duaGrabada.getNumcorredoc());

			listParticipante = funcionesService.getListParticipante(params);

			for (Participante participanteActual : listParticipante) {
				if (participanteActual.getTipoParticipante().getCodDatacat().equals(tipoSender)) { // Tipo Declarante
					if (!(numeroDocumentoIdentidadSender.equals(participanteActual.getNumeroDocumentoIdentidad()) 
							&& tipoDocumentoIdentidadSender.equals(participanteActual.getTipoDocumentoIdentidad().getCodDatacat())))
					{
						listErr.add(catalogoAyudaService.getError("00337"));
						/*RZAVALA FORMB*/
						listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
					}

				}
			}
		} else {

			listErr.add(getErrorMap("00341", new Object[] {
					numcorreref, annprese, codregimenref, codaduanaref }));
			/*RZAVALA FORMB*/
			listErr.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());

		}
		return listErr;
	}

	/**
	 * Validar proveedor
	 * @param proveedor
	 * @param dav
	 * @return
	 */
	@Deprecated
	public List<Map<String, String>> validarProveedor(Participante proveedor, DAV dav) {
		ValProveFB valProveFB =   fabricaDeServicios.getService("ValProveFB");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();

		if(((Declaracion)dav.getPadre()).isExoneradoFB()){
			return result;
		}

		if(proveedor!=null){		
			//ValProveFB valParticipante = new ValProveFB();		
			//valParticipante.setCatalogoHelper( getCatalogoHelper() );
			//valParticipante.setFormatoBService(getFormatoBService() );
			//valParticipante.setFuncionesService( getFuncionesService() );

			result.add( valProveFB.codtipparticipante(dav) );
			result.add( valProveFB.codtipdocparticipante(dav) );
			if (!SunatStringUtils.isEmptyTrim(proveedor.getNumeroDocumentoIdentidad()))
				result.add(valProveFB.numdocparticipante(proveedor.getNumeroDocumentoIdentidad()));
			result.add( valProveFB.codpaisparticipante(dav) );
			result.add( valProveFB.nomparticipante(dav) );
			result.add( valProveFB.dirparticipante(dav) );
			result.add( valProveFB.desubigparticipante(dav) );
			result.add( valProveFB.numtelefono(dav) );

			if( !SunatStringUtils.isEmpty( proveedor.getFax() )  )
				result.add( valProveFB.numfax(dav) );

			result.add( valProveFB.dirmailweb(dav) );
			result.add( valProveFB.dirpagweb(dav) );
		}
		return result;
	}

	//glazaror... metodo optimizado
	public List<Map<String, String>> validarProveedor(Participante proveedor, DAV dav, Map<String, Object> variablesIngreso) {

		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		ValProveFB valProveFB =   fabricaDeServicios.getService("ValProveFB");
		if(((Declaracion)dav.getPadre()).isExoneradoFB()){
			return result;
		}

		if(proveedor!=null){		
			//ValProveFB valParticipante = new ValProveFB();		
			//valParticipante.setCatalogoHelper( getCatalogoHelper() );
			//valParticipante.setFormatoBService(getFormatoBService() );
			//valParticipante.setFuncionesService( getFuncionesService() );

			//glazaror... le pasamos variablesIngreso
			result.add( valProveFB.codtipparticipante(dav, variablesIngreso) );
			//glazaror... le pasamos variablesIngreso
			result.add( valProveFB.codtipdocparticipante(dav, variablesIngreso) );
			if (!SunatStringUtils.isEmptyTrim(proveedor.getNumeroDocumentoIdentidad()))
				result.add(valProveFB.numdocparticipante(proveedor.getNumeroDocumentoIdentidad()));
			//glazaror... le pasamos variablesIngreso
			result.add( valProveFB.codpaisparticipante(dav, variablesIngreso) );
			result.add( valProveFB.nomparticipante(dav) );
			result.add( valProveFB.dirparticipante(dav) );
			result.add( valProveFB.desubigparticipante(dav) );
			result.add( valProveFB.numtelefono(dav) );

			if( !SunatStringUtils.isEmpty( proveedor.getFax() )  )
				result.add( valProveFB.numfax(dav) );

			result.add( valProveFB.dirmailweb(dav) );
			result.add( valProveFB.dirpagweb(dav) );
		}
		return result;
	}

	/**
	 * Validar proveedor local
	 * @param dav
	 * @return
	 */
	public List<Map<String, String>> validarProveedorLocal(DAV dav){
		ValProveLocFB valProveLocFB =   fabricaDeServicios.getService("ValProveLocFB");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}

		boolean listafactura = false;

		for (DatoFactura factura : dav.getListFacturas()) {
			if (!CollectionUtils.isEmpty(factura.getListFactSucesivas())){
				listafactura = true;
				break;
			}
		}

		/*Adecuaciones a regla de proveedor local seg�n RIN del 28/03/2014 RZM*/
		if ((((Declaracion) dav.getPadre()).getDua().getCodpropiedad().equals("02") || 
				(dav.getCodnatutrans().equals(Constants.COD_NATU_TRANS_VENTAS_SUCESIVAS_ANTES_NACIONALIZACION)
						&& listafactura))) {
			//			ValProveLocFB valParticipante = new ValProveLocFB();		
			//			valParticipante.setCatalogoHelper( getCatalogoHelper() );
			//			valParticipante.setFormatoBService(getFormatoBService() );
			//			valParticipante.setFuncionesService( getFuncionesService() );
			result.add( valProveLocFB.codtipparticipante(dav) );
			result.add( valProveLocFB.codtipdocparticipante(dav) );
			result.addAll( valProveLocFB.numdocparticipante(dav ) );
			result.addAll( valProveLocFB.nomparticipante(dav ) );
		}
		else 
		{ /*Adecuaciones a regla de proveedor local seg�n RIN del 28/03/2014 RZM*/
			if (!SunatStringUtils.isEmpty(dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat()))	result.add(getErrorMap("31775", new Object[] {dav.getNumsecuprov(), dav.getProveedorLocal().getTipoDocumentoIdentidad().getCodDatacat()}));
			if (!SunatStringUtils.isEmpty(dav.getProveedorLocal().getNumeroDocumentoIdentidad()))	result.add(getErrorMap("31776", new Object[] {dav.getNumsecuprov(), dav.getProveedorLocal().getNumeroDocumentoIdentidad()}));        			
			if (!SunatStringUtils.isEmpty(dav.getProveedorLocal().getNombreRazonSocial()))	result.add(getErrorMap("31777", new Object[] {dav.getNumsecuprov(), dav.getProveedorLocal().getNombreRazonSocial()}));
			if (!SunatStringUtils.isEmpty(dav.getProveedorLocal().getTipoParticipante().getCodCatalogo()))	result.add(getErrorMap("31774", new Object[] {dav.getNumsecuprov(), dav.getProveedorLocal().getTipoParticipante().getCodDatacat() }));			
		}

		return result;
	}


	/**
	 * Validar ventas sucesivas
	 * @param dav
	 * @return
	 */

	public List<Map<String, String>> validarVentasSucesivas(DAV dav) {
		ValFactSuc valFactSuc =   fabricaDeServicios.getService("ValFactSuc");
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}

		if (dav.getCodnatutrans().equals(Constants.COD_NATU_TRANS_VENTAS_SUCESIVAS_ANTES_NACIONALIZACION)) {

			//			ValFactSuc valVentaSucesiva = new ValFactSuc();
			//			valVentaSucesiva.setCatalogoHelper(getCatalogoHelper());
			//			valVentaSucesiva.setFormatoBService(getFormatoBService());
			//			valVentaSucesiva.setFuncionesService(getFuncionesService());

			boolean envioFactVentaSucesiva = false;

			for (DatoFactura factura : dav.getListFacturas()) {
				if (!CollectionUtils.isEmpty(factura.getListFactSucesivas())){
					for (DatoFactSuce facturaSucesiva : factura.getListFactSucesivas()) {
						envioFactVentaSucesiva = true;
						result.add(valFactSuc.validarFechaFacturaSucesiva(facturaSucesiva));
						result.add(valFactSuc.numfactsuc(facturaSucesiva));
						result.add(valFactSuc.mtofactsuc(facturaSucesiva));
					}
				}				
			}

			if(!envioFactVentaSucesiva){
				result.add(valFactSuc.validarFechaFacturaSucesiva(null));
				result.add(valFactSuc.numfactsuc(null));
				result.add(valFactSuc.mtofactsuc(null));
			}
		} else			
		{
			/*1.2.	El sistema valida que si no se consign� en el Formato B el c�digo 29 
			 *�Ventas sucesivas antes de la nacionalizaci�n�, no se consigne ninguna factura de venta sucesiva ni 
			 *ninguno de sus datos como son la fecha, n�mero y monto de la factura de venta sucesiva.*/			
			for (DatoFactura factura : dav.getListFacturas()) {
				if (!CollectionUtils.isEmpty(factura.getListFactSucesivas())){
					for (DatoFactSuce facturaSucesiva : factura.getListFactSucesivas()) {
						if (facturaSucesiva.getFecfactsuc()!=null)	result.add(getErrorMap("31779", new Object[]	{dav.getNumsecuprov(),factura.getNumsecfactu(),	SunatDateUtils.getFormatDate(facturaSucesiva.getFecfactsuc(), "dd/MM/yyyy")}));
						if (!SunatStringUtils.isEmpty(facturaSucesiva.getNumfactsuc().toString()))	result.add(getErrorMap("31780", new Object[] {dav.getNumsecuprov(), factura.getNumsecfactu(), facturaSucesiva.getNumfactsuc().toString()}));        			
						if (!SunatStringUtils.isEmpty(facturaSucesiva.getMtofactsuc().toString()))	result.add(getErrorMap("31781", new Object[] {dav.getNumsecuprov(), factura.getNumsecfactu(),facturaSucesiva.getMtofactsuc().toString()}));

					}
				}

			}
		}
		return result;
	}


	/**
	 * Validar intermediario
	 * @param dav
	 * @return
	 */
	public List<Map<String, String>> validarIntermediario(DAV dav) {		
		ValIntermediarioFB valIntermediarioFB =   fabricaDeServicios.getService("ValIntermediarioFB");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return result;
		}
		//ValIntermediarioFB valParticipante = new ValIntermediarioFB();		
		//		ValIntermediarioFB.setCatalogoHelper( getCatalogoHelper() );
		//		valParticipante.setFormatoBService(getFormatoBService() );
		//		valParticipante.setFuncionesService( getFuncionesService() );

		if (dav.getIndexisinter().equals(Constants.COD_EXISTE_INTERMEDIARIO_SI)) {
			//			Participante partic=intermediario;
			//			DataCatalogo  tipoDocumentoIdentidad= partic!=null?partic.getTipoDocumentoIdentidad():null;
			//			String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
			//			String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
			//			String nombreRazonSocial=partic!=null?partic.getNombreRazonSocial():null;
			//			String direccion=partic!=null?partic.getDireccion():null;
			//			String ciudad=partic!=null?partic.getCiudad():null;
			//			String email=partic!=null?partic.getEmail():null;
			//			DataCatalogo tipoParticipante=partic!=null?partic.getTipoParticipante():null;
			//			String codParticipante=tipoParticipante!=null?tipoParticipante.getCodDatacat():null;
			//			DataCatalogo pais=partic!=null?partic.getPais():null;
			//			String codPais=pais!=null?pais.getCodDatacat():null;

			//	if( ! SunatStringUtils.isEmpty( codParticipante) )
			result.add( valIntermediarioFB.codtipparticipante(dav) );
			//				String codPais = dav.getIntermediario().getPais() != null ? dav.getIntermediario().getPais().getCodDatacat() : "";//por SAU201510002000120  pase 436 //se comenta porq validacion es dentro PASE451
			//				 if(codPais.equals("PE")){//por SAU201510002000120  pase 436 dichos campos son condicionados a que sea solo de peru//se comenta porq validacion es dentro 451
			result.addAll( valIntermediarioFB.codtipdocparticipante(dav) );

			//if( ! SunatStringUtils.isEmpty(numeroDocumentoIdentidad ) )
			result.addAll( valIntermediarioFB.numdocparticipante(dav) );
			//				 }//por SAU201510002000120  pase 436//se comenta porq validacion es dentro PASE443			
			//if( ! SunatStringUtils.isEmpty( codPais ) )
			result.add( valIntermediarioFB.codpaisparticipante(dav) );

			//if( ! SunatStringUtils.isEmpty( nombreRazonSocial ) )
			result.add( valIntermediarioFB.nomparticipante(dav) );

			//if( ! SunatStringUtils.isEmpty( direccion ) )
			result.add( valIntermediarioFB.dirparticipante(dav) );

			//if( ! SunatStringUtils.isEmpty( ciudad ) )
			result.add( valIntermediarioFB.desubigparticipante(dav ) );
			//		result.add( valParticipante.numtelefono(intermediario.getTelefono()) );
			//		result.add( valParticipante.numfax(intermediario.getFax()) );
			//if( ! SunatStringUtils.isEmpty( email ) )
			result.addAll( valIntermediarioFB.dirmailweb(dav) );
			//		result.add( valParticipante.dirpagweb(intermediario.getPaginaWeb()) );
			//ggranados formb
			result.add(valIntermediarioFB.codtipinter(dav));
			//fin ggranados formb


		}else{
			if (!SunatStringUtils.isEmpty(dav.getIntermediario().getTipoDocumentoIdentidad().getCodDatacat())
					|| !SunatStringUtils.isEmpty(dav.getIntermediario().getNumeroDocumentoIdentidad())
					|| !SunatStringUtils.isEmpty(dav.getIntermediario().getNombreRazonSocial())
					|| !SunatStringUtils.isEmpty(dav.getIntermediario().getTipoParticipante().getCodCatalogo())) {
				result.add(getErrorMap("30588", new Object[] {
						dav.getNumsecuprov(), dav.getIndexisinter() }));
			}
		}
		return result;
	}

	/**
	 * Validar declarante
	 * @param dav
	 * @return
	 */
	public List<Map<String, String>> validarPersonaDecl(DAV dav) {
		ValDeclaranteFB valDeclaranteFB =   fabricaDeServicios.getService("ValDeclaranteFB");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();

		//		ValDeclaranteFB valParticipante = new ValDeclaranteFB();		
		//		valParticipante.setCatalogoHelper( getCatalogoHelper() );
		//		valParticipante.setFormatoBService(getFormatoBService() );
		//		valParticipante.setFuncionesService( getFuncionesService() );

		if (dav.getPersonaDecl() != null) {
			Participante partic=dav.getPersonaDecl();
			DataCatalogo tipoParticipante=partic!=null?partic.getTipoParticipante():null;
			result.add( valDeclaranteFB.codtipparticipante(tipoParticipante) );
			result.add( valDeclaranteFB.codtipdocparticipante(dav) );
			result.add( valDeclaranteFB.numdocparticipante(dav) );
			result.add( valDeclaranteFB.nomparticipante(dav) );
			result.add(valDeclaranteFB.validarCargoDeclarante(dav));
		}
		return result;
	}

	//glazaror... optimizacion del metodo validarPersonaDecl
	public List<Map<String, String>> validarPersonaDecl(DAV dav, Map<String, Object> variablesIngreso) {
		ValDeclaranteFB valDeclaranteFB =   fabricaDeServicios.getService("ValDeclaranteFB");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();

		if (dav.getPersonaDecl() != null) {
			Participante partic=dav.getPersonaDecl();
			DataCatalogo tipoParticipante=partic!=null?partic.getTipoParticipante():null;
			result.add( valDeclaranteFB.codtipparticipante(tipoParticipante, variablesIngreso) );
			result.add( valDeclaranteFB.codtipdocparticipante(dav, variablesIngreso) );
			result.add( valDeclaranteFB.numdocparticipante(dav) );
			result.add( valDeclaranteFB.nomparticipante(dav) );
			result.add(valDeclaranteFB.validarCargoDeclarante(dav));
		}
		return result;
	}

	public Map<String, Object> setupDAV(DAV dav){

		Map<String, Object> parameter = new  HashMap<String, Object>();

		parameter.put("dav", dav);

		return parameter;
	}

	/* PASE...........MERGE LUISMI */
	/**Validar el envio del formato B
	 * @param declaracion
	 * @return TRANSACCION XX01
	 * @return mapa
	 * ERRORES 30592,30595
	 */
	@ServicioAnnot(tipo="V",codServicio=2499, descServicio="valida validarEnviosFormatoB")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"declaracion","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=2499,numSecEjec=248,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.FormatoA")
	public List<Map<String, ?>> validarEnviosFormatoB(Declaracion declaracion, Date fechaReferencia) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		ResponseListManager responseListManager = new ResponseListManager();
		List<Map<String, String>> errorEnvioFormatoB = new ArrayList<Map<String, String>>();

		if (!CollectionUtils.isEmpty(declaracion.getListDAVs())){
			return responseListManager.getResponseList();
		}
		//cambio en el f2 ggranados formb
		//valida si el envio del formato b puede ser exonerado
		if(tieneEnvioFormatoBExonerado(declaracion.getDua(), fechaReferencia)){
			declaracion.setExoneradoFB(true);       
			responseListManager.addResponseMap(catalogoAyudaService.getError("30592"));
			return responseListManager.getResponseList();
		}

		//valida si el envio del formato b es obligatorio
		errorEnvioFormatoB = this.debeEnviarFormatoBObligatorio(declaracion, fechaReferencia);

		if (!CollectionUtils.isEmpty(errorEnvioFormatoB)) {
			responseListManager.addResponseList1(errorEnvioFormatoB);		 
			//responseListManager.addResponseMap(catalogoAyudaService.getError(errorEnvioFormatoB.toString()));
			responseListManager.addErrorFinalizarProceso();
			return responseListManager.getResponseList();
		}

		//valida si el envio del formato b puede ser diferido
		if(tieneEnvioFormatoBDiferido(declaracion.getDua())) {
			declaracion.setExoneradoFB(true);
			responseListManager.addResponseMap(catalogoAyudaService.getError("30592"));		  
			return responseListManager.getResponseList();

		}else if(declaracion.getDua().getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)){
			responseListManager.addResponseMap(catalogoAyudaService.getError("30595"));
			responseListManager.addErrorFinalizarProceso();
			return responseListManager.getResponseList();
		}else{            
			responseListManager.addResponseMap(catalogoAyudaService.getError("30777"));
			responseListManager.addErrorFinalizarProceso();
			return responseListManager.getResponseList();
		}		
	}



	public Declaracion importadorTieneOtraDuaConFormatoBDiferido(
			String numeroDocumentoImportador, String tipoDocumentoImportador, Date fechaReferencia){        

		Map<String,Object> params = new HashMap<String,Object>();
		params.put("INDICADOR_REGUL", false);
		params.put("ENVIO_REGUL", false);
		params.put("PLAZO", Constants.PLAZO_MAXIMO_DESCARGA);
		params.put("COD_MODALIDAD", ConstantesDataCatalogo.MODA_ANTICIPADA);
		params.put("NUM_DOCIDENT_IMP", numeroDocumentoImportador);
		params.put("COD_TIPDOC_IMP", tipoDocumentoImportador);
		params.put("COD_CANAL", ConstantesDataCatalogo.COD_CANAL_VERDE);

		//		List<Declaracion> listaDeclaraciones = FormatoBServiceImpl.getInstance().getCabDeclaraDAO().findDeclaraPendienteRegularizacion(params);
		//		List<Declaracion> listaDeclaraciones=((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDeclaraPendienteRegularizacion(params);

		GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
		List<Declaracion> listaDeclaraciones =  getDeclaracionService.getDeclaracionPendienteRegularizar(params);


		Declaracion declaracion;      
		//        GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
		for (Declaracion decla : listaDeclaraciones) {
			//            declaracion = FormatoBServiceImpl.getInstance().getDeclaracionService().getDeclaracionResumida(
			//                    		decla.getCodaduana(), 
			//                    		decla.getNumeroDeclaracion().intValue(), 
			//                    		decla.getDua().getAnnpresen(), 
			//                    		decla.getCodregimen());
			declaracion = getDeclaracionService.getDeclaracionResumida(
					decla.getCodaduana(), 
					decla.getNumeroDeclaracion().intValue(), 
					decla.getDua().getAnnpresen(), 
					decla.getCodregimen());
			if(declaracion!=null){
				if (CollectionUtils.isEmpty(declaracion.getListDAVs())) {
					if (!tieneEnvioFormatoBExonerado(declaracion.getDua(), fechaReferencia)) {
						return declaracion;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Validar si el envio de la Declaracion esta exonerado de transmitir el formato B. 
	 * @param declaracion
	 * @return boolean
	 */

	public boolean tieneEnvioFormatoBExonerado(DUA dua, Date fechaReferencia){
		//verificar105
		//        Integer gcFechaIngSis = SunatNumberUtils.getTodayAsInteger();
		//        String tipoDocum = "";
		//        String numeDocum = "";
		//
		//        if (SunatStringUtils.isEqualTo(dua.getDeclarante().getTipoParticipante().getCodDatacat(), Constants.COD_DATA_CATALOG_CONSIGNATARIO_DUENO)) {
		//            tipoDocum = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
		//            numeDocum = dua.getDeclarante().getNumeroDocumentoIdentidad();
		//        }
		// Se Verifica en la tabla RES_SPIM si est� exonerado de la transmisi�n
		// de Formato B.
		//        boolean exonerado = funcionesService.isExonerado(tipoDocum, numeDocum, gcFechaIngSis);
		//        if (exonerado) {
		//            return true;
		//        }

		if (SunatStringUtils.isEqualTo(dua.getCodmodalidad(), ConstantesDataCatalogo.COD_MODALIDAD_URGENTE)
				&& SunatStringUtils.isEqualTo(dua.getIndSocorro(), ConstantesDataCatalogo.IND_SOCORRO)) {
			return true;
		}

		if (SunatStringUtils.isEqualTo(dua.getCodtipotratamiento(), ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)) {
			return true;
		}
		// serie con codigo liberatorio   
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		for (DatoSerie serie : dua.getListSeries()) {                        
			Map existeCodLiberatorioEx = catalogoAyudaService.getElementoCat(
					ConstantesTipoCatalogo.CATALOGO_COD_LIBERATORIO_EXONERADO, serie.getCodliberatorio().toString(),
					fechaReferencia);

			if (!CollectionUtils.isEmpty(existeCodLiberatorioEx)) {
				return true;
			}
		}
		// serie con partida exonerada
		for (DatoSerie serie : dua.getListSeries()) {
			Map existePartidaEx = catalogoAyudaService.getElementoCat(
					ConstantesTipoCatalogo.CATALOGO_PARTIDA_EXONERADA,
					SunatStringUtils.substringFox(serie.getNumpartnandi().toString(), 1, 4), fechaReferencia);

			if (!CollectionUtils.isEmpty(existePartidaEx)) {
				return true;
			}
		}

		return false;
	}

	/***
	 * Validar si se puede transmitir el formato B de forma diferida.* 
	 * @param dua
	 * @return
	 */
	public boolean tieneEnvioFormatoBDiferido(DUA dua){

		boolean esDuaAnticipadaConGarantia = false;
		boolean esDuaAnticipadaEImportadorFrecuente = false;
		esDuaAnticipadaConGarantia = esDuaAnticipadaConGarantia160(dua);
		esDuaAnticipadaEImportadorFrecuente = esDuaAnticipadaEImportadorFrecuente(dua);

		// Dua Anticipada con importador frecuente o cuenta con la garantia art. 160
		if ((esDuaAnticipadaConGarantia) || (esDuaAnticipadaEImportadorFrecuente)) {
			return true;
		}
		return false;
	}
	//GGRANADOS - TEST   
	//    public Map<String, String> validarEnviaMontosProvisionales(DatoSerie serie){
	//    	Map<String, String> error = new HashMap<String, String>();
	//    	
	//        if (((Declaracion) serie.getPadre().getPadre()).isExoneradoFB()) {
	//            return error;
	//        }
	//    	
	//    	Integer numeroSerieValorProvisional = funcionesService.obtenerSeriesValorProvisional(serie);
	//    	if (numeroSerieValorProvisional!=null) {
	//    		error = catalogoHelper.getErrorMap("30593", new Object[] {serie.getNumserie()});
	//    	}
	//    	return error;
	//    }

	/**
	 * Validar si es obligatorio el envio del formato B.
	 * @param declaracion
	 * @return mapa
	 * @TRANSACCION XX01
	 * @Error 30594, 30593, 30667
	 */

	public List<Map<String, String>> debeEnviarFormatoBObligatorio(Declaracion declaracion, Date fechaReferencia){
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		List<Map<String, String>> lstError = new ArrayList<Map<String, String>>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		/**P34 AMANCILLA*/
		if("70".equals(declaracion.getCodregimen())){
			return lstError;
		}

		/***FIN*/

		/*Incorporaci�n de reglas del valor provisional de la RIN10 28/03/2014 RZM*/
		/*El sistema verifica que si se consigna la fecha fin del valor provisional en la secci�n de datos generales del formato A o el Valor Estimado
		 */
		Date fecfinprovisional = new Date();
		if (declaracion.getDua().getFecfinprovsional() != null) fecfinprovisional = declaracion.getDua().getFecfinprovsional(); 
		else  fecfinprovisional = SunatDateUtils.getDateFromInteger(99991231);     // valor por default 99991231

		if (!"99991231".equals(sdf.format(fecfinprovisional)))
			lstError.add(getErrorMap("31778", new Object[] { SunatDateUtils.getFormatDate(declaracion.getDua().getFecfinprovsional(), "dd/MM/yyyy")}));        	
		/*-*/		


		for (DatoSerie serie : declaracion.getDua().getListSeries()) {
			if(esAutoUsado(serie)){
				lstError.add(getErrorMap("30594", new Object[] { serie.getNumserie() }));				
			}			

			Integer numeroSerieValorProvisional = funcionesService.obtenerSeriesValorProvisional(serie);
			if (numeroSerieValorProvisional!=null) {
				lstError.add( getErrorMap("30593",new Object[]{ numeroSerieValorProvisional, serie.getValestimado()}));
			}
		}

		if(!CollectionUtils.isEmpty(lstError)){
			return lstError;
		}

		Declaracion otraDuaConFormatoBDiferido = 
				importadorTieneOtraDuaConFormatoBDiferido(
						declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad(), 
						declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(), 
						fechaReferencia);

		if (otraDuaConFormatoBDiferido != null) {
			StringBuffer numeroDua = new StringBuffer(otraDuaConFormatoBDiferido.getCodaduana()).append(" - ")
					.append(otraDuaConFormatoBDiferido.getDua().getAnnpresen()).append(" - ")
					.append(otraDuaConFormatoBDiferido.getDua().getCodregimen()).append(" - ")
					.append(otraDuaConFormatoBDiferido.getNumeroDeclaracion().toString());
			lstError.add(getErrorMap("30667", new Object[] { numeroDua }));
		}

		return lstError;
	}

	/**
	 * Verifica si alguna de las series corresponde a un auto usado FORMATO A
	 * @param dua
	 * @return
	 */
	public Integer esAutoUsado(DUA dua) {	  
		for (DatoSerie serie : dua.getListSeries()) {
			if (esPartidaVehiculo(serie.getNumpartnandi()) && 
					esProductoUsado(serie.getCodestamerca())) {
				return serie.getNumserie();
			}
		}	
		return null;
	}

	/**
	 * Verifica si la serie corresponde a un auto usado FORMATO A 
	 * @param serie
	 * @return boolean
	 */
	public boolean esAutoUsado(DatoSerie serie) {     
		if (esPartidaVehiculo(serie.getNumpartnandi()) && 
				esProductoUsado(serie.getCodestamerca())) {
			return true;
		}           
		return false;
	}    

	/**
	 * Verifica si el estado de la mercaderia es usada. 
	 * @param codEstadoMercaderia
	 * @return boolean
	 */

	public boolean esProductoUsado(String codEstadoMercaderia) {	  
		CatalogoValidaService catalogoValidaService = this.fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		List<Map<String, String>> resultado = catalogoValidaService.validarElementoGrupo("531", codEstadoMercaderia);
		if (resultado.isEmpty()) {
			return true;
		}
		return false;
	}

	/**
	 * Verifica si la partida corresponde a vehiculos
	 * @param numeroPartida
	 * @return boolean*/
	public boolean esPartidaVehiculo(Long numeroPartida) {
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		String codigoCatalogoVEP = String.valueOf(numeroPartida).substring(0, 4);
		String codigoCatalogoVES = String.valueOf(numeroPartida);
		boolean resultadoVEP = CollectionUtils.isEmpty(catalogoValidaService.validarElementoCat("VEP", codigoCatalogoVEP));
		boolean resultadoVES = CollectionUtils.isEmpty(catalogoValidaService.validarElementoCat("VES", codigoCatalogoVES));
		//boolean resultadoVEP= 	catalogoHelper.isValid(codigoCatalogoVEP, "VEP");
		//boolean resultadoVES= 	catalogoHelper.isValid(codigoCatalogoVES, "VES");


		if ((resultadoVEP) || (resultadoVES)) {
			return true;
		}
		return false;
	}


	/**
	 * Valida que la declaracion no est� referida a partidas de veh�culos usados.
	 * @param item
	 * @return map
	 * Error : 30585*/
	//RETIRAR DE LAS VALIDACIONES DEL GGRANADOS_TXX02
	//	public Map<String, String> declaracionContienePartidaAutoUsado(DatoItem item) {
	//		Map<String, String> result = new HashMap<String, String>();
	//		if (tieneEnvioFormatoBDiferido(((Declaracion)item.getPadre().getPadre().getPadre()).getDua())){
	//			
	//			if (esPartidaVehiculo(item.getNumpartnandi())	&& (esProductoUsado(item.getCodestamer()))) {
	//				result = catalogoHelper.getErrorMap("30585", new Object[]
	//								{ item.getNumsecitem(),
	//								  item.getCodestamer(),
	//								  item.getNumpartnandi() });
	//			
	//			}
	//		}
	//		return result;
	//	}

	/**
	 * Valida que todos los valores de los items que se env�an sean definitivos, tipo de valor = �1�
	 * @param datoMontoProv
	 * @return map
	 * Error : 30586 */	
	public Map<String, String> sonValoresDefinitivos(DatoMontoProv datoMontoProv) {
		Map<String, String> result = new HashMap<String, String>();

		if(!SunatStringUtils.isEmpty(datoMontoProv.getIndtipovalor())){
			if (!datoMontoProv.getIndtipovalor().equals(Constants.CODIGO_VALOR_DEFINITIVO)) {
				result = getErrorMap("30586",   
						new Object[] { ((DatoItem) datoMontoProv.getPadre()).getNumsecitem(),}); 

			}
		}
		return result;

	}

	/**
	 * Valida:
	 *  a.	Dua anticipada y cuente con garantia 160
	 *  b.	Dua anticipada y corresponda a un importador frecuente.
	 *  c.	Que no tenga pendiente el envio del formato B con plazo vencido para realizarlo.
	 * @param declaracion
	 * @return map
	 * @TRANSACCION XX02
	 * Errores :30587, 30589  */

	//RETIRAR DE LAS VALIDACIONES DEL GGRANADOS_TXX02		
	//    public List<Map<String, String>> puedeEnviarFormatoBDiferido(Declaracion declaracion, Date fechaReferencia){
	//
	//        List<Map<String, String>> errores = new ArrayList<Map<String, String>>();
	//        
	//        if(tieneEnvioFormatoBExonerado(declaracion.getDua(), fechaReferencia)){
	//        	return errores;
	//        }
	//        
	//        Declaracion otraDuaConFormatoBDiferido = importadorTieneOtraDuaConFormatoBDiferido(
	//        		declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad(), 
	//                declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(), fechaReferencia);
	//
	//        if (otraDuaConFormatoBDiferido != null) {
	//            errores.add(catalogoHelper.getErrorMap("30589"));
	//            errores.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
	//            return errores;
	//        }
	//
	//        if ((tieneEnvioFormatoBDiferido(declaracion.getDua()))) {
	//            return errores;
	//        }
	//        else {
	//            errores.add(catalogoHelper.getErrorMap("30587"));
	//            errores.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
	//        }
	//        return errores;
	//    }


	public boolean esDuaAnticipadaConGarantia160(DUA dua) {		
		if (!StringUtils.isEmpty(dua.getPago().getPagoDeclaracion().getCodgarantia())	
				&& dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO))
			return true;
		return false;

	}

	public boolean esDuaAnticipadaEImportadorFrecuente(DUA dua) {
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		String tipoDocum = "";
		String numeDocum = "";

		if (SunatStringUtils.isEqualTo(dua.getDeclarante().getTipoParticipante().getCodDatacat(),
				ConstantesDataCatalogo.TIPO_OPERADOR_DUENO_CONSIGNATARIO)){
			tipoDocum = dua.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat();
			numeDocum = dua.getDeclarante().getNumeroDocumentoIdentidad();
		}


		if ((dua.getCodmodalidad().equals(ConstantesDataCatalogo.COD_MODALIDAD_ANTICIPADO)) && 
				(funcionesService.isImportadorFrecuente(dua.getCodregimen().toString(), tipoDocum, numeDocum))) {
			return true;
		}
		return false;

	}

	/**
	 *3.Validaciones de la determinaci�n del valor.
	  3.1.Validaci�n de la casilla 8.1.1 �Precio Neto seg�n factura�.
	  3.2.Validaci�n de la casilla 8.2.3 �Bienes suministrados por el importador, gratuitamente o precio reducido y utilizados en las mercanc�as importadas�.
	  3.3.Validaci�n de la casilla 8.2.4 �C�nones y derechos de licencia�
	  3.4.Validaci�n de la casilla 8.2.5 �Cualquier parte del producto de la reventa, cesi�n o utilizaci�n posterior directa o indirecta que revierta al vendedor2
	 * @param dav
	 * @return listmap
	 * Errores :30613, 30614, 30615, 30616*/

	public List<Map<String,String>> validarDeterminacionValorTransaccion(DAV dav){

		List<Map<String, String>> errores = new ArrayList<Map<String,String>>();

		if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
			return errores;
		}

		boolean casilla79Seleccionada = false;
		boolean casilla710Seleccionada = false;

		for (DatoCondTransaccion datoCondTransaccion : dav.getListCondTransacciones()) {
			if (datoCondTransaccion.getCodindcondtra().equals("09") && datoCondTransaccion.getIndcondtra().equals("1")) {
				casilla79Seleccionada = true;
			}
			if (datoCondTransaccion.getCodindcondtra().equals("10") && datoCondTransaccion.getIndcondtra().equals("1")) {
				casilla710Seleccionada = true;
			}
		} 
		BigDecimal presBiser11Aux = BigDecimal.ZERO; 
		BigDecimal precFactu01 = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PREC_FACTU).getMtologistico();	  
		BigDecimal presBiser11 = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PRES_BISER).getMtologistico();
		BigDecimal mateComp12  = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MATECOMP).getMtologistico();
		BigDecimal herrUtil13  = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_HERRUTIL).getMtologistico();
		BigDecimal matConsu14  = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MATCONSU).getMtologistico();
		BigDecimal trabInge15  = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_TRABINGE).getMtologistico();
		BigDecimal vDerLicen16 = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VDER_LICEN).getMtologistico();
		BigDecimal prodReven17 = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PROD_REVEN).getMtologistico();

		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (SunatStringUtils.isStringInList(dav.getCodnatutrans(), "11,12,13,29")) {
			if (!SunatNumberUtils.isGreaterThanZero(precFactu01)) {
				//glazaror... evitamos el uso de catalogoHelper.getErrorMap
				/*errores.add(getCatalogoHelper().getErrorMap("30613",
                        new Object[] { dav.getNumsecuprov(), precFactu01, dav.getCodnatutrans() }));*/

				//glazaror... hacemos uso de catalogoAyudaService.getError
				String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
				String precFactu01AsString = (precFactu01 != null) ? precFactu01.toString() : " ";
				String codigoNatuTrans = (dav.getCodnatutrans() != null) ? dav.getCodnatutrans().toString() : " ";
				errores.add(catalogoAyudaService.getError("30613", new String[] { numeroSecuenciaProveedor, precFactu01AsString, codigoNatuTrans}));

			}
		}

		if(presBiser11!=null){
			presBiser11Aux=SunatNumberUtils.sum(mateComp12,herrUtil13,matConsu14,trabInge15);

			if(!SunatNumberUtils.isEqual(presBiser11, presBiser11Aux)){
				//glazaror... evitamos el uso de catalogoHelper.getErrorMap
				//errores.add( getCatalogoHelper().getErrorMap("30614", new Object[]{dav.getNumsecuprov(), presBiser11 } ) );

				//glazaror... hacemos uso de catalogoAyudaService.getError
				String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
				String presBiser11AsString = (presBiser11 != null) ? presBiser11.toString() : " ";
				errores.add(catalogoAyudaService.getError("30614", new String[] { numeroSecuenciaProveedor, presBiser11AsString}));

			}
		}

		if(casilla79Seleccionada){
			if(!SunatNumberUtils.isGreaterThanZero(vDerLicen16)){
				//glazaror... evitamos el uso de catalogoHelper.getErrorMap
				//errores.add( getCatalogoHelper().getErrorMap("30615", new Object[]{dav.getNumsecuprov(),vDerLicen16 } ) );

				//glazaror... hacemos uso de catalogoAyudaService.getError
				String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
				String vDerLicen16AsString = (vDerLicen16 != null) ? vDerLicen16.toString() : " ";
				errores.add(catalogoAyudaService.getError("30615", new String[] { numeroSecuenciaProveedor, vDerLicen16AsString}));

			}
		}

		if(casilla710Seleccionada){
			if(!SunatNumberUtils.isGreaterThanZero(prodReven17)) {
				//glazaror... evitamos el uso de catalogoHelper.getErrorMap
				//errores.add( getCatalogoHelper().getErrorMap("30616", new Object[]{dav.getNumsecuprov(),prodReven17} ) );

				//glazaror... hacemos uso de catalogoAyudaService.getError
				String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
				String prodReven17AsString = (prodReven17 != null) ? prodReven17.toString() : " ";
				errores.add(catalogoAyudaService.getError("30616", new String[] { numeroSecuenciaProveedor, prodReven17AsString}));
			}

		}

		return errores;
	}

	/**
	 * Se valida que cuando se transmita en alguna de las series del formato A de la DUA, 
        el r�gimen precedente 91 y las mercanc�as correspondan a veh�culos usados 
        (estado de la mercanc�a: 20, 21, 22, 23, 24, 25, 26, 27, 28), 
        se debe consignar obligatoriamente como pa�s de embarque el c�digo 1B correspondiente a Zona Franca del Per�. 
        En caso contrario (Ver F10).
	 * @param serie
	 * @ERRORES 30666
	 * @TRANSACCION XX01
	 * @return
	 */
	//GGRANADOS FORMB
	public List<Map<String, String>> validarAutoUsadoRegimenPrecedente(DatoSerie serie){
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();

		Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

		if(declaracion.isExoneradoFB()){
			return result;
		}

		boolean tieneRegPrecCetico = correspondeARegPrecCetico(serie);	    

		if(tieneRegPrecCetico && esAutoUsado(serie)){
			List<DatoItem> listItemsXSerie = FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie);
			for (DatoItem datoItem : listItemsXSerie) {
				DatoFactura factura = (DatoFactura)datoItem.getPadre();
				if(!factura.getCodpaisembar().equals(Constants.COD_PAIS_ZONA_FRANCA)){
					result.add(getErrorMap("30666",
							new Object[] { 
									((DAV)factura.getPadre()).getNumsecuprov(),
									factura.getNumsecfactu(), 
									factura.getCodpaisembar()}));
				}
			}
		}

		return result;

	}

	private boolean correspondeARegPrecCetico(DatoSerie serie){
		if (serie.getListRegPrecedencia()!=null && serie.getListRegPrecedencia().size()>0){//PAS20165E220200059-INC 2016-053883
			Elementos<DatoRegPrecedencia> lstRegPrec = serie.getListRegPrecedencia();
			for (DatoRegPrecedencia datoRegPrecedencia : lstRegPrec) {
				if(datoRegPrecedencia.getCodregipre().equals(Constants.REGIMEN_91)){
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Validar que si la DUA no cuenta con formato B, no lo este transmitiendo por primera vez en la rectificaci�n	
	 * @param declaracion 
	 * @TRANSACCION XX03
	 * @return list
	 */	

	public List<Map<String, String>> validarNoEnviaFBPrimeraVez (Declaracion declaracion, Map<String,Object> variablesIngreso ) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		List<Map<String, String>> errores = new ArrayList<Map<String,String>>();


		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
		String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
		String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
		String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
		String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;

		//Verificar si tiene formato B registrado
		//		Declaracion declaracionDB = FormatoBServiceImpl.getInstance().getDeclaracionService()
		//	    		.getDeclaracionResumida(codaduanaref, SunatNumberUtils.toInteger(numcorreref),SunatNumberUtils.toInteger(annprese),codregimenref);
		GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
		Declaracion declaracionDB = getDeclaracionService.getDeclaracionResumida(codaduanaref, SunatNumberUtils.toInteger(numcorreref),SunatNumberUtils.toInteger(annprese),codregimenref);
		variablesIngreso.put("declaracionDB", declaracionDB);
		//Si no tiene formato B, en la recti no debe transmitirlo por primera vez.
		if (CollectionUtils.isEmpty(declaracionDB.getListDAVs())) {
			if (!CollectionUtils.isEmpty(declaracion.getListDAVs())) {
				errores.add(catalogoAyudaService.getError("30746"));
				errores.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
			}
		}

		return errores;

	}

	/**
	 * Valida que si tiene transmisi�n diferida del envio del formato B y
	 * a�n no lo ha realizado, no debe variar los datos que le dan esa condici�n. 
	 * no debe varias los datos que le dan esa condici�n.
	 * @param declaracion 
	 * @TRANSACCION XX03
	 * @return list
	 */	

	public List<Map<String, String>> verificarCondicionesEnvioDiferido (Declaracion declaracion, Map<String,Object> variablesIngreso) {

		List<Map<String, String>> errores = new ArrayList<Map<String,String>>();		

		Declaracion declaracionDB = (Declaracion) variablesIngreso.get("declaracionDB");	    

		//amancilla PAS20155E220200035 las dfiligencia esta vacio
		if(declaracionDB==null && "1019".equals(declaracion.getCodtipotrans())){
			NumdeclRef numdeclRef = declaracion.getNumdeclRef();
			String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
			String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
			String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
			String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;
			GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
			declaracionDB = getDeclaracionService.getDeclaracionResumida(codaduanaref, SunatNumberUtils.toInteger(numcorreref),SunatNumberUtils.toInteger(annprese),codregimenref);

			variablesIngreso.put("declaracionDB", declaracionDB);
		}//fin amancilla

		if(!CollectionUtils.isEmpty(declaracionDB.getListDAVs())){
			return errores;
		}
		boolean tieneFormatoBDiferido = tieneEnvioFormatoBDiferido(declaracionDB.getDua());
		boolean tieneFormatoBDiferidoRecti = tieneEnvioFormatoBDiferido(declaracion.getDua());

		if (tieneFormatoBDiferido){
			if (!tieneFormatoBDiferidoRecti){
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				errores.add(catalogoAyudaService.getError("30748"));
				errores.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
			}
		}

		return errores;

	}	

	/**
	 * Si tiene transmisi�n exceptuada del envio del formato B y a�n no lo ha realizado,
	 * no debe varias los datos que le dan esa condici�n.
	 * @param declaracion 
	 * @TRANSACCION XX03,XX05
	 * @return list
	 */	

	public List<Map<String, String>> verificarCondicionesEnvioExonerado (Declaracion declaracion , Date fechaReferencia, Map<String,Object> variablesIngreso ) {

		List<Map<String, String>> errores = new ArrayList<Map<String,String>>();

		Declaracion declaracionDB = (Declaracion) variablesIngreso.get("declaracionDB");

		//amancilla PAS20155E220200035 las dfiligencia esta vacio
		if(declaracionDB==null && "1019".equals(declaracion.getCodtipotrans())){
			NumdeclRef numdeclRef = declaracion.getNumdeclRef();
			String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
			String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
			String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
			String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;		
			GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
			declaracionDB = getDeclaracionService.getDeclaracionResumida(codaduanaref, SunatNumberUtils.toInteger(numcorreref),SunatNumberUtils.toInteger(annprese),codregimenref);

			variablesIngreso.put("declaracionDB", declaracionDB);
		}//fin amancilla

		if(!CollectionUtils.isEmpty(declaracionDB.getListDAVs())){
			return errores;
		}
		boolean tieneFormatoBExonerado = tieneEnvioFormatoBExonerado(declaracionDB.getDua(), fechaReferencia);
		boolean tieneFormatoBExoneradoRecti = tieneEnvioFormatoBExonerado(declaracion.getDua(), fechaReferencia);

		if (tieneFormatoBExonerado)		
		{  if (!tieneFormatoBExoneradoRecti){
			CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			errores.add(catalogoAyudaService.getError("30743"));
			errores.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
		}else{
			declaracion.setExoneradoFB(true);
		}

		}

		return errores;


	}

	/**
	 * Validar que si la dua tiene transmisi�n diferida y a�n no lo haya realizado el envio del formato B,
	 * en la rectificaci�n no debe transmitir series que correspondan a vehiculos usados.
	 * @param declaracion 
	 * @TRANSACCION XX03
	 * @return list
	 */	
	public List<Map<String, String>> validarNoEnviaVehiUsados(Declaracion declaracion, Map<String,Object> variablesIngreso){		
		List<Map<String, String>> errores = new ArrayList<Map<String,String>>();

		Declaracion declaracionDB = (Declaracion) variablesIngreso.get("declaracionDB");	

		//amancilla PAS20155E220200035 las dfiligencia esta vacio
		if(declaracionDB==null && "1019".equals(declaracion.getCodtipotrans())){
			NumdeclRef numdeclRef = declaracion.getNumdeclRef();
			String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
			String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
			String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
			String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;
			GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
			declaracionDB = getDeclaracionService.getDeclaracionResumida(codaduanaref, SunatNumberUtils.toInteger(numcorreref),SunatNumberUtils.toInteger(annprese),codregimenref);

			variablesIngreso.put("declaracionDB", declaracionDB);
		}//fin amancilla

		if (CollectionUtils.isEmpty(declaracionDB.getListDAVs())){
			if (tieneEnvioFormatoBDiferido(declaracion.getDua())){
				for (DatoSerie serie : declaracion.getDua().getListSeries()){
					if (esAutoUsado(serie)){
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						errores.add(catalogoAyudaService.getError("30747"));
						errores.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
						return errores;
					}

				}
			}
		}

		return errores;

	}

	/**
	 * Validar que si la dua tiene transmisi�n diferida y a�n no lo haya realizado el envio del formato B,
	 * en la rectificaci�n no debe transmitir series que correspondan a vehiculos usados.
	 * @param declaracion, fechaReferencia
	 * @TRANSACCION XX03
	 * @return list
	 */		
	public List<Map<String, String>> validarPuedeRectificarFA(Declaracion declaracion, Map<String,Object> variablesIngreso){		
		List<Map<String, String>> errores = new ArrayList<Map<String,String>>();	    		
		Declaracion declaracionDB = (Declaracion) variablesIngreso.get("declaracionDB");	

		//amancilla PAS20155E220200035 las dfiligencia esta vacio
		if(declaracionDB==null && "1019".equals(declaracion.getCodtipotrans())){
			NumdeclRef numdeclRef = declaracion.getNumdeclRef();
			String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
			String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
			String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
			String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;
			GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
			declaracionDB = getDeclaracionService.getDeclaracionResumida(codaduanaref, SunatNumberUtils.toInteger(numcorreref),SunatNumberUtils.toInteger(annprese),codregimenref);

			variablesIngreso.put("declaracionDB", declaracionDB);
		}//fin amancilla

		if (CollectionUtils.isEmpty(declaracionDB.getListDAVs())){
			if (tieneEnvioFormatoBDiferido(declaracion.getDua())){
				if(!tienePlazoEnvioDiferidoFB(declaracion)){
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					errores.add(catalogoAyudaService.getError("30744"));
					errores.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());

				}else{
					declaracion.setExoneradoFB(true);
				}
			}
		}

		return errores;

	}

	/**
	 * Verifica si esta dentro del plazo para realizar el envio complementario del formato B.
	 * @param serie
	 * @TRANSACCION XX03
	 * @return boolean
	 */	
	private boolean tienePlazoEnvioDiferidoFB (Declaracion declaracion) {
		//Si la dua tiene canal rojo o naranja
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		if (SunatStringUtils.isEmpty(declaracion.getDua().getCodCanal()))
		{	return true; }

		if ((declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_NARANJA)) || (declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_ROJO)))
		{
			//si la fecha es diferente a 01/01/0001 (ha sido recepcionada) 
			if (!SunatDateUtils.isDefaultDate(declaracion.getDua().getFecRecep())){
				return false;
			}
		}

		//canal verde 
		if (declaracion.getDua().getCodCanal().equals(ConstantesDataCatalogo.COD_CANAL_VERDE))
		{
			//verde regularizable
			if(funcionesService.esDuaRegularizable(declaracion.getDua().getNumcorredoc())){
				if(funcionesService.tieneTransmisionDeRegularizacion(
						declaracion.getDua().getNumcorredoc(),
						ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT,
						null)){
					return false;
				}
			}else  {
				//verde no regularizable
				Manifiesto manifiesto =  funcionesService.obtenerManifiestoDeDua(declaracion);			    
				Integer iFechaMas15dias = SunatDateUtils.getIntegerFromDate(SunatDateUtils.addDay(manifiesto.getFechaTerminoDeDescarga(), 15));
				Integer iFechaActual= SunatDateUtils.getIntegerFromDate(SunatDateUtils.getCurrentDate());				
				if( iFechaActual > iFechaMas15dias)
				{
					return false;
				}
			}
		}

		return true;    
	}

	/**
	 * Validar que si la DUA no cuenta con formato B, no lo este transmitiendo por primera vez en la rectificaci�n.
	 * @param declaracion, fechaReferencia
	 * @TRANSACCION XX04
	 * @return list
	 */	

	public List<Map<String, String>> validarEnvioFBRegu(Declaracion declaracion)
	{

		List<Map<String, String>> errores = new ArrayList<Map<String,String>>();	    
		NumdeclRef numdeclRef = declaracion.getNumdeclRef();
		String codaduanaref = numdeclRef != null ? numdeclRef.getCodaduana(): null;
		String codregimenref = numdeclRef != null ? numdeclRef.getCodregimen(): null;
		String numcorreref = numdeclRef != null ? numdeclRef.getNumcorre(): null;
		String annprese = numdeclRef != null ? numdeclRef.getAnnprese() : null;		

		//		 Declaracion declaracionDB = FormatoBServiceImpl.getInstance().getDeclaracionService()
		//		    		.getDeclaracionResumida(codaduanaref, SunatNumberUtils.toInteger(numcorreref),SunatNumberUtils.toInteger(annprese),codregimenref);
		GetDeclaracionService getDeclaracionService = (GetDeclaracionService)fabricaDeServicios.getService("declaracionService");
		Declaracion declaracionDB = getDeclaracionService.getDeclaracionResumida(codaduanaref, SunatNumberUtils.toInteger(numcorreref),SunatNumberUtils.toInteger(annprese),codregimenref);
		if(!tieneEnvioFormatoBExonerado(declaracionDB.getDua(), declaracion.getDua().getFecNumeracion()))
		{
			if(CollectionUtils.isEmpty(declaracionDB.getListDAVs())){
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				errores.add(catalogoAyudaService.getError("30745"));
				errores.add(ResponseMapManager.getErrorResponseMapFinalizarProceso());
			}		  
		}
		else{		
			if(CollectionUtils.isEmpty(declaracionDB.getListDAVs())){
				declaracion.setExoneradoFB(true);
			}
		}


		return errores;

	}	

	/*
    public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}*/
	//fin pase270
	/**
	 * Realiza la validacion del envio del formato B
	 * @param declaracion
	 * @return
	 */


	public List<Map<String, String>> validarPersonaDeclFormatoB (Participante personaDecl,Declaracion declaracion,String codTransaccion)
	{
		ValDeclaranteFB valDeclaranteFB =   fabricaDeServicios.getService("ValDeclaranteFB");
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();		
		//		ValDeclaranteFB valParticipante = new ValDeclaranteFB();		
		//		valParticipante.setCatalogoHelper( getCatalogoHelper() );
		//		valParticipante.setFormatoBService(getFormatoBService() );
		//		valParticipante.setFuncionesService( getFuncionesService() );

		if(personaDecl!=null){		
			Participante partic=personaDecl;
			DataCatalogo  tipoDocumentoIdentidad= partic!=null?partic.getTipoDocumentoIdentidad():null;
			String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
			String numeroDocumentoIdentidad=partic!=null?partic.getNumeroDocumentoIdentidad():null;
			String nombreRazonSocial=partic!=null?partic.getNombreRazonSocial():null;
			Date fecha_referencia=null;	

			if (codTransaccion.equals(ConstantesDataCatalogo.TRANS_NUMERACION_IMPORTACION_DEFINITIVA) ||
					codTransaccion.equals(ConstantesDataCatalogo.TRANS_NUMERACION_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO) ||
					codTransaccion.equals(ConstantesDataCatalogo.TRANS_NUMERACION_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO)){			  
				fecha_referencia = new Date();			  
			}else{
				fecha_referencia=declaracion.getDua().getFecdeclaracion();
			}			
			result.add(valDeclaranteFB.codTipDocParticipanteDecl(codTipoDocumento));

			log.info("valDeclaranteFB.codTipDocParticipanteDecl(codTipoDocumento).isEmpty() = "+valDeclaranteFB.codTipDocParticipanteDecl(codTipoDocumento).isEmpty());
			log.info("valDeclaranteFB.codTipDocParticipanteDecl(codTipoDocumento).size() = "+valDeclaranteFB.codTipDocParticipanteDecl(codTipoDocumento).size());

			if( valDeclaranteFB.codTipDocParticipanteDecl(codTipoDocumento).isEmpty() && 
					valDeclaranteFB.codTipDocParticipanteDecl(codTipoDocumento).size()==0){			 
				if(codTipoDocumento.equals(ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI)){				  
					result.add(valDeclaranteFB.formatoTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad));	
					log.info("valDeclaranteFB.formatoTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad) = "+valDeclaranteFB.formatoTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad).isEmpty());
					log.info("valDeclaranteFB.formatoTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad) = "+valDeclaranteFB.formatoTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad).size());
					if(valDeclaranteFB.formatoTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad).isEmpty() &&
							valDeclaranteFB.formatoTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad).size()==0){ 
						result.add(valDeclaranteFB.existenciaTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad));
						if(valDeclaranteFB.existenciaTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad).isEmpty() &&
								valDeclaranteFB.existenciaTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad).size()==0){
							result.add(valDeclaranteFB.vigenciaTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad,fecha_referencia));
							if(valDeclaranteFB.vigenciaTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad,fecha_referencia).isEmpty() &&
									valDeclaranteFB.vigenciaTipoDocumento(codTipoDocumento,numeroDocumentoIdentidad,fecha_referencia).size()==0	   
									){
								result.add(valDeclaranteFB.edadPersonaDecl(codTipoDocumento,numeroDocumentoIdentidad,fecha_referencia) );
								if(valDeclaranteFB.edadPersonaDecl(codTipoDocumento,numeroDocumentoIdentidad,fecha_referencia).isEmpty() &&
										valDeclaranteFB.edadPersonaDecl(codTipoDocumento,numeroDocumentoIdentidad,fecha_referencia).size()==0	   
										){
									result.add(valDeclaranteFB.validarNombrePersonaDecl(codTipoDocumento,numeroDocumentoIdentidad,nombreRazonSocial)); 
								}							   	
							}

						}				   
					}	  	  
				}
			}

		}
		return result;

	}	
	

	@ServicioAnnot(tipo = "V", codServicio = 3498, descServicio = "Valida la resoluci�n de la declaracion de valor")
	@Override
	public List<Map<String, String>> validarResolucion (DAV dav, Date fechaReferencia){
		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>();
		if(!CollectionUtils.isEmpty(dav.getListDocumentoSoporteFormatoB())){
			for(DocumentoSoporteFormatoB docSoporteB : dav.getListDocumentoSoporteFormatoB()) {
				if(docSoporteB.getTipoDocumento() != null && docSoporteB.getTipoDocumento().equals("998") && !SunatStringUtils.isEmpty(docSoporteB.getCodResolucion())) {
					boolean esTipoResolucionValida = CollectionUtils.isEmpty(
							((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).
							validarElementoCat("146", docSoporteB.getCodResolucion(), fechaReferencia));
					if(!esTipoResolucionValida) {
						lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
								"37085",new String[] {dav.getNumsecuprov().toString(), docSoporteB.getCodResolucion()}));
					}
					
					if(SunatStringUtils.isEmpty(docSoporteB.getNumResolucion()) || docSoporteB.getFechaResolucion() == null) {
						lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
								"37086",new String[] {dav.getNumsecuprov().toString()}));
					}
					
					if(docSoporteB.getCodResolucion().equals("04") && SunatStringUtils.isEmpty(docSoporteB.getDesResolucion())) {
						lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
								"37087",new String[] {dav.getNumsecuprov().toString()}));
					}
					
					break;
				}
			}				
		}
		return lstErrores;
	}
	
	public List<Map<String, String>> validarMedioPago (DAV dav, Date fechaReferencia){
		return validarMedioPago (dav, fechaReferencia, null);
	}
	
	/*
	 * 
	 * 	10.	Si no env�a c�digo de medio de pago ir a F10.
		11.	Si env�a un c�digo de medio de pago que no exista en la tabla ir a F11.
		12.	Si env�a un c�digo de entidad financiera que no exista en la tabla ir a F12.
		13.	Si env�a un c�digo de medio de pago diferente a 01 (Efectivo) y 14 (Otros) y no env�a el c�digo de la entidad financiera y la identificaci�n del medio de pago ir a F13.
		14.	Si env�a el c�digo de medio de pago 14 (Otros) y no env�a su descripci�n ir a F14.
		15.	Si env�a el c�digo de entidad financiera 99 (Otros) y no env�a su descripci�n ir a F15.
		16.	Si env�a descripci�n del medio de pago mayor a 40 caracteres ir a F16.
		17.	Si env�a descripci�n de la entidad financiera mayor a 40 caracteres ir a F17.
		18. Si env�a medio de pago 1 o 14 entonces no debe declarar la entidad financiera y ni la identificaci�n del medio de pago. Sino F27. PAS20181U220500202
		19. Se coloca vigencia en funsion al regimen - PAS20191U220500086
	 * 
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3499, descServicio = "Valida el medio de pago de la declaracion de valor")
	@Override
	public List<Map<String, String>> validarMedioPago (DAV dav, Date fechaReferencia, Declaracion declaracion){
		List<Map<String,String>> lstErrores=  new ArrayList<Map<String,String>>();
		boolean enviaMedioPago = false;
		Date fechaVigencia = null;
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if (declaracion == null) {
			fechaVigencia = SunatDateUtils.getDateFromInteger(20190715); // Por defecto vigencia de los reg�menes 20 y 21
		} else {
			String lcCodi_regi = declaracion.getDua().getCodregimen()==null?(declaracion.getCodregimen()==null?declaracion.getNumdeclRef().getCodregimen():declaracion.getCodregimen()):declaracion.getDua().getCodregimen();
			if (lcCodi_regi!=null)
			fechaVigencia = (Date) catalogoAyudaService.getElementoCat(Constantes.CATALOGO_CONTROL_CAMBIO, lcCodi_regi.concat("MP")).get("fec_inidatcat");
		}
		
		if (fechaVigencia!=null && SunatDateUtils.esFecha1MayorIgualQueFecha2(fechaReferencia, fechaVigencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
			if(!CollectionUtils.isEmpty(dav.getListDocumentoSoporteFormatoB())){
				for(DocumentoSoporteFormatoB docSoporteB : dav.getListDocumentoSoporteFormatoB()) {
					if(docSoporteB.getTipoDocumento() != null && docSoporteB.getCodMedioPago() != null && 
							docSoporteB.getTipoDocumento().equals("450")) {
						enviaMedioPago = true;
						//JCV Se cambia forma de validar
						/*
						boolean esMedioPagoValido = CollectionUtils.isEmpty(
								((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).
								validarElementoCat("147", docSoporteB.getCodMedioPago(), fechaReferencia));
						*/
						boolean esMedioPagoValido = ((AyudaServiceDataCatalogo)fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo")).
										getElementoActual("147", docSoporteB.getCodMedioPago(), fechaReferencia) != null;
						
						if(!esMedioPagoValido) {
							lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
									"37089",new String[] {dav.getNumsecuprov().toString(), docSoporteB.getCodMedioPago()}));
						}
						
						if(docSoporteB.getCodMedioPago().equals("14") && SunatStringUtils.isEmpty(docSoporteB.getDesMedioPago())) {
							lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
									"37092",new String[] {dav.getNumsecuprov().toString()}));
						}
						
						if(!SunatStringUtils.isStringInList(docSoporteB.getCodMedioPago(), "01", "14")) {
							if(esMedioPagoValido && (SunatStringUtils.isEmpty(docSoporteB.getCodEntidadFinanciera()) || 
									SunatStringUtils.isEmpty(docSoporteB.getCodIdentPago()))) {
								lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
										"37091",new String[] {dav.getNumsecuprov().toString(), docSoporteB.getCodMedioPago()}));
							}
							
						}
						
						// PAS20181U220500202 - JCV 20181126 - Cuando declara medio de paso 01 o 14
						Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0053", fechaReferencia);
						if(!CollectionUtils.isEmpty(MapaValManNum) && SunatStringUtils.isStringInList(docSoporteB.getCodMedioPago(), "01", "14")) {
							if((docSoporteB.getCodEntidadFinanciera()!=null && !SunatStringUtils.isEmpty(docSoporteB.getCodEntidadFinanciera().trim())) ||
								(docSoporteB.getCodIdentPago()!=null && !SunatStringUtils.isEmpty(docSoporteB.getCodIdentPago().trim()))) {
								lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
										"37194",new String[] {dav.getNumsecuprov().toString(), docSoporteB.getCodMedioPago()}));
							}
						} else {
							if(docSoporteB.getCodEntidadFinanciera()!=null && !SunatStringUtils.isEmpty(docSoporteB.getCodEntidadFinanciera().trim())) {
								//JCV Se cambia forma de validar
								/*boolean esEntidadFinancieraValida = CollectionUtils.isEmpty(
										((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).
										validarElementoCat("148", docSoporteB.getCodEntidadFinanciera(), fechaReferencia));*/
								boolean esEntidadFinancieraValida = ((AyudaServiceDataCatalogo)fabricaDeServicios.getService("Ayuda.ayudaServiceDataCatalogo")).
										getElementoActual("148", docSoporteB.getCodEntidadFinanciera(), fechaReferencia) != null;
								
								if(!esEntidadFinancieraValida) {
									lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
											"37090",new String[] {dav.getNumsecuprov().toString(), docSoporteB.getCodEntidadFinanciera()}));
								}
								
								if(docSoporteB.getCodEntidadFinanciera().equals("99") && SunatStringUtils.isEmpty(docSoporteB.getDesEntidadFinanciera())) {
									lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
											"37093",new String[] {dav.getNumsecuprov().toString()}));
								}
							}
						}
						break;					
					}
					
				}
			}
			
			if(!enviaMedioPago) {
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
						"37088",new String[] {dav.getNumsecuprov().toString()}));
			}	
		}	
		
		return lstErrores;
	}
	
	/*
	 * 	18.	De no enviar esta informaci�n ir a F18.
		19.	Si el valor enviado supera los 60 caracteres ir a F19.
	 * 
	 */
	@ServicioAnnot(tipo = "V", codServicio = 3500, descServicio = "Valida el representante legal del declarante - declaracion de valor")
	@Override
	public Map<String, String> validarRepresentateLegal(DAV dav) {
		Map<String, String> result = new HashMap<String, String>();
		if (dav.getRepresentanteLegal() == null || dav.getRepresentanteLegal().getNombreRazonSocial() == null) {
			result =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(
					"37096",new String[] {dav.getNumsecuprov().toString()});
		}
		return result;
	}
	/*
	public ValFactSuc getValFactSuc() {
		return valFactSuc;
	}

	public void setValFactSuc(ValFactSuc valFactSuc) {
		this.valFactSuc = valFactSuc;
	}*/
}