package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilFibra;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;


/**
 * 
 * @author lalberti
 * 
 */

public class ValidadorTextilFibra extends ValidadorTextilAbstract
{

    private static List<String> unComSet = new ArrayList<String>(Arrays.asList("KG", "LB"));
    private static String codErrorUnidadComercial = "31300";
    public ValidadorTextilFibra()
    {
        super();
        //unComSet.add("KG");
        //unComSet.add("LB");
       // ValidadorTextilAbstract.getErrors().put("codUnComErr", "31300");
        // TODO Auto-generated constructor stub
    }

    @Override
    public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract object, Declaracion dua) throws Exception
    {
        List<ErrorDescrMinima> lstErrores = validarEstructura(object);
        //DatoItem item  = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
        // lstErrores.addAll(validarEstructura(object));
        if (CollectionUtils.isEmpty(lstErrores))
        {

            DatoItem item = obtenerItem(object, dua);

            lstErrores.addAll(this.validarUnidadComercial(object, item, unComSet,codErrorUnidadComercial));
            lstErrores.addAll(this.validarFOBVsPesoObs(object, dua));
            lstErrores.addAll(this.validarSumaPorcentaje(object));
    }
    return lstErrores;
  }

  public List<ErrorDescrMinima> validarCompoFibra1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoFibraPorcen1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoFibra2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoFibraPorcen2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarPresentacion(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima>validarTipoFibra(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarSumaPorcentaje(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    TextilFibra fibra = (TextilFibra) object;
    Integer p1 = 0;
    Integer p2 = 0;
    try{
      p1 = fibra.getCompoFibraPorcen1erComp()!= null &&
    		  !SunatStringUtils.isEmptyTrim(fibra.getCompoFibraPorcen1erComp().getValtipdescri())?
    	              Integer.parseInt(fibra.getCompoFibraPorcen1erComp().getValtipdescri()):0;
      p2 = fibra.getCompoFibraPorcen2doComp()!= null &&
    		  !SunatStringUtils.isEmptyTrim(fibra.getCompoFibraPorcen2doComp().getValtipdescri())?
              Integer.parseInt(fibra.getCompoFibraPorcen2doComp().getValtipdescri()):0;
    }catch(NumberFormatException e){}
    if((p1 + p2)!=100){
      //Consultar como hacer para que el mensaje salga con los datos correctos
      Integer s = p1+p2;
      DatoDescrMinima suma = fibra.getCompoFibraPorcen1erComp();
      suma.setValtipdescri(s.toString());
      lst.add(obtenerError("31319", suma));
    }
    return lst;
  }

  public List<ErrorDescrMinima> validarEstructuraFisica(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarClaseYUso(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }
}
