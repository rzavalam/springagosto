package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.ayudas.service.FeriadoService;
import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValNegocNumeracFormAServiceImpl;
import pe.gob.sunat.despaduanero2.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.Liquida;
import pe.gob.sunat.recauda2.genadeudo.model.dao.PatgGeneraLcNpdaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NabandinDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.AdualibDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.SoporteService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.util.Utilidades;
import pe.gob.sunat.despaduanero2.diligencia.ingreso.service.DiligenciaService;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.recauda2.genadeudo.service.GarantiaOperativaService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoConsumoService;
import pe.gob.sunat.recauda2.ctrlpago.service.BancosService;

/**
 * Clase que contiene los metodos para las validaciones de una declaracion acogida a PECO-Amazonia
 * @author lsotor
 *
 */
public class PecoAmazoniaServiceImpl extends IngresoAbstractServiceImpl implements PecoAmazoniaService {
	//private FabricaDeServicios	fabricaDeServicios;
	//private CatalogoValidaService catalogoValidaService;
	//private AyudaService ayudaService;
	//private CabDiligenciaDAO cabdiligenciaDAO;	
	//private Log log = LogFactory.getLog(ValNegocNumeracFormAServiceImpl.class);

//INICIO RIN08-Codigos de rechazo RIN 08 PECO-Amazonia	
	public final static String ERR_LEY_PECO_REGIMEN 				= "35150"; //Error Ley PECO Regimen	
	public final static String ERR_LEY_PECO_AM_ADUANA_INGRESO 		= "35151"; //Error Ley PECO aduana ingreso	
	public final static String ERR_LEY_PECO_ADUANA_DESTINO 			= "35152"; //Error Ley PECO aduana destino	
	public final static String ERR_LEY_AMAZONIA_ADUANA_DESTINO 		= "35469"; //Error Ley PECO aduana destino	
	public final static String ERR_ADUANA_DESTINO 					= "35470"; //Error Ley PECO aduana destino
	public final static String ERR_LEY_PECO_SUBPARTIDA_ARANCELARIA 	= "35240"; //Error  Ley PECO por validacin de subpartida arancelaria	
	public final static String ERR_LEY_PECO_CORRELACION 			= "35241"; //Error Ley PECO por correlacin entre subpartidas	
	public final static String ERR_LEY_PECO_CONVENIO_PECO_AMAZONIA 	= "35471"; //Error Ley PECO por correlacin entre subpartidas	
	public final static String ERR_LEY_PECO_INF_COMPLEMENTARIA 		= "35246"; //Error Ley PECO por informacin complementaria	
	public final static String ERR_LEY_PECO_UBIGEO_AMAZONIA 		= "35247"; //Error Ley Amazona por ubigeo incorrecto
	public final static String ERR_LEY_AMAZONIA_UBIGEO_DESTINO 		= "35580"; //Error Ley Amazona por ubigeo-destino incorrecto PAS201830001100015
	
	//Error en la Regularizacion
	public final static String ERR_REGU_INCORP_MODIF_TPI       		= "35248";
	public final static String ERR_REGU_INCORP_MODIF_NABANDINA 		= "35249";  //20150222 - Error en nabandina
	public final static String ERR_REGU_INCORP_MODIF_ADU_DEST  		= "35250";
	public final static String ERR_REGU_INCORP_MODIF_COD_LIBER 		= "35472";	
	public final static String ERR_REGU_INCORP_MODIF_NANDINA   		= "35481";  //20150222 - Error en nandina
	//Error en la Rectificacion Previa Evaluacion
	public final static String ERR_RECTI_INCORP_ADU_DEST  			= "35473";
	public final static String ERR_RECTI_INCORP_TPI       			= "35474";
	public final static String ERR_RECTI_INCORP_PARTIDA   			= "35475";
	public final static String ERR_RECTI_INCORP_COD_LIBER 			= "35476";
	
	//Error en la Rectificacion con Levante
	public final static String ERR_RECTI_LEVANTE_INCORP_ADU_DEST  	= "32019";
	public final static String ERR_RECTI_LEVANTE_INCORP_TPI       	= "32020";
	public final static String ERR_RECTI_LEVANTE_INCORP_PARTIDA   	= "32021";
	public final static String ERR_RECTI_LEVANTE_INCORP_COD_LIBER 	= "32022";
	
	//Error en la Rectificacion posterior a la Diligencia
	public final static String ERR_RECTI_MODIF_TPI        			= "35477";
	public final static String ERR_RECTI_MODIF_COD_LIBER  			= "35478";
	public final static String ERR_RECTI_MODIF_PARTIDA    			= "35479";
	public final static String ERR_RECTI_MODIF_ADU_DEST   			= "35480";
	//Error en la Rectificacion posterior a la Diligencia
	public final static String ERR_CONCLU_INCORP_MODIF_TPI 			= "31926";
	public final static String ERR_CONCLU_INCORP_MODIF_COD_LIBER	= "31929";
	public final static String ERR_CONCLU_INCORP_MODIF_PARTIDA 		= "31927";
	public final static String ERR_CONCLU_INCORP_MODIF_ADU_DEST		= "31928";
	
	//PAS201830001100016 - mtorralba 20181106 - INICIO
	public final static String ERR_INDICADOR_ACOGIMIENTO_POSTERIOR	  = "37094";
	public final static String ERR_EXCEDE_PLAZO_ACOGIMIENTO_POSTERIOR = "37095";
	public final static String ERR_TIENE_DESISTIMIENTO_PECOAMAZONIA	  = "37097";
	public final static String ERR_TIENE_DILIGENCIA_EN_DESTINO	      = "37189";
	public final static String ERR_INDICADOR_DESISTIMIENTO_BENEFICIO  = "37191";
	public final static String ERR_NO_DEBE_ENVIAR_INDICADOR           = "32059";
	public final static String ERR_NO_HA_RETIRADO_TODOS_LOS_DATOS     = "32060";
	public final static String COD_TIPODILIG_DILIGENCIA_EN_DESTINO = "22";
	//PAS201830001100016 - mtorralba 20181106 - FINAL
	
//FIN RIN 08 	
	
	public List<Map<String,?>> validacionesPECOAmazonia(Declaracion declaracion, Map<String,Object> variablesIngreso, Declaracion declaracionBD){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("*********** validacionesPECOAmazonia ********");	
			
		Map<Integer,Object> mapaSerieDUA = esPECOAmazonia(declaracion);
		String esPecoAmazonia = mapaSerieDUA.get(Integer.valueOf("0")).toString();		
		String codTransaccion = variablesIngreso.get("codTransaccion").toString();
		
		if(ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(esPecoAmazonia)){
			
			//Si no es de peco/amazonia y si es de otro regimen que no sea de importacion definitiva no hace nada
			if(!ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(declaracion.getDua().getCodregimen())){
				return responseListManager.getResponseList();
			}
			
			
			//En caso no corresponda a numeracion verificamos si se acogio en la numeracion 
			if(!ConstantesDataCatalogo.TRANS_NUMERACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)){
				Map<Integer,Object> mapaSerieDUABD = esPECOAmazonia(declaracionBD);
				String esPecoAmazoniaBD = mapaSerieDUABD.get(Integer.valueOf("0")).toString();	
				
				if(ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(esPecoAmazoniaBD)){
					//Si no corresponde acogimiento a PECO-Amazonia no debe incluir la aduana de destino
					responseListManager.addResponseList(validarNoAcogimientoPECOAmazonia(declaracion.getDua().getOtraAduana().getCodopadusal()));
					return responseListManager.getResponseList();
				}
			}
			else{
				//Si no corresponde acogimiento a PECO-Amazonia no debe incluir la aduana de destino
				responseListManager.addResponseList(validarNoAcogimientoPECOAmazonia(declaracion.getDua().getOtraAduana().getCodopadusal()));
				responseListManager.addResponseList(validarIndicadoresPECO(declaracion, codTransaccion));
				return responseListManager.getResponseList();
			}
		}
			
		//Seteamos en variablesIngreso si la declaracion en proceso corresponde a una DUA de PECO-Amazonia.
		variablesIngreso.put("esPecoAmazonia", esPecoAmazonia);		
		
		int nCodTransaccion = Integer.parseInt(codTransaccion);
		switch(nCodTransaccion){
			case 1001: //Validaciones en la Numeracion
					   responseListManager.addResponseList(validacionesNumeracion(declaracion,variablesIngreso,mapaSerieDUA));
					   break;
			case 1003: //Validaciones en la Rectificacion
				       responseListManager.addResponseList(validacionesRectificacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
					   break;
			case 1004: //Validaciones en la Regularizacion
					   responseListManager.addResponseList(validacionesRegularizacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
					   break;
			case 1005: //Validaciones en la Regularizacion URGENTE
				   	   responseListManager.addResponseList(validacionesRegularizacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
				   	   break;
			case 1007: //Validaciones en la Diligencia de Rectificacion
				   	   responseListManager.addResponseList(validacionesRectificacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
				   	   break;
			case 1019: //Validaciones en la Rectificacion de Oficio
				   	   responseListManager.addResponseList(validacionesRectificacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
				   	   break;
			case 1008: //Validaciones en la Diligencia de Regularizacion
				   	   responseListManager.addResponseList(validacionesRegularizacion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
				   	   break;					   
			case 1016: //Validaciones en la Diligencia de Despacho
				   	   responseListManager.addResponseList(validacionesDiligenciaDespacho(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
				   	   break;
			case 1012: //Validaciones en la Diligencia de Conclusion
			   	   	   responseListManager.addResponseList(validacionesConclusion(declaracion,declaracionBD,variablesIngreso,mapaSerieDUA));
			   	   	   break;
			case 2001: //Validaciones en la Numeracion
					   responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
					   break;
			case 2101: //Validaciones en la Numeracion
					   responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
					   break;
			case 7001: //Validaciones en la Numeracion
					   responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
					   break;			
			case 2003: //Validaciones en la Rectificacion
					   responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
					   break;
			case 2103: //Validaciones en la Rectificacion
					   responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
					   break;
			case 7003: //Validaciones en la Rectificacion
					   responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
					   break;
		}
				
		//responseListManager.addErrorFinalizarProceso(); // Se coloca cuando quiero cortar el proceso y que no siga validando
		return responseListManager.getResponseList();
	}
	
	public List<Map<String,?>> validacionesNumeracion(Declaracion declaracion, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("********* validacionesNumeracion **********");
		
		//1. Validamos el Regimen
		responseListManager.addResponseList(validarRegimen(declaracion.getDua().getCodregimen(),mapaSerieDUA,declaracion));
		//2. Validamos la Aduana de Ingreso
		responseListManager.addResponseList(validarAduanaIngreso(declaracion));
		//3. Validamos la Aduana de Destino si es PECO
		responseListManager.addResponseList(validarAduanaDestinoPECO(declaracion,mapaSerieDUA));
		//4. Validamos la Aduana de Destino si es Ley Amazonia
		responseListManager.addResponseList(validarAduanaDestinoCodLiberatorio(declaracion,mapaSerieDUA));
		//5. Validamos la correlacion entre Nandina y Nabandina
		responseListManager.addResponseList(validarCorrelacionNandinaNabandina(declaracion,mapaSerieDUA));
		//6. Validamos Lista de Observaciones
		responseListManager.addResponseList(validarInformacionComplementaria(declaracion,mapaSerieDUA));
		//7. Validamos que transmita las partidas nandina y nabandina
		responseListManager.addResponseList(validarSubpartidaArancelaria(declaracion,mapaSerieDUA));
		//8. Validamos que la partida este dentro del convenio
		responseListManager.addResponseList(validarPartidaConvenioPECOAmazonia(declaracion,mapaSerieDUA));
		//9. Validamos el Ubigeo
		responseListManager.addResponseList(validarUbigeo(declaracion,mapaSerieDUA));
		//10. Validamos que no envie indicadores de Acogimiento Posterior ni de Desistimiento  PAS201830001100016 - mtorralba
		String codTransaccion = variablesIngreso.get("codTransaccion").toString();
		boolean tieneLevante = variablesIngreso.get("tieneLevante")==null ? false : (variablesIngreso.get("tieneLevante").toString().equals("SI") ? true : false );
		if( !tieneLevante ) {
			responseListManager.addResponseList(validarIndicadoresPECO(declaracion, codTransaccion, ""));
		}
		return responseListManager.getResponseList();		
	}	
	
	public List<Map<String,?>> validacionesRectificacion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();
		
		if(log.isDebugEnabled()) log.debug("********* validacionesRectificacion ********** codCanal: [" + codCanal + "]");

		Date fecAutLevante = declaracionBD.getDua().getFecAutlevante()!=null?declaracionBD.getDua().getFecAutlevante():SunatDateUtils.getDefaultDate();
		//if(!StringUtils.hasText(codCanal)){
		if( SunatDateUtils.isDefaultDate(fecAutLevante)) {  //PAS201830001100016 - mtorralba 20181030 - Validaciones PECO antes de Levante
			//1. Validamos lo mismo que en la numeracion
			variablesIngreso.put("tieneLevante", "NO");
			responseListManager.addResponseList(validacionesNumeracion(declaracion, variablesIngreso, mapaSerieDUA));
			//PAS20181U220200069 - mtorralba 20190405 - Verifica desistimiento
			if( esDesistimientoBeneficio(declaracion, declaracionBD) ) {
				if( !verificaRetiroTotal(declaracion.getDua().getOtraAduana().getCodopadusal(), declaracionBD.getDua().getOtraAduana().getCodopadusal(), "AduanaDestino") ||
					!verificaRetiroTotal(declaracion.getDua().getListSeries(), declaracionBD.getDua().getListSeries(), "PartidaNabandina") ) {
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					responseListManager.addResponseMap(catalogoAyudaService.getError(ERR_NO_HA_RETIRADO_TODOS_LOS_DATOS, null));
				}
				return responseListManager.getResponseList();
			}
		}
		else{ //PAS201830001100016 - mtorralba 20181030 - Validaciones PECO despus de Levante
			variablesIngreso.put("tieneLevante", "SI");
			//1. Validamos que no se acoja en la rectificacion
			responseListManager.addResponseList(acogimientoPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA,ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA));
			//2. Validamos que no se modifique/elimine en la rectificacion si ya tiene diligencia
			responseListManager.addResponseList(modificacionPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA,ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA));			
			//3. Validamos lo mismo que en la numeracion
			responseListManager.addResponseList(validacionesNumeracion(declaracion, variablesIngreso, mapaSerieDUA));	
		}
		
		return responseListManager.getResponseList();		
	}
	
	public List<Map<String,?>> validacionesRegularizacion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();
		
		if(log.isDebugEnabled()) log.debug("********* validacionesRegularizacion ********** codCanal: [" + codCanal + "]");
		
		//1. Validamos que no se acoja en la regularizacion
		responseListManager.addResponseList(acogimientoPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA,ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA));
		//2. Validamos que no se modifique/elimine en la regularizacion 
		responseListManager.addResponseList(modificacionPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA,ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA));
		
		return responseListManager.getResponseList();		
	}
		
	public List<Map<String,?>> validacionesDiligenciaDespacho(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();
		
		if(log.isDebugEnabled()) log.debug("********* validacionesDiligenciaDespacho ********** codCanal: [" + codCanal + "]");

		//1. Validamos la Aduana de Ingreso
		responseListManager.addResponseList(validarAduanaIngreso(declaracion));
		//2. Validamos la Aduana de Destino si es PECO
		responseListManager.addResponseList(validarAduanaDestinoPECO(declaracion,mapaSerieDUA));
		//3. Validamos la Aduana de Destino si es Ley Amazonia
		responseListManager.addResponseList(validarAduanaDestinoCodLiberatorio(declaracion,mapaSerieDUA));
		//4. Validamos que transmita las partidas nandina y nabandina
		responseListManager.addResponseList(validarSubpartidaArancelaria(declaracion,mapaSerieDUA));
		//5. Validamos que la partida este dentro del convenio
		responseListManager.addResponseList(validarPartidaConvenioPECOAmazonia(declaracion,mapaSerieDUA));
		//6. Validamos la correlacion entre Nandina y Nabandina
		responseListManager.addResponseList(validarCorrelacionNandinaNabandina(declaracion,mapaSerieDUA));
		
		return responseListManager.getResponseList();
	}
	
	/** 
	 * Validaciones para la Diligencia de Conclusion 
	 */
	public List<Map<String,?>> validacionesConclusion(Declaracion declaracion, Declaracion declaracionBD, Map<String,Object> variablesIngreso, Map<Integer,Object> mapaSerieDUA){
		ResponseListManager responseListManager = new ResponseListManager();
		String codCanal = declaracionBD.getDua().getCodCanal();
		
		if(log.isDebugEnabled()) log.debug("********* validacionesConclusion ********** codCanal: [" + codCanal + "]");
		
		//1. Validamos que no se acoja en la Diligencia Conclusion
		responseListManager.addResponseList(acogimientoPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA, declaracion.getDua().getCodregimen().concat(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)));
		//2. Validamos que no se modifique/elimine en la Diligencia Conclusion
		responseListManager.addResponseList(modificacionPosteriorNumeracion(declaracion,declaracionBD,mapaSerieDUA,declaracion.getDua().getCodregimen().concat(ConstantesDataCatalogo.TRANSACCION_DILIGENCIA_CONCLUSIONDESPACHO_VALIDACION)));			
		
		return responseListManager.getResponseList();		
	}
	
	/**
	 * RIN08 - Permite determinar si una declaracion corresponde a alguno de los convenios PECO y/o Amazona
	 * 0=Ninguno / 1=PECO / 2=AMAZONIA / 3=Ambos
	 */
	public Map<Integer,Object> esPECOAmazonia(Declaracion declaracion){
		Map<Integer,Object> duaPECOAmazonia = new HashMap<Integer,Object>();		
		boolean esPeco = false;
		boolean esAmazonia = false;
		boolean almenosUnaPeco = false;
		boolean almenosUnaAmazonia = false;
		String convInter = "";
				
		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			esPeco = false;
			esAmazonia = false;
			//Verificamos si la serie tiene declarado PECO
			convInter= SunatStringUtils.toStringObj(serie.getCodconvinter());
			
			if(ConstantesDataCatalogo.COD_TIP_34.equals(convInter) || 
					ConstantesDataCatalogo.COD_TIP_35.equals(convInter) || 
					ConstantesDataCatalogo.COD_TIP_36.equals(convInter)){
				esPeco = true;
				almenosUnaPeco = true;
			}
			
			//Verificamos si la serie tiene declarado Ley Amazonia
			if(ConstantesDataCatalogo.COD_LIBERATORIO_AMAZONIA.equals(serie.getCodliberatorio().toString())){
				esAmazonia = true;
				almenosUnaAmazonia = true;
			}
			
			if(esPeco && esAmazonia) duaPECOAmazonia.put(serie.getNumserie(),ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS);
			else 
				if(esPeco) duaPECOAmazonia.put(serie.getNumserie(),ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO);
				else
					if(esAmazonia) duaPECOAmazonia.put(serie.getNumserie(),ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA);
					else
						duaPECOAmazonia.put(serie.getNumserie(),ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO);
		}
		
		//Para CERO se coloca si la DUA en general se acoge a algn beneficio PECO/Amazonia
		if(almenosUnaPeco || almenosUnaAmazonia){
			if(almenosUnaPeco && almenosUnaAmazonia) duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS);
			else 
				if(almenosUnaPeco) duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO);
				else
					if(almenosUnaAmazonia) duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA);
					else
						duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO);
		}
		else{
			duaPECOAmazonia.put(Integer.valueOf("0"),ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO);
		}		
			
		return duaPECOAmazonia;
	}
	
	//PAS201830001100016 - mtorralba 20190204 
	public String esPecoAmazonia(Long numcorredoc) {
		String PecoAmazonia = "0";
		boolean esPeco = false;
		boolean esAmazonia = false;
		Map<String,Object> paramSerie = new HashMap<String,Object>();
		paramSerie.put("NUM_CORREDOC", numcorredoc);
		paramSerie.put("IND_DEL", "0");
		String[] codConvenio = {"4438","  34","  35","  36"};
		paramSerie.put("LIST_COD_CONVENIO",codConvenio);
		
		ConvenioSerieDAO convenioSerieDAO = fabricaDeServicios.getService("diligencia.ingreso.convenioSerieDef");
		List<Map<String,Object>> listaConvenios = convenioSerieDAO.select(paramSerie);
		for(Map<String,Object> mapaConvenio : listaConvenios ) {
			esAmazonia = mapaConvenio.get("COD_CONVENIO").toString().equals("4438") ? true : esAmazonia; 
			esPeco = mapaConvenio.get("COD_CONVENIO").toString().equals("  34") || 
					 mapaConvenio.get("COD_CONVENIO").toString().equals("  35") ||
					 mapaConvenio.get("COD_CONVENIO").toString().equals("  36") ? true : esPeco; 
		}
		
		if(esPeco && esAmazonia) 
			PecoAmazonia = ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS;
		else if(esPeco) 
			PecoAmazonia = ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO;
		else if(esAmazonia) 
			PecoAmazonia = ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA;
		else
			PecoAmazonia = ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO;
		
		return PecoAmazonia;
	}
	
	
	public List<Map<String,?>> validarNoAcogimientoPECOAmazonia(String aduanaDestino){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarNoAcogimientoPECOAmazonia **** ");
				
		if(aduanaDestino != null && !"".equals(aduanaDestino.trim())){
			Map<String, String> listError = new HashMap<String, String>();
			listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_ADUANA_DESTINO, new String[] {aduanaDestino});			
			responseListManager.addResponseMap(listError);			
		}
		
		return responseListManager.getResponseList();
	}	
	
	public List<Map<String,?>> validarRegimen(String codRegimen, Map<Integer,Object> mapa, Declaracion declaracion){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarRegimen ****  codRegimen: " + codRegimen);
		
		if(!ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(codRegimen)){
			for (DatoSerie serie:declaracion.getDua().getListSeries()){
				String preferencia = mapa.get(serie.getNumserie()).toString();
				if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_REGIMEN, new String[] {serie.getNumserie().toString()});
					responseListManager.addResponseMap(listError);
				}
			}
		}
		
		return responseListManager.getResponseList();
	}
	
	public List<Map<String,?>> validarAduanaIngreso(Declaracion declaracion){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarAduanaIngreso ****");
		
		if(!CollectionUtils.isEmpty(catalogoValidaService.validarElementoGrupo(ConstantesGrupoCatalogo.COD_GRP_ADUANAS_INGRESO_PECO_AM, declaracion.getDua().getCodaduanaorden()))){
			Map<String, String> listError = new HashMap<String, String>();
			listError = catalogoAyudaService.getError(ERR_LEY_PECO_AM_ADUANA_INGRESO, new String[] {declaracion.getDua().getCodaduanaorden()});
			responseListManager.addResponseMap(listError);
		}
		
		return responseListManager.getResponseList();
	}
	
	public List<Map<String,?>> validarAduanaDestinoPECO(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();
		
		String aduanaDestino = "";
		
		if(declaracion.getDua().getOtraAduana() != null){
			aduanaDestino = declaracion.getDua().getOtraAduana().getCodopadusal() != null ? declaracion.getDua().getOtraAduana().getCodopadusal() : ""; 
		}
		
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarAduanaDestinoPECO **** destino:" +aduanaDestino);
		
		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			String codConvInter = serie.getCodconvinter().toString();
			
			if(ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO.equals(preferencia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(preferencia)){
				if(ConstantesDataCatalogo.COD_TIP_34.equals(codConvInter) && !"226".equals(aduanaDestino)){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_ADUANA_DESTINO, new String[] {aduanaDestino, serie.getCodconvinter().toString()});
					responseListManager.addResponseMap(listError);
					break;
				}
				if(ConstantesDataCatalogo.COD_TIP_35.equals(codConvInter) && !"217".equals(aduanaDestino)){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_ADUANA_DESTINO, new String[] {aduanaDestino, serie.getCodconvinter().toString()});
					responseListManager.addResponseMap(listError);
					break;
				}
				if(ConstantesDataCatalogo.COD_TIP_36.equals(codConvInter) && !"271".equals(aduanaDestino)){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_ADUANA_DESTINO, new String[] {aduanaDestino, serie.getCodconvinter().toString()});
					responseListManager.addResponseMap(listError);
					break;
				}
			}
		}		
		
		return responseListManager.getResponseList();
	}
	
	public List<Map<String,?>> validarAduanaDestinoCodLiberatorio(Declaracion declaracion, Map<Integer,Object> mapa){
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		ResponseListManager responseListManager = new ResponseListManager();
		
		String aduanaDestino = "";
		
		if(declaracion.getDua().getOtraAduana() != null){
			aduanaDestino = declaracion.getDua().getOtraAduana().getCodopadusal() != null ? declaracion.getDua().getOtraAduana().getCodopadusal() : "" ;
		}
		
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarAduanaDestinoCodLiberatorio **** ");
		
		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			
			if(ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA.equals(preferencia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(preferencia)){
				if("".equals(aduanaDestino) || !CollectionUtils.isEmpty(catalogoValidaService.validarElementoGrupo(ConstantesGrupoCatalogo.COD_GRP_ADUANAS_DEST_LIBERATORIO, aduanaDestino))){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_AMAZONIA_ADUANA_DESTINO, new String[] {aduanaDestino});
					responseListManager.addResponseMap(listError);
					break;
				}
			}
		}
		
		return responseListManager.getResponseList();
	}
	
	public List<Map<String,?>> validarSubpartidaArancelaria(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();
		Long nabandinda = 0L;
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarSubpartidaArancelaria **** ");
		
		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
				//nabandinda = serie.getNumpartnabanAsLong()==null?0L:serie.getNumpartnabanAsLong();
				nabandinda = serie.getNumpartnaban()!=null && !"".equals(serie.getNumpartnaban().trim())?serie.getNumpartnabanAsLong():0L;
				if(serie.getNumpartnandi().compareTo(0L)==0 || nabandinda.compareTo(0L)==0){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_SUBPARTIDA_ARANCELARIA, new String[] {serie.getNumserie().toString()});
					responseListManager.addResponseMap(listError);
				}
			}
		}
		
		return responseListManager.getResponseList();
	}
	
	public List<Map<String,?>> validarCorrelacionNandinaNabandina(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarCorrelacionNandinaNabandina **** ");
		
		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
				HashMap<String, Object> paramsNabandin = new HashMap<String, Object>();
				paramsNabandin.put("nabandi", serie.getNumpartnaban());
				paramsNabandin.put("nandina", serie.getNumpartnandi());				
				
				Integer existeNabandin = ((NabandinDAO)fabricaDeServicios.getService("nabandinDAO")).count(paramsNabandin);				
				if (existeNabandin==0){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_CORRELACION, new String[] {serie.getNumserie().toString()});
					responseListManager.addResponseMap(listError);
				}
			}
		}
		
		return responseListManager.getResponseList();
	}

	public List<Map<String,?>> validarInformacionComplementaria(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();
		boolean existeObs = false;
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarInformacionComplementaria **** ");
		
		if(declaracion.getDua().getListObservaciones().size() > 0 ) {
			for (Observacion obs:declaracion.getDua().getListObservaciones()){	
				//Tipo de Obervacion (cod_catalogo = '369' | 01:Formato A - 06:Series Formato A)			
				if("06".equals(obs.getCodtipobserva()) && !"".equals(obs.getObsdeclaracion())) 
					existeObs = true;
			} 
		}
		
		if(!existeObs){
			for (DatoSerie serie:declaracion.getDua().getListSeries()){
				String preferencia = mapa.get(serie.getNumserie()).toString();
				if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
					//No hay observaciones por serie, estan a nivel de datos generales, seria el mismo error para cada serie acogida
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_INF_COMPLEMENTARIA, new String[] {serie.getNumserie().toString()});
					responseListManager.addResponseMap(listError);
				}
			}
		}		
		
		return responseListManager.getResponseList();
	}
	//20152002/ Modificado Rin08
	public List<Map<String,?>> validarPartidaConvenioPECOAmazonia(Declaracion declaracion, Map<Integer,Object> mapa){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarPartidaConvenioPECOAmazonia **** ");
		
		//20150220 - Se debe validar con la aduana de destino
		String aduanaDestino = declaracion.getDua().getOtraAduana().getCodopadusal() != null ? declaracion.getDua().getOtraAduana().getCodopadusal() : "" ;
		
		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			if(ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA.equals(preferencia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(preferencia)){			
				HashMap<String, Object> paramsAdualib = new HashMap<String, Object>();
				paramsAdualib.put("tlib","C");
				paramsAdualib.put("cnab", serie.getNumpartnaban());
				paramsAdualib.put("clib", serie.getCodliberatorio());
				paramsAdualib.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
				paramsAdualib.put("cadu", aduanaDestino); //20150220 - Se valida con la aduana de destino
				
				Integer existeAdualib = ((AdualibDAO)fabricaDeServicios.getService("adualibDAO")).count(paramsAdualib);
				if (existeAdualib==0){					
					Map<String, String> listError = new HashMap<String, String>();
					//listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(Constantes.ERR_LEY_PECO_CONVENIO_PECO_AMAZONIA, new String[] {serie.getNumserie().toString()});
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_CONVENIO_PECO_AMAZONIA, 
							new String[] {serie.getNumserie().toString(), serie.getNumpartnaban(), aduanaDestino});
					responseListManager.addResponseMap(listError);
				}
			}
			
			//20150220 - Se valida la vigencia de la nabandina para los TPI de PECO
			if(ConstantesDataCatalogo.PREFERENCIAS_DECL_PECO.equals(preferencia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(preferencia)){			
				HashMap<String, Object> paramsAdualib = new HashMap<String, Object>();
				paramsAdualib.put("tlib","I");
				paramsAdualib.put("cnab", serie.getNumpartnaban());
				paramsAdualib.put("clib", "32"); //20150220 - Segun conversion en el servicio verilib debe validarse con codigo 32.
				paramsAdualib.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
				paramsAdualib.put("cadu", aduanaDestino); //20150220 - Se valida con la aduana de destino
				
				Integer existeAdulibe = ((pe.gob.sunat.despaduanero2.declaracion.model.dao.AdulibeDAO)fabricaDeServicios.getService("adulibeDAO")).count(paramsAdualib);					
				if (existeAdulibe==0){
					Map<String, String> listError = new HashMap<String, String>();
					//listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(Constantes.ERR_LEY_PECO_CONVENIO_PECO_AMAZONIA, new String[] {serie.getNumserie().toString()});
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_CONVENIO_PECO_AMAZONIA, 
							new String[] {serie.getNumserie().toString(), serie.getNumpartnaban(), aduanaDestino});
					responseListManager.addResponseMap(listError);
				}
			}
		}
		
		return responseListManager.getResponseList();
	}	
	
	public List<Map<String,?>> validarUbigeo(Declaracion declaracion, Map<Integer,Object> mapaSerieDUA){
		AyudaService ayudaService = (AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService");
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarUbigeo **** ");
						
		//Solo se valida el Ubigeo cuando declara en alguna serie que se acoge a Ley de Amazonia
		String esAmazonia = mapaSerieDUA.get(Integer.valueOf("0")).toString();
		if(ConstantesDataCatalogo.PREFERENCIAS_DECL_AMAZONIA.equals(esAmazonia) || ConstantesDataCatalogo.PREFERENCIAS_DECL_AMBOS.equals(esAmazonia)){
			PreferenciaArancelariaService preferenciaArancelariaService = fabricaDeServicios.getService("preferenciaArancelariaService");
			
			String aduanaDestino = declaracion.getDua().getOtraAduana().getCodopadusal();
			String ubigeoDuenoConsignatario = preferenciaArancelariaService.consultarUbigeoImportadorPreferenciaArancelaria(
					declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(), declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad());
			
			if(log.isDebugEnabled()) log.debug("**** ubigeoDuenoConsignatario: " + ubigeoDuenoConsignatario);
			
			Map<String,Object> paramsCatRefpartidas=new HashMap<String,Object>();
			paramsCatRefpartidas.put("tipo_uso", "ULA");
			//paramsCatRefpartidas.put("codi_aduan", aduanaDestino);
			paramsCatRefpartidas.put("fechaVigencia", SunatDateUtils.getCurrentIntegerDate());
			paramsCatRefpartidas.put("codUbigeo", ubigeoDuenoConsignatario);		
			paramsCatRefpartidas.put("ayudaID", "CatRefpartidas");
			
			Integer countCatRefParts = (Integer)ayudaService.countCatRefParidas(paramsCatRefpartidas);		
			if(countCatRefParts==0){
				Map<String, String> listError = new HashMap<String, String>();
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_PECO_UBIGEO_AMAZONIA, new String[] {ubigeoDuenoConsignatario});
				responseListManager.addResponseMap(listError);
			}else{//para el acogimiento al beneficio de la Ley de Amazona el domicilio fiscal del importador debe encontrarse dentro de la jurisdiccin de la Aduana de destino en la zona establecida como Amazonia. 
				paramsCatRefpartidas.put("codi_aduan", aduanaDestino);
								
				Integer countCatRefPartidas = (Integer)ayudaService.countCatRefParidas(paramsCatRefpartidas);		
				if(countCatRefPartidas==0){
					Map<String, String> listError = new HashMap<String, String>();
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_LEY_AMAZONIA_UBIGEO_DESTINO, new String[] {aduanaDestino});
					responseListManager.addResponseMap(listError);
			}
			}// FIN - PAS201830001100015
		}
	
		return responseListManager.getResponseList();
	}
	
	 
	private boolean tieneDiligenciaDespacho(Declaracion declaracionBD, String[] lstDiligencia){
		boolean tieneDiligencia = false;		
		Map<String, String> PkDocu = new HashMap<String, String>();
		PkDocu.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc().toString());		
		PkDocu.put("viewRevision","false"); // No obtener las que estan en revisin
		
		//20150215 - Utilizamos el servicio de Diligencia
		//List<Map<String, Object>> lstdiligencias = cabdiligenciaDAO.findByDocumento(PkDocu);
		List<Map<String, Object>> lstdiligencias = ((DiligenciaService)fabricaDeServicios.getService("diligencia.ingreso.diligenciaService")).obtenerDiligencias(PkDocu);
		
		/* Si tiene diligencias: basta que una tenga fecha diferente de default para que se considere como diligenciada */
		if (!CollectionUtils.isEmpty(lstdiligencias)) {
			for (Map<String, Object> diligencia : lstdiligencias) {	
				//if("02".equals(diligencia.get("COD_TIPDILIGENCIA")) || "03".equals(diligencia.get("COD_TIPDILIGENCIA"))){
				if(SunatStringUtils.include(SunatStringUtils.toStringObj(diligencia.get("COD_TIPDILIGENCIA")), lstDiligencia)){
					Date fechaDiligencia = (Date) diligencia.get("FEC_DILIGENCIA");
					if (fechaDiligencia != null && !DateUtil.isDefaultDate(fechaDiligencia)) {
						tieneDiligencia = true;
						break;
					}
				}
			}
		}
		
		return tieneDiligencia;
	}
	
	//PAS201830001100016 - mtorralba 20181105 - Valida si ya cuenta con un determinado tipo de Diligencia
	private boolean tieneDiligencia(Declaracion declaracionBD, String[] lstDiligencia){
		boolean tieneDiligencia = false;		
		Map<String, String> PkDocu = new HashMap<String, String>();
		PkDocu.put("NUM_CORREDOC", declaracionBD.getDua().getNumcorredoc().toString());		
		PkDocu.put("viewRevision","false"); // No obtener las que estan en revisin
		
		//20150215 - Utilizamos el servicio de Diligencia
		//List<Map<String, Object>> lstdiligencias = cabdiligenciaDAO.findByDocumento(PkDocu);
		List<Map<String, Object>> lstdiligencias = ((DiligenciaService)fabricaDeServicios.getService("diligencia.ingreso.diligenciaService")).obtenerDiligencias(PkDocu);
		
		/* Si tiene diligencias: basta que una tenga fecha diferente de default para que se considere como diligenciada */
		if (!CollectionUtils.isEmpty(lstdiligencias)) {
			for (Map<String, Object> diligencia : lstdiligencias) {	
				//if("02".equals(diligencia.get("COD_TIPDILIGENCIA")) || "03".equals(diligencia.get("COD_TIPDILIGENCIA"))){
				if(SunatStringUtils.include(SunatStringUtils.toStringObj(diligencia.get("COD_TIPDILIGENCIA")), lstDiligencia)){
					Date fechaDiligencia = (Date) diligencia.get("FEC_DILIGENCIA");
					if (fechaDiligencia != null && !DateUtil.isDefaultDate(fechaDiligencia)) {
						tieneDiligencia = true;
						break;
					}
				}
			}
		}
		
		return tieneDiligencia;
	}

	//PAS201830001100016 - mtorralba 20181105 - Se incorporan validaciones solicitadas en RIN 08 - Complemento PECO Amazonia 
	public List<Map<String,?>> acogimientoPosteriorNumeracion(Declaracion declaracion, Declaracion declaracionBD, Map<Integer,Object> mapa, String codTransaccion){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: acogimientoPosteriorNumeracion ****");
		
		//Incorporacion de la Aduana de Destino
		String aduanaDestino = declaracion.getDua().getOtraAduana().getCodopadusal();
		String aduanaDestinoBD = declaracionBD.getDua().getOtraAduana().getCodopadusal();
		Date fecAutLevante = declaracionBD.getDua().getFecAutlevante()!=null?declaracionBD.getDua().getFecAutlevante():SunatDateUtils.getDefaultDate();
		
		boolean tieneDiligenciaDestino = tieneTipoDiligencia(declaracionBD.getDua().getNumcorredoc().toString(), COD_TIPODILIG_DILIGENCIA_EN_DESTINO);
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService"); //PAS201830001100016 - mtorralba 20181105
		if((aduanaDestino != null && !"".equals(aduanaDestino.trim())) && (aduanaDestinoBD == null || "".equals(aduanaDestinoBD.trim()))){
			Map<String, String> listError = new HashMap<String, String>();
			if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
				if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)) {
					//listError = catalogoAyudaService.getError(ERR_RECTI_LEVANTE_INCORP_ADU_DEST, null);
			    } else if(ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion))
					listError = catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_ADU_DEST, null);
				else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion))
					listError = catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_ADU_DEST, null);
				else
					listError = catalogoAyudaService.getError(ERR_RECTI_LEVANTE_INCORP_ADU_DEST, null);
			}
			else //Error cuando ya cuenta con diligencia en Aduana de Destino
				listError = catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO,new String[] {"","INCORPORAR","CODIGO DE ADUANA DESTINO"});
			responseListManager.addResponseMap(listError);
		}
		
		//Incorporacion de datos x serie
		String TPI = "0";
		String codigoLiberatorio = "0";
		Long nabandina = 0L;
		Long nabandinaBD = 0L;
		Long nandina = 0L;
		Long nandinaBD = 0L;
		
		String solicitaAcogimientoPosterior   = verificarIndicadorDeclarado(declaracion, ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_ACOGIMIENTO_POSTERIOR);
		String solicitaAcogimientoPosteriorBD = verificarIndicadorDeclarado(declaracionBD, ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_ACOGIMIENTO_POSTERIOR);
		boolean esAcogimientoPosterior = false;
		
		for (DatoSerie serie:declaracion.getDua().getListSeries()){
			List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
			String preferencia = mapa.get(serie.getNumserie()).toString();			
			if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia)){
				//No consideraba que en la recti enviase mas series
				DatoSerie serieBD = new DatoSerie();
				if (SunatNumberUtils.isGreaterOrEqualsThanParam(declaracionBD.getDua().getListSeries().size(), serie.getNumserie())) {
					//serieBD = declaracionBD.getDua().getListSeries().get(serie.getNumserie()-1);//se quita no corresponde esta evaluacin por desorden en resultado de bd pase55
									/**Inicio cambios pase PAS20165E220200055**/
									for(DatoSerie serieRealBD: declaracionBD.getDua().getListSeries()){
										if(serieRealBD.getNumserie().equals(serie.getNumserie())){
											serieBD = serieRealBD;
											break;
										}
									}
									/**Fin cambios pase PAS20165E220200055**/
				} 
				
				TPI = serie.getCodconvinter().toString();
				codigoLiberatorio = serie.getCodliberatorio().toString();
				//nabandinda = serie.getNumpartnabanAsLong()==null?0L:serie.getNumpartnabanAsLong();
				nabandina = serie.getNumpartnaban()!=null && !"".equals(serie.getNumpartnaban().trim())?serie.getNumpartnabanAsLong():0L;
				//nabandindaBD = serieBD.getNumpartnabanAsLong()==null?0L:serieBD.getNumpartnabanAsLong();
				nabandinaBD = serieBD.getNumpartnaban()!=null && !"".equals(serieBD.getNumpartnaban().trim())?serieBD.getNumpartnabanAsLong():0L;
				
				//20150222 - Se agrega la validacion de la nandina
				nandina = serie.getNumpartnandi()!=null?serie.getNumpartnandi():0L;
				nandinaBD = serieBD.getNumpartnandi()!=null?serieBD.getNumpartnandi():0L;
				String numeroSerie = serie.getNumserie().toString();			
				//Incorporacion de TPI
				if("0".equals(serieBD.getCodconvinter().toString()) && !"0".equals(TPI)){
					esAcogimientoPosterior = true;
					//Map<String, String> listError = new HashMap<String, String>();
					if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
						if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion))
							//if (SunatDateUtils.isDefaultDate(fecAutLevante)){
							//	listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_RECTI_INCORP_TPI, new String[] {serie.getNumserie().toString()});
							//} else{
								listError.add(catalogoAyudaService.getError(ERR_RECTI_LEVANTE_INCORP_TPI, new String[] {numeroSerie}));
							//}
						else if (ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion))						
							listError.add(catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_TPI, new String[] {serie.getCodconvinter().toString(), numeroSerie}));
						else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion))
							listError.add(catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_TPI, new String[] {numeroSerie}));
						else 
							listError.add(catalogoAyudaService.getError(ERR_RECTI_INCORP_TPI, new String[] {numeroSerie}));
						//responseListManager.addResponseMap(listError);
					}
					else //Error cuando ya cuenta con diligencia en Aduana de Destino
						listError.add(catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO, new String[] {"SERIE ".concat(numeroSerie).concat(": ") ,"INCORPORAR","CONVENIO PECO"}));
					
				}
				
				//Incorporacion de Codigo Liberatorio
				if("0".equals(serieBD.getCodliberatorio().toString()) && !"0".equals(codigoLiberatorio)){
					esAcogimientoPosterior =  true;
					if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
						if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)) {
							//if (SunatDateUtils.isDefaultDate(fecAutLevante)){
							//	listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_RECTI_INCORP_COD_LIBER, new String[] {serie.getNumserie().toString()});
							//} else{
							//	listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_RECTI_LEVANTE_INCORP_COD_LIBER, new String[] {serie.getNumserie().toString()});
							//}
							if( !solicitaAcogimientoPosterior.equals(ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_ACOGIMIENTO_POSTERIOR))
								listError.add(catalogoAyudaService.getError(ERR_INDICADOR_ACOGIMIENTO_POSTERIOR, new String[] {numeroSerie}));
	//PasePecoPAS20181U220200069
							if( excedePlazoSolicitudRectificacion (declaracion,Calendar.getInstance().getTime()) )  
								listError.add(catalogoAyudaService.getError(ERR_EXCEDE_PLAZO_ACOGIMIENTO_POSTERIOR, new String[] {numeroSerie}));
							
							//Validamos que no haya presentado Desistimiento
							if( verificarIndicadorDeclarado(declaracionBD, ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_DESISTIMIENTO).equals(ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_DESISTIMIENTO) )
								listError.add(catalogoAyudaService.getError(ERR_TIENE_DESISTIMIENTO_PECOAMAZONIA, new String[] {numeroSerie}));
						
						}
						else if (ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion))
							listError.add(catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_COD_LIBER, new String[] {numeroSerie}));
						else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion))
							listError.add(catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_COD_LIBER, new String[] {numeroSerie}));
						else
							listError.add(catalogoAyudaService.getError(ERR_RECTI_INCORP_COD_LIBER, new String[] {numeroSerie}));
					}
					else //Error cuando ya cuenta con diligencia en Aduana de Destino
						listError.add(catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO,new String[] {"SERIE ".concat(numeroSerie).concat(": ") ,"INCORPORAR","BENEFICIO DE LEY DE AMAZONIA"}));
				}
				
				//Incorporacion de Partida Nabandina
				if(nabandinaBD.compareTo(0L)==0 && nabandina.compareTo(0L)!=0){
					//Map<String, String> listError = new HashMap<String, String>();	
					if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
						if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)) {
							//if (SunatDateUtils.isDefaultDate(fecAutLevante)){
							//	listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_RECTI_INCORP_PARTIDA, new String[] {serie.getNumserie().toString()});
							//} else {
							//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_RECTI_LEVANTE_INCORP_PARTIDA, new String[] {serie.getNumserie().toString()}));
							//}
						} else if (ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion))
							listError.add(catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_NABANDINA, new String[] {serie.getNumserie().toString()}));
						else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion))
							listError.add(catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_PARTIDA, new String[] {serie.getNumserie().toString()}));
						else
							listError.add(catalogoAyudaService.getError(ERR_RECTI_INCORP_PARTIDA, new String[] {serie.getNumserie().toString()}));
						//responseListManager.addResponseMap(listError);
					}
					else //Error cuando ya cuenta con diligencia en Aduana de Destino
						listError.add(catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO, new String[] {"SERIE ".concat(numeroSerie).concat(": ") ,"INCORPORAR","PARTIDA NABANDINA"}));
				}
				
				//20150222 - Incorporacion de Partida Nandina
				if(nandinaBD.compareTo(0L)==0 && nandina.compareTo(0L)!=0){
					//Map<String, String> listError = new HashMap<String, String>();	
					if(!ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)){
						//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(ERR_REGU_INCORP_MODIF_NANDINA, new String[] {serie.getNumserie().toString()}));
						//responseListManager.addResponseMap(listError);
					}
				}
				
			}
			
			//Se incluyen los errores en la lista de Errores
			for( Map<String,String> mapaError : listError ) 
				responseListManager.addResponseMap(mapaError);
			
		} //final FOR
		
		if( esAcogimientoPosterior )
			responseListManager.addResponseList(validarIndicadoresPECO(declaracion, codTransaccion, "ACOGIMIENTO"));
		return responseListManager.getResponseList();
	}
	
	
	//PAS201830001100016 - mtorralba 20181105 - Se incorporan validaciones solicitadas en RIN 08 - Complemento PECO Amazonia 
	public List<Map<String,?>> modificacionPosteriorNumeracion(Declaracion declaracion, Declaracion declaracionBD, Map<Integer,Object> mapa, String codTransaccion){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: modificacionPosteriorNumeracion **** ");
		
		boolean esEliminado = false;
		boolean esModificado = false;
		boolean tieneAcogimiento = false;
		boolean existeDiligencia = tieneDiligenciaDespacho(declaracionBD, new String[]{ConstantesDataCatalogo.COD_DILIG_REV_DOC,ConstantesDataCatalogo.COD_DILIG_REC_FIS});
		
		//Modificacion de la Aduana de Destino
		String aduanaDestino = declaracion.getDua().getOtraAduana().getCodopadusal();
		String aduanaDestinoBD = declaracionBD.getDua().getOtraAduana().getCodopadusal();

		boolean tieneDiligenciaDestino = tieneTipoDiligencia(declaracionBD.getDua().getNumcorredoc().toString(), COD_TIPODILIG_DILIGENCIA_EN_DESTINO);
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService"); //PAS201830001100016 - mtorralba 20181105

		
		//Se verifica si se desiste totalmente de Beneficio PECO.
		if( esDesistimientoBeneficio(declaracion, declaracionBD) ) {
			if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
				//PAS201830001100016 - mtorralba 20181228 - Bug Verificamos que haya retirado NABANDINA y Aduana destino
				if( !verificaRetiroTotal(declaracion.getDua().getOtraAduana().getCodopadusal(), declaracionBD.getDua().getOtraAduana().getCodopadusal(), "AduanaDestino") ||
					!verificaRetiroTotal(declaracion.getDua().getListSeries(), declaracionBD.getDua().getListSeries(), "PartidaNabandina") ) {
						responseListManager.addResponseMap(catalogoAyudaService.getError(ERR_NO_HA_RETIRADO_TODOS_LOS_DATOS, null));
				}

				//Validamos que enve indicador de Desistimiento
				if( !verificarIndicadorDeclarado(declaracion, ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_DESISTIMIENTO).equals(ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_DESISTIMIENTO))
					responseListManager.addResponseMap(catalogoAyudaService.getError(ERR_INDICADOR_DESISTIMIENTO_BENEFICIO, null));
				responseListManager.addResponseList(validarIndicadoresPECO(declaracion, codTransaccion, "DESISTIMIENTO"));
				
			}
			else
				responseListManager.addResponseMap(catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO, new String[] {"","DESISTIR","DEL BENEFICIO PECO Y/O AMAZONIA"}));
			return responseListManager.getResponseList();
		}
		
		esEliminado = (aduanaDestinoBD != null && !"".equals(aduanaDestinoBD.trim())) && (aduanaDestino == null || "".equals(aduanaDestino.trim()));
		esModificado = (aduanaDestinoBD != null && !"".equals(aduanaDestinoBD.trim())) && (aduanaDestino != null && !"".equals(aduanaDestino.trim())) && !aduanaDestino.equals(aduanaDestinoBD);
		if(esEliminado || esModificado){
			if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
				Map<String, String> listError = new HashMap<String, String>();	
				//MORDONEZL SE ELIMINA DICHA REGLA POR RIN 08
				//if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia) 
					//listError = catalogoAyudaService.getError(ERR_RECTI_MODIF_ADU_DEST, null); Se elimina la regla en la RIN08
				//else 
				if(ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia)
						listError = catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_ADU_DEST, null);				
				else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion))	
					listError = catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_ADU_DEST, null);
				else if (existeDiligencia && !ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion))
					listError = catalogoAyudaService.getError(ERR_RECTI_MODIF_ADU_DEST, null);
				responseListManager.addResponseMap(listError);		
			}
			else //Error cuando ya cuenta con diligencia en Aduana de Destino 
				responseListManager.addResponseMap(catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO, new String[] {"",(esEliminado?"RETIRAR":"MODIFICAR"),"CODIGO DE ADUANA DESTINO"}));
		}
		
		//Incorporacion de datos x serie
		String TPI = "0";
		String codigoLiberatorio = "0";
		Long nabandina = 0L;
		Long nabandinaBD = 0L;
		Long nandina = 0L;
		Long nandinaBD = 0L;			
		String numeroSerie = "";
		boolean esModificacion = false;
		
		for (DatoSerie serie : declaracion.getDua().getListSeries()){
			String preferencia = mapa.get(serie.getNumserie()).toString();
			DatoSerie serieBD = new DatoSerie();
			//No consideraba que en la recti enviase mas series
			if (SunatNumberUtils.isGreaterOrEqualsThanParam(declaracionBD.getDua().getListSeries().size(), serie.getNumserie())) {
				//serieBD = declaracionBD.getDua().getListSeries().get(serie.getNumserie()-1);//se quita no corresponde esta evaluacin por desorden en resultado de bd pase55
				/**Inicio cambios pase PAS20165E220200055**/
				for(DatoSerie serieRealBD: declaracionBD.getDua().getListSeries()){
					if(serieRealBD.getNumserie().equals(serie.getNumserie())){
						serieBD = serieRealBD;
						break;
					}
				}
				/**Fin cambios pase PAS20165E220200055**/
			} 			
			tieneAcogimiento = (serieBD.getCodconvinter()!=null && !"0".equals(serieBD.getCodconvinter().toString())) || 
							   (serieBD.getCodliberatorio()!=null && !"0".equals(serieBD.getCodliberatorio().toString()));
			numeroSerie = serie.getNumserie().toString();
			if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(preferencia) || tieneAcogimiento){

				TPI = serie.getCodconvinter().toString();
				codigoLiberatorio = serie.getCodliberatorio().toString();
				//nabandinda = serie.getNumpartnabanAsLong()==null?0L:serie.getNumpartnabanAsLong();
				nabandina = serie.getNumpartnaban()!=null && !"".equals(serie.getNumpartnaban().trim())?serie.getNumpartnabanAsLong():0L;
				//nabandindaBD = serieBD.getNumpartnabanAsLong()==null?0L:serieBD.getNumpartnabanAsLong();
				nabandinaBD = serieBD.getNumpartnaban()!=null && !"".equals(serieBD.getNumpartnaban().trim())?serieBD.getNumpartnabanAsLong():0L;
				
				//20150222 - Se agrega la validacion de la nandina
				nandina = serie.getNumpartnandi()!=null?serie.getNumpartnandi():0L;
				nandinaBD = serieBD.getNumpartnandi()!=null?serieBD.getNumpartnandi():0L;
				
				//Modificacion de TPI
				esEliminado = !"0".equals(serieBD.getCodconvinter().toString()) && "0".equals(TPI);
				esModificado = !"0".equals(serieBD.getCodconvinter().toString()) && !"0".equals(TPI) && !TPI.equals(serieBD.getCodconvinter().toString());
				if(esEliminado || esModificado){
					if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
						esModificacion = true;
						Map<String, String> listError = new HashMap<String, String>();	
						//MORDONEZL SE ELIMINA DICHA REGLA POR RIN 08
						//if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia)
						//	listError = catalogoAyudaService.getError(ERR_RECTI_MODIF_TPI, new String[] {numeroSerie});
						//else 
						if (ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia)
							listError = catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_TPI, new String[] {serieBD.getCodconvinter().toString(), numeroSerie});
						else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion))
							listError = catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_TPI, new String[] {numeroSerie});
						else if (existeDiligencia && !ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion))
							listError = catalogoAyudaService.getError(ERR_RECTI_MODIF_TPI, new String[] {numeroSerie});
						responseListManager.addResponseMap(listError);
					}
					else //Error cuando ya cuenta con diligencia en Aduana de Destino 
						responseListManager.addResponseMap(catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO, 
								new String[] {"SERIE ".concat(numeroSerie).concat(": "),(esEliminado?"RETIRAR":"MODIFICAR"),"CONVENIO PECO"}));
					
				}
				
				//Modificacion de Codigo Liberatorio
				esEliminado = !"0".equals(serieBD.getCodliberatorio().toString()) && "0".equals(codigoLiberatorio);
				esModificado = !"0".equals(serieBD.getCodliberatorio().toString()) && !"0".equals(codigoLiberatorio) && !codigoLiberatorio.equals(serieBD.getCodliberatorio().toString());
				if(esEliminado || esModificado){
					if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
						esModificacion = true;
						Map<String, String> listError = new HashMap<String, String>();	
						//MORDONEZL SE ELIMINA DICHA REGLA POR RIN 08
//						if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia)
//							listError = catalogoAyudaService.getError(ERR_RECTI_MODIF_COD_LIBER, new String[] {numeroSerie});
//						else 
						if (ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia)
							listError = catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_COD_LIBER, new String[] {numeroSerie});
						else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion))
							listError = catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_COD_LIBER, new String[] {numeroSerie});
						else if (existeDiligencia && !(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) || ConstantesDataCatalogo.TRANS_DILIG_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)))
							listError = catalogoAyudaService.getError(ERR_RECTI_MODIF_COD_LIBER, new String[] {numeroSerie});
						responseListManager.addResponseMap(listError);
					}
					else //Error cuando ya cuenta con diligencia en Aduana de Destino 
						responseListManager.addResponseMap(catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO, 
								new String[] {"SERIE ".concat(numeroSerie).concat(": "),(esEliminado?"RETIRAR":"MODIFICAR"),"BENEFICIO DE LEY DE AMAZONIA"}));
				}

				//Modificacion de Partida Nabandina
				esEliminado = nabandinaBD.compareTo(0L)!=0 && nabandina.compareTo(0L)==0;
				esModificado = nabandinaBD.compareTo(0L)!=0 && nabandina.compareTo(0L)!=0 && nabandina.compareTo(nabandinaBD)!=0;
				if(esEliminado || esModificado){
					if( !tieneDiligenciaDestino) { //Si no tiene diligencia en Aduana de Destino
						Map<String, String> listError = new HashMap<String, String>();	
						//MORDONEZL SE ELIMINA DICHA REGLA POR RIN 08
//						if(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia)
//							listError = catalogoAyudaService.getError(ERR_RECTI_MODIF_PARTIDA, new String[] {numeroSerie});
//						else 
							if (ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia)
							listError = catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_NABANDINA, new String[] {numeroSerie});
						else if(ConstantesDataCatalogo.TRANS_CONCLUSION_DESPACHO.equals(codTransaccion))
							listError = catalogoAyudaService.getError(ERR_CONCLU_INCORP_MODIF_PARTIDA, new String[] {numeroSerie});
						else if (existeDiligencia && !ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion))
							listError = catalogoAyudaService.getError(ERR_RECTI_MODIF_PARTIDA, new String[] {numeroSerie});
						responseListManager.addResponseMap(listError);
					}
					else //Error cuando ya cuenta con diligencia en Aduana de Destino 
						responseListManager.addResponseMap(catalogoAyudaService.getError(ERR_TIENE_DILIGENCIA_EN_DESTINO, 
								new String[] {"SERIE ".concat(numeroSerie).concat(": "),(esEliminado?"RETIRAR":"MODIFICAR"),"PARTIDA NABANDINA"}));
				}
				
				//20150222 - Incorporacion de Partida Nandina
				//Modificacion de Partida Nabandina
				esEliminado = nandinaBD.compareTo(0L)!=0 && nandina.compareTo(0L)==0;
				esModificado = nandinaBD.compareTo(0L)!=0 && nandina.compareTo(0L)!=0 && nandina.compareTo(nandinaBD)!=0;
				if(esEliminado || esModificado){
					Map<String, String> listError = new HashMap<String, String>();			
					if(!ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) && existeDiligencia){						
						listError = catalogoAyudaService.getError(ERR_REGU_INCORP_MODIF_NANDINA, new String[] {numeroSerie});
						responseListManager.addResponseMap(listError);
					}
				}			
			}
		}
		
		if( esModificacion )
			responseListManager.addResponseList(validarIndicadoresPECO(declaracion, codTransaccion, "MODIFICACION"));
		
		return responseListManager.getResponseList();
	}
	
	/**
	 *RIN08
	 *Valida las series si es el caso de PECO 
	 * */
	public String validarSeriePecoAmazoniaModificada(Map<String, Object> requestParameterMap){
		 
		HashMap<String, Object> paramsNabandin = new HashMap<String, Object>();
		HashMap<String, Object> paramsAdualib = new HashMap<String, Object>();
		Integer existe;
		String msg="";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("COD_ADUANA", requestParameterMap.get("cod_aduana").toString());
		params.put("finicio",requestParameterMap.get("fec_declaracion").toString());
		params.put("ffin", requestParameterMap.get("fec_declaracion").toString());
		boolean valorCondicion=false;
		String aduanaDestino=requestParameterMap.get("cod_adudest").toString();
		String num_secserie =requestParameterMap.get("num_secserie").toString();
		
		SoporteService soporteService = fabricaDeServicios.getService("diligencia.ingreso.soporteService");		 
		 
		if (  ConstantesDataCatalogo.COD_TIP_34.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim())  ||  ConstantesDataCatalogo.COD_TIP_35.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim()) 
			|| ConstantesDataCatalogo.COD_TIP_36.equals( Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim()) || ConstantesDataCatalogo.COD_TIP_4438.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_ind_libe")).trim())) {

			valorCondicion=true;
		}
		
		if (valorCondicion){
			 
			 if ((ConstantesDataCatalogo.COD_TIP_34.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim())  && ConstantesDataCatalogo.ADUANA_IQUITOS.equals(aduanaDestino)) || 
					 (ConstantesDataCatalogo.COD_TIP_35.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim())  && ConstantesDataCatalogo.ADUANA_PUCALLPA.equals(aduanaDestino)) ||
					 	(ConstantesDataCatalogo.COD_TIP_36.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim())  && ConstantesDataCatalogo.ADUANA_TARAPOTO.equals(aduanaDestino))) {
			 
				 if ( "".equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("num_parnabandina")).trim()) || "".equals(Utilidades.crearCadenaDesdeObjeto( requestParameterMap.get("num_partnandi")).trim())){
	                  msg=msg.concat("TPI ").concat(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim()).concat(":S�lo se debe considerar la Subpartida arancelaria NANDINA y NABANDINA, serie ").concat(num_secserie).concat(" \n \n");
				 }
				 
				paramsNabandin.put("nabandi", Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("num_parnabandina")).trim());
				paramsNabandin.put("nandina", Utilidades.crearCadenaDesdeObjeto( requestParameterMap.get("num_partnandi")).trim());  
			    existe = ((NabandinDAO)fabricaDeServicios.getService("nabandinDAO")).count(paramsNabandin);
				   
				if (existe==0){//si no cumple
					// 5. Que la Subpartida arancelaria NABANDINA est� correlacionada con la Subpartida arancelaria NANDINA.
                    msg=msg.concat("TPI ").concat(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim()).concat(":NABANDINA declarada no tiene correlaci�n con la NANDINA, serie ").concat(num_secserie).concat("\n \n");
				}
		
				 params.put("partida", Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("num_partnandi")).trim());
				 if (soporteService.existePartidaNandina(params)!=1){//si no cumple
					 // 6. Que la Subpartida arancelaria NANDINA se encuentre vigente.
				     msg=msg.concat("TPI ").concat(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim()).concat(":Subpartida nacional NANDINA no vigente, serie ").concat(num_secserie).concat("\n \n");
				 }
			} 
			else 
				if ((ConstantesDataCatalogo.COD_TIP_34.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim()) && !ConstantesDataCatalogo.ADUANA_IQUITOS.equals(aduanaDestino)) || 
						(ConstantesDataCatalogo.COD_TIP_35.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim())  && !ConstantesDataCatalogo.ADUANA_PUCALLPA.equals(aduanaDestino)) ||
						(ConstantesDataCatalogo.COD_TIP_36.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim()) && !ConstantesDataCatalogo.ADUANA_TARAPOTO.equals(aduanaDestino))) {
		                     msg=msg.concat("TPI ").concat(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_tpi")).trim()).concat("Aduana De Destino Inv�lida \n \n");

				}
	
				 if ( ConstantesDataCatalogo.COD_TIP_4438.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_ind_libe")).trim())   && ( ConstantesDataCatalogo.ADUANA_CHICLAYO.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_CUZCO.equals(aduanaDestino)
						 || ConstantesDataCatalogo.ADUANA_IQUITOS.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_PAITA.equals(aduanaDestino) ||  ConstantesDataCatalogo.ADUANA_PISCO.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_PUCALLPA.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_PTO_MALDONADO.equals(aduanaDestino)
						 || ConstantesDataCatalogo.ADUANA_PUNO.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_SALAVERRY.equals(aduanaDestino)   || ConstantesDataCatalogo.ADUANA_TARAPOTO.equals(aduanaDestino)  )  ) {
		
				 
					 if ( "".equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("num_parnabandina")).trim()) || "".equals(Utilidades.crearCadenaDesdeObjeto( requestParameterMap.get("num_partnandi")).trim())){
						 msg=msg.concat("CODIGO LIBERATORIO 4438").concat(":S�lo se debe considerar la Subpartida arancelaria NANDINA y NABANDINA, serie ").concat(num_secserie).concat(" \n \n");
					 }
					 
					 paramsAdualib.put("cnab", Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("num_parnabandina")).trim());
					 paramsAdualib.put("clib", Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_ind_libe")));
					 paramsAdualib.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
					 paramsAdualib.put("cadu", requestParameterMap.get("cod_aduana").toString());					 
					 existe = ((AdualibDAO)fabricaDeServicios.getService("adualibDAO")).count(paramsAdualib);
					 
					 if (existe==0){//si no cumple
						 // 4. Que la Subpartida arancelaria NABANDINA se encuentre dentro del Protocolo modificatorio 
						 //del Convenio de Cooperaci�n Aduanera Peruano Colombiano (TPI 34,35 � 36)
						 //y C�digo Liberatorio 4438.
					     msg=msg.concat("CODIGO LIBERATORIO 4438").concat(":NABANDINA no se encuentra en Arancel - Convenio Peruano Colombiano/Ley de Amazonia, serie ").concat(num_secserie).concat("\n \n");
					 }
				 
				     paramsNabandin.put("nabandi", Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("num_parnabandina")).trim());
				     paramsNabandin.put("nandina", Utilidades.crearCadenaDesdeObjeto( requestParameterMap.get("num_partnandi")).trim());  
				     Integer existeNabandin = ((NabandinDAO)fabricaDeServicios.getService("nabandinDAO")).count(paramsNabandin);
					 if (existeNabandin==0){//si no cumple
						//5. Que la Subpartida arancelaria NABANDINA est� correlacionada con la Subpartida arancelaria NANDINA.
						msg=msg.concat("CODIGO LIBERATORIO 4438").concat(":NABANDINA declarada no tiene correlaci�n con la NANDINA, serie ").concat(num_secserie).concat("\n \n");
					 }
					 
					 params.put("partida", Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("num_partnandi")).trim());
					 if (soporteService.existePartidaNandina(params)!=1){//si no cumple
						//6. Que la Subpartida arancelaria NANDINA se encuentre vigente.
					    msg=msg.concat("CODIGO LIBERATORIO 4438").concat(":Subpartida nacional NANDINA no vigente, serie ").concat(num_secserie).concat("\n \n");
					 }
				}
				else 
					if (ConstantesDataCatalogo.COD_TIP_4438.equals(Utilidades.crearCadenaDesdeObjeto(requestParameterMap.get("cod_tipconvenio_ind_libe")).trim()) && !( ConstantesDataCatalogo.ADUANA_CHICLAYO.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_CUZCO.equals(aduanaDestino)
							|| ConstantesDataCatalogo.ADUANA_IQUITOS.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_MARITIMA_CALLAO.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_PAITA.equals(aduanaDestino) ||  ConstantesDataCatalogo.ADUANA_PISCO.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_PUCALLPA.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_PTO_MALDONADO.equals(aduanaDestino)
								|| ConstantesDataCatalogo.ADUANA_PUNO.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_SALAVERRY.equals(aduanaDestino) || ConstantesDataCatalogo.ADUANA_TARAPOTO.equals(aduanaDestino))){
			                  msg=msg.concat("CODIGO LIBERATORIO 4438:Aduana De Destino Inv�lida \n \n");
					}

		 }
		 
		return msg;
	}
	
	
	//20150215 - Anulacion de LC 0006 cuando la DUA ya se encuentre cancelada
	public String procesarAnulacionLC0006PecoAmazonia(Liquida liquidacionPeco, Map<String, Object> mapLiquida){

		HashMap<String, Object> param = new HashMap<String, Object>();	
		String resultado = "";
		
		//Anulamos la LC en la tabla del SDA
		Long numCorredoc = Long.parseLong(mapLiquida.get("NUMCORREDOC").toString());
		param = new HashMap<String, Object>();
		param.put("numCorredoc", numCorredoc);
		param.put("numIdentdeuda", mapLiquida.get("NUMIDENTDEUDA").toString());
		param.put("n_codEstadmin", "A");
		((DeudaDocumDAO)fabricaDeServicios.getService("diligencia.ingreso.deudaDocumDef_xa")).updateDeudaByMap(param); 

		//Anulamos la LC en tabla del SIGAD y Bancos
		param = new HashMap<String, Object>();
		param.put("TCRLADUANA", mapLiquida.get("CODADUDOCLIQ").toString());
		param.put("TCRLANO", mapLiquida.get("ANNDOCLIQ").toString().substring(2, 4));
		param.put("TCRLNROLIQ", mapLiquida.get("NUMDOCLIQ").toString());
		param.put("TCAPLICACION", "SEIDA");
		param.put("TCLCRAZONELI", "POR PAGO DE DAM ACOGIDA A PECO / LEY AMAZONIA");	

		PatgGeneraLcNpdaDAO patgGeneraLcNpdaDAO = ((PatgGeneraLcNpdaDAO)fabricaDeServicios.getService("patgGeneraLcNpdaDefDx"));
		DataSourceContextHolder.setKeyDataSource(mapLiquida.get("CODADUDOCLIQ").toString());
		patgGeneraLcNpdaDAO.anulaLC(param);


		//Si tiene garantia se debe desafectar la cta.cte.
		if("G".equals(mapLiquida.get("CODESTADMIN").toString())){
			param = new HashMap<String, Object>();
			param.put("cRUC", mapLiquida.get("RUC").toString()); // RUC del beneficiario
			param.put("cTIPOEXTIN", "06"); 
			param.put("cADUANA", mapLiquida.get("CODADUDOCLIQ").toString());
			param.put("cANO", mapLiquida.get("ANNDOCLIQ").toString().substring(2, 4));
			param.put("cREGIMEN", "96");
			param.put("cNUMERO", mapLiquida.get("NUMDOCLIQ").toString());
			param.put("cCDA", mapLiquida.get("CDA").toString());
			//param.put("nMONTOA", mapLiquida.get("MONTO"));
			param.put("nMONTOA", liquidacionPeco.getRldmontot());
			param.put("cMONEDAA", "D");
			param.put("nTIPOCAM", BigDecimal.ZERO);
			param.put("nFECHA", SunatDateUtils.getCurrentIntegerDate());
			param.put("cDOCUMENTO", mapLiquida.get("NUMREF").toString());
			param.put("cTRANS", " ");
			 if(log.isDebugEnabled())
		    		log.debug("procesarAnulacionLC0006PecoAmazonia Desafectando Garantia para LC- :"+liquidacionPeco.getRladuana()+"-"+liquidacionPeco.getRlano()+"-"+liquidacionPeco.getRlnroliq());
			resultado=(String) ((PagarantiaDAO)fabricaDeServicios.getService("pagarantiaDAO")).procesarDesafectarGarantia(param);
		}
		return resultado;
	}
//Inicio RIN08	
	//20150321 - Metodo que valida en la Diligencia de Rectificacion para una DUA acogida a PECO/Amazonia que inclya el dato 
	//		   - de aduana de destino necesariamente y que este corresponda con el TPI/Cod. Liberatorio declarado
	public String validaAduanaDestinoDiligenciaRectificacion(String codAduanaDestino, List<Map<String,Object>> lstSerie, String numCorreDoc){
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		String mensaje = "";
		DiligenciaService diligenciaService = (DiligenciaService)fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
		Map<String, Object> duadiligenciada = diligenciaService.findDuaDiligenciada(numCorreDoc);
	    boolean tieneDiligenciaDespacho = duadiligenciada == null ? false : true;
	    boolean tieneTPIPeco=false;
		if (tieneDiligenciaDespacho){		
			if(lstSerie != null && !lstSerie.isEmpty()){			
				for(Map<String,Object> serie : lstSerie){
					
					List<Map<String,Object>> lstConvenioSerie = new ArrayList<Map<String,Object>>();				 
					if(serie.containsKey("T0042")){
					 
						lstConvenioSerie = (List<Map<String, Object>>) serie.get("T0042");						 
						for(Map<String, Object> convenio : lstConvenioSerie){
							boolean esEliminado = convenio.get("indica")!=null && convenio.get("indica").equals("A")?true:false;
							//Evaluamos que no exista tpi 34 35 36
							if(convenio.get("COD_TIPCONVENIO").equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL) && !esEliminado){
								 //&& convenio.get("IND_DEL").equals("0")
								
								boolean anulaCodTPI = false;
								if(convenio.get("indica")!=null && !convenio.get("indica").equals("")){
									 anulaCodTPI = convenio.get("indica").equals("A")?true:false;
								}

								if (
								         	   convenio.get("COD_CONVENIO").toString().trim().equals(ConstantesDataCatalogo.COD_TIP_34) ||
								               convenio.get("COD_CONVENIO").toString().trim().equals(ConstantesDataCatalogo.COD_TIP_35) ||
								               convenio.get("COD_CONVENIO").toString().trim().equals(ConstantesDataCatalogo.COD_TIP_36)
								   ){
									tieneTPIPeco=true;/// validacion solo para DAMs de PECO
								   }
								//Si la declaracion no incluye aduana de destino se debe validar que no declare TPI
								if ((codAduanaDestino == null || codAduanaDestino.toString().trim().equals("")) && !anulaCodTPI && tieneTPIPeco){
									mensaje = ": No se puede retirar la Aduana de Destino debido a que la DUA esta acogida a Peco";
									break;
								}

								if(convenio.get("COD_CONVENIO").toString().trim().equals(ConstantesDataCatalogo.COD_TIP_34)){
									//Si la declaracion no incluye aduana de destino se debe validar que no declare TPI
									//if (codAduanaDestino == null || codAduanaDestino.toString().trim().equals("")){									
									//	mensaje = ": No se puede retirar la Aduana de Destino debido a que la DUA esta acogida a Peco";
									//	break;
									//}
									//Si la declaracion incluye aduana de destino se debe validar que corresponda al TPI
									if (codAduanaDestino != null && !"226".equals(codAduanaDestino.toString().trim()) && !anulaCodTPI){
										mensaje = ": Serie " + convenio.get("NUM_SECSERIE").toString().trim() + ", Aduana de Destino " + codAduanaDestino.toString().trim() + 
											      " no corresponde a TPI " + ConstantesDataCatalogo.COD_TIP_34;
										break;
									}
								}else if(convenio.get("COD_CONVENIO").toString().trim().equals(ConstantesDataCatalogo.COD_TIP_35)){
									//Si la declaracion no incluye aduana de destino se debe validar que no declare TPI
									//if (codAduanaDestino == null || codAduanaDestino.toString().trim().equals("")){									
									//	mensaje = ": No se puede retirar la Aduana de Destino debido a que la DUA esta acogida a Peco";
									//	break;
									//}
									//Si la declaracion incluye aduana de destino se debe validar que corresponda al TPI
									if (codAduanaDestino != null && !"217".equals(codAduanaDestino.toString().trim()) && !anulaCodTPI){
										mensaje = ": Serie " + convenio.get("NUM_SECSERIE").toString().trim() + ", Aduana de Destino " + codAduanaDestino.toString().trim() + 
												  " no corresponde a TPI " + ConstantesDataCatalogo.COD_TIP_35;
										break;
									}
								}
								else if(convenio.get("COD_CONVENIO").toString().trim().equals(ConstantesDataCatalogo.COD_TIP_36)){
									//Si la declaracion no incluye aduana de destino se debe validar que no declare TPI
									//if (codAduanaDestino == null || codAduanaDestino.toString().trim().equals("")){									
									//	mensaje = ": No se puede retirar la Aduana de Destino debido a que la DUA esta acogida a Peco";
									//	break;
									//}
									//Si la declaracion incluye aduana de destino se debe validar que corresponda al TPI
									if (codAduanaDestino != null && !"271".equals(codAduanaDestino.toString().trim()) && !anulaCodTPI){
										mensaje = ": Serie " + convenio.get("NUM_SECSERIE").toString().trim() + ", Aduana de Destino " + codAduanaDestino.toString().trim() + 
												  " no corresponde a TPI " + ConstantesDataCatalogo.COD_TIP_36;
										break;
									}
								}
							}
							 
							//Evaluamos codigo liberatorio
							if(convenio.get("COD_TIPCONVENIO").equals(ConstantesDataCatalogo.CODIGO_LIBERATORIO)){
								if(convenio.get("COD_CONVENIO").toString().trim().equals(ConstantesDataCatalogo.COD_LIBERATORIO_AMAZONIA)){
									//Si la declaracion no incluye aduana de destino se debe validar que no declare Cod. Liberatorio
									boolean anulaCodLiberatorioAmazonia = false;
									if(convenio.get("indica")!=null && !convenio.get("indica").equals("")){
										 anulaCodLiberatorioAmazonia = convenio.get("indica").equals("A")?true:false;
									}
									if ((codAduanaDestino == null || codAduanaDestino.toString().trim().equals("")) && !anulaCodLiberatorioAmazonia){									
										mensaje = ": No se puede retirar la Aduana de Destino debido a que la DUA esta acogida a Ley de Amazonia";
										break;
									}
									//Si la declaracion incluye aduana de destino se debe validar que corresponda al Cod. Liberatorio declarado
									if (codAduanaDestino != null && 
											!CollectionUtils.isEmpty(catalogoValidaService.validarElementoGrupo(ConstantesGrupoCatalogo.COD_GRP_ADUANAS_DEST_LIBERATORIO, codAduanaDestino.toString().trim()))){
										mensaje = ": Serie " + convenio.get("NUM_SECSERIE").toString().trim() + ", Aduana de Destino " + codAduanaDestino.toString().trim() + 
												  " no corresponde a Cod. Liberatorio " + ConstantesDataCatalogo.COD_LIBERATORIO_AMAZONIA;
										break;
									}
								}
							}
						} 
					}	
				}
			}
		}
//Fin Rin08		
		return mensaje;
	}
	
	
	private String verificarIndicadorDeclarado(Declaracion declaracion, String codIndicador) {
		String rpta = "";
		String codTipoIndica = "";
		String indActivo = "";
		if( declaracion.getDua().getListIndicadores()!=null && declaracion.getDua().getListIndicadores().size() > 0 ) {
			for( DatoIndicadores indicador : declaracion.getDua().getListIndicadores() ) {
				indActivo = indicador.getIndicadorActivo()!=null ? (indicador.getIndicadorActivo().equals("") ? "1" : indicador.getIndicadorActivo()): "1" ;
				codTipoIndica = indicador.getCodtipoindica()!=null ? indicador.getCodtipoindica() : " "; 
				if( indActivo.equals("1") )
					if( codTipoIndica.equals(codIndicador) ) {
						rpta = codTipoIndica;
						break;
					}
			}
		}
		return rpta;
	}
		
//PasePecoPAS20181U220200069
	public boolean excedePlazoSolicitudRectificacion ( Declaracion declaracion , Date fecha) {
		boolean resul = false;
		GarantiaOperativaService garantiaOperativaService = fabricaDeServicios.getService("recauda.diligencia.garantiaService");
		Date fechaInicioPlazo = declaracion.getDua().getFecdeclaracion();

		//Verificamos si tiene Garantia Previa (Art.160)
		if( declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia() != null ) 
			fechaInicioPlazo = declaracion.getDua().getFecdeclaracion();
		else { 
			//Verficamos si tiene Garantia Operativa (Art.159)
			Map<String,Object> params = new HashMap<String,Object>();
			params.put("codAduana", declaracion.getNumdeclRef().getCodaduana());
			params.put("codRegimen", declaracion.getNumdeclRef().getCodregimen());
			params.put("annPresen", declaracion.getNumdeclRef().getAnnprese().trim());
			params.put("numDeclaracion", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre().trim(),6,'0') );
			params.put("anoPresen", declaracion.getNumdeclRef().getAnnprese().trim().substring(2));
			List<Map> listaGaran = garantiaOperativaService.obtenerGarantiaPorDeclaracion(params);
			
			if( listaGaran.size() > 0 ) {
				Map datosGaran = listaGaran.get(0);
				fechaInicioPlazo = SunatDateUtils.getDateFromInteger(Integer.valueOf(datosGaran.get("FINICIO_DOCAFI").toString()));
			}
			else {
				//Si no tiene Garantia, se busca la fecha de Pago en las tablas de Bancos, para lo cual obtenemos el CDA de la DAM
				ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
				Map<String,Object> datosDAM = new HashMap<String,Object>();
				Map<String,Object> datosPago = new HashMap<String,Object>();
				
				datosDAM = consultaDeclaracionImpoConsumoService.obtenerDAMGarantizada(params);
				if( datosDAM.size() > 0 )  {
					String numcda  = datosDAM.get("NUM_CDA").toString();
					BancosService bancosService = fabricaDeServicios.getService("recauda2.BancosService");
					datosPago = bancosService.obtenerDatosBanco(numcda);
				}
				
				if( datosPago.size() > 0 )  
					fechaInicioPlazo = datosPago.get("FFE_CANCE")==null ? fechaInicioPlazo : 
						                             SunatDateUtils.getDateFromUnknownFormat(datosPago.get("FFE_CANCE").toString());
			}
		}
			
		//Obtengo Fecha de Notificacin
		FeriadoService feriadoService = fabricaDeServicios.getService("catalogo.FeriadoService");
		List<String> feriados = feriadoService.obtenerListaDeFeriados(2);
		Date fechaLimite = SunatDateUtils.obtenerDiaUtil(fechaInicioPlazo, 30, feriados);
		resul = SunatDateUtils.esFecha1MayorQueFecha2(fecha, fechaLimite, SunatDateUtils.COMPARA_SOLO_FECHA);
		
		return resul;
	}
	//PasePecoPAS20181U220200069
	public boolean excedePlazoDiligenciaAduanaDestino( Declaracion declaracion,Date fechaDiligencia) {
		boolean resul = false;
		GarantiaOperativaService garantiaOperativaService = fabricaDeServicios.getService("recauda.diligencia.garantiaService");
		Date fechaInicioPlazo = declaracion.getDua().getFecdeclaracion();

		//Verificamos si tiene Garantia Previa (Art.160)
		if( declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia() != null ) 
			fechaInicioPlazo = declaracion.getDua().getFecdeclaracion();
		else {
			//Verficamos si tiene Garantia Operativa (Art.159)
			Map params = new HashMap();
			params.put("codAduana", declaracion.getNumdeclRef().getCodaduana());
			params.put("codRegimen", declaracion.getNumdeclRef().getCodregimen());
			params.put("annPresen", declaracion.getNumdeclRef().getAnnprese().trim());
			params.put("numDeclaracion", SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre().trim(),6,'0') );
			params.put("anoPresen", declaracion.getNumdeclRef().getAnnprese().trim().substring(2));
			List<Map> listaGaran = garantiaOperativaService.obtenerGarantiaPorDeclaracion(params);
			
			if( listaGaran.size() > 0 ) {
				Map datosGaran = listaGaran.get(0);
				fechaInicioPlazo = SunatDateUtils.getDateFromInteger(Integer.valueOf(datosGaran.get("FINICIO_DOCAFI").toString()));
			}
			else {
				//Si no tiene Garantia, se busca la fecha de Pago en las tablas de Bancos, para lo cual obtenemos el CDA de la DAM
				ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");
				Map<String,Object> datosDAM = new HashMap<String,Object>();
				Map<String,Object> datosPago = new HashMap<String,Object>();
				
				datosDAM = consultaDeclaracionImpoConsumoService.obtenerDAMGarantizada(params);
				if( datosDAM.size() > 0 )  {
					String numcda  = datosDAM.get("NUM_CDA").toString();
					BancosService bancosService = fabricaDeServicios.getService("recauda2.BancosService");
					datosPago = bancosService.obtenerDatosBanco(numcda);
				}
				
				if( datosPago.size() > 0 )  
					fechaInicioPlazo = datosPago.get("FFE_CANCE")==null ? fechaInicioPlazo : 
						                             SunatDateUtils.getDateFromUnknownFormat(datosPago.get("FFE_CANCE").toString());
			}
		}
			
		//Obtengo Fecha de Notificaci�n
		FeriadoService feriadoService = fabricaDeServicios.getService("catalogo.FeriadoService");
		List<String> feriados = feriadoService.obtenerListaDeFeriados(2);
		Date fechaLimite = SunatDateUtils.obtenerDiaUtil(fechaInicioPlazo, 60, feriados);
		resul = SunatDateUtils.esFecha1MayorQueFecha2(fechaDiligencia, fechaLimite, SunatDateUtils.COMPARA_SOLO_FECHA);
		
		return resul;
	}
	

	private boolean tieneTipoDiligencia(String numcorredoc, String tipoDiligencia) {
		//Se verifica si tiene Diligencia Destino
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("numcorredoc", numcorredoc);
		params.put("codtipdiligencia", tipoDiligencia);
		DiligenciaService diligenciaService = fabricaDeServicios.getService("diligencia.ingreso.diligenciaService");
		boolean resul = SunatNumberUtils.isGreaterThanZero(diligenciaService.count(params));
		return resul;
	}


	private boolean esDesistimientoBeneficio(Declaracion declaracion, Declaracion declaracionBD) {
		boolean esEliminado = verificaRetiroTotal(declaracion.getDua().getListSeries(), declaracionBD.getDua().getListSeries(), "ConvenioInternacional");
		if( esEliminado) esEliminado = verificaRetiroTotal(declaracion.getDua().getListSeries(), declaracionBD.getDua().getListSeries(), "CodigoLiberatorio");
		//if( esEliminado) esEliminado = verificaRetiroTotal(declaracion.getDua().getOtraAduana().getCodopadusal(), declaracionBD.getDua().getOtraAduana().getCodopadusal(), "AduanaDestino");
		//if( esEliminado) esEliminado = verificaRetiroTotal(declaracion.getDua().getListSeries(), declaracionBD.getDua().getListSeries(), "PartidaNabandina");
		return esEliminado;
	}
	

	private boolean verificaRetiroTotal(Object datoEnviado, Object datoBD, String campo) {
		
		List<DatoSerie> listaSeries = null;
		List<DatoSerie> listaSeriesBD = null;
		String valorNuevo = "";
		String valorBD = "";
	
		boolean esEliminado = false;
		
		if( campo.equals("AduanaDestino") ) {
			valorNuevo = datoEnviado==null ? "0" : (datoEnviado.toString().trim().equals("") ? "0" : datoEnviado.toString());
			valorBD = datoBD==null ? "0" : (datoBD.toString().trim().equals("") ? "0" : datoBD.toString());
			esEliminado = !"0".equals(valorBD) && "0".equals(valorNuevo); 
		}
		else {
			listaSeries = (List<DatoSerie>) datoEnviado;
			listaSeriesBD = (List<DatoSerie>) datoBD;

			for (DatoSerie serie:listaSeries){
				
				DatoSerie serieBD = new DatoSerie();
				for(DatoSerie serieRealBD: listaSeriesBD){
					if(serieRealBD.getNumserie().equals(serie.getNumserie())){
						serieBD = serieRealBD;
						break;
					}
				}
	
				if( campo.equals("ConvenioInternacional")) {
					valorNuevo = serie.getCodconvinter()==null ? "0" : serie.getCodconvinter().toString();
					valorBD = serieBD.getCodconvinter()==null ? "0" : serieBD.getCodconvinter().toString();
					
				}
				else if( campo.equals("CodigoLiberatorio")) {
					valorNuevo = serie.getCodliberatorio()==null ? "0" : serie.getCodliberatorio().toString();
					valorBD = serieBD.getCodliberatorio()==null ? "0" : serieBD.getCodliberatorio().toString();
				}
				else if( campo.equals("PartidaNabandina")) {
					valorNuevo = serie.getNumpartnaban()!=null && !serie.getNumpartnaban().trim().equals("") ? serie.getNumpartnaban() : "0"; 
					valorBD = serieBD.getNumpartnaban()!=null && !serieBD.getNumpartnaban().trim().equals("") ? serieBD.getNumpartnaban() : "0";
				}
	
				if( "0".equals(valorNuevo) )
					esEliminado = true;
				else 
					esEliminado = false;
				
				if( !esEliminado ) break;
			} //Final FOR principal
		}
		return esEliminado;
	}


	private List<Map<String,?>> validarIndicadoresPECO(Declaracion declaracion, String codTransaccion ){
		return validarIndicadoresPECO(declaracion, codTransaccion, "" );
	}
	
	
	private List<Map<String,?>> validarIndicadoresPECO(Declaracion declaracion, String codTransaccion, String operacion){
		ResponseListManager responseListManager = new ResponseListManager();
		
		if(log.isDebugEnabled()) log.debug("**** Inicio: validarIndicadoresPECO **** ");
		
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		boolean tieneIndicadorAcogimiento   = ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_ACOGIMIENTO_POSTERIOR.equals(verificarIndicadorDeclarado(declaracion, ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_ACOGIMIENTO_POSTERIOR));
		boolean tieneIndicadorDesistimiento = ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_DESISTIMIENTO.equals(verificarIndicadorDeclarado(declaracion, ConstantesDataCatalogo.INDICADOR_PECO_AMAZONIA_DESISTIMIENTO));
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		String momento = "";
		if( tieneIndicadorAcogimiento || tieneIndicadorDesistimiento ) {
			if(codTransaccion.equals(ConstantesDataCatalogo.TRANS_NUMERACION_IMPORTACION_DEFINITIVA)) {
				momento = "EN TRANSACCION DE NUMERACION";
				if( tieneIndicadorAcogimiento )
					listError.add(catalogoAyudaService.getError(ERR_NO_DEBE_ENVIAR_INDICADOR, new String[] {"ACOGIMIENTO POSTERIOR A LEY DE AMAZONIA", momento}));
				if( tieneIndicadorDesistimiento )
					listError.add(catalogoAyudaService.getError(ERR_NO_DEBE_ENVIAR_INDICADOR, new String[] {"DESISTIMIENTO DE BENEFICIO PECO/AMAZONIA", momento}));
			}
			else if(codTransaccion.equals(ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA)) {
				if( operacion.equals("") ) {  //Rectificacion antes del Levante 
					momento = "ANTES DEL LEVANTE";
					if( tieneIndicadorAcogimiento )
						listError.add(catalogoAyudaService.getError(ERR_NO_DEBE_ENVIAR_INDICADOR, new String[] {"ACOGIMIENTO POSTERIOR A LEY DE AMAZONIA", momento}));
					if( tieneIndicadorDesistimiento )
						listError.add(catalogoAyudaService.getError(ERR_NO_DEBE_ENVIAR_INDICADOR, new String[] {"DESISTIMIENTO DE BENEFICIO PECO/AMAZONIA", momento}));
				}
				else if( operacion.equals("ACOGIMIENTO") ) {  //Rectificacion antes del Levante 
					momento = "AL ESTAR SOLICITANDO ACOGIMIENTO POSTERIOR";
					if( tieneIndicadorDesistimiento )
						listError.add(catalogoAyudaService.getError(ERR_NO_DEBE_ENVIAR_INDICADOR, new String[] {"DESISTIMIENTO DE BENEFICIO PECO/AMAZONIA", momento}));
				}
				else if( operacion.equals("DESISTIMIENTO") ) {  //Rectificacion antes del Levante 
					momento = "AL ESTAR SOLICITANDO DESISTIMIENTO DEL BENEFICIO PECO/AMAZONIA";
					if( tieneIndicadorAcogimiento )
						listError.add(catalogoAyudaService.getError(ERR_NO_DEBE_ENVIAR_INDICADOR, new String[] {"ACOGIMIENTO POSTERIOR A LEY DE AMAZONIA", momento}));
				}
				else { 
					momento = "POR NO CORRESPONDER A LA RECTIFICACION SOLICITADA";
					if( tieneIndicadorAcogimiento )
						listError.add(catalogoAyudaService.getError(ERR_NO_DEBE_ENVIAR_INDICADOR, new String[] {"ACOGIMIENTO POSTERIOR A LEY DE AMAZONIA", momento}));
					if( tieneIndicadorDesistimiento )
						listError.add(catalogoAyudaService.getError(ERR_NO_DEBE_ENVIAR_INDICADOR, new String[] {"DESISTIMIENTO DE BENEFICIO PECO/AMAZONIA", momento}));
				}
			}
			responseListManager.addResponseList1(listError); 
		}
		
		return responseListManager.getResponseList();
	}

	
	/*
	public CatalogoValidaService getCatalogoValidaService() {
		return catalogoValidaService;
	}
	
	public void setCatalogoValidaService(CatalogoValidaService catalogoValidaService) {
		this.catalogoValidaService = catalogoValidaService;
	}
	
	public AyudaService getAyudaService() {
		return ayudaService;
	}
	
	public void setAyudaService(AyudaService ayudaService) {
		this.ayudaService = ayudaService;
	}
	
	
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}