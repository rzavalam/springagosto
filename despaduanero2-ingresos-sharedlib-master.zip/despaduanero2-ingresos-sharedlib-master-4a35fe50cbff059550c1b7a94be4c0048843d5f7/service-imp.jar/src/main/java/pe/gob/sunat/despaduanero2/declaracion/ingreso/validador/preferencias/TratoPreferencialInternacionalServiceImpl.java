package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.SolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.TratoPreferencialInternacionalService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * Metodos necesarios y comunes para las validaciones de los Tratos Preferenciales Internacionales
 * @author rbegazo
 *
 */
public class TratoPreferencialInternacionalServiceImpl extends ValDuaAbstract implements TratoPreferencialInternacionalService {

	public static final String CATALOGO_ASOCIACION_TLC_SERVICIO= "126";
	private static final String GRUPO_TLC_MODIFICACION_FECHA_CO = "609";
	//private FabricaDeServicios	fabricaDeServicios;
		
	//rpumacayo 70
    //private CatalogoAyudaService catalogoAyudaService;
	//rpumacayo 70	
	
	/**
	 * Verifica si debe validar bajo el nuevo esquema de TLCs.
	 * @param serie
	 * @param variablesIngreso
	 */
	
	@ServicioAnnot(tipo="V",codServicio=3333, descServicio="validacion de tlcs")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=3333,numSecEjec=25,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarTratoPreferenciaInternacional(DatoSerie serie, Map<String, Object> variablesIngreso){
		Map<String, String> listError = new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		boolean indValidaTLC;
		Integer codConvenio = serie.getCodconvinter();
		if (codConvenio ==null) {
			indValidaTLC = false;
		} else {
//			indValidaTLC = catalogoHelper.isValid(codConvenio.toString(), ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS);
			//glazaror... hacer uso de utilitario IngresoVariablesUtil para validar elementos de catalogos
			indValidaTLC = IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString(), variablesIngreso);
			//indValidaTLC = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
		}
		// Si se determina que debe validar bajo el nuevo esquema de TLCs, pero no enviar CO, no tiene sentido aplicar validaciones
		// por lo que se envia el error y se setea la variable en false
		if (indValidaTLC) {
			DUA dua =  (DUA) serie.getPadre();
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
			if (listCertificadoOrigen.isEmpty() || listCertificadoOrigen == null){
				//glazaror... evitamos el uso de catalogoHelper.getErrorMap
//				listError = catalogoHelper.getErrorMap("30749", new String[] {serie.getNumserie().toString(),codConvenio.toString()});
				//glazaror... hacemos uso de catalogoAyudaService.getError
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30749", new String[] {serie.getNumserie().toString(),codConvenio.toString(), serie.getNumserie().toString()});
				indValidaTLC = false;
			}
		}
		variablesIngreso.put("indValidaTLC", indValidaTLC);		
		return listError;
	}
	

	
	/**
	 * Identifica si un determinado servicio deber� ser ejecutado como parte de la validaci�n de los TLC, invocado por dato general de la declaracion
	 * @param o
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	//se deberia usar un solo metodo para validar servicio tlc rin peru -corea msnade236_1
	@Deprecated
	public boolean validarServicioTLC (Object o, DatoSerie serie, Date fechaReferencia, List<String> serviciosTLC){
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
		boolean res = false;
		boolean indValidaTLC = true;
		Integer codConvenio = serie.getCodconvinter();
		if (codConvenio ==null) {
			indValidaTLC = false;
		}
		//else {
//			indValidaTLC = catalogoHelper.isValid(codConvenio.toString(), ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS);	
		//	indValidaTLC = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, codConvenio.toString()));
		//}				
		if (indValidaTLC){
			String codServicio = SunatStringUtils.toStringObj(GeneralUtils.getCurrentMethod(o).getAnnotation(ServicioAnnot.class).codServicio());
			List<String>  listServicios = obtenerServiciosAsociados(fechaReferencia, serviciosTLC);
			if (!CollectionUtils.isEmpty(listServicios)){
				if (listServicios.indexOf(codConvenio.toString().concat(codServicio)) > -1){					
					res = true;
				}
			}
		}
		return res;
	}
	
	
	/**
	 * Identifica si un determinado servicio deber� ser ejecutado como parte de la validaci�n de los TLC
	 * @param o
	 * @param serie
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @return
	 */
	public boolean validarServicioTLC (Object o, DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso){
		boolean res = false;
		//glazaror... esta linea de codigo para obtener codigo de servicio es invocada muchas veces... se debe evaluar si puede ser hardcodeado
		//por el momento se mueve esta linea de codigo siempre y cuando cumpla la condicion de indValidaTLC
		//String codServicio = SunatStringUtils.toStringObj(GeneralUtils.getCurrentMethod(o).getAnnotation(ServicioAnnot.class).codServicio());

		//glazaror msnade236_1... defino a este nivel la variable codigoServicio para poder reutilizarla en el nuevo metodo de validacion isFechaVigenteParaTipoCertificado
		String codServicio = null;
		
		if(variablesIngreso.get("indValidaTLC")!=null){
			boolean indValidaTLC=(Boolean)variablesIngreso.get("indValidaTLC");

			if (indValidaTLC){
				Integer codConvenio = serie.getCodconvinter();
				List<String>  listServicios = obtenerServiciosAsociados(fechaReferencia, variablesIngreso);
				if (!CollectionUtils.isEmpty(listServicios)){
					//glazaror... se obtiene el codigo de servicio solo cuando se encuentran una lista de servicios
					//glazaror msnade236_1... como la variable ya la he definido en un bloque superior elimino la definicion en este punto
					//String codServicio = SunatStringUtils.toStringObj(GeneralUtils.getCurrentMethod(o).getAnnotation(ServicioAnnot.class).codServicio());
					codServicio = SunatStringUtils.toStringObj(GeneralUtils.getCurrentMethod(o).getAnnotation(ServicioAnnot.class).codServicio());
					//for (Map<String, String> listServicio : listServicios){
					if (listServicios.indexOf(codConvenio.toString().concat(codServicio)) > -1){					
						res = true;
					}
				}
			}
		}
		//glazaror msnade236_1... ahora validamos que la fecha de certificado de origen y la fecha actual sean validas de acuerdo al tipo de certificado
		if (res) {
			ControlVigenciaTPIService controlVigenciaService = ((ControlVigenciaTPIService) fabricaDeServicios.getService("controlVigenciaTPIService"));
			res = controlVigenciaService.isServicioVigente(variablesIngreso, serie, fechaReferencia, codServicio);
		}
		return res;
	}
	
	/**
	 * Obtiene la asociacion del Trato Preferencial Internacional TPI  con los servicios asociados
	 * @param codConvenio
	 * @param fechaReferencia
	 * @return
	 */
	private List<String>  obtenerServiciosAsociados(Date fechaReferencia, List<String> serviciosTLC) {
		if(CollectionUtils.isEmpty(serviciosTLC)){
			List<Map<String, String>> listServiciosCatalogo =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getListaAsociado(CATALOGO_ASOCIACION_TLC_SERVICIO, fechaReferencia);
			for (Map<String, String> listServicioCatalogo : listServiciosCatalogo){
				String pkServicioTLC = listServicioCatalogo.get("cod_datacat").concat(listServicioCatalogo.get("cod_datacatasoc"));
				serviciosTLC.add(pkServicioTLC);
			}			
		} 
		return serviciosTLC;
	}
	
	private List<String>  obtenerServiciosAsociados(Date fechaReferencia, Map<String, Object> variablesIngreso) {
		List<String> listServicios = new ArrayList<String>();
		if(variablesIngreso.get("serviciosTLC")==null){
			//listServicios =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getListaElementosAsoc(CATALOGO_ASOCIACION_TLC_SERVICIO, "C",SunatStringUtils.toStringObj(codConvenio),fechaReferencia);
			List<Map<String, String>> listServiciosCatalogo =  ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getListaAsociado(CATALOGO_ASOCIACION_TLC_SERVICIO, fechaReferencia);
			for (Map<String, String> listServicioCatalogo : listServiciosCatalogo){
				String pkServicioTLC = listServicioCatalogo.get("cod_datacat").concat(listServicioCatalogo.get("cod_datacatasoc"));
				listServicios.add(pkServicioTLC);
			}			
			variablesIngreso.put("serviciosTLC", listServicios);
		} else{
			listServicios = (List<String>)variablesIngreso.get("serviciosTLC");
		}
		return listServicios;
	}
	
    
	/**
	 * Permite obtener el valor del atributo dentro del modelo de catalogos el cual se encuentra asociado a un determinado TLC
	 * @param codAtributo
	 * @param codGrupo
	 * @param codTipoCat
	 * @param codElemento
	 * @return
	 */
	// rtineo optimizacion
	public String obtenerAtributo(String codAtributo, String codGrupo, String codTipoCat, String codElemento, Map<String, Object> variablesIngreso){
		if (variablesIngreso != null) {
			//verificamos si ya fue cargado anteriormente el grupo de montos tope de factura
			String identificadorGrupo = "grupoAtributo" + codAtributo;
			Map<String, String> grupoAtributos = (Map<String, String>) variablesIngreso.get(identificadorGrupo);
			if (grupoAtributos == null) {
				//entonces cargamos por unica vez los montos tope de factura
				grupoAtributos = cargarGrupoAtributos(codAtributo,variablesIngreso);
			}
			return grupoAtributos.get(codElemento);
		}else{
			Map<String, Object> ayudaAtributoGrupo = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataAtributo(
					codAtributo, codGrupo, codTipoCat, codElemento);
			String val_atributo = ayudaAtributoGrupo.get("val_atributo") == null ? null:ayudaAtributoGrupo.get("val_atributo").toString();
			return val_atributo;
		}
	}
	
	public String obtenerAtributo(String codAtributo, String codGrupo, String codTipoCat, String codElemento){
		return obtenerAtributo(codAtributo,codGrupo,codTipoCat,codElemento,null);
	}
	
	//fin optimizacion
	
	/**Pase548 II
	 * Permite determinar si previamente a la rectificaci�n se declar� TPI (no es primera vez)
	 * @param serie
	 * @param declaracionBD
	 * @return
	 */
	public boolean esRectificacionTPI (DatoSerie serie, Declaracion declaracionBD ) {
		boolean esTPIRectificado = false;
		int serieXML = 0;
		int tpiXML = 0;
		List<DatoSerie> seriesBD = declaracionBD.getDua().getListSeries();
		
		serieXML = serie.getNumserie();
		tpiXML = serie.getCodconvinter();
		//EGH_PAS20165E220100028
		boolean encontro = false;
		for (DatoSerie serieBD:seriesBD){
			if (serieXML == serieBD.getNumserie()) {
				//EGH_PAS20165E220100028
				encontro = true;
				/*actualizacion por ajustes con normativa 10/12/2014*/
				if ((serieBD.getCodconvinter()==null || serieBD.getCodconvinter()==0) && tpiXML !=0){
					esTPIRectificado = true;//acogido por primera vez (TPIBD=0,  TPIXML!=0)
				}				
				if (serieBD.getCodconvinter()!=null && serieBD.getCodconvinter()!=0 && tpiXML !=0  && tpiXML != serieBD.getCodconvinter()){
					esTPIRectificado = true;//acogido por primera vez (TPIBD!=0 , TPIXML!=0, TPIBD != TPIXML)
				}
				// Si es el mismo TPI y estan cambiando la Fecha del Certificado de Origen, tambien se considera una rectificacion
				//glazaror msnade236_1... el metodo "esRectificacionFechaCertiOrigen" se paso a clase ValDuaAbstract para ser reusado en distintas clases especializadas... le pasamos adicionalmente fabricaDeServicios 
				if (serieBD.getCodconvinter()!=null && serieBD.getCodconvinter()!=0 && tpiXML !=0  && tpiXML == serieBD.getCodconvinter()
						&& esRectificacionFechaCertiOrigen(fabricaDeServicios, serie,declaracionBD.getDua(),serieBD) ) {
					esTPIRectificado = true;//fecha de CO diferente (TPIBD!=0 , TPIXML!=0, TPIBD == TPIXML)
				}
				break;
				/*actualizacion por ajustes con normativa 10/12/2014*/
			}				
		}	
		//EGH_PAS20165E220100028
		if(!encontro) esTPIRectificado = true;
		return esTPIRectificado;
	}
	//TLC Corea 2016-66
	//Se obtiene la fecha de referencia para validacion de plazos cuando la fecha de CO ha sido modificado
	//Si no hay una transmision previa Ej. Regularizacion, la fecha de refencia es la actual
	//Si hay transmision evalua si se cambio el dato en la diligencia y toma la fecha de diligencia
	//si no se cambio el dato en la diligencia toma la fecha de transmision
	public Date obtenerFechaReferenciaCOEnEvaluacion(DatoAutocertificacion certiOrigen,Map<String, Object> variablesIngreso){
		Date fechaReferencia = new Date();
		if(certiOrigen.getCambioCertiEvaluacion()!=null){
			return fechaReferencia;
		}else{
			if(variablesIngreso.get("cabSolicitudParaValidacionTLC") != null){
				SolicitudRectificacionBean solicitud = (SolicitudRectificacionBean)variablesIngreso.get("cabSolicitudParaValidacionTLC"); 
				fechaReferencia = solicitud.getFec_solicitud();
			}
		}
		
		return fechaReferencia;
	}
	//fin TLC Corea
	
	/**
	 * Se verifica si cuando se modifica la Fecha del Certificado de Origen, el TPI debe tomar la Fecha de referencia la Fecha en que se realiza la Modificacion.
	 * @param serie
	 * @param duaBD
	 * @param serieBD
	 * @return
	 */
	//glazaror msnade236_1... se mueve a clase padre ValDuaAbstract para poder reutilizar este metodo en otras clases especializadas
	/*private boolean esRectificacionFechaCertiOrigen(DatoSerie serie, DUA duaBD, DatoSerie serieBD) {
		boolean esDiferenteFechaCO = false;//se cambia nombre porque detecta que hay cambios de fecha de CO entre BD y XML TPI814
		
		String codTPI = serie.getCodconvinter().toString();
		//Inicio EGH_INGRESO
		//DataGrupoCat dato = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataGrupoCat(GRUPO_TLC_MODIFICACION_FECHA_CO, codTPI);
		
		//if (dato != null){
			
			DUA dua = (DUA) serie.getPadre();
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
			List<DatoAutocertificacion> listCertificadoOrigenBD=getCertiOrigen(duaBD, serieBD);
			
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Date fecemisionBD =!CollectionUtils.isEmpty(listCertificadoOrigenBD)?listCertificadoOrigenBD.get(0).getFecemision():SunatDateUtils.getDefaultDate();
			
			if (SunatDateUtils.compareDate(fecemision, fecemisionBD) != 0){
				// Esta rectificando la Fecha del Certificado de Origen
				esDiferenteFechaCO = true;
			}
		//}
		//Fin EGH_INGRESO
		return esDiferenteFechaCO;
	}*/
	
	/**Pase548 II
	 * Permite determinar si es una recti con el mismo TPI
	 * @param serie
	 * @param declaracionBD
	 * @return
	 */
	public boolean esMismoTPI (DatoSerie serie, Declaracion declaracionBD ) {
		boolean esMismoTPI = false;
		int serieXML = 0;
		int tpiXML = 0;
		List<DatoSerie> seriesBD = declaracionBD.getDua().getListSeries();
		
		serieXML = serie.getNumserie();
		tpiXML = serie.getCodconvinter();
		for (DatoSerie serieBD:seriesBD){
			if (serieXML == serieBD.getNumserie()) {
				if (serieBD.getCodconvinter()!=null && serieBD.getCodconvinter()!=0 && tpiXML == serieBD.getCodconvinter()){
					esMismoTPI = true;//TPI xml igual a bd (TPIBD!=0 , TPIXML!=0, TPIBD = TPIXML)
				}
				break;
			}				
		}	
		return esMismoTPI;
	}

	private Map<String, String> cargarGrupoAtributos(String codigoAtributo, Map<String, Object> variablesIngreso) {
		//glazaror msnade236_1... para mantener la logica anterior pasamos en duro las constantes de grupo y catalogo tal como la parte comentada 
		return IngresoVariablesUtil.cargarGrupoAtributos(fabricaDeServicios, codigoAtributo, ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, variablesIngreso);
	}
	
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}