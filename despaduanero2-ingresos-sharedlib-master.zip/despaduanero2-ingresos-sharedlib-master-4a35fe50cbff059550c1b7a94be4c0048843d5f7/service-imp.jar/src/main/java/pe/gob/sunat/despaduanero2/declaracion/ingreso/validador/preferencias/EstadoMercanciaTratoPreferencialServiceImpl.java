package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.EstadoMercanciaTratoPreferencialService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.CatalogoHelperImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Metodos asociados a validacion de estado de mercancias en sus diferentes formas y usos
 * @author rbegazo
 *
 */
public class EstadoMercanciaTratoPreferencialServiceImpl extends IngresoAbstractServiceImpl implements	EstadoMercanciaTratoPreferencialService {
	
	public static final String TIPO_MARGEN_REMANUFACTURADO= "4";
	public static final Long  NUM_SUBPARTIDA_ESTADO_INICIO = 8703100000L;
	public static final Long  NUM_SUBPARTIDA_ESTADO_FINAL  = 8703900090L;

	//private FabricaDeServicios	fabricaDeServicios;

	private static final String GRUPO_TLC_ESTADO_MERCANCIA_NUEVO = "709";//PAS20155E220200172 TPI 814-PERU HONDURAS
	public static final String GRUPO_ESTADO_MERCANCIA_NUEVO_VIG   = "710";//PAS20155E220200172 TPI 814-PERU HONDURAS
	
	
	/**
	 * Valida el estado de la mercancia.
	 * Si es que el tipo de margen es remanufacturado (4) se valida de la forma antigua (servicio 3338), de lo contrario se valida que el estado
	 * de la mercancia exista en el grupo de catalogo 710.
	 * Creado para el proyecto MSNADE236-6
	 * @param serie Serie que esta siendo evaluada
	 * @param variablesIngreso Variables usadas en el procesamiento
	 * @param fechaReferencia fecha de numeracion
	 * @return errores de validacion (en caso de que el estado de mercancia no sea valido)
	 * @author glazaror
	 */
	@Override
	@ServicioAnnot(tipo="V",codServicio=3472, descServicio="	")
	@ServInstDetAnnot(tipoRpta={1,1}, nomAtr={"serie", "variablesIngreso", "fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3472, numSecEjec=99, nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarEstadoMercancia(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		Map<String, String> erroresValidacion = new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)) {
			return erroresValidacion;
		}
		//verificamos si es que el tipo de margen es 4
		String codigoTipoMargen = serie.getCodtipomarge();
		String codigoEstadoMercancia = serie.getCodestamerca();
		Integer codigoConvenio = serie.getCodconvinter();
		if (!SunatStringUtils.isEqualTo(codigoTipoMargen, TIPO_MARGEN_REMANUFACTURADO)) {
			//segun correo de normativo indicando que si es TM=4 no aplica la validacion del estado de la mercancia
//			//glazaror... si es que el tipo de margen es igual a 4 entonces se ejecutara la logica anterior de validacion de mercancia
//			return validarEstadoMercanciaAnterior(serie, fechaReferencia, variablesIngreso);
//		} else {
			//glazaror este servicio XXX1 solo valida que el estado de mercancia sea valido en el grupo 710
			if (!IngresoVariablesUtil.isElementoGrupoValido(fabricaDeServicios, GRUPO_ESTADO_MERCANCIA_NUEVO_VIG, SunatStringUtils.toNotNull(codigoEstadoMercancia), variablesIngreso)) {
				CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
				erroresValidacion = catalogoAyudaService.getError("30680", new String[] {serie.getNumserie().toString(), codigoEstadoMercancia, codigoConvenio.toString()});
			}
		}
		return erroresValidacion;
	}

	/**
	 * Valida el estado de la mercancia.
	 * Si tipo de margen es remanufacturado(4) se valida de la forma antigua (servicio 3453).
	 * Si numero de subpartida esta en el rango 8703100000-8703900090 se valida que el estado de mercancia exista en el grupo catalogo 710,
	 * de lo contrario se valida que el estado de mercancia exista en el catalogo general de estados de mercancia 25.
	 * Creado para el proyecto MSNADE236-6
	 * @param serie Serie que esta siendo evaluada
	 * @param variablesIngreso Variables usadas en el procesamiento
	 * @param fechaReferencia fecha de numeracion
	 * @return errores de validacion (en caso de que el estado de mercancia no sea valido)
	 * @author glazaror
	 */
	@Override
	@ServicioAnnot(tipo="V",codServicio=3473, descServicio="	")
	@ServInstDetAnnot(tipoRpta={1,1}, nomAtr={"serie", "variablesIngreso", "fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3473, numSecEjec=99, nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarEstadoMercanciaConEvaluacionRangoSubpartida(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		Map<String, String> erroresValidacion = new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)) {
			return erroresValidacion;
		}
		//verificamos si es que el tipo de margen es 4
		String codigoTipoMargen = serie.getCodtipomarge();
		String codigoEstadoMercancia = serie.getCodestamerca();
		Integer codigoConvenio = serie.getCodconvinter();
		if (!SunatStringUtils.isEqualTo(codigoTipoMargen, TIPO_MARGEN_REMANUFACTURADO)) {
			//segun correo de normativo indicando que si es TM=4 no aplica la validacion del estado de la mercancia
//			//glazaror... si es que el tipo de margen es igual a 4 entonces se ejecutara la logica anterior de validacion de mercancia
//			return validarEstadoMercanciaSubPartidaAnterior(serie, variablesIngreso, fechaReferencia);
//		} else {
			CatalogoAyudaService catalogoAyudaService = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService"));
			// Si se encuentran en un rango de partidas no aplica esta regla
			Long subPartidaNacional = serie.getNumpartnandi();
			if (SunatNumberUtils.isLessThanParam(subPartidaNacional,  NUM_SUBPARTIDA_ESTADO_INICIO) || SunatNumberUtils.isGreaterThanParam(subPartidaNacional,  NUM_SUBPARTIDA_ESTADO_FINAL)) {
				//glazaror este servicio XXX2 solo valida que el estado de mercancia sea valido en el grupo 710
				if (!IngresoVariablesUtil.isElementoGrupoValido(fabricaDeServicios, GRUPO_ESTADO_MERCANCIA_NUEVO_VIG, SunatStringUtils.toNotNull(codigoEstadoMercancia), variablesIngreso)) {
					erroresValidacion = catalogoAyudaService.getError("30680", new String[] {serie.getNumserie().toString(), codigoEstadoMercancia, codigoConvenio.toString()});
				}
			} else {
				//entonces verificamos que el estado de mercancia sea parte del catalogo general de estados de mercancia (catalogo 25)
				if (!IngresoVariablesUtil.isElementoCatalogoValido(fabricaDeServicios, ConstantesDataCatalogo.COD_CATALOGO_ESTADO_MERCANCIA, SunatStringUtils.toNotNull(codigoEstadoMercancia), variablesIngreso)) {
					erroresValidacion = catalogoAyudaService.getError("30680", new String[] {serie.getNumserie().toString(), codigoEstadoMercancia, codigoConvenio.toString()});
				}
			}
		}
		return erroresValidacion;
	}
	
	@ServicioAnnot(tipo="V",codServicio=3338, descServicio="	")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3338,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarEstadoNuevoMercancia(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		Map<String, String> listError=new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//glazaror... para declaraciones numeradas antes de la puesta en produccion se ejecutara la logica anterior de validacion de mercancia
		return validarEstadoMercanciaAnterior(serie, fechaReferencia, variablesIngreso);
	}
	
	@ServicioAnnot(tipo="V",codServicio=3453, descServicio="	")
	@ServInstDetAnnot(tipoRpta={1,1},nomAtr={"serie","variablesIngreso","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3453,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> validarEstadoNuevoMercanciaSubPartida(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		Map<String, String> listError=new HashMap<String, String>();
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia,variablesIngreso)){
			return listError;
		}
		//glazaror... para declaraciones numeradas antes de la puesta en produccion se ejecutara la logica anterior de validacion de mercancia
		return validarEstadoMercanciaSubPartidaAnterior(serie, variablesIngreso, fechaReferencia);
	}

	
	/**
	 * Valida el estado de mercancia Usada
	 */
	public Map<String, String> validarEstadoUsadoMercancia(String numSerie, String codEstmerca, Date fechaReferencia) {
		//glazaror... invocamos al nuevo metodo para mantener la logica en un solo metodo pasandole null en variablesIngreso
		return validarEstadoUsadoMercancia(numSerie, codEstmerca, fechaReferencia, null);
		/*Map<String, String> listError=new HashMap<String, String>();
//		CatalogoHelperImpl catalogoHelper = fabricaDeServicios.getService("catalogoHelper");
//		if (!CollectionUtils.isEmpty(catalogoHelper.getCatalogoValidacionService().validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_ESTADO_MERCANCIA_USADO, SunatStringUtils.toNotNull(codEstmerca)))){
		if (!CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_ESTADO_MERCANCIA_USADO, SunatStringUtils.toNotNull(codEstmerca)))){
//				listError = catalogoHelper.getErrorMap("XX11", new String[] {numSerie, codEstmerca});		
			listError= ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30662",new String[] { numSerie, codEstmerca });			
		}
		return listError;*/
	}
	
	//glazaror... metodo optimizado
	@Override
	public Map<String, String> validarEstadoUsadoMercancia(String numSerie, String codEstmerca, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		Map<String, String> listError=new HashMap<String, String>();

		//glazaror... para hacer validaciones a nivel de detalle se debe usar IngresoVariablesUtil
		//if (!CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_ESTADO_MERCANCIA_USADO, SunatStringUtils.toNotNull(codEstmerca)))){
		if (!IngresoVariablesUtil.isElementoGrupoValido(fabricaDeServicios, ConstantesGrupoCatalogo.GRUPO_ESTADO_MERCANCIA_USADO, SunatStringUtils.toNotNull(codEstmerca), variablesIngreso)) {
			listError= ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30662",new String[] { numSerie, codEstmerca });			
		}
		return listError;
	}


	//glazaror msnade236-6
	//se mantiene logica actual de validacion del estado de mercancia para los TPI 338, 358, 804, 805, 808, 809, 810, 811, 813, 814
	private Map<String, String> validarEstadoMercanciaAnterior(DatoSerie serie, Date fechaReferencia, Map<String, Object> variablesIngreso) {
		Map<String, String> listError = new HashMap<String, String>();
		/*TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		if (!tpiService.validarServicioTLC (this, serie, fechaReferencia, variablesIngreso)){
			return listError;
		}*/
		String codTipomarge = serie.getCodtipomarge();
		String codEstmerca  = serie.getCodestamerca();
		Integer codConvenio = serie.getCodconvinter();
		
		//inicio de ajustes pase PAS20155E220200172 TPI 814-PERU HONDURAS
		DataGrupoCat dato = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataGrupoCat(GRUPO_TLC_ESTADO_MERCANCIA_NUEVO, codConvenio.toString());
		if (dato != null) {
			if (!IngresoVariablesUtil.isElementoGrupoValido(fabricaDeServicios, GRUPO_ESTADO_MERCANCIA_NUEVO_VIG, SunatStringUtils.toNotNull(codEstmerca), variablesIngreso)) {
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30680", new String[] {serie.getNumserie().toString(),codEstmerca,codConvenio.toString()});
			}
		} else {
			//fin de ajustes pase PAS20155E220200172 TPI 814-PERU HONDURAS
			if (!IngresoVariablesUtil.isElementoGrupoValido(fabricaDeServicios, ConstantesGrupoCatalogo.GRUPO_ESTADO_MERCANCIA_NUEVO, SunatStringUtils.toNotNull(codEstmerca), variablesIngreso)) {
				if (SunatStringUtils.isEqualTo(codEstmerca,ConstantesDataCatalogo.COD_ESTADO_USADO_REMANUFATURADO)) {
					if (!SunatStringUtils.isEqualTo(codTipomarge,TIPO_MARGEN_REMANUFACTURADO)) {
						listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30680", new String[] {serie.getNumserie().toString(),codEstmerca,codConvenio.toString()});
					}
				}else{
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30680", new String[] {serie.getNumserie().toString(),codEstmerca,codConvenio.toString()});
				}			
			}
		}//TPI 814
		return listError;
	}
	
	//glazaror msnade236-6
	//se mantiene logica actual de validacion del estado de mercancia para el TPI 806
	public Map<String, String> validarEstadoMercanciaSubPartidaAnterior(DatoSerie serie, Map<String, Object> variablesIngreso, Date fechaReferencia) {
		Map<String, String> listError = new HashMap<String, String>();
		
		String codTipomarge = serie.getCodtipomarge();
		String codEstmerca  = serie.getCodestamerca();
		Integer codConvenio = serie.getCodconvinter();
		if (!CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoGrupo(ConstantesGrupoCatalogo.GRUPO_ESTADO_MERCANCIA_NUEVO, SunatStringUtils.toNotNull(codEstmerca)))){
			if (SunatStringUtils.isEqualTo(codEstmerca,ConstantesDataCatalogo.COD_ESTADO_USADO_REMANUFATURADO)) {
				if (!SunatStringUtils.isEqualTo(codTipomarge,TIPO_MARGEN_REMANUFACTURADO)) {
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30680", new String[] {serie.getNumserie().toString(),codEstmerca,codConvenio.toString()});
				}
			}else{
				// Si se encuentran en un rango de partidas no aplica esta regla
				Long subPartidaNacional = serie.getNumpartnandi();
				if (SunatNumberUtils.isLessThanParam(subPartidaNacional,  NUM_SUBPARTIDA_ESTADO_INICIO) || SunatNumberUtils.isGreaterThanParam(subPartidaNacional,  NUM_SUBPARTIDA_ESTADO_FINAL)){
					listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30680", new String[] {serie.getNumserie().toString(),codEstmerca,codConvenio.toString()});
				}
			}			
		}
		return listError;
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
	*/
}
