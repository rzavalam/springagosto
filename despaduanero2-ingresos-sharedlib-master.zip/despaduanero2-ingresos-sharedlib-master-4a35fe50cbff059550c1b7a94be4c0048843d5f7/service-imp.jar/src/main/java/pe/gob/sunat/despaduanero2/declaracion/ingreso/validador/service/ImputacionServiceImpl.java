package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DetPagodua;
import pe.gob.sunat.despaduanero2.declaracion.model.DeudaDocum;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeudaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Cambio1DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetPagoDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ImputacionServiceImpl implements ImputacionService {

	public DeudaDocumDAO deudaDocumeDAO;
	public CabDeudaDAO cabdeudaDAO;
	public DetPagoDuaDAO detpagoduaDAO;
	public Cambio1DAO cambio1DAO;
	protected CatalogoHelperImpl catalogoHelper;
	private ProveedorFuncionesService funcionesService;
	
	private AyudaService ayudaService;
/*
	public List<Map<String,String>> imputacion(Declaracion declaracion,Map<String,Object> deudaCalculada) throws Exception{
		
		List<Map<String, String>> resultadoError =new ArrayList<Map<String,String>>();
		
		
        boolean exigibilidad =false;
        if(declaracion.getDua().getFecdeclaracion()!=null && 
        		declaracion.getDua().getFecdeclaracion().after(DateUtil.stringToDate("26/08/2008"))){
        	exigibilidad=true;
        }
        
        boolean tienePagos=false;
        DetPagodua detPagoParam=new DetPagodua();
        detPagoParam.setNumCorredoc(declaracion.getDua().getNumcorredoc());
         List<DetPagodua> listPagos= detpagoduaDAO.selectByDocumento(detPagoParam);
         if(!CollectionUtils.isEmpty(listPagos))
        	 tienePagos=true;
         
         boolean fecterminoRectificado=true; // revisar
              
         boolean fecVencimientoDefault=false;
         Date fechaVencimiento=(Date) deudaCalculada.get("FECH_VENCI");
         if(DateUtil.isDefaultDate(fechaVencimiento)){
			 fecVencimientoDefault=true;
		 }         
        
         if(exigibilidad && tienePagos && fecVencimientoDefault && fecterminoRectificado){
        	 resultadoError.addAll(imputacionxPagos(declaracion, deudaCalculada));
         }
         
		
		return resultadoError;
		
	}*/
	
	public Map<String,Object> Spgenimputacion(Declaracion declaracion,Map<String,Object> deudaCalculada) throws Exception{

		//Map<String,Map<?,Object>> detalleImputacion=new HashMap<String, Map<?,Object>>();
		Map<String,Object> detalleImputacion=new HashMap<String,Object>();
		Map<String,BigDecimal> matrizTribxPagar= new HashMap<String, BigDecimal>();
    	Map<Long,Map<String,BigDecimal>> mapTribImputadosPago=new HashMap<Long, Map<String,BigDecimal>>();
		
		
		// 1  recibir parametros 
		String TCAduana    =declaracion.getNumdeclRef().getCodaduana();
        String Tcfano      =declaracion.getNumdeclRef().getAnnprese();
        String TcCodi_regi =declaracion.getNumdeclRef().getCodregimen();
        String Tcndcl      =declaracion.getNumdeclRef().getNumcorre();
        Date TcFechDesc  =declaracion.getDua().getManifiesto().getFectermino();
        Map<String, Object> params=new HashMap<String, Object>();
        
        /*2.- si tiene alguno de estos tipos de cancelacion se ignora la impuatacion 
          select  decode(decla.tipo_cance, 7,'S',51,'S',52,'S',53,'S',50,'S','N') into
           auxcondicional from dual;*/

        boolean aplicaImputacion=true;
        DeudaDocum deudaParam=new DeudaDocum();
        deudaParam.setNumCorredoc(declaracion.getDua().getNumcorredoc());
        List<DeudaDocum> lstDeuda= deudaDocumeDAO.selectByDocumento(deudaParam);
        if(!CollectionUtils.isEmpty(lstDeuda)){
        	for(DeudaDocum deuda:lstDeuda){
        		if(SunatStringUtils.isStringInList(deuda.getCodEstpago(), "7,51,52,53,50")){
        			aplicaImputacion=false;
        			break;
        		}
        	}
        }
        
		   if(aplicaImputacion){        
		        /*
		         * 
			3.- se obtiene monto Total de deuda a pagar 
			      SpGetTribxPagar(TCAduana   ,Tcfano     ,TcCodi_regi ,Tcndcl      ,
			    lnAnt.adv   ,lnAnt.igv   ,lnAnt.isc   ,lnAnt.ipm   ,
			    lnAnt.dump  ,lnAnt.des   ,lnAnt.ipa   ,lnAnt.sad   ,
			    lnAnt.com   ,lnAnt.sda   ,LnMonTotNum  , TcInvoca  );        
		         * */
		        
		        matrizTribxPagar= montoTotalAPagar(deudaCalculada);
		        
		        // 4.- obtener todos los pagos efectuados a la Deuda de la dua 
		         params=new HashMap<String, Object>();
		        params.put("numCorredoc", declaracion.getDua().getNumcorredoc());
		        params.put("columnasc", "FEC_PAGO");
		        List<DetPagodua> pagosDua=detpagoduaDAO.selectPagoByParams(params);
	    		Map<String,BigDecimal> mpSaldoPago=new HashMap<String, BigDecimal>();
		        BigDecimal tasaInteres=null;
		        BigDecimal interes=null;
	        	Date fechAnterior=null;
		        if(!CollectionUtils.isEmpty(pagosDua)){
		        	// 5.- Por cada �Pago hacer 
		        	Date fechActual=null;
		        	Date fecVencimiento=TcFechDesc;
		        	int iPago=1;
		        	for(DetPagodua pago:pagosDua){
		        		// para obtener un detalle de los montos imputados 
		        		Map<String,BigDecimal> mapMontosImputados=new HashMap<String, BigDecimal>();
		        		// el detalle esta relacionado a un pago
		        		mapTribImputadosPago.put(pago.getNumSecpago(), mapMontosImputados);
		        		
		        		BigDecimal  saldoImpuestos=sumarSaldoImpuestos(matrizTribxPagar);
		        		

		        		
		        		/*5.1 - Calcular interes desde la fecha del pago anterior a la fecha de pago actual  
		        		� si es el primer pago 
		        		desde la fecha vencimiento hasta la fecha del pago*/
		        		
		        		if(iPago==1){
		        			tasaInteres=interes_tim(SunatDateUtils.getIntegerFromDate(fecVencimiento), 
		        					 SunatDateUtils.getIntegerFromDate(pago.getFecPago()) , "D");
		        		}
		        		else{
		        			tasaInteres=interes_tim(SunatDateUtils.getIntegerFromDate(fechAnterior), 
		       					 SunatDateUtils.getIntegerFromDate(pago.getFecPago()) , "D");
		        			
		        		}
		        		
		        		// interes = saldo * tasainteres
		        		interes=SunatNumberUtils.multiply(saldoImpuestos, tasaInteres);
		        		
		        		matrizTribxPagar.put("INTERES", interes);
		        		BigDecimal lsaldopagoaux=pago.getMtoPagado();
		        		mpSaldoPago.put("PPagoaDistrib", lsaldopagoaux);
		        		
		        		imputarImpuestos(mpSaldoPago, matrizTribxPagar,mapMontosImputados);
		         		fechAnterior=pago.getFecPago();
		        	     iPago++;
		        	}
		        }
		    }
		   
		   detalleImputacion.put("detalleSaldoPendienteImputacion", matrizTribxPagar);
		   detalleImputacion.put("detalleMontosImputado", mapTribImputadosPago);
		return detalleImputacion;
	}
	
	
	public BigDecimal sumarSaldoImpuestos(Map<String,BigDecimal> matrizxpagar ){
		BigDecimal totalSaldoTributo = BigDecimal.ZERO;
		if(!CollectionUtils.isEmpty(matrizxpagar)){
		   for(String tributo :matrizxpagar.keySet()){
			   // No se considera el interes
				   totalSaldoTributo=SunatNumberUtils.sum(totalSaldoTributo, matrizxpagar.get(tributo));
		   }	
		}
		
		return totalSaldoTributo;
	}
	
	public BigDecimal sumarTotalImputadoxTributo(Map<Long,Map<String,BigDecimal>> detalleImputacion, String nomTributo ){
		BigDecimal totalmontoImputado = BigDecimal.ZERO;
		if(!CollectionUtils.isEmpty(detalleImputacion)){
			
		   for(Map<String,BigDecimal> infoImputacion :detalleImputacion.values()){
			   for(String tributo:infoImputacion.keySet()){
				   if(tributo.equals(nomTributo))
				   totalmontoImputado=SunatNumberUtils.sum(totalmontoImputado, infoImputacion.get(tributo));
			   }
		   	}	
		}
		
		return totalmontoImputado;
	}
	
	
	public BigDecimal interes_tim(Integer fecha_Venc, Integer fecha_act, String moneda){
		
		/*FUNCTION interes_tim(fecha_Venc number, fecha_act number, moneda varchar2)
		  RETURN NUMBER IS
		  LnRetorno NUMBER(11, 6) := 0;
		  qmoneda   varchar2(3);
		  inte_tim  NUMBER(11, 6) := 0;
		BEGIN
		  select decode(moneda, 'D', 'TI$', 'TIS') into qmoneda from dual;
		  if fecha_act <= fecha_Venc then
		    inte_tim := 0;
		  else
		    begin
		      select sum(nvl(pcompra,0))
		        into LnRetorno
		        from cambio1
		       where cmoneda = qmoneda
		         and fingreso between fecha_Venc and fecha_act;
		    EXCEPTION
		      WHEN no_data_found THEN
		        LnRetorno := 0;
		    end;

		    inte_tim := LnRetorno / 100;
		  end if;
		  RETURN inte_tim;
		END interes_tim;*/
		
		BigDecimal inte_tim=BigDecimal.ZERO;
		String qmoneda=moneda.equals("D")?"TI$":"TIS";
		BigDecimal LnRetorno=BigDecimal.ZERO;
		if(fecha_act.compareTo(fecha_Venc)<=0){
			
		}
		else{
			Map<String,Object> params=new HashMap<String, Object>();
			params.put("qmoneda", qmoneda);
			params.put("fecha_Venc", fecha_Venc);
			params.put("fecha_act", fecha_act);
//			LnRetorno=cambio1DAO.getsumpcompra(params);
			params.put("ayudaID", "Cambio1");
			LnRetorno = (BigDecimal)ayudaService.getsumpcompra(params);
			
			inte_tim=LnRetorno.divide(new BigDecimal(100));
			
		}
		return inte_tim;
	}
	

public void SPimputaTrib(Map<String,BigDecimal> mpSaldoPago
		,Map<String,BigDecimal> tributosxPagar,Map<String,BigDecimal> montosImputados, String nomTributo){
	/*procedure SPimputaTrib(
			PPagoaDistrib in out number,
			PimTrib in out number,
			PsTrib in out number,
			PMontoaimput in out number ) is
			begin
			  -- primero la imputacion y saldo a 0
			      PimTrib := 0;
			      PsTrib  := PMontoaimput;
			      --DBMS_OUTPUT.PUT_LINE ( 'trib  ');

			      --DBMS_OUTPUT.PUT_LINE ( 'a distrib:  '|| PPagoaDistrib );
			     -- DBMS_OUTPUT.PUT_LINE ( 'imputar: '|| PMontoaimput );
			      if PPagoaDistrib > 0 then
			        if (PPagoaDistrib >= PMontoaimput) then
		
			          PimTrib := PMontoaimput;
			          PsTrib  := 0;
			          PPagoaDistrib   := PPagoaDistrib - PMontoaimput;
			        else
			          PimTrib := PPagoaDistrib;
			          PsTrib  := PMontoaimput - PPagoaDistrib;
			          PPagoaDistrib   := 0;
			        end if;
			      else
			        PimTrib := 0;
			        PsTrib  := PMontoaimput;
			      end if;

			      --DBMS_OUTPUT.PUT_LINE ( 'imputado:  '|| PimTrib );
			      --DBMS_OUTPUT.PUT_LINE ( 'Saldo : '|| PPagoaDistrib );

			     -- DBMS_OUTPUT.PUT_LINE ( 'Saldo trib : '|| PsTrib );

			end SPimputaTrib;
	*/
	
	BigDecimal PPagoaDistrib=mpSaldoPago.get("PPagoaDistrib");
	BigDecimal PimTrib=BigDecimal.ZERO;
	BigDecimal PsTrib=null;
	BigDecimal PMontoaimput=tributosxPagar.get(nomTributo);

    PsTrib  = PMontoaimput;
    if(PPagoaDistrib.compareTo(BigDecimal.ZERO)>0){
    	if(PPagoaDistrib.compareTo(PMontoaimput)>=0){
	          PimTrib = PMontoaimput;
              PsTrib  = BigDecimal.ZERO;
              PPagoaDistrib  = SunatNumberUtils.diference(PPagoaDistrib, PMontoaimput);
    	}
    	else{
	          PimTrib = PPagoaDistrib;
    	      PsTrib  = SunatNumberUtils.diference(PMontoaimput, PPagoaDistrib)  ;
	          PPagoaDistrib  = BigDecimal.ZERO;
    	}
    }
    else{
        PimTrib = BigDecimal.ZERO;
    	PsTrib  = PMontoaimput;
    }

    
	mpSaldoPago.put("PPagoaDistrib",PPagoaDistrib); // saldo del pago 
	tributosxPagar.put(nomTributo,PsTrib); // saldo del tributo
	montosImputados.put(nomTributo, PimTrib);// monto imputado para el tributo
    
}
	
public List<Map<String,String>> verificarSaldo(Map<String,BigDecimal> matrizTribxPagar){
	List<Map<String,String>> lstResultadoError = new ArrayList<Map<String,String>>();
	Map<String,String> mensajeImputacion = null;
	
	if(!CollectionUtils.isEmpty(matrizTribxPagar)){
		for(String codTrib:matrizTribxPagar.keySet()){
			BigDecimal montoSaldo=matrizTribxPagar.get(codTrib);;
			if(montoSaldo!=null && montoSaldo.compareTo(BigDecimal.ZERO)>0){
				if(codTrib.equals("INTERES"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE INTERES:"+ montoSaldo );

				if(codTrib.equals("MTSERV"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE SERVICIO DE DESPACHO ADUANERO:"+ montoSaldo );

				if(codTrib.equals("MCOMM"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE TASA D.S. 003-96:"+ montoSaldo );
				
				if(codTrib.equals("MADUM"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE ANTIDUMPING / COMPENSATORIO:"+ montoSaldo );

				if(codTrib.equals("MADV"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE ADVALOREM:"+ montoSaldo );

				if(codTrib.equals("MSAD"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE SOBRETASA ADICIONAL:"+ montoSaldo );

				if(codTrib.equals("MDES"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE DERECHO ESPECIFICO:"+ montoSaldo );

				if(codTrib.equals("MIPM"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE IPM:"+ montoSaldo );

				if(codTrib.equals("MIPMA"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE IPM ADICIONAL:"+ montoSaldo );
				
				if(codTrib.equals("MISC"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE ISC:"+ montoSaldo );

				if(codTrib.equals("MIGV"))
					mensajeImputacion= catalogoHelper.getErrorMap("30279", "DEUDA PENDIENTE IGV:"+ montoSaldo );

				
			}
			lstResultadoError.add(mensajeImputacion);
		}
	}
     return lstResultadoError;
	
}



public Map<String,BigDecimal> montoTotalAPagar(Map<String,Object> deudaCalculada){
    Map<String,Object> parameterMap=new HashMap<String, Object>();
    
    Map<String,BigDecimal> matrizTribxPagar=new HashMap<String, BigDecimal>();
    
    if(!CollectionUtils.isEmpty(deudaCalculada)){
    	for(String tributo:deudaCalculada.keySet()){
    		BigDecimal monto=null;
    	if(tributo.equals("MTSERV_ACUMULADO")) {//MTSERV
    		monto=(BigDecimal)deudaCalculada.get(tributo);
    		matrizTribxPagar.put("MTSERV", monto);
    	}
		if(tributo.equals("MCOMM_ACUMULADO")) {//MCOMM
			monto=(BigDecimal)deudaCalculada.get(tributo);
		   matrizTribxPagar.put("MCOMM", monto);
	     }

		if(tributo.equals("MADUM_ACUMULADO")) {//MADUM
			monto=(BigDecimal)deudaCalculada.get(tributo);
		   matrizTribxPagar.put("MADUM", monto);
	     }
		
		if(tributo.equals("MADV_ACUMULADO")) {//MADV
			monto=(BigDecimal)deudaCalculada.get(tributo);
		    matrizTribxPagar.put("MADV", monto);
	     }
		if(tributo.equals("MSAD_ACUMULADO")) {//MSAD
			monto=(BigDecimal)deudaCalculada.get(tributo);
		   matrizTribxPagar.put("MSAD", monto);
		}
		
		if(tributo.equals("MDES_ACUMULADO")) {//MDES
			monto=(BigDecimal)deudaCalculada.get(tributo);
		   matrizTribxPagar.put("MDES", monto);
	     }

		if(tributo.equals("MIPM_ACUMULADO")) {//MIPM
			monto=(BigDecimal)deudaCalculada.get(tributo);
		   matrizTribxPagar.put("MIPM", monto);
	     }    		
		
		if(tributo.equals("MIPMA_ACUMULADO")) {//MIPMA
			monto=(BigDecimal)deudaCalculada.get(tributo);
		   matrizTribxPagar.put("MIPMA", monto);
	     }
		
		if(tributo.equals("MISC_ACUMULADO")) {//MISC
			monto=(BigDecimal)deudaCalculada.get(tributo);
		   matrizTribxPagar.put("MISC", monto);
	     }
		
		if(tributo.equals("MIGV_ACUMULADO")) {//MIGV
			monto=(BigDecimal)deudaCalculada.get(tributo);
		   matrizTribxPagar.put("MIGV", monto);
	     }    		    		    		
		
    }
   }
 return matrizTribxPagar;
}


private void imputarImpuestos(Map<String,BigDecimal> mpSaldoPago
		,Map<String,BigDecimal> matrizTribxPagar,Map<String,BigDecimal> montosImputados){
	 // INTERES
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "INTERES");
     // SERVICIO DE DESPACHO ADUANERO
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MTSERV");
    // -- TASA D.S. 003-96
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MCOMM");

        //-- ANTIDUMPING / COMPENSATORIO
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MADUM");
    
       //-- ADVALOREM
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MADV");
    
      //--SOBRETASA ADICIONAL
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MSAD");

     //--DERECHO ESPECIFICO
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MDES");
    
    //--   IPM
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MIPM");
    
       //--   IPM ADICIONAL
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MIPMA");
    
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MISC");
      //--   IGV
    SPimputaTrib(mpSaldoPago , matrizTribxPagar, montosImputados, "MIGV");

}

private BigDecimal totalAutoliquidacion(Declaracion declaracion,Map<String,Object> variablesIngreso){
	Map<String,BigDecimal> mapTributosAutoliquidacion= funcionesService.obtenerTributosAutoliquidacion(declaracion,variablesIngreso);
	BigDecimal totalAutoliq=BigDecimal.ZERO;
	if(!CollectionUtils.isEmpty(mapTributosAutoliquidacion)){
		for(BigDecimal montoAutoliq:mapTributosAutoliquidacion.values()){
			totalAutoliq=totalAutoliq.add(montoAutoliq);
		}
	}
	return totalAutoliq;
}


public DeudaDocumDAO getDeudaDocumeDAO() {
	return deudaDocumeDAO;
}


public void setDeudaDocumeDAO(DeudaDocumDAO deudaDocumeDAO) {
	this.deudaDocumeDAO = deudaDocumeDAO;
}


public CabDeudaDAO getCabdeudaDAO() {
	return cabdeudaDAO;
}


public void setCabdeudaDAO(CabDeudaDAO cabdeudaDAO) {
	this.cabdeudaDAO = cabdeudaDAO;
}


public DetPagoDuaDAO getDetpagoduaDAO() {
	return detpagoduaDAO;
}


public void setDetpagoduaDAO(DetPagoDuaDAO detpagoduaDAO) {
	this.detpagoduaDAO = detpagoduaDAO;
}


public Cambio1DAO getCambio1DAO() {
	return cambio1DAO;
}


public void setCambio1DAO(Cambio1DAO cambio1dao) {
	cambio1DAO = cambio1dao;
}


public CatalogoHelperImpl getCatalogoHelper() {
	return catalogoHelper;
}


public void setCatalogoHelper(CatalogoHelperImpl catalogoHelper) {
	this.catalogoHelper = catalogoHelper;
}


public ProveedorFuncionesService getFuncionesService() {
	return funcionesService;
}


public void setFuncionesService(ProveedorFuncionesService funcionesService) {
	this.funcionesService = funcionesService;
}


public AyudaService getAyudaService() {
	return ayudaService;
}


public void setAyudaService(AyudaService ayudaService) {
	this.ayudaService = ayudaService;
}


/* Ya no se calcula de esta manera el monto 
public Map<String,BigDecimal> montoTotalAPagar(Long numCorreDoc,Map<String,Object> deudaCalculada){
    Map<String,Object> parameterMap=new HashMap<String, Object>();
    parameterMap.put("numCorredoc", numCorreDoc);
    parameterMap.put("codTipdeuda", "01");
    Integer intMaxIdentDeuda=deudaDocumeDAO.selectMaxIdentDeuda(parameterMap);
    
    CabDeuda paramCabDeuda=new CabDeuda();
    paramCabDeuda.setNumCorredoc(numCorreDoc);
    paramCabDeuda.setNumIdentdeuda(intMaxIdentDeuda);
    List<CabDeuda> lstTributos= cabdeudaDAO.selectByDeuda(paramCabDeuda);
    Map<String,BigDecimal> matrizTribxPagar=new HashMap<String, BigDecimal>();
    if(!CollectionUtils.isEmpty(lstTributos)){
    	for(CabDeuda tributo:lstTributos){
    		BigDecimal monto=null;
    		if(tributo.getCodTributo().equals("0007")) {//MTSERV
    			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MTSERV"));
    		   matrizTribxPagar.put("MTSERV", monto);
    	     }
		if(tributo.getCodTributo().equals("0053")) {//MCOMM
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MCOMM"));
		   matrizTribxPagar.put("MCOMM", monto);
	     }

		if(tributo.getCodTributo().equals("0050")) {//MADUM
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MADUM"));
		   matrizTribxPagar.put("MADUM", monto);
	     }
		
		if(tributo.getCodTributo().equals("0001")) {//MADV
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MADV"));
		   matrizTribxPagar.put("MADV", monto);
	     }
		if(tributo.getCodTributo().equals("0062")) {//MSAD
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MSAD"));
		   matrizTribxPagar.put("MSAD", monto);
		}
		
		if(tributo.getCodTributo().equals("0021")) {//MDES
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MDES"));
		   matrizTribxPagar.put("MDES", monto);
	     }

		if(tributo.getCodTributo().equals("0014")) {//MIPM
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MIPM"));
		   matrizTribxPagar.put("MIPM", monto);
	     }    		
		
		if(tributo.getCodTributo().equals("0054")) {//MIPMA
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MIPMA"));
		   matrizTribxPagar.put("MIPMA", monto);
	     }
		
		if(tributo.getCodTributo().equals("0003")) {//MISC
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MISC"));
		   matrizTribxPagar.put("MISC", monto);
	     }
		
		if(tributo.getCodTributo().equals("0002")) {//MIGV
			monto=SunatNumberUtils.sum(tributo.getMtoValpag(),(BigDecimal)deudaCalculada.get("MIGV"));
		   matrizTribxPagar.put("MIGV", monto);
	     }    		    		    		
		
    }
   }
 return matrizTribxPagar;
}*/

}
