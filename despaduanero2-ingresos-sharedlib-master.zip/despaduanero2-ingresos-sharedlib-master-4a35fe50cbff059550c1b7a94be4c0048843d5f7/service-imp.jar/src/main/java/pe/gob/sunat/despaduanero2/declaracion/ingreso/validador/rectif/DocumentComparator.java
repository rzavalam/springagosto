package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DatoRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DetSolicitudRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAdiSerieImpoConsumo;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.util.ManifiestoUtil;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
/*branch ingreso hosorio inicio 2011-009*/
public abstract class DocumentComparator {
	public Map<Class, List<String>> mapIdentificadoresClase;
	public List<DetSolicitudRectificacionBean> listaCambios;
	public String tipoComparacion; // normal (rectificado vs actual) , invertido (actual vs rectificado)
	public Object objnuevo;
	public Object objanterior;
    
	public DocumentComparator() {
		tipoComparacion="N";
		listaCambios=new ArrayList<DetSolicitudRectificacionBean>();
		// TODO Auto-generated constructor stub
	}
	public abstract void comparacion(Object rectificado, Object anterior) throws Exception ;
	public abstract Map<String, Object> obtenerClave(String codTabla, Object objeto) ;
	
	public Object getAtributo(Object obj, String nombreAtributo)  {
		if (obj != null) {
			String nombreMetodoGet = "get".concat(nombreAtributo.replaceFirst(nombreAtributo.substring(0, 1), nombreAtributo.substring(0, 1)
					.toUpperCase()));
			try {
				Method  metodoGet = obj.getClass().getMethod(nombreMetodoGet);
				return metodoGet.invoke(obj);
				
			} catch (Exception e) {
				return null;
			}
		} else
			return null;
		
		
	}
	
	public Object getNestedAtributo(Object obj, String nestedNombreAtributo){
		if(nestedNombreAtributo.indexOf(".")>0){
			int indicePunto=nestedNombreAtributo.indexOf(".");
			String nombreAtributo=  nestedNombreAtributo.substring(0, indicePunto);
			return getNestedAtributo(getAtributo(obj, nombreAtributo),nestedNombreAtributo.substring(indicePunto+1) );
		}
		else return getAtributo(obj, nestedNombreAtributo);
	}	
	
	
	/**
	 * Buscar en lista.
	 * 
	 * @param lstObj List
	 * @param obj Object
	 * @return el object
	 * @throws Exception 
	 */
	public Object buscarEnLista(List lstObj, Object obj) throws Exception {

		if (!CollectionUtils.isEmpty(lstObj)) {
			List<String> lstIdentificadores = mapIdentificadoresClase.get(obj.getClass());
			if (!CollectionUtils.isEmpty(lstIdentificadores)) {

				for (int i = 0; i < lstObj.size(); i++) {
					boolean iguales = false;
					Object objTmp = lstObj.get(i);
					for (String identificador : lstIdentificadores) {
						Object atributo1 = this.getAtributo(obj, identificador);
						Object atributo2 = this.getAtributo(objTmp, identificador);
						if (atributo1 != null && atributo2 != null) {
							if (atributo1.toString().trim().equals(atributo2.toString().trim())) {
								iguales = true;
							} else {
								iguales = false;
								break;
							}
						} else {
							iguales = false;
							break;
						}
					}
					if (iguales) {
						return objTmp;
					}
				}
				return null;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	
	
	
	
	public void agregarCambioAtributo(DatoRectificacionBean datoRec, Map<String, DatoRectificacionBean> datosRef, String columna	) {
		if (datoRec != null) {
			datosRef.put(columna, datoRec);
		}
	}
	
	public DetSolicitudRectificacionBean agregarCambioRegistro(String codTabla, Map<String, Object> clave, Map<String, DatoRectificacionBean> datos,
			String tipoCambio) {

		DetSolicitudRectificacionBean registroRectificado = null;
		if ((tipoComparacion.equals("N") && (tipoCambio.equals(Constants.IND_REGISTRO_NUEVO) || tipoCambio.equals(Constants.IND_REGISTRO_RECTIFICADO)))
				|| (tipoComparacion.equals("I") && tipoCambio.equals(Constants.IND_REGISTRO_ANULADO))) {
			// la clave no puede estar vacioa
			if (!CollectionUtils.isEmpty(clave)) {

				// los datos solo pueden estar vacios en anulacion de registro
				// en modificacion o creacion de registro los datos no pueden estar vacios
				if ((!datos.isEmpty() && tipoCambio.equals(Constants.IND_REGISTRO_RECTIFICADO))
						|| tipoCambio.equals(Constants.IND_REGISTRO_NUEVO) || tipoCambio.equals(Constants.IND_REGISTRO_ANULADO)) {
					registroRectificado = new DetSolicitudRectificacionBean(codTabla, clave);
					registroRectificado.setDatosRectificados(datos);
					registroRectificado.setTipoCambio(tipoCambio);
					this.listaCambios.add(registroRectificado);
				}
			}
		}

		return registroRectificado;
	}

	public List<DetSolicitudRectificacionBean> getListaCambios() {
		return listaCambios;
	}
	public void setListaCambios(List<DetSolicitudRectificacionBean> listaCambios) {
		this.listaCambios = listaCambios;
	}

	public String getTipoComparacion() {
		return tipoComparacion;
	}
	public void setTipoComparacion(String tipoComparacion) {
		this.tipoComparacion = tipoComparacion;
	}
	public Map<Class, List<String>> getMapIdentificadoresClase() {
		return mapIdentificadoresClase;
	}
	public void setMapIdentificadoresClase(
			Map<Class, List<String>> mapIdentificadoresClase) {
		this.mapIdentificadoresClase = mapIdentificadoresClase;
	}
	public Object getObjnuevo() {
		return objnuevo;
	}
	public void setObjnuevo(Object objnuevo) {
		this.objnuevo = objnuevo;
	}
	public Object getObjanterior() {
		return objanterior;
	}
	public void setObjanterior(Object objanterior) {
		this.objanterior = objanterior;
	}
	
	public abstract void completarDatos(Object objnuevo) ;
	
	/**
	 * Compara atributo.
	 * 
	 * @param primero Object
	 * @param segundo Object
	 * @param nombreAtributo String
	 * @return el dato rectificacion bean
	 * @throws Exception 
	 */
	public DatoRectificacionBean comparaAtributo(Object primero, Object segundo, String nombreAtributo) {
		Object atr1 = null;
		Object atr2 = null;
        try {
        	atr1 = getNestedAtributo(primero, nombreAtributo);
        	if(SunatStringUtils.include(nombreAtributo, new String[]{"codtratprefe","codconvinter","codliberatorio"})){
        		atr1 = atr1!=null?SunatStringUtils.lpad(atr1.toString(), 4,' '):atr1;        		
        	}
        	if(SunatStringUtils.include(nombreAtributo, new String[]{"codgarantia"})){
        		atr1 = atr1!=null?(atr1.toString().trim().isEmpty()?null:atr1):null ;        		
        	}
        	
		} catch (Exception e) {
		}

        try {
        	atr2 = getNestedAtributo(segundo, nombreAtributo);
        	if(SunatStringUtils.include(nombreAtributo, new String[]{"codtratprefe","codconvinter","codliberatorio"})){
        		atr2 = atr2!=null?SunatStringUtils.lpad(atr2.toString(), 4,' '):atr2;       		
        	}
        	
        	if(SunatStringUtils.include(nombreAtributo, new String[]{"codgarantia"})){
        		atr2 = atr2!=null?(atr2.toString().trim().isEmpty()?null:atr2):null ;        		
        	}
		} catch (Exception e) {
		}

		
		


		return comparaAtributo(atr1, atr2);

	}

	/**
	 * Compara atributo.
	 * 
	 * @param atr1 Object
	 * @param atr2 Object
	 * @return el dato rectificacion bean
	 * @throws Exception 
	 */
	public DatoRectificacionBean comparaAtributo(Object atr1, Object atr2)  {

		DatoRectificacionBean datoRec = null;

		Object obj = atr1 != null ? atr1 : atr2;
		if (obj != null) {
			if (obj instanceof DataCatalogo) {
				atr1 = atr1 != null ? ((DataCatalogo) atr1).getCodDatacat() : null;
				atr2 = atr2 != null ? ((DataCatalogo) atr2).getCodDatacat() : null;
				String defaultString = " ";
				if (atr1 != null && atr1.equals(""))
					atr1 = defaultString;
				if (atr2 != null && atr2.equals(""))
					atr2 = defaultString;
				atr1 = atr1 != null ? ((String) atr1) : defaultString;
				atr2 = atr2 != null ? ((String) atr2) : defaultString;
			}
			if (obj instanceof java.util.Date) {
				Date defaultDate=null;
				try {
					defaultDate = DateUtil.stringToDate("01/01/0001");	
				} catch (Exception e) {
				}
				 
				atr1 = atr1 != null ? atr1 : defaultDate;
				atr2 = atr2 != null ? atr2 : defaultDate;
			}
			if (obj instanceof java.lang.String) {
				String defaultString = " ";
				if (atr1 != null && atr1.equals(""))
					atr1 = defaultString;
				if (atr2 != null && atr2.equals(""))
					atr2 = defaultString;
				atr1 = atr1 != null ? ((String) atr1) : defaultString;
				atr2 = atr2 != null ? ((String) atr2) : defaultString;
			}

			if (obj instanceof BigDecimal) {
				atr1 = atr1 != null ? atr1 : BigDecimal.ZERO;
				atr2 = atr2 != null ? atr2 : BigDecimal.ZERO;
			}

			if (obj instanceof Integer) {
				Integer defaulInt = new Integer(0);
				atr1 = atr1 != null ? atr1 : defaulInt;
				atr2 = atr2 != null ? atr2 : defaulInt;
			}

			if (obj instanceof Long) {
				Long defaulLong = new Long(0);
				atr1 = atr1 != null ? atr1 : defaulLong;
				atr2 = atr2 != null ? atr2 : defaulLong;
			}

		}

		if (tipoComparacion.equals("N")) { // comparacion en sentido normal
			if (atr1 != null || atr2 != null) {
				if (atr1 != null && atr2 != null) {
					boolean distintos = false;

					if (atr1 instanceof BigDecimal) {
						if (((BigDecimal) atr1).compareTo((BigDecimal) atr2) != 0) {
							distintos = true;
						}
					} else if (atr1 instanceof java.util.Date) {
						if( SunatDateUtils.sonIguales((Date)atr1, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)
								&& SunatDateUtils.sonIguales((Date)atr2, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA)){//por bug blocker pase105 arey
							distintos = false;		
						}
						else if (((Date) atr1).compareTo((Date) atr2) != 0) {
							distintos = true;
						}
					} else if (atr1 instanceof java.lang.String) {

						if (!((String) atr1).trim().equals(((String) atr2).trim())) {
							distintos = true;
						}
					} else if (!atr1.equals(atr2)) {
						distintos = true;
					}
					if (distintos) {
						datoRec = new DatoRectificacionBean(atr1, atr2); // atributo modificacion
						datoRec.setTipoRectificacion(Constants.IND_CAMPO_RECTIFICADO);
					}
				} else if (atr1 != null) {
					datoRec = new DatoRectificacionBean(atr1, null); // atributo nuevo
					datoRec.setTipoRectificacion(Constants.IND_CAMPO_NUEVO);
				} else if (atr2 != null) {
					datoRec = new DatoRectificacionBean(null, atr2); // atributo eliminado
					datoRec.setTipoRectificacion(Constants.IND_CAMPO_ANULADO);
				}
			}
		}
		// para a�adir los atributos del objeto(registro) eliminado
		// comentado xq no se a�ade al json ,los atributos del objeto eliminado
		/*
		 * else{ if(primero!=null && segundo==null ){ if(atr1!=null){ datoRec=new DatoRectificacionBean(null,atr1); // atributo eliminado }
		 * } }
		 */
		return datoRec;

	}

	/**
	 * Evaluar cambio registro.
	 * 
	 * @param rectificado Object
	 * @param actual Object
	 * @return el string
	 */
	public String evaluarCambioRegistro(Object rectificado, Object actual) {
		String tipoCambio = "";
		if (rectificado != null) {
			if (actual == null) {
				if (tipoComparacion.equals("N"))
					return Constants.IND_REGISTRO_NUEVO;
				else
					return Constants.IND_REGISTRO_ANULADO;
			} else
				return Constants.IND_REGISTRO_RECTIFICADO;
		}
		return tipoCambio;
	}
	
	/**
	 * Se compara primerObjeto con SegundoObjeto ademas se verifica que si uno de los datos es NULL o Vacio o Default y el otro dato es igual a NULL o Vacio o Default
	 * entonces decimos que son iguales.
	 * asi se evita que el sistema piense que se quiere rectificar un campo, cuando en realidad no se
	 * esta transmitiendo o no se transmiti� en la numeracion.
	 * Se usa cuando se presentan problemas con la rectificacion debido a campos que se graban con un default en la BD
	 * cuando no son transmitidos en la numeraci�n.
	 * Los 3 parametros deben ser de la misma Clase si no da Excepcion
	 * <P>Esta Funcion trabaja para cualquier tipo de Objeto que tenga su metodo equals sobreescrito
	 * como por ej: String, Date, Integer, BigDecimal, Double etc.
	 * Si se desea usar para comparar otro tipo de Datos como por Ejemplo DataCatalogo, entonces sobrescribir el metodo equals de esa clase
	 * <P>Esta Funcion Verifica en ambos Sentidos asi que no importa cual de los Objetos proviene de la BD
	 * <P>Esta Funcion no modifica los Datos que se usan como Parametros
	 * <P>Esta Funcion no trabaja cuando el Default en la Base de Datos no es constante por ejemplo SYSDATE 
	 * @param primerObjeto	El Objeto que se desea comparar con el Segundo
	 * @param segundoObjeto El Objeto que se desea comparar con el Primero
	 * @param dataDefault	El valor que por default le asigna la Base de Datos a este Dato (No puede ser NULL)
	 * @author nsullcar
	 */
	public <O extends Object> boolean sonIgualesValidacionIncluyeDefault(final O primerObjeto, final O segundoObjeto, final O dataDefault){
		//Verificamos que dataDefault no sea null
		if(dataDefault==null){
			throw new  IllegalArgumentException("El parametro dataDefault no puede ser null");
		}
		//Verificamos que los otro argumentos sean del mismo tipo que el dataDefault
		if(primerObjeto != null && !dataDefault.getClass().getCanonicalName().equals(primerObjeto.getClass().getCanonicalName())){
			throw new  IllegalArgumentException("El primerObjeto no es del mismo tipo de dato que el dataDefault");
		}
		if(segundoObjeto != null && !dataDefault.getClass().getCanonicalName().equals(segundoObjeto.getClass().getCanonicalName())){
			throw new  IllegalArgumentException("El segundoObjeto no es del mismo tipo de dato que el dataDefault");
		}

		//INICIAMOS LA COMPARACION
		boolean sonIguales=false;
		//Caso base de la comparacion NULL o Vacio o Default son Iguales entre si para la comparaci�n cuando hay un Default en la BD
		
		if((primerObjeto == null || primerObjeto.equals("")|| primerObjeto.equals(dataDefault))
			&& (segundoObjeto == null || segundoObjeto.equals("") || segundoObjeto.equals(dataDefault)  )	
		){
			sonIguales = true;
		}
		//Si las condiciones de arriba no se cumplen, entonces comparamos directamente el uno con el otro
		if(!sonIguales){
			if(primerObjeto != null){//esto es para Evitar NullPointer Exception, ya que uno de los objetos puede ser nulo 
				sonIguales =  primerObjeto.equals(segundoObjeto);
			} else {//si el primerObjeto es nulo el segundo no lo es y viceversa. 
				sonIguales =  segundoObjeto.equals(primerObjeto);
			}
		}
		return sonIguales;
	}

	public int sizeBean (Class<?> clase, Object obj){
		Field[] fields = null;
		fields = ManifiestoUtil.obtenerAtributosClase(clase);
		int size=0;
		for(int i = 0; i < fields.length; i++) {
			Field field = fields[i];
			Object atributo = this.getAtributo(obj, field.getName());
			if (atributo !=null)
				size++;
		}
		return size;
	}

}
