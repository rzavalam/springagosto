/*
 * Clase que define el servicio de validaciones de los datos del manifiesto.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageGetManif;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageTD;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * The Class ValNegocManifFormA. Clase que define el servicio de validaciones de los datos del manifiesto.
 */
public class ValNegocManifFormAServiceImpl extends ValDuaAbstract implements ValNegocManifFormA{
	
	//private PackageTD packageTD;

	/**
	 * Valida datos del manifiesto. Hace referencia al procedimiento almacenado SPTD_VAL_MANIF del SIGAD
	 * @deprecated Revisar consulta no implementada en MCDAGE
	 * @param declaracion Declaracion
	 * @param xTipoProce String
	 * @return Lista de errores
	 */
	public List<Map<String, String>> valManif(Declaracion declaracion, String xTipoProce){
		DUA dua=declaracion.getDua();
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		DatoManifiesto manifiesto=dua.getManifiesto();
		String xcodi_aduan=declaracion.getCodaduana();
		String xcodi_alma=dua.getNumruclugarecep();
		String gcvia_trans="";
		//SPTD_VAL_MANIF 2-8 
		/*
		 * wTableM = 'MCDAGE'
			wTableBl = 'MCDETA'
			wTableCta = 'MCDREG'
		 */
		
		String xanno_manif=manifiesto!=null?manifiesto.getAnnmanif():null;
		String xcadu_manif=manifiesto!=null?manifiesto.getCodaduamanif():null; 
		String xnume_manif=manifiesto!=null?manifiesto.getNummanif():null;
		Date xfech_termi=manifiesto!=null?manifiesto.getFectermino():null; 
		//PAS20145E220000090 - MATC 20140617  INICIO
		if( xfech_termi !=null && SunatDateUtils.sonIguales(xfech_termi, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
			xfech_termi = dua.getFecLlegada();
		}
		//PAS20145E220000090 - MATC 20140617  FINAL
		
		if (SunatStringUtils.isEmptyTrim(xanno_manif))
			listError.add(ResponseMapManager.getErrorResponseMap("8505","ANHO DEL MANIFIESTO INVALIDO"));
		if (!xcodi_aduan.equals(xcadu_manif) && !"154".equals(xcodi_aduan))
			listError.add(ResponseMapManager.getErrorResponseMap("0014","ADUAHDR1.CADU_MANIF, CODI_ADUAN-"+xcadu_manif+","+xcodi_aduan));
		String wtmanif=PackageGetManif.getTipo(gcvia_trans,xcodi_alma,xcodi_aduan);
		if (!SunatStringUtils.isEmptyTrim(wtmanif)){
			Map<String,Object> paramsManif=new HashMap<String,Object>();
			String xadua_manif=xcadu_manif;
			if ("154".equals(xcadu_manif) && "0".equals(gcvia_trans)){
				xadua_manif="910";
			}
			String xanoman=xanno_manif.substring(2,4);
			paramsManif.put("anno", xanoman);
			paramsManif.put("nume_mc",SunatStringUtils.lpad(xnume_manif, 5, ' '));
			if (("5".equals(gcvia_trans) && (new Integer(xanno_manif))<=2000) ||
					("4".equals(gcvia_trans) && (new Integer(xanno_manif))<=1999 && (new Integer(xnume_manif)<6500))
					){
				paramsManif.put("codi_term", xcodi_alma);
			}
			paramsManif.put("via_trans", gcvia_trans);
			paramsManif.put("codi_aduan", xadua_manif);
			Map<String,Object> mapMcDage=new HashMap<String,Object>();
			/*
			 * 		Se obtiene Fecha de termino de descarga o llegada 
			Sql = 'SELECT a.FECH_DESC, a.FECH_LLEGA FROM ' + wTableM + 
				' a WHERE ' + wWhere +' AND a.ESTADO <> ''' +'A'+''''
			 */
			Integer xFecha;
			if (mapMcDage!=null){
				Integer fech_desc=(Integer)mapMcDage.get("fech_desc");
				if (fech_desc==null || fech_desc==0){
					xFecha=(Integer)mapMcDage.get("fech_llega");
				}else{
					xFecha=fech_desc;
				}
			}else{
				xFecha=0;
			}
			if (xFecha==0){
				listError.add(ResponseMapManager.getErrorResponseMap("0121","TRANSMITIO "));
				return listError;
			}
			FechaBean fbXFecha=new FechaBean(String.valueOf(xFecha));
			Calendar calFechTermi=Calendar.getInstance();
			calFechTermi.setTime(xfech_termi);
			if (fbXFecha.getCalendar().compareTo(calFechTermi)!=0){
				listError.add(ResponseMapManager.getErrorResponseMap("0017","ADUAHDR1::FECHTERMI/FECH_LLEGA - FECHA DE TERMINO DE LA DESCARGA: "+(xFecha.intValue())+" TRANSMITIO: "));
			}
			Calendar calXFecha=fbXFecha.getCalendar();
			calXFecha.add(Calendar.DATE, 36);
			int dayWeek=calXFecha.get(Calendar.DAY_OF_WEEK);
			int addDay=dayWeek==Calendar.SATURDAY?2:(dayWeek==Calendar.SUNDAY?1:0);
			calXFecha.add(Calendar.DATE, addDay);
			Elementos<DatoOtroDocSoporte> doc=dua.getListOtrosDocSoporte();
			//String xtipo_docas=doc.get(0).getCodtipodocasoc();
			  String xtipo_docas=xTipoProce;
			if (calXFecha.compareTo(Calendar.getInstance())<0 && SunatStringUtils.include(xtipo_docas,new String[]{"3","P"})){
				listError.add(ResponseMapManager.getErrorResponseMap("0302","FECHA DE TERMINO DE LA DESCARGA ES "+(xFecha.intValue())));
			}
			if (SunatStringUtils.include(wtmanif, new String[]{"A","P"})){
				for(DatoSerie serie:dua.getListSeries()){
					PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
					DatoDocTransporte docTrans=getDocTransporte(dua,serie);
					String wcono_embar=docTrans.getNumdoctransporte();
					Integer vvigguiacp=packageTD.getCambioVigente("MC03", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
					if (wcono_embar.length()<=12){
						if (!"P".equals(wtmanif) || "235".equals(xcadu_manif) || vvigguiacp!=1){
							if (!"244".equals(xcodi_aduan))
								wcono_embar=SunatStringUtils.lpad(wcono_embar, 12, '0');
						}
					}else{
						if (!"P".equals(wtmanif) || "235".equals(xcadu_manif) || vvigguiacp!=1){
							wcono_embar=wcono_embar.substring(wcono_embar.length()-12,wcono_embar.length());
						}
					}
					if (SunatStringUtils.isEmptyTrim(wcono_embar)){
						//listError.add(ResponseMapManager.getErrorResponseMap("0122","ADUAHDR1::CONO_EMBAR - "+));
					}
				}
				
			}
		}
		return listError;
	}

	/*
	public PackageTD getPackageTD() {
		return packageTD;
	}

	public void setPackageTD(PackageTD packageTD) {
		this.packageTD = packageTD;
	}*/
	

}
