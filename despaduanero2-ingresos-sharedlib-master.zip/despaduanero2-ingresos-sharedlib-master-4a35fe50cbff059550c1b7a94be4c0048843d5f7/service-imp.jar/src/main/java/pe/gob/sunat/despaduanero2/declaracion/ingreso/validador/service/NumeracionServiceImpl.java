package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import org.springframework.context.ApplicationContext;

import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.Cambio1DAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.SPGeneralDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.TabImpDUDAO;
import pe.gob.sunat.despaduanero2.model.dao.DiasUtilesDAO;
import pe.gob.sunat.recauda2.garantia.model.dao.PagarantiaDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.CabDocliqDAO;
import pe.gob.sunat.servicio2.registro.model.dao.SprDAO;

@Deprecated
public class NumeracionServiceImpl {
	
	
	private ApplicationContext appContext= null;

	
	private static NumeracionServiceImpl instance;
	
	
	private PagarantiaDAO pagarantiaDAO;
	private CabDeclaraDAO cabDeclaraDAO;
	private DeudaDocumDAO deudaDocumDAO;
	private DiasUtilesDAO diasUtilesDAO;
	private Cambio1DAO cambio1DAO;
	private TabImpDUDAO  tabImpDUDAO; 
	private CabDocliqDAO cabDocliqDAO;
	private SPGeneralDAO spGeneralDAO;
//	private SprDAO sprDAO ;
    private ProveedorFuncionesService funcionesService;

	
	public SPGeneralDAO getSpGeneralDAO() {
		return spGeneralDAO;
	}

	public void setSpGeneralDAO(SPGeneralDAO spGeneralDAO) {
		this.spGeneralDAO = spGeneralDAO;
	}

	public CabDocliqDAO getCabDocliqDAO() {
		return cabDocliqDAO;
	}

	
	public ProveedorFuncionesService getFuncionesService() {
		return funcionesService;
	}

	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}

	public void setCabDocliqDAO(CabDocliqDAO cabDocliqDAO) {
		this.cabDocliqDAO = cabDocliqDAO;
	}

	public DiasUtilesDAO getDiasUtilesDAO() {
		return diasUtilesDAO;
	}

	public void setDiasUtilesDAO(DiasUtilesDAO diasUtilesDAO) {
		this.diasUtilesDAO = diasUtilesDAO;
	}

	public DeudaDocumDAO getDeudaDocumDAO() {
		return deudaDocumDAO;
	}

	public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
		this.deudaDocumDAO = deudaDocumDAO;
	}

	public PagarantiaDAO getPagarantiaDAO() {
		return pagarantiaDAO;
	}

	public void setPagarantiaDAO(PagarantiaDAO pagarantiaDAO) {
		this.pagarantiaDAO = pagarantiaDAO;
	}

	private NumeracionServiceImpl() {
	}
	
	public static NumeracionServiceImpl getInstance() {
		if(instance == null )
		{
			instance = new NumeracionServiceImpl();

		}
		
		return instance;
	}

	public static void setInstance(NumeracionServiceImpl instance) {
		NumeracionServiceImpl.instance = instance;
	}

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public Cambio1DAO getCambio1DAO() {
		return cambio1DAO;
	}

	public void setCambio1DAO(Cambio1DAO cambio1DAO) {
		this.cambio1DAO = cambio1DAO;
	}

	public TabImpDUDAO getTabImpDUDAO() {
		return tabImpDUDAO;
	}

	public void setTabImpDUDAO(TabImpDUDAO tabImpDUDAO) {
		this.tabImpDUDAO = tabImpDUDAO;
	}

//	public SprDAO getSprDAO() {
//		return sprDAO;
//	}
//
//	public void setSprDAO(SprDAO sprDAO) {
//		this.sprDAO = sprDAO;
//	}  
  
	
}
