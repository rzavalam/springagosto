package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.transportista;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.ConstantesAsociacionCatalogo;

public class ValTransportistaServiceImpl extends IngresoAbstractServiceImpl implements ValTransportistaService{

	protected final Log logImportador = LogFactory.getLog(getClass());
		
	@ServicioAnnot(tipo="V",codServicio=6555)
	@ServInstDetAnnot(tipoRpta={0,1,1},nomAtr={"this,codTransaccion,fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=6555,numSecEjec=91,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, ?>> validarTipoDocumentoIdentidadTransportista(DUA dua,String codTransaccion, Date fechaReferencia){		
		CatalogoValidaService catalogoValida = fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");
		Participante transportista = dua.getManifiesto().getEmpTransporte();
		String codAsociacion = ConstantesAsociacionCatalogo.CATALOGO_ASOCIACION_TRANSACCION_COD_DOC_TRANSPORTISTA;
		String codTipoDocumento = transportista.getTipoDocumentoIdentidad().getCodDatacat();
		String prefijoMsjAsociado = "TIPO DE DOCUMENTO DE TRANSPORTISTA ENVIADO";
		return catalogoValida.validarAsociacion(codAsociacion, codTransaccion, codTipoDocumento, prefijoMsjAsociado, "1", "1", fechaReferencia);		
	}
	
	@ServicioAnnot(tipo="V",codServicio=6556)
	@ServInstDetAnnot(tipoRpta={0,1,1},nomAtr={"this,codTransaccion,fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=6556,numSecEjec=91,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, ?>> validarTipoOperadorTransportistaPermitido(DUA dua,String codTransaccion, Date fechaReferencia){
		CatalogoValidaService catalogoValida = fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");
		Participante transportista = dua.getManifiesto().getEmpTransporte();
		String codAsociacion = ConstantesAsociacionCatalogo.CATALOGO_ASOCIACION_TRANSACCION_COD_CLASE_TRANSPORTISTA;
		String codCalseOperador = transportista.getTipoParticipante().getCodDatacat();
		String prefijoMsjAsociado = "TIPO DE OPERADOR TRANSPORTISTA ENVIADO";
		return catalogoValida.validarAsociacion(codAsociacion, codTransaccion, codCalseOperador, prefijoMsjAsociado, "1", "1", fechaReferencia);
	}
	
	
}
