package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.despaduanero.catalogo.tg.model.TablNew;
import pe.gob.sunat.despaduanero.catalogo.tg.service.TablnewDAOService;
import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.model.DataGrupoCat;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocAutorizante;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public class ValDuaAbstract extends IngresoAbstractServiceImpl {
	
	protected final static String MODALIDAD_ANTICIPADA="10";
	protected final static String MODALIDAD_EXCEPCIONAL="00";
	protected final static String MODALIDAD_URGENTE="01";
	
	protected final static String DOC_SOPORTE="1";
	//INICIO EJHM P46
	protected final static String CON_DOC_AUTORIZA="1";
	protected final static String SIN_DOC_AUTORIZA="2";
	protected final static String CON_Y_SIN_DOC_AUTORIZA="3";
	//FIN EJHM P46
	protected final static String FACTURA="2";
	protected final static String DOC_TRANSPORTE="3";
	protected final static String DOC_AUTORIZANTE="4";
	protected final static String CERTI_ORIGEN="5";
	protected final static String INDICADOR_DUA = "02";
	
	//glazaror msnade236_1... se copio la constante "GRUPO_TLC_MODIFICACION_FECHA_CO" de pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.TratoPreferencialInternacionalServiceImpl
	private static final String GRUPO_TLC_MODIFICACION_FECHA_CO = "609";
	
	//private TablnewDAOService tablnewDAOService; 
	
	protected Map<String,Object> getNuevoMapa(){
		return new HashMap<String,Object>();
	}
	
	//fnverierror
	protected Map<String, String> veriError(List<Map<String,String>> listError, String tipoTabla,String pcodigo, String perror, String pTable, String pcampo ){
		String mdescError=pcampo+"-"+pcodigo+" del Tipo:" + tipoTabla;
		if (!"==".equals(tipoTabla)){
			TablnewDAOService tablnewDAOService = (TablnewDAOService)fabricaDeServicios.getService("Ayuda.tablnewServiceService");
			Map<String,Object> params=new HashMap<String,Object>();
			params.put("tipo", tipoTabla);
			params.put("codigo", pcodigo);
			params.put("fechavigencia", SunatDateUtils.getCurrentIntegerDate());
			List<TablNew> listTablNew=tablnewDAOService.findTablNewByParams(params);
			if (listTablNew!=null && !listTablNew.isEmpty())
				mdescError="";
			else
				mdescError=pcampo+" - No Vigente "+pcodigo + " del Tipo " + tipoTabla;
		}else if ("UBIGEO".equals(pTable)){
			Map<String,?> mapUbigeo=new HashMap<String,Object>();
			/*
			 * Valida en la tabla UBIGEO:
			 */
			if (mapUbigeo!=null)
				mdescError="";
		}else if ("UBIALMA".equals(pTable)){
			Map<String,?> mapUbialma=new HashMap<String,Object>();
			/*
			 * SELECT COUNT(*) FROM UBIALMA WHERE CALM = '3014' AND cubialm = pCodigo 
			 */
			if (mapUbialma!=null)
				mdescError="";
		}else if("PUERTOS".equals(pTable)){
			Map<String,?> mapPuertos=new HashMap<String,Object>();
			/*
			 * SELECT COUNT(*) FROM PUERTOS WHERE CPAIS= SUBSTR(pCodigo,1,2) AND CPUERTO  = SUBSTR(pCodigo,3,3) 
			 */
			if (mapPuertos!=null)
				mdescError="";
		}
		if (!"".equals(mdescError))
			listError.add(this.getErrorMapWithDescription(perror,mdescError));
		return null;
	}
	
	protected DatoDocTransporte getDocTransporte(DUA dua, DatoSerie serie){
		//glazaror... optimizacion
		if (serie.isDocumentoTransporteCargado()) {
			//entonces retornamos el documento de transporte cargado anteriormente
			return serie.getDocumentoTransporte();
		}
		//sino entonces cargamos el documento de transporte... ejecutamos la logica actual que se ejecuta por cada serie
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		String numDocTransporte="";
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_TRANSPORTE.equals(serieDoc.getCodtipodocsoporte()))
				numDocTransporte=String.valueOf(serieDoc.getNumiddocsoporte());
		}
		for(DatoDocTransporte docTransp:dua.getListDocTransporte()){
			if (numDocTransporte!=null){
				if (numDocTransporte.equals(String.valueOf(docTransp.getNumsecdoctrans()))) {
					//glazaror... antes de retornar el documento de transporte encontrado... seteamos en la seria para no volver a ejecutar la logica pesada
					serie.setDocumentoTransporte(docTransp);
					serie.setDocumentoTransporteCargado(true);
					return docTransp;
				}
			}
		}
		//glazaror... si es que no se encuentra igualmente indicamos que el documento de transporte ya fue cargado... para no volver a ejecutar la busqueda
		serie.setDocumentoTransporteCargado(true);
		return null;
	}
	//lmvr RN 175
	protected List<DatoDocTransporte> getListDocTransporte(DUA dua, DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		Integer numSecDT=0;
		List<DatoDocTransporte> list=new ArrayList<DatoDocTransporte>();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_TRANSPORTE.equals(serieDoc.getCodtipodocsoporte()))
				numSecDT=serieDoc.getNumiddocsoporte();
			if (numSecDT!=null && numSecDT!=0){
				for(DatoDocTransporte documentoTransporte:dua.getListDocTransporte()){
					if (numSecDT.intValue()==documentoTransporte.getNumsecdoctrans())
						list.add(documentoTransporte);
				}
				numSecDT=0;
			}
		}
		return list;
	}
	
	protected boolean tieneDocTransporte(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_TRANSPORTE.equals(serieDoc.getCodtipodocsoporte()))
				return true;
		}
		return false;
	}
	
	protected List<DatoFacturaref> getFacturaRef(DUA dua, DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		Integer numSecFactu=0;
		List<DatoFacturaref> list=new ArrayList<DatoFacturaref>();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (FACTURA.equals(serieDoc.getCodtipodocsoporte()))
				numSecFactu=serieDoc.getNumiddocsoporte();
			if (numSecFactu!=null && numSecFactu!=0){
				for(DatoFacturaref facturaRef:dua.getListFacturaRef()){
					if (numSecFactu.intValue()==facturaRef.getNumsecfactu())
						list.add(facturaRef);
				}
				numSecFactu=0;
			}
		}
		return list;
	}	
	
	/***Adicionado por el PAS20155E220000508**/
	protected List<DatoOtroDocSoporte> getLC(DUA dua, DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		Integer numSecLC=0;		
		List<DatoOtroDocSoporte> list=new ArrayList<DatoOtroDocSoporte>();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_SOPORTE.equals(serieDoc.getCodtipodocsoporte()))
				numSecLC=serieDoc.getNumiddocsoporte();
			if (numSecLC!=null && numSecLC!=0){
				for(DatoOtroDocSoporte LC:dua.getListOtrosDocSoporte()){
					if (numSecLC.intValue()==LC.getNumsecdocum())
						if (LC.getCodtipoproceso().equalsIgnoreCase(ConstantesDataCatalogo.TIPO_DOC_AUTOLIQUIDACION)){
							list.add(LC);							
							return list;
						}
				}
				numSecLC=0;
			}
		}
		return list;
	}	
	
	//lmvr
	protected boolean compararFacturas(List<DatoFacturaref> listnumfactura, List<DatoFacturaref> listnumfactura2){
		 
		for (DatoFacturaref factura : listnumfactura) {
			for (DatoFacturaref facturaComparada : listnumfactura2) {
				if (factura.getNumfactura().equals(facturaComparada.getNumfactura())) {
					return true;
				}
			}
		}
		return false;
	}

	
	//lmvr
		protected boolean estadoRegularizable(Declaracion declaracion){
			
			DUA dua= declaracion.getDua();				
			List<DatoIndicadores> listIndicadorDua = dua.getListIndicadores();
			for(DatoIndicadores indicadores:listIndicadorDua){
				if (INDICADOR_DUA.equals(indicadores.getCodtipoindica()))
					return true;
			}	
			return false;
		}


	protected DatoFacturaref getFacturaRefPorDocSoporte(DUA dua, DatoSerieDocSoporte docSoporte){
		DatoFacturaref datoFacturaref = null;
		//Verificamos que el documento de soporte sea una factura
		if(FACTURA.equals(docSoporte.getCodtipodocsoporte())){
				//Buscamos en las Facturas asociadas a la DUA
				for(DatoFacturaref facturaRef:dua.getListFacturaRef()){
					if (docSoporte.getNumiddocsoporte().intValue()==facturaRef.getNumsecfactu()){
						datoFacturaref = facturaRef;
						break;
					}
						
				}
		}
		return datoFacturaref;
	}	

	protected boolean tieneFacturaRef(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (FACTURA.equals(serieDoc.getCodtipodocsoporte()))
				return true;
		}
		return false;
	}
	
	/***Adicionado por el PAS20155E220000508**/
	protected boolean tieneLC(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_SOPORTE.equals(serieDoc.getCodtipodocsoporte()))
				return true;
		}
		return false;
	}
	
	protected int getCantidadFacturaRef(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		int contFactura=0;
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (FACTURA.equals(serieDoc.getCodtipodocsoporte()))
				contFactura ++;
		}
		return contFactura;
	}
	
	protected List<DatoAutocertificacion> getCertiOrigen(DUA dua, DatoSerie serie){
		//rtineo optimizacion, primero verificamos si los certificados de origen ya fueron grabados
		if(serie.getCertificadosOrigen() != null){
			return serie.getCertificadosOrigen();
		}
		//rtineo sino continuamos con la logica anterior
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		Integer numsecCO=0;
		List<DatoAutocertificacion> list=new ArrayList<DatoAutocertificacion>();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (CERTI_ORIGEN.equals(serieDoc.getCodtipodocsoporte()))
				numsecCO=serieDoc.getNumiddocsoporte();
			if (numsecCO!=null && numsecCO!=0){
				if(dua.getDatoCertificadoOrigen()!=null && !CollectionUtils.isEmpty(dua.getDatoCertificadoOrigen().getListAutocertificacion())){//adicionado por PAS20155E220200192
					for(DatoAutocertificacion certiOrigen:dua.getDatoCertificadoOrigen().getListAutocertificacion()){
						if (numsecCO.intValue()==certiOrigen.getNumsecCO())
							list.add(certiOrigen);
					}	
				}
				numsecCO=0;
			}
		}
		//rtineo finalmente cargamos los certificados
		serie.setCertificadosOrigen(list);
		//rtineo fin optimizacion
		return list;
	}	

	protected boolean tieneCertiOrigen(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (CERTI_ORIGEN.equals(serieDoc.getCodtipodocsoporte()))
				return true;
		}
		return false;
	}
	
	protected int getCantidadCertiOrigen(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		int contCertiOrigen=0;
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (CERTI_ORIGEN.equals(serieDoc.getCodtipodocsoporte()))
				contCertiOrigen ++;
		}
		return contCertiOrigen;
	}
	
	//lmvr: RN 163 - I
	protected int getCantidadDocTransporte(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		int contDocTransporte=0;
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_TRANSPORTE.equals(serieDoc.getCodtipodocsoporte()))
				contDocTransporte ++;
		}
		return contDocTransporte;
	}
	
	
	protected List<DatoOtroDocSoporte> getDocSoporte(DUA dua, DatoSerie serie){
		//rtineo optimizacion, primero verificamos si es que los documentos de soporte de la serie ya fueron cargadas anteriormente
		if (serie.getDocumentosSoporte() != null) {
			//entonces retornamos la lista de documentos de soporte cargados anteriormente
			return serie.getDocumentosSoporte();
		}
		//optimizacion sino ejecutamos la logica usada para cargar la lista de documentos de soporte

		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		Integer numsecdocum=0;
		List<DatoOtroDocSoporte> list=new ArrayList<DatoOtroDocSoporte>();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_SOPORTE.equals(serieDoc.getCodtipodocsoporte()))
				numsecdocum=serieDoc.getNumiddocsoporte();
			if (numsecdocum!=null && numsecdocum!=0){
				for(DatoOtroDocSoporte docSoporte:dua.getListOtrosDocSoporte()){
					if (numsecdocum.intValue()==docSoporte.getNumsecdocum())
						list.add(docSoporte);
				}	
				numsecdocum=0;
			}
		}
		//optimizacion por ultimo cargamos la lista de documentos de soporte en el objeto serie para que no se vuelva a ejecutar la logica pesada
		serie.setDocumentosSoporte(list);
		return list;
	}		

	
	//lmvr - Parte I - RN 173
	protected List<DatoOtroDocSoporte> getCantFacturas(DUA dua){
		
		List<DatoOtroDocSoporte> list=new ArrayList<DatoOtroDocSoporte>();
	
		for(DatoOtroDocSoporte docSoporte:dua.getListOtrosDocSoporte()){
					if (FACTURA.equals(docSoporte.getCodtipodocasoc()))
						list.add(docSoporte);
		 }	

		return list;
	}

		
	
	
	
	protected List<DatoDocAutorizante> getDocAutorizante(DUA dua, DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		Integer numsecdocum=0;
		List<DatoDocAutorizante> list=new ArrayList<DatoDocAutorizante>();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_AUTORIZANTE.equals(serieDoc.getCodtipodocsoporte()))
				numsecdocum=serieDoc.getNumiddocsoporte();
			if (numsecdocum!=null && numsecdocum!=0){
				for(DatoDocAutorizante docAutorizante:dua.getListDocAutorizantes()){
					if (numsecdocum.intValue()==docAutorizante.getNumsecdocum())
						list.add(docAutorizante);
				}
				numsecdocum=0;
			}
		}
		return list;
	}
	


	//Numeracion DSEER
	protected DatoDocAutorizante getDocAutorizanteNew(DUA dua, DatoSerieDocSoporte serieDocSoporte){
		Integer numsecdocum=0; 
		DatoDocAutorizante datoDocAutorizante = null;
		if (DOC_AUTORIZANTE.equals(serieDocSoporte.getCodtipodocsoporte()))
			numsecdocum=serieDocSoporte.getNumiddocsoporte();
		if (numsecdocum!=null && numsecdocum!=0){
			for(DatoDocAutorizante docAutorizante:dua.getListDocAutorizantes()){
				if (numsecdocum.intValue()==docAutorizante.getNumsecdocum()){
					datoDocAutorizante = docAutorizante;
					break;
				}
			}
		}

		return datoDocAutorizante;
	}

	protected boolean tieneDocAutorizante(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_AUTORIZANTE.equals(serieDoc.getCodtipodocsoporte()))
				return true;
		}
		return false;
	}
	
	protected int getCantidadDocAutorizante(DatoSerie serie){
		List<DatoSerieDocSoporte> serieDocs=serie.getListSerieDocSoporte();
		int contDocAutorizante=0;
		for(DatoSerieDocSoporte serieDoc:serieDocs){
			if (DOC_AUTORIZANTE.equals(serieDoc.getCodtipodocsoporte()))
				contDocAutorizante ++;
		}
		return contDocAutorizante;
	}
	
		
	
	protected Map<String,String> getDUAError(String codError, String msje){
		if(codError.length()<5)
			codError=SunatStringUtils.lpad(codError, 5, '0');
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService");
		return getErrorMapWithDescription(codError,msje);
	}
	
	protected Map<String,String> getDUAError(String codError, Object[] args){
		//TODO M�todo de grabaci�n de Error/Alerta  (Actualizar al M�todo est�ndar) 
		if(codError.length()<5)
			codError=SunatStringUtils.lpad(codError, 5, '0');
		return getErrorMap(codError,args);
	}
	
	protected DatoDescrMinima getDescripcionMinimaItemByTipo(DatoItem item,String codigoTipoDesc) {
		for (DatoDescrMinima descrMinima : item.getListDecrMinima()) {
			if (SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), codigoTipoDesc)) {
				return descrMinima;
			}
		}
		return null;
	}
	
	
	
	
	protected Observacion getObservacionbyTipo(DUA dua,String codTipoObserv ){
		
		if(!CollectionUtils.isEmpty(dua.getListObservaciones())){
		     for(Observacion obs:dua.getListObservaciones()){
		    	 if(obs.getCodtipobserva().equals(codTipoObserv)){
		    		 return obs;
		    	 }
		     }	
		}
		return null;
	}
	
	protected DatoOtroDocSoporte getDocSoporteByTypoProceso(DUA dua,String codTipoProceso)
	{
		if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
			for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
				if(StringUtils.hasText(soporte.getCodtipoproceso()) && soporte.getCodtipoproceso()
						.equals(codTipoProceso) ){
					return soporte;
				}
			}
		}
		return null;
	}	
	//P46 EJHM
	protected DatoOtroDocSoporte getDocSoporteByTypoProceso(DUA dua,String codTipoProceso,boolean flagDiligencia)
	{
		if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
			for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
				Integer indEliminado = soporte.getIndicadorEliminado()!=null?soporte.getIndicadorEliminado():0;
				if(indEliminado==1 && flagDiligencia){
					continue;
				}
				if(StringUtils.hasText(soporte.getCodtipoproceso()) && soporte.getCodtipoproceso()
						.equals(codTipoProceso) ){
					return soporte;
				}
			}
		}
		return null;
	}
	//P46 EJHM
	
	
	protected Object getPropertyByObjectPath(Declaracion d,String ObjectPath){
		
	    //ejemplo de object path
	    //String path="dua.listSeries[0].listRegPrecedencia[0].codaduapre";
	    try {
	    	  return  PropertyUtils.getNestedProperty(d, ObjectPath);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}
	
	protected Elementos<DatoSerieDocSoporte> getListSerieSoporteByType(DatoSerie serie,String listCodtipodocsoporte){
		Elementos<DatoSerieDocSoporte> listaSerieSoporte=new Elementos<DatoSerieDocSoporte>();
		if(!CollectionUtils.isEmpty(serie.getListSerieDocSoporte())){
			for(DatoSerieDocSoporte serieSoporte:serie.getListSerieDocSoporte()){
				if( SunatStringUtils.isStringInList(serieSoporte.getCodtipodocsoporte(), listCodtipodocsoporte) ){
					listaSerieSoporte.add(serieSoporte);
				}
			}
		}
		
		
		return listaSerieSoporte;
		
	}
	
	protected List<DatoOtroDocSoporte> getListDocSoporteByTipoProceso(DUA dua,String codTipoProceso)
	{
		List<DatoOtroDocSoporte> lista=new ArrayList<DatoOtroDocSoporte>(); 
		
		if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
			for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
				if(StringUtils.hasText(soporte.getCodtipoproceso()) && soporte.getCodtipoproceso()
						.equals(codTipoProceso) ){
					 lista.add(soporte);
				}
			}
		}
		return lista;
	}		
	
	protected List<DatoOtroDocSoporte> getListDocSoporteByTipoDocAsociado(DUA dua,String codTipDocAsoc)
	{
		List<DatoOtroDocSoporte> lista=new ArrayList<DatoOtroDocSoporte>(); 
		
		if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
			for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
				if(StringUtils.hasText(soporte.getCodtipodocasoc()) && soporte.getCodtipodocasoc()
						.equals(codTipDocAsoc) ){
					 lista.add(soporte);
				}
			}
		}
		return lista;
	}
	//Inicio - PAS20165E220200022
	protected List<DatoOtroDocSoporte> getListDocSoporteByTipoDocAsociado(DUA dua,String codTipDocAsoc1,String codTipDocAsoc2)
	{
		List<DatoOtroDocSoporte> lista=new ArrayList<DatoOtroDocSoporte>(); 
		
		if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
			for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
				if(StringUtils.hasText(soporte.getCodtipodocasoc()) && (soporte.getCodtipodocasoc()
						.equals(codTipDocAsoc1)||soporte.getCodtipodocasoc()
						.equals(codTipDocAsoc2)) ){
					 lista.add(soporte);
				}
			}
		}
		return lista;
	}	
	//Fin - PAS20165E220200022
	
	//INICIO EJHM P46
		protected String getDocAutorizanteDonacion(DUA dua,String codTipResolucion,String codTipExpediente, String codTipoProceso, boolean flagDiligencia)
		{
			
			boolean conDocAutoriza=false;
			boolean sinDocAutoriza=false;
			if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
				for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
					Integer indEliminado = soporte.getIndicadorEliminado()!=null?soporte.getIndicadorEliminado():0;
					if(indEliminado==1 && flagDiligencia){
						continue;
					}
					
					if(StringUtils.hasText(soporte.getCodtipoproceso()) && soporte.getCodtipoproceso()
							.equals(codTipoProceso) ){
						if(StringUtils.hasText(soporte.getCodtipodocasoc()) && soporte.getCodtipodocasoc()
								.equals(codTipResolucion) ){
							conDocAutoriza=true;
						} else
						if(StringUtils.hasText(soporte.getCodtipodocasoc()) && soporte.getCodtipodocasoc()
								.equals(codTipExpediente) ){
							sinDocAutoriza=true;
						}
					}
					
				}
			}
			if(conDocAutoriza && !sinDocAutoriza){
			  return CON_DOC_AUTORIZA;
			} else
			if(!conDocAutoriza && sinDocAutoriza){
			  return SIN_DOC_AUTORIZA;
			} else	
			if(conDocAutoriza && sinDocAutoriza){
				return CON_Y_SIN_DOC_AUTORIZA;
			}
			
			return "";
		}

		//Inicio - PAS20165E220200022
		protected String getDocAutorizanteDonacion(DUA dua,String codTipResolucion1,String codTipResolucion2,String codTipExpediente, String codTipoProceso, boolean flagDiligencia)
		{
			
			boolean conDocAutoriza=false;
			boolean sinDocAutoriza=false;
			if(!CollectionUtils.isEmpty(dua.getListOtrosDocSoporte())){
				for(DatoOtroDocSoporte soporte:dua.getListOtrosDocSoporte()){
					Integer indEliminado = soporte.getIndicadorEliminado()!=null?soporte.getIndicadorEliminado():0;
					if(indEliminado==1 && flagDiligencia){
						continue;
					}
					
					if(StringUtils.hasText(soporte.getCodtipoproceso()) && soporte.getCodtipoproceso()
							.equals(codTipoProceso) ){
						if(StringUtils.hasText(soporte.getCodtipodocasoc()) && (soporte.getCodtipodocasoc()
								.equals(codTipResolucion1) || soporte.getCodtipodocasoc()
								.equals(codTipResolucion2))){
							conDocAutoriza=true;
						} else
						if(StringUtils.hasText(soporte.getCodtipodocasoc()) && soporte.getCodtipodocasoc()
								.equals(codTipExpediente) ){
							sinDocAutoriza=true;
						}
					}
					
				}
			}
			if(conDocAutoriza && !sinDocAutoriza){
			  return CON_DOC_AUTORIZA;
			} else
			if(!conDocAutoriza && sinDocAutoriza){
			  return SIN_DOC_AUTORIZA;
			} else	
			if(conDocAutoriza && sinDocAutoriza){
				return CON_Y_SIN_DOC_AUTORIZA;
			}
			
			return "";
		}		
		//Fin - PAS20165E220200022
		
		//FIN EJHM
	
	public boolean isRegimenDeposito(Declaracion declaracion){
		if(declaracion!=null && declaracion.getDua() !=null){
			if(!CollectionUtils.isEmpty(declaracion.getDua().getListSeries())){
			  	for(DatoSerie serie:declaracion.getDua().getListSeries()){
			  		if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
			  			for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
			  				if("70".equals(regPrec.getCodregipre()))
			  					return true;
			  			}
			  		}
			  	}
			}
		}
		return false;
	}
	
	protected List<DatoIndicadores> getListIndicadorByTipo(DUA dua,String codTipoIndicador)
	{
		List<DatoIndicadores> lista=new ArrayList<DatoIndicadores>(); 
		
		if(!CollectionUtils.isEmpty(dua.getListIndicadores())){
			for(DatoIndicadores indicador:dua.getListIndicadores()){
				if(StringUtils.hasText(indicador.getCodtipoindica()) && indicador.getCodtipoindica()
						.equals(codTipoIndicador) ){
					//P46  inicio EJHM
					if(indicador.getIndicadorActivo()!=null && indicador.getIndicadorActivo().equals("0")){
						continue;	
					}
					//P46  fin
					 lista.add(indicador);
				}
			}
		}
		return lista;
	}
	
	public boolean existeRegPrecedenciaReposicion (Elementos<DatoSerie> series){
		boolean tienereposicion = false;
		for (DatoSerie datoSerieActual : series) {
			if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
				for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
					if ("12".equals(datoRegPreActual.getCodregipre())){						
						tienereposicion=true;	
						break;
					}
				}
			}		
		}
		return tienereposicion;
	}
	
	public boolean existeRegPrecedencia (Elementos<DatoSerie> series){
		boolean tienePrecedencia = false;
		for (DatoSerie datoSerieActual : series) {
			if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
				for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
					if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(datoRegPreActual.getCodregipre())){
						;
					}else{
						if (!tienePrecedencia)
							tienePrecedencia=true;
					}
				}
			}		
		}
		return tienePrecedencia;
	}
       
	/**
	 * Verificar si debe datar por regimen de precedencia
	 * @param series
	 * @return
	 */
	public boolean datarPrecedencia(Elementos<DatoSerie> series){
		boolean tieneQueDatar = true;
		boolean tieneReposicion = false;
		boolean tieneOtraPrecedencia = false;
		for (DatoSerie datoSerieActual : series) {
			if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
				for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {					
					if (ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION.equals(datoRegPreActual.getCodregipre())){
						tieneReposicion=true;	
						//break; PAS20165E220200041
					}else if(ConstantesDataCatalogo.REG_IMPO_CONSUMO.equals(datoRegPreActual.getCodregipre())){
							;
					}else{
						if (!tieneOtraPrecedencia)
							tieneOtraPrecedencia=true; 
					}
				}
			}		
		}
		if (tieneReposicion && !tieneOtraPrecedencia){
			tieneQueDatar = true;
		}
		if (!tieneReposicion && tieneOtraPrecedencia){
			tieneQueDatar = false;
		}
		if (!tieneReposicion && !tieneOtraPrecedencia){
			tieneQueDatar = true;
		}
		if (tieneReposicion && tieneOtraPrecedencia){
			tieneQueDatar = false;
		}
		return tieneQueDatar; 
	}

        /**
	 * Devuelve un determinado tipo de documento de soporte
	 * @param dua
	 * @param serie
	 * @param tipoDocAsociado
	 * @return
	 */
	public DatoOtroDocSoporte getDocSoportePorTipo (DUA dua, DatoSerie serie, String tipoDocAsociado){
		List<DatoOtroDocSoporte> listDocSoporte = getDocSoporte(dua,serie);
		for(DatoOtroDocSoporte docSoporte:listDocSoporte){
			//amancilla PAS20155E220200035 cae con null se cambia de posicion tal vez falte llenar en el mapa conver
			//if (docSoporte.getCodtipodocasoc().equals(tipoDocAsociado)){
			if (tipoDocAsociado.equals(docSoporte.getCodtipodocasoc())){
				return docSoporte;
			}				
		}
		return new DatoOtroDocSoporte();
	}	

	/**
	 * Permite obtener el numero de factura asociado a una determinada serie
	 * @param dua
	 * @param serie
	 * @return
	 */
	public String getNumFactura(DUA dua, DatoSerie serie){
		List<DatoFacturaref> lstFacturas= getFacturaRef(dua, serie);
		DatoFacturaref facturaRef=new DatoFacturaref();
		if(!CollectionUtils.isEmpty(lstFacturas))
			facturaRef=lstFacturas.get(0);
		
		String numFacturaRef=facturaRef.getNumfactura();
		return numFacturaRef;
	}
  
	/**
	 * Permite obtener datos de la factura asociada a una determinada serie
	 * @param dua
	 * @param serie
	 * @return
	 */
	public DatoFacturaref getDatoFacturaRef(DUA dua, DatoSerie serie){
		List<DatoFacturaref> lstFacturas= getFacturaRef(dua, serie);
		DatoFacturaref facturaRef=new DatoFacturaref();
		if(!CollectionUtils.isEmpty(lstFacturas))
			facturaRef=lstFacturas.get(0);
		
		
		return facturaRef;
	}
	
	
	
	/**
	 * Obtiene el proveedor correspondiente a una serie
	 * @param serie
	 * @param declaracion
	 * @return
	 */
	protected Participante getProveedorCorrespondiente(DatoSerie serie, Declaracion declaracion) {
		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura factura : dav.getListFacturas()) {
				for (DatoItem item : factura.getListItems()) {
					for (DatoSerieItem serieItem : item.getListSerieItems()) {
						if (SunatNumberUtils.isEqual(serieItem.getNumserie(), serie.getNumserie())) {
							return dav.getProveedor();
						}
					}
				}
			}
		}

		return null;
	}

	/**
	 * devuelve el codigo de indicador si existe caso contrario devuelve null 
	 * @param dua
	 * @param codIndicador
	 * @return
	 */
	public String getIndicador(DUA dua , String codIndicador){
		List<DatoIndicadores> lstIndicadores= dua.getListIndicadores();
		DatoIndicadores indicadorEncontrado= null;
		if( lstIndicadores!=null && lstIndicadores.size()>0 ) {  //PAS20171U220200005
			for(DatoIndicadores indicador : lstIndicadores){
				String indicadorBD = indicador.getCodtipoindica()==null ? "" : indicador.getCodtipoindica();
				if(indicadorBD.equals(codIndicador)){
					indicadorEncontrado = indicador;
					break;
					
				}	
			}	
		}
		if(indicadorEncontrado!=null)
			return indicadorEncontrado.getCodtipoindica();
		return null;
	}
	
	//glazaror msnade236_1
	protected DatoAutocertificacion getCertificadoOrigen(DatoSerie serie) {
		DUA dua = (DUA) serie.getPadre();
		List<DatoAutocertificacion> certificadosOrigen = getCertiOrigen(dua, serie);
		if (!CollectionUtils.isEmpty(certificadosOrigen)) {
			return certificadosOrigen.get(0);
		}
		return null;
	}
	
	/**
	 * Se verifica si cuando se modifica la Fecha del Certificado de Origen, el TPI debe tomar la Fecha de referencia la Fecha en que se realiza la Modificacion.
	 * @param serie
	 * @param duaBD
	 * @param serieBD
	 * @return
	 */
	//glazaror msnade236_1... se mueve aqui desde pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.TratoPreferencialInternacionalServiceImpl
	//para poder reutilizar este metodo en otras clases especializadas
	protected boolean esRectificacionFechaCertiOrigen(FabricaDeServicios fabricaDeServicios, DatoSerie serie, DUA duaBD, DatoSerie serieBD) {
		boolean esDiferenteFechaCO = false;//se cambia nombre porque detecta que hay cambios de fecha de CO entre BD y XML TPI814
		
		String codTPI = serie.getCodconvinter().toString();
		DataGrupoCat dato = ((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataGrupoCat(GRUPO_TLC_MODIFICACION_FECHA_CO, codTPI);
		
		if (dato != null){
			
			DUA dua = (DUA) serie.getPadre();
			List<DatoAutocertificacion> listCertificadoOrigen=getCertiOrigen(dua, serie);
			List<DatoAutocertificacion> listCertificadoOrigenBD=getCertiOrigen(duaBD, serieBD);
			
			Date fecemision = listCertificadoOrigen.get(0).getFecemision();
			Date fecemisionBD =!CollectionUtils.isEmpty(listCertificadoOrigenBD)?listCertificadoOrigenBD.get(0).getFecemision():SunatDateUtils.getDefaultDate();
			
			if (!SunatDateUtils.sonIguales(fecemision, fecemisionBD,SunatDateUtils.COMPARA_SOLO_FECHA)){//PAS20175E220200050
				// Esta rectificando la Fecha del Certificado de Origen
				esDiferenteFechaCO = true;
			}
		}
		
		return esDiferenteFechaCO;
	}
	
	public Map<String,String> getErrorMapWithDescription(String errorCode, String description){
		
		if( SunatStringUtils.isEmpty(errorCode) )
			return getEmptyErrorMap(errorCode);		
		
		errorCode = SunatStringUtils.lpad(errorCode, 5, '0');
		
		DataCatalogo dataCatalogo =((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo("F09", errorCode);
		if(dataCatalogo != null)
		{
			return getErrorMapFromDataCatalogo(dataCatalogo);
		}else{
			return getEmptyErrorMap(errorCode);
		}

	}	
	
	private Map<String,String>  getEmptyErrorMap(String errorCode){
		Map<String,String> map = new HashMap<String, String>();
		map.put(ResponseMapManager.KEY_CODIGO, SunatStringUtils.isEmpty(errorCode) ? "XXXXX": errorCode );
		map.put(ResponseMapManager.KEY_DESCRIPCION, " ");
		map.put(ResponseMapManager.KEY_TIPO_ALERTA, ResponseMapManager.VALUE_TIPO_ALERTA_WARNING);			
		return map;
	}
  
	private Map<String,String>  getErrorMapFromDataCatalogo(DataCatalogo dataCatalogo)
	{
		Map<String,String> map = new HashMap<String, String>();
		map.put(ResponseMapManager.KEY_CODIGO, dataCatalogo.getCodDatacat() );
		map.put(ResponseMapManager.KEY_DESCRIPCION, dataCatalogo.getDesDatacat());
		map.put(ResponseMapManager.KEY_TIPO_ALERTA, ResponseMapManager.VALUE_TIPO_ALERTA_WARNING);			
		
		return map;
	}
	
	public Map<String,String> getErrorMap(String errorCode, Object[] args){
		if( SunatStringUtils.isEmpty(errorCode) )
			return getEmptyErrorMap(errorCode);		
		errorCode = SunatStringUtils.lpad(errorCode, 5, '0');		

		DataCatalogo dataCatalogo =((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo("F09", errorCode);
		if(dataCatalogo != null) {
			dataCatalogo.setDesDatacat( MessageFormat.format( dataCatalogo.getDesDatacat(), args )  );			
			return getErrorMapFromDataCatalogo(dataCatalogo);
		}else{
			return getEmptyErrorMap(errorCode);
		}		
	}	
	
		
	public Map<String,String> getErrorMap(String errorCode, Object args){
		
		if( SunatStringUtils.isEmpty(errorCode) )
			return getEmptyErrorMap(errorCode);
		
		errorCode = SunatStringUtils.lpad(errorCode, 5, '0');
		
		DataCatalogo dataCatalogo =((CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getDataCatalogo("F09", errorCode);
		if(dataCatalogo != null)
		{
			dataCatalogo.setDesDatacat( MessageFormat.format( dataCatalogo.getDesDatacat(), new Object[]{args} )  );	
			
			return getErrorMapFromDataCatalogo(dataCatalogo);
		}else{
			return getEmptyErrorMap(errorCode);
		}
		
	}


	/*
	public TablnewDAOService getTablnewDAOService() {
		return tablnewDAOService;
	}

	public void setTablnewDAOService(TablnewDAOService tablnewDAOService) {
		this.tablnewDAOService = tablnewDAOService;
	}*/


	
	
	
}
