/*
 * Clase que define el servicio de validaciones del declarante de la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FormatoAServiceImpl;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValDeclaran. Clase que define el servicio de validaciones del declarante de la DUA
 */
public class ValDeclaranServiceImpl extends ValDuaAbstract implements  ValDeclaran{

	//private FabricaDeServicios fabricaDeServicios;

	/**
	 * Valida el Tipo participante.<br>
	 * Valida que el campo numsecuparticipante de los elementos de la lista sean secuenciales de 1 a n.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error. 
	 * 
	 * @param tipoParticipante DataCatalogo, tipo de participante
	 * @return Map
	 */
	public Map<String, String> tipoParticipante (DataCatalogo tipoParticipante){
		String codtipparticipante=tipoParticipante.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("316", codtipparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("316", codtipparticipante,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return ResponseMapManager.getErrorResponseMap("30298","Error catalogo codtipparticipante");	
	}

	/**
	 * Valida el Tipo documento identidad.
	 * 
	 * @param tipoDocumentoIdentidad DataCatalogo, Tipo documento identidad.
	 * @return el mapa de errrores
	 */
	public Map<String, String> tipoDocumentoIdentidad(DataCatalogo tipoDocumentoIdentidad){
		String codtipdocparticipante=tipoDocumentoIdentidad.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("27", codtipdocparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", codtipdocparticipante, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return ResponseMapManager.getErrorResponseMap("30299","Error catalogo codtipdocparticipante");	
	}

	/**
	 * Valida el numero de documento de identidad del declarante.<br>
	 * 
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numeroDocumentoIdentidad String
	 * @return Map
	 */
	public Map<String, String> numeroDocumentoIdentidad(String numeroDocumentoIdentidad){
		return !SunatStringUtils.isEmptyTrim(numeroDocumentoIdentidad)?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("30300","");
	}

	/**
	 * Valida el pais del declarante.
	 * 
	 * @param pais DataCatalogo
	 * @return el mapa de errrores
	 */
	public Map<String, String> pais(DataCatalogo pais){
		String codpaisparticipante=pais.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J2", codpaisparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codpaisparticipante, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return ResponseMapManager.getErrorResponseMap("30301","Error catalogo codpaisparticipante");	
	}

	/**
	 * Valida el nombre de la razon social.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param nombreRazonSocial String
	 * @return Map
	 */
	public Map<String, String> nombreRazonSocial(String nombreRazonSocial){
		return (!SunatStringUtils.isEmptyTrim(nombreRazonSocial) && nombreRazonSocial.trim().length()>=5)?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("30302","");
	}

	/**
	 * Valida la direccion del declarante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 10 caracteres.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param direccion String
	 * @return Map
	 */
	public Map<String, String> direccion(String direccion){
		return (!SunatStringUtils.isEmptyTrim(direccion) && direccion.trim().length()>=10)?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("","");
	}

	/**
	 * Valida la ciudad del declarante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param ciudad String
	 * @return Map
	 */
	public Map<String, String> ciudad(String ciudad){
		return (!SunatStringUtils.isEmptyTrim(ciudad) && ciudad.trim().length()>=5)?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("","");
	}


	/**
	 * Valida el telefono del declarante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param telefono String
	 * @return Map
	 */
	public Map<String, String> telefono(String telefono){
		return (!SunatStringUtils.isEmptyTrim(telefono) && telefono.trim().length()>=5)?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("","");
	}

	/**
	 * Valida el fax del declarante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fax String
	 * @return Map
	 */
	public Map<String, String> fax(String fax){
		return (!SunatStringUtils.isEmptyTrim(fax) && fax.trim().length()>=5)?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("","");
	}

	/**
	 * Valida el email del declarante.<br>
	 * Valida que el par&&acute;metro siempre tenga un valor y que corresponda a una direcci&oacute;n de correo electr&oacute;nico.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param email String, email del declarante
	 * @return Map
	 */
	public Map<String, String> email(String email){
		return (!SunatStringUtils.isEmptyTrim(email) && SunatStringUtils.isValidEmailAddress(email))?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("","");
	}

	/**
	 * Valida la pagina Web del declarante.<br> 
	 * 
	 * Valida que el par&&acute;metro siempre tenga un valor y que corresponda a una direcci&oacute;n de p&aacute;gina web.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param paginaWeb String, pagina Web del declarante
	 * @return Map
	 */
	public Map<String, String> paginaWeb(String paginaWeb){
		return (!SunatStringUtils.isEmptyTrim(paginaWeb) && SunatStringUtils.isValidURLAddress(paginaWeb))?new HashMap<String,String>():ResponseMapManager.getErrorResponseMap("","");
	}

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
*/

}
