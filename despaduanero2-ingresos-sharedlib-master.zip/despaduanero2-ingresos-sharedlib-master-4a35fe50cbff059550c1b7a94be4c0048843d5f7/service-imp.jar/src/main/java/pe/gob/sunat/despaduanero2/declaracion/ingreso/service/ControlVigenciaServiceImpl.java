package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;

public class ControlVigenciaServiceImpl extends IngresoAbstractServiceImpl implements ControlVigenciaService {

	public boolean esVigenteRIN05(Date fechaReferencia){ 
		
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");
		Date fechaEval = new Date();
		if(fechaReferencia!=null){
			fechaEval = fechaReferencia;
		}
		
		List<Map<String,String>> listaVigencia = catalogoValidaService.validarElementoCat(ConstantesDataCatalogo.COD_CATALOGO_VIGENCIA,
				ConstantesDataCatalogo.COD_DATACATALOGO_HABILITACION_RIN05, fechaEval); 
		
		if(!ResponseListManager.responseListHasErrors(listaVigencia)){	
			return true;
		}
		
		return false;
	}

	public boolean esVigenteRIN05PrimeraParte(Date fechaReferencia){ 
	
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");
		Date fechaEval = new Date();
		if(fechaReferencia!=null){
			fechaEval = fechaReferencia;
		}
		
		List<Map<String,String>> listaVigencia = catalogoValidaService.validarElementoCat(ConstantesDataCatalogo.COD_CATALOGO_VIGENCIA,
				ConstantesDataCatalogo.COD_DATACATALOGO_HABILITACION_RIN05, fechaEval); 
		
		if(!ResponseListManager.responseListHasErrors(listaVigencia)){	
			return true;
		}
		
		return false;
	}
	
	public boolean esVigenteRIN05SegundaParte(Date fechaReferencia){ 
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");		
		Date fechaEval = new Date();
		if(fechaReferencia!=null){
			fechaEval = fechaReferencia;
		}
		List<Map<String,String>> listaVigencia = catalogoValidaService.validarElementoCat(ConstantesDataCatalogo.COD_CATALOGO_VIGENCIA,
				ConstantesDataCatalogo.COD_DATACATALOGO_HABILITACION_RIN05SEGUNDAPARTE, fechaEval); 
	
		if(!ResponseListManager.responseListHasErrors(listaVigencia)){	
			return true;
		}	
		return false;
	}
	//csantillan PAS20181U220200054
	public boolean esVigenteRIN31(Date fechaReferencia){
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");
		Date fechaEval = new Date();
		if(fechaReferencia!=null){
			fechaEval = fechaReferencia;
		}
		final String COD_DATACATALOGO_HABILITACION_RIN31 = "0061";
		List<Map<String,String>> listaVigencia = catalogoValidaService.validarElementoCat(ConstantesDataCatalogo.COD_CATALOGO_VIGENCIA,
				COD_DATACATALOGO_HABILITACION_RIN31, fechaEval);

		if(!ResponseListManager.responseListHasErrors(listaVigencia)){
			return true;
		}
		return false;
	}
	public boolean esVigentePecoAmazoniaSegundaParte(Date fechaReferencia){
	
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");		
		Date fechaEval = new Date();
		if(fechaReferencia!=null){
			fechaEval = fechaReferencia;
		}
		List<Map<String,String>> listaVigencia = catalogoValidaService.validarElementoCat(ConstantesDataCatalogo.COD_CATALOGO_VIGENCIA,
				ConstantesDataCatalogo.COD_DATACATALOGO_HABILITACION_PECOAMAZONIASEGUNDAPARTE, fechaEval); 
	
		if(!ResponseListManager.responseListHasErrors(listaVigencia)){	
			return true;
		}	
		return false;
	
	}
	public boolean esVigenteRIN05SegundaParteII(Date fechaReferencia){ 
		CatalogoValidaService catalogoValidaService = (CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal");		
		Date fechaEval = new Date();
		if(fechaReferencia!=null){
			fechaEval = fechaReferencia;
		}
		List<Map<String,String>> listaVigencia = catalogoValidaService.validarElementoCat(ConstantesDataCatalogo.COD_CATALOGO_VIGENCIA,
				ConstantesDataCatalogo.COD_DATACATALOGO_HABILITACION_RIN05SEGUNDAPARTE, fechaEval); 
	
		if(!ResponseListManager.responseListHasErrors(listaVigencia)){	
			return true;
		}	
		return false;
	}
	
}
