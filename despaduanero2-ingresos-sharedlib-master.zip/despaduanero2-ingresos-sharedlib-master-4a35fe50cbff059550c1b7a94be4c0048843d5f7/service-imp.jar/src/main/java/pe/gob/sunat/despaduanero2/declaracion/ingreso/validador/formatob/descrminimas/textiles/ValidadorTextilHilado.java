package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilHilado;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * @author lalberti
 */
public class ValidadorTextilHilado extends ValidadorTextilAbstract
{

    private static List<String> unComSet                = new ArrayList<String>(Arrays.asList("KG", "LB"));
    private static String       codErrorUnidadComercial = "31301";

    public ValidadorTextilHilado()
    {
        super();
        //unComSet.add("KG");
        //unComSet.add("LB");
        //ValidadorTextilAbstract.getErrors().put("codUnComErr", "31301");
    }

    @Override
    public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract object, Declaracion dua) throws Exception
    {
        List<ErrorDescrMinima> lstErrores = validarEstructura(object);


        //lstErrores.addAll(validarEstructura(object));

        if (CollectionUtils.isEmpty(lstErrores))
        {
            DatoItem item = obtenerItem(object, dua);
            lstErrores.addAll(this.validarUnidadComercial(object, item, unComSet,codErrorUnidadComercial));
            lstErrores.addAll(this.validarFOBVsPesoObs(object, dua));
            lstErrores.addAll(validarComponentesHilado(object));
            lstErrores.addAll(validarSumaPorcenComp(object));
    }


    return lstErrores;
  }

  public List<ErrorDescrMinima> validarComponentesHilado(ModelAbstract object){
    TextilHilado hilado = (TextilHilado) object;
    List<DatoDescrMinima> componentes = new ArrayList<DatoDescrMinima>();
    componentes.add(hilado.getCompoHilado1erComp());
    componentes.add(hilado.getCompoHilado2doComp());
    componentes.add(hilado.getCompoHilado3erComp());
    componentes.add(hilado.getCompoHilado4toComp());
    return validarDuplicidad(hilado, componentes, "31825");
  }

  public List<ErrorDescrMinima> validarTipoFibra(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoHilado1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoHiladoPorcen1erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarGradoElaboracion(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarPrimerAcabado(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarSegundoAcabado(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarPresentacion(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarDensidadLineal(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarEstructuraFisicaYUso(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoHilado2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoHiladoPorcen2doComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoHilado3erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoHiladoPorcen3erComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoHilado4toComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarCompoHiladoPorcen4toComp(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarSumaPorcenComp(ModelAbstract object){
    List<ErrorDescrMinima> lst =  new ArrayList<ErrorDescrMinima>();
    TextilHilado hilado = (TextilHilado) object;
    Integer p1 = 0;
    Integer p2 = 0;
    Integer p3 = 0;
    Integer p4 = 0;
    try{
      p1 = hilado.getCompoHiladoPorcen1erComp()!=null && 
      		  !SunatStringUtils.isEmptyTrim(hilado.getCompoHiladoPorcen1erComp().getValtipdescri())?
      		  Integer.parseInt(hilado.getCompoHiladoPorcen1erComp().getValtipdescri()):0; 
      p2 = hilado.getCompoHiladoPorcen2doComp()!=null && 
    		  !SunatStringUtils.isEmptyTrim(hilado.getCompoHiladoPorcen2doComp().getValtipdescri())?
    		  Integer.parseInt(hilado.getCompoHiladoPorcen2doComp().getValtipdescri()):0;
      p3 = hilado.getCompoHiladoPorcen3erComp()!=null &&
    		  !SunatStringUtils.isEmptyTrim(hilado.getCompoHiladoPorcen3erComp().getValtipdescri())?
              Integer.parseInt(hilado.getCompoHiladoPorcen3erComp().getValtipdescri()):0;
      p4 = hilado.getCompoHiladoPorcen4toComp()!=null &&
    		  !SunatStringUtils.isEmptyTrim(hilado.getCompoHiladoPorcen4toComp().getValtipdescri())?
    		  Integer.parseInt(hilado.getCompoHiladoPorcen4toComp().getValtipdescri()):0;
    }catch(NumberFormatException e){}
    if((p1 + p2 + p3 + p4) != 100){
      Integer sum = p1 + p2+ p3+p4;
      DatoDescrMinima suma = hilado.getCompoHiladoPorcen1erComp();
      suma.setValtipdescri(sum.toString());
      lst.add(obtenerError("31369", suma));
    }
    return lst;
  }
}
