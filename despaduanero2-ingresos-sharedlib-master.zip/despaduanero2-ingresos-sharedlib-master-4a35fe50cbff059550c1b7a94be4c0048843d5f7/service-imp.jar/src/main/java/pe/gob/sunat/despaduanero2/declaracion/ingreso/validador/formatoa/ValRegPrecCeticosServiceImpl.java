package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero.despacho.especial.ct.model.TrasladoCetico;
import pe.gob.sunat.despaduanero.despacho.especial.ct.model.TrasladoSeriesCetico;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValItemFB;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.DescrMinimaHelper;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service.VehiculoService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageTD;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.FormatoBUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGasto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoMontoGastoUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoVehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DuaRegPre;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DocuPreceDuaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DuaRegPreDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.MrestriDAO;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionService;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.sigad.despacho.especial.service.TrasladoCeticoService;

public class ValRegPrecCeticosServiceImpl extends ValDuaAbstract implements ValRegPrecCeticosService {

	//private FabricaDeServicios	fabricaDeServicios;


	public List<Map<String,String>> valDetRegPreCeticos(Declaracion  declaracion,DatoSerie serie, DatoRegPrecedencia regPrec, Date fechaReferencia, String  codTransaccion){

		String maduana = declaracion.getCodaduana();
		List<Map<String, String>> listError=new ArrayList<Map<String, String>>();
		//RIN 1.1 Si el Regimen precendente es 91 y la modalidad es distinto de excepcional
		if ("91".equals(regPrec.getCodregipre()) && (!"00".equals(declaracion.getDua().getCodmodalidad()))) {
			//grabaTelelog(listError,"30455","MODALIDAD DE DESPACHO NO CORRESPONDE PARA ACOGIMIENTO CON SOLICITUD DE TRASLADO CETICOS");
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30455"));
		}
		//RIN 1.2 Se valida Aduana de Transmision
		if("91".equals(regPrec.getCodregipre()) && !SunatStringUtils.include(maduana, new String[]{"046","145","163"})){
			//grabaTelelog(listError,"30497","ADUANA INCORRECTA PARA CETICOS");
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30497"));
		}

		//JPL: Si el Regimen Precedente de una serie es 91 de CETICOS 
		// y el Regimen actual es 10,20 o 21
		// y la modalidad es Excepcional 00
		//if ("91".equals(regPrec.getCodregipre()) && "10".equals(declaracion.getDua().getCodregimen())){
		if ("91".equals(regPrec.getCodregipre()) && 
				(("10".equals(declaracion.getDua().getCodregimen())) ||
						("20".equals(declaracion.getDua().getCodregimen())) ||
						("21".equals(declaracion.getDua().getCodregimen()))) &&
				"00".equals(declaracion.getDua().getCodmodalidad())    
				){

			//JPL 20110216 
			//RIN 1.3  Valida Solicitud de Traslado
			//RIN 1.4 1.5 Si se realiza la declaracion con RUC y no tiene ventas Sucecivas
			//Se valida que el RUC declarado corresponda con el usuario de CETICO que realizo la solicitud
			//RIN 1.6 Se valida Manifiesto registrado en la DUA igual a la S/T
			//RIN 1.7 Se valida Fecha de Recepcion de la S/T

			TrasladoCeticoService trasladoCeticoService = fabricaDeServicios.getService("sigad.despacho.especial.service.trasladoCeticoService");
			
			TrasladoCetico trasladoCetico = trasladoCeticoService.selectTrasladoCeticoByPk(regPrec.getCodaduapre(),regPrec.getAnndeclpre() != null ? regPrec.getAnndeclpre().substring(0, 4) : "",Cadena.padLeft(regPrec.getNumdeclpre(),6,'0'));
			if (trasladoCetico != null) {
				//Por regla R1884 - RIN05 - PAS20181U220200049
				CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
				Map<String, Object> MapaValManNum = catalogoAyudaService.getElementoCat("380", "0045", fechaReferencia);
				if (CollectionUtils.isEmpty(MapaValManNum)){
					String annmanif = declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4)!=null?declaracion.getDua().getManifiesto().getAnnmanif().substring(0, 4): " ";
					if((!trasladoCetico.getNumeManif().trim().equals(declaracion.getDua().getManifiesto().getNummanif())) ||
							((!trasladoCetico.getCaduManif().equals(declaracion.getDua().getManifiesto().getCodaduamanif())) ||
									((!trasladoCetico.getAnnoManif().equals(annmanif))))){
						//grabaTelelog(listError, "30499","MANIFIESTO CONSIGNADO EN LA DUA NO CORRESPONDE AL MANIFIESTO DE LA SOLICITUD DE TRASLADO");
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30499"));
					}					
				}

				if(declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat().equals("4") && !this.tieneVentasSucecivas(serie,declaracion)){
					if (!declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad().equals(trasladoCetico.getNroDocumento())) {
						//grabaTelelog(listError, "30456","RUC DECLARADO NO CORRESPONDE AL RUC DEL USUARIO DE CETICOS");
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30456"));
					}
				}

				if (trasladoCetico.getFrecepOfad() == null || trasladoCetico.getFrecepOfad()==0){
					//grabaTelelog(listError,"5769","REG. PREC : SOLICITUD DE TRASLADO NO RECEPCIONADA EN CETICOS");
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("05769"));
				}
			} else {
				//grabaTelelog(listError,"5768","NUMERO DE SOLICITUD DE TRASLADO DE MERCANCIAS A CETICOS NO EXISTE");//cambia de mensaje
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("05768"));
				//break;//jenciso pase 2014-039 se reemplaza por un return para que no continue con las dem�s validaciones
				return listError;
			}

			//RIN 1.8 Se valida por serie el registro del regimen precedente de la serie. 
			//RIN 1.9 Se valida documento de transporte declarado igual a la S/T
			
			//TrasladoSeriesCetico trasladoSeriesCetico=FormatoAServiceImpl.getInstance().getTrasladoSeriesCeticoDAO().selectByPrimaryKey(regPrec.getCodaduapre(),regPrec.getAnndeclpre()!=null?regPrec.getAnndeclpre().substring(0,4):"",Cadena.padLeft(String.valueOf(regPrec.getNumserpre()), 4, ' '),Cadena.padLeft(regPrec.getNumdeclpre(),6,'0'));
			TrasladoSeriesCetico trasladoSeriesCetico= trasladoCeticoService.selectSerieTrasladoCeticoByPk(regPrec.getCodaduapre(),regPrec.getAnndeclpre()!=null?regPrec.getAnndeclpre().substring(0,4):"",Cadena.padLeft(String.valueOf(regPrec.getNumserpre()), 4, ' '),Cadena.padLeft(regPrec.getNumdeclpre(),6,'0'));

			if(trasladoSeriesCetico!=null)
			{
				if(trasladoSeriesCetico.getAduana()==null ||
						trasladoSeriesCetico.getAno()==null ||
						trasladoSeriesCetico.getCetico()==null ||
						trasladoSeriesCetico.getNumero()==null ||
						trasladoSeriesCetico.getNserie()==null)
				{
					//grabaTelelog(listError,"30457","FALTA UN DATO DE LA SOLICITUD DE SERIE CETICO");
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30457"));
				}

				DatoDocTransporte docTransporteSerie=getDocTransporte(declaracion.getDua(), serie);
				String numDocTransporte;
				numDocTransporte = "";
				if(docTransporteSerie != null){
					numDocTransporte = docTransporteSerie.getNumdoctransporte();
					if (!numDocTransporte.equals(trasladoSeriesCetico.getConoEmbar())) {
						//grabaTelelog(listError, "30511","DOCUMENTO DE TRANSPORTE DECLARADO PARA LA SERIE NO CORRESPONDE CON EL REGISTRADO EN LA SERIE DE LA S/T");
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30511"));
					}
				}

				//Sistema 3003 RF 1.4 -- jenciso pase 2014-039
				if(!SunatDateUtils.getIntegerFromDate(regPrec.getFecvencpre()).equals(trasladoSeriesCetico.getFvencPlazo())){
					//grabaTelelog(listError,"30767","FECHA DE VENCIMIENTO DE LA SOLICITUD DE TRASLADO DE MERCANCIAS A CETICOS NO ES LA REGISTRADA EN LA SOLICITUD DE TRASLADO A CETICOS");//por registrar
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30767"));
				}

				//RIN 1.10 Para los regimenes 20,21 valida que la fecha de numeracion,
				//sea anterior o igual a la fecha de fin de vigencia de la solic de traslado a CETICOS
				if(SunatDateUtils.getIntegerFromDate(fechaReferencia)>trasladoSeriesCetico.getFvencPlazo() &&
						(	    ("20".equals(declaracion.getDua().getCodregimen())) ||
								("21".equals(declaracion.getDua().getCodregimen()))))
				{
					//grabaTelelog(listError,"30458","SOLICITUD DE TRASLADO A CETICOS VENCIDA"); //jenciso - se cambia en base a la RIN	
					//grabaTelelog(listError,"30768","FECHA DE VENCIMIENTO DE LA SOLICITUD DE TRASLADO DE MERCANCIAS A CETICOS SE ENCUENTRA VENCIDA");
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30768"));

				}
			}else{
				//grabaTelelog(listError,"30459","SERIE DE LA SOLICITUD DE TRASLADO A CETICOS NO EXISTE");
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30459"));
				//break;
				return listError;
			}	

			//jenciso pase 2014-039
			//RF 2.1 // la fecha de referencia debe ser la fecha de numeraci�n de la declaraci�n
			//sistema 3003 
			//se obtiene la subpartida nacional correlacionada
			ProveedorFuncionesService funcionesService = fabricaDeServicios.getService("funcionesService");
			Long partidaCorrelacionada = null; 
			partidaCorrelacionada = funcionesService.getCorrelPartida(8701200000L,new Long(0), SunatDateUtils.getIntegerFromDate(fechaReferencia));

			//RIN 2.1 Implica que se ejecutaran las demas 8.2 en adelante.....
			if( serie.getNumpartnandi() == 8701200000L || serie.getNumpartnandi().equals(partidaCorrelacionada) || SunatStringUtils.isStringInList ( SunatStringUtils.substringFox(serie.getNumpartnandi().toString(), 1, 4) , "8702,8703,8704,8705"))
			{														
				//RIN 2.2 Se valida clase de bulto VEI
				if (!"VEI".equals(serie.getCodclasbul())){
					//grabaTelelog(listError,"30498","NO HA DECLARADO LA CLASE VEI PARA VEHICULOS CETICOS");
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30498"));
				}	

				ValItemFB valItemFB = fabricaDeServicios.getService("ValItemFB");
				DatoItem itemFB = valItemFB.getItemCorrespondiente(serie, declaracion);

				//RIN 2.3 Se valida estado de la mercancia
				if(itemFB!=null && itemFB.getCodestamer()!=null ){//jenciso solo si existe itemFB
					if(!SunatStringUtils.isStringInList(itemFB.getCodestamer(), "20,21,22,23,24,25,27,28") ){
						//grabaTelelog(listError,"30477","ESTADO DE LA MERCANC�A NO ES USADA, NO CORRESPONDE A CETICOS");
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30477"));
					}
				}
				//RIN 2.4 Regimen Precedente Nacionalizado Anteriormente con otra DUA.
				Map<String, String> mapParametros = new HashMap<String, String>();
				mapParametros.put("NUM_DECLARACIONPRE", regPrec.getNumdeclpre());
				mapParametros.put("ANN_PRESENPRE", regPrec.getAnndeclpre()!=null?regPrec.getAnndeclpre().substring(0,4):"");
				mapParametros.put("COD_ADUANAPRE", regPrec.getCodaduapre());
				mapParametros.put("COD_REGIMENPRE", regPrec.getCodregipre());
				mapParametros.put("NUM_SECSERIEPRE", Cadena.padLeft(String.valueOf(regPrec.getNumserpre()), 4, ' '));


				//GetDeclaracionService getDeclaracionService = fabricaDeServicios.getService("declaracionService");
				DocuPreceDuaDAO docuPreceDuaDAO = fabricaDeServicios.getService("docuPreceDuaDAO");
				List<Map<String, Object>> lstSeriesPrecedentes = docuPreceDuaDAO.select(new HashMap<String, Object>(mapParametros));
				if(!CollectionUtils.isEmpty(lstSeriesPrecedentes))
				{
					for(Map<String, Object> mapPrec:lstSeriesPrecedentes)
					{
						String strNumCorreDocAnt = ((BigDecimal)mapPrec.get("NUM_CORREDOC")).toString();
						String strNumSerieDocAnt = ((BigDecimal)mapPrec.get("NUM_SECSERIEPRE")).toString();
						String strIndel = SunatNumberUtils.toBigDecimal(mapPrec.get("IND_DEL")).toString();
						if(Integer.parseInt(strNumSerieDocAnt)==(regPrec.getNumserpre()!=null?regPrec.getNumserpre():0) && !strIndel.equals("1")){
							
							DeclaracionService declaracionService = fabricaDeServicios.getService("declaracion.DeclaracionService");
							
							Map<String,Object> paramsCabDeclara=new HashMap<String,Object>();
							paramsCabDeclara.put("numeroCorrelativo", strNumCorreDocAnt);
							DUA numdeclaracion = (DUA) declaracionService.findDUAByKeyMap(paramsCabDeclara);

							String num_declaracion = SunatStringUtils.lpad(numdeclaracion.getNumdocumento(), 6, '0');
							Number annpresen = numdeclaracion.getAnnpresen();
							String codaduanaorden = numdeclaracion.getCodaduanaorden();

							if(declaracion.getNumdeclRef() != null){
								String num_declaref =SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(), 6, '0');
								if ((num_declaracion.equals(num_declaref)) && 
										(codaduanaorden.equals(declaracion.getNumdeclRef().getCodaduana()) )&&
										(annpresen.toString().equals(declaracion.getNumdeclRef().getAnnprese()))){
									break;
								}else {
									//grabaTelelog(listError,"30460",new Object[]{strNumSerieDocAnt, codaduanaorden + "-" + annpresen + "-" + num_declaracion});
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30460",new String[] {strNumSerieDocAnt, codaduanaorden + "-" + annpresen + "-" + num_declaracion}));
									break;													
								}															
							} else {
								//grabaTelelog(listError,"30460",new Object[]{strNumSerieDocAnt, codaduanaorden + "-" + annpresen + "-" + num_declaracion});
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30460",new String[] {strNumSerieDocAnt, codaduanaorden + "-" + annpresen + "-" + num_declaracion}));
								break;													
							}
						}
					}
				} else {

					Map<String, Object> mapDuaRegPre=new HashMap<String,Object>();
					mapDuaRegPre.put("caduregpre", trasladoSeriesCetico.getAduana());
					mapDuaRegPre.put("fanoregpre", trasladoSeriesCetico.getAno());
					mapDuaRegPre.put("ndclregpre", trasladoSeriesCetico.getNumero());
					mapDuaRegPre.put("nserregpre", trasladoSeriesCetico.getNserie()); 
					mapDuaRegPre.put("codiregpre", regPrec.getCodregipre());

					DuaRegPreDAO duaRegPreDAO = fabricaDeServicios.getService("duaregpreDAO");
					List<DuaRegPre> lsDuaRegPre=duaRegPreDAO.findDuaRegPreByParams(mapDuaRegPre);

					if(!CollectionUtils.isEmpty(lsDuaRegPre)){						        				
						DuaRegPre duaregpre= lsDuaRegPre.get(0); 
						//grabaTelelog(listError,"30460", new Object[]{trasladoSeriesCetico.getNserie(), duaregpre.getCodiAduan()+ "-" + duaregpre.getAnoPrese()+ "-" +duaregpre.getNumeCorre()});
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30460",new String[] {trasladoSeriesCetico.getNserie(), duaregpre.getCodiAduan()+ "-" + duaregpre.getAnoPrese()+ "-" +duaregpre.getNumeCorre()}));
						//break;
						return listError;
					}	
				}



				/***************************************************************************
						  JPL - Estas Validaciones ya estaban programadas solo se reubican de acuerdo a lo dispuesto en el RIN
				 ***************************************************************************/

				//HECHO Sql = "Select * from MRESTRI where codi_Regi='98' and tipodoc in ('1','4') and cnan = "+A_CADENA(SERIES.Part_Nandi,10)
				Map<String,Object> paramsMrestri=new HashMap<String,Object>();
				paramsMrestri.put("codi_regi", "98");
				paramsMrestri.put("tipodoc_in", " '1','4' ");
				paramsMrestri.put("cnan", serie.getNumpartnandi());
				/*KIB:cambiado con Elsa del catrefpartidas al Mrestri 24/02/2010
				 * int contMrestri=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO().count(paramsMrestri);
				 */

				MrestriDAO mrestriDAO = fabricaDeServicios.getService("mrestriDAO");
				int contMrestri=mrestriDAO.count(paramsMrestri);
				//contMrestri = 1; System.err.println("Mas datos de regimen de precedencia: " + serie.getCodclasbul() + " " + contMrestri); //OJO RETIRAR LUEGO
				if (contMrestri>0 && "VEI".equals(serie.getCodclasbul()) ){
					TrasladoSeriesCetico trasladoSeriesCetico1=trasladoCeticoService.selectSerieTrasladoCeticoByPk(regPrec.getCodaduapre(),regPrec.getAnndeclpre()!=null?regPrec.getAnndeclpre().substring(0,4):"",Cadena.padLeft(String.valueOf(regPrec.getNumserpre()), 4, ' '),Cadena.padLeft(regPrec.getNumdeclpre(),6,'0'));
					//RIN 2.5 Valida Fecha de Recepcion Cetico
					//TODO TDDI Regla 107 
					List<DatoItem> listItemsSerie=FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie);
					for(DatoItem item:listItemsSerie){
						//jenciso Inicio - carga las descripciones minimas
						DatoDescrMinima descrMinimaClasVari= null;
						if(CollectionUtils.isEmpty(item.getListDecrMinima())){
							/**Cambios por PAS20155E220000260 para considerar nueva estructura AREY***/
							if (!DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima())){		
								FormBItemDescriDAO formBItemDescriDAO = fabricaDeServicios.getService("formBItemDescriDAO");
								Map<String,Object> mapParams = new HashMap<String, Object>();
								mapParams.put("numcorredoc", declaracion.getNumeroCorrelativo());
								mapParams.put("numsecitem", item.getNumsecitem());
								mapParams.put("numsecfact", item.getNumsecfact());
								mapParams.put("numsecuprov", item.getNumsecprove());
								List<DatoDescrMinima> lstDescrMinima =  formBItemDescriDAO.findDescrMinimaByMap(mapParams);
								descrMinimaClasVari = FormatoBUtils.getDescrMinima(lstDescrMinima, "04");
								Elementos<DatoDescrMinima> elementosDescriMinima = new Elementos<DatoDescrMinima>();
								elementosDescriMinima.addAll(lstDescrMinima);
								item.setListDecrMinima(elementosDescriMinima);
							}
							/**Cambios por PAS20155E220000260 para considerar nueva estructura AREY***/
						}
						/***Se  comenta por ocasionar error PAS20155E220000260
					 else{

						descrMinimaClasVari=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "04");
					}
					//jenciso Fin
						 ***/
						/**Cambios por PAS20155E220000260 para considerar nueva estructura AREY***/
						try {
							validarVehiculosCETICOS(listError, serie, trasladoSeriesCetico1, item,declaracion);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}//fin del for del item
				}//fin clase bulto VEI

				//RIN 2.7 Se valida pesos y bultos declarados contra los de la S/T
				BigDecimal absoluteDiferenceBultoserie = SunatNumberUtils.absoluteDiference(new BigDecimal (trasladoSeriesCetico.getBulto()), serie.getCntbultos());
				if(!SunatNumberUtils.isEqualToZero(absoluteDiferenceBultoserie))
				{
					//grabaTelelog(listError,"30469","CANTIDAD DE BULTOS DE LA SERIE DE LA S/T NO COINCIDE CON CANTIDAD DE BULTOS DE LA SERIE");
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30469"));
				}

				BigDecimal absoluteDiferencePesoserie = SunatNumberUtils.absoluteDiference(trasladoSeriesCetico.getPeso(), serie.getCntpesobruto());
				if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferencePesoserie, new BigDecimal(0.5)))
				{
					//grabaTelelog(listError,"30470","PESO DE LA SERIE DE LA S/T NO COINCIDE CON PESO DE LA SERIE");
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30470"));
				}

				//Validaciones Hoja de Gastos
				//RIN 2.9.1
				List<DatoVehiculo> listVeh=serie.getListVehiculos();
				if (listVeh!=null && !listVeh.isEmpty()){
					for (DatoVehiculo vehiculo : serie.getListVehiculos()) {
						boolean booTienePublicacion = false;
						if(vehiculo.getNomlibro()!=null){

							if (vehiculo.getNomlibro().equals("SIN PUBLICACION") &&
									(vehiculo.getCodejempl()==null || SunatStringUtils.isEmptyTrim(vehiculo.getCodejempl()))&&
									(vehiculo.getNumpagin()==null || SunatNumberUtils.isEqualToZero(vehiculo.getNumpagin()))&&
									(vehiculo.getNumitemb())==null &&
									(vehiculo.getAnnmespubli()==null || vehiculo.getAnnmespubli().toString().equals("0") )&&
									(vehiculo.getNumfactconve()==null || SunatNumberUtils.isEqualToZero(vehiculo.getNumfactconve()) )) {
								booTienePublicacion = false;
							} else {
								if ((vehiculo.getNomlibro()) != null && (vehiculo.getAnnmespubli()) != null	&& !vehiculo.getNomlibro().equals("SIN PUBLICACION")) {
									booTienePublicacion = true;
								} else {// Validacion RIN 2.9.2
									//grabaTelelog(listError, "30500","DATOS DE LA PUBLICACION IMCOMPLETOS - EJEMPLAR Y FECHA DE LA PUBLICACION");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30500"));
									booTienePublicacion = true;
								}
							}
							//Validacion RIN 2.9.3 2.9.4
							//if((vehiculo.getNomlibro())!=null)
							//{booTienePublicacion = true;}

						}else { 
							//grabaTelelog(listError,"30514","SI NO DISPONE DE PUBLICACION DEBERA CONSIGNAR: SIN PUBLICACION,  EN LA CASILLA 2.1");
							listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30514"));
						}

						
						ValNegocNumeracFormA valNegocNumeracFormA = fabricaDeServicios.getService("ValNegocNumeracFormA");
						DatoMontoGastoUtil monGastoUtil = ConvertirListaAMontoGastoUtil(vehiculo.getListMontoGastos());
						DAV dav = valNegocNumeracFormA.getDAVCorrespondiente(serie,declaracion);
						DatoFactura factura = valNegocNumeracFormA.getFacturaCorrespondiente(serie,declaracion);

						if(SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMfobfact().getValmonto()) &&
								SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMflete().getValmonto()) &&
								SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMseguro().getValmonto())  &&
								SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMtasa().getValmonto()) &&
								SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMfobcalc().getValmonto()) &&
								SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMvaduan().getValmonto()))
						{
							//Si Tiene una publicacion de gastos
							if(booTienePublicacion)
							{													
								//RIN 2.9.5
								if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpublica().getValmonto()))!=true)
								{
									//grabaTelelog(listError,"30461","NO HA INGRESADO MONTO CONSIGNADO EN LA PUBLICACION");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30461"));
								}											
								//RIN 2.9.6
								if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpuaju().getValmonto()))!=true)
								{
									//grabaTelelog(listError,"30501","NO HA INGRESADO MONTO POR PUBLICACION MAS AJUSTES");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30501"));
								}
								//RIN 2.9.7
								BigDecimal bgSumatoriaOpcionales = new BigDecimal(0);
								bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMroof().getValmonto());
								bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMequicd().getValmonto());
								bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMnvcd().getValmonto());
								bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMnvdvd().getValmonto());
								bgSumatoriaOpcionales = SunatNumberUtils.sum(bgSumatoriaOpcionales, monGastoUtil.getMotpub().getValmonto());

								BigDecimal bgAbsoluteDiffOpcionales = SunatNumberUtils.absoluteDiference(monGastoUtil.getMopcpu().getValmonto(), bgSumatoriaOpcionales);

								if(!SunatNumberUtils.isLessOrEqualsThanParam(bgAbsoluteDiffOpcionales, new BigDecimal(1)))
								{
									//grabaTelelog(listError,"30462","MONTO US$ AJUSTE POR OPCIONALES SEG�N PUBLICACI�N NO COINCIDE.");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30462"));
								}
								//RIN 2.9.8
								BigDecimal bgSumatoriaOpcAjustes = new BigDecimal(0);
								bgSumatoriaOpcAjustes = SunatNumberUtils.sum(bgSumatoriaOpcAjustes, monGastoUtil.getMpublica().getValmonto());
								bgSumatoriaOpcAjustes = SunatNumberUtils.sum(bgSumatoriaOpcAjustes, monGastoUtil.getMtrans().getValmonto());
								bgSumatoriaOpcAjustes = SunatNumberUtils.sum(bgSumatoriaOpcAjustes, monGastoUtil.getMopcpu().getValmonto());

								BigDecimal bgAbsoluteDiffOpcAjustes = SunatNumberUtils.absoluteDiference(monGastoUtil.getMpuaju().getValmonto(), bgSumatoriaOpcAjustes);

								if(!SunatNumberUtils.isLessOrEqualsThanParam(bgAbsoluteDiffOpcAjustes, new BigDecimal(1)))
								{
									//grabaTelelog(listError,"30463","MONTO US$ RESULTANTE DE LA PUBLICACI�N INCLUIDO AJUSTES NO COINCIDE");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30463"));
								}
								//RIN 2.9.9										
								BigDecimal absoluteDiferenceFOB = SunatNumberUtils.absoluteDiference(monGastoUtil.getMpuaju().getValmonto(), FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PREC_FACTU).getMtologistico());

								if(     SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpuaju().getValmonto()) &&
										!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceFOB, new BigDecimal(1)) ){	
									//grabaTelelog(listError,"30464","MONTO EN US$ RESULTANTE DE LA PUBLICACI�N INCLUIDO AJUSTES NO COINCIDE CON EL FORMATO B");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30464"));
								}

								//RIN 2.9.10
								BigDecimal bgSumatoriaFobParciales = new BigDecimal(0);
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMpuaju().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtasa().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtranex().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtranin().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtrasla().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMuventa().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMotrost().getValmonto());
								//Campos de la Casilla 5
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMnvtv().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMnvdvdtv().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMaire().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMtapiz().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMccolor().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMaro().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMctrans().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMadapta().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMotros().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMroofa().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMequicda().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMnvcda().getValmonto());
								bgSumatoriaFobParciales = SunatNumberUtils.sum(bgSumatoriaFobParciales, monGastoUtil.getMnvdvda().getValmonto());

								BigDecimal absoluteDiferenceSumFOBPar = SunatNumberUtils.absoluteDiference(monGastoUtil.getMfobcalc().getValmonto(), bgSumatoriaFobParciales);

								if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceSumFOBPar, new BigDecimal(1))) {
									//grabaTelelog(listError,"30465","TOTAL US$ VALOR FOB CALCULADO NO COINCIDE");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30465"));
								}

								//RIN 2.9.11
								BigDecimal bgMontoTotalAdicional = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MASDSCTO).getMtologistico();

								BigDecimal bgSumatoriaGastoCetico = new BigDecimal(0);
								//Campos de la Casilla 4
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtasa().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtranex().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtranin().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtrasla().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMuventa().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMotrost().getValmonto());
								//Campos de la Casilla 5
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMnvtv().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMnvdvdtv().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMaire().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMtapiz().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMccolor().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMaro().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMctrans().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMadapta().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMotros().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMroofa().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMequicda().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMnvcda().getValmonto());
								bgSumatoriaGastoCetico = SunatNumberUtils.sum(bgSumatoriaGastoCetico, monGastoUtil.getMnvdvda().getValmonto());

								BigDecimal absoluteDiferenceSumGasCetico = SunatNumberUtils.absoluteDiference(bgMontoTotalAdicional, bgSumatoriaGastoCetico);

								if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceSumGasCetico, new BigDecimal(1))) {
									//grabaTelelog(listError,"30466","GASTOS DE CETICOS NO COINCIDE CON FORMATO B");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30466"));
								}

							}
							//Si no tiene una publicacion de gastos
							else
							{ //RIN 2.9.12
								if(SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpublica().getValmonto()) ||
										SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMtrans().getValmonto()) ||
										SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMopcpu().getValmonto()) ||
										SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMpuaju().getValmonto())) {

									//grabaTelelog(listError,"30502","SI NO CUENTA CON LA PUBLICACION NO DEBE CONSIGNAR INFORMACION EN LAS CASILLAS DATOS DE LA PUBLICACION NI EN LAS CASILLAS 3.1 a 3.4.");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30502"));
								}else  {											
									//RIN 2.9.13
									List<DatoItem> listItemsSerie=FormatoBUtils.getItemsSeries(declaracion.getListDAVs(), serie);
									for(DatoItem item:listItemsSerie){

										/**Inicio de cambios PAS20155E220000260 AREY**/
										VehiculoService vehiculoService = fabricaDeServicios.getService("descripcionMinima.VehiculoService");	
										String repB = null;
										try {
											repB = vehiculoService.obtenerGastosReparacion(item, declaracion);
										} catch (Exception e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
										BigDecimal bgRepB = new BigDecimal(0);
										if(!SunatStringUtils.isEmptyTrim(repB)){
											try{
												bgRepB = new BigDecimal (repB);
											}catch(NumberFormatException e){
												//grabaTelelog(listError,"30512","REGISTRAR GASTOS POR REPARACION Pos:47-52 DESCOM3");
												listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30512"));
											}
										}else{
											//grabaTelelog(listError,"30512","REGISTRAR GASTOS POR REPARACION Pos:47-52 DESCOM3");
											listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30512"));
										}

										BigDecimal bgPrecioRepB = new BigDecimal(0);
										BigDecimal bgPreciofactB = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PREC_FACTU).getMtologistico();
										bgPrecioRepB = SunatNumberUtils.sum(bgPreciofactB, bgRepB);
										BigDecimal bgPrecioGastHoja = new BigDecimal(0);
										bgPrecioGastHoja = SunatNumberUtils.sum(bgPrecioGastHoja, monGastoUtil.getMfobfact().getValmonto());
										bgPrecioGastHoja = SunatNumberUtils.sum(bgPrecioGastHoja, monGastoUtil.getMrepara().getValmonto());

										BigDecimal absoluteDiferenceSumPrecFact = SunatNumberUtils.absoluteDiference(bgPrecioRepB, bgPrecioGastHoja);

										if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceSumPrecFact, new BigDecimal(1))) {
											//grabaTelelog(listError,"30467","VALOR DE FACTURA + GASTOS DE REPARACI�N NO COINCIDE CON EL MONTO DEL FORMATO B (BDUADET2 O ARCHIVO EQUIVALENTE");
											listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30467"));
										}
									}
									//RIN 2.9.14
									BigDecimal bgMontoFOBFactcom = monGastoUtil.getMfobfact().getValmonto();
									BigDecimal bgPreciofactB2 = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_PREC_FACTU).getMtologistico();

									if(SunatNumberUtils.isGreaterOrEqualsThanZero(bgMontoFOBFactcom) &&
											!SunatNumberUtils.isEqual(bgMontoFOBFactcom, bgPreciofactB2)){
										//grabaTelelog(listError,"30468","MONTO US$ EN FACTURA DE EXPORTACI�N NO COINCIDE CON EL DEL FORMATO B");
										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30468"));
									}
									//RIN 2.9.15
									BigDecimal bgFobCalculado = monGastoUtil.getMfobcalc().getValmonto();
									BigDecimal bgFobParciales = new BigDecimal(0);
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMfobfact().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMrepara().getValmonto());
									//Casillas 4.1 - 4.7
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMctimon().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtasa().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtranex().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtranin().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtrasla().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMuventa().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMotrost().getValmonto());
									//Casillas 5
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMnvtv().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMnvdvdtv().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMaire().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMtapiz().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMccolor().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMaro().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMctrans().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMadapta().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMotros().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMroofa().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMequicda().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMnvcda().getValmonto());
									bgFobParciales = SunatNumberUtils.sum(bgFobParciales, monGastoUtil.getMnvdvda().getValmonto());

									BigDecimal absoluteDiferenceParcCalc = SunatNumberUtils.absoluteDiference(bgFobCalculado, bgFobParciales);

									if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceParcCalc, new BigDecimal(1))) {
										//grabaTelelog(listError,"30465","TOTAL US$ VALOR FOB CALCULADO NO COINCIDE");
										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30465"));
									}
									//RIN 2.9.16
									BigDecimal bgOtrasAdic = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_MASDSCTO).getMtologistico();
									BigDecimal bgFobParciales2 = new BigDecimal(0);
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMrepara().getValmonto());
									//Casillas 4.1 - 4.7
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMctimon().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtasa().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtranex().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtranin().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtrasla().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMuventa().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMotrost().getValmonto());
									//Casillas 5
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMnvtv().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMnvdvdtv().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMaire().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMtapiz().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMccolor().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMaro().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMctrans().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMadapta().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMotros().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMroofa().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMequicda().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMnvcda().getValmonto());
									bgFobParciales2 = SunatNumberUtils.sum(bgFobParciales2, monGastoUtil.getMnvdvda().getValmonto());

									BigDecimal absoluteDiferenceParcCalc2 = SunatNumberUtils.absoluteDiference(bgOtrasAdic, bgFobParciales2);

									if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceParcCalc2, new BigDecimal(1))){
										//grabaTelelog(listError,"30466","GASTOS DE CETICOS NO COINCIDEN CON FORMATO B");
										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30466"));
									}
								}
							}
							//Si tiene o no publicacion de gastos
							//RIN 2.9.17
							if(SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMrepara().getValmonto()) ||
									SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMctimon().getValmonto()))
							{
								//RIN 2.9.19
								BigDecimal absoluteDiferenceFOBFA = SunatNumberUtils.absoluteDiference(monGastoUtil.getMfobcalc().getValmonto(), serie.getMtofobdol());
								if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferenceFOBFA, new BigDecimal(1))){
									//grabaTelelog(listError,"30471","FOB CALCULADO NO COINCIDE CON EL DEL FORMATO A");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30471"));
								}
								//RIN 2.9.20
								BigDecimal bgValorAduana = monGastoUtil.getMvaduan().getValmonto();
								BigDecimal bgFobFletSeg = new BigDecimal(0); 
								bgFobFletSeg = 	SunatNumberUtils.sum(bgFobFletSeg, monGastoUtil.getMfobcalc().getValmonto());
								bgFobFletSeg = 	SunatNumberUtils.sum(bgFobFletSeg, monGastoUtil.getMflete().getValmonto());
								bgFobFletSeg = 	SunatNumberUtils.sum(bgFobFletSeg, monGastoUtil.getMseguro().getValmonto());

								BigDecimal absoluteDiferencevalAduana = SunatNumberUtils.absoluteDiference(bgValorAduana, bgFobFletSeg);
								if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferencevalAduana, new BigDecimal(1))){
									//grabaTelelog(listError,"30472","TOTAL US$ VALOR EN ADUANA NO COINCIDE");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30472"));
								}
								//RIN 2.9.21 - RIN 2.10.22
								BigDecimal bgSegHojaGastos = monGastoUtil.getMseguro().getValmonto();
								BigDecimal bgSegFormatoB = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_VGAS_SEGUR).getMtologistico();
								BigDecimal bgSegFormatoA = serie.getMtosegdol();

								BigDecimal absoluteDiferHGB =  SunatNumberUtils.absoluteDiference(bgSegHojaGastos, bgSegFormatoB);
								BigDecimal absoluteDiferHGA =  SunatNumberUtils.absoluteDiference(bgSegHojaGastos, bgSegFormatoA);

								if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferHGB, new BigDecimal(1))){
									//grabaTelelog(listError,"30473","SEGURO DE HOJA DE GASTOS NO COINCIDE CON EL FORMATO B");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30473"));
								}

								if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferHGA, new BigDecimal(1))){
									//grabaTelelog(listError,"30474","SEGURO DE HOJA DE GASTOS NO COINCIDE CON SERIE FORMATO A");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30474"));
								}
								//RIN 2.9.23 2.9.24
								BigDecimal bgFleteHojaGastos = monGastoUtil.getMflete().getValmonto();
								BigDecimal bgFleteFormatoB = FormatoBUtils.getMontoDAV(dav, Constants.TIPO_MONTO_DAV_TOTGASTRAN).getMtologistico();
								BigDecimal bgFleteFormatoA = serie.getMtofledol();

								BigDecimal absoluteDiferFleteHGB =  SunatNumberUtils.absoluteDiference(bgFleteHojaGastos, bgFleteFormatoB);
								BigDecimal absoluteDiferFleteHGA =  SunatNumberUtils.absoluteDiference(bgFleteHojaGastos, bgFleteFormatoA);

								if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferFleteHGB, new BigDecimal(1))){
									//grabaTelelog(listError,"30475","FLETE DE HOJA DE GASTOS NO COINCIDE CON EL FORMATO B");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30475"));
								}
								//RIN 2.9.25
								if(!SunatNumberUtils.isLessOrEqualsThanParam(absoluteDiferFleteHGA, new BigDecimal(1))){
									//grabaTelelog(listError,"30476","FLETE DE HOJA DE GASTOS NO COINCIDE CON SERIE FORMATO A");
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30476"));
								}
							}else {
								//grabaTelelog(listError,"30504","NO HA ENVIADO MONTO POR REPARACION O MONTO POR CAMBIO DE TIMON");
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30504"));
							}

						}else{
							//RIN 2.9.16
							if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMfobfact().getValmonto()))!=true){
								//grabaTelelog(listError,"30505","NO HA INGRESADO MONTO EN US$ CONSIGNADO EN LA FACTURA COMERCIAL");
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30505"));
							}											
							if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMflete().getValmonto()))!=true) {
								//grabaTelelog(listError,"30506","NO HA INGRESADO MONTO EN US$ POR TRANSPORTE INTERNACIONAL");
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30506"));
							}
							if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMseguro().getValmonto()))!=true) {
								//grabaTelelog(listError,"30507","NO HA INGRESADO MONTO EN US$ POR SEGURO");	
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30507"));
							}
							if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMtasa().getValmonto()))!=true) {
								//grabaTelelog(listError,"30508","NO HA INGRESADO MONTO EN US$ POR TASA");	
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30508"));
							}
							if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMfobcalc().getValmonto()))!=true) {								
								//grabaTelelog(listError,"30509","NO HA INGRESADO MONTO FOB EN US$ CALCULADO");	
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30509"));
							}
							if((SunatNumberUtils.isGreaterThanZero(monGastoUtil.getMvaduan().getValmonto()))!=true) {
								//grabaTelelog(listError,"30510","NO HA INGRESADO MONTO DE VALOR EN ADUANA");	
								listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30510"));
							}
						}
					}
				}else {
					//grabaTelelog(listError,"30513","NO HA INGRESADO HOJA DE COSTEO");
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30513"));
				}
			}					
		}

		return listError; 
	}


	private boolean tieneVentasSucecivas(DatoSerie serie,Declaracion declaracion)	{
		ValNegocNumeracFormA valNegocNumeracFormA = fabricaDeServicios.getService("ValNegocNumeracFormA");
		boolean result = false;
		DatoFactura factura = valNegocNumeracFormA.getFacturaCorrespondiente(serie,declaracion);
		if(factura!=null){   
			if(!CollectionUtils.isEmpty(factura.getListFactSucesivas())){
				result = true;
			}
		}					
		return result;
	}



	/*inicio cambio amancilla*/

	/**Adicionado por PAS20155E220000260 para considerar nueva estructura 
	 * factorizacion de este metodo para que soporte la nueva y antigua estructura
	 * de descripciones minimas
	 *
	 * @param listError
	 * @param serie
	 * @param trasladoSeriesCetico1
	 * @param item
	 */
	private void validarVehiculosCETICOS(List<Map<String, String>> listError, DatoSerie serie, TrasladoSeriesCetico trasladoSeriesCetico1, DatoItem item,Declaracion declaracion) throws Exception
	{

		VehiculoService vehiculo = fabricaDeServicios.getService("descripcionMinima.VehiculoService");

		String chasis = vehiculo.obtenerChasis(item,declaracion);
		//si no se envia el chasis se toma el VIN 
		if(SunatStringUtils.isEmptyTrim(chasis)){
			String numeroVIN = vehiculo.obtenerVIN(item, declaracion);
			chasis = numeroVIN;
		}

		if (!SunatStringUtils.isEmptyTrim(chasis))
		{
			validarChasisCETICOS(listError, serie, trasladoSeriesCetico1, chasis);
			//RIN 2.7 Se valida Revisa1
			if (vigenciaCriterio("1021", SunatDateUtils.getCurrentIntegerDate()) > 0) {

				String revisa1 = vehiculo.obtenerRevisa1(item,declaracion);
				if (!SunatStringUtils.isEmptyTrim(revisa1)) {

					validarRevisa1CETICOS(listError, trasladoSeriesCetico1, revisa1);
				}
			}
		} else {
			//grabaTelelog(listError, "01260", "");
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("01260"));
		}
	}


	/**Adicionado por PAS20155E220000260 para considerar nueva estructura de descripciones minimas***/
	private void validarRevisa1CETICOS(List<Map<String, String>> listError, TrasladoSeriesCetico trasladoSeriesCetico1, String revisa1)
	{
		if (revisa1 != null && trasladoSeriesCetico1.getRevisa1() != null &&
				!revisa1.trim().equals(trasladoSeriesCetico1.getRevisa1().trim())) {
			//grabaTelelog(listError,"30373","");
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30373"));
		}
	}

	/**Adicionado por PAS20155E220000260 para considerar nueva estructura de descripciones minimas***/
	private void validarChasisCETICOS(List<Map<String, String>> listError, DatoSerie serie, TrasladoSeriesCetico trasladoSeriesCetico1, String chasis)
	{
		if (!SunatStringUtils.isEmptyTrim(chasis)) {
			String matco = serie.getDesmatecomp() == null ? "" : serie.getDesmatecomp();
			String fopre = serie.getDesformapres() == null ? "" : serie.getDesformapres();
			//RIN 2.8 Se valida chasis del vehiculo
			if (matco.indexOf(chasis) == -1 && fopre.indexOf(chasis) == -1)
				//grabaTelelog(listError, "30371", new Object[] {chasis, serie.getNumserie()}); //"CHASIS NO COINCIDE ENTRE FORMATO B Y EN SERIE DE DUA");//30371-05777
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30373",new String[] {chasis, serie.getNumserie().toString()}));
			//se extrae la validacion para que muestre ambos mensajes de ser el caso
			String ceticoChasis=trasladoSeriesCetico1.getChasis();
			String ceticoMercancia=trasladoSeriesCetico1.getMercancia();
			if ((SunatStringUtils.isEmpty(ceticoChasis) || ceticoChasis.indexOf(chasis)==-1) && (SunatStringUtils.isEmpty(ceticoMercancia) || ceticoMercancia.indexOf(chasis)==-1)){
				TrasladoCeticoService trasladoCeticoService = fabricaDeServicios.getService("sigad.despacho.especial.service.trasladoCeticoService");
				String nsoli="";
				Map<String,Object> paramsChasis=new HashMap<String,Object>();
				paramsChasis.put("chasis", chasis.toUpperCase());
				//List<TrasladoSeriesCetico> listExistect=FormatoAServiceImpl.getInstance().getTrasladoSeriesCeticoDAO().findByParams(paramsChasis);
				List<TrasladoSeriesCetico> listExistect= trasladoCeticoService.findTrasladoSeriesCeticoByOthers(paramsChasis,trasladoSeriesCetico1.getAduana());
				if (listExistect==null || listExistect.isEmpty()){
					paramsChasis=new HashMap<String,Object>();
					paramsChasis.put("aduana", trasladoSeriesCetico1.getAduana());
					paramsChasis.put("mercanciaLike", chasis.toUpperCase());
					//listExistect=FormatoAServiceImpl.getInstance().getTrasladoSeriesCeticoDAO().findByParams(paramsChasis);
					listExistect=trasladoCeticoService.findTrasladoSeriesCeticoByOthers(paramsChasis, trasladoSeriesCetico1.getAduana());

					if (listExistect!=null && !listExistect.isEmpty()){
						TrasladoSeriesCetico existect=listExistect.get(0);
						nsoli=" , CHASIS ES DE S/T: "+existect.getAduana()+" - "+existect.getAno()+" - "+existect.getNumero()+" - "+existect.getNserie();
					}
				}

				///grabaTelelog(listError,"30372",new Object[]{chasis,nsoli});//05780-30372 cambiarlo// jenciso (se cambia segun F2)
				//grabaTelelog(listError,"30372",new Object[]{ceticoChasis!=null?ceticoChasis:"",chasis});//05780-30372 cambiarlo// jenciso (se cambia segun F2)
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30372",new String[] {ceticoChasis!=null?ceticoChasis:"",chasis}));
			}
		}
	}


	/**
	 * Vigencia criterio.
	 * 
	 * @param codigoProceso String
	 * @param fecha Integer
	 * @return el integer
	 */
	private Integer vigenciaCriterio(String codigoProceso, Integer fecha){
		PackageTD packageTD = fabricaDeServicios.getService("PackageTD");
		return packageTD.getCambioVigente(codigoProceso, fecha);
	}


	private DatoMontoGastoUtil ConvertirListaAMontoGastoUtil(Elementos<DatoMontoGasto> montosGasto)
	{
		DatoMontoGastoUtil monGastoUtil = new DatoMontoGastoUtil();
		for(DatoMontoGasto tmpMongasto:montosGasto)
		{
			if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MPUBLICA))
			{monGastoUtil.setMpublica(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTRANS))
			{monGastoUtil.setMtrans(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MOPCPU))
			{monGastoUtil.setMopcpu(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MROOF))
			{monGastoUtil.setMroof(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MEQUICD))
			{monGastoUtil.setMequicd(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVCD))
			{monGastoUtil.setMnvcd(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVDVD))
			{monGastoUtil.setMnvdvd(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MOTPUB))
			{monGastoUtil.setMotpub(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MPUAJU))
			{monGastoUtil.setMpuaju(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MFOBFACT))
			{monGastoUtil.setMfobfact(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MREPARA))
			{monGastoUtil.setMrepara(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MBUECO))
			{monGastoUtil.setMbueco(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MMAXIM))
			{monGastoUtil.setMmaxim(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MCTIMON))
			{monGastoUtil.setMctimon(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MFLETE))
			{monGastoUtil.setMflete(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MSEGURO))
			{monGastoUtil.setMseguro(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTASA))
			{monGastoUtil.setMtasa(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTRANEX))
			{monGastoUtil.setMtranex(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTRANIN))
			{monGastoUtil.setMtranin(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTRASLA))
			{monGastoUtil.setMtrasla(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MUVENTA))
			{monGastoUtil.setMuventa(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MOTROST))
			{monGastoUtil.setMotrost(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVTV))
			{monGastoUtil.setMnvtv(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVDVDTV))
			{monGastoUtil.setMnvdvdtv(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MAIRE))
			{monGastoUtil.setMaire(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MTAPIZ))
			{monGastoUtil.setMtapiz(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MCCOLOR))
			{monGastoUtil.setMccolor(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MARO))
			{monGastoUtil.setMaro(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MCTRANS))
			{monGastoUtil.setMctrans(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MADAPTA))
			{monGastoUtil.setMadapta(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MOTROS))
			{monGastoUtil.setMotros(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MROOFA))
			{monGastoUtil.setMroofa(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MEQUICDA))
			{monGastoUtil.setMequicda(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVCDA))
			{monGastoUtil.setMnvcda(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MNVDVDA))
			{monGastoUtil.setMnvdvda(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MFOBCALC))
			{monGastoUtil.setMfobcalc(tmpMongasto);}
			else if(tmpMongasto.getTipmonto().trim().equals(Constants.TIPO_MONTO_GASTO_MVADUAN))
			{monGastoUtil.setMvaduan(tmpMongasto);}			 
		}	
		return monGastoUtil;
	}

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
