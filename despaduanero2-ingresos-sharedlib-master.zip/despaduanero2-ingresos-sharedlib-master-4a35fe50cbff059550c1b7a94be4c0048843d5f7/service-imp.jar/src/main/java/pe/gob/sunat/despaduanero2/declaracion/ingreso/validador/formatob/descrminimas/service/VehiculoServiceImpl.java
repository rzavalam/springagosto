package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

import org.springframework.beans.factory.annotation.Autowired;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.DescrMinimaHelper;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.FormatoBUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

import java.math.BigDecimal;

/**
 * Created by amancillaa on 20/06/14.
 */
public class VehiculoServiceImpl implements VehiculoService
{

    @Autowired
    private FabricaDeServicios fabricaDeServicios;

    @Override
    public Vehiculo obtenerVehiculo(DatoItem item, Declaracion declaracion) throws Exception
    {
        Vehiculo vehiculo = null;
        TipoDeDescrMinimaService tipoDeDescrMinima = fabricaDeServicios.getService("descripcionMinima.TipoDeDescrMinimaService");
        Enum<?> tipoDescrMinima = tipoDeDescrMinima.obtenerTipoDeDescrMinima(item);

        if ("VEHICULO".equals(tipoDescrMinima.name()))
        {
            TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");

            vehiculo = (Vehiculo) transformador.poblarObjetoDescrMinima(tipoDescrMinima, item, declaracion);
        }

        return vehiculo;
    }

    @Override
    public String obtenerMarca(DatoItem item, Declaracion declaracion) throws Exception
    {
        String marca = "";

        if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima()))
        {
            TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
            Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
            if(vehiculo!=null){
                marca = vehiculo.getMarcaComercial().getValtipdescri();
            }
        }
        else
        {
            String codMarca=DescrMinimaHelper.getDescripcionMinimaItemByTipo(item, ConstantesDataCatalogo.DESC_MINIMA_MARCA_COMER).getValtipdescri();
        }

        return marca;
    }

    @Override
    public String obtenerModelo(DatoItem item, Declaracion declaracion) throws Exception
    {
        String modelo = "";

        if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima()))
        {
            TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
            Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
            if(vehiculo!=null){
                modelo = vehiculo.getMarcaComercial().getValtipdescri();
            }
        }
        else
        {
            modelo=DescrMinimaHelper.getDescripcionMinimaItemByTipo(item, ConstantesDataCatalogo.DESC_MINIMA_MODELO).getValtipdescri();
        }

        return modelo;
    }

    @Override
    public String obtenerChasis(DatoItem item, Declaracion declaracion) throws Exception
    {
        String chasis = "";

        if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima()))
        {
            TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
            Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
            if(vehiculo!=null){
                chasis = vehiculo.getNumeroChasis().getValtipdescri();
            }
        }
        else
        {
            DatoDescrMinima descrMinimaClasVari = FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "04");
            String clasVari = descrMinimaClasVari.getValtipdescri();
            //validar que sea diferente de nullo y mayor de 6 clasVari
            //error 1260
            if (!SunatStringUtils.isEmpty(clasVari) && clasVari.length() > 6) {
                int end = clasVari.length() >= 27 ? 26 : clasVari.length();
                chasis = clasVari.substring(6, end).trim();
            }
        }

        return chasis;
    }

    @Override
    public String obtenerRevisa1(DatoItem item, Declaracion declaracion) throws Exception
    {
        String revisa1 = "";

        if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima()))
        {
            TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
            Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
            if(vehiculo!=null){
                revisa1 = vehiculo.getNumeroRevisa1().getValtipdescri();
            }
        }else{
            DatoDescrMinima descrMinimaDesCom3 = FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "09");
            if (descrMinimaDesCom3 != null) {
                String descCom3 = descrMinimaDesCom3.getValtipdescri();

                if (!SunatStringUtils.isEmpty(descCom3) && descCom3.length() > 25) {
                    int end = descCom3.length() >= 41 ? 40 : descCom3.length();
                    revisa1 = descCom3.substring(24, end);
                }
            }
        }

        return revisa1;
    }

    @Override
    public String obtenerGastosReparacion(DatoItem item, Declaracion declaracion) throws Exception
    {
        String gastos = "";

        if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima()))
        {
            TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
            Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
            if(vehiculo!=null){
                gastos = vehiculo.getGastosReparacion().getValtipdescri();
            }
        }else{

            DatoDescrMinima descrMinimaDesCom3=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "09");

            if (descrMinimaDesCom3!=null){
                String descCom3=descrMinimaDesCom3.getValtipdescri();
                if (!SunatStringUtils.isEmpty(descCom3) && descCom3.length()>47){
                    int end=descCom3.length()>=53?52:descCom3.length();
                    gastos=descCom3.substring(46,end).trim();
                }
            }
        }

        return gastos;
    }

	@Override
	public String obtenerIndicadorSNTT(DatoItem item, Declaracion declaracion)
			throws Exception {

		String indicador="";		
		
		  if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima())){
	             Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
	            if(vehiculo!=null){
	                indicador = vehiculo.getIndicadorSNTT().getValtipdescri();
	            }
	      }else{
	            DatoDescrMinima  descrMinimaCaraTipo=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "03");

	            if (descrMinimaCaraTipo!=null){
	                String caraTipo=descrMinimaCaraTipo.getValtipdescri();
	                if (!SunatStringUtils.isEmpty(caraTipo) && caraTipo.length()>64){
	                    int end=caraTipo.length()>=66?65:caraTipo.length();
	                    indicador = caraTipo.substring(64,end).trim();
	                }
	            }
	        }

		return indicador;
	}

	@Override
	public String obtenerTipoEncendido(DatoItem item, Declaracion declaracion)
			throws Exception {
		
		String tipoEncendido="";
		
		if(DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima())){
			Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
			if(vehiculo!=null){		
					tipoEncendido = vehiculo.getTipoEncendido().getValtipdescri();//catalogo u otros				
			}
		}else{
				DatoDescrMinima descrMinimaClasVari=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "04");
				
				if(descrMinimaClasVari!=null){
					String clasVari=descrMinimaClasVari.getValtipdescri();
					if(!SunatStringUtils.isEmpty(clasVari) && clasVari.length()>68){
						int end=clasVari.length()>=71?71:clasVari.length();
						tipoEncendido = clasVari.substring(68,end).trim();//catalogo o ZZZ
					}					
				}
		}
		return tipoEncendido;
	}
	

	@Override
	public String obtenerCategoria(DatoItem item, Declaracion declaracion)
			throws Exception {
		
		String categoria="";
		
		if(DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima())){
			Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
			if(vehiculo!=null){
				categoria = vehiculo.getCategoria().getValtipdescri();
			}
		}else{
				DatoDescrMinima descrMinimaNombComer=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "00");
				
				if(descrMinimaNombComer!=null){
					String nombComer=descrMinimaNombComer.getValtipdescri();
					if(!SunatStringUtils.isEmpty(nombComer) && nombComer.length()>0){
						int end=nombComer.length()>=3?3:(nombComer.length()>=2?2:nombComer.length());
						categoria = nombComer.substring(0,end).trim();
					}
				}
		}
		return categoria;
	}

	@Override
	public BigDecimal obtenerKilometraje(DatoItem item, Declaracion declaracion)
			throws Exception {
		
		BigDecimal kilometraje= new BigDecimal(0);
		
		if(DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima())){
			Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
			if(vehiculo!=null){
				kilometraje =vehiculo.getKilometraje().getValtipdescri()!=null && vehiculo.getKilometraje().getValtipdescri()!=""?new BigDecimal(vehiculo.getKilometraje().getValtipdescri()):new BigDecimal(0);
			}
		}else{
				DatoDescrMinima descrMinimaUsoAplic=FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "05");
				
				if(descrMinimaUsoAplic!=null){
					String usoAplic=descrMinimaUsoAplic.getValtipdescri();
					if(!SunatStringUtils.isEmpty(usoAplic) && usoAplic.length()>61){
						int end=usoAplic.length()>=71?71:usoAplic.length();
						kilometraje = new BigDecimal(usoAplic.substring(61,end).trim());
					}					
				}
		}
		return kilometraje;
	}

	@Override
	public int obtenerPesoBrutoKG(DatoItem item, Declaracion declaracion)
			throws Exception {
		int pesoBruto= 0;
		
		if(DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima())){
			Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
			if(vehiculo!=null){
				pesoBruto = vehiculo.getPesoBrutoKG().getValtipdescri()!=null && vehiculo.getPesoBrutoKG().getValtipdescri()!=""?new Integer(vehiculo.getPesoBrutoKG().getValtipdescri()):new Integer(0);				
			}
		}else{
				DatoDescrMinima descrMinimaUsoAplic=FormatoBUtils.getDescrMinima(item.getListDecrMinima(),"05");
				
				if(descrMinimaUsoAplic!=null){
					String usoAplic=descrMinimaUsoAplic.getValtipdescri();
					if(!SunatStringUtils.isEmpty(usoAplic) && usoAplic.length()>38){
						int end=usoAplic.length()>=44?44:usoAplic.length();
						pesoBruto=new Integer(usoAplic.substring(38,end).trim());
					}	
				}			
		} 
		return pesoBruto;
	}
	
	/**Adicionado por PAS20155E220000260 pro errores en validacion de CETICOS en minimas AREY**/
    public String obtenerVIN(DatoItem item, Declaracion declaracion) throws Exception
    {
        String numeroVIN = "";

        if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima()))
        {
            TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
            Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
            if(vehiculo!=null){
                numeroVIN = vehiculo.getNumeroVIN().getValtipdescri();
            }
        }
        else
        {
            DatoDescrMinima descrMinimaClasVari = FormatoBUtils.getDescrMinima(item.getListDecrMinima(), "04");
            String clasVari = descrMinimaClasVari.getValtipdescri();
            //validar que sea diferente de nullo y mayor de 26 clasVari            
            if (!SunatStringUtils.isEmpty(clasVari) && clasVari.length() > 26) {
                int end = clasVari.length() >= 45 ?  44 : clasVari.length();
                numeroVIN = clasVari.substring(26, end).trim();
            }
        }

        return numeroVIN;
    }
    
	/**Adicionado por PAS20175E220200059 **/
    public String obtenerCarroceria(DatoItem item, Declaracion declaracion) throws Exception
    {
        String carroceria = "";

        if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima()))
        {
            TransformadorDescrMinimaService transformador = fabricaDeServicios.getService("descripcionMinima.TransformadorDescrMinimaService");
            Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
            if(vehiculo!=null){
            	carroceria = vehiculo.getCarroceria().getValtipdescri().trim();
            }
        }
        
        return carroceria;
    }
    
    /**Adicionado por PAS20191U220500021 **/
    public String obtenerAnoModelo(DatoItem item, Declaracion declaracion) throws Exception
    {
        String annModelo = "";

        if (DescrMinimaHelper.tieneNuevaEstructura(item.getListDecrMinima()))
        {
            Vehiculo vehiculo = obtenerVehiculo(item, declaracion);
            if(vehiculo!=null){
            	annModelo = vehiculo.getAnnoModelo().getValtipdescri().trim();
            }
        }
        
        return annModelo;
    }
    
}
