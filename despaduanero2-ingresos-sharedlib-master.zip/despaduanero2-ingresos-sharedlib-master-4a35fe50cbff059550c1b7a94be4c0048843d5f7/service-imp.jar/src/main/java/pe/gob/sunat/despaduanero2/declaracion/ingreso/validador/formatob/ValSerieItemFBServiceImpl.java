package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.FormatoBUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValSerieItemFBServiceImpl extends ValDuaAbstract implements ValSerieItemFB{

	/**
     * Validar que el total de series declaradas en el formato B est�n 
     * correlacionadas con las series del formato A y viceversa.
     * @param serieItem
     * @param declaracion
     * @return
     */
	public Map<String, String> numserie(DatoSerieItem serieItem, Declaracion declaracion) {
		
		Map<String, String> result = new HashMap<String, String>();
		
        if (declaracion.isExoneradoFB()) {
            return result;
        }

		boolean existsInFA = false;

		for( DatoSerie serie: declaracion.getDua().getListSeries()){
            if (serie.getNumserie().intValue() == serieItem.getNumserie()){
				existsInFA = true;
                break;
		}

		}
		
		if (!existsInFA) {
            result = getErrorMap("30760",
                    new Object[] { ((DatoItem)serieItem.getPadre()).getNumsecitem(),
            						 serieItem.getNumserie()!=null?serieItem.getNumserie():" "});
        }

        return result;
    }

	/** Visceversa		 
	/ * @param  serieItem, declaracion
	/ * @return map
	/ * @pase */
    public Map<String, String> verificarSerieFormatoAEstaEnFormatoB(DatoSerie serie){

        Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) serie.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }

        if (!serieFormatoAEncuentraEnFormatoB(serie)) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            //result = catalogoHelper.getErrorMap("30636", new Object[] { serie.getNumserie()!=null?serie.getNumserie():" "});
        	
        	//glazaror... hacemos uso de catalogoAyudaService.getError
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	String numeroSerie = (serie.getNumserie() != null) ? serie.getNumserie().toString() : " ";
        	result = catalogoAyudaService.getError("30636", new String[] {numeroSerie});

        }

        return result;
    }
	
	
    public boolean serieFormatoAEncuentraEnFormatoB(DatoSerie serie){

        Declaracion declaracion = (Declaracion) serie.getPadre().getPadre();

        for (DAV dav : declaracion.getListDAVs()) {
            for (DatoFactura factura : dav.getListFacturas()) {
                for (DatoItem item : factura.getListItems()) {
                    for (DatoSerieItem serieitem : item.getListSerieItems()) {
                        if (SunatNumberUtils.isEqual(serieitem.getNumserie(), serie.getNumserie()))
                            return true;
                    }
                }
            }
        }

        return false;
    }
	
	/**
	 * Valida que la sumatoria del fob de los items en la correlacion del formato B 
     * por serie, sea igual al ajuste total de la serie en el Formato A.
	 * @param serie
	 * @param declaracion
	 * @return
	 */
	public Map<String, String> mtofobitser(DatoSerie serie){

		Map<String, String> result = new HashMap<String, String>();
        
        Declaracion declaracion = (Declaracion)serie.getPadre().getPadre();

        if (declaracion.isExoneradoFB()) {
            return result;
        }

        List<DatoSerieItem> seriesItems = getSeriesItemCorrespondiente(serie, declaracion);

        BigDecimal qfob = new BigDecimal(0);
        BigDecimal qfobDifMin = new BigDecimal(0.1);

        for (DatoSerieItem datoSerieItem : seriesItems) {
            qfob = SunatNumberUtils.sum(qfob, datoSerieItem.getMtofobitser());
        }

        BigDecimal dif = SunatNumberUtils.absoluteDiference(qfob, serie.getMtofobdol());
        if (SunatNumberUtils.isGreaterThanParam(dif, qfobDifMin)) {
            result = getErrorMap("05643",
                    new Object[] {
            		serie.getNumserie(),
            		serie.getMtofobdol()!=null?serie.getMtofobdol():" " , qfob });
        }
		
        return result;
    }
	
    /**
     * Valida que la sumatoria del ajuste de los items en la correlacion del formato B 
     * por serie, sea igual al ajuste total de la serie en el Formato A.  
     * @param serie
     * @param declaracion
     * @return
     */
	public Map<String, String> mtoajuitser(DatoSerie serie, Declaracion declaracion) {

		Map<String, String> result = new HashMap<String, String>();
		
		if( declaracion.isExoneradoFB() )
			return result;
		
		List<DatoSerieItem> seriesItems = getSeriesItemCorrespondiente(serie, declaracion);
				
		BigDecimal qaju = new BigDecimal(0);
		BigDecimal qajuDifMin = new BigDecimal(1);
		
		for (DatoSerieItem datoSerieItem : seriesItems) {
			qaju = SunatNumberUtils.sum(qaju, datoSerieItem.getMtoajuitser());	
		}
		
		BigDecimal dif = SunatNumberUtils.absoluteDiference(qaju, serie.getMtoajuste());
		
        if (SunatNumberUtils.isLessThanParam(qajuDifMin, dif)) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*result = catalogoHelper.getErrorMap("30165",
                    new Object[] { serie.getNumserie(),  serie.getMtoajuste()!=null?serie.getMtoajuste():" ", qaju });*/
        	
        	//glazaror... hacemos uso de catalogoAyudaService.getError
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	String numeroSerie = (serie.getNumserie() != null) ? serie.getNumserie().toString() : " ";
        	String montoAjuste = (serie.getMtoajuste() != null) ? serie.getMtoajuste().toString() : " ";
        	String qajuAsString = (qaju != null) ? qaju.toString() : " ";
        	result = catalogoAyudaService.getError("30165", new String[] {numeroSerie, montoAjuste, qajuAsString});

		}
        
		return result;
	}
	
	/*branch ingreso 2011-009 hosorio inicio 05/07/2011*/
	//private List<DatoSerieItem> getSeriesItemCorrespondiente(DatoSerie serie, Declaracion declaracion) {
	public List<DatoSerieItem> getSeriesItemCorrespondiente(DatoSerie serie, Declaracion declaracion) {
	/*branch ingreso 2011-009 hosorio fin 05/07/2011*/
		List<DatoSerieItem> listSerieItem = new ArrayList<DatoSerieItem>();
		for (DAV dav : declaracion.getListDAVs()) {
			for (DatoFactura factura : dav.getListFacturas()) {
				for (DatoItem item : factura.getListItems()) {
					for (DatoSerieItem serieItem : item.getListSerieItems()) {
						if (SunatNumberUtils.isEqual(serieItem.getNumserie(), serie.getNumserie())) {
							listSerieItem.add(serieItem); 
						}
					}
				}
			}
		}

		return listSerieItem;
	}

    /**
     * Validar que la sumatoria de la cantidad de unidades comerciales de la mercancia 
     * declarada en la correlaci�n de items del formato B redondeada a 3 decimales, sea 
     * igual a la cantidad declarada en la serie respectiva del formato A.
     * @param serie
     * @return
     */
    public Map<String, String> validarCantUniComerSerieXSerieItem(DatoSerie serie){

        Map<String, String> result = new HashMap<String, String>();

        Declaracion declaracion = ((Declaracion) serie.getPadre().getPadre());

        if (declaracion.isExoneradoFB()) {
            return result;
        }

        List<DatoSerieItem> listaSerieItems = getSeriesItemCorrespondiente(serie, declaracion);

        BigDecimal totalCantMercXSerieItem = BigDecimal.ZERO;

        for (DatoSerieItem serieItem : listaSerieItems)
            totalCantMercXSerieItem = SunatNumberUtils.sum(totalCantMercXSerieItem, serieItem.getCant_mercd());

        if (!SunatNumberUtils.isEqual(SunatNumberUtils.scaleHalfUp(totalCantMercXSerieItem, 3), serie.getCntunicomer()))

            result = getErrorMap("30630", new Object[] { serie.getNumserie(), serie.getCntunicomer(),
                    totalCantMercXSerieItem });
        return result;

    }		

    /**
     * Valida que la subpartida declarada en la serie del Formato A sea la misma que 
     * la subpartida de los �tem(s) correlacionado(s) del Formato B,
     * Valida que el pa�s de origen declarado en la serie del Formato A sea el mismo 
     * pa�s de origen de los �tem(s) correlacionado(s) del Formato B.
     * Valida que el estado de mercanc�a declarado en la serie del Formato A sea el 
     * mismo que el estado de mercanc�a de los �tem(s) correlacionado(s) del Formato B.
     * @param serie
     * @return
     */
    public List<Map<String, String>> validarDatosSerieXSerieItem(DatoSerie serie){

        List<Map<String, String>> listError = new ArrayList<Map<String, String>>();

        Declaracion declaracion = ((Declaracion) serie.getPadre().getPadre());

        if (declaracion.isExoneradoFB()) {
            return listError;
        }
        //gmontoya bug 18671
		if (declaracion.getListDAVs() != null
				&& declaracion.getListDAVs().size() > 0) {
			List<DatoItem> listadoSerieItems = FormatoBUtils.getItemsSeries(
					declaracion.getListDAVs(), serie);

			for (DatoItem item : listadoSerieItems) {

				if (!SunatNumberUtils.isEqual(serie.getNumpartnandi(),
						item.getNumpartnandi())) {
					listError.add(getErrorMap(
							"30631",
							new Object[] { serie.getNumserie(),
									item.getNumsecitem(),
									serie.getNumpartnandi().toString(),
									item.getNumpartnandi().toString() }));
				}

				if (!SunatStringUtils.isEqualTo(serie.getCodpaisorige(),
						item.getCodpaisorige())) {
					//RIN13 se invierte el orden para que muestre adecuado mensaje
					listError.add(getErrorMap(
							"30632",
							new Object[] { item.getNumsecitem(),
									serie.getNumserie(),
									serie.getCodpaisorige(),
									item.getCodpaisorige() }));
				}

				if (!SunatStringUtils.isEqualTo(serie.getCodestamerca(),
						item.getCodestamer())) {
					listError.add(getErrorMap(
							"30633",
							new Object[] { serie.getNumserie(),
									item.getNumsecitem(),
									serie.getCodestamerca(),
									item.getCodestamer() }));
				}

			}
		}
        return listError;

    }
		
    /**
     * Validar que la totalidad de los �tems del Formato B est�n correlacionados 
     * en las series del Formato A y viceversa. En caso contrario (Ver F24).
     * @param item
     * @return
     */
    public Map<String, String> validarExisteItemFBEnCorrelacionSerieFA(DatoItem item){

        Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }

        if(!(item.getListSerieItems().size()>0)){
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*result = catalogoHelper.getErrorMap("30637", new Object[]{ 
                       item.getNumsecitem()});*/
        	
        	//glazaror... hacemos uso de catalogoAyudaService.getError
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	String numeroSecuenciaItem = (item.getNumsecitem() != null) ? item.getNumsecitem().toString() : " ";
        	result = catalogoAyudaService.getError("30637", new String[] {numeroSecuenciaItem});

        }

        return result;
    }
    
	/**
	 * Valida que los items de la correlacion del FB esten asociados por lo menos 
	 * a una serie del formato A	
	 * @param serieItem
	 * @return
	 */
    public Map<String, String> validarExisteItemFAEnCorrelacionSerieFB(DatoSerieItem serieItem){

        Map<String, String> result = new HashMap<String, String>();
        if (((Declaracion) serieItem.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
        if (((DatoItem) serieItem.getPadre()).getNumsecitem() != serieItem.getNumsecitem()) {
            result = getErrorMap("30638", new Object[] { serieItem.getNumserie(), serieItem.getNumsecitem() });
        }
        return result;
    }
	
		
		
		
		
}
