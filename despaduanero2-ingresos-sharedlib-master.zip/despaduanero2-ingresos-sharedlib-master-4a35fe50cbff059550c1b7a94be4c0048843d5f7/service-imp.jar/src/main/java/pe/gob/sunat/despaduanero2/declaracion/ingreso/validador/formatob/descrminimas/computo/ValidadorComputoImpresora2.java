package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoImpresora;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;


public class ValidadorComputoImpresora2 extends ValidadorComputoAbstract
{

  private final static String INYECCION = "INY";
  private final static String LASER     = "LAS";
  private final static String PLOTER    = "PLO";
  private final static String MATRICIAL = "MAT";
  private final static String COD_ZZZ   = "1";
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua)throws Exception
  {

	    List<ErrorDescrMinima> lstErrores = validarEstructura(objeto);

      if (CollectionUtils.isEmpty(lstErrores)){
          DatoItem item =  obtenerItem(objeto, dua);
          lstErrores.addAll(validarUnidadComercial(objeto, item));
          lstErrores.addAll(validarNombreComercial(objeto, item, dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarTipoImpresora(objeto));
         // lstErrores.addAll(validarVelocidadImpresionCPS(objeto));
          lstErrores.addAll(validarVelocidadImpresionColoresPPM(objeto));
          lstErrores.addAll(validarVelocidadImpresionNegroPPM(objeto));
          lstErrores.addAll(validarPinesImpresoraMatricial(objeto));
      }

         return lstErrores;
  }
  
  public List<ErrorDescrMinima> validarVelocidadImpresionNegroPPM(ModelAbstract object){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	  ComputoImpresora impresora = (ComputoImpresora) object;
	  String tipoImpresora = impresora.getTipoImpresora().getValtipdescri();
	  String velocidadImpresionPPM = impresora.getVelocidadImpresionNegroPPM().getValtipdescri();
	  if(Arrays.asList(INYECCION,LASER,PLOTER).contains(tipoImpresora)){		  
		  if(SunatStringUtils.isEmptyTrim(velocidadImpresionPPM)){
			  lst.add(obtenerError("31477",impresora.getVelocidadImpresionNegroPPM()));
		  }
	  }
      else if (!SunatStringUtils.isEmptyTrim(velocidadImpresionPPM))
      {
          String regla="el tipo de impresora consignada es diferente a INY,LAS,PLO";
          String campo= obtenerDescripcionDelCalogo("500", impresora.getVelocidadImpresionNegroPPM().getCodtipdescr());
          Object[] argumentos = new Object[] { regla,campo };
          ErrorDescrMinima error = obtenerError("30897",impresora.getVelocidadImpresionNegroPPM(), argumentos);
          lst.add(error);
      }
	  return lst;
  }

  public List<ErrorDescrMinima> validarVelocidadImpresionColoresPPM(ModelAbstract object){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	  ComputoImpresora impresora = (ComputoImpresora) object;
	  String tipoImpresora = impresora.getTipoImpresora().getValtipdescri();
	  String datoAVAlidar = impresora.getVelocidadImpresionColoresPPM().getValtipdescri();
	  if(Arrays.asList(INYECCION,LASER,PLOTER).contains(tipoImpresora)){		  
		  if(SunatStringUtils.isEmptyTrim(datoAVAlidar)){
			  lst.add(obtenerError("31478",impresora.getVelocidadImpresionColoresPPM()));
		  }
	  }
      else if (!SunatStringUtils.isEmptyTrim(datoAVAlidar))
      {
          String regla="el tipo de impresora consignada es diferente a INY,LAS,PLO";
          String campo= obtenerDescripcionDelCalogo("500", impresora.getVelocidadImpresionColoresPPM().getCodtipdescr());
          Object[] argumentos = new Object[] { regla,campo };
          ErrorDescrMinima error = obtenerError("30897",impresora.getVelocidadImpresionColoresPPM(), argumentos);
          lst.add(error);
      }
	  return lst;
  }
  
   
//ya no se transmiten las casillas columnas Impresion, Memoria Impresora, velocidad Impresion
  public List<ErrorDescrMinima> validarTipoImpresora(ModelAbstract object){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	  ComputoImpresora impresora = (ComputoImpresora) object;
	  String tipoImpresora = impresora.getTipoImpresora().getValtipdescri();
	  //String capacidad = impresora.getCapacidadMemoriaImpresora().getValtipdescri();
	  String resolucion = impresora.getResolucionImpresion().getValtipdescri();
	  //String ancho = impresora.getColumnasImpresion().getValtipdescri();
	  if(SunatStringUtils.isEqualTo(tipoImpresora, LASER)){
		  if(/*SunatStringUtils.isEmptyTrim(capacidad) ||*/ SunatStringUtils.isEmptyTrim(resolucion) 
				  /*|| !SunatStringUtils.isEmptyTrim(ancho)*/){
			  lst.add(obtenerError("33021",impresora.getTipoImpresora()));
		  }
	  }else if(SunatStringUtils.isEqualTo(tipoImpresora, INYECCION)){
		  if(SunatStringUtils.isEmptyTrim(resolucion) ){
			  lst.add(obtenerError("31480",impresora.getTipoImpresora()));  
		  }
		 /* if(!SunatStringUtils.isEmptyTrim(ancho) || !SunatStringUtils.isEmptyTrim(capacidad)){
			  lst.add(obtenerError("31481",impresora.getTipoImpresora()));
		  }
	  }else if(SunatStringUtils.isEqualTo(tipoImpresora, MATRICIAL)){
		  if(SunatStringUtils.isEmptyTrim(ancho) || !SunatStringUtils.isEmptyTrim(capacidad)){
			  lst.add(obtenerError("31482", impresora.getTipoImpresora()));
		  }*/
	  }else if(SunatStringUtils.isEqualTo(tipoImpresora, PLOTER)){
		  if(/*SunatStringUtils.isEmptyTrim(capacidad) ||*/ SunatStringUtils.isEmptyTrim(resolucion)){
			  lst.add(obtenerError("33019",impresora.getTipoImpresora()));
		  }
		 /* if(!SunatStringUtils.isEmptyTrim(ancho)){
			  lst.add(obtenerError("31484",impresora.getTipoImpresora()));
		  }*/
	  }else if(COD_ZZZ.equals(impresora.getTipoImpresora().getCodtipvalor())){
		  if(SunatStringUtils.isEmptyTrim(resolucion) /*||SunatStringUtils.isEmptyTrim(capacidad)*/){
			  lst.add(obtenerError("33020",impresora.getTipoImpresora()));
		  }
		 /* if(!SunatStringUtils.isEmptyTrim(ancho)){
			  lst.add(obtenerError("31486",impresora.getTipoImpresora()));
		  }*/
	  }
	  return lst;
  }
  public List<ErrorDescrMinima> validarPinesImpresoraMatricial(ModelAbstract object){
	  List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
	  ComputoImpresora impresora = (ComputoImpresora) object;
	  String tipoImpresora = impresora.getTipoImpresora().getValtipdescri();
	  String datoAValidar = impresora.getPinesImpresoraMatricial().getValtipdescri();
	  if(SunatStringUtils.isEqualTo(MATRICIAL, tipoImpresora)){
		  if(SunatStringUtils.isEmptyTrim(datoAValidar)){
			  lst.add(obtenerError("31487",impresora.getTipoImpresora()));
		  }
	  }else if(!SunatStringUtils.isEqualTo(MATRICIAL, tipoImpresora) && 
			  !SunatStringUtils.isEmptyTrim(datoAValidar)){
		  lst.add(obtenerError("31488",impresora.getTipoImpresora()));
	  }
	  return lst;
  }
  
  public List<ErrorDescrMinima> validarColumnasImpresion(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
  
  public List<ErrorDescrMinima> validarResolucionImpresion(ModelAbstract object){
	  return new ArrayList<ErrorDescrMinima>();
  }
}
