/*
 * Clase que define el servicio de validaciones de las descripciones minimas del formato B de la declaracion.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.CatRefpartidas;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DescrPosicion;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.IngresoVariablesUtil;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Observacion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * 
 * The Class ValDescMin. Clase que define el servicio de validaciones de las descripciones minimas del formato B de la declaracion.
 */
public class ValDescMinServiceImpl extends ValDuaAbstract implements ValDescMin{

//	private static ValDescMinServiceImpl instance;
	//private ValItemFB  valItemFB;
        //private HotSwappableTargetSource swapperDatasource;
	//private FabricaDeServicios fabricaDeServicios;
	
	
	/*
	public void setValItemFB(ValItemFB valItemFB) {
		this.valItemFB = valItemFB;
	}*/	

	private ValDescMinServiceImpl (){

	}
	
//	public static ValDescMinServiceImpl getInstance() {
//		if(instance == null )
//		{
//			instance = new ValDescMinServiceImpl();
//		}
//		
//		return instance;
//	}

	//private ValLibFBServiceImpl descmin;
	
	/**
	 * Retorna el valor de descmin.
	 * 
	 * @return  descmin
	 */
	/*
	public ValLibFBServiceImpl getDescmin() {
		return descmin;
	}
	
	public void setDescmin(ValLibFBServiceImpl descmin) {
		this.descmin = descmin;
	}*/

	//rtineo mejoras, se sobrecarga el metodo
	public Map<String, String> codtipdescri(DatoDescrMinima datoDescrMinima) {	
		return codtipdescri(datoDescrMinima,null);
	}
	//rtineo fin
	/**
	 * Valida el C�digo del tipo de descripci�n.
	 * @param arg String. C�digo del tipo de descripci�n.
	 * @return el map
	 */
	public Map<String, String> codtipdescri(DatoDescrMinima datoDescrMinima,Map<String, Object> variablesIngreso) {		
		Map<String, String> result = new HashMap<String, String>();
	// bug 21408 pase 42
		if(datoDescrMinima.getPadre()!=null && datoDescrMinima.getPadre().getPadre().getPadre().getPadre()  instanceof Declaracion  &&
				((Declaracion)datoDescrMinima.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()){
            return result;
		}	
		// bug 21408 pase 42
		
//		if(datoDescrMinima.getPadre()!=null && datoDescrMinima.getPadre().getPadre().getPadre().getPadre() instanceof Declaracion &&
//				((Declaracion)datoDescrMinima.getPadre().getPadre().getPadre().getPadre()).isExoneradoFB()){//pase399 - en trxdilig error 24
//            return result;
//        }//se reversiona tal como estaba, se corrigui� el seteo del padre de DAV pase 42
		//rtineo mejoras, se valida con lo almacenado en variables ingreso
		boolean isValid = false;
		if(variablesIngreso != null){
			isValid = IngresoVariablesUtil.validarElementoCatalogo(fabricaDeServicios,datoDescrMinima.getCodtipdescr(), "320",variablesIngreso);
		}else{
			//continua ejecutando metodo anterior
			isValid = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("320", datoDescrMinima.getCodtipdescr()));
			//isValid = catalogoHelper.isValid(datoDescrMinima.getCodtipdescr(), "320");
		}
		//rtineo mejoras, fin
		if(!isValid)
		{
			result = getErrorMap("30171", new Object[]{
			        ((DAV)datoDescrMinima.getPadre().getPadre().getPadre()).getNumsecuprov(),
					((DatoFactura)datoDescrMinima.getPadre().getPadre()).getNumsecfactu(),  
					((DatoItem) datoDescrMinima.getPadre()).getNumsecitem(),
					datoDescrMinima.getCodtipdescr()});
		}
		
		return result;
	}                

	//rtineo mejoras, se sobrecarga el metodo
	public List<Map<String, String>> valtipdescr(DatoItem item){
		return valtipdescr(item,null);
	}
	
	/* Valida el valor de la descripci�n de la mercanc�a.	  
	 * 9.1.	el valor de la descripci�n del nombre comercial, marca y modelo de mercanc�a transmitida debe tener una longitud m�nima de 2 caracteres excepto cuando est� sujeto a descripci�n m�nima y se indique de otra manera. 
	 * 9.2.	El valor transmitido en Caracter�sticas y Clase y variedad, debe tener una longitud mayor de cero caracteres excepto cuando est� sujeto a descripci�n m�nima y se indique de otra manera. Es obligatorio.  
	 * @param DatoDescrMinima 
	 * @return List
	 * @Errores 30172,30598,30599
	 */	
	//para funcionar con variablesIngreso deve haber cargado valores en el key mapPartNandiRestCache, mapSubPartNandiRestCache de varaiblesIngreso
    public List<Map<String, String>> valtipdescr(DatoItem item,Map<String, Object> variablesIngreso){

        List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

        if (item.getPadre()!=null && item.getPadre().getPadre().getPadre() instanceof Declaracion &&
        		((Declaracion) item.getPadre().getPadre().getPadre()).isExoneradoFB()) {//pase399 - en trxdilig error 24
            return listErr;
        }

        Date fechaVigencia = (item.getPadre()!=null && item.getPadre().getPadre().getPadre() instanceof Declaracion &&
        		((Declaracion) item.getPadre().getPadre().getPadre()).getDua()!=null && 
        		((Declaracion) item.getPadre().getPadre().getPadre()).getDua().getFecdeclaracion()!=null)?
        		((Declaracion)item.getPadre().getPadre().getPadre()).getDua().getFecdeclaracion():null; 
        //rtineo mejoras, se valida con lo almacenado en variablesIngreso
        boolean esPartidaDescMin = false;
        boolean esSubPartDescMin = false;
        if(variablesIngreso != null){
        	//esPartidaDescMin = IngresoVariablesUtil.validarElementoCatalogo(fabricaDeServicios, item.getNumpartnandi().toString(),Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, variablesIngreso);
        	//esSubPartDescMin = IngresoVariablesUtil.validarElementoCatalogo(fabricaDeServicios, SunatStringUtils.substring(item.getNumpartnandi().toString(), 0, 4),Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, variablesIngreso);
        	Map mapPartida =  (Map<String,List>)variablesIngreso.get("mapPartNandiRestCache");
        	if(!CollectionUtils.isEmpty(mapPartida)) esPartidaDescMin = (Boolean)mapPartida.get(item.getNumpartnandi().toString());
        	Map mapSubPartida =  (Map<String,List>)variablesIngreso.get("mapSubPartNandiRestCache");
        	if(!CollectionUtils.isEmpty(mapPartida)) esSubPartDescMin = (Boolean)mapSubPartida.get(SunatStringUtils.substring(item.getNumpartnandi().toString(),0,4));
        }else{
        	//continua ejecutando los metodos anteriores
            //esPartidaDescMin = catalogoHelper.isValid(item.getNumpartnandi().toString(), Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN,fechaVigencia);
            esPartidaDescMin = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, item.getNumpartnandi().toString(),fechaVigencia));
            //esSubPartDescMin = catalogoHelper.isValid(SunatStringUtils.substring(item.getNumpartnandi().toString(), 0, 4),Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN,fechaVigencia);
            esSubPartDescMin = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(Constants.COD_CATALOGO_ES_PARTIDA_DESC_MIN, SunatStringUtils.substring(item.getNumpartnandi().toString(), 0, 4),fechaVigencia));
        }
        //rtineo fin
        if (esPartidaDescMin || esSubPartDescMin) {
        	return listErr;
        }
            List<DatoDescrMinima> lstDescMin = item.getListDecrMinima();
            for (DatoDescrMinima datoDescrMinima : lstDescMin) {
                if (!SunatStringUtils.isEmpty(datoDescrMinima.getValtipdescri())) {
                    if (SunatStringUtils.isStringInList(datoDescrMinima.getCodtipdescr(), "00,01,02")) {
                        if (!SunatStringUtils.isLengthGreaterThanNumber(datoDescrMinima.getValtipdescri().trim(), 1)) {
                            listErr.add(getErrorMap("30599",
                                    new Object[] { ((DatoItem) datoDescrMinima.getPadre()).getNumsecitem(),
                                            datoDescrMinima.getValtipdescri().trim(), 
                                            datoDescrMinima.getCodtipdescr(), }));
                        }
                    }
                    
                    if (SunatStringUtils.isStringInList(datoDescrMinima.getCodtipdescr(), "03,04")) {
                        if (!SunatStringUtils.isLengthGreaterThanNumber(datoDescrMinima.getValtipdescri().trim(), 0)) {
                            listErr.add(getErrorMap("30617",
                                    new Object[] { ((DatoItem) datoDescrMinima.getPadre()).getNumsecitem(),
                                            datoDescrMinima.getValtipdescri().trim(), 
                                            datoDescrMinima.getCodtipdescr(), }));
                        }
                    }
                }
                else {
                	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
                    listErr.add(catalogoAyudaService.getError("30172"));
                }
            }
        
            return listErr;

    }                
	
	/**
	 * Realiza las validaciones de todas las descripciones minimas del formato B de la declaracion. 
	 * 
	 * @param item DatoItem
	 * @param declaracion Declaracion
	 * @return el list
	 */
	public List<Map<String, String>> valgraldescmin(DatoItem item, Declaracion declaracion) {
		ValLibFBServiceImpl descmin = fabricaDeServicios.getService("ValLibFB");
		ProveedorFuncionesService funcionesService =   fabricaDeServicios.getService("funcionesService");
		ValItemFB valItemFB =   fabricaDeServicios.getService("ValItemFB");
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		
		if(declaracion.isExoneradoFB()){
		    return listErr;
		}
		
		Integer fechaIngSi = SunatNumberUtils.getTodayAsInteger();
		
		descmin.vProcesar = "S";
		descmin.swCetico = "N";
		descmin.codigoAduana = declaracion.getCodaduana();
		descmin.mUnidMercd = item.getCodunidcomer();
		
		descmin.mAroAno = item.getAnnfabrica();
		descmin.mPartNandi = item.getNumpartnandi().toString();
		descmin.mEstaMercd = item.getCodestamer();
		descmin.mPaisOrigen = item.getCodpaisorige();
		descmin.mModeMercd = item.getDesmodelo();
		
		
		//Corresponde a la fecha de embarque de la serie del formato A asociada al item del formato B
		descmin.pFechEmbar = 0;
		DatoSerie serie = valItemFB.getSerieCorrespondiente(item, declaracion);
		
		if(serie != null)
		{
			for( DatoDocTransporte docTrans: declaracion.getDua().getListDocTransporte() )
			{
				descmin.pFechEmbar = SunatDateUtils.getIntegerFromDate(docTrans.getFecembarque());
			}		
			
			//Segmento DatosRegPrecedencia campo codregipre, obtenido de relacionar la serie del formato A con el item del formato B
			if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())){ //PAS20165E220200069
				for( DatoRegPrecedencia regPrec: serie.getListRegPrecedencia() )
				{
					descmin.pCodRegPre =regPrec.getCodregipre();	
				}				
			}
			
			//DatosManifiesto.fectermino
			DatoManifiesto manif=declaracion.getDua().getManifiesto();
			Date fectermino=manif!=null?manif.getFectermino():null;
			
			descmin.pFechLlega = SunatDateUtils.getIntegerFromDate( fectermino );
			
			descmin.gnCnt=0;
			descmin.gcCuero = "CUR";
			
			//DatosSeries.codtratprefe // Corresponde al trato preferencial de la serie del formato A asociada al item del formato B
			descmin.wclib = "";
			
			descmin.mCodiRegi = declaracion.getDua().getCodregimen(); // NumdeclRef.codregimen
			descmin.nyear = SunatNumberUtils.getCurrentYear();
			descmin.gcCapitulo = ""; // SUBSTR(LPAD(A_CADENA(mPART_NANDI),10,'0'),1,4)
			descmin.vFechIngsi = SunatNumberUtils.getTodayAsInteger();
			descmin.vRevisa1 = " ";
			descmin.tipoTrat = declaracion.getDua().getCodtipotratamiento();
			descmin.gnVecesVal = 0;
			descmin.lcCodigoComp="";
			descmin.lPartidaSoftware = 0;
			descmin.xRespuesta=0;
			descmin.marchivo="XML";
					
			//for( Datodeclarante declarante :  declaracion.getDua().getListDeclarantes())
			if( SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getTipoParticipante().getCodDatacat(), "45") )
				descmin.wruc = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
			
			for (DatoDescrMinima descrMinima : item.getListDecrMinima()) {
				if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "00") )
					descmin.mNombComer = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "01") )
					descmin.mMarcComer = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "02") )
					descmin.mModeComer = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "03") )
					descmin.mCaraTipo = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "04") )
					descmin.mClasVari = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "05") )
					descmin.mUsoAplic = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "06") )
					descmin.mMatCompo = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "07") )
					descmin.mDescCom1 = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "08") )
					descmin.mDescCom2 = descrMinima.getValtipdescri();
				else if( SunatStringUtils.isEqualTo(descrMinima.getCodtipdescr(), "09") )
					descmin.mDescCom3 = descrMinima.getValtipdescri();
			}		

			descmin.vNomCo = SunatStringUtils.substringFox(descmin.mNombComer, 1, 3);
			descmin.mCate = SunatStringUtils.substringFox(descmin.mNombComer, 1, 1);
			descmin.mSubCat = SunatStringUtils.substringFox(descmin.mNombComer, 1, 2);
			descmin.wClase = SunatStringUtils.substringFox(descmin.mNombComer, 3, 2);
			descmin.mSN = SunatStringUtils.substringFox(descmin.mCaraTipo, 65, 1);
			descmin.nAS = SunatStringUtils.substringFox(descmin.mUsoAplic, 1, 2);
			descmin.nPB = SunatStringUtils.substringFox(descmin.mUsoAplic, 38, 6);
			descmin.nPN = SunatStringUtils.substringFox(descmin.mUsoAplic, 44, 6);
			descmin.mCH = SunatStringUtils.substringFox(descmin.mClasVari, 7, 20);
			descmin.mVI = SunatStringUtils.substringFox(descmin.mClasVari, 27, 18);
			descmin.mEX = SunatStringUtils.substringFox(descmin.mClasVari, 45, 2);
			descmin.mEncend = SunatStringUtils.substringFox(descmin.mClasVari, 69, 3);
			descmin.mCarro = SunatStringUtils.substringFox(descmin.mCaraTipo, 1, 3);
			descmin.vTipo = SunatStringUtils.substringFox(descmin.mNombComer, 1, 3);
			descmin.vTipFi = SunatStringUtils.substringFox(descmin.mCaraTipo, 1, 3);
			
			for (Observacion observacion : item.getListObservaciones()) {
				if( SunatStringUtils.isEqualTo(observacion.getCodtipobserva(), "1003") )
				{
					descmin.mTobsItem = observacion.getObsdeclaracion();
				}
			}
			
			String tipoMerc = funcionesService.fnTipo(descmin.mPartNandi, descmin.mNombComer, descmin.mCaraTipo, fechaIngSi);
			
			//Se establece el tipo de mercancia para el grabado de las descripciones minimas.
			for (DatoDescrMinima descrMinima : item.getListDecrMinima()) {
				descrMinima.setCodmercancia(tipoMerc);
			}	
			
			if( ! SunatStringUtils.isEqualTo(tipoMerc , "**") )
			{
				List<CatRefpartidas> list = funcionesService.existsInRefPartidasByTipoUsoAndPartNandiAndCapitulo("DVA", descmin.mPartNandi, SunatStringUtils.substringFox(descmin.mPartNandi, 1, 4));
				
				if( list.size() == 0 )
				{
					descmin.gTipoDescMin = "**";
				}
			}
			
			if( SunatStringUtils.isStringInList(tipoMerc, "(KD,KE,KF,KG") )
			{
				descmin.gnNewVal1 = funcionesService.cambioVigente("DM03", fechaIngSi);
				descmin.gnNewVal2 = funcionesService.cambioVigente("DM07", fechaIngSi);
			}
			
			//60.	Se verifica CETICOS solo corresponde a AUTOS usados procedentes del Jap�n
			if( SunatStringUtils.isEqualTo(descmin.pCodRegPre, "91") 
					&& SunatStringUtils.isStringInList(declaracion.getCodaduana(), "172,163,145,046")
					&& 
					( SunatStringUtils.isEqualTo(descmin.mPartNandi, "8701200000") 
							|| SunatStringUtils.isStringInList( SunatStringUtils.substringFox(descmin.mPartNandi, 1, 4), "8702,8703,8704,8705"))
					&& SunatStringUtils.isStringInList(descmin.mEstaMercd, "20,21,22,23,24,25,26,27")
					&& SunatStringUtils.isEqualTo(descmin.mPaisOrigen, "JP")
					)
			{
				descmin.swCetico = "V"; 
			}
			
			//63.	Se verifica la extensi�n de la informaci�n de CETICOS de autos usados. 
			if( SunatStringUtils.isStringInList(declaracion.getCodaduana(), "172,163,145,046")
					&& 
					( SunatStringUtils.isEqualTo(descmin.mPartNandi, "8701200000") 
							|| SunatStringUtils.isStringInList( SunatStringUtils.substringFox(descmin.mPartNandi, 1, 4), "8702,8703,8704,8705"))
					&& SunatStringUtils.isStringInList(descmin.mEstaMercd, "20,21,22,23,24,25,26,27")
					&& SunatStringUtils.isEqualTo(descmin.mPaisOrigen, "JP")
					)
			{
				descmin.vRevisa1 =  SunatStringUtils.substringFox(descmin.mDescCom3, 25, 16);
				
				
				if( SunatStringUtils.isEmpty( SunatStringUtils.substringFox(descmin.mDescCom3, 53, 15) ) )
				{
					//1.	ERROR LA EXTENSION DE LA INFORMACION DE CETICOS NO DEBE SER BLANCO 
					//2.	SI NO TIENE INFORMACION INGRESAE N.T. 
					//3.	InsTelelog('5786',marchivo+'EXTENSION DE VEHICULO EN BLANCO, SI NO TIENE DATOS INGRESE, N.T.')
					listErr.add( getErrorMap("5786", new Object[]{descmin.marchivo}) );
				}
			}
			
			String vLibrTribu = null;
			//for( Datodeclarante declarante : declaracion.getDua().getListDeclarantes() )
			
			if(SunatStringUtils.isEqualTo(declaracion.getDua().getDeclarante().getTipoParticipante().getCodDatacat(),"45"))
				vLibrTribu	= declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
			
			
			if( funcionesService.existsInResSPIMByTipoDocAndNumDoc("4", vLibrTribu) 
					&& descmin.vFechIngsi  >= 20000607 && descmin.vFechIngsi <= 20020828)
			{
				descmin.vProcesar = "N";
			}
			
			if( SunatStringUtils.isEqualTo(descmin.vProcesar, "S") 
					&& ! SunatStringUtils.isEqualTo(tipoMerc, "**") )
			{
				if( SunatStringUtils.isEqualTo(tipoMerc, "99")  ) //1.	Se env�a rechazos
				{
					if(SunatStringUtils.isEqualTo(descmin.mPartNandi, "9607200000l")  )
					{
						//a.	InsTelelog('5690',marchivo+'NOMB_COMER'+' VALOR ENVIADO '+mNomb_Comer
						//b.	+' DEBIO ENVIAR CODIGO DE PARTES DEL CIERRE')  
						listErr.add( getErrorMap("5690", new Object[]{descmin.marchivo,descmin.mNombComer}) );
					}else if(SunatStringUtils.isStringInList(descmin.mPartNandi, "9001300000,9001400000,9001500000,9003110000,9003191000,9003199000,9004100000")) {
						//a.	InsTelelog('5730',marchivo+'NOMB_COMER'+' VALOR ENVIADO '+mNomb_Comer
						//b.	+' DEBIO ENVIAR CODIGO DEL NOMBRE COMERCIAL')  
						listErr.add( getErrorMap("5730", new Object[]{descmin.marchivo,descmin.mNombComer}) );
					}
				}else{
					//1.	Se validan las Descripciones M�nimas.
					//2.	SpEs_Desc_Min( cTipo_Merc ) 
					HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");
					Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + descmin.codigoAduana));
					listErr.addAll(descmin.valDescMin( tipoMerc ));
					swapperDatasource.swap(o);
				}
			}else{
				if( SunatStringUtils.isEqualTo(descmin.vProcesar, "S") )
				{
					//1.	SpVal_NoMal 
					listErr.addAll(descmin.valNombCom());
				}
			}
			
		}
		
		return listErr;
	}
	/*branch ingreso 2011-009 hosorio inicio*/
	public List<Map<String, String>> valgraldescmin2(Declaracion declaracion) {
		List<Map<String, String>> listErr = new ArrayList<Map<String,String>>();
		
		if(declaracion.isExoneradoFB()){
		    return listErr;
		}
		
		if(!CollectionUtils.isEmpty(declaracion.getListDAVs())){
			for(DAV dv:declaracion.getListDAVs()){
				
				if(!CollectionUtils.isEmpty(dv.getListFacturas())){
					for(DatoFactura fac:dv.getListFacturas()){
						if(!CollectionUtils.isEmpty(fac.getListItems())){
							for(DatoItem di:fac.getListItems()){

								/**pase 548 adicionado por conflictos en proceso DESCRMINIMAS**/
								if (!CollectionUtils.isEmpty(di.getListDecrMinima())) {
									//Transmision de la Rectificacion DESCRMINIMAS		
									DescrPosicion descrMinNuevaEstructura = null;//Transmision de Rectificacion DESCRMINIMAS
									String codigoCampo = di.getListDecrMinima().get(0).getCodtipdescr();	
									descrMinNuevaEstructura =((FormBItemDescriDAO) fabricaDeServicios.getService("formBItemDescriDAO")).getDescrPosicion(codigoCampo); 

									if(descrMinNuevaEstructura!=null){
										break;
									}else{
								listErr.addAll(valgraldescmin(di, declaracion));
							}
								}/**pase 548fin de cambios por conflictos en proceso DESCRMINIMAS**/
							}
						}	
					}
				}
				
			}
		}
		
		return listErr;
	}
	/*branch ingreso 2011-009 hosorio fin*/	
/*
	public HotSwappableTargetSource getSwapperDatasource() {
		return swapperDatasource;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
	
}
