package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.importador;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.DateUtil;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ValGeneralEERService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaran;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeclaranDAO;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.servicio2.registro.model.dao.DdpDAO;
import pe.gob.sunat.servicio2.registro.model.dao.T733DAO;

public class ValImportadorServiceImpl extends IngresoAbstractServiceImpl implements ValImportadorService {
	
	protected final Log logImportador = LogFactory.getLog(getClass());
	
	@SuppressWarnings("rawtypes")
	public List<Map<String, String>> validaExistenciaDNI(Declaracion declaracion) throws ParseException {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		
		T733DAO t733DAO = fabricaDeServicios.getService("servicio.registro.model.t733DAO");
		
		String numDocumentoIdentidad = declaracion.getDua().getConsignatario().getNumeroDocumentoIdentidad(); 
		if (ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI.equals(declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat())) {
			
			Map map = t733DAO.findByPK(numDocumentoIdentidad, "01");
			
			if(map==null) {
				
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("40245",
						new String[] { numDocumentoIdentidad }));
				return listError;
			}	
		}
		return listError;
	}
	
	public List<Map<String, String>> valMayoriaEdad(Declaracion declaracion) throws ParseException {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		T733DAO t733DAO = fabricaDeServicios.getService("servicio.registro.model.t733DAO");
		
		String numDocumentoIdentidad = declaracion.getDua().getConsignatario().getNumeroDocumentoIdentidad(); 
		if (ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI.equals(declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat())) {
				//.getDeclarante().getTipoDocumentoIdentidad().getCodDatacat())) {

			Map map = t733DAO.findByPK(numDocumentoIdentidad, "01");
			
			if(map!=null) {
			
				Date fechaNacimiento = (Date)map.get("fec_nac_pnat");
				
				//validar que que el declarante.numeroDocumentoIdentidad corresponda con un mayor de edad
				if (!pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.GeneralUtils.esMayorDeEdad(fechaNacimiento)) {
					//se debe emitir el mensaje E7
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70100",
							new String[] { numDocumentoIdentidad}));
				}
			}
		}
		// TODO: implement
		//Se, obtiene del objeto DUA los siguientes atributos: declarante
		//Si el atributo declarante.tipoDocumentoIdentidad.codDatacat es igual a "3"
		//validar que que el declarante.numeroDocumentoIdentidad corresponda con un mayor de edad
		//Caso contrario se debe emitir el mensaje E7
		return listError;
	}
		   
	public List<Map<String, String>> valCondicionPersona(Declaracion declaracion) throws ParseException {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		T733DAO t733DAO = fabricaDeServicios.getService("servicio.registro.model.t733DAO");
		
		if (ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI.equals(declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat())) {
			//validar que que el declarante.numeroDocumentoIdentidad no corresponda con una persona fallecida
			Map map = t733DAO.findByPK(declaracion.getDua().getConsignatario().getNumeroDocumentoIdentidad(), "01");
			if(map==null) return listError;
			Date fechaDeceso = (Date)map.get("fec_fall_pnat");
			String strFechaDeceso =  DateUtil.dateToString(fechaDeceso, "dd/MM/yyyy");
			
			if (!Constantes.DEFAULT_FECHA_BD.equals(strFechaDeceso)) {
				//Deceso de la persona
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70101",
						new String[] { declaracion.getDua().getConsignatario().getNumeroDocumentoIdentidad()  
				}));
			}
		}
		
		// TODO: implement
		//Se, obtiene del objeto DUA los siguientes atributos: declarante
		//Si el atributo declarante.tipoDocumentoIdentidad.codDatacat es igual a "3"
		//validar que que el declarante.numeroDocumentoIdentidad no corresponda con una persona fallecida
		//Caso contrario se emite el mensaje E38
		return listError;
	}
		   
	public List<Map<String, String>> valTipoDocumentoPermitido(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		if(!SunatStringUtils.include(declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat(), 
				new String[]{ ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI,
							  ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC,
							  ConstantesDataCatalogo.TIPO_DOCUMENTO_PASAPORTE,
							  ConstantesDataCatalogo.TIPO_DOCUMENTO_CARNET_EXTRANJERIA,
							  ConstantesDataCatalogo.TIPO_DOCUMENTO_ORGANISMO_INTERNACIONAL,
							  ConstantesDataCatalogo.TIPO_DOCUMENTO_SALVOCONDUCTO
				})) {
			//Se rechaza la transmision
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70170",
					new String[] { declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat()  
			}));
		}
		// TODO: implement
		//Se, obtiene del objeto DUA los siguientes atributos: declarante
		//Si el atributo declarante.tipoDocumentoIdentidad.codDatacat es diferente a "3","4","6","7","8","9" (cod_catalogo:27)
		//se rechaza la transmision		 
		return listError;
	}
		   
	public List<Map<String, String>> valRegistroOrganismoInternacional(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		//if (ConstantesDataCatalogo.TIPO_DOCUMENTO_ORGANISMO_INTERNACIONAL.equals(declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat())) {
		if (ConstantesDataCatalogo.TIPO_DOCUMENTO_ORGANISMO_INTERNACIONAL.equals(declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat())) {
			//Se valida que el organismo internacional este registrado en la sunat
			String codAduana = declaracion.getCodaduana();

			HotSwappableTargetSource swapper = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.dx.prp1");
			swapper.swap(fabricaDeServicios.getService("despaduanero2.dxdaen."+codAduana ));			
			
			DeclaranDAO declaranOperativaDAO = (DeclaranDAO) fabricaDeServicios.getService("declaracion.declaranOperativaDAO");
			Map<String,String> declaran = new HashMap<String,String>();
			declaran.put("ctipodoc",ConstantesDataCatalogo.TIPO_DOCUMENTO_ORGANISMO_INTERNACIONAL);
			declaran.put("cdocumen",declaracion.getDua().getConsignatario().getNumeroDocumentoIdentidad());
			declaran.put("flagVigentes","true");

			List<Declaran> listDeclaran = declaranOperativaDAO.listDeclaran(declaran);
			
			if(CollectionUtils.isEmpty(listDeclaran)) {			
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70102"));
			}
		}
		
		// TODO: implement
		//Se, obtiene del objeto DUA los siguientes atributos: declarante
		//Si el atributo declarante.tipoDocumentoIdentidad.codDatacat es igual a "8" (cod_catalogo:27)
		//Se valida que el organismo internacional este registrado en la sunat
		//Caso contrario se emite el mensaje E8
		return listError;
	}
		   
	public List<Map<String, String>> valObligatoriedadRazonSocial(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		
		if(!SunatStringUtils.include(declaracion.getDua().getDeclarante().getTipoDocumentoIdentidad().getCodDatacat(), 
				new String[]{ ConstantesDataCatalogo.TIPO_DOCUMENTO_DNI,
							  ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC
				})) {
			//Se valida que se transmita declarante.nombreRazonSocial obligatoriamente
		} else {
			//Caso contrario se emite el mensaje E9
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70103"));
		}
		// TODO: implement
		//Se, obtiene del objeto DUA los siguientes atributos: declarante
		//Si el atributo declarante.tipoDocumentoIdentidad.codDatacat es diferente a "3" y diferente a "4" (cod_catalogo:27)
		//Se valida que se transmita declarante.nombreRazonSocial obligatoriamente
		//Caso contrario se emite el mensaje E9
		return listError;
	}
	
	@Deprecated
	public List<Map<String, String>> valObligatoriedadDireccion(Declaracion declaracion) {
		
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		
		if (!ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(declaracion.getDua().getConsignatario().getTipoDocumentoIdentidad().getCodDatacat())) {
			//Se valida que se transmita declarante.direccion obligatoriamente
			if(SunatStringUtils.isEmpty(declaracion.getDua().getConsignatario().getDireccion())) {
				//Caso contrario se emite el mensaje E10
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70104"));
			}
		}else {
			if(!SunatStringUtils.isEmpty(declaracion.getDua().getConsignatario().getDireccion())) {
				//Caso contrario se emite el mensaje E10
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("70186"));
			}
		} 
		//inicio mlaura PAS20181U220400008-MAC-046
		if (ConstantesDataCatalogo.ROL_PARTICIPANTE_CONSIGNATARIO.equals(declaracion.getDua().getConsignatario().getTipoParticipante().getCodDatacat())) {
			if (SunatStringUtils.isEmpty(declaracion.getDua().getConsignatario().getDireccion())) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08014"));
			}
		}//fin mlaura PAS20181U220400008-MAC-046
		
		//Se, obtiene del objeto DUA los siguientes atributos: declarante
		//Si el atributo declarante.tipoDocumentoIdentidad.codDatacat es diferente a "4" (cod_catalogo:27)
		//Se valida que se transmita declarante.direccion obligatoriamente
		//Caso contrario se emite el mensaje E10
		return listError;
	}
	
	//inicio lalberti
	@ServicioAnnot(tipo="V",codServicio=6557)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"this"})
	@OrquestaDespaAnnot(codServInstancia=6557,numSecEjec=91,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, String>> validarEstadoRUCImportador(DUA dua){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		DdpDAO ddpDAO = fabricaDeServicios.getService("servicio.registro.model.ddpDAO");
		Participante consignatario = dua.getConsignatario();
		String codTipoDocumento = consignatario.getTipoDocumentoIdentidad().getCodDatacat();
		if(ConstantesDataCatalogo.TIPO_DOCUMENTO_RUC.equals(codTipoDocumento)){
			String numRuc = consignatario.getNumeroDocumentoIdentidad();		
			Map<String, ?> map = ddpDAO.findByPK(numRuc);
			if (CollectionUtils.isEmpty(map)) {
				listError.add(catalogoAyudaService.getError(Constantes.ERR_RUC_INVALIDO, new String[] {numRuc}));
			} else {				
				if (!map.get("ddp_estado").equals("00")) { 
				//Estado 00|ACTIVO     
					listError.add(catalogoAyudaService.getError(Constantes.ERR_RUC_NO_ACTIVO, new String[] {numRuc}));
				}
				if (map.get("ddp_flag22").equals("12")) {
				//Condicion 12|NO HABIDO                            
					listError.add(catalogoAyudaService.getError(Constantes.ERR_RUC_NO_HABIDO, new String[] {numRuc}));
				}
			}
		}		
		return listError;
	}
	//Segun F2 el pais del importador siempre ser� Per�
	@ServicioAnnot(tipo="V",codServicio=6558)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"this"})
	@OrquestaDespaAnnot(codServInstancia=6558,numSecEjec=91,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DUA")
	public List<Map<String, String>> validarPaisImportador(DUA dua){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");		
		Participante consignatario = dua.getConsignatario();
		String codPaisImportador = consignatario.getPais().getCodDatacat();
		if(!ConstantesDataCatalogo.PAIS_PERU.equals(codPaisImportador)) {
			listError.add(catalogoAyudaService.getError("70157"));
		}
		return listError;
	}
	
	public List<Map<String, ?>> validarMandatoriedadTipoNroDocumento(Participante participante) {
		CatalogoAyudaService catalogoAyudaService = fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		ValGeneralEERService valGeneralEERService = fabricaDeServicios.getService("ingreso.validador.service");
		ResponseListManager responseList = new ResponseListManager();
		if (ConstantesDataCatalogo.CONSIGNATARIO.equals(participante.getTipoParticipante().getCodDatacat())) {
			if(participante.getTipoDocumentoIdentidad() == null || participante.getTipoDocumentoIdentidad().getCodDatacat() == null || participante.getNumeroDocumentoIdentidad() == null )
				responseList.addResponseMap(catalogoAyudaService.getError("70181"));
			else
				return valGeneralEERService.validarTipoyNumeroDeDocumentoDeParticipantes(participante);
		} else if (ConstantesDataCatalogo.ROL_PARTICIPANTE_EMBARCADOR.equals(participante.getTipoParticipante().getCodDatacat()) || ConstantesDataCatalogo.ROL_PARTICIPANTE_REMITENTE.equals(participante.getTipoParticipante().getCodDatacat())) {
			return valGeneralEERService.validarTipoyNumeroDeDocumentoDeParticipantes(participante);
		}
		return responseList.getResponseList();
	}
}
