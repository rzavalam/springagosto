package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.reproduccion;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;

/**
 * La Class ValidadorDescrMinimaReproCasetteAudio.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class ValidadorReproCasetteAudio extends ValidadorReproAbstract
{
	public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
        List<ErrorDescrMinima>  lstErrores  = validarEstructura(objeto);
		//lstErrores.addAll(validarEstructura(objeto));

      if (CollectionUtils.isEmpty(lstErrores)){
    	  lstErrores.addAll(super.validarUnidadComercial(objeto, dua));
          lstErrores.addAll(super.validarNombreComercial(objeto,dua));
          lstErrores.addAll(super.validarMarcaComercial(objeto));
          lstErrores.addAll(super.validarModelo(objeto));
          lstErrores.addAll(validarDatosEnviadosCorrespondenAltipoDescrMinima(objeto,dua.getDua().getFecdeclaracion()));
          lstErrores.addAll(validarTipoMaterialCinta(objeto));
          lstErrores.addAll(validarTiempoGrabacion(objeto));
      }


		return  lstErrores ;
	}

	public List<ErrorDescrMinima>  validarTipoMaterialCinta(ModelAbstract objeto)
	{
		return new ArrayList<ErrorDescrMinima>();
  }

	public List<ErrorDescrMinima>  validarTiempoGrabacion (ModelAbstract objeto)
	{
		return new ArrayList<ErrorDescrMinima>();
	}
}
