/*
 * Clase que define el servicio de validaciones de contingentes arancelarios
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.contingentes;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.OperadorAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PaisOrigenTratoPreferencialService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageGeneral;
import pe.gob.sunat.despaduanero2.declaracion.model.ContCtaCte;
import pe.gob.sunat.despaduanero2.declaracion.model.Contplazo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContCtaCteDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContValidDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ContplazoDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.NandTasaDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ibatis.criteria.ContCtaCteCriteria;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;

/**
 * Clase que realiza la validacion de los contingentes de la declaracion
 * 
 * @author rcalla
 *
 */
public class ValidaContingentesServiceImpl extends ValDuaAbstract implements ValidaContingentesService {

	private final Log log = LogFactory.getLog(getClass());

	private static final String COD_TRX_NUMERACION = "01"; 
	private static final String COD_TRX_REGULARIZA_URG = "05";
	private static final String COD_TRX_DILIG_DESP_GRA = "06";
	private static final String COD_TRX_DILIG_DESP_VAL = "16";
	private static final String COD_TRX_DILIG_REGU_GRA = "08";
	//inicio P21-P22
	private static final String COD_TRX_DILIG_CONCLU_GRA = "12";
	private static final String COD_TRX_DILIG_CONCLU_VAL = "11";
	//fin P21-P22
	private static final String COD_TRX_RECTIFICACION = "03"; //RMC RIN-P47
	private static final String COD_TRX_REGULARIZA_ANT = "04"; //RMC RIN-P47
	private static final String COD_TRX_DILIG_RECTIF = "07"; //RMC RIN-P47
	private static final String COD_TRX_RECT_OFI_VAL = "09"; //RMC RIN-P47
	private static final String COD_TRX_RECT_OFI_GRA = "10"; //RMC RIN-P47
	private static final String COD_TRX_RECT_OFI_D_VAL = "19"; //RMC RIN-P47

	//private ContingentesUtil contingentesUtil; 

	//private CatalogoHelperImpl catalogoHelper;

	//private ContCtaCteDAO contCtaCteDAO;
	//private ContValidDAO contValidDAO;
	//private ContplazoDAO contplazoDAO;

	//private FabricaDeServicios fabricaDeServicios;
	//private HotSwappableTargetSource swapperDatasource;
	//private AyudaService ayudaService;
	/**
	 * Establece un valor a contValidDAO.
	 * 
	 * @param contValidDAO ContValidDAO
	 */
	/*
	public void setContValidDAO(ContValidDAO contValidDAO) {
		this.contValidDAO = contValidDAO;
	}

	
	public void setContplazoDAO(ContplazoDAO contplazoDAO) {
		this.contplazoDAO = contplazoDAO;
	}


	public void setContCtaCteDAO(ContCtaCteDAO contCtaCteDAO) {
		this.contCtaCteDAO = contCtaCteDAO;
	}

	public void setContingentesUtil(ContingentesUtil contingentesUtil) {
		this.contingentesUtil = contingentesUtil;
	}
	 */

	/*
	 * (non-Javadoc)
	 * 
	 * @seepe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service. ValidaContingentesService#procesarOrdenEnvio()
	 */
	@Override
	public List<Map<String, String>> procesarOrdenEnvio(Declaracion declaracion, Map<String, Object> variablesIngreso, Integer nroErroresNegocio) {
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		Map<String,Object> mapCntSolAntSeries = new HashMap<String,Object>();
		if( log.isWarnEnabled() )
			log.warn("Entry "+this.getClass().getCanonicalName()+".procesarOrdenEnvio");
		//establece la aduana correcta
		PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
		HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.ds.prp1");		
		swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + declaracion.getDua().getCodaduanaorden()));

		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		List<Map<String, String>> listErrOtros = new ArrayList<Map<String, String>>();
		List<Map<String, String>> listErrManif = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> lstmapCntSolAntSeries = new ArrayList<Map<String, Object>>();
		List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();

		String codTransaccion = (String)variablesIngreso.get("codTransaccion");
		String numeroDocumentoIdentidadSender = (String)variablesIngreso.get("numeroDocumentoIdentidadSender"); //NUM RUC AGENTE
		String numeroDeReferencia = (String)variablesIngreso.get("numOrden"); //ANNPRESEN concat NUM_ORDEN

		//Map<String, Object> operador = catalogoHelper.getOperadorAyudaService().getOperador(numeroDocumentoIdentidadSender, "41");
		Map<String, Object> operador = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperador(numeroDocumentoIdentidadSender, "41");
		String agente = (String)operador.get("cod_antadu");		

		String annOrden = null;
		String numeOrden = null;
		Declaracion declaracionBD = null;

		String codtpi=" ";
		String codpais=" ";

		if(codTransaccion.endsWith(COD_TRX_NUMERACION)){
			annOrden = numeroDeReferencia.substring(0, 4);
			numeOrden = numeroDeReferencia.substring(4, numeroDeReferencia.length());

			if( declaracion.getDua().getFecNumeracion() == null ) 
				declaracion.getDua().setFecNumeracion( SunatDateUtils.getCurrentDate() ); 
		}else{
			declaracionBD = contingentesUtil.getDeclaracionBD(declaracion);

			annOrden = declaracion.getNumdeclRef().getAnnprese();
			numeOrden = SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0');
			declaracion.getDua().setFecNumeracion(declaracionBD.getDua().getFecNumeracion() );
		}

		//Solo aplica para el r�gimen de importaci�n consumo
		if(! codTransaccion.startsWith(Constants.REGIMEN_IMPORTACION_CONSUMO.toString()) )
			return listErr;


		boolean gbcontingente = PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000022", declaracion.getDua().getFecNumeracion()) > 0;
		if( gbcontingente ){

			//boolean isValidaContingenteNumeracion = contingentesUtil.validaContingenteNum(declaracion, codTransaccion);
			//boolean isValidaContingenteNumeracion = true;
			boolean isValidaContingenteRectificacion = contingentesUtil.validaContingenteRectif(declaracion, codTransaccion);
			boolean isValidaContingenteRegularizacion = contingentesUtil.validaContingenteRegul(declaracion, codTransaccion);
			boolean isViaTransPostal = false;
			boolean tieneIndicador16 = false;
			boolean tieneIndicador16BD = false;

			if( codTransaccion.endsWith(COD_TRX_NUMERACION) || isValidaContingenteRectificacion || isValidaContingenteRegularizacion)
			{
				int isValidaFechaManifiesto = 0;
				int isValidaModalidad = 0;
				boolean isCampoInvalido = false;

				/*
				 * Paso 4 del cu11
				 * Para las series de las declaraciones de importaci�n urgentes o excepcionales (normales), se verificar� los datos enviados en
				 * la orden, para determinar si se esta solicitando el acogimiento a contingente arancelario
				 */			
				//Para el Acumulador de Cantidades Solicitadas Series Anteriores				
				mapCntSolAntSeries.put("cntSolAntSeries",new BigDecimal(0));
				//Indicador si se debe reservar aun si se ha agotado el saldo en una serie distinta a la primera serie.
				mapCntSolAntSeries.put("indSaldoAgoPriSer","0"); 
				listErrManif = contingentesUtil.validarFechaNumeracionFechaLlegada(declaracion)  ;


				if (declaracion.getDua().getManifiesto().getCodmodtransp().equals(ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL)) {
					isViaTransPostal = true;	
				}
				tieneIndicador16 = tieneIndicador16(declaracion);
				tieneIndicador16BD  = tieneIndicador16BD(declaracion);
				//PAS20165E220200076 - mtorralba 20160927 - Bug MSNADE280-720
				List<Map<String,Object>> listaUsoPorGrupo = new ArrayList<Map<String,Object>>(); 

				for(DatoSerie serie:declaracion.getDua().getListSeries()){
					codtpi=SunatStringUtils.toStringObj(serie.getCodconvinter());
					codpais =serie.getCodpaisorige();
					listValidPorAlcohol=new ArrayList<Map<String, Object>>();


					if("5".equals( serie.getCodtipomarge() ) && ( serie.getCodconvinter() == null || serie.getCodconvinter() == 0)  )
					{
						listErr.add(ResponseMapManager.getErrorResponseMap("08801", "SERIE:"+ serie.getNumserie() +" PARA ACOGERSE A CONTINGENTE ARANCELARIO, DEBE ACOGERSE A UN TPI"));

					}


					/*
					 * Para las series de las declaraciones de importaci�n urgentes o excepcionales (normales), se verificar� los datos enviados
					 * en la orden, para determinar si se esta solicitando el acogimiento a contingente arancelario. El Tipo de Margen
					 * necesariamente debe tener el valor �5�, caso contrario no se trata de una solicitud de contingente arancelario.
					 */
					if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), serie.getCodtipomarge() ) ){

						// Se verifica si es un TPI valida la fecha de llegada del manifiesto
						if( isValidaFechaManifiesto == 0 && !CollectionUtils.isEmpty(listErrManif))	 {
							isValidaFechaManifiesto ++;
							nroErroresNegocio ++;
							listErr.addAll(listErrManif );
						}						
						//DZC Valida que el pais pertenezca al Grupo de Union Europea 
						String p=serie.getCodpaisorige();
						if(codtpi.equals("812")) 
						{										
							String mensaje1 =  "SERIE:"+ serie.getNumserie() +" PARA ACOGERSE A TPI 812 CON CONTINGENTE ARANCELARIO EL PA�S ORIGEN DEBE SER DEL GRUPO DE PA�S UE";
							//Map<String,Object> mpDataAsoc =FormatoAServiceImpl.getInstance().getCatalogoValidacionService().getCatalogoAyudaService().getElementoAsoc("003",SunatStringUtils.toStringObj(codtpi), codpais);
							boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codtpi.toString(), codpais);

							//if (!CollectionUtils.isEmpty(mpDataAsoc)){
							if (existePuerto){
								serie.setCodpaisorige("UE");
							}
							else
							{
								listErr.add(ResponseMapManager.getErrorResponseMap("08801", mensaje1));
								nroErroresNegocio= nroErroresNegocio + 1;

							}
						}

						List<Map<String,Object>> listJoinContingente=contingentesUtil.getListJoinContingente(serie , declaracion);

						if(CollectionUtils.isEmpty(listJoinContingente)){   
							/*
							 * Si no se encuentra ning�n registro se grabar� el error :
							 */
							//NSR: 18/05/2011 Se completa el numero de partida con ceros a la izquierda hasta 10 caracteres de longitud
							listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08801","E", 
									new String[]{serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
							nroErroresNegocio= nroErroresNegocio + 1;
						}else{
							/*
							 * Se verificar� si en los datos de la serie se ha cumplido con transmitir los datos necesarios para aplicar al TPI
							 */
							Map<String,Object> mapDatosCont=listJoinContingente.get(0);
							//Se valida si el campo tiene porcentake de alcohol
							listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont);

							mapDatosCont.put("numDoc",numeOrden);
							mapDatosCont.put("annDoc", annOrden);
							mapDatosCont.put("agente", agente);
							/*branch ingreso 2011-029 inicio hosorio 15/07/2011*/
							mapDatosCont.put("codTipoDoc", "03");
							/*branch ingreso 2011-029 fin hosorio 15/07/2011*/

							//listErr.addAll( validaCamposContingente(serie, mapDatosCont, declaracion.getDua()) );
							listErrOtros = validaCamposContingente(serie, mapDatosCont, declaracion.getDua(),codTransaccion) ;
							if( !CollectionUtils.isEmpty(listErrOtros))	 {
								nroErroresNegocio= nroErroresNegocio + 1;
								listErr.addAll(listErrOtros );
								isCampoInvalido = true;
							} 

							//listErr.addAll( validaPlazoTPI(serie, mapDatosCont, declaracion) );
							listErrOtros = validaPlazoTPI(serie, mapDatosCont, declaracion) ;
							if( !CollectionUtils.isEmpty(listErrOtros))	 {
								nroErroresNegocio= nroErroresNegocio + 1;
								listErr.addAll(listErrOtros );
							}

							//Si es numeracion se ejecutaran las validaciones/acciones definidas
							//if(isValidaContingenteNumeracion){ 
							// Se cambia porque se debe valida

							if(codTransaccion.endsWith(COD_TRX_NUMERACION)){


								// Inicio: PAS20145E220000337 - rcontreras
								//listErr.addAll( this.validarIndicadorContingente(declaracion) );
								if ( tieneIndicador16 ) {
									listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35422"));
									nroErroresNegocio= nroErroresNegocio + 1;
								}
								//listErr.addAll( this.validarVigenciaContingente(serie) );
								listErrOtros = this.validarVigenciaContingente(serie , declaracion ) ;
								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									nroErroresNegocio= nroErroresNegocio + 1;
									listErr.addAll(listErrOtros );
								}
								if ( serie.getCodtipomarge().equals("5") && isViaTransPostal) {
									listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35421"));
									nroErroresNegocio= nroErroresNegocio + 1;
								}

								//ContPeriodo contPeriodo = getContPeriodo(serie, mapDatosCont);
								BigDecimal cantSolCont = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
								//Paso 5 del CU
								liberaReservaContingentes();

								//Paso 6 del CU
								if(SunatNumberUtils.isGreaterThanZero(cantSolCont))
								{
									if ( !isCampoInvalido) {
										listErr.addAll( validaSaldoContingente(serie, mapDatosCont, declaracion,mapCntSolAntSeries , listValidPorAlcohol, listaUsoPorGrupo) ); //PAS20165E220200076 - mtorralba 20160927
									}
								}else{
									//Paso 7 del CU
									if ( !isCampoInvalido) {
										listErr.addAll( validaExistenciaReserva(serie, mapDatosCont, declaracion, listValidPorAlcohol) );
									}
								}

								//Paso 8 del CU
								listErr.addAll( actualizaCtaCteContingente(variablesIngreso) );
							} else if (isValidaContingenteRectificacion){
								//RMC RIN-P47 2015-0508
								//Verificamos que se haya enviado el indicador 16
								if ( !tieneIndicador16 ) {
									listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35605"));
									nroErroresNegocio= nroErroresNegocio + 1;
								}

								//Verificamos la vigencia del contingente
								listErrOtros = this.validarVigenciaContingente(serie , declaracion ) ;
								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									nroErroresNegocio= nroErroresNegocio + 1;
									listErr.addAll(listErrOtros );
								}

								//Verificamos el tipo de margen enviado
								if ( serie.getCodtipomarge().equals("5") && isViaTransPostal) {
									listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35421"));
									nroErroresNegocio= nroErroresNegocio + 1;
								}

								//Verificamos el saldo para 


							}else if (isValidaContingenteRegularizacion){
								//RMC RIN-P47 2015-0508

								//Verificamos que se haya enviado el indicador 16
								if ( tieneIndicador16 ) {
									listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35422"));
									nroErroresNegocio= nroErroresNegocio + 1;
								}

								//Verificamos la vigencia del contingente
								listErrOtros = this.validarVigenciaContingente(serie , declaracion ) ;
								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									nroErroresNegocio= nroErroresNegocio + 1;
									listErr.addAll(listErrOtros );
								}

								//RMC RIN-P47
								//ContPeriodo contPeriodo = getContPeriodo(serie, mapDatosCont);
								if (codTransaccion.endsWith(Constants.COD_TRANSAC_REGULARIZACION)) {

									BigDecimal cantSolCont = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
									//Paso 5 del CU
									liberaReservaContingentes();

									//Paso 6 del CU
									if(SunatNumberUtils.isGreaterThanZero(cantSolCont)) {
										if ( !isCampoInvalido) {
											listErr.addAll( validaSaldoContingente(serie, mapDatosCont, declaracion,mapCntSolAntSeries , listValidPorAlcohol, listaUsoPorGrupo) ); //PAS20165E220200076 - mtorralba 20160927
										}
									}else{
										//Paso 7 del CU
										if ( !isCampoInvalido) {
											listErr.addAll( validaExistenciaReserva(serie, mapDatosCont, declaracion, listValidPorAlcohol) );
										}
									}

								}

								//Verificamos el tipo de margen enviado
								if ( serie.getCodtipomarge().equals("5") && isViaTransPostal) {
									listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35421"));
									nroErroresNegocio= nroErroresNegocio + 1;
								}

							}

						}
					}
					serie.setCodpaisorige(codpais);   
				}				
			}						
		}
		if( log.isWarnEnabled() )
			log.warn("Exit "+this.getClass().getCanonicalName()+".procesarOrdenEnvio. result="+listErr);

		if(nroErroresNegocio == 0 && (contingentesUtil.is8805UnicoError(listErr, 0L) || "1".equals(mapCntSolAntSeries.get("indSaldoAgoPriSer")) )){
			variablesIngreso.put("is8805UnicoError", Boolean.TRUE);
		}

		return listErr; 
	}



	private boolean  tieneIndicador16 (Declaracion declaracion) {
		boolean tipoIndicador16 = false;
		if ( declaracion.getDua().getListIndicadores() != null ) { 
			for ( DatoIndicadores datoIndicador : declaracion.getDua().getListIndicadores()  ) {
				if ( datoIndicador.getCodtipoindica() != null 
						&& datoIndicador.getCodtipoindica().trim().equals("16") ) {
					tipoIndicador16 = true;
					break; 
				}
			}
		}
		return tipoIndicador16 ; 

	}

	private boolean tieneIndicador16BD(Declaracion declaracion){
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("numcorredoc", declaracion.getNumeroCorrelativo());
		params.put("codtipoindica","16");
		params.put("indactivo","1");

		IndicadorDUADAO indicadorDUADAO = fabricaDeServicios.getService("indicadorDUADAO");
		List<DatoIndicadores> listaDatoIndicadores = indicadorDUADAO.findIndicadoresByMap(params);
		if(!CollectionUtils.isEmpty(listaDatoIndicadores)){
			for(DatoIndicadores indicadorTemp:listaDatoIndicadores){
				if("16".equals(indicadorTemp.getCodtipoindica()) ){
					return true;
				}
			}
		}		
		return false;
	}

	/**
	 * <p><strong><u>Pase: PAS20145E220000337</u></strong></p>
	 * El sistema deber&aacute;  validar que si se ha consignado el Tipo de Margen (TM) igual a &lsquo;5&rsquo;, 
	 * TPI y Sub-partida nacional (SPN), este debe estar asociado  a un contingente arancelario vigente 
	 * (Periodo vigente, Pa&iacute;s Origen, TPI, Grupo  de SPN del contingente y NALADISA asociada al 
	 * contingente de corresponder) a la  fecha de la numeraci&oacute;n. 
	 * @author rcontreras
	 * @param serie - Serie de la declaracion
	 * @return 
	 * <p>Si se encuentra   asociado a un contingente arancelario vigente a la fecha de la numeraci&oacute;n, retorna una lista sin mensajes de error.</p>
	 *	<p>Si no se encuentra   asociado a un contingente arancelario vigente a la fecha de la numeraci&oacute;n, retorna una lista con el siguiente mensaje de error: </p>
	 *	<ul>
	 *	  <li>En la serie [n&uacute;mero de serie]: El TPI/SPN declarado  no tiene asociado un contingente Arancelario, no corresponde declarar el Tipo  de Margen 5.</li>
	 *	</ul>
	 */
	private List<Map<String, String>> validarVigenciaContingente(DatoSerie serie, Declaracion declaracion) {
		return validarVigenciaContingente(serie,declaracion,null) ; 
	}

	//RTINEO optimizacion se sobrecarga el metodo
	private List<Map<String, String>> validarVigenciaContingente(DatoSerie serie, Declaracion declaracion, Map<String,Object> variablesIngreso) {
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		if ( serie.getCodtipomarge().equals("5") /*&& serie.getNumpartnalad() != null && 
				serie.getNumpartnalad().trim().length() > 0*/ ) {
			//rtineo optimizacion se hace el llamado al metodo optimizado
			List<Map<String,Object>> listJoinContingente = new ArrayList<Map<String,Object>>();
			if(variablesIngreso!=null){
				listJoinContingente=contingentesUtil.getListJoinContingente(serie , declaracion,variablesIngreso);
			}else{
				listJoinContingente=contingentesUtil.getListJoinContingente(serie , declaracion);
			}
			//rtineo fin optimizacion

			if(CollectionUtils.isEmpty(listJoinContingente)){
				//				String mensajeError = "En la serie [" + serie.getNumserie() + "]: El TPI/SPN declarado no tiene asociado un " +
				//									"contingente Arancelario, no corresponde declarar el Tipo de Margen 5";
				listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35423","E", new String[]{serie.getNumserie().toString()}));				
				//listErr.add(ResponseMapManager.getErrorResponseMap("35423", mensajeError));
			}
		}

		return listErr ; 
	}


	/**
	 * Procedimiento que valida los datos por cada TPI registrado en la tabla CONTVALID.
	 * Se verificar� si en los datos de la serie se ha cumplido con transmitir los datos necesarios para aplicar al TPI.
	 * Para esto se utiliza la tabla CONTVALID y se filtra por las columnas COD_TPI, COD_PAIS_ORIGEN y NUM_GRUPO_CONT.
	 * Los registros obtenidos nos indican como se validar�n los datos seg�n las columnas COD_TIPO_VALID y COD_CAMPO,
	 * la fecha del sistema debe estar comprendida entre los campos de fecha FEC_INIVIG y FEC_FINVIG, en la tabla CONTCAMPO
	 * se filtrar� con la columna del mismo nombre COD_CAMPO.
	 * Si no se cumple la validaci�n se deber� grabar el error � advertencia de ser el caso:
	 * 8802 : �Nombre_Campo no cumple con validaci�n�.
	 * 9803 : �Nombre_Campo no cumple con validaci�n�.
	 * 
	 * @param serie DatoSerie
	 * @param mapDatosCont Map<String,Object>
	 * @param dua DUA
	 * @return el list
	 */
	private List<Map<String, String>> validaCamposContingente(DatoSerie serie, Map<String,Object> mapDatosCont, DUA dua, Map<String,Object> variablesIngreso,String codTransaccion){
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

		String cundcont=(String)mapDatosCont.get("codUndCont");
		BigDecimal factconv=(BigDecimal)mapDatosCont.get("numFactConv");
		BigDecimal factequi=(BigDecimal)mapDatosCont.get("numFactEqui");
		BigDecimal cntsolcont = BigDecimal.ZERO;
		BigDecimal cntporalcohol = BigDecimal.ZERO;

		log.info(" validaCamposContingente listErr cundcont "+cundcont);
		log.info(" validaCamposContingente listErr factconv "+factconv);
		log.info(" validaCamposContingente listErr factequi "+factequi);


		if (Constants.COD_UND_UND.equals(cundcont))
			cntsolcont=serie.getCntunifis().multiply(factconv.multiply(factequi));
		if (Constants.COD_UND_KGS.equals(cundcont))
			cntsolcont=serie.getCntpesoneto().multiply(factconv.multiply(factequi));
		if (Constants.COD_UND_USD.equals(cundcont))
			cntsolcont=serie.getMtofobdol().multiply(factconv.multiply(factequi));
		if (Constants.COD_UND_TON.equals(cundcont))  {
			cntsolcont=serie.getCntpesoneto().multiply(factconv.multiply(factequi));
		}
		if (Constants.COD_UND_PAR.equals(cundcont))
			cntsolcont=serie.getCntunifis().multiply(factconv.multiply(factequi));
		if (Constants.COD_UND_LIT.equals(cundcont))
			cntsolcont=serie.getCntunifis().multiply(factconv.multiply(factequi));


		log.info(" validaCamposContingente listErr 1 ");

		log.info(" validaCamposContingente cntsolcont "+cntsolcont );

		log.info(" validaCamposContingente serie.getCntunifis() "+serie.getCntunifis());
		log.info(" validaCamposContingente serie.getCntpesoneto() "+serie.getCntpesoneto());
		log.info(" validaCamposContingente serie.getMtofobdol() "+serie.getMtofobdol());

		boolean seIndicaPorcAlcohol = ( serie.getPoralcohol() != null &&  
				serie.getPoralcohol().
				compareTo(java.math.BigDecimal.ZERO) > 0 ) ; 

		log.info(" validaCamposContingente listErr seIndicaPorcAlcohol "+seIndicaPorcAlcohol);

		log.info(" validaCamposContingente listErr serie.getPoralcohol() "+serie.getPoralcohol());

		if ( seIndicaPorcAlcohol ) 
			cntporalcohol = serie.getPoralcohol();

		log.info(" validaCamposContingente listErr cntporalcohol "+cntporalcohol);

		//rtineo optimizacion se hace el llamado al metodo optimizado
		List<Map<String,Object>> listCampValid = new ArrayList<Map<String,Object>>();
		//Map<String, List<Map<String, Object>>> ListValidCamposCache = (Map<String, List<Map<String, Object>>>) variablesIngreso.get("ListValidCamposCache");
		if(variablesIngreso != null){
			listCampValid = contingentesUtil.getListValidCampos(dua, mapDatosCont, variablesIngreso,codTransaccion);
		}

		if ( ! CollectionUtils.isEmpty(listCampValid) ){
			for(Map<String,Object> mapCampValid:listCampValid){
				String rval="";
				String codCampo = (String) mapCampValid.get("codCampo");

				if (codCampo.trim().equals("05") || codCampo.trim().equals("06") || codCampo.trim().equals("07") || codCampo.trim().equals("08") || codCampo.trim().equals("11") || 
						codCampo.trim().equals("12") || codCampo.trim().equals("13") || codCampo.trim().equals("14") || codCampo.trim().equals("15") || codCampo.trim().equals("16") || 
						codCampo.trim().equals("17") || codCampo.trim().equals("18") || codCampo.trim().equals("19") ) {

					List<DatoAutocertificacion> listCertiOrig=getCertiOrigen(dua, serie);

					if (!CollectionUtils.isEmpty(listCertiOrig)) {
						//if (listCertiOrig!=null && !listCertiOrig.isEmpty()){

						log.info(" validaCamposContingente listErr listCertiOrig "+listCertiOrig);

						for(DatoAutocertificacion certiOrig:listCertiOrig){


							log.info(" validaCamposContingente listErr  certiOrig "+certiOrig);

							rval=contingentesUtil.valDatoContingente(mapCampValid,serie.getNumpartnalad(),cntsolcont,certiOrig.getFecemision(),certiOrig.getNumdocumento(),certiOrig.getCodffco(),(String)mapDatosCont.get("codPaisOrigen"), cntporalcohol);
							log.info(" validaCamposContingente listErr rval "+rval);
							if (!"OK".equals(rval)){
								String resvali=rval.substring(0,1); 
								String codtele;
								if ("E".equals(resvali))
									codtele="08802";
								else
									codtele="09803";
								//NOMBRE_CAMPO NO CUMPLE CON VALIDACI�N
								//listErr.add(catalogoHelper.getErrorMap(codtele, new Object[]{mapCampValid.get("desNomcampo")} ));

								log.info(" validaCamposContingente listCertiOrig codCampo"+codCampo);

								if ("20".equals(codCampo)) {
									log.info(" validaCamposContingente listCertiOrig codCampo Entro");

									listErr.add(((CatalogoAyudaService)fabricaDeServicios.
											getService("Ayuda.catalogoAyudaService")).
											getError("35426", "E",new String[]{	serie.getNumserie().toString(), 
													serie.getCodconvinter().toString(), 
													serie.getNumpartnandi().toString()}));
								} else 
									listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codtele, "E", new String[]{mapCampValid.get("desNomcampo").toString()} ));

								log.info(" validaCamposContingente listErr 3 "+listErr);
								//								listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codtele, new String[]{mapCampValid.get("desNomcampo").toString()} ));
							}
						}
					}
				}else{

					log.info(" validaCamposContingente listErr mapCampValid "+mapCampValid);
					log.info(" validaCamposContingente listErr codCampo "+codCampo);
					// Si no existe certificado de origen se envian valores nulos.
					rval=contingentesUtil.valDatoContingente(mapCampValid,serie.getNumpartnalad(),cntsolcont,null,null,null,(String)mapDatosCont.get("codPaisOrigen"), cntporalcohol);
					if (!"OK".equals(rval)){
						String resvali=rval.substring(0,1); 
						String codtele;
						if ("E".equals(resvali))
							codtele="08802";
						else
							codtele="09803";
						//NOMBRE_CAMPO NO CUMPLE CON VALIDACI�N
						//listErr.add(catalogoHelper.getErrorMap(codtele, new Object[]{mapCampValid.get("desNomcampo")} ));
						if ("20".equals(codCampo)) {
							listErr.add(((CatalogoAyudaService)fabricaDeServicios.
									getService("Ayuda.catalogoAyudaService")).
									getError("35426", "E",new String[]{	serie.getNumserie().toString(), 
											serie.getCodconvinter().toString(), 
											serie.getNumpartnandi().toString()}));
						} else 
							listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codtele,"E", new String[]{mapCampValid.get("desNomcampo").toString()} ));

						log.info(" validaCamposContingente listErr 4 "+listErr);
					}

				}
			}
		}		

		return listErr;
	}

	//rtineo optimizacion se sobrecarga el metodo
	private List<Map<String, String>> validaCamposContingente(DatoSerie serie, Map<String,Object> mapDatosCont, DUA dua ,String codTransaccion){
		return validaCamposContingente( serie, mapDatosCont, dua, null,codTransaccion );
	}
	//rtineo fin optimizacion

	/**
	 * Se procede a validar los plazos definidos para el TPI, pa�s de origen y n�mero del grupo del contingente solicitado.
	 * Se utiliza la tabla CONTPLAZO y se filtra por los campos COD_TPI, COD_PAIS_ORIGEN y NUM_GRUPO_CONT,
	 * la fecha del sistema debe estar comprendida entre los campos de fecha FEC_INIVIG y FEC_FINVIG.
	 * Si no se cumple la validaci�n se deber� grabar el error : 8803 : Colocar el contenido del campo MSJ_INV_PLAZO
	 * 
	 * @param serie DatoSerie
	 * @param mapDatosCont Map<String,Object>
	 * @param declaracion Declaracion
	 * @return el list
	 */
	private List<Map<String, String>> validaPlazoTPI(DatoSerie serie, Map<String, Object> mapDatosCont, Declaracion declaracion) {
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		ContplazoDAO  contplazoDAO = fabricaDeServicios.getService("contPlazoDAO");
		
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();

		Map<String, Object> paramsContPlazo = new HashMap<String, Object>();
		paramsContPlazo.put("codTpi", mapDatosCont.get("codTpi"));
		paramsContPlazo.put("codPaisOrigen", mapDatosCont.get("codPaisOrigen"));
		paramsContPlazo.put("numGrupoCont", mapDatosCont.get("numGrupoCont"));
		paramsContPlazo.put("fechIngsi", declaracion.getDua().getFecNumeracion());
		List<Contplazo> listCPlazoValid = contplazoDAO.findByParams(paramsContPlazo);
		if (!CollectionUtils.isEmpty(listCPlazoValid)) {
			for (Contplazo contplazo : listCPlazoValid) {
				Date fechFactu = contingentesUtil.getFechaFactura(serie.getNumserie(), declaracion);
				List<DatoAutocertificacion> listCertiOrig = getCertiOrigen(declaracion.getDua(), serie);
				if (!CollectionUtils.isEmpty(listCertiOrig)) {
					for (DatoAutocertificacion certiOrig : listCertiOrig) {
						Date fechCertiOrig = certiOrig.getFecemision();
						//DZC se envia la fecha de declaracion
						Date FecNumeracion=declaracion.getDua().getFecNumeracion();
						if (declaracion.getDua().getFecNumeracion()==null) FecNumeracion=declaracion.getDua().getFecdeclaracion();
						//DZC FIN
						String resvali = contingentesUtil.valPlazoContingente(contplazo, FecNumeracion, fechCertiOrig,
								fechFactu, serie.getNumserie());
						if (!"OK".equals(resvali)) {

							listErr.add(ResponseMapManager.getErrorResponseMap("08803", contplazo.getMsjInvPlazo()));
						}
					}
				} else {
					Date fechCertiOrig = null;
					String resvali = contingentesUtil.valPlazoContingente(contplazo, declaracion.getDua().getFecNumeracion(), fechCertiOrig,
							fechFactu, serie.getNumserie());
					if (!"OK".equals(resvali)) {
						listErr.add(ResponseMapManager.getErrorResponseMap("08803", contplazo.getMsjInvPlazo()));
					}
				}
			}
		}

		return listErr;
	}





	/**
	 * Antes de proceder a la verificaci�n de los saldos del contingente se deber� ejecutar el procedimiento almacenado
	 *  que libera las reservas de contingente generadas por Teledespacho en caso se hayan excedido las 6 horas de plazo.  
	 * La finalidad es tener el saldo correctamente actualizado del TPI solicitado para el periodo correspondiente. 
	 * El procedimiento almacenado es el siguiente :
	 * USAMIMPO.SPAJOBCONTCABSOL( )
	 * Parametro: pindproce = 'O'
	 */
	private void liberaReservaContingentes(){
		try {
			ContCtaCteDAO  contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
			contCtaCteDAO.spAJobContCabSol('O');
		} catch (Exception e) {
			e.printStackTrace();
		}
		//contCtaCteDAO.spAJobContCabSol('O');           
	}


	private List<Map<String, String>> validaSaldoContingente(DatoSerie serie, Map<String,Object> mapDatosCont, Declaracion declaracion,Map<String,Object> mapCntSolAntSeries , 
			List<Map<String,Object>> listValidPorAlcohol) {
		return validaSaldoContingente(serie, mapDatosCont, declaracion,mapCntSolAntSeries,listValidPorAlcohol, null);
	}


	/**
	 * Verificamos si hay saldo disponible seg�n la cantidad solicitada serie.getCntunifis()
	 * 
	 * @param serie DatoSerie
	 * @param mapDatosCont Map<String,Object>
	 * @param declaracion Declaracion
	 * @return el list
	 */
	private List<Map<String, String>> validaSaldoContingente(DatoSerie serie, Map<String,Object> mapDatosCont, Declaracion declaracion,Map<String,Object> mapCntSolAntSeries , 
			List<Map<String,Object>> listValidPorAlcohol, List<Map<String,Object>> listaUsoPorGrupo) {
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		BigDecimal cntCantSolAntSeries = BigDecimal.ZERO;
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		BigDecimal cntSaldoContPeriodo = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
		ContCtaCte contCtaCte = contingentesUtil.getContCtaCte(mapDatosCont, serie, declaracion);
		String codEstado = contCtaCte != null ? contCtaCte.getCodEstado(): "";


		log.debug("datosContingente:"+serie.getNumserie()+"-"+serie.getCodconvinter()+"-"+ serie.getCodtipomarge()+"-"+serie.getCntpesoneto()+"-"+serie.getNumpartnandi()+"-"+
				mapDatosCont.get("cntSaldoCont")+"-"+mapDatosCont.get("numGrupoCont"));

		if(SunatNumberUtils.isLessOrEqualsThanZero(cntSaldoContPeriodo) && !Constants.COD_EST_CONTINGENTE_SIN_RESERVA.equals(codEstado) ) {
			listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08804", new String[]{serie.getNumserie().toString(), 
					serie.getCodconvinter().toString(), serie.getCodpaisorige(), serie.getNumpartnandi().toString()}));
		}else{
			BigDecimal cantSolCont = BigDecimal.ZERO;
			//Actualizo el Saldo de Contingente con lo solicitado en Series Anteriores
			cntCantSolAntSeries=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolAntSeries"));

			// Aqui debemos considerar la suma de las anteriores series.
			cantSolCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);

			//PAS20165E220200076 - mtorralba 20160927 - Bug MSNADE280-720 - INICIO
			boolean grupoRegistrado = false;
			Map<String,Object> usadoPorGrupo = new HashMap<String,Object>();

			if( listaUsoPorGrupo != null ) {
				for( int i=0; i<listaUsoPorGrupo.size(); i++ ) {
					usadoPorGrupo = listaUsoPorGrupo.get(i);
					if( usadoPorGrupo.get("COD_GRUPO").toString().equals(mapDatosCont.get("numGrupoCont").toString()) ) {
						BigDecimal cantidadUsada = (BigDecimal)usadoPorGrupo.get("CANTIDAD_USADA");
						cntSaldoContPeriodo = cntSaldoContPeriodo.subtract(cantidadUsada);
						usadoPorGrupo.put("CANTIDAD_USADA",cantSolCont.add(cantidadUsada));
						listaUsoPorGrupo.remove(i);
						listaUsoPorGrupo.add(usadoPorGrupo);
						grupoRegistrado = true;
						break;
					}
				}
				if( !grupoRegistrado) {
					Map<String,Object> nuevoMapa = new HashMap<String,Object>();
					nuevoMapa.put("COD_GRUPO",mapDatosCont.get("numGrupoCont").toString());
					nuevoMapa.put("CANTIDAD_USADA", cantSolCont);
					listaUsoPorGrupo.add(nuevoMapa);

				}
			}
			//PAS20165E220200076 - mtorralba 20160927 - Bug MSNADE280-720 - FIN	
			else {
				cntSaldoContPeriodo=cntSaldoContPeriodo.subtract(cntCantSolAntSeries); 
			}


			if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo)) {
				if( SunatNumberUtils.isGreaterThanParam(cantSolCont,cntSaldoContPeriodo) ){

					// Verificamos si le corresponde multiplica por el factor del alcohol
					// RSV se agrega para calcula el porcentaje de alcohol 
					BigDecimal factConv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactConv"));
					BigDecimal factEquiv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactEqui"));
					boolean seIndicaPorcAlcohol = false ;
					// Para que cuando no envia porcentaje de alcohol no se muestre la vlidacion de saldo
					boolean muestra = true ;
					if ( ! CollectionUtils.isEmpty(listValidPorAlcohol) ){
						seIndicaPorcAlcohol = ( serie.getPoralcohol() != null && serie.getPoralcohol().compareTo(java.math.BigDecimal.ZERO) > 0 ) ;
						if ( seIndicaPorcAlcohol  ) {
							factEquiv =  serie.getPoralcohol().divide(SunatNumberUtils.toBigDecimal("100.00")); 
						} else {
							muestra = false ;
						}
					}
					BigDecimal xcntSaldoContPeriodo = cntSaldoContPeriodo;
					BigDecimal xcantSolCont = cantSolCont;

					if (muestra) {
						if ( seIndicaPorcAlcohol  ) {
							xcntSaldoContPeriodo = xcntSaldoContPeriodo.multiply(factConv);
							xcntSaldoContPeriodo =  xcntSaldoContPeriodo.divide(factEquiv,3,BigDecimal.ROUND_HALF_UP);
							xcantSolCont =  xcantSolCont.multiply(factConv);
							xcantSolCont =  xcantSolCont.divide(factEquiv,3,BigDecimal.ROUND_HALF_UP);
						}
					}
					// RSV se agrega para calcula el porcentaje de alcohol 
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08805","E", 
							new String[]{serie.getNumserie().toString(),cntSaldoContPeriodo.toString() }));
					String mensaje2 = "TRANSMITIR SERIE "+serie.getNumserie()+" CON "+xcntSaldoContPeriodo+" CANTIDAD DE CONTINGENTE, TPI "+serie.getCodconvinter()+" Y TIPO DE MARGEN "+serie.getCodtipomarge();
					String mensaje3 = "TRANSMITIR NUEVA SERIE CON ("+ (SunatNumberUtils.diference(xcantSolCont,xcntSaldoContPeriodo)) +") SIN CONSIGNAR TPI "+serie.getCodconvinter()+" NI TIPO DE MARGEN "+serie.getCodtipomarge(); //jreynoso bug20760
					//listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje1));
					listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje2));
					listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje3));
					//Si se genero alguna reserva debe activar el GrabarContingentesServiceImpl. 
					mapCntSolAntSeries.remove("indSaldoAgoPriSer");
					mapCntSolAntSeries.put("indSaldoAgoPriSer","1");
				}
			}else
			{				
				//listError.add(catalogoHelper.getErrorMap("8804", new Object[]{serie.getNumserie().toString(),serie.getCodconvinter(), serie.getCodpaisorige(), serie.getNumpartnandi().toString()}));
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08804","E", new String[]{serie.getNumserie().toString(),serie.getCodconvinter().toString(), serie.getCodpaisorige(), serie.getNumpartnandi().toString()}));
			}
			//se comenta jreynoso bug20760
			//Actualizo el map del Cantidades Solicitadas en series anteriores para la siguiente serie

			//Se habilita para probar
			cntCantSolAntSeries = cntCantSolAntSeries.add(cantSolCont);
			mapCntSolAntSeries.remove("cntSolAntSeries");
			mapCntSolAntSeries.put("cntSolAntSeries",cntCantSolAntSeries);
		}

		return listError;
	}


	/**
	 * Se verificar� si hay alguna reserva  realizada por Teledespacho o Teledespacho SEIDA pendiente de asignar
	 * para la orden que se esta procesando y de no existir se verificar� si hay alguna reserva de otras ordenes.
	 * 
	 * @param serie DatoSerie
	 * @param mapDatosCont Map<String,Object>
	 * @param declaracion Declaracion
	 * @return el list
	 */
	@SuppressWarnings("unchecked")
	private List<Map<String, String>> validaExistenciaReserva(DatoSerie serie, Map<String,Object> mapDatosCont, Declaracion declaracion, List<Map<String,Object>> listValidPorAlcohol){
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		ContCtaCteDAO  contCtaCteDAO = fabricaDeServicios.getService("contCtaCteDAO");
		BigDecimal cantSolCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();

		ContCtaCteCriteria mapParamsVal1 = new ContCtaCteCriteria(); 
		ContCtaCteCriteria.Criteria c1 = mapParamsVal1.createCriteria();
		c1.andNumDocEqualTo((String)mapDatosCont.get("numDoc"));
		c1.andAnnDocEqualTo((String)mapDatosCont.get("annDoc"));
		c1.andNumSerieDocEqualTo(serie.getNumserie());
		c1.andCodTipoDocEqualTo("03");
		c1.andCodAduanaDocEqualTo( declaracion.getDua().getCodaduanaorden() );
		c1.andCodRegimenDocEqualTo( declaracion.getDua().getCodregimen());
		c1.andCodEstadoEqualTo(Constants.COD_EST_CONTINGENTE_SIN_RESERVA);  
		//RMC RIN-P47
		boolean esDiligRect = mapDatosCont.get("esDiligRect") != null ? (Boolean) mapDatosCont.get("esDiligRect") : false; 
		if (!esDiligRect) {
			c1.andCodAgenteEqualTo((String)mapDatosCont.get("agente")); 
		}

		List<ContCtaCte> listCtaCte1 = contCtaCteDAO.selectByContCtaCteCriteria(mapParamsVal1);

		if( !CollectionUtils.isEmpty(listCtaCte1) ){
			if (!SunatNumberUtils.isEqual( cantSolCont.setScale(3,BigDecimal.ROUND_HALF_UP) , listCtaCte1.get(0).getCntContiSol().setScale(3,BigDecimal.ROUND_HALF_UP)) ) {//bug 20766 PASE 47 


				String message = "EN LA ORDEN " + declaracion.getCodaduana() + "-" + mapDatosCont.get("annDoc") + "-" + mapDatosCont.get("numDoc")
				+ " SERIE: " + serie.getNumserie() + " CONT. RESERVADO "+listCtaCte1.get(0).getCntContiSol()+" CANT. SOLICITADA "+cantSolCont+","
				+ " LA CANTIDAD RESERVADA NO COINCIDE CON LO SOLICITADO NUEVAMENTE";
				listError.add(ResponseMapManager.getErrorResponseMap("08806", message) );
			}
		}else{
			ContCtaCteCriteria mapParamsVal2 = new ContCtaCteCriteria(); 
			ContCtaCteCriteria.Criteria c2 = mapParamsVal2.createCriteria();

			c2.andCodTpiEqualTo( serie.getCodconvinter().toString());
			c2.andCodPaisOrigenEqualTo( serie.getCodpaisorige());
			c2.andNumGrupoContEqualTo(SunatNumberUtils.toInteger(mapDatosCont.get("numGrupoCont")));
			c2.andPerContingenteEqualTo((String)mapDatosCont.get("perContingente"));
			c2.andCodTipoDocEqualTo("03");
			c2.andCodEstadoEqualTo(Constants.COD_EST_CONTINGENTE_SIN_RESERVA);

			List<ContCtaCte> listCtaCte2 = contCtaCteDAO.selectByContCtaCteCriteria(mapParamsVal2);
			if (! CollectionUtils.isEmpty(listCtaCte2) ) {
				String numeroOrden = declaracion.getCodaduana() + "-" + mapDatosCont.get("annDoc") + "-" + mapDatosCont.get("numDoc");
				//9801 : �SE TIENE RESERVADO A CANTIDAD DE CONTINGENTE. FECHA DE VENCIMIENTO DE RESERVA : DD/MM/YY HH:MM:SS�.
				for (ContCtaCte contCtaCte : listCtaCte2) {
					Calendar cal = Calendar.getInstance();
					cal.setTime(contCtaCte.getFecRegistro());
					Date date2 = pe.gob.sunat.despaduanero2.util.DateUtil.addHour(contCtaCte.getFecRegistro(), 6);
					cal.add(Calendar.HOUR, 6);
					//listError.add(catalogoHelper.getErrorMap("9801",new Object[]{numeroOrden,contCtaCte.getNumSerieDoc(), contCtaCte.getCntContiSol(), SunatDateUtils.getFormatDate(cal.getTime(), "dd/MM/yyyy HH:mm:ss")} ));

					if (  SunatStringUtils.isEqualTo( contCtaCte.getCodAgente(),(String)mapDatosCont.get("agente"))  &&
							SunatStringUtils.isEqualTo( contCtaCte.getCodAduanaDoc(),declaracion.getCodaduana())  &&
							SunatStringUtils.isEqualTo( contCtaCte.getNumDoc(),(String)mapDatosCont.get("numDoc"))  &&
							SunatStringUtils.isEqualTo( contCtaCte.getAnnDoc(),(String)mapDatosCont.get("annDoc"))   ) {
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("09801","E",new String[]{numeroOrden,
								contCtaCte.getNumSerieDoc().toString(), contCtaCte.getCntContiSol().toString(),   SunatDateUtils.getFormatDate(date2, "dd/MM/yyyy HH:mm:ss")} ));

					} else {
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35425","E", new String[]{serie.getNumserie().toString(),
								contCtaCte.getCntContiSol().toString(), SunatDateUtils.getFormatDate(date2, "dd/MM/yyyy HH:mm:ss") }));	
					}
				}
				//NSR: 18/05/2011 Se completa el numero de partida con ceros a la izquierda hasta 10 caracteres de longitud
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08804","E", new String[]{serie.getNumserie().toString(), serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0') }));

			}else{
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08804","E", new String[]{serie.getNumserie().toString(), serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0') }));
			}
		}

		return listError;
	}

	/**
	 * Actualiza cta cte contingente.
	 * 
	 * @param variablesIngreso Map<String,Object>
	 * @return el list
	 */
	private List<Map<String, String>> actualizaCtaCteContingente(Map<String,Object> variablesIngreso ){

		variablesIngreso.put("actualizaCtaCteContingente", Boolean.TRUE);
		List<Map<String, String>> listError = new ArrayList<Map<String,String>>();
		return listError;
	}

	/*
	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}
	 */
	private DatoSerie obtenerSerieOld(Integer numeroSerie, List<DatoSerie> lstSeriesBd, List<Map<String, Object>> seriesEnMap) {
		DatoSerie serieOld = null;
		if (seriesEnMap != null) {
			//buscamos en la lista de maps
			String numeroSerieAsString = numeroSerie.toString();
			for (Map<String, Object> serieEnMap : seriesEnMap) {
				//parece que llega como bigdecimal comparamos como cadenas... temporalmente
				if (numeroSerieAsString.equals(serieEnMap.get("NUM_SECSERIE").toString())) {
					//entonces generamos un objeto DatoSerie con los datos requeridos: Codconvinter, Numpartnandi, Codpaisorige, Cntpesoneto, Codunifis, Mtofobdol, Cntunifis
					serieOld = new DatoSerie();
					//num_partnandi
					serieOld.setNumpartnandi(SunatNumberUtils.toLong(serieEnMap.get("NUM_PARTNANDI")));
					//Codpaisorige
					serieOld.setCodpaisorige((String) serieEnMap.get("COD_PAISORIGEN"));
					//Cntpesoneto
					serieOld.setCntpesoneto(SunatNumberUtils.toBigDecimal(serieEnMap.get("CNT_PESO_NETO")));
					//Codunifis
					serieOld.setCodunifis(SunatStringUtils.toStringObj(serieEnMap.get("COD_UNIFISICA")));
					//Mtofobdol
					serieOld.setMtofobdol(SunatNumberUtils.toBigDecimal(serieEnMap.get("MTO_FOBDOL")));
					//codconvinter
					//buscamos el dato codconvinter
					String codigoConvenio = null;
					List<Map<String, Object>> conveniosSerie = (List<Map<String, Object>>) serieEnMap.get("lstConvenioSerie");
					if (conveniosSerie != null && !conveniosSerie.isEmpty()) {
						for (Map<String, Object> convenioSerie : conveniosSerie) {
							String tipoConvenio = convenioSerie.get("COD_TIPCONVENIO").toString();
							if ("I".equals(tipoConvenio)) {
								codigoConvenio = convenioSerie.get("COD_CONVENIO").toString().trim();
								break;
							}
						}
					}
					if (codigoConvenio != null && !codigoConvenio.isEmpty()) {
						serieOld.setCodconvinter(new Integer(codigoConvenio));
					}
				}
			}
		} else {
			for (DatoSerie serieBD : lstSeriesBd) {
				if (SunatNumberUtils.isEqual(serieBD.getNumserie(), numeroSerie)) {
					serieOld = serieBD;
					break;
				}
			}
		}
		return serieOld;
	}


	private List<Map<String, String>> validaSaldoContingenteNoNumeracion(DatoSerie serie,DatoSerie serieOld, Map<String,Object> mapDatosCont, Declaracion declaracion, 
			Map<String,Object> mapCntSolAntSeries, boolean blSerieNueva,  List<Map<String,Object>> listValidPorAlcohol , Map<Integer, ContCtaCte> cuentasCorrientesRecMap, String codTransaccion) {
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		BigDecimal cntCantSolAntSeries = BigDecimal.ZERO;
		BigDecimal cntCantDevAntSeries = BigDecimal.ZERO;
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		BigDecimal cntSaldoContPeriodo = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
		boolean cambiGrupo = false;


		//PAS20175E220200045 RSV PARA CONSIDERAR LOS SALDOS DE SERIES ANTERIORES
		BigDecimal cantSolCont = BigDecimal.ZERO;
		cntCantSolAntSeries=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolAntSeries"));
		cntSaldoContPeriodo=cntSaldoContPeriodo.subtract(cntCantSolAntSeries);
		cntCantDevAntSeries=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolDevSeries"));
		cntSaldoContPeriodo=cntSaldoContPeriodo.add(cntCantDevAntSeries);
		//VRD- INICIO BUG 20851
		if (!SunatNumberUtils.isEqual(serie.getPoralcohol(), serieOld.getPoralcohol()) &&( ! CollectionUtils.isEmpty(listValidPorAlcohol))) {

			if ( codTransaccion.endsWith(COD_TRX_DILIG_RECTIF)  ) {

				ContCtaCte serieCtaCte = cuentasCorrientesRecMap.get(serie.getNumserie());
				cantSolCont = SunatNumberUtils.diference(serieCtaCte.getCntContiSol(),
						contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol));

			} else {
				cantSolCont = SunatNumberUtils.diference(contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol),
						contingentesUtil.getCantContingenteSolicitado(serieOld, mapDatosCont, listValidPorAlcohol));
			}

		}	else {
			cantSolCont = contingentesUtil.getCantContingenteSolicitado( serie, mapDatosCont, listValidPorAlcohol);
		}
		//VRD- FIN BUG 20851

		BigDecimal cntContingente = contingentesUtil.getRectificaCantContingentes(serie, serieOld, mapDatosCont);
		ContCtaCte serieCtaCte = cuentasCorrientesRecMap.get(serie.getNumserie());
		if (serieCtaCte != null) {
			cntContingente = serieCtaCte.getCntContiSol() == null ? new BigDecimal(0): SunatNumberUtils.toBigDecimal(serieCtaCte.getCntContiSol());   
		}

		if (serieCtaCte == null) {
			cambiGrupo = true;   
		} else {

			if ( !serieCtaCte.getCodTpi().toString().trim().equals(mapDatosCont.get("codTpi").toString().trim()) ||
					!serieCtaCte.getNumGrupoCont().toString().trim().equals(mapDatosCont.get("numGrupoCont").toString().trim()) ||
					!serieCtaCte.getCodPaisOrigen().toString().trim().equals(mapDatosCont.get("codPaisOrigen").toString().trim()) ||
					!serieCtaCte.getPerContingente().toString().trim().equals(mapDatosCont.get("perContingente").toString().trim())
					) {
				cambiGrupo = true;
			}
		}



		BigDecimal cndDifAdicional=SunatNumberUtils.diference(cantSolCont, cntContingente);
		BigDecimal cntCntContSolRec= new BigDecimal(0); 
		if ( codTransaccion.endsWith(COD_TRX_DILIG_RECTIF)  ) {
			serieCtaCte = cuentasCorrientesRecMap.get(serie.getNumserie());
			if (serieCtaCte != null) {
				cntCntContSolRec = serieCtaCte.getCntContiSol() == null ? new BigDecimal(0): SunatNumberUtils.toBigDecimal(serieCtaCte.getCntContiSol());   
				if (SunatNumberUtils.isGreaterOrEqualsThanParam(cntCntContSolRec, cantSolCont)       ) {
					return listError; 
				} else {
					cndDifAdicional=SunatNumberUtils.diference(cantSolCont, cntCntContSolRec);
				}
			}
		}

		// No hay cambio
		//if (cndDifAdicional.compareTo(new BigDecimal(0)) == 0) {
		//					 }

		if(SunatNumberUtils.isGreaterOrEqualsThanZero(cndDifAdicional)){

			if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo))
			{
				if( SunatNumberUtils.isGreaterThanParam(cndDifAdicional,cntSaldoContPeriodo) ){
					// Verificamos si le corresponde multiplica por el factor del alcohol
					// RSV se agrega para calcula el porcentaje de alcohol 
					BigDecimal factConv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactConv"));
					BigDecimal factEquiv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactEqui"));
					boolean seIndicaPorcAlcohol = false ;
					if ( ! CollectionUtils.isEmpty(listValidPorAlcohol) ){
						seIndicaPorcAlcohol = ( serie.getPoralcohol() != null && serie.getPoralcohol().compareTo(java.math.BigDecimal.ZERO) > 0 ) ;
						if ( seIndicaPorcAlcohol  ) {
							factEquiv =  serie.getPoralcohol().divide(SunatNumberUtils.toBigDecimal("100.00")); 
						}
					}

					BigDecimal xcndDifAdicional =cndDifAdicional; 
					BigDecimal xcntSaldoContPeriodo = cntSaldoContPeriodo;
					if ( seIndicaPorcAlcohol  ) {
						xcntSaldoContPeriodo =  xcntSaldoContPeriodo.multiply(factConv);
						xcntSaldoContPeriodo =  xcntSaldoContPeriodo.divide(factEquiv,3,BigDecimal.ROUND_HALF_UP);

						xcndDifAdicional =  xcndDifAdicional.multiply(factConv);
						xcndDifAdicional =  xcndDifAdicional.divide(factEquiv,3,BigDecimal.ROUND_HALF_UP);

					}
					// RSV se agrega para calcula el porcentaje de alcohol 
					if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo)) {
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08805","E", 
								new String[]{serie.getNumserie().toString(), String.valueOf( cntSaldoContPeriodo )   }));

					}

					//Cuando la serie no es nueva y se rectifica
					if ( !cambiGrupo  ) {
						String mensaje2 = "";
						if(blSerieNueva)
							mensaje2 = "LA SERIE "+serie.getNumserie()+" AGREGADA NO DEBE CONSIGNAR TIPO DE MARGEN 5";
						else
							mensaje2 = "LA SERIE "+serie.getNumserie()+" NO DEBER� SER MODIFICADA. AGREGAR NUEVA SERIE CON "+xcndDifAdicional +" SIN CONSIGNAR TIPO DE MARGEN 5 ";

						listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje2));
						listError.add(((CatalogoAyudaService)fabricaDeServicios.
								getService("Ayuda.catalogoAyudaService")).
								getError("08804","E", new String[]{serie.getNumserie().toString(), serie.getCodconvinter().toString(), 
										serie.getCodpaisorige(), serie.getNumpartnandi().toString()}));
					}


				}
			}else
			{

				// Verificamos si le corresponde multiplica por el factor del alcohol
				// RSV se agrega para calcula el porcentaje de alcohol 
				BigDecimal factConv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactConv"));
				BigDecimal factEquiv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactEqui"));
				boolean seIndicaPorcAlcohol = false ;
				if ( ! CollectionUtils.isEmpty(listValidPorAlcohol) ){
					seIndicaPorcAlcohol = ( serie.getPoralcohol() != null && serie.getPoralcohol().compareTo(java.math.BigDecimal.ZERO) > 0 ) ;
					if ( seIndicaPorcAlcohol  ) {
						factEquiv =  serie.getPoralcohol().divide(SunatNumberUtils.toBigDecimal("100.00")); 
					}
				}
				BigDecimal xcntSaldoContPeriodo = cntSaldoContPeriodo;
				BigDecimal xcndDifAdicional =cndDifAdicional; 
				if ( seIndicaPorcAlcohol  ) {
					xcntSaldoContPeriodo =  xcntSaldoContPeriodo.multiply(factConv);
					xcntSaldoContPeriodo =  xcntSaldoContPeriodo.divide(factEquiv,3,BigDecimal.ROUND_HALF_UP);
					xcndDifAdicional =  xcndDifAdicional.multiply(factConv);
					xcndDifAdicional =  xcndDifAdicional.divide(factEquiv,3,BigDecimal.ROUND_HALF_UP);
				}

				if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo)) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08805","E", 
							new String[]{serie.getNumserie().toString(), String.valueOf( cntSaldoContPeriodo )   }));

				}

				String mensaje2 = "";
				if(blSerieNueva)
					mensaje2 = "LA SERIE "+serie.getNumserie()+" AGREGADA NO DEBE CONSIGNAR TIPO DE MARGEN 5";
				else
					mensaje2 = "LA SERIE "+serie.getNumserie()+" NO DEBER� SER MODIFICADA. AGREGAR NUEVA SERIE CON "+xcndDifAdicional +" SIN CONSIGNAR TIPO DE MARGEN 5 ";

				listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje2));
				listError.add(((CatalogoAyudaService)fabricaDeServicios.
						getService("Ayuda.catalogoAyudaService")).
						getError("08804","E", new String[]{serie.getNumserie().toString(), serie.getCodconvinter().toString(), 
								serie.getCodpaisorige(), serie.getNumpartnandi().toString()}));
				// Fin
			}

		} else {
			// PAS20175E220200043 - No se valida Cuando el monto es negativo porque es una devoluci�n
			/*if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo))
						{
							//<cuando hay saldo Math.abs(diferencia.doubleValue())
							if( SunatNumberUtils.isGreaterThanParam( cndDifAdicional.abs() ,cntSaldoContPeriodo) ){
								// Verificamos si le corresponde multiplica por el factor del alcohol
								// RSV se agrega para calcula el porcentaje de alcohol 
								BigDecimal factConv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactConv"));
								BigDecimal factEquiv = SunatNumberUtils.toBigDecimal(mapDatosCont.get("numFactEqui"));
								boolean seIndicaPorcAlcohol = false ;
								if ( ! CollectionUtils.isEmpty(listValidPorAlcohol) ){
									seIndicaPorcAlcohol = ( serie.getPoralcohol() != null && serie.getPoralcohol().compareTo(java.math.BigDecimal.ZERO) > 0 ) ;
						            if ( seIndicaPorcAlcohol  ) {
						           	 factEquiv =  serie.getPoralcohol().divide(SunatNumberUtils.toBigDecimal("100.00")); 
						            }
								}
								BigDecimal xcntSaldoContPeriodo = cntSaldoContPeriodo;
								BigDecimal xcndDifAdicional =cndDifAdicional;
								if ( seIndicaPorcAlcohol  ) {
									xcntSaldoContPeriodo =  xcntSaldoContPeriodo.multiply(factConv);
									xcntSaldoContPeriodo =  xcntSaldoContPeriodo.divide(factEquiv,3,BigDecimal.ROUND_HALF_UP);

									xcndDifAdicional =  xcndDifAdicional.multiply(factConv);
									xcndDifAdicional =  xcndDifAdicional.divide(factEquiv,3,BigDecimal.ROUND_HALF_UP);

								}
								// RSV se agrega para calcula el porcentaje de alcohol 
								if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo)) {
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08805","E", 
											new String[]{serie.getNumserie().toString(), String.valueOf( cntSaldoContPeriodo )   }));

								}


								//Cuando la serie no es nueva y se rectifica
								if ( !cambiGrupo  ) {
									 String mensaje2 = "";
								        if(blSerieNueva)
								        	mensaje2 = "LA SERIE "+serie.getNumserie()+" AGREGADA NO DEBE CONSIGNAR TIPO DE MARGEN 5";
								        else
								        	mensaje2 = "LA SERIE "+serie.getNumserie()+" NO DEBER� SER MODIFICADA. AGREGAR NUEVA SERIE CON "+xcndDifAdicional +" SIN CONSIGNAR TIPO DE MARGEN 5 ";

								        listError.add(ResponseMapManager.getErrorResponseMap("08805", mensaje2));
								        listError.add(((CatalogoAyudaService)fabricaDeServicios.
								        					getService("Ayuda.catalogoAyudaService")).
								        					getError("08804","E", new String[]{serie.getNumserie().toString(), serie.getCodconvinter().toString(), 
								        							serie.getCodpaisorige(), serie.getNumpartnandi().toString()}));
								}


							}
						}

			 */
		}

		//PAS20175E220200045 RSV PARA CONSIDERAR LOS SALDOS DE SERIES ANTERIORES
		BigDecimal cantSolContNuev = BigDecimal.ZERO;
		if(SunatNumberUtils.isGreaterThanZero(cndDifAdicional)){


			cantSolContNuev=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolAntSeries"));
			cantSolContNuev = cantSolContNuev.add(cndDifAdicional);

			mapCntSolAntSeries.put("cntSolAntSeries",cantSolContNuev);	
		}
		if(SunatNumberUtils.isLessThanZero(cndDifAdicional)){
			cantSolContNuev=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolDevSeries"));
			cantSolContNuev = cantSolContNuev.add(cndDifAdicional.abs());

			mapCntSolAntSeries.put("cntSolDevSeries",cantSolContNuev);	
		}
		//Indicador si se debe reservar aun si se ha agotado el saldo en una serie distinta a la primera serie.
		mapCntSolAntSeries.put("indSaldoAgoPriSer","0"); 


		return listError;
	}

	//Para este metodo se verifica cual de todos los casos cumple que tiene la cantidad solicitada para afectarlo.
	private List<Map<String, String>> validaSaldoRectifOficio(DatoSerie serie, Declaracion declaracion, 
			List<Map<String,Object>> listContRectifi, Map<String, Object> variablesIngreso , Map<String,Object>  mapDatosCont) {

		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		//BigDecimal cntSaldoContPeriodo = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
		List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		boolean noHaySaldo = true;
		BigDecimal cantSolCont = BigDecimal.ZERO;

		log.info(" validaSaldoRectifOficio listError 20 "+ listError );
		try {
			if (noHaySaldo ) {
				if( CollectionUtils.isEmpty(listContRectifi)){
					listContRectifi=contingentesUtil.listContingenteRecOficio(serie , declaracion);
				}
				log.info(" validaSaldoRectifOficio listError 21 "+ listError );
				if( !CollectionUtils.isEmpty(listContRectifi)){
					for (Map<String,Object> mapDatosContPeriodo  : listContRectifi) {
						BigDecimal cntSaldoContPerRecti = SunatNumberUtils.toBigDecimal(mapDatosContPeriodo.get("cntSaldoCont"));
						if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPerRecti)){
							listError = validaCamposContingente(serie, mapDatosContPeriodo, declaracion.getDua(), variablesIngreso,"");
							log.info(" validaSaldoRectifOficio listError 22 "+ listError );
							listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosContPeriodo);
							cantSolCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosContPeriodo, listValidPorAlcohol);
							if( SunatNumberUtils.isLessOrEqualsThanParam(cantSolCont,cntSaldoContPerRecti) ){
								noHaySaldo = false;
								// Se debe pones este dato en la lista de contingentes del cache y solo es cuando se acoge OJOJO
								List<Map<String, String>> listErrOtros = validaCamposContingente(serie, mapDatosContPeriodo, declaracion.getDua(), variablesIngreso,"");
								log.info(" validaSaldoRectifOficio listError 23 "+ listError );
								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									listError.addAll(listErrOtros );
									log.info(" validaSaldoRectifOficio listError 24 "+ listError );
								} 										
								break;
							}
						}
					}

				}
			}

			if( noHaySaldo ){
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35761","E", 
						new String[]{SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0'), serie.getCodconvinter().toString(), serie.getCodpaisorige()}));

				log.info(" validaSaldoRectifOficio listError 25 "+ listError );
			}

		} catch (Exception e)
		{
			e.printStackTrace();
			log.info(" validaSaldoRectifOficio listError 26 "+ e.getMessage() );
			log.debug(" validaSaldoRectifOficio listError 26 "+e.getMessage());
		}


		return listError;
	}	



	/*branch  ingreso 2011-029 diligencia despacho fin */
	//DZC ISC ini 
	public boolean EsPartidaLicores(String part_nandi,Date  Fdeclaracion, String regimen) {  
		boolean resultado=false;   
		boolean VigenciaLicores=false;  //Vigencia en CAT_REFPARTIDAS
		boolean tieneNandTasa998=false;  //Tiene nandtasa 998
		boolean VigenciaISC=PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000413", Fdeclaracion)>0;
		Integer fechaIngreso = SunatDateUtils.getIntegerFromDate(Fdeclaracion);

		Map<String,Object> paramsCatRef=new HashMap<String,Object>();
		paramsCatRef.put("tipo_uso", "LIC");
		paramsCatRef.put("cnan", part_nandi);
		paramsCatRef.put("fechaVigencia", new Integer(SunatDateUtils.getCurrentFormatDate("yyyyMMdd")));
		//         	CatRefPartidasDAO catrefpartidasDAO=FormatoAServiceImpl.getInstance().getCatrefpartidasDAO();
		//			int contCatRef=catrefpartidasDAO.count(paramsCatRef);			
		paramsCatRef.put("ayudaID", "CatRefpartidas");
		//			Integer contCatRef = (Integer)ayudaService.countCatRefParidas(paramsCatRef);
		Integer contCatRef = (Integer)((AyudaService)fabricaDeServicios.getService("Ayuda.ayudaService")).countCatRefParidas(paramsCatRef);

		if (contCatRef>0)VigenciaLicores=true;
		// vemos si esta vigente en el nandatasa para VISC = 998
		HashMap<String,Object> paramsNandtasaLic=new HashMap<String,Object>();
		//paramsNandtasaLic.put("tnan", tnan);
		paramsNandtasaLic.put("cnan", part_nandi);
		paramsNandtasaLic.put("finitas", fechaIngreso);
		paramsNandtasaLic.put("ffintas", fechaIngreso);
		paramsNandtasaLic.put("visc", 998);
		int contNandTasa998=((NandTasaDAO)fabricaDeServicios.getService("nandtasaDAO")).count2(paramsNandtasaLic); 
		if (contNandTasa998>0)tieneNandTasa998=true;

		if (regimen.equals("10") && VigenciaISC && VigenciaLicores && tieneNandTasa998)         
		{   // Si no declara TNAN
			resultado=true;
		}

		return resultado;
	}



	/*branch  ingreso 2011-029 diligencia despacho inicio */
	public List<Map<String, String>> procesarDiligencia(Declaracion declaracion, Map<String, Object> variablesIngreso ,  Integer nroErroresNegocio )
	{
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		List<Map<String, String>> listErrOtros = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> lstmapCntSolAntSeries = new ArrayList<Map<String, Object>>();
		List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();
		List<Map<String, String>> listErrorManif = new ArrayList<Map<String, String>>();
		List<Map<String, String>> listFechaLlegaManif = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> listJoinContingente =new ArrayList<Map<String, Object>>();
		try
		{
			/* olunar - 581 */
			boolean blSerieNueva = false;
			boolean blNuevoContingente = false;
			boolean blCambioGrupo=false;
			String codTransaccion = "";
			boolean blCambioTpiPartida=false;
			boolean isCampoInvalido = false;
			boolean isGarantizado = false;
			boolean garantiaEstaPagada = false;
			boolean isViaTransPostal = false;
			//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
			boolean estaPagada = false;
			boolean blAcogeNuevoCont = false;

			boolean blError35758 = false;
			boolean blError35759 = false;
			boolean blError35422 = false;
			boolean blError35421 = false;

			Map<String, Object> mapRespuesta = contingentesUtil.getListContingenteDeclaracion(declaracion, variablesIngreso);;
			List<Map<String, Object>> listContingenteDeclaracion = (List<Map<String, Object>>) mapRespuesta.get("listJoinContingente");
			listValidPorAlcohol=(List<Map<String, Object>>) mapRespuesta.get("listValidPorAlcohol");
			List<Map<String,Object>> listValidCampos=(List<Map<String, Object>>) mapRespuesta.get("listValidCampos");

			codTransaccion = variablesIngreso.get("codTransaccion") == null ? "": (String)variablesIngreso.get("codTransaccion");
			if ( codTransaccion.trim().length() == 0 )
				codTransaccion =  declaracion.getCodtipotrans() == null ? "": declaracion.getCodtipotrans();

			String numeroDocumentoIdentidadSender = (String)variablesIngreso.get("numeroDocumentoIdentidadSender"); //NUM RUC AGENTE

			Map<String, Object> operador = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperador(numeroDocumentoIdentidadSender, "41");
			String agente = (String)operador.get("cod_antadu");		

			List listConvenioSerie = new ArrayList();
			int codConvInter = 0; 
			int newCodConvInter = 0;
			String tipoMargen = "";
			boolean tieneIndicador16 = false;
			boolean tieneIndicador16BD = false;

			// modulo de contingentes activo	
			boolean gbcontingente = PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000022", new Date()).intValue() > 0;
			//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
			boolean isValidaContingenteRectificacion = contingentesUtil.validaContingenteRectif(declaracion, codTransaccion);
			if (gbcontingente) {
				List<DatoSerie> lstSeriesBd= contingentesUtil.getSeriesBD(declaracion.getNumeroCorrelativo());
				Map<String,Object> mapCntSolAntSeries = new HashMap<String,Object>();

				listFechaLlegaManif = contingentesUtil.validarFechaNumeracionFechaLlegada(declaracion);
				listErrorManif.addAll( listFechaLlegaManif );


				if(codTransaccion.endsWith(COD_TRX_REGULARIZA_URG)){
					// Si tiene garant�a
					isGarantizado = contingentesUtil.tieneGarantia160(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
					if( isGarantizado )
					{
						garantiaEstaPagada = !contingentesUtil.isNotEfectuadoPago(declaracion, "74");
					}
				}

				if (declaracion.getDua().getManifiesto().getCodmodtransp().equals(ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL)) {
					isViaTransPostal = true;	
				}

				tieneIndicador16 = tieneIndicador16 (declaracion);
				tieneIndicador16BD = tieneIndicador16BD(declaracion);
				//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
				estaPagada = !contingentesUtil.isNotEfectuadoPago(declaracion, "0");

				Map<Integer, ContCtaCte> cuentasCorrientesRecMap = null;
				//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA DILIGENCIA DE RECTIFICACI�N
				//	if ( codTransaccion.endsWith(COD_TRX_DILIG_RECTIF)  ) {
				cuentasCorrientesRecMap = contingentesUtil.getContCtaCteAllAsMap(declaracion.getDua().getListSeries(), declaracion);
				//}

				//glazaror... para evitar ejecutar un query para consultar cuenta corriente por cada serie... ejecutamos el siguiente metodo
				Map<Integer, ContCtaCte> cuentasCorrientesMap = contingentesUtil.getContCtaCteAllAsMap(lstSeriesBd, declaracion);

				//Por cada series de  la Dua Actual 
				for (DatoSerie serie : declaracion.getDua().getListSeries())
				{

					blSerieNueva = false;
					blNuevoContingente = false;
					blCambioGrupo=false;
					newCodConvInter = 0;
					isCampoInvalido = false;
					codConvInter = serie.getCodconvinter() == null ? 0:serie.getCodconvinter(); 
					tipoMargen = serie.getCodtipomarge() == null ? "":serie.getCodtipomarge();
					listValidPorAlcohol=new ArrayList<Map<String, Object>>();

					if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen )) {
						listError.addAll(listErrorManif);
						if( !CollectionUtils.isEmpty(listErrorManif))	 {
							nroErroresNegocio= nroErroresNegocio + 1;
						}				                  
					}
					/* fin */	

					// serie de Base de datos correspondiente
					DatoSerie serieOld = null;
					for(DatoSerie serieBD:lstSeriesBd){
						if (SunatNumberUtils.isEqual(serieBD.getNumserie(), serie.getNumserie())) {
							serieOld=serieBD;
							if ( !SunatNumberUtils.isEqual(serieOld.getCodconvinter(), serie.getCodconvinter()) ||
									!SunatNumberUtils.isEqual(serieOld.getNumpartnandi(), serie.getNumpartnandi())) {
								blCambioTpiPartida = true;
							}

							if ( tipoMargen.equals("5") && !serieOld.getCodtipomarge().trim().equals("5") ){
								blAcogeNuevoCont = true;
							}
							break;
						}
					}

					// datos de Cuenta Corriente de Contingencia para la serie
					Map<String, Object> mapDatosCont = new HashMap<String, Object>();
					mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
					mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
					mapDatosCont.put("codTipoDoc", "02");
					mapDatosCont.put("codEstado", "03");

					//glazaror... evitamos otro query adicional por serie
					//ContCtaCte serieCtaCte= contingentesUtil.getContCtaCte(mapDatosCont,serie,declaracion);

					//glazaror... obtenemos la cuenta corriente de la serie del map
					ContCtaCte serieCtaCte = cuentasCorrientesMap.get(serie.getNumserie());

					/* olunar 581 - Cuando la serie es nueva */
					if(serieOld==null)
					{
						for (DatoSerie serieAux : declaracion.getDua().getListSeries())
						{ // Tomando el contingente de la serie que tiene el mismo grupo de contingente
							if(serie.getCodpaisorige().equals(serieAux.getCodpaisorige()) && serie.getCodconvinter().intValue()==serieAux.getCodconvinter().intValue())
							{
								//glazaror... evitamos otro query adicional por serie
								//serieCtaCte= contingentesUtil.getContCtaCte(mapDatosCont,serieAux,declaracion);

								//glazaror... obtenemos la cuenta corriente de serieAux del map
								serieCtaCte = cuentasCorrientesMap.get(serieAux.getNumserie());
								if(serieCtaCte!=null)serieCtaCte.setNumSerieDoc(serie.getNumserie());
								break;  
							}
						}
						serieOld=new DatoSerie();
						serieOld.setCntunifis(new BigDecimal(0));
						serieOld.setCntpesoneto(new BigDecimal(0));
						serieOld.setMtofobdol(new BigDecimal(0));
						serieOld.setCodconvinter(serie.getCodconvinter());
						serieOld.setNumpartnandi(serie.getNumpartnandi());
						serieOld.setCodpaisorige(serie.getCodpaisorige());
						blSerieNueva=true;
					}
					/* fin */		

					variablesIngreso.put("blSerieNueva", blSerieNueva);

					//se valida si es una serie que ya esta con contingente
					boolean gbcontCtaCte = !(serieCtaCte==null);

					// Solo se verifica la transmisi�n
					//		          if (codTransaccion.equals("1008") || codTransaccion.equals("1006")) {
					if(codTransaccion.endsWith(COD_TRX_DILIG_REGU_GRA ) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_VAL)
							//inicio P21-P22
							|| codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL)
							|| codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL) ){
						//fin P21-P22
						if (!CollectionUtils.isEmpty((List) variablesIngreso.get("listConvenioSerie")))
						{
							List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) variablesIngreso.get("listConvenioSerie");
							for (int i = 0; i < lstConvenioSerie.size(); i++)
							{
								HashMap Convenio = (HashMap) lstConvenioSerie.get(i);


								if (Convenio.get("NUM_SECSERIE").toString().trim().equals(serie.getNumserie().toString().trim())) {
									if (Convenio.get("COD_TIPCONVENIO").toString().equals("I")) {
										if(!"1".equals((String)Convenio.get("IND_DEL"))){
											if(Convenio.get("COD_CONVENIO")!=null){
												newCodConvInter = Integer.parseInt( Convenio.get("COD_CONVENIO").toString().trim());
											}
										} else if("1".equals((String)Convenio.get("IND_DEL"))){
											// Se elimino la serie
											newCodConvInter = 0;
										}
									} 
								} /*else {
						    	// Se elimino la serie
						    	codConvInter = 0;
						    }*/
							}

							if ( newCodConvInter != codConvInter) {
								serie.setCodconvinter(newCodConvInter);	
							}
						} 
					}


					if ( tipoMargen.equals("5")){
						if (serie.getCodconvinter() == null || serie.getCodconvinter() == 0) {
							listError.add(ResponseMapManager.getErrorResponseMap("08801", "SERIE".concat(serie.getNumserie().toString()).concat(" PARA ACOGERSE A CONTINGENTE ARANCELARIO, DEBE ACOGERSE A UN TPI")));
							nroErroresNegocio= nroErroresNegocio + 1;
						}  

						if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen ) )
						{
							liberaReservaContingentes();
							String codtpi=SunatStringUtils.toStringObj(serie.getCodconvinter());
							if(codtpi.equals("812"))  {
								String codpais =serie.getCodpaisorige();
								String mensaje1 = "PARA ACOGERSE A TPI 812 CON CONTINGENTE ARANCELARIO EL PA�S ORIGEN DEBE SER DEL GRUPO DE PA�S UE";
								PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
								boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codtpi.toString(), codpais);
								if (existePuerto){
									serie.setCodpaisorige("UE");
								} else	{
									listError.add(ResponseMapManager.getErrorResponseMap("08801", mensaje1));
									nroErroresNegocio= nroErroresNegocio + 1;
								}
							}
						}
					}		          



					if (!gbcontCtaCte) {
						// si no esta afiliado a contingente y se quiere a acoger es un rechazo
						if ( tipoMargen.equals("5")){
							// Se valida si hay TPI y si hay contingente 
							// se obtiene el grupo de contingente al que pertenece la serie diligenciada
							//glazaror... optimizacion se consulta una sola vez data de contingentes en BD
							listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
							if(CollectionUtils.isEmpty(listJoinContingente)){ 

								if (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL) ) {
									listJoinContingente=contingentesUtil.listContingenteRecOficio(serie , declaracion);
									if(CollectionUtils.isEmpty(listJoinContingente)){   
										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35761","E", 
												new String[]{SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0'), serie.getCodconvinter().toString(), serie.getCodpaisorige()}));
										nroErroresNegocio= nroErroresNegocio + 1;
									} else {
										blNuevoContingente = true;
									}
								}  else {
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08801","E", new String[]{serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
									nroErroresNegocio= nroErroresNegocio + 1;
								}
							}  else {
								blNuevoContingente = true;  
							}
						}
					}    

					if( !CollectionUtils.isEmpty(listJoinContingente)) {
						mapDatosCont = listJoinContingente.get(0);
						///rtineo optimizacion se consulta una unica vez a la BD
						listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont, variablesIngreso, codTransaccion);
					} else {
						//glazaror... optimizacion se consulta una sola vez data de contingentes en BD
						listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
						if( !CollectionUtils.isEmpty(listJoinContingente)){ 
							mapDatosCont = listJoinContingente.get(0);
							//rtineo optimizacion se consulta una unica vez a la BD
							listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont, variablesIngreso,codTransaccion);
						}

					}
					// se valida si hay cambio en los datos relevantes para contingencia
					boolean datosRectificados = contingentesUtil.solicitaRectificarContingente( serie, serieOld , listValidPorAlcohol);

					if (datosRectificados || blNuevoContingente || blSerieNueva || blCambioGrupo) 
					{
						// if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), serie.getCodtipomarge() ) )
						if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen ) )
						{

							liberaReservaContingentes();
							// se obtiene el grupo de contingente al que pertenece la serie diligenciada
							//glazaror... optimizacion se consulta una sola vez data de contingentes en BD
							listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
							if(CollectionUtils.isEmpty(listJoinContingente)){   
								/* Si no se encuentra ning�n registro se grabar� el error :									 */
								//NSR: 18/05/2011 Se completa el numero de partida con ceros a la izquierda hasta 10 caracteres de longitud
								//listErr.add(catalogoHelper.getErrorMap("08801", new Object[]{serie.getCodconvinter(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
								if (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)) {
									listJoinContingente=contingentesUtil.listContingenteRecOficio(serie , declaracion);
									if(CollectionUtils.isEmpty(listJoinContingente)){   
										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35761","E", 
												new String[]{SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0'), serie.getCodconvinter().toString(), serie.getCodpaisorige()}));
										nroErroresNegocio= nroErroresNegocio + 1;
									} 
								}  else {
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08801","E", new String[]{serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
									nroErroresNegocio= nroErroresNegocio + 1;
								}
							}else{
								mapDatosCont = listJoinContingente.get(0);
								if( CollectionUtils.isEmpty(listValidPorAlcohol)){
									//rtineo optimizacion se consulta una unica vez a la BD
									listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont, variablesIngreso,codTransaccion);  
								}


								// Se verifica que se quier acoger a contingente 
								//Incorpora contingente (TPI y TM5) mediante la transmisi�n de la regularizaci�n siempre y cuando la mercanc�a haya arribado (como se indica en RF1)
								//y no se haya efectuado el pago y verifica si tiene garantia
								// Solo se verifica la transmisi�n
								if(codTransaccion.endsWith(COD_TRX_REGULARIZA_URG)){
									//String codGarantia = declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
									if (serieCtaCte==null) {
										// Si tiene garant�a
										if(! isGarantizado )
										{
											listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08807","E", 
													new String[]{serie.getNumserie().toString(),serie.getCodconvinter().toString(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
											nroErroresNegocio= nroErroresNegocio + 1;
										} else {

											// Se valida si la garant�a se pago
											//if (contingentesUtil.isEfectuadoPago(declaracion, "74")){
											if ( garantiaEstaPagada){
												listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08807","E", 
														new String[]{serie.getNumserie().toString(),serie.getCodconvinter().toString(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
												nroErroresNegocio= nroErroresNegocio + 1;
											} else {
												if( !CollectionUtils.isEmpty(listFechaLlegaManif))	 {
													nroErroresNegocio= nroErroresNegocio + 1;
													listError.addAll(listFechaLlegaManif );
												}
											}
										}

									}
								}

								if (serieCtaCte != null) {
									if(!SunatStringUtils.isEqualTo(serieCtaCte.getNumGrupoCont().toString(),SunatStringUtils.toStringObj(mapDatosCont.get("numGrupoCont")))
											|| !SunatStringUtils.isEqualTo(serieCtaCte.getCodPaisOrigen(),SunatStringUtils.toStringObj(mapDatosCont.get("codPaisOrigen")) )
											|| !SunatStringUtils.isEqualTo(serieCtaCte.getCodTpi(), SunatStringUtils.toStringObj(mapDatosCont.get("codTpi")) )
											//|| !SunatNumberUtils.isEqual(serie.getNumpartnandi(), serieOld.getNumpartnandi()) //olunar - 581 
											){
										blCambioGrupo=true;
									}
								} else 
									blCambioGrupo=true;


								//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
								if (isValidaContingenteRectificacion && blNuevoContingente ) {

									if (!tieneIndicador16 && estaPagada  ) {
										//35758 PARA ACOGERSE A CONTINGENTE DESPU�S DEL PAGO DE TRIBUTOS DEBER� CONSIGNAR EL INDICADOR 16
										blError35758 = true;
										//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35758"));
										nroErroresNegocio= nroErroresNegocio + 1;
									}
									if (tieneIndicador16 && !estaPagada) {
										//35759 LA DECLARACI�N NO SE ENCUENTRA CANCELADA. NO DEBE ENVIAR EL INDICADOR 16
										//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35759"));
										blError35759 = true;
										nroErroresNegocio= nroErroresNegocio + 1;
									}
								} 
								//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS

								listErrOtros =this.validarVigenciaContingente(serie , declaracion, variablesIngreso);
								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									nroErroresNegocio= nroErroresNegocio + 1;
									listError.addAll(listErrOtros );
								}

								if ( tipoMargen.equals("5") && isViaTransPostal) {
									blError35421 = true;
									nroErroresNegocio= nroErroresNegocio + 1;
								}
								listErrOtros = validaCamposContingente(serie, mapDatosCont, declaracion.getDua(), variablesIngreso,codTransaccion);

								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									nroErroresNegocio= nroErroresNegocio + 1;
									listError.addAll(listErrOtros );
									isCampoInvalido = true;
								} 
								// Se agrega cuando sucede rectificaciones en las unidades ya que tambien cambian 
								if (contingentesUtil.isRectificaCantContingentes(serie, serieOld, mapDatosCont, listValidPorAlcohol) || blSerieNueva || blCambioGrupo || blNuevoContingente || datosRectificados) 
								{

									if ( blCambioGrupo || blNuevoContingente) {
										blSerieNueva = true;
									}
									liberaReservaContingentes();

									BigDecimal cntContingente = new BigDecimal(0);
									BigDecimal cntSolicCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);
									BigDecimal cndDifAdicional=new BigDecimal(0);
									BigDecimal cntSaldoContPeriodo = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));

									if (blCambioGrupo || blNuevoContingente || blSerieNueva ) {
										cndDifAdicional = cntSolicCont;
									} else {
										cntContingente = contingentesUtil.getRectificaCantContingentes(serie, serieOld, mapDatosCont);
										if(SunatNumberUtils.isGreaterOrEqualsThanZero(cntContingente)){
											cndDifAdicional=SunatNumberUtils.diference(cntSolicCont, cntContingente);
										} else {
											// No hubo cambios solo se cambio la partida
											if (blCambioTpiPartida) {
												cndDifAdicional = new BigDecimal( -1);
											}
										}

									}

									if(codTransaccion.endsWith(COD_TRX_REGULARIZA_URG) || codTransaccion.endsWith(COD_TRX_RECTIFICACION) ){
										if ( blNuevoContingente || blSerieNueva ) {
											cntSaldoContPeriodo = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
											if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo))
											{
												if ( !isCampoInvalido) {
													listError.addAll( validaSaldoContingenteNoNumeracion(serie, serieOld, mapDatosCont, declaracion,mapCntSolAntSeries, blSerieNueva,  listValidPorAlcohol , cuentasCorrientesRecMap, codTransaccion) );	
												}
											}else{
												// No hay saldo en el periodo
												if ( !isCampoInvalido) {
													mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
													mapDatosCont.put("annDoc",declaracion.getNumdeclRef().getAnnprese());
													mapDatosCont.put("agente",agente);

													// Se verifica si existe devoluci�n de contingente en esta orden Se debe verificar para cambio de contingente
													BigDecimal cntCantDevAntSeries=SunatNumberUtils.toBigDecimal(mapCntSolAntSeries.get("cntSolDevSeries"));
													if ( SunatNumberUtils.isLessThanParam(cntCantDevAntSeries, cntSolicCont) ||  SunatNumberUtils.isEqualToZero(cntCantDevAntSeries) ) {
														listError.addAll( validaExistenciaReserva(serie, mapDatosCont, declaracion, listValidPorAlcohol) );
													}
												}
											}
										}else {
											//															if(SunatNumberUtils.isGreaterOrEqualsThanZero(cndDifAdicional)){
											listError.addAll( validaSaldoContingenteNoNumeracion(serie,serieOld, mapDatosCont, declaracion, mapCntSolAntSeries, blSerieNueva  , listValidPorAlcohol , cuentasCorrientesRecMap, codTransaccion) );
											//													     }
										}

									} else  {

										/*if(codTransaccion.endsWith(COD_TRX_RECTIFICACION)){
															 if ( blNuevoContingente || blSerieNueva ) {
																	cntSaldoContPeriodo = SunatNumberUtils.toBigDecimal(mapDatosCont.get("cntSaldoCont"));
																	if(SunatNumberUtils.isGreaterThanZero(cntSaldoContPeriodo))
																	{
																		if ( !isCampoInvalido) {
																		  listError.addAll( validaSaldoContingenteNoNumeracion(serie, serieOld, mapDatosCont, declaracion,mapCntSolAntSeries, blSerieNueva,  listValidPorAlcohol , cuentasCorrientesRecMap, codTransaccion) );	
																		}
																	}else{
																		if ( !isCampoInvalido) {
																			mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
																			mapDatosCont.put("annDoc",declaracion.getNumdeclRef().getAnnprese());
																			mapDatosCont.put("agente",agente);
																			listError.addAll( validaExistenciaReserva(serie, mapDatosCont, declaracion, listValidPorAlcohol) );
																		}
																	}
															 }
															 if( cndDifAdicional.compareTo(new BigDecimal(0)) < 0 ){
																 if( SunatNumberUtils.isEqualToZero(cntSaldoContPeriodo))
																	{ 
																		mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
																		mapDatosCont.put("annDoc",declaracion.getNumdeclRef().getAnnprese());
																		mapDatosCont.put("agente",agente);
																		listError.addAll( validaExistenciaReserva(serie, mapDatosCont, declaracion, listValidPorAlcohol) );
																	} 
															 }
														 }
										 */
										//Se considera cuando es nuevo contingente
										if( blNuevoContingente && (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA ) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)) ) {
											listError.addAll( validaSaldoRectifOficio(serie, declaracion,   listJoinContingente, variablesIngreso , mapDatosCont) );
										} else {
											listError.addAll( validaSaldoContingenteNoNumeracion(serie,serieOld, mapDatosCont, declaracion, mapCntSolAntSeries, blSerieNueva,   listValidPorAlcohol , cuentasCorrientesRecMap,codTransaccion) );
										}

									}

								} 								
							}

						} /*else {
				        	  // Aqui se debe verificar si se retira contingente y no ahora no es ...... 
				        	  // se debe liberar contingente pero eso en la grabaci�n
				          }*/
					}

					if(codTransaccion.endsWith(COD_TRX_DILIG_REGU_GRA ) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_VAL)
							//inicio P21-P22
							|| codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL)
							|| codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)){
						//fin P21-P22		        		  
						if (!CollectionUtils.isEmpty((List) variablesIngreso.get("listConvenioSerie")))
						{
							if (  SunatNumberUtils.isEqual(newCodConvInter, codConvInter)) {
								serie.setCodconvinter(codConvInter);	
							}

						} 


					}
				}
				//Se muestra el error por declaraci�n de los siguientes errores de numeraci�n
				if (blError35758) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35758"));
					nroErroresNegocio= nroErroresNegocio + 1;
				}
				if (blError35759) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35759"));
					nroErroresNegocio= nroErroresNegocio + 1;
				}


				if ( isValidaContingenteRectificacion && tieneIndicador16 &&  !blAcogeNuevoCont && !estaPagada ) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35422"));
					nroErroresNegocio= nroErroresNegocio + 1;
				} else {
					if ( !isValidaContingenteRectificacion && tieneIndicador16  ) {
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35422"));
						nroErroresNegocio= nroErroresNegocio + 1;
					}
				}



				if (blError35421) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35421"));
					nroErroresNegocio= nroErroresNegocio + 1;
				}




			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			log.error("Error en contingente***",e);
			String message = "OCURRIO UN ERROR GRAVE";
			listError.add(ResponseMapManager.getErrorResponseMap("08807", message));
		}

		if(nroErroresNegocio == 0 && contingentesUtil.is8805UnicoError(listError, 0L)  ){
			variablesIngreso.put("is8805UnicoError", Boolean.TRUE);
			variablesIngreso.put("nroErrores", nroErroresNegocio);
		}


		return listError;
	}


	/*branch  ingreso 2011-029 diligencia despacho inicio */
	//PAS20165E220200076 - rserranov 20161014 - Se crea m�todo en atenci�n a bug M_SNADE280-1154
	public List<Map<String, String>> procesarDilRectif(Declaracion declaracion, Map<String, Object> variablesIngreso ,  Integer nroErroresNegocio ) {
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		List<Map<String, String>> listErrOtros = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> lstmapCntSolAntSeries = new ArrayList<Map<String, Object>>();
		List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();
		List<Map<String, String>> listErrorManif = new ArrayList<Map<String, String>>();
		List<Map<String, String>> listFechaLlegaManif = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> listJoinContingente =new ArrayList<Map<String, Object>>();
		try {
			boolean blSerieNueva = false;
			boolean blNuevoContingente = false;
			boolean blCambioGrupo=false;
			String codTransaccion = "";
			boolean blCambioTpiPartida=false;
			boolean isCampoInvalido = false;
			boolean isGarantizado = false;
			boolean garantiaEstaPagada = false;
			boolean isViaTransPostal = false;
			//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
			boolean estaPagada = false;
			boolean blAcogeNuevoCont = false;

			boolean blError35758 = false;
			boolean blError35759 = false;
			boolean blError35422 = false;
			boolean blError35421 = false;

			Map<String, Object> mapRespuesta = contingentesUtil.getListContingenteDeclaracion(declaracion, variablesIngreso);;
			List<Map<String, Object>> listContingenteDeclaracion = (List<Map<String, Object>>) mapRespuesta.get("listJoinContingente");
			listValidPorAlcohol=(List<Map<String, Object>>) mapRespuesta.get("listValidPorAlcohol");
			List<Map<String,Object>> listValidCampos=(List<Map<String, Object>>) mapRespuesta.get("listValidCampos");

			codTransaccion = variablesIngreso.get("codTransaccion") == null ? "": (String)variablesIngreso.get("codTransaccion");
			if ( codTransaccion.trim().length() == 0 )  codTransaccion =  declaracion.getCodtipotrans() == null ? "": declaracion.getCodtipotrans();

			String numeroDocumentoIdentidadSender = (String)variablesIngreso.get("numeroDocumentoIdentidadSender"); //NUM RUC AGENTE

			Map<String, Object> operador = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperador(numeroDocumentoIdentidadSender, "41");
			String agente = (String)operador.get("cod_antadu");		

			List listConvenioSerie = new ArrayList();
			int codConvInter = 0; 
			int newCodConvInter = 0;
			String tipoMargen = "";
			boolean tieneIndicador16 = false;

			// modulo de contingentes activo	
			boolean gbcontingente = PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000022", new Date()).intValue() > 0;
			//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
			boolean isValidaContingenteRectificacion = contingentesUtil.validaContingenteRectif(declaracion, codTransaccion);

			if (gbcontingente) {
				List<DatoSerie> lstSeriesBd= contingentesUtil.getSeriesBD(declaracion.getNumeroCorrelativo());
				Map<String,Object> mapCntSolAntSeries = new HashMap<String,Object>();

				listFechaLlegaManif = contingentesUtil.validarFechaNumeracionFechaLlegada(declaracion);
				listErrorManif.addAll( listFechaLlegaManif );

				if(codTransaccion.endsWith(COD_TRX_REGULARIZA_URG)){
					// Si tiene garant�a
					isGarantizado = contingentesUtil.tieneGarantia160(declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia());
					if( isGarantizado ) garantiaEstaPagada = !contingentesUtil.isNotEfectuadoPago(declaracion, "74");
				}

				isViaTransPostal = (declaracion.getDua().getManifiesto().getCodmodtransp().equals(ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL)) ? true : false;

				tieneIndicador16 = tieneIndicador16 (declaracion);
				//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
				estaPagada = !contingentesUtil.isNotEfectuadoPago(declaracion, "0");

				Map<Integer, ContCtaCte> cuentasCorrientesRecMap = null;
				//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA DILIGENCIA DE RECTIFICACI�N
				cuentasCorrientesRecMap = contingentesUtil.getContCtaCteAllAsMap(declaracion.getDua().getListSeries(), declaracion);

				//glazaror... para evitar ejecutar un query para consultar cuenta corriente por cada serie... ejecutamos el siguiente metodo
				Map<Integer, ContCtaCte> cuentasCorrientesMap = contingentesUtil.getContCtaCteAllAsMap(lstSeriesBd, declaracion);

				//Por cada series de  la Dua Actual 
				for (DatoSerie serie : declaracion.getDua().getListSeries()) {

					blSerieNueva = false;
					blNuevoContingente = false;
					blCambioGrupo=false;
					newCodConvInter = 0;
					isCampoInvalido = false;
					codConvInter = serie.getCodconvinter() == null ? 0:serie.getCodconvinter(); 
					tipoMargen = serie.getCodtipomarge() == null ? "":serie.getCodtipomarge();
					listValidPorAlcohol=new ArrayList<Map<String, Object>>();

					if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen )) {
						listError.addAll(listErrorManif);
						if( !CollectionUtils.isEmpty(listErrorManif)) nroErroresNegocio= nroErroresNegocio + 1;
					}
					/* fin */	

					// serie de Base de datos correspondiente
					DatoSerie serieOld = null;
					for(DatoSerie serieBD:lstSeriesBd){
						if (SunatNumberUtils.isEqual(serieBD.getNumserie(), serie.getNumserie())) {
							serieOld=serieBD;
							blCambioTpiPartida = !SunatNumberUtils.isEqual(serieOld.getCodconvinter(), serie.getCodconvinter()) || !SunatNumberUtils.isEqual(serieOld.getNumpartnandi(), serie.getNumpartnandi()) ? true : false;
							blAcogeNuevoCont = tipoMargen.equals("5") && !serieOld.getCodtipomarge().trim().equals("5") ? true : false; 
						}
						break;
					}

					// datos de Cuenta Corriente de Contingencia para la serie
					Map<String, Object> mapDatosCont = new HashMap<String, Object>();
					mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
					mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
					mapDatosCont.put("codTipoDoc", "02");
					mapDatosCont.put("codEstado", "03");

					//glazaror... obtenemos la cuenta corriente de la serie del map
					ContCtaCte serieCtaCte = cuentasCorrientesMap.get(serie.getNumserie());

					if(serieOld==null) {
						for (DatoSerie serieAux : declaracion.getDua().getListSeries()) { // Tomando el contingente de la serie que tiene el mismo grupo de contingente
							if(serie.getCodpaisorige().equals(serieAux.getCodpaisorige()) && serie.getCodconvinter().intValue()==serieAux.getCodconvinter().intValue()) {
								serieCtaCte = cuentasCorrientesMap.get(serieAux.getNumserie());
								if(serieCtaCte!=null) serieCtaCte.setNumSerieDoc(serie.getNumserie());
								break;  
							}
						}
						serieOld=new DatoSerie();
						serieOld.setCntunifis(new BigDecimal(0));
						serieOld.setCntpesoneto(new BigDecimal(0));
						serieOld.setMtofobdol(new BigDecimal(0));
						serieOld.setCodconvinter(serie.getCodconvinter());
						serieOld.setNumpartnandi(serie.getNumpartnandi());
						serieOld.setCodpaisorige(serie.getCodpaisorige());
						blSerieNueva=true;
					}
					/* fin */		

					variablesIngreso.put("blSerieNueva", blSerieNueva);

					//se valida si es una serie que ya esta con contingente
					boolean gbcontCtaCte = !(serieCtaCte==null);

					// Solo se verifica la transmisi�n
					if( codTransaccion.endsWith(COD_TRX_DILIG_REGU_GRA ) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_VAL) ||
							codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) ||
							codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL) ){

						if (!CollectionUtils.isEmpty((List) variablesIngreso.get("listConvenioSerie"))) {
							List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) variablesIngreso.get("listConvenioSerie");
							for (int i = 0; i < lstConvenioSerie.size(); i++) {
								HashMap Convenio = (HashMap) lstConvenioSerie.get(i);
								if (Convenio.get("NUM_SECSERIE").toString().trim().equals(serie.getNumserie().toString().trim())) {
									if (Convenio.get("COD_TIPCONVENIO").toString().equals("I")) {
										if(!"1".equals((String)Convenio.get("IND_DEL"))){
											if(Convenio.get("COD_CONVENIO")!=null){
												newCodConvInter = Integer.parseInt( Convenio.get("COD_CONVENIO").toString().trim());
											}
										} else if("1".equals((String)Convenio.get("IND_DEL"))) {
											newCodConvInter = 0;
										}
									} 
								}
							}//Final for

							if ( newCodConvInter != codConvInter)  
								serie.setCodconvinter(newCodConvInter);	
						} 
					}


					if ( tipoMargen.equals("5")){
						if (serie.getCodconvinter() == null || serie.getCodconvinter() == 0) {
							listError.add(ResponseMapManager.getErrorResponseMap("08801", "SERIE".concat(serie.getNumserie().toString()).concat(" PARA ACOGERSE A CONTINGENTE ARANCELARIO, DEBE ACOGERSE A UN TPI")));
							nroErroresNegocio= nroErroresNegocio + 1;
						}  

						if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen ) ) {
							liberaReservaContingentes();
							String codtpi=SunatStringUtils.toStringObj(serie.getCodconvinter());
							if(codtpi.equals("812"))  {
								String codpais =serie.getCodpaisorige();
								String mensaje1 = "PARA ACOGERSE A TPI 812 CON CONTINGENTE ARANCELARIO EL PA�S ORIGEN DEBE SER DEL GRUPO DE PA�S UE";
								PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
								boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codtpi.toString(), codpais);
								if (existePuerto){
									serie.setCodpaisorige("UE");
								} else	{
									listError.add(ResponseMapManager.getErrorResponseMap("08801", mensaje1));
									nroErroresNegocio= nroErroresNegocio + 1;
								}
							}
						}
					}		          

					if (!gbcontCtaCte) {
						// si no esta afiliado a contingente y se quiere a acoger es un rechazo
						if ( tipoMargen.equals("5")){
							// Se valida si hay TPI y si hay contingente. Se obtiene el grupo de contingente al que pertenece la serie diligenciada
							//glazaror... optimizacion se consulta una sola vez data de contingentes en BD
							listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
							if(CollectionUtils.isEmpty(listJoinContingente)){ 
								if (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL) ) {
									listJoinContingente=contingentesUtil.listContingenteRecOficio(serie , declaracion);
									if(CollectionUtils.isEmpty(listJoinContingente)){   
										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35761","E", 
												new String[]{SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0'), serie.getCodconvinter().toString(), serie.getCodpaisorige()}));
										nroErroresNegocio= nroErroresNegocio + 1;
									} else {
										blNuevoContingente = true;
									}
								}  else {
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08801","E", new String[]{ 
											serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
									nroErroresNegocio= nroErroresNegocio + 1;
								}
							}  else {
								blNuevoContingente = true;  
							}
						}
					}    

					if( !CollectionUtils.isEmpty(listJoinContingente)) {
						mapDatosCont = listJoinContingente.get(0);
						//rtineo optimizacion se consulta una unica vez a la BD
						listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont, variablesIngreso, codTransaccion);
					} else {
						//glazaror... optimizacion se consulta una sola vez data de contingentes en BD
						listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
						if( !CollectionUtils.isEmpty(listJoinContingente)){ 
							mapDatosCont = listJoinContingente.get(0);
							//rtineo optimizacion se consulta una unica vez a la BD
							listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont, variablesIngreso,codTransaccion);
						}
					}
					// se valida si hay cambio en los datos relevantes para contingencia
					boolean datosRectificados = contingentesUtil.solicitaRectificarContingente( serie, serieOld , listValidPorAlcohol);
					if (datosRectificados || blNuevoContingente || blSerieNueva || blCambioGrupo)  {
						// if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), serie.getCodtipomarge() ) )
						if ( contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen ) ) {
							liberaReservaContingentes();
							// se obtiene el grupo de contingente al que pertenece la serie diligenciada
							//glazaror... optimizacion se consulta una sola vez data de contingentes en BD
							listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
							if(CollectionUtils.isEmpty(listJoinContingente)){   
								/* Si no se encuentra ning�n registro se grabar� el error :									 */
								//NSR: 18/05/2011 Se completa el numero de partida con ceros a la izquierda hasta 10 caracteres de longitud
								//listErr.add(catalogoHelper.getErrorMap("08801", new Object[]{serie.getCodconvinter(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
								if (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)) {
									listJoinContingente=contingentesUtil.listContingenteRecOficio(serie , declaracion);
									if(CollectionUtils.isEmpty(listJoinContingente)){   
										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35761","E", 
												new String[]{SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0'), serie.getCodconvinter().toString(), serie.getCodpaisorige()}));
										nroErroresNegocio= nroErroresNegocio + 1;
									} 
								}  else {
									listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08801","E", new String[]{serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
									nroErroresNegocio= nroErroresNegocio + 1;
								}
							}else{
								mapDatosCont = listJoinContingente.get(0);
								if( CollectionUtils.isEmpty(listValidPorAlcohol)){
									//rtineo optimizacion se consulta una unica vez a la BD
									listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont, variablesIngreso,codTransaccion);  
								}

								// Se verifica que se quier acoger a contingente 
								//Incorpora contingente (TPI y TM5) mediante la transmisi�n de la regularizaci�n siempre y cuando la mercanc�a haya arribado (como se indica en RF1)
								//y no se haya efectuado el pago y verifica si tiene garantia
								// Solo se verifica la transmisi�n
								if(codTransaccion.endsWith(COD_TRX_REGULARIZA_URG)){
									//String codGarantia = declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia();
									if (serieCtaCte==null) {
										// Si tiene garant�a
										if(! isGarantizado ) {
											listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08807","E", 
													new String[]{serie.getNumserie().toString(),serie.getCodconvinter().toString(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
											nroErroresNegocio= nroErroresNegocio + 1;
										} else {
											// Se valida si la garant�a se pago
											//if (contingentesUtil.isEfectuadoPago(declaracion, "74")){
											if ( garantiaEstaPagada){
												listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08807","E", 
														new String[]{serie.getNumserie().toString(),serie.getCodconvinter().toString(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
												nroErroresNegocio= nroErroresNegocio + 1;
											} else {
												if( !CollectionUtils.isEmpty(listFechaLlegaManif))	 {
													nroErroresNegocio= nroErroresNegocio + 1;
													listError.addAll(listFechaLlegaManif );
												}
											}
										}
									}
								}

								if (serieCtaCte != null) {
									if(!SunatStringUtils.isEqualTo(serieCtaCte.getNumGrupoCont().toString(),SunatStringUtils.toStringObj(mapDatosCont.get("numGrupoCont"))) ||
											!SunatStringUtils.isEqualTo(serieCtaCte.getCodPaisOrigen(),SunatStringUtils.toStringObj(mapDatosCont.get("codPaisOrigen")) ) ||
											!SunatStringUtils.isEqualTo(serieCtaCte.getCodTpi(), SunatStringUtils.toStringObj(mapDatosCont.get("codTpi"))) ) {
										blCambioGrupo=true;
									}
								} else blCambioGrupo=true;


								//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
								if (isValidaContingenteRectificacion && blNuevoContingente ) {
									if (!tieneIndicador16 && estaPagada  ) {
										//35758 PARA ACOGERSE A CONTINGENTE DESPU�S DEL PAGO DE TRIBUTOS DEBER� CONSIGNAR EL INDICADOR 16
										blError35758 = true;
										//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35758"));
										nroErroresNegocio= nroErroresNegocio + 1;
									}
									if (tieneIndicador16 && !estaPagada) {
										//35759 LA DECLARACI�N NO SE ENCUENTRA CANCELADA. NO DEBE ENVIAR EL INDICADOR 16
										//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35759"));
										blError35759 = true;
										nroErroresNegocio= nroErroresNegocio + 1;
									}
								} else {
									//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA DILIGENCIA DE RECTIFICACI�N
									if ( !codTransaccion.endsWith(COD_TRX_DILIG_RECTIF)  ) {
										if ( tieneIndicador16 ) {
											//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35422"));
											blError35422 = true;
											nroErroresNegocio= nroErroresNegocio + 1;
										}
									}
								}
								//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
								listErrOtros =this.validarVigenciaContingente(serie , declaracion, variablesIngreso);
								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									nroErroresNegocio= nroErroresNegocio + 1;
									listError.addAll(listErrOtros );
								}
								if ( tipoMargen.equals("5") && isViaTransPostal) {
									blError35421 = true;
									nroErroresNegocio= nroErroresNegocio + 1;
								}
								listErrOtros = validaCamposContingente(serie, mapDatosCont, declaracion.getDua(), variablesIngreso,codTransaccion);
								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									nroErroresNegocio= nroErroresNegocio + 1;
									listError.addAll(listErrOtros );
									isCampoInvalido = true;
								} 
								// Se agrega cuando sucede rectificaciones en las unidades ya que tambien cambian 
								liberaReservaContingentes();
							}								
						}
					} 
					if( codTransaccion.endsWith(COD_TRX_DILIG_REGU_GRA ) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_VAL) ||
							codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) ||
							codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)) {
						if (!CollectionUtils.isEmpty((List) variablesIngreso.get("listConvenioSerie"))) {
							if (  SunatNumberUtils.isEqual(newCodConvInter, codConvInter)) serie.setCodconvinter(codConvInter);	
						} 
					}
				}  //Final FOR
			}
			//Se muestra el error por declaraci�n de los siguientes errores de numeraci�n
			if (blError35758 ||  !tieneIndicador16 && blAcogeNuevoCont && estaPagada && codTransaccion.endsWith(COD_TRX_DILIG_RECTIF)) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35758"));
				nroErroresNegocio= nroErroresNegocio + 1;
			}
			if (blError35759) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35759"));
				nroErroresNegocio= nroErroresNegocio + 1;
			}
			// Se verifica que acepto todo
			if (blError35422 || tieneIndicador16 && !blAcogeNuevoCont && !estaPagada ) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35422"));
				nroErroresNegocio= nroErroresNegocio + 1;
			}
			if (blError35421) {
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35421"));
				nroErroresNegocio= nroErroresNegocio + 1;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			log.error("Error en contingente***",e);
			String message = "OCURRIO UN ERROR GRAVE";
			listError.add(ResponseMapManager.getErrorResponseMap("08807", message));
		}

		if(nroErroresNegocio == 0 && contingentesUtil.is8805UnicoError(listError, 0L)  ) {
			variablesIngreso.put("is8805UnicoError", Boolean.TRUE);
			variablesIngreso.put("nroErrores", nroErroresNegocio);
		}

		return listError;
	}




	/*branch  ingreso 2011-029 diligencia despacho inicio */
	/**
	 * Verifica si debe validar bajo el nuevo esquema de TLCs.
	 * @param serie
	 * @param variablesIngreso
	 */

	@ServicioAnnot(tipo="V",codServicio=3474, descServicio="validacion de Contingenntes")
	@ServInstDetAnnot(tipoRpta={1,1,1},nomAtr={"declaracion","variablesIngreso","nroErroresNegocio"})
	@OrquestaDespaAnnot(codServInstancia=3474,numSecEjec=500,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.contingentes")	
	public List<Map<String, String>> procesarRectiOficio(Declaracion declaracion, Map<String, Object> variablesIngreso ,  Integer nroErroresNegocio )
	{
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		List<Map<String, String>> listErrOtros = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> lstmapCntSolAntSeries = new ArrayList<Map<String, Object>>();
		//   List<Map<String,Object>> listValidPorAlcohol=new ArrayList<Map<String, Object>>();
		List<Map<String, String>> listErrorManif = new ArrayList<Map<String, String>>();
		List<Map<String, String>> listFechaLlegaManif = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> listJoinContingente =new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> listContRectifi =new ArrayList<Map<String, Object>>();
		Integer nroErroresContingente = 0;
		try
		{
			// boolean isValidaManifiesto = true;	    	
			boolean blSerieNueva = false;
			boolean blNuevoContingente = false;
			boolean blCambioGrupo=false;
			String codTransaccion = "";
			boolean blCambioTpiPartida=false;
			boolean isCampoInvalido = false;
			boolean isGarantizado = false;
			boolean garantiaEstaPagada = false;
			boolean isViaTransPostal = false;
			boolean estaPagada = false;
			boolean blSolicitCont = false;
			int codConvInter = 0; 
			int newCodConvInter = 0;
			String tipoMargen = "";
			String oldTipoMargen = "";
			boolean tieneIndicador16 = false;
			boolean blError35758 = false;
			boolean blError35759 = false;
			boolean blError35422 = false;
			boolean blError35421 = false;

			log.info(" procesarRectiOficio ");
			log.debug(" procesarRectiOficio ");


			codTransaccion = variablesIngreso.get("codTransaccion") == null ? "": (String)variablesIngreso.get("codTransaccion");
			if ( codTransaccion.trim().length() == 0 )
				codTransaccion =  declaracion.getCodtipotrans() == null ? "": declaracion.getCodtipotrans();

			String numeroDocumentoIdentidadSender = (String)variablesIngreso.get("numeroDocumentoIdentidadSender"); 
			Map<String, Object> operador = ((OperadorAyudaService)fabricaDeServicios.getService("Ayuda.operadorAyudaService")).getOperador(numeroDocumentoIdentidadSender, "41");
			String agente = (String)operador.get("cod_antadu");		


			// modulo de contingentes activo	
			boolean gbcontingente = PackageGeneral.getVigenciaCambio("983", "10", "TD000", "000022", new Date()).intValue() > 0;
			//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
			boolean isValidaContingenteRectificacion = contingentesUtil.validaContingenteRectif(declaracion, codTransaccion);

			if (gbcontingente) {
				List<DatoSerie> lstSeriesBd= contingentesUtil.getSeriesBD(declaracion.getNumeroCorrelativo());
				Map<String,Object> mapCntSolAntSeries = new HashMap<String,Object>();

				// Para no buscar por cada serie
				/*if( isValidaManifiesto && Constants.DESPACHO_URGENTE.equals(declaracion.getDua().getCodmodalidad())){
        		listErrorManif.addAll(contingentesUtil.validarManifiestoDilig(declaracion, "03"));
            }
				 */
				listFechaLlegaManif = contingentesUtil.validarFechaNumeracionFechaLlegada(declaracion);
				listErrorManif.addAll( listFechaLlegaManif );

				if (declaracion.getDua().getManifiesto().getCodmodtransp().equals(ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL)) {
					isViaTransPostal = true;	
				}

				tieneIndicador16 = tieneIndicador16 (declaracion);
				//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
				estaPagada = !contingentesUtil.isNotEfectuadoPago(declaracion, "0");

				//glazaror... para evitar ejecutar un query para consultar cuenta corriente por cada serie... ejecutamos el siguiente metodo
				Map<Integer, ContCtaCte> cuentasCorrientesMap = contingentesUtil.getContCtaCteAllAsMap(lstSeriesBd , declaracion);

				Map<Integer, ContCtaCte> cuentasCorrientesRecMap = null;
				Map<String, Object> mapRespuesta = contingentesUtil.getListContingenteDeclaracion(declaracion, variablesIngreso);;
				List<Map<String, Object>> listContingenteDeclaracion = (List<Map<String, Object>>) mapRespuesta.get("listJoinContingente");
				List<Map<String,Object>> listValidPorAlcohol=(List<Map<String, Object>>) mapRespuesta.get("listValidPorAlcohol");
				List<Map<String,Object>> listValidCampos=(List<Map<String, Object>>) mapRespuesta.get("listValidCampos");

				//Por cada series de  la Dua Actual 
				for (DatoSerie serie : declaracion.getDua().getListSeries())
				{

					blSerieNueva = false;
					blNuevoContingente = false;
					blCambioGrupo=false;
					newCodConvInter = 0;
					isCampoInvalido = false;
					codConvInter = serie.getCodconvinter() == null ? 0:serie.getCodconvinter(); 
					tipoMargen = serie.getCodtipomarge() == null ? "":serie.getCodtipomarge().trim();
					listValidPorAlcohol=new ArrayList<Map<String, Object>>();

					//Validamos si tiene tipo de margen 5 y convenio para ver si tiene contingente.
					blSolicitCont = contingentesUtil.solcitaContingente(serie.getCodconvinter(), tipoMargen );

					//Validamos a nivel de manifiesto si la mercancia llego, se termina la validaci�n porque no arrivo la mercancia
					if(  blSolicitCont) {
						listError.addAll(listErrorManif);
						if( !CollectionUtils.isEmpty(listErrorManif))	 {
							nroErroresContingente ++;
							nroErroresNegocio = nroErroresNegocio + nroErroresContingente;
							log.info(" procesarRectiOficio listError 1"+listError);
							log.debug(" procesarRectiOficio listError 1"+listError);
							return listError;

						}		

					}
					/* fin */	

					// serie de Base de datos correspondiente
					DatoSerie serieOld = null;
					for(DatoSerie serieBD:lstSeriesBd){
						if (SunatNumberUtils.isEqual(serieBD.getNumserie(), serie.getNumserie())) {
							serieOld=serieBD;
							if ( !SunatNumberUtils.isEqual(serieOld.getCodconvinter(), serie.getCodconvinter()) ||
									!SunatNumberUtils.isEqual(serieOld.getNumpartnandi(), serie.getNumpartnandi())) {
								blCambioTpiPartida = true;
							}

							//Obtenemos el tipo de margen de la serie antigua
							oldTipoMargen = serieOld.getCodtipomarge() == null ? "":serieOld.getCodtipomarge().trim();

							break;
						}
					}



					// Si tiene contingente 
					if ( tipoMargen.equals("5")  || oldTipoMargen.equals("5") ){

						liberaReservaContingentes();
						// datos de Cuenta Corriente de Contingencia para la serie
						Map<String, Object> mapDatosCont = new HashMap<String, Object>();
						mapDatosCont.put("numDoc",SunatStringUtils.lpad(declaracion.getNumdeclRef().getNumcorre(),6,'0'));
						mapDatosCont.put("annDoc", declaracion.getNumdeclRef().getAnnprese());
						mapDatosCont.put("codTipoDoc", "02");
						mapDatosCont.put("codEstado", "03");

						//glazaror... evitamos otro query adicional por serie
						//ContCtaCte serieCtaCte= contingentesUtil.getContCtaCte(mapDatosCont,serie,declaracion);
						//glazaror... obtenemos la cuenta corriente de la serie del map
						ContCtaCte serieCtaCte = cuentasCorrientesMap.get(serie.getNumserie());

						/* olunar 581 - Cuando la serie es nueva */
						if(serieOld==null)
						{
							for (DatoSerie serieAux : declaracion.getDua().getListSeries())
							{ // Tomando el contingente de la serie que tiene el mismo grupo de contingente
								if(serie.getCodpaisorige().equals(serieAux.getCodpaisorige()) && serie.getCodconvinter().intValue()==serieAux.getCodconvinter().intValue())
								{
									//glazaror... evitamos otro query adicional por serie
									//serieCtaCte= contingentesUtil.getContCtaCte(mapDatosCont,serieAux,declaracion);

									//glazaror... obtenemos la cuenta corriente de serieAux del map
									serieCtaCte = cuentasCorrientesMap.get(serieAux.getNumserie());
									if(serieCtaCte!=null)serieCtaCte.setNumSerieDoc(serie.getNumserie());
									break;  
								}
							}
							serieOld=new DatoSerie();
							serieOld.setCntunifis(new BigDecimal(0));
							serieOld.setCntpesoneto(new BigDecimal(0));
							serieOld.setMtofobdol(new BigDecimal(0));
							serieOld.setCodconvinter(serie.getCodconvinter());
							serieOld.setNumpartnandi(serie.getNumpartnandi());
							serieOld.setCodpaisorige(serie.getCodpaisorige());
							blSerieNueva=true;
						}
						/* fin */				

						//se valida si es una serie que ya esta con contingente
						boolean gbcontCtaCte = !(serieCtaCte==null);

						// Solo se verifica la transmisi�n
						if(codTransaccion.endsWith(COD_TRX_DILIG_REGU_GRA ) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_VAL)
								|| codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL)
								|| codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)){
							if (!CollectionUtils.isEmpty((List) variablesIngreso.get("listConvenioSerie")))
							{
								List<Map<String, Object>> lstConvenioSerie = (List<Map<String, Object>>) variablesIngreso.get("listConvenioSerie");
								for (int i = 0; i < lstConvenioSerie.size(); i++)
								{
									HashMap Convenio = (HashMap) lstConvenioSerie.get(i);
									if (Convenio.get("NUM_SECSERIE").toString().trim().equals(serie.getNumserie().toString().trim())) {
										if (Convenio.get("COD_TIPCONVENIO").toString().equals("I")) {
											if(!"1".equals((String)Convenio.get("IND_DEL"))){
												if(Convenio.get("COD_CONVENIO")!=null){
													newCodConvInter = Integer.parseInt( Convenio.get("COD_CONVENIO").toString().trim());
												}
											} else if("1".equals((String)Convenio.get("IND_DEL"))){
												// Se elimino la serie
												newCodConvInter = 0;
											}
										} 
									} 
								}

								if ( newCodConvInter != codConvInter) {
									serie.setCodconvinter(newCodConvInter);	
								}
							} 
						}

						log.info(" procesarRectiOficio listError 2 "+listError);
						log.debug(" procesarRectiOficio listError 2 "+listError);


						//Se hacen las validaciones generales de contingnetes 
						if ( tipoMargen.equals("5")){

							if ( !blSolicitCont ) {
								listError.add(ResponseMapManager.getErrorResponseMap("08801", "SERIE".concat(serie.getNumserie().toString()).concat(" PARA ACOGERSE A CONTINGENTE ARANCELARIO, DEBE ACOGERSE A UN TPI")));
								//        			  nroErroresNegocio= nroErroresNegocio + 1;
								nroErroresContingente ++;
							}  

							if ( blSolicitCont )
							{
								String codtpi=SunatStringUtils.toStringObj(serie.getCodconvinter());
								if(codtpi.equals("812"))  {
									String codpais =serie.getCodpaisorige();
									String mensaje1 = "PARA ACOGERSE A TPI 812 CON CONTINGENTE ARANCELARIO EL PA�S ORIGEN DEBE SER DEL GRUPO DE PA�S UE";
									PaisOrigenTratoPreferencialService  paisOrigenTratoPreferencialService = fabricaDeServicios.getService("paisOrigenTratoPreferencialService");
									boolean existePuerto = paisOrigenTratoPreferencialService.existsOrilibe(ConstantesDataCatalogo.TRATO_PREFERENCIAL_INTERNACIONAL, codtpi.toString(), codpais);
									if (existePuerto){
										serie.setCodpaisorige("UE");
									} else	{
										listError.add(ResponseMapManager.getErrorResponseMap("08801", mensaje1));
										//								nroErroresNegocio= nroErroresNegocio + 1;
										nroErroresContingente ++;
										log.info(" procesarRectiOficio listError 3 "+listError);
										log.debug(" procesarRectiOficio listError 3 "+listError);

									}
								}

							}

							// No tiene cuenta corriente y se afilia a contingente
							if (!gbcontCtaCte ) {



								// Se valida si hay TPI y si hay contingente 
								// se obtiene el grupo de contingente al que pertenece la serie diligenciada
								//glazaror... optimizacion se consulta una sola vez data de contingentes en BD
								listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
								if(CollectionUtils.isEmpty(listJoinContingente)){
									//					    	listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35423","E", new String[]{serie.getNumserie().toString()}));
									if (codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL) ) {
										listContRectifi=contingentesUtil.listContingenteRecOficio(serie , declaracion);
										if(CollectionUtils.isEmpty(listContRectifi)){   
											listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35761","E", 
													new String[]{SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0'), serie.getCodconvinter().toString(), serie.getCodpaisorige()}));
											nroErroresContingente ++;
											log.info(" procesarRectiOficio listError 4.0 "+listError);
											log.debug(" procesarRectiOficio listError 4.0 "+listError);

											continue;
										} else {
											blNuevoContingente = true;  
										}
									} else {

										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08801","E", new String[]{serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
										//nroErroresNegocio= nroErroresNegocio + 1;
										nroErroresContingente ++;
										log.info(" procesarRectiOficio listError 4 "+listError);
										log.debug(" procesarRectiOficio listError 4 "+listError);

									}	
								}  else {
									blNuevoContingente = true;  
								}
							}    

							// Se verifica que se quier acoger a contingente 
							//Incorpora contingente (TPI y TM5) mediante la transmisi�n de la regularizaci�n siempre y cuando la mercanc�a haya arribado (como se indica en RF1)
							//y no se haya efectuado el pago y verifica si tiene garantia
							// Solo se verifica la transmisi�n

							//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS
							if (isValidaContingenteRectificacion && blNuevoContingente ) {
								// Se verifica que no exista un cambio de cuenta corriente
								if (!tieneIndicador16 && estaPagada && serieCtaCte==null  ) {
									//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35758"));
									blError35758 = true;
									nroErroresContingente ++;
								}
								if (tieneIndicador16 && !estaPagada) {
									//35759 LA DECLARACI�N NO SE ENCUENTRA CANCELADA. NO DEBE ENVIAR EL INDICADOR 16
									//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35759"));
									blError35759 = true;
									//nroErroresNegocio= nroErroresNegocio + 1;
									nroErroresContingente ++;
								}
							} else {
								if ( tieneIndicador16 ) {
									//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35422"));
									blError35422 = true;
									//nroErroresNegocio= nroErroresNegocio + 1;
									nroErroresContingente ++;
								}
							}
							//PAS20165E220200076 RSERRANO CONTINGENTE SE ADICIONA PARA LA REGULARIZACION DE LAS ANTICIPADAS


							if ( isViaTransPostal) {
								//listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35421"));
								blError35421 = true;
								//nroErroresNegocio= nroErroresNegocio + 1;
								nroErroresContingente ++;
							}	              
						}

						log.info(" procesarRectiOficio listError 5 "+listError);
						log.debug(" procesarRectiOficio listError 5 "+listError);


						// Ya no valida y continua con la otra serie
						//if ( nroErroresNegocio > 1 ) {
						if ( nroErroresContingente > 0 ) {
							continue;
						}



						// Aqui se verifica si existe modificaci�n de datos de contingentes.
						boolean datosRectificados = contingentesUtil.solicitaRectificarContingente( serie, serieOld , listValidPorAlcohol);

						// Se tiene contingente y no modifica nada, no valida nada
						if ( blSolicitCont  && oldTipoMargen.equals("5") && !datosRectificados ){
							continue;
						}

						// Se solicita retiro de contingente porque tenia contingente, no valida nada
						if ( !tipoMargen.equals("5")   && oldTipoMargen.equals("5") ){
							continue;
						}

						// Sw verifica si existe cambio de grupo
						if (serieCtaCte != null) {
							if(!SunatStringUtils.isEqualTo(serieCtaCte.getNumGrupoCont().toString(),SunatStringUtils.toStringObj(mapDatosCont.get("numGrupoCont")))
									|| !SunatStringUtils.isEqualTo(serieCtaCte.getCodPaisOrigen(),SunatStringUtils.toStringObj(mapDatosCont.get("codPaisOrigen")) )
									|| !SunatStringUtils.isEqualTo(serieCtaCte.getCodTpi(), SunatStringUtils.toStringObj(mapDatosCont.get("codTpi")) )
									//|| !SunatNumberUtils.isEqual(serie.getNumpartnandi(), serieOld.getNumpartnandi()) //olunar - 581 
									){
								blCambioGrupo=true;
							}
						} else 
							blCambioGrupo=true;

						//Es necesario buscar la listJoinContingentes	          
						listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
						//Para los demas casos NO ES NECESARO VALIDAR PORQUE SE RETIRA CONTINGENTE
						if (datosRectificados || blNuevoContingente || blSerieNueva || blCambioGrupo) 
						{

							if( !CollectionUtils.isEmpty(listJoinContingente)) {
								mapDatosCont = listJoinContingente.get(0);
								///rtineo optimizacion se consulta una unica vez a la BD
								listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont, variablesIngreso, codTransaccion);
								listErrOtros = validaCamposContingente(serie, mapDatosCont, declaracion.getDua(), variablesIngreso,codTransaccion);
								log.info(" procesarRectiOficio listError 6.1 "+listError);
								log.debug(" procesarRectiOficio listError 6.1 "+listError);

								if( !CollectionUtils.isEmpty(listErrOtros))	 {
									//nroErroresNegocio= nroErroresNegocio + 1;
									nroErroresContingente ++;
									listError.addAll(listErrOtros );
									isCampoInvalido = true;

									log.info(" procesarRectiOficio listError 6 "+listError);
									log.debug(" procesarRectiOficio listError 6 "+listError);

								} 

							} else {
								//glazaror... optimizacion se consulta una sola vez data de contingentes en BD
								listJoinContingente = contingentesUtil.getListJoinContingente(serie , declaracion, variablesIngreso);
								if( !CollectionUtils.isEmpty(listJoinContingente)){ 
									mapDatosCont = listJoinContingente.get(0);
									//rtineo optimizacion se consulta una unica vez a la BD
									listValidPorAlcohol= contingentesUtil.getListFactEquiAlcohol(declaracion, mapDatosCont, variablesIngreso,codTransaccion);
								} else {

									// Se verfifica si es rectificaci�n de oficio y cuando recien se acoge si hay saldo en otros periodos, solo ese caso
									if (  (blNuevoContingente || blSerieNueva ) && 
											(codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) ||  codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL)) && 
											!CollectionUtils.isEmpty(listContRectifi) ) {
										// Para los casos de rectificaci�n de oficio
										listError.addAll( validaSaldoRectifOficio(serie,  declaracion,    listContRectifi, variablesIngreso, mapDatosCont) );

										log.info(" procesarRectiOficio listError 7 "+listError);
										log.debug(" procesarRectiOficio listError 7 "+listError);

									} else {
										listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("08801","E", new String[]{serie.getCodconvinter().toString(), serie.getCodpaisorige(), SunatStringUtils.lpad(serie.getNumpartnandi().toString(), 10, '0')}));
										//nroErroresNegocio= nroErroresNegocio + 1;
										nroErroresContingente ++;
										log.info(" procesarRectiOficio listError 8 "+listError);
										log.debug(" procesarRectiOficio listError 8 "+listError);

									}

								}


							}

							if( !CollectionUtils.isEmpty(listJoinContingente)){


								// Ya no valida y continua con la otra serie
								//if ( nroErroresNegocio > 1 ) {
								if ( nroErroresContingente  > 0 ) {
									continue;
								}

								// Se agrega cuando sucede rectificaciones en las unidades ya que tambien cambian 
								if (contingentesUtil.isRectificaCantContingentes(serie, serieOld, mapDatosCont, listValidPorAlcohol) || blSerieNueva || blCambioGrupo || blNuevoContingente || datosRectificados) 
								{
									if ( blCambioGrupo || blNuevoContingente) {
										blSerieNueva = true;
									}
									BigDecimal cntContingente = new BigDecimal(0);
									BigDecimal cntSolicCont = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);
									BigDecimal cndDifAdicional=new BigDecimal(0);
									if (blCambioGrupo || blNuevoContingente || blSerieNueva ) {
										cndDifAdicional = cntSolicCont;
									} else {
										cntContingente = contingentesUtil.getRectificaCantContingentes(serie, serieOld, mapDatosCont);
										if(SunatNumberUtils.isGreaterOrEqualsThanZero(cntContingente)){
											cndDifAdicional=SunatNumberUtils.diference(cntSolicCont, cntContingente);
										} else {
											// No hubo cambios solo se cambio la partida
											if (blCambioTpiPartida) {
												cndDifAdicional = new BigDecimal( -1);
											}
										}
									}

									if(SunatNumberUtils.isGreaterOrEqualsThanZero(cndDifAdicional)){
										if (  (blNuevoContingente || blSerieNueva ) && 
												(codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA) || codTransaccion.endsWith(COD_TRX_RECT_OFI_D_VAL))   ) {
											BigDecimal cntSolicContNew = contingentesUtil.getCantContingenteSolicitado(serie, mapDatosCont, listValidPorAlcohol);
											BigDecimal cntSolicContOld = contingentesUtil.getCantContingenteSolicitado(serieOld, mapDatosCont, listValidPorAlcohol);
											if (cntSolicContNew.compareTo(cntSolicContOld)>0){
												listError.addAll( validaSaldoRectifOficio(serie,  declaracion,    listContRectifi, variablesIngreso , mapDatosCont) );
											}

											log.info(" procesarRectiOficio listError 9 "+listError);
											log.debug(" procesarRectiOficio listError 9 "+listError);

										}  else {
											listError.addAll( validaSaldoContingenteNoNumeracion(serie,serieOld, mapDatosCont, declaracion, mapCntSolAntSeries, blSerieNueva,  listValidPorAlcohol, cuentasCorrientesRecMap, codTransaccion) );

											log.info(" procesarRectiOficio listError 10 "+listError);
											log.debug(" procesarRectiOficio listError 10 "+listError);

										}
									}


								}

							} 

						}

						if(codTransaccion.endsWith(COD_TRX_DILIG_REGU_GRA ) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_DESP_VAL)
								//inicio P21-P22
								|| codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_GRA) || codTransaccion.endsWith(COD_TRX_DILIG_CONCLU_VAL) || codTransaccion.endsWith(COD_TRX_RECT_OFI_VAL)
								|| codTransaccion.endsWith(COD_TRX_RECT_OFI_GRA)){
							//fin P21-P22		        		  
							if (!CollectionUtils.isEmpty((List) variablesIngreso.get("listConvenioSerie")))
							{
								if (  SunatNumberUtils.isEqual(newCodConvInter, codConvInter)) {
									serie.setCodconvinter(codConvInter);	
								}

							} 


						}
					} 
					// Si no tiene TipoMargen 5 el nuevo ni el antiguo no debe hacer nada

				}
				//Luego de la validaci�n d

				//Se muestra el error por declaraci�n de los siguientes errores de numeraci�n
				if (blError35758) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35758"));
					nroErroresNegocio= nroErroresNegocio + 1;
				}
				if (blError35759) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35759"));
					nroErroresNegocio= nroErroresNegocio + 1;
				}
				if (blError35422) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35422"));
					nroErroresNegocio= nroErroresNegocio + 1;
				}
				if (blError35421) {
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35421"));
					nroErroresNegocio= nroErroresNegocio + 1;
				}


			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			log.error("Error en contingente***",e);
			String message = "OCURRIO UN ERROR GRAVE";
			listError.add(ResponseMapManager.getErrorResponseMap("08807", message));

			log.info(" procesarRectiOficio listError 11 "+listError);
			log.debug(" procesarRectiOficio listError 11 "+listError);

			log.info(" procesarRectiOficio listError 12 "+ e.getMessage() );
			log.debug(" procesarRectiOficio listError 12 "+e.getMessage());



		}

		nroErroresNegocio = nroErroresNegocio + nroErroresContingente;

		log.info(" procesarRectiOficio listError 13 "+listError);
		log.debug(" procesarRectiOficio listError 13 "+listError);


		if(nroErroresNegocio == 0 && contingentesUtil.is8805UnicoError(listError, 0L)  ){
			variablesIngreso.put("is8805UnicoError", Boolean.TRUE);
			variablesIngreso.put("nroErrores", nroErroresNegocio);
		}


		return listError;
	}

	/*branch  ingreso 2011-029 diligencia despacho inicio */
	public boolean tieneContingentes(  Map<String, Object> mapDUA ) {
		ContingentesUtil  contingentesUtil = fabricaDeServicios.getService("declaracion.contingentesUtil");
		List<DatoSerie> lstSeriesBd= contingentesUtil.getSeriesBD( Long.valueOf(mapDUA.get("NUM_CORREDOC_DUA").toString()) );
		Declaracion declaracion = contingentesUtil.getDeclaracionBD(mapDUA );
		List<ContCtaCte> cuentasCorrientesAll =  contingentesUtil.getContCtaCteAll(lstSeriesBd, declaracion);
		Map<Integer, ContCtaCte> cuentasCorrientesMap = new HashMap<Integer, ContCtaCte>();
		//cuentasCorrientesMap.put(cuentaCorriente.getNumSerieDoc(), cuentaCorriente);
		int numeSerie = 0;
		if ( !CollectionUtils.isEmpty(cuentasCorrientesAll)   ) {
			for (ContCtaCte cuentaCorriente : cuentasCorrientesAll) {
				if (cuentaCorriente != null ) {
					numeSerie = cuentaCorriente.getNumSerieDoc() == null ? 0 : cuentaCorriente.getNumSerieDoc();	
					if (!cuentasCorrientesMap.containsKey(cuentaCorriente.getNumSerieDoc())) {
						cuentasCorrientesMap.put(cuentaCorriente.getNumSerieDoc(), cuentaCorriente);
					}
					return true;
				}
			}

		}

		return false;
	}

}