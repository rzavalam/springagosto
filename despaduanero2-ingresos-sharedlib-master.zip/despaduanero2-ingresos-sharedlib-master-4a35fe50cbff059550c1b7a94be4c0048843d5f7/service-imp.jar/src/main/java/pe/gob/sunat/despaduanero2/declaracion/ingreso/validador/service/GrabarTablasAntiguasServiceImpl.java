package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaran;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeclaranDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;

public class GrabarTablasAntiguasServiceImpl extends ValDuaAbstract implements GrabarTablasAntiguasService {

	@Override
	public void grabarTablasAntiguas(Declaracion declaracion, Map<String, Object> variablesIngreso) {
		Boolean grabarDeclaran = (Boolean) variablesIngreso.get("grabarDeclaran");
		Boolean actualizarDeclaran = (Boolean) variablesIngreso.get("actualizarDeclaran");
		Map<String, Object> mapDeclaran = (Map<String, Object>) variablesIngreso.get("mapDeclaran");
		if (grabarDeclaran || actualizarDeclaran) {
			if (mapDeclaran != null) {
				String ctipodoc = (String) mapDeclaran.get("tipoDocumento");
				String ddirecc = (String) mapDeclaran.get("direccion");
				String cdocumen = (String) mapDeclaran.get("numDocumento");;
				String dnombre = (String) mapDeclaran.get("nombre");;
				Declaran declaran = new Declaran();
				if (SunatStringUtils.length(dnombre) > 150){
					dnombre = dnombre.substring(0, 150);
				}
				if (SunatStringUtils.length(ddirecc) > 80){
					ddirecc = ddirecc.substring(0, 80);
				}
				DUA dua = declaracion.getDua();
				declaran.setCdocumen(cdocumen);
				declaran.setCtipodoc(ctipodoc);
				declaran.setDnombre(dnombre);
				declaran.setDdirecc(ddirecc);
				declaran.setCregimen(dua.getCodregimen());
				declaran.setRegiPride(dua.getCodregimen());
				declaran.setCadu(dua.getCodaduanaorden());

				if (grabarDeclaran) {// Solo para grabar no para actualizar				
					declaran.setFechPride(SunatDateUtils.getCurrentIntegerDate());
					declaran.setFing(SunatDateUtils.getCurrentIntegerDate());
				}
				declaran.setFfin(99991231);
				DataSourceContextHolder.setKeyDataSource(declaracion.getCodaduana());
				DeclaranDAO declaranDAO = (DeclaranDAO) fabricaDeServicios.getService("declaracion.declaranDAO");
				DeclaranDAO declaranOperativaDAO = (DeclaranDAO) fabricaDeServicios.getService("declaracion.declaranOperativaDAO");
				if (grabarDeclaran){
					declaranDAO.insertDdp(declaran);
					declaranOperativaDAO.insertDdp(declaran);
				}
				if (actualizarDeclaran){
					declaranDAO.updateByPrimaryKeySelective(declaran);
				}
			}
		}
	}
}
