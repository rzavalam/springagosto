package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;


/**
 * La Class TipoDeDescrMinimaServiceImpl.
 */
public class ValidadorSivepDescrMinimaServiceImpl implements ValidadorSivepDescrMinimaService {

	//private TipoDeDescrMinimaService tipoDeDescrMinima;
	//private TransformadorDescrMinimaService transformador;
	//private CatalogoHelperImpl catalogoHelper;
	//private FabricaDeServicios fabricaDeServicios;
	//private ValidadorFactory validadorFactory;
	  
	public String obtenerDescripcionCatalogo(String codigoABuscar,String codigoCatalogo){
		String dato = "";
		
		// -- Se necesitan estos Datos
//		ModelAbstract objetoConDatos = transformador.poblarObjetoDescrMinima(tipoDescrMinima, item, dua);
//		
//		ValidadorAbstract validador = validadorFactory.crearValidadorDescrMinima(objetoConDatos);
//		validador.obtenerDescripcionCatalogo(codigoABuscar, codigoCatalogo);
		return dato;
	};
}