/*
 * Clase que define el servicio de validaciones de los participantes del formato A de la DUA
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.servicio2.registro.model.dao.DdpDAO;
//import pe.gob.sunat.servicio2.registro.service.DdpDAOService;

/**
 * The Class ValParticipante. Clase que define el servicio de validaciones de los participantes del formato A de la DUA.
 */
public class ValParticipanteServiceImpl extends ValDuaAbstract implements ValParticipante{

	//private FabricaDeServicios fabricaDeServicios;
	
	/**
	 * Valida el Tipo participante.
	 * 
	 * @param tipoParticipante DataCatalogo
	 * @param codError String
	 * @return el mapa de errores
	 */
	
	//private DdpDAOService ddpDAOService;
	
	public Map<String, String> tipoParticipante (DataCatalogo tipoParticipante, String codError){
		String codtipparticipante=tipoParticipante.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("123", codtipparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("123", codtipparticipante,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError(codError,"Error catalogo codtipparticipante");	
	}
	
	/**
	 * Valida el Tipo participante determinando si es obligatorio o no.
	 * 
	 * @param tipoParticipante DataCatalogo
	 * @param codTipPartOblig String
	 * @param codError String
	 * @return el mapa de errores
	 */
	public Map<String, String> tipoParticipante (DataCatalogo tipoParticipante,String codTipPartOblig, String codError){
		String codtipparticipante=tipoParticipante.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("123", codtipparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("123", codtipparticipante,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			 if(codTipPartOblig!=null && !codTipPartOblig.equals(codtipparticipante)){
				 return getDUAError(codError,"Error tipo codtipparticipante");	
			 }
			 else{
				 return new HashMap<String,String>();
			 }
			
		else
			return getDUAError(codError,"Error catalogo codtipparticipante");	
	}
	

	/**
	 * Valida el Tipo documento identidad.
	 * 
	 * @param tipoDocumentoIdentidad DataCatalogo. Tipo documento identidad.
	 * @param codError String. 
	 * @return el mapa de errores
	 */
	public Map<String, String> tipoDocumentoIdentidad(DataCatalogo tipoDocumentoIdentidad, String codError){
		String codtipdocparticipante=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("27", codtipdocparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", codtipdocparticipante,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError(codError,"Error catalogo codtipdocparticipante");	
	}
	
	/**
	 * Valida el Tipo documento identidad determinando si es obligatorio o no.
	 * 
	 * @param tipoDocumentoIdentidad DataCatalogo. Tipo documento identidad.
	 * @param codTipoDocOblig String
	 * @param codError String
	 * @return el mapa de errores
	 */
	public Map<String, String> tipoDocumentoIdentidad(DataCatalogo tipoDocumentoIdentidad, 
			String codTipoDocOblig, String codError){
		String codtipdocparticipante=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
		
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("27", codtipdocparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("27", codtipdocparticipante,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
		{
			
			if(codTipoDocOblig!=null && !codTipoDocOblig.equals(codtipdocparticipante)){
				return getDUAError(codError,"Error tipo codtipdocparticipante obligatorio");
			}
			else
				return new HashMap<String,String>();
		}
			
		else
			return getDUAError(codError,"Error catalogo codtipdocparticipante");	
	}
	

	/**
	 * Valida el Numero documento identidad.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numeroDocumentoIdentidad String. Numero documento identidad.
	 * @param codError String
	 * @param tipoDocumentoIdentidad DataCatalogo. Tipo documento identidad.
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> numeroDocumentoIdentidad(String numeroDocumentoIdentidad, String codError, DataCatalogo tipoDocumentoIdentidad){
		
		String codTipoDocumento=tipoDocumentoIdentidad!=null?tipoDocumentoIdentidad.getCodDatacat():null;
		
		if (!"4".equals(codTipoDocumento)){
			return !SunatStringUtils.isEmptyTrim(numeroDocumentoIdentidad)?new HashMap<String,String>():getDUAError(codError,"");
		}else{
			if (!SunatStringUtils.isEmptyTrim(numeroDocumentoIdentidad)){
				if (numeroDocumentoIdentidad.trim().length()==11){
//					Map mapDdp=(HashMap)FormatoAServiceImpl.getInstance().getDdpDAO().findByPK(numeroDocumentoIdentidad);
//					Map mapDdp=(HashMap)ddpDAOService.findByPK(numeroDocumentoIdentidad);
					Map mapDdp=(HashMap)((DdpDAO)fabricaDeServicios.getService("servicio.registro.model.ddpDAO")).findByPK(numeroDocumentoIdentidad);
					
					if (mapDdp==null)
						return getDUAError(codError,"");
				}else{ 
					return getDUAError(codError,"");
				}
			}else{
				return getDUAError(codError,"");
			}
			return new HashMap<String,String>();
		}
	}

	/**
	 * Valida el Codigo de Pais del participante.
	 * 
	 * @param pais DataCatalogo. Datos del pais
	 * @param codError String
	 * @return el mapa de errores
	 */
	public Map<String, String> pais(DataCatalogo pais, String codError){
		String codpaisparticipante=pais.getCodDatacat();
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J2", codpaisparticipante))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2", codpaisparticipante, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError(codError,"Error catalogo codpaisparticipante");	
	}

	/**
	 * Valida el nombre de la razon social del participante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param nombreRazonSocial String. Nombre de la razon social.
	 * @param codError String
	 * @return Map
	 */
	public Map<String, String> nombreRazonSocial(String nombreRazonSocial, String codError){
		return (!SunatStringUtils.isEmptyTrim(nombreRazonSocial) && nombreRazonSocial.trim().length()>=5)?new HashMap<String,String>():getDUAError(codError,"");
	}

	/**
	 * Valida la direccion del participante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 10 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param direccion String. Direccion del participante.
	 * @param codError String
	 * @return Map
	 */
	public Map<String, String> direccion(String direccion, String codError){
		return (!SunatStringUtils.isEmptyTrim(direccion) && direccion.trim().length()>=10)?new HashMap<String,String>():getDUAError(codError,"");
	}

	/**
	 * Valida la ciudad del participante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param ciudad String. Ciudad del participante.
	 * @param codError String
	 * @return Map
	 */
	public Map<String, String> ciudad(String ciudad, String codError){
		return (!SunatStringUtils.isEmptyTrim(ciudad) && ciudad.trim().length()>=5)?new HashMap<String,String>():getDUAError(codError,"");
	}

	/**
	 * Valida el numero de telefono del participante.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param telefono String. Telefono del participante.
	 * @param codError String
	 * @return Map
	 */
	public Map<String, String> telefono(String telefono, String codError){
		return (!SunatStringUtils.isEmptyTrim(telefono) && telefono.trim().length()>=5)?new HashMap<String,String>():getDUAError(codError,"");
	}

	/**
	 * Valida el numero de fax del participante.<br>
	 * 
	 * Valida que el par&aacute;metro siempre tenga un valor y que su longitud no sea menor a 5 caracteres.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fax String. N�mero de fax.
	 * @param codError String
	 * @return Map
	 */
	public Map<String, String> fax(String fax, String codError){
		return (!SunatStringUtils.isEmptyTrim(fax) && fax.trim().length()>=5)?new HashMap<String,String>():getDUAError(codError,"");
	}

	/**
	 * Valida la direcci�n de email del participante.<br>
	 * 
	 * Valida que el par&&acute;metro siempre tenga un valor y que corresponda a una direcci&oacute;n de correo electr&oacute;nico.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param email String. Direcci�n de email del participante.
	 * @param codError String
	 * @return Map
	 */
	public Map<String, String> email(String email, String codError){
		return (!SunatStringUtils.isEmptyTrim(email) && SunatStringUtils.isValidEmailAddress(email))?new HashMap<String,String>():getDUAError(codError,"");
	}

	/**
	 * Valia la direccion de la pagina web del participante.<br>
	 * Valida que el par&&acute;metro siempre tenga un valor y que corresponda a una direcci&oacute;n de p&aacute;gina web.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param paginaWeb String
	 * @param codError String
	 * @return Map
	 */
	public Map<String, String> paginaWeb(String paginaWeb, String codError){
		return (!SunatStringUtils.isEmptyTrim(paginaWeb) && SunatStringUtils.isValidURLAddress(paginaWeb))?new HashMap<String,String>():getDUAError(codError,"");
	}

	/*
	public DdpDAOService getDdpDAOService() {
		return ddpDAOService;
	}

	public void setDdpDAOService(DdpDAOService ddpDAOService) {
		this.ddpDAOService = ddpDAOService;
	}*/
	/*

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
