package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.aop.target.HotSwappableTargetSource;

import pe.gob.sunat.despaduanero2.ayudas.model.dao.CircunoceDAO;
import pe.gob.sunat.despaduanero2.ayudas.model.dao.OpecomextDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo; //Pase548
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ResponseListManager;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidarPuntoLlegadaMercaderiaAbstract.PuntoLlegadaTerminalPortuario;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.manifiesto.model.dao.McdetaDAO;
import pe.gob.sunat.despaduanero2.manifiesto.service.DocumentoOAManifiestoValidacionService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoService;
import pe.gob.sunat.despaduanero2.manifiesto.service.ManifiestoSigadService;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

public class ValidadorPuntoLlegadaMercanciaModalidadExcepcional extends ValidarPuntoLlegadaMercaderiaAbstract implements ValidadorPuntoLlegadaMercancia {
    //Pase548
	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL = {CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL,CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO,CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS,ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_CETICOS};
	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_SIN_ICA = {CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO};
	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_SIN_PESOS_BULTOS_RECIBIDOS = {CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL,CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO,CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS,ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_CETICOS,CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO};
	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_ZOFRATACNA = {CODIGO_PUNTO_LLEGADA_ZOFRATACNA}; //CSANTILLAN PASE PAS20181U220200054
	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_EER = {ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR};
	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_POSTAL = {ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_POSTAL};
	//RIN05 PAS20181U220200004 MORDONEZL
	private static String[] PUNTOS_LLEGADA_MERCANCIA_PARA_MODALIDAD_EXCEPCIONAL_MANIFIESTOFLUVIALYTERRESTRE = { "1","3","2" ,"9","16","14"}; 
	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_AEREO = {
			CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL,
			CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO,
			CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_CETICOS,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DUTTY_FREE,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DMUA,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO};
	private static final String[] PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_AEREO_EER = {
			CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL,
			CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO,
			CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_CETICOS,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DUTTY_FREE,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DMUA,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO,
			ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR};
	
	// estos valores se tiene que llenar en el contructor de la clase
	private String codigoLugarDescarga = null;
	private String codigoPuntoLLegadaMercancia = null;
	private String regimen = null;
	private String codigoAduanaTransmision = null;
	// numero de ruc del deposito
	private String numeroRUCdeposito = null;
	// numero de ruc del lugar del punto de llegada
	private String numeroRUCpuntoLlegada = null;
	//codigo regimen precedente
	private Elementos<DatoSerie> listSeries;	
	private String annManifiesto = null;
	private String codModTranspo= null;
	private String numManifiesto= null;
	private List<DatoDocTransporte> lstdocumentostrans = null;
	private String codigoTransaccion = null;
	private String codLocalAnexo = null;
	private boolean flagEsDAMDiferidaSinICA;
	//private FabricaDeServicios fabricaDeServicios;	
	private boolean esManifiestoEerSda;//PAS20181U220200049
	private boolean esManifiestoEerSigad;//PAS20181U220200064
	public ValidadorPuntoLlegadaMercanciaModalidadExcepcional() {
		super();
	}

	/**
	 * @param regimen
	 * @param listSeries
	 * @param codigoLugarDescarga
	 * @param codigoPuntoLLegadaMercancia
	 * @param numeroRUCpuntoLlegada
	 * @param numeroRUCdeposito
	 * @param catalogoHelper
	 */
	public ValidadorPuntoLlegadaMercanciaModalidadExcepcional(
			String codigoAduanaTransmision,
			String regimen,
			Elementos<DatoSerie> listSeries,
			String codigoLugarDescarga,
			String codigoPuntoLLegadaMercancia,
			String numeroRUCpuntoLlegada,
			String numeroRUCdeposito,
			Date fechaReferencia,
			OpecomextDAO opecomextDao,
			String annManifiesto,
			String codModTranspo,
			String numManifiesto,
			ManifiestoService manifiestoService,
			DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService,
			List<DatoDocTransporte> lstdocumentostrans,
			McdetaDAO mcdetaDAO,
			FabricaDeServicios fabricaDeServicios,
			HotSwappableTargetSource swapperDatasource,
			ManifiestoSigadService manifiestoSigadService,
			CircunoceDAO circunoceDAO,
			String codigoTransaccion,
			String codLocalAnexo,
			boolean esManifiestoEerSda,
			boolean esManifiestoEerSigad) //RIN 13-619 //PAS20181U220200049
	{
		
		this.codigoAduanaTransmision = codigoAduanaTransmision;
		this.regimen =regimen;
		this.listSeries = listSeries;
		this.codigoLugarDescarga = codigoLugarDescarga;
		this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia;
		this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;		
		this.numeroRUCdeposito = numeroRUCdeposito;		
		this.fechaReferencia = fechaReferencia;		
		this.opecomextDao = opecomextDao;
		this.annManifiesto = annManifiesto;
		this.codModTranspo = codModTranspo;
		this.numManifiesto = numManifiesto;
		this.manifiestoService = manifiestoService;
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
		this.lstdocumentostrans = lstdocumentostrans;
		this.mcdetaDAO = mcdetaDAO;
		this.fabricaDeServicios = fabricaDeServicios;
		this.swapperDatasource = swapperDatasource;
		this.manifiestoSigadService = manifiestoSigadService;
		this.circunoceDAO=circunoceDAO; //RIN 13-619
		this.codigoTransaccion=codigoTransaccion;
		this.codLocalAnexo = codLocalAnexo;
		this.esManifiestoEerSda = esManifiestoEerSda; //PAS20181U220200049
		this.esManifiestoEerSigad = esManifiestoEerSigad;//PAS20181U220200064
	}
	public ValidadorPuntoLlegadaMercanciaModalidadExcepcional(
			String codigoAduanaTransmision,
			String regimen,
			Elementos<DatoSerie> listSeries,
			String codigoLugarDescarga,
			String codigoPuntoLLegadaMercancia,
			String numeroRUCpuntoLlegada,
			String numeroRUCdeposito,
			Date fechaReferencia,
			OpecomextDAO opecomextDao,
			String annManifiesto,
			String codModTranspo,
			String numManifiesto,
			ManifiestoService manifiestoService,
			DocumentoOAManifiestoValidacionService documentoOAManifiestoValidacionService,
			List<DatoDocTransporte> lstdocumentostrans,
			McdetaDAO mcdetaDAO,
			FabricaDeServicios fabricaDeServicios,
			HotSwappableTargetSource swapperDatasource,
			ManifiestoSigadService manifiestoSigadService,
			CircunoceDAO circunoceDAO,
			String codigoTransaccion,
			String codLocalAnexo,
			boolean flagEsDAMDiferidaSinICA,
			boolean esManifiestoEerSda,
			boolean esManifiestoEerSigad) //RIN 13-619 //PAS20181U220200049 y PAS20181U220200064
	{
		
		this.codigoAduanaTransmision = codigoAduanaTransmision;
		this.regimen =regimen;
		this.listSeries = listSeries;
		this.codigoLugarDescarga = codigoLugarDescarga;
		this.codigoPuntoLLegadaMercancia = codigoPuntoLLegadaMercancia;
		this.numeroRUCpuntoLlegada = numeroRUCpuntoLlegada;		
		this.numeroRUCdeposito = numeroRUCdeposito;		
		this.fechaReferencia = fechaReferencia;		
		this.opecomextDao = opecomextDao;
		this.annManifiesto = annManifiesto;
		this.codModTranspo = codModTranspo;
		this.numManifiesto = numManifiesto;
		this.manifiestoService = manifiestoService;
		this.documentoOAManifiestoValidacionService = documentoOAManifiestoValidacionService;
		this.lstdocumentostrans = lstdocumentostrans;
		this.mcdetaDAO = mcdetaDAO;
		this.fabricaDeServicios = fabricaDeServicios;
		this.swapperDatasource = swapperDatasource;
		this.manifiestoSigadService = manifiestoSigadService;
		this.circunoceDAO=circunoceDAO; //RIN 13-619
		this.codigoTransaccion=codigoTransaccion;
		this.codLocalAnexo = codLocalAnexo;
		this.flagEsDAMDiferidaSinICA = flagEsDAMDiferidaSinICA;
		this.esManifiestoEerSda = esManifiestoEerSda; //PAS20181U220200049
		this.esManifiestoEerSigad = esManifiestoEerSigad;//PAS20181U220200064
	}


	/**
	 * Se a�ade el caso Aereo, EER RIN22 RN
	 * @throws PuntoLLegadaValidadorException
	 */
	
	private void validarPuntoLlegada() throws PuntoLLegadaValidadorException {
		boolean esPuntoLlegadaCorrecto = false;
		String[] puntosLLegadaPorTipoLugarDescarga = null;

		if(StringUtils.isNotBlank(codigoLugarDescarga)){
			throw new PuntoLLegadaValidadorException("30494", "PARA DESPACHOS DIFERIDOS NO DEBE DECLARAR EL CAMPO TIPO DE LUGAR DE DESCARGA");
		}
		if(StringUtils.isBlank(codigoPuntoLLegadaMercancia)){
			throw new PuntoLLegadaValidadorException("30481", new String[]{""}, "TIPO DE PUNTO DE LLEGADA INVALIDO PARA DESPACHO DIFERIDO");
		}
		//csantillan pase 4
		//CatalogoVigenciaService catalogoVigenciaService = (CatalogoVigenciaService)fabricaDeServicios.getService("Ayuda.catalogoVigenciaService");
		
	    //boolean esVigenteRIN05 = catalogoVigenciaService!=null?catalogoVigenciaService.esVigenteRIN05(fechaReferencia):false;
//PAS20181U220200064
		List<Map<String,String>> listaOMA = ((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaServicePrincipal")).validarElementoCat("380","0043",fechaReferencia);
		boolean considerarValoresCat227 = false;
		if(!ResponseListManager.responseListHasErrors(listaOMA)){
			considerarValoresCat227 = true;
		}
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
	    boolean esVigenteRIN05PrimeraParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05PrimeraParte(fechaReferencia):false;
	    boolean esVigenteRIN05SegundaParte = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN05SegundaParte(fechaReferencia):false;
	    String codigoErrorEER ="";
		if(!esVigenteRIN05SegundaParte && flagEsDAMDiferidaSinICA){
			esPuntoLlegadaCorrecto = ArrayUtils.contains(PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_SIN_ICA,
					codigoPuntoLLegadaMercancia); 
			if(!esPuntoLlegadaCorrecto){
				throw new PuntoLLegadaValidadorException("37035", new String[]{codigoPuntoLLegadaMercancia}, "PARA DESPACHOS DIFERIDOS SIN ICA EL CAMPO TIPO DE PUNTO DE LLEGADA DEBE SER 2.");
			}
		}else{
			
			if (SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA)){
				//esPuntoLlegadaCorrecto = ArrayUtils.contains(PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_AEREO, codigoPuntoLLegadaMercancia);
				if(esManifiestoEerSda) {//sera siempre falso si no esta la vigencia del pase PAS20181U220200049
					puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_EER;
					codigoErrorEER = "70151";
				}
				else {
					//puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_AEREO;
					if(numManifiesto == null)//si no hay numero de manifiesto
						puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_AEREO_EER;
					else {
						puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_AEREO;					
						if(esManifiestoEerSigad) puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_EER;
						if(!esManifiestoEerSigad && ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR.equals(codigoPuntoLLegadaMercancia)) {//PAS20181U220200064
						codigoErrorEER = "70375";
					}
				}
				}
			} else if (!considerarValoresCat227 && SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_EER)){ //PAra el caso de que es siged - PAS20181U220200049			
				puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_EER;
				
			} else if (SunatStringUtils.isEqualTo(codModTranspo, ConstantesDataCatalogo.VIA_TRANSPORTE_POSTAL)){
				puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_POSTAL;
				
			} else if (esVigenteRIN05PrimeraParte && 
					( (!considerarValoresCat227 && (ArrayUtils.contains(new String[] { ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL,
							 ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE_ACRONIMO, ConstantesDataCatalogo.VIA_TRANSPORTE_LACUSTRE}, codModTranspo)))
						|| 	
					  (considerarValoresCat227 && (ArrayUtils.contains(new String[] { ConstantesDataCatalogo.VIA_TRANSPORTE_FLUVIAL_UNECE,
							ConstantesDataCatalogo.VIA_TRANSPORTE_TERRESTRE}, codModTranspo) )) )){
		  			puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_PARA_MODALIDAD_EXCEPCIONAL_MANIFIESTOFLUVIALYTERRESTRE; 
		  		
			}else if(esVigenteRIN05SegundaParte && flagEsDAMDiferidaSinICA){
				puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL_SIN_PESOS_BULTOS_RECIBIDOS;
			}else{			
					puntosLLegadaPorTipoLugarDescarga = PUNTOS_LLEGADA_MERCANCIA_VALIDO_PARA_MODALIDAD_EXCEPCIONAL;
				
			}
			
			//validador:
	         if(!esPuntoLlegadaCorrecto){
			     esPuntoLlegadaCorrecto = ArrayUtils.contains(puntosLLegadaPorTipoLugarDescarga, codigoPuntoLLegadaMercancia);
	         }
			if(!esPuntoLlegadaCorrecto){
				if(!codigoErrorEER.isEmpty()) {
					throw new PuntoLLegadaValidadorException(codigoErrorEER,new String[]{codigoPuntoLLegadaMercancia}, "");//PAS20181U220200049
				}else {
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					
					
					String descripcionEnvio = codModTranspo;
					String descripcionVia = catalogoAyudaService.getDataCatalogo("10", codModTranspo)!=null?catalogoAyudaService.getDataCatalogo("10", codModTranspo).getDesCorta():"";
					if(considerarValoresCat227) {
						descripcionVia = catalogoAyudaService.getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_VIA_TRANSPORTE_UNECE, codModTranspo)!=null?
								catalogoAyudaService.getDataCatalogo(ConstantesDataCatalogo.COD_CATALOGO_VIA_TRANSPORTE_UNECE, codModTranspo).getDesCorta():"";
					}
							
					if(!descripcionVia.isEmpty()) {
						descripcionEnvio = descripcionEnvio+"-"+descripcionVia;
					} 
			//Pase548
				//throw new PuntoLLegadaValidadorException("30481", new String[]{codigoPuntoLLegadaMercancia}, "TIPO DE PUNTO DE LLEGADA INVALIDO PARA DESPACHO EXCEPCIONAL");
					throw new PuntoLLegadaValidadorException("32006", new String[]{descripcionEnvio,Arrays.toString(puntosLLegadaPorTipoLugarDescarga),codigoPuntoLLegadaMercancia},"");
					//PARA DESPACHOS DIFERIDOS CON ENVIOS {0} EL CAMPO TIPO DE PUNTO DE LLEGADA DEBE SER {1} : ENVIO {2}
				}
			}
		}
		
		if (CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(regimen)){
			
			boolean esPuntoLlegadaInCorrectoDeposito = CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLLegadaMercancia);
			if(esPuntoLlegadaInCorrectoDeposito){
				throw new PuntoLLegadaValidadorException("30560", new String[]{codigoPuntoLLegadaMercancia}, "TIPO DE PUNTO DE LLEGADA INVALIDO PARA DESPACHO DIFERIDO, REGIMEN 70");
			}
		}
		
		// modificar el orden de ejecucion podria afectar a las pruebas unitarias
		validarNumeroRUCpuntoLlegada();
		validarTipoLugarDescargaPorRegimen(regimen, numeroRUCdeposito, fechaReferencia, codigoAduanaTransmision);
		
		validarRegimenPrecedente(regimen);
		
	}
	
	
	private void validarNumeroRUCpuntoLlegada() throws PuntoLLegadaValidadorException {
		PuntoLlegadaValidador puntoLlegadaValidador = tipoPuntoLlegadaValidadorBuilder(codigoPuntoLLegadaMercancia);
		puntoLlegadaValidador.validar(fechaReferencia, codigoAduanaTransmision);
	}
	
	
	/**
	 * Valida el regimen d precedencia de las series
	 * @throws PuntoLLegadaValidadorException
	 */
	private void validarRegimenPrecedente(String regimen) throws PuntoLLegadaValidadorException{

		if (!CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(regimen)) {
			for (DatoSerie serie : listSeries) {
				validarRegimenPrecedente(serie);

			}
		}	
	}

	/**
	 * Valida el regimen precedente de la serie
	 * @param serie
	 * @throws PuntoLLegadaValidadorException
	 */
	private void validarRegimenPrecedente(DatoSerie serie) throws PuntoLLegadaValidadorException {
		Elementos<DatoRegPrecedencia> listRegPrecedencia = serie.getListRegPrecedencia();
		//String codigoRegimenPrecedente = buscarPrimerRegimenPrecedente(listRegPrecedencia);
		validarRegimenPrecedente(serie.getNumserie(), listRegPrecedencia);
	}

	/**
	 * Busca el tipo del primer regimen precedente de la serie
	 * @param listRegPrecedencia
	 * @return
	 */
	private String buscarPrimerRegimenPrecedente(Elementos<DatoRegPrecedencia> listRegPrecedencia) {
		String codigoRegimenPrecedente = "";
		
		if(CollectionUtils.isNotEmpty(listRegPrecedencia)){
			//buscamos por tipo de regimen
			codigoRegimenPrecedente = listRegPrecedencia.get(0).getCodregipre();
			DatoRegPrecedencia datoRegPrecedencia = (DatoRegPrecedencia)CollectionUtils.find(listRegPrecedencia, new Predicate() {
				
				@Override
				public boolean evaluate(Object arg0) {
					String codigoRegimenPrecedente = ((DatoRegPrecedencia)arg0).getCodregipre();
					return CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente);
				}
			});
			
			if(datoRegPrecedencia != null){
				codigoRegimenPrecedente = datoRegPrecedencia.getCodregipre();
			} 
		}
		return codigoRegimenPrecedente;
	}

	private boolean existeRegimenPrecedente(Elementos<DatoRegPrecedencia> listRegPrecedencia, final String codRegPreBuscar) {

		DatoRegPrecedencia datoRegPrecedencia =  (DatoRegPrecedencia) CollectionUtils.find(listRegPrecedencia, new Predicate() {
			@Override
			public boolean evaluate(Object regPrecedencia) {
				String codigoRegimenPrecedente = ((DatoRegPrecedencia)regPrecedencia).getCodregipre();
				try {
					return codigoRegimenPrecedente.equals(codRegPreBuscar);
				} catch (NullPointerException ne) {
					return false;
				}
			}
		});
		if(datoRegPrecedencia != null){
			return true;
		}
		return false;
	}
	
	/**
	 * Valida el codigo de regimen precedente
	 * @param numeroSerie numero de serie a mostrar en la excepcion
	 * @param codigoRegimenPrecedente
	 * @throws PuntoLLegadaValidadorException si no es valido lanza una excepcion
	 */
	private void validarRegimenPrecedente(Integer numeroSerie, Elementos<DatoRegPrecedencia> listRegPrecedencia)
			throws PuntoLLegadaValidadorException {
		
		if(CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLLegadaMercancia)){
			//if(!CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente)){
			if(!existeRegimenPrecedente(listRegPrecedencia, CODIGO_REGIMEN_DEPOSITO_ADUANERO)){
				//throw new PuntoLLegadaValidadorException("30554",
						//new String[] {codigoRegimenPrecedente, numeroSerie.toString() }, "REGIMEN PRECEDENTE INVALIDO PARA LA SERIE");
				//Pase548
				throw new PuntoLLegadaValidadorException("32007",
						new String[] {codigoPuntoLLegadaMercancia ,CODIGO_REGIMEN_DEPOSITO_ADUANERO, numeroSerie.toString() }, "PARA EL TIPO DE PUNTO DE LLEGADA [{0}] SE DEBE CONSIGNAR REGIMEN PRECEDENTE DE DEPOSITO [{1}]. INVALIDO PARA LA SERIE [{2}].");
			}
		}
		//Inicio: Pase 548 - lmvr
		if(ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_CETICOS.equals(codigoPuntoLLegadaMercancia)){
			//if(!ConstantesDataCatalogo.CODIGO_REGIMEN_CETICOS.equals(codigoRegimenPrecedente)){
			if(!existeRegimenPrecedente(listRegPrecedencia, ConstantesDataCatalogo.CODIGO_REGIMEN_CETICOS)){
				throw new PuntoLLegadaValidadorException("32005",
						new String[] { codigoPuntoLLegadaMercancia, numeroSerie.toString() }, "PARA EL TIPO DE PUNTO DE LLEGADA 6 DEBE DECLARAR UN REGIMEN PRECEDENTE CETICOS");
			}
		}
		
		
		//if(ConstantesDataCatalogo.CODIGO_REGIMEN_CETICOS.equals(codigoRegimenPrecedente)){
		if(existeRegimenPrecedente(listRegPrecedencia, ConstantesDataCatalogo.CODIGO_REGIMEN_CETICOS)){
			if(!ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_CETICOS.equals(codigoPuntoLLegadaMercancia)){
				throw new PuntoLLegadaValidadorException("32003",
						new String[] { ConstantesDataCatalogo.CODIGO_REGIMEN_CETICOS, codigoPuntoLLegadaMercancia, numeroSerie.toString() }, "REGIMEN PRECEDENTE DE CETICOS: TIPO DE PUNTO DE LLEGADA INVALIDO PARA LA SERIE");
			}
		}
		
		//Fin: Pase 548 - lmvr
		
		//if(CODIGO_REGIMEN_DEPOSITO_ADUANERO.equals(codigoRegimenPrecedente)){
		if(existeRegimenPrecedente(listRegPrecedencia, CODIGO_REGIMEN_DEPOSITO_ADUANERO)){
			if(!CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLLegadaMercancia)){
				//throw new PuntoLLegadaValidadorException("30546",
					//	new String[] { codigoRegimenPrecedente, codigoPuntoLLegadaMercancia, numeroSerie.toString() }, "REGIMEN PRECEDENTE DE DEPOSITO: TIPO DE PUNTO DE LLEGADA INVALIDO PARA LA SERIE");
				//Pase548

				//P34 amancilla debe enviar 3-deposito aduanaero conversado con eduardo
				//throw new PuntoLLegadaValidadorException("32008",
				//		new String[] { codigoRegimenPrecedente, codigoPuntoLLegadaMercancia, numeroSerie.toString() }, "PARA EL REGIMEN PRECEDENTE DE DEPOSITO [{0}] SE DEBE CONSIGNAR EL TIPO DE PUNTO DE LLEGADA [{1}]. INVALIDO PARA LA SERIE [{2}]");


				throw new PuntoLLegadaValidadorException("32008",
						new String[] { CODIGO_REGIMEN_DEPOSITO_ADUANERO, CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO, numeroSerie.toString() }, "PARA EL REGIMEN PRECEDENTE DE DEPOSITO [{0}] SE DEBE CONSIGNAR EL TIPO DE PUNTO DE LLEGADA [{1}]. INVALIDO PARA LA SERIE [{2}]");
				
			}
		}
	}
	
	/**
	 * Builder para punto de llegada
	 * @param codigoPuntoLlegada
	 * @return
	 */
	PuntoLlegadaValidador tipoPuntoLlegadaValidadorBuilder(String codigoPuntoLlegada) {
		if(CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO.equals(codigoPuntoLlegada) && flagEsDAMDiferidaSinICA){
			return new PuntoLlegadaTerminalPortuarioDAMSinICa(codigoAduanaTransmision, numeroRUCpuntoLlegada, fabricaDeServicios);
		//rtineo fin
		} else if (CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoTemporal(codigoAduanaTransmision, numeroRUCpuntoLlegada, opecomextDao,annManifiesto,codModTranspo,numManifiesto,
					manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans, fabricaDeServicios, manifiestoSigadService,
					circunoceDAO,ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL);
		} else if (CODIGO_PUNTO_LLEGADA_DEPOSITO_ADUANERO.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoAduanero(numeroRUCpuntoLlegada,  (java.util.Date)fechaReferencia);			
		}else if (CODIGO_PUNTO_LLEGADA_TERMINAL_PORTUARIO.equals(codigoPuntoLlegada)) { // SE ADICIONA CAMBIANDO TERMINAL FLUVIAL POR TERMINAL PORTUARIO
			return new PuntoLlegadaTerminalPortuario(numeroRUCpuntoLlegada, codigoAduanaTransmision);			
		}else if (CODIGO_PUNTO_LLEGADA_OTROS_PUNTOS_AUTORIZADOS.equals(codigoPuntoLlegada)) {
			return new OtroPuntoLlegadaAutorizado(numeroRUCpuntoLlegada);
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_CETICOS.equals(codigoPuntoLlegada)) {
			return new ceticoPuntoLlegada(numeroRUCpuntoLlegada);			
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL.equals(codigoPuntoLlegada)) {
			return new puntoLlegadaEquipajeInternacional(numeroRUCpuntoLlegada, codLocalAnexo);			
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DUTTY_FREE.equals(codigoPuntoLlegada)) {
			return new puntoLlegadaDuttyFree(numeroRUCpuntoLlegada, (java.util.Date)fechaReferencia);
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DMUA.equals(codigoPuntoLlegada)) {
			return new puntoLlegadaDMUA(numeroRUCpuntoLlegada,  (java.util.Date)fechaReferencia);			
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_AEROPUERTO.equals(codigoPuntoLlegada)) {
			return new puntoLlegadaAeropuerto(numeroRUCpuntoLlegada, codLocalAnexo);			
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_ERR.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoTemporal(codigoAduanaTransmision, numeroRUCpuntoLlegada, opecomextDao,annManifiesto,codModTranspo,numManifiesto,
					manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans,  fabricaDeServicios, manifiestoSigadService,
					circunoceDAO, ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_EER);
		} else if (ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DEPOSITO_TEMPORAL_POSTAL.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaDepositoTemporal(codigoAduanaTransmision, numeroRUCpuntoLlegada, opecomextDao,annManifiesto,codModTranspo,numManifiesto,
					manifiestoService,documentoOAManifiestoValidacionService,lstdocumentostrans, fabricaDeServicios, manifiestoSigadService,
					circunoceDAO, ConstantesDataCatalogo.TIPO_OPERADOR_DEPOSITO_TEMPORAL_POSTAL);
		} 
//		else if (CODIGO_PUNTO_LLEGADA_TERMINAL_FLUVIAL.equals(codigoPuntoLlegada)) { // inicio csantillan pase 4
//			return new PuntoLlegadaTerminalFluvial(numeroRUCpuntoLlegada, (java.util.Date) fechaReferencia);
//		} 
		else if (CODIGO_PUNTO_LLEGADA_CENTRO_ATENCION_FRONTERIZA.equals(codigoPuntoLlegada)) { //PAS20181U220200004
			return new PuntoLlegadaCentroAtencionFronteriza(numeroRUCpuntoLlegada, (java.util.Date) fechaReferencia);
		}else if (CODIGO_PUNTO_LLEGADA_ZOFRATACNA.equals(codigoPuntoLlegada)) {
			return new PuntoLlegadaZoFraTacna(numeroRUCpuntoLlegada, (java.util.Date) fechaReferencia); // csantillan pase 4
		}else {			
			throw new RuntimeException(
					"Error de Aplicacion. El tipo de punto de llegada no es valido, para la validacion del punto de llegada");
		}
	}

	
	
	@Override
	public void validar(Date fechaReferencia, String codAduana) throws PuntoLLegadaValidadorException {
		validarPuntoLlegada();		
	}
	
	
	
	/**
	 * Cuando el tipo de punto de llegada/almac�n aduanero corresponda a �Control de Equipajes Internacional�
	 * En las series se haya registrado como r�gimen precedente el Comprobante de custodia o Acta de Incautaci�n
	 * En las series no se consigne el documento de transporte
	 * R1780  del RIN22
	 * @param declaracion
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=2537)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2537,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidadorPuntoLlegadaMercanciaModalidadExcepcional")	
	public  List<Map<String, String>> validarEquipajeInternacionalPrecedencia(Declaracion declaracion) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		String codModTransp = declaracion.getDua().getManifiesto().getCodmodtransp();
		String codModalidad = declaracion.getDua().getCodmodalidad();
		if (SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) &&
			SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA)){			
			String codigoPuntoLLegadaMercancia =declaracion.getDua().getCodlugarecepcion()!=null?declaracion.getDua().getCodlugarecepcion().toString():"";
			if (SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_EQUIPAJE_INTERNACIONAL)){
				List<DatoSerie> listSeries = declaracion.getDua().getListSeries();
				for (DatoSerie datoSerieActual : listSeries) {
					CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
					String numeSerie = datoSerieActual.getNumserie().toString();
					//En las series se haya registrado como r�gimen precedente el Comprobante de custodia o Acta de Incautaci�n
					boolean tienePrecedencia= tienePrecedenciaParam(datoSerieActual, new String[]{ConstantesDataCatalogo.ACTA_RETENCION, ConstantesDataCatalogo.ACTA_INCAUTACION});						
					if (!tienePrecedencia){							
						String desPuntoLlegadacatalogo =  SunatStringUtils.toStringObj(catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_LUGAR_PUNTO_LLEGADA, codigoPuntoLLegadaMercancia).get("des_datacat"));
						String desRegimenPrecedente1   =  SunatStringUtils.toStringObj(catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, ConstantesDataCatalogo.ACTA_RETENCION).get("des_datacat"));
						String desRegimenPrecedente2   =  SunatStringUtils.toStringObj(catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, ConstantesDataCatalogo.ACTA_INCAUTACION).get("des_datacat"));
						listError.add(catalogoAyudaService.getError("37063", new String[] {desPuntoLlegadacatalogo, numeSerie, desRegimenPrecedente1, desRegimenPrecedente2}));							
					}
					//En las series no se consigne el documento de transporte
					DatoDocTransporte documentoTransporte = getDocTransporte(declaracion.getDua(), datoSerieActual);
					if (documentoTransporte!= null ){
						String numdocTransporte = documentoTransporte.getNumdoctransporte();
						if (!SunatStringUtils.isEmptyTrim(numdocTransporte)){
							listError.add(catalogoAyudaService.getError("37058", new String[] {datoSerieActual.getNumserie().toString(), numdocTransporte}));
						}
					}
				}
			}	
		}
		return listError;
	}

	
	/**
	 * Cuando el tipo de punto de llegada/almac�n aduanero corresponda a �Duty Free� 
	 * En las series se haya declarado como r�gimen precedente una declaraci�n de Duty Free
	 * R1781  del RIN22
	 * @param declaracion
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=2538)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2538,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidadorPuntoLlegadaMercanciaModalidadExcepcional")	
	public  List<Map<String, String>> validarDutyFreePrecedencia(Declaracion declaracion) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		String codModTransp = declaracion.getDua().getManifiesto().getCodmodtransp();
		String codModalidad = declaracion.getDua().getCodmodalidad();
		if (SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) &&
			SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA)){			
			String codigoPuntoLLegadaMercancia =declaracion.getDua().getCodlugarecepcion()!=null?declaracion.getDua().getCodlugarecepcion().toString():"";
			if (SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DUTTY_FREE)){
				List<DatoSerie> listSeries = declaracion.getDua().getListSeries();
				for (DatoSerie datoSerieActual : listSeries) {
					String numeSerie = datoSerieActual.getNumserie().toString();
					//En las series se haya registrado como r�gimen precedente el Comprobante de custodia o Acta de Incautaci�n
					boolean tienePrecedencia= tienePrecedenciaParam(datoSerieActual, new String[]{ConstantesDataCatalogo.REG_DUTY_FREE});						
					if (!tienePrecedencia){
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						String desPuntoLlegadacatalogo =  SunatStringUtils.toStringObj(catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_LUGAR_PUNTO_LLEGADA, codigoPuntoLLegadaMercancia).get("des_datacat"));
						String desRegimenPrecedente    =  SunatStringUtils.toStringObj(catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, ConstantesDataCatalogo.REG_DUTY_FREE).get("des_datacat"));
						listError.add(catalogoAyudaService.getError("37063", new String[] {desPuntoLlegadacatalogo, numeSerie, desRegimenPrecedente, " "}));							
					}
				}
			}		
		}
		return listError;
	}


	/**
	 * Cuando el tipo de punto de llegada/almac�n aduanero corresponda a �Material de Uso Aeron�utico� 
	 * En las series se haya declarado como r�gimen precedente una declaraci�n de Material de Uso Aeron�utico
	 * R1782  del RIN22
	 * @param declaracion
	 * @return
	 */
	@ServicioAnnot(tipo="V",codServicio=2539)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"declaracion"})
	@OrquestaDespaAnnot(codServInstancia=2539,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.puntollegada.ValidadorPuntoLlegadaMercanciaModalidadExcepcional")	
	public  List<Map<String, String>> validarDMUAPrecedencia(Declaracion declaracion) {
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		String codModTransp = declaracion.getDua().getManifiesto().getCodmodtransp();
		String codModalidad = declaracion.getDua().getCodmodalidad();
		if (SunatStringUtils.isEqualTo(codModalidad, ConstantesDataCatalogo.COD_MODALIDAD_EXCEPCIONAL) &&
			SunatStringUtils.isEqualTo(codModTransp, ConstantesDataCatalogo.VIA_TRANSPORTE_AEREA)){			
			String codigoPuntoLLegadaMercancia =declaracion.getDua().getCodlugarecepcion()!=null?declaracion.getDua().getCodlugarecepcion().toString():"";
			if (SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DMUA)){
				List<DatoSerie> listSeries = declaracion.getDua().getListSeries();
				for (DatoSerie datoSerieActual : listSeries) {
					String numeSerie = datoSerieActual.getNumserie().toString();
					//En las series se haya registrado como r�gimen precedente el DMUA
					boolean tienePrecedencia= tienePrecedenciaParam(datoSerieActual, new String[]{ConstantesDataCatalogo.REG_DMUA});						
					if (!tienePrecedencia){
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						String desPuntoLlegadacatalogo =  SunatStringUtils.toStringObj(catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_LUGAR_PUNTO_LLEGADA, codigoPuntoLLegadaMercancia).get("des_datacat"));
						String desRegimenPrecedente    =  SunatStringUtils.toStringObj(catalogoAyudaService.getElementoCat(ConstantesTipoCatalogo.CATALOGO_CODIGO_REGIMEN_ADUANERO, ConstantesDataCatalogo.REG_DMUA).get("des_datacat"));
						listError.add(catalogoAyudaService.getError("37063", new String[] {desPuntoLlegadacatalogo, numeSerie, desRegimenPrecedente, " "}));
					}
				}
			}			
		}
		return listError;
	}

	
	private boolean tienePrecedenciaParam(DatoSerie datoSerieActual, String[] catprecedencia){
		boolean tienePrecedencia=false;
		if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
			for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
				if(SunatStringUtils.include(datoRegPreActual.getCodregipre(), catprecedencia)){
					tienePrecedencia=true;
					break;
				}
			}
		}
		return tienePrecedencia;
	}
/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}