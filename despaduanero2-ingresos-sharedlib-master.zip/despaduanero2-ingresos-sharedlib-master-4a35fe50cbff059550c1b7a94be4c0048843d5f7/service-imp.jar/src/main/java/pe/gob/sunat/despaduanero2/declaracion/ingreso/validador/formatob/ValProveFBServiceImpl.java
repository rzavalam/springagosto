package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValProveFBServiceImpl extends ValParticipanteFB implements ValProveFB{
	
	
	
		/**
	 * Validar obligatoriamente que se haya transmitido el c�digo del tipo de participante 123 � 93
	 * @param dav
	 * @return map
	 * @Error 30117
	 * */
    public Map<String, String> codtipparticipante(DAV dav){

        if (!"93".equals(dav.getProveedor().getTipoParticipante().getCodDatacat())
                || dav.getProveedor().getTipoParticipante().getCodDatacat().isEmpty())

            return getErrorMap("30117",
                    new Object[] {	dav.getNumsecuprov(),
            						dav.getProveedor().getTipoParticipante().getCodDatacat()!=null?dav.getProveedor().getTipoParticipante().getCodDatacat():" "});

        Map<String, String> result = super.codtipparticipante(dav.getProveedor().getTipoParticipante());

        if (result != null)
            return getErrorMap("30117",
                    new Object[] { dav.getNumsecuprov(), dav.getProveedor().getTipoParticipante().getCodDatacat()!=null?dav.getProveedor().getTipoParticipante().getCodDatacat():" " });

        return new HashMap<String, String>();
    }	
    
    //glazaror... metodo optimizado
    @Override
    public Map<String, String> codtipparticipante(DAV dav, Map<String, Object> variablesIngreso) {
    	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        if (!"93".equals(dav.getProveedor().getTipoParticipante().getCodDatacat())
                || dav.getProveedor().getTipoParticipante().getCodDatacat().isEmpty()) {

        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*return getCatalogoHelper().getErrorMap("30117",
                    new Object[] {	dav.getNumsecuprov(),
            						dav.getProveedor().getTipoParticipante().getCodDatacat()!=null?dav.getProveedor().getTipoParticipante().getCodDatacat():" "});*/
        	
        	//glazaror... utilizamos catalogoAyudaService.getError
            String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String codigoTipoParticipante = (dav.getProveedor() != null && dav.getProveedor().getTipoParticipante() != null) ? dav.getProveedor().getTipoParticipante().getCodDatacat() : " ";
            
            return catalogoAyudaService.getError("30117",  new String[] {numeroSecuenciaProveedor, codigoTipoParticipante});
        }
        //glazaror... le pasamos como ultimo parametro variablesIngreso
        Map<String, String> result = super.codtipparticipante(dav.getProveedor().getTipoParticipante(), variablesIngreso);
        
        if (result != null) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*return getCatalogoHelper().getErrorMap("30117",
                    new Object[] { dav.getNumsecuprov(), dav.getProveedor().getTipoParticipante().getCodDatacat()!=null?dav.getProveedor().getTipoParticipante().getCodDatacat():" " });*/
        	
        	//glazaror... utilizamos catalogoAyudaService.getError
        	String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String codigoTipoParticipante = (dav.getProveedor() != null && dav.getProveedor().getTipoParticipante() != null) ? dav.getProveedor().getTipoParticipante().getCodDatacat() : " ";
            
            return catalogoAyudaService.getError("30117",  new String[] {numeroSecuenciaProveedor, codigoTipoParticipante});
        }

        return new HashMap<String, String>();
    }
	
	/**
	 * Validar C�digo de Tipo de Documento Identidad del Participante , se llama desde validarProveedor
	 * @param dav
	 * @return map
	 * @Error 30120
	 * */
    public Map<String, String> codtipdocparticipante(DAV dav){

        Map<String, String> result = super.codtipdocparticipante(dav.getProveedor().getTipoDocumentoIdentidad());
        //bug 17345 pase 105
        if (SunatStringUtils.isEmpty(dav.getProveedor().getNumeroDocumentoIdentidad()) && !SunatStringUtils.isEmpty(dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat()) && result != null )
        {
        	return getErrorMap("30756",
                    new Object[] { dav.getNumsecuprov()});
        }
//fin
		//inicio Pase 433 gmontoya Intermediario
		if(dav.getFlag()!=null){
			if (!dav.getFlag().equals("1") && !SunatStringUtils.isEmpty(dav.getProveedor().getNumeroDocumentoIdentidad()))//Pase 433 gmontoya Intermediario
        {
        
        	if (SunatStringUtils.isEmpty(dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat()) || result != null)
                return getErrorMap("30120",
                        new Object[] { dav.getNumsecuprov(), dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat()!=null?dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat():" " });
        				
        		
        }
		}else{//fin Pase 433 gmontoya Intermediario
			if (!SunatStringUtils.isEmpty(dav.getProveedor().getNumeroDocumentoIdentidad()))//Pase 433 gmontoya Intermediario
			{
			
				if (SunatStringUtils.isEmpty(dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat()) || result != null)
					return getErrorMap("30120",
							new Object[] { dav.getNumsecuprov(), dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat()!=null?dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat():" " });
							
        
			}
		}
      
        
        return new HashMap<String, String>();
    }
    
    //glazaror... metodo optimizado... se usa variablesIngreso
    @Override
    public Map<String, String> codtipdocparticipante(DAV dav, Map<String, Object> variablesIngreso) {
    	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        Map<String, String> result = super.codtipdocparticipante(dav.getProveedor().getTipoDocumentoIdentidad(), variablesIngreso);
        //bug 17345 pase 105
        if (SunatStringUtils.isEmpty(dav.getProveedor().getNumeroDocumentoIdentidad()) && !SunatStringUtils.isEmpty(dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat()) && result != null ) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
        	/*return getCatalogoHelper().getErrorMap("30756",
                    new Object[] { dav.getNumsecuprov()});*/
        	
        	//glazaror... utilizamos catalogoAyudaService.getError
        	String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            return catalogoAyudaService.getError("30756",  new String[] {numeroSecuenciaProveedor});
        }
        //fin
        if (!SunatStringUtils.isEmpty(dav.getProveedor().getNumeroDocumentoIdentidad())) {
        	if (SunatStringUtils.isEmpty(dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat()) || result != null) {
        		//glazaror... evitamos el uso de catalogoHelper.getErrorMap
                /*return getCatalogoHelper().getErrorMap("30120",
                        new Object[] { dav.getNumsecuprov(), dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat()!=null?dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat():" " });*/
        		
        		//glazaror... utilizamos catalogoAyudaService.getError
                String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
                String tipoDocumentoIdentidad = (dav.getProveedor() != null && dav.getProveedor().getTipoDocumentoIdentidad() != null) ? dav.getProveedor().getTipoDocumentoIdentidad().getCodDatacat() : " ";
                
                return catalogoAyudaService.getError("30120",  new String[] {numeroSecuenciaProveedor, tipoDocumentoIdentidad});
        	}
        }
        return new HashMap<String, String>();
    }
	
	@Override
	public Map<String, String> numdocparticipante(String arg) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		if( SunatStringUtils.isEmpty(arg) ) return new HashMap<String, String>();
		
		Map<String, String> result = super.numdocparticipante(arg);
		if(result != null) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			//return getCatalogoHelper().getErrorMap("30121");
			
			//glazaror... utilizamos catalogoAyudaService.getError
            return catalogoAyudaService.getError("30121");
		}
		
		return new HashMap<String, String>();
		
	}
	
	/**
	 * Validar obligatoriamente que se envie el c�digo del pa�s del proveedor
	 * @param dav
	 * @return map
	 * @Error 301222
	 */
	@Deprecated
	public Map<String, String> codpaisparticipante (DAV dav) {
		
		Map<String, String>  result = super.codpaisparticipante(dav.getProveedor().getPais());
		
		if(dav.getProveedor().getPais() == null || result != null )
			return getErrorMap("30122", new Object[]{
					dav.getNumsecuprov(),
					dav.getProveedor().getPais().getCodDatacat()!=null?dav.getProveedor().getPais().getCodDatacat():" "});
		
		return result = new HashMap<String, String>();
	}
	
	//glazaror... metodo optimizado
	@Override
	public Map<String, String> codpaisparticipante (DAV dav, Map<String, Object> variablesIngreso) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String>  result = super.codpaisparticipante(dav.getProveedor().getPais(), variablesIngreso);
		
		if(dav.getProveedor().getPais() == null || result != null ) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*return getCatalogoHelper().getErrorMap("30122", new Object[]{
					dav.getNumsecuprov(),
					dav.getProveedor().getPais().getCodDatacat()!=null?dav.getProveedor().getPais().getCodDatacat():" "});*/
			
			//glazaror... utilizamos catalogoAyudaService.getError
			String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String pais = (dav.getProveedor() != null && dav.getProveedor().getPais() != null) ? dav.getProveedor().getPais().getCodDatacat() : " ";
            return catalogoAyudaService.getError("30122",  new String[] {numeroSecuenciaProveedor, pais});
		}
		
		return result = new HashMap<String, String>();
	}
	
	/**
	 * Validar obligatoriamente  que envie la direcci�n del proveedor con una longitud de minimo 10 caracteres
	 * @param dav
	 * @return map
	 * @Error 30123
	 */
	public Map<String, String> dirparticipante (DAV dav) {
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String, String>  result = super.dirparticipante(dav.getProveedor().getDireccion());
		
		if(dav.getProveedor().getDireccion()==null || result != null ) {
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*return getCatalogoHelper().getErrorMap("30123", new Object[]{
					dav.getNumsecuprov(),
					dav.getProveedor().getDireccion().trim()!=null?dav.getProveedor().getDireccion().trim():" "});*/
			
			//glazaror... utilizamos catalogoAyudaService.getError
            String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String direccionProveedor = (dav.getProveedor() != null && dav.getProveedor().getDireccion() != null) ? dav.getProveedor().getDireccion().trim() : " ";
            return catalogoAyudaService.getError("30123",  new String[] {numeroSecuenciaProveedor, direccionProveedor});
		}
		
		return result = new HashMap<String, String>();
	}
	
	/**
	 * Validar obligatoriamente que envie la ciudad del proveedor con una longitud de minima 2 caracteres.
	 * @param dav
	 * @return map
	 * @Error 30124
	 */	
    public Map<String, String> desubigparticipante(DAV dav){
    	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        Map<String, String> result = super.desubigparticipante(dav.getProveedor().getCiudad());

        if ((dav.getProveedor().getCiudad() == null) || (result != null)) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*return getCatalogoHelper().getErrorMap("30124", new Object[]{
					dav.getNumsecuprov(),
					dav.getProveedor().getCiudad().trim()!=null?dav.getProveedor().getCiudad():" "});*/
        	
        	//glazaror... utilizamos catalogoAyudaService.getError
        	String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String ciudadProveedor = (dav.getProveedor() != null) ? dav.getProveedor().getCiudad() : " ";
            return catalogoAyudaService.getError("30124",  new String[] {numeroSecuenciaProveedor, ciudadProveedor});
        }
        
        
        return result = new HashMap<String, String>();

    }	
	
	/**
	 * Validar obligatoriamente que se envie el telefono del proveedor, el dato declarado puede contener n�meros, guiones, par�ntesis, signo + y espacio.
	 * @param dav
	 * @return map
	 * @Error 30125
	 */	
    public Map<String, String> numtelefono(DAV dav){
    	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        Map<String, String> result = super.numtelefono(dav.getProveedor().getTelefono());

        if (dav.getProveedor().getTelefono() == null || result != null) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*return getCatalogoHelper().getErrorMap("30125",
                    new Object[] { dav.getNumsecuprov(),
            		dav.getProveedor().getTelefono()!=null? dav.getProveedor().getTelefono():" "});*/
        	
        	//glazaror... utilizamos catalogoAyudaService.getError
            String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String telefonoProveedor = (dav.getProveedor() != null) ? dav.getProveedor().getTelefono() : " ";
            return catalogoAyudaService.getError("30125",  new String[] {numeroSecuenciaProveedor, telefonoProveedor});
        }
        return result = new HashMap<String, String>();
    }
	
	/**
	 * Validar opcionalmente que se haya transmitido el fax del proveedor, el dato declarado puede contener n�meros, guiones, par�ntesis, signo + y espacio
	 * @param dav
	 * @return map
	 * @Error 30126
	 */
    public Map<String, String> numfax(DAV dav){
    	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        Map<String, String> result = super.numfax(dav.getProveedor().getFax());
        if (result != null) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*return getCatalogoHelper().getErrorMap("30126",
                    new Object[] { dav.getNumsecuprov(), dav.getProveedor().getFax() });*/
        	
        	//glazaror... utilizamos catalogoAyudaService.getError
            String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String faxProveedor = (dav.getProveedor() != null) ? dav.getProveedor().getFax() : " ";
            return catalogoAyudaService.getError("30126",  new String[] {numeroSecuenciaProveedor, faxProveedor});
        }

        return new HashMap<String, String>();

    }
	
	/**
	 * Validar opcionalmente que se haya transmitido el email del proveedor, debe contener el caracter @, el �.� y su longitud debe ser mayor a 4 caracteres.
	 * @param dav
	 * @return map
	 * @Error 30127
	 */
    public Map<String, String> dirmailweb(DAV dav){
        Map<String, String> result = super.dirmailweb(dav.getProveedor().getEmail());
        if (result != null) {
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*return getCatalogoHelper().getErrorMap("30127",
                    new Object[] { 
                    dav.getNumsecuprov(), 
                    dav.getProveedor().getEmail()});*/
        	
        	//glazaror... utilizamos catalogoAyudaService.getError
            String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String emailProveedor = (dav.getProveedor() != null) ? dav.getProveedor().getEmail() : " ";
            return catalogoAyudaService.getError("30127",  new String[] {numeroSecuenciaProveedor, emailProveedor});
        	
        }

        return result = new HashMap<String, String>();
    }
	
	
	
	/**
	 * Validar opcionalmente que se haya transmitido la direccion web del proveedor, el dato debe tener una longitud mayor a los 4 caracteres.
	 * @param dav
	 * @return map
	 * @Error 30128	 
	 */
    public Map<String, String> dirpagweb(DAV dav){

        Map<String, String> result = super.dirpagweb(dav.getProveedor().getPaginaWeb());

        if (result != null) {
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*return getCatalogoHelper().getErrorMap("30128",
                    new Object[] { 
                    dav.getNumsecuprov(), 
                    dav.getProveedor().getPaginaWeb()});*/
        	
        	//glazaror... utilizamos catalogoAyudaService.getError
            String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String paginaWebProveedor = (dav.getProveedor() != null) ? dav.getProveedor().getPaginaWeb() : " ";
            return catalogoAyudaService.getError("30128",  new String[] {numeroSecuenciaProveedor, paginaWebProveedor});
        }

        return result = new HashMap<String, String>();
    }
	
	/**
	 * Validar que si no se encontro el c�digo de proveedor (codproveedor del
	 * segmento DAVs) en la tabla respectiva, debe enviar alg�n valor en el
	 * campo nomparticipante (longitud mayor a 5 caracteres), sino generar el
	 * mensaje de error 5508. 
	 * Adem�s validar que si ya existe el nombre del proveedor para el pais enviado se genere el mensaje de error 5669. 
	 * Si encontro el c�digo de proveedor en la tabla respectiva y el nombre del
	 * proveedor enviado es diferente al de la tabla (CNOMB_PROV) se genera el
	 * mensaje de advertencia 9075
	 * 
	 * Validar obligatoriamente que haya transmitido el nombre o razon social del proveedor.
	 * @param dav
	 * @return map
	 * @Erro 05524
	 */
   public Map<String, String> nomparticipante(DAV dav){
        Map<String, String> result = new HashMap<String, String>();
        if (dav.getProveedor().getNombreRazonSocial() == null
                || !SunatStringUtils.isLengthGreaterThanNumber(dav.getProveedor().getNombreRazonSocial().trim(), 4)) {
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*result = catalogoHelper.getErrorMap("05524", 
                    new Object[] { 
                    dav.getNumsecuprov(),
                    dav.getProveedor().getNombreRazonSocial().trim()!=null? dav.getProveedor().getNombreRazonSocial().trim():" "});*/
            
            //glazaror... utilizamos catalogoAyudaService.getError
            String numeroSecuenciaProveedor = (dav.getNumsecuprov() != null) ? dav.getNumsecuprov().toString() : " ";
            String razonSocialProveedor = (dav.getProveedor() != null && dav.getProveedor().getNombreRazonSocial() != null) ? dav.getProveedor().getNombreRazonSocial().trim() : " ";
            result = catalogoAyudaService.getError("05524",  new String[] {numeroSecuenciaProveedor, razonSocialProveedor});
        }

        return result;
    }
}
