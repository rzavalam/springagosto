package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

//import org.springframework.aop.target.HotSwappableTargetSource;

import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Depocta;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Polizad;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.Seriesd;
import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.DepoctaDAO;
//import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.DepoctaDAO;
//import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.PolizadDAO;
//import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.SeriesdDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.RitCc;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.RitPit;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.RitSer;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.RitCcDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.RitSerDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.RitpitDAO;
//import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.RitCcDAO;
//import pe.gob.sunat.despaduanero.despacho.entrada.ti.model.dao.RitSerDAO;
import pe.gob.sunat.despaduanero.despacho.especial.ct.model.TrasladoCetico;
import pe.gob.sunat.despaduanero.despacho.especial.ct.model.TrasladoSeriesCetico;
//import pe.gob.sunat.despaduanero.despacho.especial.ct.model.dao.TrasladoCeticoDAO;
//import pe.gob.sunat.despaduanero.despacho.especial.ct.model.dao.TrasladoSeriesCeticoDAO;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.sigad.despacho.especial.service.TrasladoCeticoService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionDepositoAduaneroService;



public class RegimenesPrecedentesServiceImpl extends IngresoAbstractServiceImpl implements RegimenesPrecedentesService {

	//private PolizadDAO polizadDAO;
	//private SeriesdDAO seriesdDAO;
	//private DepoctaDAO depoctaDAO;
	//private RitpitDAO ritpitDAO;
	//private RitSerDAO ritSerDAO;
	//private RitCcDAO ritCcDAO;
	//private CabDeclaraDAO cabDeclaraDAO;
	//private TrasladoCeticoDAO trasladoCeticoDAO;
	//private TrasladoSeriesCeticoDAO trasladoSeriesCeticoDAO;
	
	//FabricaDeServicios fabricaDeServicios;
	//HotSwappableTargetSource swapperDatasource;
	
	
	/*
	  Para verificar que la Declaraci�n Precedente exista y que que no est� vencida.
	  Recibe como mar�metro un mapa on los campos:
	  declaracion.get("COD_ADUANAPRE")
	  declaracion.get("COD_REGIMENPRE")
	  declaracion.get("ANN_PRESENPRE")
	  declaracion.get("NUM_DECLARACIONPRE")
	  
	  y devuelve como resultado un Map con los siguientes datos:
	  Para el r�gimen 70:
	  String VALIDADO: Puede ser "S" o "N" si ha realizado la validaci�n o no
	  String EXISTE: Puede ser "S" o "N" si existe o no existe la DUA
	  String ESTADO: " " no anulado, "A" anulado
	  Date FEC_VENCI: la fecha de vencimiento de la DUA
	  
	  Para el r�gimen 20:
	  String VALIDADO: Puede ser "S" o "N" si ha realizado la validaci�n o no
	  String EXISTE: Puede ser "S" o "N" si existe o no existe la DUA
	  String ESTADO: Estado de la Imp. Temporal, sacado del campo Spit
	  String TFERIA: Tipo de fer�a.
	  String CFERIA: C�digo de fer�a.
	  
	  Para el r�gimen 91:
	  String VALIDADO: Puede ser "S" o "N" si ha realizado la validaci�n o no
	  String EXISTE: Puede ser "S" o "N" si existe o no existe el traslado
	  String ESTADO: Estado del traslado, sacado del campo cestado
	  */	
	@SuppressWarnings("unchecked")
	public Map<String, ?> verificarDeclacionPrecente(Map declaracion){
		HashMap resultado = new HashMap();	
		Date fecVenci = null;
		Date fecNumera = null;
		Date fecVista = null;
		resultado.put("VALIDADO", "N");
		resultado.put("EXISTE", "N");
		resultado.put("ESTADO", " ");
		resultado.put("FEC_VENCI", fecVenci);
		resultado.put("TFERIA", " ");
		resultado.put("CFERIA", " ");
		resultado.put("FEC_NUMERA", fecNumera);
		resultado.put("TIPO_AFORO", " ");
		resultado.put("FEC_VISTA", fecVista);
		resultado.put("SALDADA", "N");
		
		Map<String, Object> duaPrece = new HashMap<String, Object>();
		
		if (declaracion.get("COD_REGIMENPRE").equals("70")) { // Para Dep�sito
			//PolizadDAO polizadDAO = fabricaDeServicios.getService("polizadDAO");
			
			ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService =fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
			
			resultado.put("VALIDADO", "S");
			duaPrece.put("codiAduan", declaracion.get("COD_ADUANAPRE"));
			duaPrece.put("anoPrese", declaracion.get("ANN_PRESENPRE").toString().substring(2, 4));
			duaPrece.put("numeCorre", Cadena.padLeft(declaracion.get("NUM_DECLARACIONPRE").toString(), 6, '0'));
			//List<Polizad> lstPolizad = polizadDAO.selectByMap(duaPrece);
			List<Polizad> lstPolizad = consultaDeclaracionDepositoAduaneroService.consultarDeclaracionDeposito(duaPrece, SunatStringUtils.toStringObj(declaracion.get("COD_ADUANAPRE")));
			if (lstPolizad==null || lstPolizad.size()==0) {
				return resultado;
			} else {
				resultado.put("EXISTE", "S");
				Polizad polizad = lstPolizad.get(0);
				if (!(polizad.getPoliAnula().trim().equals(""))) {
					resultado.put("ESTADO", "A");
				}
				Integer lnTipoPlazo = 0;
				if (polizad.getPautoTipo()>polizad.getPlazoTipo()) {
					lnTipoPlazo = polizad.getPautoTipo();
				} else {
					lnTipoPlazo = polizad.getPlazoTipo();
				}
				Integer lnPlazoNum = 0;
				if (polizad.getPautoNum()>polizad.getPlazoNum()) {
					lnPlazoNum = polizad.getPautoNum();
				} else {
					lnPlazoNum = polizad.getPlazoNum();
				}
				Integer lnPlazoDias = 0;
				if (lnTipoPlazo==1) {
					lnPlazoDias = lnPlazoNum*30;
				} else {
					lnPlazoDias = lnPlazoNum;
				}
				Integer lnFecInicio = 0;
				if (polizad.getFechIncer()==0) {
					lnFecInicio = polizad.getFechIngsi();
				} else {
					lnFecInicio = polizad.getFechIncer();
				}
				if (polizad.getFechTecer()==0) {
					String stFecha = (new FechaBean(lnFecInicio.toString(),"yyyyMMdd")).getFormatDate("dd/MM/yyyy");
					String tmpDate = new FechaBean().getOtraFecha(stFecha, "yyyyMMdd", lnPlazoDias, Calendar.DATE);
					fecVenci = (new FechaBean(tmpDate,"yyyyMMdd")).getSQLDate();
				} else {
					fecVenci = new FechaBean(polizad.getFechTecer().toString(), "yyyyMMdd").getSQLDate();
				}
				if (polizad.getFechIngsi()==0) {
					fecNumera = (new FechaBean(polizad.getFechIngsi().toString(),"yyyyMMdd")).getSQLDate();
				} else {
					fecNumera = new FechaBean("00010101", "yyyyMMdd").getSQLDate();
				}
				if (polizad.getFechVista()==0) {
					fecVista = (new FechaBean(polizad.getFechVista().toString(),"yyyyMMdd")).getSQLDate();
				} else {
					fecVista = new FechaBean("00010101", "yyyyMMdd").getSQLDate();
				}
				if (polizad.getFechCance()>0) {
					resultado.put("SALDADA", "S");
				}
				resultado.put("FEC_VENCI", fecVenci);
				resultado.put("FEC_NUMERA", fecNumera);
				resultado.put("TIPO_AFORO", polizad.getTipoAforo());
				resultado.put("FEC_VISTA", fecVista);
			}
			
		} else if (declaracion.get("COD_REGIMENPRE").equals("20")) {
			//RitpitDAO ritpitDAO = fabricaDeServicios.getService("declaracion.ritpitDAO");
			RitpitDAO  ritpitDAO=fabricaDeServicios.getService("despacho.entrada.ritpitDef");
			DataSourceContextHolder.setKeyDataSource(declaracion.get("COD_ADUANAPRE").toString());
			resultado.put("VALIDADO", "S");
			RitPit ritPit = ritpitDAO.selectByPrimaryKey(declaracion.get("COD_ADUANAPRE").toString(), 
					declaracion.get("ANN_PRESENPRE").toString(), 
					Integer.parseInt(declaracion.get("NUM_DECLARACIONPRE").toString()));
			if (ritPit==null) {
				return resultado;
			}
			resultado.put("EXISTE", "S");
			resultado.put("ESTADO", ritPit.getSpit());
			resultado.put("FEC_VENCI", fecVenci);
			resultado.put("TFERIA", ritPit.getTferia());
			resultado.put("CFERIA", ritPit.getCferia());
			if (ritPit.getFnumera()==0) {
				fecNumera = new FechaBean("00010101", "yyyyMMdd").getSQLDate();
			} else {
				fecNumera = (new FechaBean(ritPit.getFnumera().toString(),"yyyyMMdd")).getSQLDate();
			}
			resultado.put("FEC_NUMERA", fecNumera);
			
		} else if (declaracion.get("COD_REGIMENPRE").equals("91")) {
			if (declaracion.get("COD_ADUANAPRE")!=null && (SunatStringUtils.isStringInList(declaracion.get("COD_ADUANAPRE").toString(), "046,145,163,172"))) {
				TrasladoCeticoService trasladoCeticoService = fabricaDeServicios.getService("sigad.despacho.especial.service.trasladoCeticoService");
				//TrasladoCeticoDAO trasladoCeticoDAO = fabricaDeServicios.getService("trasladoCeticoDAO");
				resultado.put("VALIDADO", "S");
				//TrasladoCetico trasladoCetico = trasladoCeticoDAO.selectByPrimaryKey(declaracion.get("COD_ADUANAPRE").toString(),
				TrasladoCetico trasladoCetico = trasladoCeticoService.selectTrasladoCeticoByPk(declaracion.get("COD_ADUANAPRE").toString(), 
						declaracion.get("ANN_PRESENPRE").toString(), 
						Cadena.padLeft(declaracion.get("NUM_DECLARACIONPRE").toString(), 6, '0'));
				if (trasladoCetico==null) {
					return resultado;
				}
				resultado.put("EXISTE", "S");
				resultado.put("ESTADO", trasladoCetico.getCestado());
			}
		}
		return resultado;
	}
	
	/*
	  Para verificar que la Declaraci�n Precedente exista y que que no est� vencida.
	  Recibe como mar�metro un mapa on los campos:
	  declaracion.get("COD_ADUANAPRE")
	  declaracion.get("COD_REGIMENPRE")
	  declaracion.get("ANN_PRESENPRE")
	  declaracion.get("NUM_DECLARACIONPRE")
	  
	  y devuelve como resultado:
	  String RESULTADO: Si est� vac�o no hay error, sino devolver� el mensaje de error.
	  */	
	@SuppressWarnings("unchecked")
	public String validaDeclacionPrecente(Map declaracion){	
		//swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds."+declaracion.get("COD_ADUANAPRE").toString().trim()));
		
		String regimen = declaracion.get("COD_REGIMENPRE").toString();
		
		Map<String, ?> mapRegpre = verificarDeclacionPrecente(declaracion);
		if (mapRegpre.get("VALIDADO").equals("S")) {
			if (mapRegpre.get("EXISTE").equals("N")) {
				return "No existe Declaracion precedente";
			} else {
				if (mapRegpre.get("ESTADO").equals("A")) {
					return "Declaracion precedente anulada";
				}
			}
			if ("70".equals(regimen) && mapRegpre.get("TIPO_AFORO").equals("F") && ((Date)mapRegpre.get("FEC_VISTA")).equals(new FechaBean("00010101", "yyyyMMdd").getSQLDate())) {
				return "DUA no ha sido diligenciada";
			} else if ("70".equals(regimen) && mapRegpre.get("SALDADA").equals("S")) {
				return "DUA ya no tiene saldo por regularizar";
			}
		}
		
		mapRegpre = verificarSaldo(declaracion);
		if (mapRegpre.get("VALIDADO").equals("S")) {
			if (mapRegpre.get("EXISTE").equals("N")) {
				return "No existe serie precedente";
			} else if ("70".equals(regimen) && ((BigDecimal)mapRegpre.get("SALDO_PESO")).compareTo((BigDecimal)declaracion.get("CNT_PESO_BRUTO"))<0 ) {
				return "Serie de la DUA precedente no tiene saldo en Peso para descargar";
			} else if ("70".equals(regimen) && ((BigDecimal)mapRegpre.get("SALDO_UNID")).compareTo((BigDecimal)declaracion.get("CNT_UNIFIS"))<0 ) {
				return "Serie de la DUA precedente no tiene saldo en Unidades f�sicas para descargar";
			}
		}
		return "";
	}
	
	/*
  	Para verificar la queda saldo por regularizar (por serie)
  	Recibe como mar�metro un mapa on los campos:
	  serieDeclaracion.get("COD_ADUANAPRE")
	  serieDeclaracion.get("COD_REGIMENPRE")
	  serieDeclaracion.get("ANN_PRESENPRE")
	  serieDeclaracion.get("NUM_DECLARACIONPRE")
	  serieDeclaracion.get("NUM_SECSERIEPRE")
	  Estos par�metros son condicionales, se usan para la rectificaci�n, para descontar lo saldado por la misma DUA
	  serieDeclaracion.get("NUM_CORREDOC")
	  serieDeclaracion.get("NUM_SECSERIE")

	  
	  y devuelve como resultado un Map con los siguientes datos:
	  Para 70:
	  String VALIDADO: Puede ser "S" o "N" si ha realizado la validaci�n o no
	  String EXISTE: Puede ser "S" o "N" si existe o no existe la serie de la DUA
	  BigDecimal SALDO_PESO: Saldo en peso
	  BigDecimal SALDO_UNID: Saldo en unidades f�sicas
	  Para 91:
	  String VALIDADO: Puede ser "S" o "N" si ha realizado la validaci�n o no
	  String EXISTE: Puede ser "S" o "N" si existe o no existe la serie de la DUA
	  BigDecimal SALDO_UNID: Saldo en unidades f�sicas
	  Integer FRECI_CETI: Fecha de recepci�n del Cetico
	  String UNIFI_UM: Tipo de unidades f�sicas
	  String CHASIS: Chasis del veh�culo
	  String MERCANCIA: Descripci�n de la mercanc�a
  */	
	@SuppressWarnings("unchecked")
	public Map<String, ?> verificarSaldo(Map serieDeclaracion){
		Map resultado = new HashMap();	
		BigDecimal saldoPeso = new BigDecimal("0");
		BigDecimal saldoUnid = new BigDecimal("0");
		resultado.put("VALIDADO", "N");
		resultado.put("EXISTE", "N");
		resultado.put("SALDO_PESO", saldoPeso);
		resultado.put("SALDO_UNID", saldoUnid);
		resultado.put("FRECI_CETI", Integer.valueOf("0"));
		resultado.put("UNIFI_UM", " ");
		resultado.put("CHASIS", " ");
		resultado.put("MERCANCIA", " ");

		Map serPrece = new HashMap();
		BigDecimal lnPesoDesc = new BigDecimal("0");
		BigDecimal lnUnidDesc = new BigDecimal("0");
		
		if (serieDeclaracion.get("COD_REGIMENPRE").equals("70")) { // Para Dep�sito
			//SeriesdDAO seriesdDAO = fabricaDeServicios.getService("seriesdDAO");
			ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService =fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
			resultado.put("VALIDADO", "S");
			serPrece.put("codiAduan", serieDeclaracion.get("COD_ADUANAPRE"));
			serPrece.put("anoPrese", serieDeclaracion.get("ANN_PRESENPRE").toString().substring(2, 4));
			serPrece.put("numeCorre", Cadena.padLeft(serieDeclaracion.get("NUM_DECLARACIONPRE").toString(), 6, '0'));
			serPrece.put("numeSerpr", Cadena.padLeft(serieDeclaracion.get("NUM_SECSERIEPRE").toString().trim(), 4, ' ')); // En el PL USAMTG00.Sptd_Ctactedeposito se usa numeSerpr
			serPrece.put("sdel", " ");
			//Seriesd seriesd = seriesdDAO.selectByPrimaryKey(serieDeclaracion.get("ANN_PRESENPRE").toString().substring(2, 4), 
			Seriesd seriesd = consultaDeclaracionDepositoAduaneroService.consultarSerieDeposito (serieDeclaracion.get("ANN_PRESENPRE").toString().substring(2, 4),
					serieDeclaracion.get("COD_ADUANAPRE").toString(),  
					Cadena.padLeft(serieDeclaracion.get("NUM_DECLARACIONPRE").toString().trim(), 6, '0'),
					Cadena.padLeft(serieDeclaracion.get("NUM_SECSERIEPRE").toString().trim(), 4, ' '));
			if (seriesd==null) {
				return resultado;
			} else {
				resultado.put("EXISTE", "S");
			}
			DepoctaDAO depoctaDAO = fabricaDeServicios.getService("despacho.entrada.depoctaDef");
			DataSourceContextHolder.setKeyDataSource(serieDeclaracion.get("COD_ADUANAPRE").toString());
			//DepoctaDAO depoctaDAO = fabricaDeServicios.getService("depoctaDAO");
			List<Depocta> lstDepocta = depoctaDAO.findByMap(serPrece);
			for (Depocta depocta : lstDepocta) {
				if (!(Integer.valueOf(serieDeclaracion.get("NUM_DECLARACION").toString()).equals(Integer.valueOf(depocta.getNumePoliz()))
						&& serieDeclaracion.get("COD_REGIMEN").equals(depocta.getRegiPoliz())
						&& Integer.valueOf(serieDeclaracion.get("NUM_SECSERIE").toString()).equals(Integer.valueOf(depocta.getNumeSerie())))) {
					lnPesoDesc = lnPesoDesc.add(depocta.getPesoBruto());
					lnUnidDesc = lnUnidDesc.add(depocta.getUnidFiqty());
				}
			}
			if (seriesd.getPesoBrafo().compareTo(lnPesoDesc)>0) {
				saldoPeso = seriesd.getPesoBrafo().subtract(lnPesoDesc);
				resultado.put("SALDO_PESO", saldoPeso);
			}
			if (seriesd.getUnidFiqty().compareTo(lnUnidDesc)>0) {
				saldoUnid = seriesd.getUnidFiqty().subtract(lnUnidDesc);
				resultado.put("SALDO_UNID", saldoUnid);
			}
			
		} else if (serieDeclaracion.get("COD_REGIMENPRE").equals("91")) { // Traslados a CETICOS
			if (serieDeclaracion.get("COD_ADUANAPRE")!=null && (SunatStringUtils.isStringInList(serieDeclaracion.get("COD_ADUANAPRE").toString(), "046,145,163,172"))) {
				//TrasladoSeriesCeticoDAO trasladoSeriesCeticoDAO = fabricaDeServicios.getService("trasladoSeriesCeticoDAO");
				TrasladoCeticoService trasladoCeticoService = fabricaDeServicios.getService("sigad.despacho.especial.service.trasladoCeticoService");
				
				resultado.put("VALIDADO", "S");
				//TrasladoSeriesCetico trasladoSeriesCetico = trasladoSeriesCeticoDAO.selectByPrimaryKey(serieDeclaracion.get("COD_ADUANAPRE").toString(), 
				TrasladoSeriesCetico trasladoSeriesCetico = trasladoCeticoService.selectSerieTrasladoCeticoByPk(serieDeclaracion.get("COD_ADUANAPRE").toString(),
						serieDeclaracion.get("ANN_PRESENPRE").toString(), 
						Cadena.padLeft(serieDeclaracion.get("NUM_SECSERIEPRE").toString().trim(), 4, ' '), 
						Cadena.padLeft(serieDeclaracion.get("NUM_DECLARACIONPRE").toString(), 6, '0'));
				if (trasladoSeriesCetico==null) {
					return resultado;
				} 
				resultado.put("EXISTE", "S");
				resultado.put("SALDO_UNID", trasladoSeriesCetico.getSaldo());
				resultado.put("FRECI_CETI", trasladoSeriesCetico.getFreciCeti());
				resultado.put("UNIFI_UM", trasladoSeriesCetico.getUnifiUm());
				resultado.put("UNIFI_UM", trasladoSeriesCetico.getUnifiUm());
				resultado.put("CHASIS", trasladoSeriesCetico.getChasis());
				resultado.put("MERCANCIA", trasladoSeriesCetico.getMercancia());
			}
		} else if (serieDeclaracion.get("COD_REGIMENPRE").equals("20")) { // Importaci�n Temporal
			//RitSerDAO ritSerDAO = fabricaDeServicios.getService("despacho.entrada.ritSerDef");
			RitSerDAO  ritSerDAO=fabricaDeServicios.getService("despacho.entrada.ritSerDef");
			DataSourceContextHolder.setKeyDataSource(serieDeclaracion.get("COD_ADUANAPRE").toString());
			resultado.put("VALIDADO", "S");
			RitSer ritSer = ritSerDAO.selectByPrimaryKey(serieDeclaracion.get("COD_ADUANAPRE").toString(), 
					serieDeclaracion.get("ANN_PRESENPRE").toString(), 
					Integer.parseInt(serieDeclaracion.get("NUM_DECLARACIONPRE").toString()), 
					Integer.parseInt(serieDeclaracion.get("NUM_SECSERIEPRE").toString()));
			if (ritSer==null) {
				return resultado;
			}
			BigDecimal lnAnterior = new BigDecimal("0");
			if (serieDeclaracion.get("NUM_CORREDOC")!=null && serieDeclaracion.get("NUM_SECSERIE")!=null) {
				CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
				RitCcDAO ritCcDAO = fabricaDeServicios.getService("ritccDAO");
				
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("numeroCorrelativo", Long.valueOf(serieDeclaracion.get("NUM_CORREDOC").toString()).longValue());
				DUA dua = cabDeclaraDAO.selectByNumCorredoc(params);
				RitCc ritCc = ritCcDAO.selectByPrimaryKey(dua.getCodaduanaorden(), 
						serieDeclaracion.get("COD_ADUANAPRE").toString(), 
						dua.getAnnpresen().toString(), 
						serieDeclaracion.get("ANN_PRESENPRE").toString(), 
						Integer.parseInt(serieDeclaracion.get("NUM_DECLARACIONPRE").toString()), 
						Integer.parseInt(dua.getNumdocumento()), 
						Integer.parseInt(serieDeclaracion.get("NUM_SECSERIE").toString().trim()), 
						Integer.parseInt(serieDeclaracion.get("NUM_SECSERIEPRE").toString().trim()), "NA");
				if (ritCc!=null) {
					lnAnterior = ritCc.getVunifistra();
				}
			}
			resultado.put("EXISTE", "S");
			resultado.put("SALDO_UNID", ritSer.getMsaldo().subtract(lnAnterior)); // Se resta porque es negativo
		}
		
		return resultado;
	}

         /**
	 * {@inheritDoc}
	 */
	public List<Object> obtenerDeclaracionPrecedenteDeposito(DUA dua){
		List<Object> listObject = new ArrayList<Object>();
		for (DatoSerie datoSerieActual : dua.getListSeries()) {
			if (datoSerieActual.getListRegPrecedencia()!=null && datoSerieActual.getListRegPrecedencia().size()>0){
				for (DatoRegPrecedencia datoRegPreActual : datoSerieActual.getListRegPrecedencia()) {
					if (datoRegPreActual.getCodregipre().equals(ConstantesDataCatalogo.REG_DEPOSITO)){
						if (!buscaPrecedente(listObject, datoRegPreActual)){
							listObject.add(cargaPrecedente(datoRegPreActual));
						}						
						break;
					}
				}
			}   
		}
		return listObject;
	}
	
	/**
	 * Por cada declaracion precedente se busca en el SDA, sino existe se busca en el SIGAD
	 * y se devuelve la informaci�n como un objeto 
	 * @param duaprecedente
	 * @return
	 */
	
	private Object cargaPrecedente( DatoRegPrecedencia duaprecedente){
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDAO");
		//PolizadDAO polizadDAO = fabricaDeServicios.getService("polizadDAO");
		ConsultaDeclaracionDepositoAduaneroService consultaDeclaracionDepositoAduaneroService =fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionDepositoAduaneroService");
		
		Map<String,Object> paramsDeclaracion=new HashMap<String,Object>();
		paramsDeclaracion.put("codigoRegimen", duaprecedente.getCodregipre());
		paramsDeclaracion.put("codigoAduana", duaprecedente.getCodaduapre());
		paramsDeclaracion.put("annoPresentacion", new Integer(duaprecedente.getAnndeclpre().substring(0, 4)));
		paramsDeclaracion.put("numeroDeclaracion", new Integer(duaprecedente.getNumdeclpre().toString()));				
		DUA dua = cabDeclaraDAO.findDUAByKeyMap(paramsDeclaracion);
		if (dua == null){
			Map<String,Object> paramsPolizad=new HashMap<String,Object>();
			paramsPolizad.put("anoPrese", duaprecedente.getAnndeclpre().substring(2, 4));
			paramsPolizad.put("codiAduan", duaprecedente.getCodaduapre());
			paramsPolizad.put("numeCorre", SunatStringUtils.lpad(duaprecedente.getNumdeclpre(),6,'0'));
			//List<Polizad> lstPolizad = polizadDAO.selectByMap(paramsPolizad);
			List<Polizad> lstPolizad = consultaDeclaracionDepositoAduaneroService.consultarDeclaracionDeposito(paramsPolizad, SunatStringUtils.toStringObj(duaprecedente.getCodaduapre()));
			return lstPolizad.isEmpty()?lstPolizad:lstPolizad.get(0);
		}
		return dua;
	}
	
        
	/**
	 * Consulta si en la lista de objetos de declaraciones precedentes ya se registro o almacen� algun registro
	 * @param listObject
	 * @param duaprecedente
	 * @return
	 */
	private boolean buscaPrecedente(List<Object> listObject, DatoRegPrecedencia duaprecedente){
		boolean encontro = false;
		for (ListIterator<Object> iterador = listObject.listIterator(); iterador.hasNext();) {
			Object elemento = iterador.next();
			if (elemento instanceof DUA) {
				DUA dua =  (DUA)  elemento;
				//Validar si tiene 0 a la izquierda y lo del ano a 4 0 2 digitos
				if (duaprecedente.getCodaduapre().equals(dua.getCodaduanaorden()) &&
					duaprecedente.getAnndeclpre().substring(0, 4).equals(dua.getAnnpresen()) &&
					duaprecedente.getCodregipre().equals(dua.getCodregimen()) &&
					duaprecedente.getNumdeclpre().equals(SunatStringUtils.lpad(dua.getNumdocumento(),6,'0'))){
					encontro = true;
				}
			}
			if (elemento instanceof Polizad) {
				Polizad polizad = (Polizad) elemento;
				if (duaprecedente.getCodaduapre().equals(polizad.getCodiAduan()) &&
					duaprecedente.getAnndeclpre().substring(2, 4).equals(polizad.getAnoPrese()) &&
					duaprecedente.getCodregipre().equals(polizad.getCodiRegi()) &&
					SunatStringUtils.lpad(duaprecedente.getNumdeclpre(),6,'0').equals(polizad.getNumeCorre())){
					encontro = true;
				}
			}
		}
		return encontro;
	}
	
	
	/**
	 * De una lista de objetos de regimen de precedencia deposito obtiene la fecha de la declaracion y se devuelve la mayor de ellas
	 * @param listObject
	 * @return
	 */
	public  Date fecemisionPrecedencia(List<Object> listObject){
		Date fecingsiPrecedencia = null;
		Date fechingsi = null;
		for (ListIterator<Object> iterador = listObject.listIterator(); iterador.hasNext();) {
			Object elemento = iterador.next();
			if (elemento instanceof DUA) {
				DUA dua =  (DUA)  elemento;
				fechingsi = dua.getFecdeclaracion();
			}
			if (elemento instanceof Polizad) {
				Polizad polizad = (Polizad) elemento;
				fechingsi = SunatDateUtils.getDateFromInteger(polizad.getFechIngsi());
			}
			if (fecingsiPrecedencia == null) {
				fecingsiPrecedencia = fechingsi;
			}else {
				if (SunatDateUtils.esFecha1MenorQueFecha2(fecingsiPrecedencia, fechingsi, SunatDateUtils.COMPARA_SOLO_FECHA)){
					fecingsiPrecedencia = fechingsi;
				}
			}
		}
		return fecingsiPrecedencia;
	}

	/*
	public PolizadDAO getPolizadDAO() {
  	return polizadDAO;
  }

	public void setPolizadDAO(PolizadDAO polizadDAO) {
  	this.polizadDAO = polizadDAO;
  }

	public SeriesdDAO getSeriesdDAO() {
  	return seriesdDAO;
  }

	public void setSeriesdDAO(SeriesdDAO seriesdDAO) {
  	this.seriesdDAO = seriesdDAO;
  }

	public DepoctaDAO getDepoctaDAO() {
  	return depoctaDAO;
  }

	public void setDepoctaDAO(DepoctaDAO depoctaDAO) {
  	this.depoctaDAO = depoctaDAO;
  }

	public RitpitDAO getRitpitDAO() {
		return ritpitDAO;
	}

	public void setRitpitDAO(RitpitDAO ritpitDAO) {
		this.ritpitDAO = ritpitDAO;
	}

	public RitSerDAO getRitSerDAO() {
		return ritSerDAO;
	}

	public void setRitSerDAO(RitSerDAO ritSerDAO) {
		this.ritSerDAO = ritSerDAO;
	}

	public TrasladoSeriesCeticoDAO getTrasladoSeriesCeticoDAO() {
		return trasladoSeriesCeticoDAO;
	}

	public void setTrasladoSeriesCeticoDAO(
			TrasladoSeriesCeticoDAO trasladoSeriesCeticoDAO) {
		this.trasladoSeriesCeticoDAO = trasladoSeriesCeticoDAO;
	}

	public RitCcDAO getRitCcDAO() {
		return ritCcDAO;
	}

	public void setRitCcDAO(RitCcDAO ritCcDAO) {
		this.ritCcDAO = ritCcDAO;
	}

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public TrasladoCeticoDAO getTrasladoCeticoDAO() {
		return trasladoCeticoDAO;
	}

	public void setTrasladoCeticoDAO(TrasladoCeticoDAO trasladoCeticoDAO) {
		this.trasladoCeticoDAO = trasladoCeticoDAO;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}
	*/
}
