package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certireposicion;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.RepoTra;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.Repocer;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.Reposce;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.dao.RepocerDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.dao.ReposceDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
//import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;//P28-part2 - bug 23938
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
//import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;//P28-part2 - bug 23938
import pe.gob.sunat.sigad.ingreso.service.CertificadoReposicionService;

public class ValRegPrecedenciaReposicionServiceImpl extends ValDuaAbstract implements ValRegPrecedenciaReposicionService {
	

//private FabricaDeServicios fabricaDeServicios;

	
	/** Validar la existencia del n�mero de certificado consignado en la serie de declaraci�n */
	public List<Map<String,String>> validaExistenciaCRMF(List<Repocer> certificadoReposicion,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		
		if(certificadoReposicion.size()==0){
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35008", new String[]{String.valueOf(numSerieDUA) , codAduaAnioDuaNumCertXML}));
			return result;
		}
		return result;
	}
	
	
	/** Validar que el certificado de reposici�n no se encuentre en estado Anulado */
	public List<Map<String,String>> validaEstadoCRMF(List<Repocer> certificadoReposicion,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		Repocer certificado = certificadoReposicion.get(0);
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		
		String estadoNoAnulado = ConstantesDataCatalogo.ESTADO_NO_ANULADO_CRMF;
		String estadoAnulado = ConstantesDataCatalogo.ESTADO_ANULADO_CRMF;
		String estadoCRMF = certificado.getCerAnula()==null?estadoNoAnulado:certificado.getCerAnula();
		
		if(estadoCRMF.equals(estadoAnulado)){					
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35016", new String[]{String.valueOf(numSerieDUA), codAduaAnioDuaNumCertXML}));
		}
		return result;
	}
	
	
	/** Validar que el RUC de la declaraci�n corresponda al beneficiario */
	public List<Map<String,String>> validaRUCBeneficiario(List<Repocer> certificadoReposicion,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		CertificadoReposicionService certificadoReposicionService = fabricaDeServicios.getService("sigad.ingreso.CertificadoReposicionService");
		RepoTra certificadoTransferido=new RepoTra();
		Map<String,Object> parametrosTransf = new HashMap<String, Object>();
		Repocer certificado = certificadoReposicion.get(0);
		String numRucCRMF = certificado.getCerNdoi();
		String numRucDecl = params.get("numRucXML").toString();
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		
		parametrosTransf.put("trAdua", params.get("codAduanaXML"));
		parametrosTransf.put("trNcer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString().trim(),6,'0'));
		parametrosTransf.put("trAnce", params.get("anioCertificadoXML"));
		parametrosTransf.put("trItem", params.get("numItemXML"));//P28-PAS20155E410000032-bug:P_SNADE008-3192
		
		certificadoTransferido=certificadoReposicionService.listarCertificadoTransferido(parametrosTransf);
		
		if (certificadoTransferido!=null){
			String numRucTrans = certificadoTransferido!=null ? certificadoTransferido.getTrTndoc() : "";
			if(!numRucDecl.equals(numRucTrans)){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35009", new String[]{String.valueOf(numSerieDUA) , codAduaAnioDuaNumCertXML}));
			}
		} else {
			if (!numRucDecl.equals(numRucCRMF)){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35009", new String[]{String.valueOf(numSerieDUA) , codAduaAnioDuaNumCertXML}));
			} 
		}

		return result;
	}
	
	
	/** Validar que el item consignado para la serie de la declaraci�n exista */
	public List<Map<String,String>> validaExistenciaItem(List<Reposce> listSeriesCertificado,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		String numItemDecl = params.get("numItemXML").toString();
		String tipoDiligencia = params.get("tipoDiligencia") != null ? params.get("tipoDiligencia").toString() : "";//P28-PAS20155E410000032-[jlunah] BUG 3759 Jira
		boolean existe = false;
		for(Reposce reposceTmp: listSeriesCertificado){
			String numItemCRMF = reposceTmp.getSceItem().toString();
	    	existe = false;
	    	if(numItemDecl.equals(numItemCRMF)){
	    		existe=true;
	    		break;
	    	}
		}				
		
		if(existe==false){
			/*inicio P28-PAS20155E410000032-[jlunah] BUG 3759 Jira*/
			if(tipoDiligencia.equals(ConstantesDataCatalogo.COD_DILIG_REGULAR)){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35625", new String[]{String.valueOf(numSerieDUA), numItemDecl, codAduaAnioDuaNumCertXML}));
			}else{/*fin P28-PAS20155E410000032-[jlunah] BUG 3759 Jira*/
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35011", new String[]{String.valueOf(numSerieDUA), numItemDecl, codAduaAnioDuaNumCertXML}));			
			}//P28-PAS20155E410000032-[jlunah] BUG 3759 Jira
		}		
		return result;
	}
	
	
	/** Validar la fecha de vencimiento consignada en la serie de la declaraci�n */
	public List<Map<String,String>> validaFechaVencimiento(List<Repocer> certificadoReposicion,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		Repocer certificado = certificadoReposicion.get(0);
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		Integer fecVencCRMF = certificado.getCerFvcto();
		Integer fecVencDecl = SunatNumberUtils.toInteger(params.get("fecVencimientoXML"));	
		if(!SunatStringUtils.toStringObj(fecVencCRMF).equals(SunatStringUtils.toStringObj(fecVencDecl))){
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35012", new String[]{String.valueOf(numSerieDUA), codAduaAnioDuaNumCertXML}));					
		}
		return result;
	}
				
	
	/** Validar la fecha fin de vigencia del certificado de reposici�n sea mayor o igual a fecha de numeraci�n */
	public List<Map<String,String>> validaFechaVigencia(List<Repocer> certificadoReposicion,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		Repocer certificado = certificadoReposicion.get(0);
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		Integer fecVencCRMF = certificado.getCerFvcto();
		Integer fechaActual = SunatNumberUtils.toInteger(params.get("fecNumeracion"));
		
		if(fecVencCRMF<fechaActual){
			result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35017", new String[]{String.valueOf(numSerieDUA), codAduaAnioDuaNumCertXML}));					
		}
		return result;
	}
	
	
	/** Validar que solo se puede hacer referencia a un solo item del certificado de reposici�n */
	public List<Map<String,String>> validaUnicoCertificado(DatoSerie datoSerie,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		String numItemDecl = params.get("numItemXML").toString();
		
		if(datoSerie.getListRegPrecedencia().size()>1){
			int cantidadRegimenes = 0;
			for (DatoRegPrecedencia elem : datoSerie.getListRegPrecedencia()){
				//correcion AFMA P28 solo debe contar las no eliminadas
				//if (elem.getCodregipre().equals(ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION)){
				if (elem.getCodregipre().equals(ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION) &&  !"1".equals(elem.getIndDel())){
					cantidadRegimenes++;
				}
			}
			if (cantidadRegimenes > 1){
				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35018", new String[]{String.valueOf(numSerieDUA), numItemDecl ,codAduaAnioDuaNumCertXML }));
			}
		}
		return result;
	}
	
	
	/** Validar que el item consignado en la serie de la declaraci�n no se encuentre anulado */
	public List<Map<String,String>> validaEstadoItem(List<Reposce> listSeriesCertificado,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		String numItemDecl = params.get("numItemXML").toString();
		
		for(Reposce reposceTmp: listSeriesCertificado){
	    	String numItemCRMF = reposceTmp.getSceItem().toString();
	    	if(numItemDecl.equals(numItemCRMF)){
				if(reposceTmp.getSceFanul()>0){
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35019", new String[]{String.valueOf(numSerieDUA), numItemDecl, codAduaAnioDuaNumCertXML}));				    				
				}
			}
		}
		return result;
	}
					

	/** Validar que las unidades fisicas y equivalentes consignadas en la serie coincidan con la CRMF */
	public List<Map<String,String>> validaUndFisicaEquiva(List<Reposce> listSeriesCertificado,Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();	
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		String undFisicaDecl = params.get("undFisicaXML").toString();
		String undEquivDecl = params.get("undEquivalentesXML").toString();
		String numItemDecl = params.get("numItemXML").toString();
		
		for(Reposce reposceTmp: listSeriesCertificado){
	    	String undFisicaCRMF = reposceTmp.getSceUni().trim();
	    	String numItemCRMF = reposceTmp.getSceItem().toString();

	    	if(numItemDecl.equals(numItemCRMF)){
				if((!undFisicaDecl.equals(undFisicaCRMF)) && (!undEquivDecl.equals(undFisicaCRMF))){
					codAduaAnioDuaNumCertXML = codAduaAnioDuaNumCertXML + "-" + numItemCRMF;//P28-part2 - bug 24019
					result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35020", new String[]{String.valueOf(numSerieDUA),undFisicaDecl,undEquivDecl, codAduaAnioDuaNumCertXML, undFisicaCRMF}));
				}
				
			}
		}
		return result;
	}
										
	
	/** Validar que las cantidades fisicas no excedan a la cantidad disponible por item del CRMF */
	public List<Map<String,String>> validaCntFisicaEquiva(List<Reposce> listSeriesCertificado, Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		CertificadoReposicionService certificadoReposicionService = fabricaDeServicios.getService("sigad.ingreso.CertificadoReposicionService");
		BigDecimal cantFisicaDecl = new BigDecimal(params.get("cntFisicaXML").toString().trim()) ;
		BigDecimal cantEquivalenteDecl = new BigDecimal(params.get("cntEquivalenteXML").toString().trim());
		String numItemXML = params.get("numItemXML").toString();
		String numSerieDUA = params.get("numSerieDUA").toString();
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		String undFisicaDecl = params.get("undFisicaXML").toString();
		String undEquivDecl = params.get("undEquivalentesXML").toString();
		boolean existeTransferencia = false;
		
		/**Verifica si existe transferencia*/
		Map<String,Object> parametrosTransf = new HashMap<String, Object>();
		parametrosTransf.put("trAdua", params.get("codAduanaXML"));
		parametrosTransf.put("trNcer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString().trim(),6,'0'));
		parametrosTransf.put("trAnce", params.get("anioCertificadoXML"));
		parametrosTransf.put("trItem", params.get("numItemXML"));//P28-part2 - bug 23990
		RepoTra certificadoTransferido=certificadoReposicionService.listarCertificadoTransferido(parametrosTransf);
		if (certificadoTransferido!=null){
			existeTransferencia=true;
		}else{
			existeTransferencia=false;
		}
		
		BigDecimal cantDecl = new BigDecimal("0.0");
				
		for(Reposce reposceTmp: listSeriesCertificado){
			Map<String,Object> parametrosDisp = new HashMap<String, Object>();
	    	String undFisicaCRMF = reposceTmp.getSceUni().trim();
	    	String numItemCRMF = reposceTmp.getSceItem().toString();	    	
	    	if(numItemXML.equals(numItemCRMF)){
				parametrosDisp.put("existeTransferencia", existeTransferencia);
				parametrosDisp.put("trAdua", params.get("codAduanaXML"));
				parametrosDisp.put("trAnce", params.get("anioCertificadoXML"));
				parametrosDisp.put("trNcer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString(),6,'0'));//pase 433
				parametrosDisp.put("trItem", params.get("numItemXML"));
				parametrosDisp.put("rfcadu", params.get("codAduanaXML"));
				parametrosDisp.put("rffano", params.get("anioCertificadoXML"));
				parametrosDisp.put("rfncer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString(),6,'0'));//pase 433
				parametrosDisp.put("rfnitem", SunatStringUtils.lpad(String.valueOf(params.get("numItemXML")),3,'0'));//pase 433
				parametrosDisp.put("sceAdua", params.get("codAduanaXML"));
				parametrosDisp.put("sceAnce", params.get("anioCertificadoXML"));
				parametrosDisp.put("sceNcer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString(),6,'0'));//pase 433
				parametrosDisp.put("sceItem", params.get("numItemXML"));
				parametrosDisp.put("codAduanaDua", params.get("codAduanaDua"));		
				
				//Agregamos los parametros de la DUA
				parametrosDisp.put("dicadu", params.get("codAduanaDua"));
				parametrosDisp.put("difano", params.get("anioDua"));
				parametrosDisp.put("dindcl", params.get("numDeclaracion"));
				//parametrosDisp.put("dinser", params.get("numSerieDUA"));
				parametrosDisp.put("dinser", SunatStringUtils.lpad(SunatStringUtils.toStringObj(params.get("numSerieDUA")), 4, ' '));//P28
				
				//ini P28-PAS20155E410000032 - bug 23702
				parametrosDisp.put("mSaldDispAdiItemCrmf", params.get("mSaldDispAdiItemCrmf"));
				parametrosDisp.put("obtenerTotalSinRestarReservas", false);//Se debe restar las reservas P28-PAS20155E410000032-[jlunah] BUG 3395 Jira
				//fin P28-PAS20155E410000032 - bug 23702
				BigDecimal saldoDisponible = certificadoReposicionService.obtenerSaldoDisponibleCertificado(parametrosDisp);
			
				if(undFisicaDecl.equals(undFisicaCRMF)){
		    				cantDecl=cantFisicaDecl;
					if(cantFisicaDecl.compareTo(saldoDisponible)==1){
						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35021", new String[]{String.valueOf(numSerieDUA), String.valueOf(cantFisicaDecl), String.valueOf(numItemXML), codAduaAnioDuaNumCertXML}));				    				
					}
				}else if (undEquivDecl.equals(undFisicaCRMF)){
		    				cantDecl=cantEquivalenteDecl;
					if(cantEquivalenteDecl.compareTo(saldoDisponible)==1){
	    				result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35023", new String[]{String.valueOf(numSerieDUA), String.valueOf(cantEquivalenteDecl), String.valueOf(numItemXML), codAduaAnioDuaNumCertXML}));				    				
	    			}
				}
			}
		}
		return result;
	}
					
	
					
	
	/** Validar que al consignar el mismo n�mero de certificado e item para diferentes series de la declaraci�n, estas no excedan el saldo disponible por el item del certificado */
	public List<Map<String,String>> validaCntAgrupadaFisicaEquiva(List<Reposce> listSeriesCertificado, Map<String,BigDecimal> cantidadAcumuladaCertificado, Map<String,Object> params){
		
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		CertificadoReposicionService certificadoReposicionService = fabricaDeServicios.getService("sigad.ingreso.CertificadoReposicionService");
		BigDecimal cantFisicaDecl = new BigDecimal(params.get("cntFisicaXML").toString().trim()) ;
		BigDecimal cantEquivalenteDecl = new BigDecimal(params.get("cntEquivalenteXML").toString().trim());
		BigDecimal cantDecl = new BigDecimal("0.0");
		String codAduaAnioDuaNumCertXML = params.get("codAduaAnioDuaNumCertXML").toString();
		String numItemXML = params.get("numItemXML").toString();
		String undFisicaDecl = params.get("undFisicaXML").toString();
		String undEquivDecl = params.get("undEquivalentesXML").toString();
		String numCertificadoXML = params.get("numCertificadoXML").toString();
		boolean existeTransferencia = false;
		
		/**Verifica si existe transferencia*/
		Map<String,Object> parametrosTransf = new HashMap<String, Object>();
		parametrosTransf.put("trAdua", params.get("codAduanaXML"));
		parametrosTransf.put("trNcer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString().trim(),6,'0'));
		parametrosTransf.put("trAnce", params.get("anioCertificadoXML"));
		parametrosTransf.put("trItem", params.get("numItemXML"));//P28-part2 - bug 23990
		RepoTra certificadoTransferido=certificadoReposicionService.listarCertificadoTransferido(parametrosTransf);
		if (certificadoTransferido!=null){
			existeTransferencia=true;
		}else{
			existeTransferencia=false;
		}
		
		for(Reposce reposceTmp: listSeriesCertificado){			
	    	String undFisicaCRMF = reposceTmp.getSceUni().trim();
	    	String numItemCRMF = reposceTmp.getSceItem().toString();	    	
	    	if(numItemXML.equals(numItemCRMF)){
	    		if(undFisicaDecl.equals(undFisicaCRMF)){
					cantDecl=cantFisicaDecl;
	    		}else if (undEquivDecl.equals(undFisicaCRMF)){
					cantDecl=cantEquivalenteDecl;
				}
	    		
		    			//Para CRF que tiene el mismo numero en un solo envio
		    			String numreferencia = SunatStringUtils.lpad(numCertificadoXML,6,'0').concat(SunatStringUtils.lpad(SunatStringUtils.toStringObj(numItemXML),3,'0')); 	//pase 433
		    			//if(cantidadAcumuladaCertificado.containsKey(numCertificadoXML)){
		    			if(cantidadAcumuladaCertificado.containsKey(numreferencia)){
		    				BigDecimal cantTmp = cantidadAcumuladaCertificado.get(numreferencia).add(cantDecl);
		    				cantidadAcumuladaCertificado.put(numreferencia, cantTmp);
				}else{
		    				cantidadAcumuladaCertificado.put(numreferencia, cantDecl);
				}
				
		    			if(cantidadAcumuladaCertificado.containsKey(numreferencia.concat("_"))){
		    				BigDecimal contTmp = cantidadAcumuladaCertificado.get(numreferencia.concat("_")).add(new BigDecimal(1));
		    				cantidadAcumuladaCertificado.put(numreferencia.concat("_"), contTmp);
		    			}else{
		    				cantidadAcumuladaCertificado.put(numreferencia.concat("_"), new BigDecimal(1));
		    			}
	    	}
	    }
				
				/** Validar que al consignar el mismo n�mero de certificado e item para diferentes series de la declaraci�n, estas no excedan el saldo disponible por el item del certificado */
		
		if (!cantidadAcumuladaCertificado.isEmpty()){
					String numreferencia = SunatStringUtils.lpad(numCertificadoXML,6,'0').concat(SunatStringUtils.lpad(SunatStringUtils.toStringObj(numItemXML),3,'0'));
					if(cantidadAcumuladaCertificado.get(numreferencia.concat("_")) != null//P28-PAS20155E410000033
							&& cantidadAcumuladaCertificado.get(numreferencia.concat("_")).compareTo(new BigDecimal(1)) == 1 ){//P28-PAS20155E410000033
//							.compareTo(getTotalSeriesRelacionadoAlItemCrmf(params)) == 0 ){//P28-part2 - bug 23938
				Map<String,Object> parametrosDisp = new HashMap<String, Object>();
				parametrosDisp.put("existeTransferencia", existeTransferencia);
				parametrosDisp.put("trAdua", params.get("codAduanaXML"));
				parametrosDisp.put("trAnce", params.get("anioCertificadoXML"));
				parametrosDisp.put("trNcer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString(),6,'0'));//pase 433
				parametrosDisp.put("trItem", params.get("numItemXML"));
				parametrosDisp.put("rfcadu", params.get("codAduanaXML"));
				parametrosDisp.put("rffano", params.get("anioCertificadoXML"));
				parametrosDisp.put("rfncer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString(),6,'0'));//pase 433
				parametrosDisp.put("rfnitem", SunatStringUtils.lpad(String.valueOf(numItemXML),3,'0'));
				parametrosDisp.put("sceAdua", params.get("codAduanaXML"));
				parametrosDisp.put("sceAnce", params.get("anioCertificadoXML"));
				parametrosDisp.put("sceNcer", SunatStringUtils.lpad(params.get("numCertificadoXML").toString(),6,'0'));//pase 433
				parametrosDisp.put("sceItem", params.get("numItemXML"));
				parametrosDisp.put("codAduanaDua", params.get("codAduanaDua"));
				
				//Agregamos los parametros de la DUA
				parametrosDisp.put("dicadu", params.get("codAduanaDua"));
				parametrosDisp.put("difano", params.get("anioDua"));
				parametrosDisp.put("dindcl", params.get("numDeclaracion"));
				parametrosDisp.put("dinser", SunatStringUtils.lpad(SunatStringUtils.toStringObj(params.get("numSerieDUA")), 4, ' '));//se descomenta P28-PAS20155E410000032-[jlunah] BUG 3395 Jira
				
				/*inicio P28-PAS20155E410000032-[jlunah] BUG 3395 Jira*/
				parametrosDisp.put("mSaldDispAdiItemCrmf", params.get("mSaldDispAdiItemCrmf"));
				parametrosDisp.put("obtenerTotalSinRestarReservas", true);//No se deben restar las reservas
				/*fin P28-PAS20155E410000032-[jlunah] BUG 3395 Jira*/
				
				BigDecimal saldo = certificadoReposicionService.obtenerSaldoDisponibleCertificado(parametrosDisp); 					
				
							if(cantidadAcumuladaCertificado.get(numreferencia).compareTo(saldo)==1){
						result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35022", new String[]{String.valueOf(cantidadAcumuladaCertificado.get(numreferencia)), String.valueOf(numItemXML), codAduaAnioDuaNumCertXML}));					
					}
			}
		}
		return result;
	}
	
//	//ini P28-part2 - bug 23938
//	private BigDecimal getTotalSeriesRelacionadoAlItemCrmf(Map<String, Object> params) {
//		BigDecimal total = BigDecimal.ZERO;
//		
//		Object objDeclaracion = params.get("declaracion");
//		if(objDeclaracion != null && objDeclaracion instanceof Declaracion) {
//			Declaracion declaracion = (Declaracion)objDeclaracion;
//			Elementos<DatoSerie> series = declaracion.getDua().getListSeries();
//			
//			for (DatoSerie serie : series) {
//				for (DatoRegPrecedencia datoRegPrecedencia : serie.getListRegPrecedencia()) {
//					if ("12".equals(datoRegPrecedencia.getCodregipre()) && !"1".equals(datoRegPrecedencia.getIndDel())) {
//						String rfcadu = datoRegPrecedencia.getCodaduapre();
//						String rffano = datoRegPrecedencia.getAnndeclpre() == null || datoRegPrecedencia.getAnndeclpre().length() < 4?
//								"" : datoRegPrecedencia.getAnndeclpre().substring(0, 4);
//						String rfncer = datoRegPrecedencia.getNumdeclpre();
//						String rfnitem = datoRegPrecedencia.getNumserpre().toString();
//						
//						if(rfcadu.equals(params.get("codAduanaXML"))
//								&& rffano.equals(params.get("anioCertificadoXML"))
//								&& rfncer.equals(SunatStringUtils.lpad(params.get("numCertificadoXML").toString(),6,'0'))
//								&& rfnitem.equals(params.get("numItemXML").toString())) {
//							total = total.add(BigDecimal.ONE);
//						}
//					}
//				}
//			}	
//		}
//		
//		return total;
//	}
//	//fin P28-part2 - bug 23938
	
	/*INICIO-P28*/
	@Override
	public List<Map<String,String>> procesarDatosCertificadoReposicion(Map<String,Object> params){
		
		List<Map<String,String>> resultList = new ArrayList<Map<String,String>>();
		List<Map<String,String>> retorno = new ArrayList<Map<String,String>>();
		Map<String,Object> datos = new HashMap<String, Object>();
		String numSerieDUA = params.get("numSerie").toString();
		String codAduaAnioDuaNumCertXML = params.get("cerAdua").toString().concat("-"+params.get("cerAnce").toString()+"-"+params.get("cerCert").toString());
		Integer fecNumeracion = SunatNumberUtils.toInteger(params.get("fechaNumeracion"));
		String numItemXML = params.get("numItem").toString();
		String tipoDiligencia = params.get("tipoDiligencia") != null ? params.get("tipoDiligencia").toString() : "";//P28-PAS20155E410000032-[jlunah] BUG 3759 Jira
		
		/**certificadoReposicion*/
		RepocerDAO repocerDAO = fabricaDeServicios.getService("despacho.entrada.repocerDAO");
		List<Repocer>  certificadoReposicion = repocerDAO.listCertificadoReposicion(params);
		
		/**Datos necesarios para las validaciones*/
		datos.put("numSerieDUA", numSerieDUA);
		datos.put("codAduaAnioDuaNumCertXML", codAduaAnioDuaNumCertXML);
		datos.put("fecNumeracion", fecNumeracion);
		datos.put("numItemXML", numItemXML);
		datos.put("tipoDiligencia", tipoDiligencia);//P28-PAS20155E410000032-[jlunah] BUG 3759 Jira
		
		//ValRegPrecedenciaReposicionService valRegPrecedenciaReposicion = fabricaDeServicios.getService("ValRegPrecedenciaReposicion");
		
		/** Validar la existencia del n�mero de certificado consignado en la serie de declaraci�n */
		retorno = this.validaExistenciaCRMF(certificadoReposicion, datos);
		if(!retorno.isEmpty()){			
			resultList.add(retorno.get(0));
		}else{			
			/** Validar que el certificado de reposici�n no se encuentre en estado Anulado */
			retorno = new ArrayList<Map<String,String>>();
			retorno = this.validaEstadoCRMF(certificadoReposicion, datos);
			if(!retorno.isEmpty()){
				resultList.add(retorno.get(0));
			}
			
			/** Validar la fecha fin de vigencia del certificado de reposici�n sea mayor o igual a fecha de numeraci�n */
			retorno = new ArrayList<Map<String,String>>();
			retorno = this.validaFechaVigencia(certificadoReposicion, datos);
			if(!retorno.isEmpty()){
				resultList.add(retorno.get(0));
			}
			
			/**listSeriesCertificado*/
			ReposceDAO reposceDAO = fabricaDeServicios.getService("despacho.entrada.reposceDAO");
			List<Reposce>  listSeriesCertificado = reposceDAO.listSeriesCertificadoReposicion(params);
			
			/** Validar que el item consignado para la serie de la declaraci�n exista */
			retorno = new ArrayList<Map<String,String>>();
			retorno = this.validaExistenciaItem(listSeriesCertificado, datos);
			if(!retorno.isEmpty()){
				resultList.add(retorno.get(0));
			}else{				
				/** Validar que el item consignado en la serie de la declaraci�n no se encuentre anulado */
				retorno = new ArrayList<Map<String,String>>();
				retorno = this.validaEstadoItem(listSeriesCertificado, datos);
				if(!retorno.isEmpty()){
					resultList.add(retorno.get(0));
				}
			}
		}
		return resultList;
	}
	/*FIN-P28*/
	
	/*
	
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
	
	
	
}
