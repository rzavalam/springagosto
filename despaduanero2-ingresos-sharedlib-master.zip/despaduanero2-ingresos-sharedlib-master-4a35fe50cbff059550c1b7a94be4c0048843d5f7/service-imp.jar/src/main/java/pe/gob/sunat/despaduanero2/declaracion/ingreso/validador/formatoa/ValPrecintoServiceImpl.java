/*
 * Clase que define el servicio de validaciones de la relacion de precintos
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.model.DatoEquipamiento;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPrecinto;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * The Class ValPrecinto. Clase que define el servicio de validaciones de la relacion de precintos.
 */
public class ValPrecintoServiceImpl extends ValDuaAbstract implements ValPrecinto{
	
	/**
	 * Valida que el numero de precionto sea alfanumerico.<br>
	 * Valida que el par&aacute;metro sea no vacio y un valor alfanum&eacute;rico.
	 * Si es v&aacute;lido se devuelve null, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numprecinto String
	 * @return Map
	 */
	public Map<String, String> numprecinto(String numprecinto){
		return SunatStringUtils.isAlphanumeric(numprecinto)?new HashMap<String,String>():getDUAError("08911","");
	}
	//inicio gmontoya Pase 451 - 2015	
	@Override
	public List<Map<String, String>> validarUnicidadPrecinto(Declaracion declaracion) {
		// TODO Auto-generated method stub
		List<String> listaEquipamiento = new ArrayList<String>();
		List<Map<String, String>> listaErrores = new ArrayList<Map<String,String>>();
		for(DatoEquipamiento datoEquip:declaracion.getDua().getManifiesto().getListEquipamientos()){
			for(DatoPrecinto datoPrecinto : datoEquip.getListPrecintos()){
				if(listaEquipamiento.contains(datoPrecinto.getNumprecinto())){
					listaErrores.add(getDUAError("35576",new Object[]{datoPrecinto.getNumprecinto()}));
				}else{
					listaEquipamiento.add(datoPrecinto.getNumprecinto());
				}
			}
		}

		return listaErrores;
	}
	//fin gmontoya Pase 451 - 2015
}
