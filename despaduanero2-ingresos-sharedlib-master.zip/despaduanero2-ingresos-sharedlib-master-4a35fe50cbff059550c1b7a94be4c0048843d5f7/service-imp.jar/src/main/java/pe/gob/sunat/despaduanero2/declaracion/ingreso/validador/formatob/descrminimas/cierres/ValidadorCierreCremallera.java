package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.cierres;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreCremallera;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValidadorCierreCremallera extends ValidadorCierreAbstract{

	private static final String CATALOGO_UNID_COMER_CIERRES = "567"; //Tiene los mismos elementos de Pilas
	
  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception{
		List<ErrorDescrMinima> lstErroresDescrMin = validarEstructura(objeto);

      if (CollectionUtils.isEmpty(lstErroresDescrMin)){
          lstErroresDescrMin.addAll(validarUnidadComercial(objeto,dua));
          lstErroresDescrMin.addAll(validarNombreComercial(objeto));
          lstErroresDescrMin.addAll(validarMarcaComercial(objeto));
          lstErroresDescrMin.addAll(validarModelo(objeto));
          lstErroresDescrMin.addAll(validarTipoCierre(objeto));
          lstErroresDescrMin.addAll(validarComposicionCinta(objeto));
          lstErroresDescrMin.addAll(validarPresentacionCinta(objeto));
          lstErroresDescrMin.addAll(validarTipoLlave(objeto));
          lstErroresDescrMin.addAll(validarMaterialLlave(objeto));
          lstErroresDescrMin.addAll(validarTamanoCremallera(objeto));
          lstErroresDescrMin.addAll(validarMaterialDientes(objeto));
          lstErroresDescrMin.addAll(validarTamanoDientes(objeto));
      }

	    return lstErroresDescrMin;
  }
  
  public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract objeto, Declaracion dua){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  CierreCremallera cierreCremallera = (CierreCremallera) objeto;
	  String datoAValidar = obtenerItem(objeto,dua).getCodunidcomer().trim();
	  //rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
	  Map<String,Object> variablesIngreso = objeto.getMapCatalogos();
	  if(noestaEnSubGrupoCatalogo(CATALOGO_UNID_COMER_CIERRES,datoAValidar,variablesIngreso)){
	   	 Object[] demasArgumentosMSJError = new Object[] { cierreCremallera.getNumsecprove(),cierreCremallera.getNumsecfact(),
	   	 cierreCremallera.getNumsecitem(),"CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
         ErrorDescrMinima error = obtenerError("31790",ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);	   	  
         lstErroresDescrMin.add(error); 
	  }
	  return lstErroresDescrMin;	  
	}  
  
  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();	  
	}
  
  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}

  public List<ErrorDescrMinima> validarModelo(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}
  
  public List<ErrorDescrMinima> validarTipoCierre(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}
  
  public List<ErrorDescrMinima> validarComposicionCinta(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();

	  Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
	  CierreCremallera cierreCremallera = (CierreCremallera) objeto;  
	  String datoAValidar;	  
	  if(cierreCremallera.getComposicionCinta() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = cierreCremallera.getComposicionCinta().getValtipdescri().trim(); 	  
	  if(noEstaEnCatalogo(datoAValidar,"M1",fechaVigencia)){
	   	  ErrorDescrMinima error = obtenerError("31792",cierreCremallera.getComposicionCinta());
	   	  lstErroresDescrMin.add(error);			  
	  }
	  return lstErroresDescrMin;
	}
  
  public List<ErrorDescrMinima> validarPresentacionCinta(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();

	  Date fechaVigencia = objeto.getFechaIniVigenciaValidador();//AREY-MIN PASE137
	  CierreCremallera cierreCremallera = (CierreCremallera) objeto; 
	  String datoAValidar;	  
	  if(cierreCremallera.getPresentacionCinta() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = cierreCremallera.getPresentacionCinta().getValtipdescri().trim();	  
	  if(noEstaEnCatalogo(datoAValidar,"M3",fechaVigencia)){
	   	  ErrorDescrMinima error = obtenerError("31794",cierreCremallera.getPresentacionCinta());
	   	  lstErroresDescrMin.add(error);			  
	  }
	  return lstErroresDescrMin;
	}
  
  public List<ErrorDescrMinima> validarTipoLlave(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}
  
  public List<ErrorDescrMinima> validarMaterialLlave(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}
  
  public List<ErrorDescrMinima> validarTamanoCremallera(ModelAbstract objeto){
	  return new ArrayList<ErrorDescrMinima>();
	}
  
  public List<ErrorDescrMinima> validarMaterialDientes(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  CierreCremallera cierreCremallera = (CierreCremallera) objeto;
	  String datoAValidar;	  
	  if(cierreCremallera.getMaterialDientes() == null)
		  datoAValidar = "";
	  else
		  datoAValidar = cierreCremallera.getMaterialDientes().getValtipdescri().trim();  
      if (SunatStringUtils.isEmpty(datoAValidar)){
		   	  ErrorDescrMinima error = obtenerError("31872",cierreCremallera.getMaterialDientes());
		   	  lstErroresDescrMin.add(error);			  
      }
      return lstErroresDescrMin;
	}
  
  public List<ErrorDescrMinima> validarTamanoDientes(ModelAbstract objeto){
	  List<ErrorDescrMinima> lstErroresDescrMin = new ArrayList<ErrorDescrMinima>();
	  CierreCremallera cierreCremallera = (CierreCremallera) objeto;
	  String datoAValidar ;
	  Float datoAValidarN;
	  Float arreglo[] = {2F,3F,4.5F,5F,7F,8F};
	  if(cierreCremallera.getTamanoDientes() == null){
	      datoAValidar = "";
	  	  datoAValidarN = 0F;
	  }
	  else{
		  datoAValidar = cierreCremallera.getTamanoDientes().getValtipdescri().trim();
		  if(!SunatStringUtils.isEmpty(datoAValidar))
			  datoAValidarN = Float.valueOf(datoAValidar);
		  else
			  datoAValidarN = 0F;
	  }
	  if(!SunatStringUtils.isEmpty(datoAValidar)){
		  if((datoAValidarN < 8 && !SeEncuentra(arreglo,datoAValidarN))){
		   	  ErrorDescrMinima error = obtenerError("31799",cierreCremallera.getTamanoDientes());
		   	  lstErroresDescrMin.add(error);			  
		}
	  }
	  else{
	   	  ErrorDescrMinima error = obtenerError("31871",cierreCremallera.getTamanoDientes());
	   	  lstErroresDescrMin.add(error);		
	  }
	  
	  return lstErroresDescrMin;
	}
  
  private boolean SeEncuentra(Float[] arreglo, Float elemento) {
	  int valores = arreglo.length;    
	  boolean encontrado=false;       
	  for ( int posicion = 0; posicion < valores; posicion++ )  
			  if ( arreglo[posicion].equals(elemento))      
				  encontrado=true;    
	  return encontrado;
	  }  
  
}
