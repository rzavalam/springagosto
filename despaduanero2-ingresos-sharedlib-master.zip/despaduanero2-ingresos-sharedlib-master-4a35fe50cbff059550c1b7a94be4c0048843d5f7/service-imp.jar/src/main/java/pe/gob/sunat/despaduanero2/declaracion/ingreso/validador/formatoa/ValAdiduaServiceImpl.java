/*
 * Clase que define el servicio de validaciones de la DUA 
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FormatoAServiceImpl;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValAdidua.<br>
 * Clase que define el servicio de validaciones de la DUA.
 * 
 * @author rcalla
 */
public class ValAdiduaServiceImpl extends ValDuaAbstract implements ValAdidua {
	//private FabricaDeServicios fabricaDeServicios;
	/**
	 * @param String codidcertorigen
	 * @return Map<String, String>
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 */
	@ServicioAnnot(tipo="V",codServicio=2100)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codidcertorigen"})
	@OrquestaDespaAnnot(codServInstancia=2100,numSecEjec=1,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte")
	public Map<String, String> codidcertorigen(String codidcertorigen){
		return !SunatStringUtils.isEmptyTrim(codidcertorigen)?new HashMap<String,String>():getDUAError("30081","Error codidcertorigen "+codidcertorigen);
	}

	/**
	 * @param String codidfactura
	 * @return Map<String, String>
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 */
	@ServicioAnnot(tipo="V",codServicio=2101)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codidfactura"})
	@OrquestaDespaAnnot(codServInstancia=2101,numSecEjec=2,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte")
	public Map<String, String> codidfactura(String codidfactura){
		return !SunatStringUtils.isEmptyTrim(codidfactura)?new HashMap<String,String>():getDUAError("30082","Error codidfactura:"+codidfactura);
	}

	/**
	 * @param String codidocsoporte
	 * @return Map<String, String>
	 * Valida que el par&aacute;metro tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 */
	@ServicioAnnot(tipo="V",codServicio=2102)
	@ServInstDetAnnot(tipoRpta={0},nomAtr={"codidocsoporte"})
	@OrquestaDespaAnnot(codServInstancia=2102,numSecEjec=3,nomClase="pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieDocSoporte")
	public Map<String, String> codidocsoporte(String codidocsoporte){
		return !SunatStringUtils.isEmptyTrim(codidocsoporte)?new HashMap<String,String>():getDUAError("30083","Error codidocsoporte:"+codidocsoporte);
	}


	/**
	 *  V�lida el ID del documento de soporte
	 * 
	 * @param numiddocsoporte Integer, ID del documento de soporte
	 * @return el mapa de errores de validaci�n
	 */
	public Map<String, String> numiddocsoporte(Integer numiddocsoporte){
		return numiddocsoporte!=null && numiddocsoporte>0?new HashMap <String,String>():getDUAError("30281","Error numiddocsoporte:"+numiddocsoporte);
	}

	
	/**
	 * 
	 * V�lida el c�digo del tipo de documento de soporte
	 * 
	 * @param codtipodocsoporte String, c�digo del tipo de documento de soporte
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> codtipodocsoporte(String codtipodocsoporte){
		if (!SunatStringUtils.isEmptyTrim(codtipodocsoporte)){
			//if (FormatoAServiceImpl.getInstance().isValidCatalogo("367", codtipodocsoporte))
			boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("367", codtipodocsoporte,SunatDateUtils.getCurrentDate()));
			if (validaCatalogo)
				return new HashMap<String,String>();
			else
				//return getDUAError("30282","Error catalogo codtipdocsoporte");
				return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30282");
		}else{
			//return getDUAError("30282","Error codtipdocsoporte");
			return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30282");
		}
	}	
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
	
}
