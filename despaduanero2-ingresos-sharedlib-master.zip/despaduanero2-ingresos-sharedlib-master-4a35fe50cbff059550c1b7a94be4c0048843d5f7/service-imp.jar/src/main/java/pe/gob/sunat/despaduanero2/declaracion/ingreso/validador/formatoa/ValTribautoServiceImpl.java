/*
 * Clase que define el servicio de validaciones de Relaci�n de  derechos.impuestos, recargos, tasas, e intereses autoliquidados.
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * The Class ValTribauto. Clase que define el servicio de validaciones de Relaci�n de  derechos.impuestos, recargos, tasas, e intereses autoliquidados.
 */
public class ValTribautoServiceImpl extends ValDuaAbstract implements ValTribauto{
	//private FabricaDeServicios fabricaDeServicios;
	/**
	 * Valida el codigo del tributo a pagar:         - Ad-Valorem - Igv - Isc  - Otros - Derechos Antidumping - Derechos Especificos - Ipm - Ipm Adicional - Sobretasa Adicional - Tasa Servicio Aduanero - Interes Compensatorio.<br>
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtributo String. C�digo de tibuto a pagar.
	 * @return Map
	 */
	public Map<String, String> codtributo(String codtributo){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("T32", codtributo))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("T32", codtributo, SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("08516","Error catalogo codtributo");
	}

	/**
	 * Valida el codigo de Moneda en la que se expresa el tributo a pagar.<br> 
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codmoneda String. Moneda en la que se expresa el tributo a pagar
	 * @return Map
	 */
	public Map<String, String> codmoneda(String codmoneda){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("J1", codmoneda))
		boolean validaCatalogo=CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J1", codmoneda,SunatDateUtils.getCurrentDate()));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			return getDUAError("30095","Error catalogo codmoneda Tribauto Envio "+codmoneda);
	}

	/**
	 * Valida el Monto del valor de tributo a pagar.<br>
	 * Valida que el par&aacute;metro no sea menor a cero.
	 * Si es v&aacute;lido se devuelve un mapa vacio, en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param mtovalortrib BigDecimal. Monto del valor de tributo a pagar.
	 * @return Map
	 */
	public Map<String, String> mtovalortrib(BigDecimal mtovalortrib){
		return SunatNumberUtils.isGreaterOrEqualsThanZero(mtovalortrib)?new HashMap<String,String>():getDUAError("08517","");
	}
	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/

}
