package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.donacion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.IndicadorDuaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.recauda2.genadeudo.service.DeudaDeclaracionService;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public class ImpugnacionTributosParaDonacionServiceImpl extends ValDuaAbstract implements ImpugnacionTributosParaDonacionService {

	//private FabricaDeServicios fabricaDeServicios;
	
	/**validarImpugnacionDeTributos**/
	public List<Map<String,String>> validarImpugnacionDeTributos(Declaracion declaracion, Declaracion declaracionBD){
		List<Map<String, String>> lstErrores = new ArrayList<Map<String,String>>();
		List<DatoSerie> lstSerie = declaracion.getDua().getListSeries();
		boolean cumple = cumpleRequisitosParaImpugnarTributos(declaracion);		
		if(cumple){
			lstErrores.addAll(validarExpediente(declaracion));
			lstErrores.addAll(validarGarantia160(declaracion));
			if(!lstSerie.isEmpty()){
				for(DatoSerie serie: lstSerie){
					lstErrores.addAll(validarTratamientoPreferencial(declaracion,serie));
				}
			}
			
			DeudaDeclaracionService deudaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.deudaDeclaracionService");
			boolean estaImpugnadaDeuda = deudaDeclaracionService.estaImpugnadaDeudaPorDonacion(declaracion);
			if(estaImpugnadaDeuda){
				//-----------------------------------------
				List<DatoIndicadores> listIndicadoresNEW = declaracion.getDua().getListIndicadores()!=null?declaracion.getDua().getListIndicadores():new ArrayList<DatoIndicadores>();
				if(!listIndicadoresNEW.isEmpty()){
					for(DatoIndicadores datoIndicadorNEW: listIndicadoresNEW){
						String indicadorNEW = datoIndicadorNEW.getCodtipoindica();
						if(SunatStringUtils.isEqualTo(indicadorNEW, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL)){
							lstErrores.addAll(validarCancelacionLC006(declaracion));
						}
					}
				}
			}			
		}
		
		return lstErrores;
	}
	
	/**cumpleRequisitosParaImpugnarTributos**/
	public boolean cumpleRequisitosParaImpugnarTributos(Declaracion declaracion){
		
		boolean result = false;
		String[] arrayTipIndicador = new String[] {
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL,
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL };
		List<DatoIndicadores> listIndicadores = declaracion!=null && declaracion.getDua()!=null && declaracion.getDua().getListIndicadores()!=null?declaracion.getDua().getListIndicadores():new ArrayList<DatoIndicadores>();
		if(!listIndicadores.isEmpty()){
			for(DatoIndicadores datoIndicador: listIndicadores){
				String indicador = datoIndicador.getCodtipoindica();
				if(SunatStringUtils.include(SunatStringUtils.toStringObj(indicador), arrayTipIndicador)  && !"0".equals(datoIndicador.getIndicadorActivo())){
					result = true;
					break;
				}else{
					result = false;
				}
			}
		}
		
		return result;
	}
	
	/**validarExpediente**/
	public List<Map<String,String>> validarExpediente(Declaracion declaracion){
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
//		List<DatoIndicadores> listIndicadores = declaracion.getDua().getListIndicadores()!=null?declaracion.getDua().getListIndicadores():new ArrayList<DatoIndicadores>();
		List<DatoOtroDocSoporte> listDocSoporte = declaracion.getDua().getListOtrosDocSoporte()!=null?declaracion.getDua().getListOtrosDocSoporte():new ArrayList<DatoOtroDocSoporte>();
		
//		if(!listIndicadores.isEmpty()){
//			for(DatoIndicadores datoIndicadores: listIndicadores){
//				String indicadorNew = datoIndicadores.getCodtipoindica();
//				if(!SunatStringUtils.isEqualTo(indicadorNew, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL)){
//					return lstErrores;
//				}
//			}
//		}
		
		if(!listDocSoporte.isEmpty()){
			boolean consignaCodDocDonacion = false;
			for(DatoOtroDocSoporte docSoporte: listDocSoporte){
				String tipoProcesoDelDocumentoAsoc = docSoporte.getCodtipoproceso();
				String tipoDocumentoAsoc = docSoporte.getCodtipodocasoc();
				Integer indEliminado = docSoporte.getIndicadorEliminado()!=null?docSoporte.getIndicadorEliminado():0;//P46-PAS20155E410000032-[jlunah]
				
				if(SunatStringUtils.isEqualTo(tipoProcesoDelDocumentoAsoc, ConstantesDataCatalogo.COD_DOCUMENTO_DONACION) && indEliminado == 0){//P46-PAS20155E410000032-[jlunah] si el documento no esta eliminado
					consignaCodDocDonacion = true;			
				}
				if(consignaCodDocDonacion){
					if(!SunatStringUtils.isEqualTo(tipoDocumentoAsoc, ConstantesDataCatalogo.COD_DOCUMENTO_EXPEDIENTE)){
						//error Nro. 17
						lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35438"));
					}
					break;
				}				
			}
			if(!consignaCodDocDonacion){
				//error Nro. 16
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35450"));
			}
		} else {//Ini P46 - PAS20155E220000329 - bug 22386
			
			/*inicio P46-PAS20155E410000032-[jlunah]*/
			String regimenDiligencia = ConstantesDataCatalogo.REG_IMPO_CONSUMO + ConstantesDataCatalogo.TRANSACCION_RECTI_OFICIO_VALIDACION;
			if(regimenDiligencia.equals(declaracion.getCodtipotrans())){
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35450"));
			}
			/*fin P46-PAS20155E410000032-[jlunah]*/
			
			List<DatoSerie> listSeries = declaracion.getDua().getListSeries();
			
			String[] arrayCodLibeSinResolucion = new String[] {
					ConstantesDataCatalogo.COD_LIBE_DONA_RELIGIOSAS,
					ConstantesDataCatalogo.COD_LIBE_DONA_VEHIC_RELIGIOSAS};
			
			boolean tieneCodLiber20012002 = false;
			for(DatoSerie datoSerie: listSeries){
				Integer codLibe = datoSerie.getCodliberatorio()!=null?datoSerie.getCodliberatorio():0;
				if(SunatStringUtils.include(SunatStringUtils.toStringObj(codLibe), arrayCodLibeSinResolucion)){
					tieneCodLiber20012002=true;
					break;
				}		
			}
			
			if(!tieneCodLiber20012002) {
				lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35438"));
		}
		}//Fin P46 - PAS20155E220000329 - bug 22386
		
		return lstErrores;
	}
	
	/**validarGarantia160**/
	public List<Map<String,String>> validarGarantia160(Declaracion declaracion){
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		String tieneGarantia = declaracion.getDua().getPago()!=null?declaracion.getDua().getPago().getPagoDeclaracion()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia()!=null?declaracion.getDua().getPago().getPagoDeclaracion().getCodgarantia():"":"":"";
		if(!tieneGarantia.equalsIgnoreCase("")){
			//error Nro. 18
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35429"));
		}
		
		return lstErrores;
	}
	
	/**validarTratamientoPreferencial**/
	public List<Map<String,String>> validarTratamientoPreferencial(Declaracion declaracion, DatoSerie serie){
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		//tipo de cancelaci�n
		String[] arrayTipCance = new String[] {"0","73","6","66"};		
		Integer codTratoPref = serie.getCodtratprefe()!=null?serie.getCodtratprefe():0;
		Integer codConvinter = serie.getCodconvinter()!=null?serie.getCodconvinter():0;
		Integer codTratPrefe = serie.getCodtratprefe()!=null?serie.getCodtratprefe():0;
		Integer numSerieDUA = serie.getNumserie();
		
		if(codConvinter!=0 || codTratPrefe!=0){
			//error Nro. 19
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35431", new String[]{String.valueOf(numSerieDUA)}));
		}		
		
		DeudaDeclaracionService deudaDeclaracionService = getFabricaDeServicios().getService("diligencia.ingreso.deudaDeclaracionService");
		boolean estaCanceladoDua = deudaDeclaracionService.estaCanceladoFormatoC(declaracion);
//		String tipCance="";
//		DeudaDocum tmpDeudaDocum = new DeudaDocum();
//		tmpDeudaDocum.setNumCorredoc(declaracion.getDua().getNumcorredoc());
//		tmpDeudaDocum.setCodTipdeuda("01");
//		DeudaDocumDAO deudaDocumDAO = fabricaDeServicios.getService("deudaDocumDef");
//		List<DeudaDocum> listDeudaDocum = deudaDocumDAO.selectByDocumento(tmpDeudaDocum);
//		if(!CollectionUtils.isEmpty(listDeudaDocum)){
//			for(DeudaDocum deudaDocum: listDeudaDocum){
//				DeudaDeclaracionService deudaDeclaracionService = getFabricaDeServicios().getService("diligencia.ingreso.deudaDeclaracionService");
//				tipCance = deudaDeclaracionService.obtenerTipoCancelacion(deudaDocum);
//			}
//		}
//		
//		String indicadorNew = "";
//		List<DatoIndicadores> listIndicadores = declaracion!=null && declaracion.getDua()!=null && declaracion.getDua().getListIndicadores()!=null?declaracion.getDua().getListIndicadores():new ArrayList<DatoIndicadores>();
//		if(!CollectionUtils.isEmpty(listIndicadores)){
//			indicadorNew = listIndicadores.get(0).getCodtipoindica();
//		}		
		
//		if(!SunatStringUtils.include(tipCance, arrayTipCance) && !SunatStringUtils.isEqualTo(indicadorNew, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL)){
		if(estaCanceladoDua){
			//error Nro. 20
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35456"));
		}
		
		if(codTratoPref!=0){//MODIFICADO
			//error Nro. 19
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35431", new String[]{String.valueOf(numSerieDUA)}));
		}		
		
		return lstErrores;
	}	
	@Override
	public boolean noEstaCanceladaImpugnacionDeDonacion(Map declaracion) {
		
		IndicadorDuaService indicadorDuaService = fabricaDeServicios.getService("validacion.ingreso.IndicadorDuaService");
	DeudaDeclaracionService deudaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.deudaDeclaracionService");
	boolean noEstaImpugnado = false;
	
	int tipoTratamiento= Integer.parseInt(declaracion.get("COD_TIPTRATMERC").toString());
	Long numCorreDoc =  Long.parseLong(declaracion.get("NUM_CORREDOC").toString());
	if(tipoTratamiento!=4)   //REGISTRAR CONSTANTES DONACION=4
		return  noEstaImpugnado;
	 Map<String, Object> tieneIndicadorDonacion = indicadorDuaService.obtenerIndicadoresDonacion(numCorreDoc);
		if(tieneIndicadorDonacion==null)
		   return noEstaImpugnado;
		
		noEstaImpugnado = deudaDeclaracionService.noEstaImpugnadaDeudaPorDonacion(numCorreDoc);
		
		return  noEstaImpugnado;

	}
	
	/**validarCancelacionLC006**/
	public List<Map<String,String>> validarCancelacionLC006(Declaracion declaracion){
		String[] arrayTipIndicador = new String[] {
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL,
				ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL };
		List<Map<String,String>> lstErrores = new ArrayList<Map<String,String>>();
		List<DatoIndicadores> listIndicadoresNEW = declaracion.getDua().getListIndicadores()!=null?declaracion.getDua().getListIndicadores():new ArrayList<DatoIndicadores>();
		boolean existeIndDif06 = false;
		if(!listIndicadoresNEW.isEmpty()){
			for(DatoIndicadores datoIndicadorNEW: listIndicadoresNEW){
				String indicadorNEW = datoIndicadorNEW.getCodtipoindica();
				if(!SunatStringUtils.isEqualTo(indicadorNEW, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL) && SunatStringUtils.include(indicadorNEW, arrayTipIndicador)){
					existeIndDif06 = true;
				}
			}
		}
		
		if(existeIndDif06){
			return lstErrores;
		}
		
		Map<String,Object> mapDeclaracionActual = new HashMap<String, Object>();
		mapDeclaracionActual.put("COD_ADUANA", declaracion.getDua().getCodaduanaorden());
		mapDeclaracionActual.put("ANN_PRESEN", declaracion.getDua().getAnnorden());
		mapDeclaracionActual.put("NUM_DECLARACION", declaracion.getNumeroDeclaracion());
		mapDeclaracionActual.put("COD_REGIMEN", declaracion.getDua().getCodregimen());
		mapDeclaracionActual.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
//		mapDeclaracionActual.put("conceptosImputados", null);
		
		LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.liquidaDeclaracionService");
//		List listAutoLiq = liquidaDeclaracionService.obtenerAutoliquidaciones(mapCabDeclaraActual, "AUTOLIQ", "0006", "0006");
		boolean existeLC0006Cancelada = liquidaDeclaracionService.existeLC0006Cancelada(mapDeclaracionActual);
		if(!existeLC0006Cancelada){
			//error Nro. 21
			lstErrores.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35457"));
		}
		
		return lstErrores;
	}
	
	/**estaImpugnadaDeuda**/
	public boolean estaImpugnadaDeuda(Declaracion declaracion){
		boolean result = false;
		
		boolean cumple = cumpleRequisitosParaImpugnarTributos(declaracion);
		if(!cumple){
			return cumple;
		}else{
			DeudaDeclaracionService deudaDeclaracionService = fabricaDeServicios.getService("diligencia.ingreso.deudaDeclaracionService");
			result = deudaDeclaracionService.estaImpugnadaDeudaPorDonacion(declaracion);
		}		
		return result;
	}	

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
	
}
