package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import java.text.ParseException;

//import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_LIQUI_NUMERACION;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_LIQUI_RECTIFICACION;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_LIQUI_REGULARIZACION;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TIPO_LIQUI_RELIQUIDACION;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_NUMERACION;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_RECTIFICACION;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT;
//import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.PecoAmazoniaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoDecla;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoProducto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.DeudaDocumDAO;
import pe.gob.sunat.despaduanero2.manifiesto.util.orquestador.tipos.TipoTransaccion;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.recauda2.genadeudo.model.CabDocliq;
import pe.gob.sunat.recauda2.genadeudo.model.MovCabliqdilig;
//import pe.gob.sunat.recauda2.genadeudo.model.dao.MovCabliqdiligDAO;
import pe.gob.sunat.recauda2.genadeudo.model.dao.CabDocliqDAO;
import org.springframework.util.CollectionUtils;
import pe.gob.sunat.recauda2.genadeudo.service.LiquidaDeclaracionService;
//import pe.gob.sunat.servicio2.registro.service.UsuarioService;

public class GeneraLiquidacionServiceImpl extends ValDuaAbstract implements GeneraLiquidacionService {

	//Logger log = Logger.getLogger(GeneraLiquidacionServiceImpl.class);

	//private LiquidaDeclaracionService liquidaDeclaracionService;
	//private CabDeclaraDAO cabDeclaraDAO;
	//private MovCabliqdiligDAO movCabliqdiligDAO;
	//private DeudaDocumDAO deudaDocumDAO;
	//private CabDocliqDAO cabDocliqDAO;


	@SuppressWarnings("unchecked")
	public Map obtenerLiquidacion(Declaracion declaracion, String codTransaccion, String numOrden, String codUsuario, String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender){
		Map retorna = new HashMap();
		HashMap paramDocLiq = new HashMap();
		DUA dua = declaracion.getDua();
		HashMap cabDeclara = new HashMap();
		String lcAnn_orden = "0000";
		String lcNume_orden = "000000";
		String lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_NUMERACION;
		String lccodTipdiligencia = " ";
		FechaBean fbCurrent = new FechaBean();
		String lcAnn_DUA = fbCurrent.getAnho();
		String lcNume_DUA = "000000";
		String lcTipoTrans = ConstantesDataCatalogo.TRANSACCION_NUMERACION;
		if (codTransaccion!=null) {
			lcTipoTrans = codTransaccion.substring(2, 4);
		}
		if (numOrden!=null) {
			lcAnn_orden = numOrden.substring(0, 4);
			lcNume_orden = numOrden.substring(4, 10);
		}
		if (codTransaccion==null || lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_NUMERACION)) {
			cabDeclara.put("NUM_DECLARACION","000000");
			cabDeclara.put("NUM_CORREDOC", Long.valueOf("0").longValue());
		} else {
			lcAnn_DUA = declaracion.getNumdeclRef().getAnnprese();
			lcNume_DUA = Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre().trim(), 6, '0');
			cabDeclara.put("NUM_DECLARACION",lcNume_DUA);
			cabDeclara.put("NUM_CORREDOC", declaracion.getNumeroCorrelativo());
			if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_RECTIFICACION)) {
				lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_RECTIFICACION;
			} else if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT) || 
					lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG) || 
					lcTipoTrans.equals("08")) {
				lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_REGULARIZACION;
			}
		}

		cabDeclara.put("NUM_ORDEN",lcNume_orden);
		Integer anho = new Integer(lcAnn_DUA);
		cabDeclara.put("ANN_PRESEN", anho);
		cabDeclara.put("COD_ADUANA", dua.getCodaduanaorden());
		cabDeclara.put("ANN_ORDEN", lcAnn_orden);
		// ECANA PAS20181U220400023 Liquidaci�n de la DSEER  
		//cabDeclara.put("COD_REGIMEN", dua.getCodregimen());
		cabDeclara.put("COD_REGIMEN", dua.getCodregimen().equals("28")?"DC":dua.getCodregimen());
		cabDeclara.put("NUM_DECLARACION", lcNume_DUA);
		DatoPago pago=dua.getPago();
		DatoPagoTrans trans=pago!=null?pago.getPagoTransaccion():null;
		Date feccarcr=trans!=null?trans.getFeccarcr():null;		

		DatoPagoDecla decla=pago!=null?pago.getPagoDeclaracion():null;
		String xcbco_pael=decla!=null?decla.getCodbcopagoelec():null;
		String xccta_pael=decla!=null?decla.getNumctapagoelec():null;
		String codGarantia=decla!=null?decla.getCodgarantia():null;


		try {

			DatoManifiesto manif=dua.getManifiesto();
			Date fectermino=manif!=null?manif.getFectermino():null;
			//PAS20145E220000090 - MATC 20140617  INICIO
			if( fectermino!=null && SunatDateUtils.sonIguales(fectermino, SunatDateUtils.getDefaultDate(), SunatDateUtils.COMPARA_SOLO_FECHA) ) { 
				fectermino = declaracion.getDua().getFecLlegada();
			}
			//PAS20145E220000090 - MATC 20140617  FINAL
			if (feccarcr!=null) {
				cabDeclara.put("FEC_CARCR", DateUtil.dateToString(feccarcr, "dd/MM/yyyy"));
			} else {
				cabDeclara.put("FEC_CARCR", "01/01/0001");
			}
			if ( fectermino==null) {
				cabDeclara.put("FEC_TERM", "01/01/0001");
			} else {
				cabDeclara.put("FEC_TERM", DateUtil.dateToString(fectermino, "dd/MM/yyyy"));
			}
			if (dua.getFecdeclaracion()!=null) {
				if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_NUMERACION)) {
					cabDeclara.put("FEC_DECLARACION", DateUtil.dateToString(DateUtil.getToday(), "dd/MM/yyyy HH:mm:ss"));					
				} else {
					cabDeclara.put("FEC_DECLARACION", DateUtil.dateToString(dua.getFecdeclaracion(), "dd/MM/yyyy HH:mm:ss"));
				}
			} else {
				cabDeclara.put("FEC_DECLARACION", DateUtil.dateToString(DateUtil.getToday(), "dd/MM/yyyy HH:mm:ss"));
			}
		}catch (ParseException e) {
			cabDeclara.put("FEC_CARCR", "01/01/0001");
			cabDeclara.put("FEC_TERM", "01/01/0001");
			cabDeclara.put("FEC_DECLARACION","01/01/0001"); 
		}
		cabDeclara.put("NUM_MANIFIESTO", dua.getManifiesto().getNummanif());
		//		String lcTipoDespa = "0";
		//		if (dua.getCodmodalidad().equals("10")) {
		//			lcTipoDespa = "1"; // Anticipado
		//		} else if (dua.getCodmodalidad().equals("01")) {
		//			lcTipoDespa = "2"; // Urgente
		//		}
		
		// ECANA PAS20181U220400023 Liquidaci�n de la DSEER  - Para calculos de tributos en la nuemracion a la DSEER se le considera con modalidad anticipada
		//cabDeclara.put("COD_MODALIDAD", dua.getCodmodalidad());
		if (dua.getCodregimen().equals("28") && (ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER.equals(codTransaccion) || ConstantesDataCatalogo.TRANSACCION_MANIFIESTO_NUMERACION_MDEER.equals(codTransaccion))) {
			cabDeclara.put("COD_MODALIDAD", "10");
		}else {
			cabDeclara.put("COD_MODALIDAD", dua.getCodmodalidad());
		}
		cabDeclara.put("COD_TIPTRATMERC", dua.getCodtipotratamiento()==null?"1":dua.getCodtipotratamiento());
		cabDeclara.put("MTO_TOTAUTOLIQ", dua.getMtototautoliq()==null?new BigDecimal("0"):dua.getMtototautoliq());
		cabDeclara.put("MTO_TOTFLETEDOL", dua.getMtotflecomex()==null?new BigDecimal("0"):dua.getMtotflecomex());
		cabDeclara.put("MTO_TOTFOBDOL", dua.getMtotfobclvta()==null?new BigDecimal("0"):dua.getMtotfobclvta());
		cabDeclara.put("MTO_TOTSEGDOL", dua.getMtotsegotros()==null?new BigDecimal("0"):dua.getMtotsegotros());
		cabDeclara.put("COD_ADUDEST", dua.getOtraAduana().getCodopadusal()==null?" ":dua.getOtraAduana().getCodopadusal());
		cabDeclara.put("IND_SOCORRO", dua.getIndSocorro()==null?" ":dua.getIndSocorro());
		cabDeclara.put("CNT_PESOBRUTO_TOTAL", dua.getCnttpesobruto()==null?new BigDecimal("0"):dua.getCnttpesobruto());
		cabDeclara.put("CNT_TOTBULTOS", dua.getCnttcantbulto()==null?new BigDecimal("0"):dua.getCnttcantbulto());
		cabDeclara.put("COD_ESTDUA", dua.getCodEstdua()==null?"00":dua.getCodEstdua());
		cabDeclara.put("COD_CANAL", " ");
		cabDeclara.put("COD_BCOPAGOELEC", xcbco_pael==null?" ":xcbco_pael);
		cabDeclara.put("NUM_CUENTAPAGOE", xccta_pael==null?" ":xccta_pael);
		//cabDeclara.put("COD_RUCLUGRECEP", dua.getNumruclugarecep()==null?" ":dua.getNumruclugarecep());
		cabDeclara.put("COD_RUCLUGRECEP"," ");
		cabDeclara.put("COD_PROPIEDAD", dua.getCodpropiedad()==null?" ":dua.getCodpropiedad());
		cabDeclara.put("NUM_CTACTE", SunatStringUtils.isEmpty(codGarantia)?" ":codGarantia);
		if (dua.getFecfinacoregimen()==null) {
			cabDeclara.put("FEC_VENREGIMEN", "01/01/0001");
		} else {
			try {
				cabDeclara.put("FEC_VENREGIMEN", DateUtil.dateToString(dua.getFecfinacoregimen(), "dd/MM/yyyy"));
			} catch (ParseException e) {
				cabDeclara.put("FEC_VENREGIMEN", "01/01/0001");
			}
		}

		/**P46**/
		List<DatoIndicadores> lstIndicadores = declaracion.getDua().getListIndicadores()!=null?declaracion.getDua().getListIndicadores():new ArrayList<DatoIndicadores>();
		List listIndicadoresDua = new ArrayList();
		HashMap indicador = new HashMap();
		if(!CollectionUtils.isEmpty(lstIndicadores)){
			DatoIndicadores datoIndicadores = lstIndicadores!=null?declaracion.getDua().getListIndicadores().get(0):new DatoIndicadores();		
			indicador.put("COD_TIPINDICADOR", datoIndicadores.getCodtipoindica());
			listIndicadoresDua.add(indicador);
		}		
		/**FIN P46**/		

		// ECANA PAS20181U220400023 Liquidaci�n de la DSEER  
		//Participante datodeclarante = declaracion.getDua().getDeclarante();
		Participante datodeclarante = dua.getCodregimen().equals("28")?declaracion.getDua().getConsignatario():declaracion.getDua().getDeclarante();

		List listParticipanteDoc = new ArrayList();
		HashMap participanteDoc = new HashMap(); 
		// ECANA PAS20181U220400023 Liquidaci�n de la DSEER
		if (dua.getCodregimen().equals("28")){
			participanteDoc.put("COD_TIPPARTIC", "50");  // ESER
		} else {
			participanteDoc.put("COD_TIPPARTIC", "41");  // AGENTE DE ADUANA
		}
		//participanteDoc.put("COD_TIPPARTIC", "41");  // AGENTE DE ADUANA
		participanteDoc.put("COD_TIPDOC", " ");
		participanteDoc.put("NUM_DOCIDENT", numeroDocumentoIdentidadSender); 
		listParticipanteDoc.add(participanteDoc);
		HashMap ParticipanteDoc2 = new HashMap();
		ParticipanteDoc2.put("COD_TIPPARTIC", "45");  // DUE�O O CONSIGNTARIO
		ParticipanteDoc2.put("COD_TIPDOC", datodeclarante.getTipoDocumentoIdentidad().getCodDatacat());
		ParticipanteDoc2.put("NUM_DOCIDENT", datodeclarante.getNumeroDocumentoIdentidad());
		listParticipanteDoc.add(ParticipanteDoc2);

		List listConvenioSerie = new ArrayList();
		List listDocupreceDua = new ArrayList();
		List listDetDeclara = new ArrayList(); 
		boolean generarLCTPI100 = false;  //PAS20144E610000076 - 20140305 MATC
		boolean generarLC15_NO_9 = false;//jenciso - RIN05 (100 y 229)
		boolean generarLC15_SI_9 = false;//jenciso - RIN05 (dem�s TPIs incluyendo 100 y 229)
		String indicador15 = this.getIndicador(declaracion.getDua(), ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		String certificadoOrigen = "";
		boolean generarLC0006 = false;  //RIN 08 - Peco-Amazonia

		for(DatoSerie serie:declaracion.getDua().getListSeries()){
			HashMap detDeclara = new HashMap();
			DatoDocTransporte docTransp = getDocTransporte(dua,serie);
			if (docTransp!=null) {
				detDeclara.put("NUM_DOCTRANSP", docTransp.getNumdoctransporte());
				detDeclara.put("COD_PUER_EMB", docTransp.getCodpuerto()); 
				try {
					detDeclara.put("FEC_EMBARQUE", DateUtil.dateToString(docTransp.getFecembarque(), "dd/MM/yyyy"));
				} catch (ParseException e) {
					detDeclara.put("FEC_EMBARQUE", "01/01/0001");
				}
			} else {
				// ECANA PAS20181U220400023 Liquidaci�n de la DSEER
				//detDeclara.put("NUM_DOCTRANSP", " ");
				//detDeclara.put("COD_PUER_EMB", " "); 
				//detDeclara.put("FEC_EMBARQUE", "01/01/0001");
				if (dua.getCodregimen().equals("28")){
					detDeclara.put("NUM_DOCTRANSP", serie.getDocumentoTransporte().getNumdoctransporte()!=null?serie.getDocumentoTransporte().getNumdoctransporte():" ");
					detDeclara.put("COD_PUER_EMB", serie.getDocumentoTransporte().getCodpuerto()!=null?serie.getDocumentoTransporte().getCodpuerto():" "); 
					detDeclara.put("FEC_EMBARQUE", serie.getDocumentoTransporte().getFecembarque()!=null?serie.getDocumentoTransporte().getFecembarque() :"01/01/0001");	
				}else {
					detDeclara.put("NUM_DOCTRANSP", " ");
					detDeclara.put("COD_PUER_EMB", " "); 
					detDeclara.put("FEC_EMBARQUE", "01/01/0001");
			}
			}

			DatoProducto product=serie.getProducto();
			String codpantidum=product!=null?product.getCodpantidum():null;
			String codexpantidum=product!=null?product.getCodexpantidum():null;
			BigDecimal mtofobfactu=product!=null?product.getMtofobfactu():null;



			detDeclara.put("COD_ADUANA", dua.getCodaduanaorden());
			detDeclara.put("CNT_BULTO", serie.getCntbultos());
			detDeclara.put("CNT_PESO_BRUTO", serie.getCntpesobruto());
			detDeclara.put("CNT_PESO_NETO", serie.getCntpesoneto());
			detDeclara.put("CNT_UNIISC", serie.getCntunicomisc());
			detDeclara.put("CNT_UNIFIS", serie.getCntunifis());
			detDeclara.put("COD_ULTRACTIVIDAD", serie.getCodaplultra());
			detDeclara.put("COD_PAISORIGEN", serie.getCodpaisorige());
			detDeclara.put("COD_PRODANTID", codpantidum); 
			detDeclara.put("COD_TIPTASAAPLICAR", serie.getCodtnan());
			detDeclara.put("COD_EXPOAPLICANTID", codexpantidum); 
			detDeclara.put("IND_ACOGCODLIBER", serie.getValindcodlib());
			detDeclara.put("COD_TIPFLETE", serie.getCodtipoflete());
			detDeclara.put("COD_TIPMARGEN", serie.getCodtipomarge());
			detDeclara.put("MTO_AJUSTE", serie.getMtoajuste());
			detDeclara.put("MTO_FLETEDOL", serie.getMtofledol());
			detDeclara.put("MTO_FOBDOL", serie.getMtofobdol());
			detDeclara.put("MTO_FOBFACT", mtofobfactu);
			detDeclara.put("MTO_SEGDOL", serie.getMtosegdol());
			detDeclara.put("NUM_PARCORRELACION", serie.getNumpartcorre());
			detDeclara.put("NUM_PARNABANDINA", serie.getNumpartnaban());
			detDeclara.put("NUM_PARNALADISA", serie.getNumpartnalad());
			detDeclara.put("NUM_PARTNANDI", serie.getNumpartnandi());
			detDeclara.put("NUM_SECSERIE", serie.getNumserie());
			detDeclara.put("MTO_PVPMONNAC", serie.getValpreciovta());
			detDeclara.put("COD_ESTMERC", serie.getCodestamerca());
			//DZC PAS20134E620000508 
			detDeclara.put("COD_UNIFISICA", serie.getCodunifis());
			listDetDeclara.add(detDeclara);

			if (serie.getCodliberatorio()!=null && serie.getCodliberatorio()>0 && dua.getCodregimen().equals("10")) {
				HashMap convenioSerie = new HashMap();
				convenioSerie.put("NUM_SECSERIE", serie.getNumserie());
				convenioSerie.put("COD_TIPCONVENIO", "C");
				convenioSerie.put("COD_CONVENIO", serie.getCodliberatorio());
				convenioSerie.put("IND_DEL", "0");
				listConvenioSerie.add(convenioSerie);

				//INICIO RIN08 - PECO-Amazonia
				if(serie.getCodliberatorio()==4438){
					generarLC0006 = true;
				}
				//FIN RIN08
			}
			if (serie.getCodtratprefe()!=null && serie.getCodtratprefe()>0) {
				HashMap convenioSerie1 = new HashMap();
				convenioSerie1.put("NUM_SECSERIE", serie.getNumserie());
				convenioSerie1.put("COD_TIPCONVENIO", "T");
				convenioSerie1.put("COD_CONVENIO", serie.getCodtratprefe());
				convenioSerie1.put("IND_DEL", "0");
				listConvenioSerie.add(convenioSerie1);
			}
			if (serie.getCodconvinter()!=null && serie.getCodconvinter()>0 && dua.getCodregimen().equals("10")) {
				HashMap convenioSerie2 = new HashMap();
				convenioSerie2.put("NUM_SECSERIE", serie.getNumserie());
				convenioSerie2.put("COD_TIPCONVENIO", "I");
				convenioSerie2.put("COD_CONVENIO", serie.getCodconvinter());
				convenioSerie2.put("IND_DEL", "0");
				listConvenioSerie.add(convenioSerie2);

				//INICIO RIN 08 - PECO-Amazonia
				if(serie.getCodconvinter()==34 || serie.getCodconvinter()==35 || serie.getCodconvinter()==36){
					generarLC0006 = true;
				}
				//INICIO RIN 08 - PECO-Amazonia

				//Inicio PAS20144E610000076 - 20140305 MATC
				//RIN05 20141127 ya no va 
				//				if( false && (serie.getCodconvinter()==100 || serie.getCodconvinter()==229 || serie.getCodconvinter()==14 )) {//jenciso RIN05 ya no debe entrar aqui
				//					List<DatoAutocertificacion> listCertiOrigen=getCertiOrigen(dua,serie);
				//					String codTipoCO = CollectionUtils.isEmpty(listCertiOrigen) ? null:listCertiOrigen.get(0).getCodtipoCO(); //Tipo de certificado de origen
				//					String numdocumento = listCertiOrigen.get(0).getNumdocumento(); //Numero de CO
				//					if( codTipoCO!= null && codTipoCO.equals("1") && (numdocumento==null || numdocumento.equals("")) ) 
				//						generarLCTPI100 = true;
				//				}
				//Final PAS20144E610000076 - 20140305 MATC

				//jenciso RIN05 Inicio
				String tipoMargen = serie.getCodtipomarge();
				if(indicador15!=null){
					//100 229 margen!=9 margen == vacio
					if( (serie.getCodconvinter()==100 || serie.getCodconvinter()==229 ) && (tipoMargen==null || tipoMargen.trim().isEmpty() || !tipoMargen.equals("9")) ) {						
						List<DatoAutocertificacion> listCertificado =  this.getCertiOrigen(dua, serie);
						DatoAutocertificacion datoCertificado = !CollectionUtils.isEmpty(listCertificado)?listCertificado.get(0): null;

						if(datoCertificado == null || (datoCertificado.getCodtipoCO() == null && datoCertificado.getNumdocumento() == null && datoCertificado.getFecemision() == null 
								&& datoCertificado.getCodcriterioO() == null && datoCertificado.getCodffco() == null)){
							generarLC15_NO_9= true;
						}

					}

					//todos margen =9
					if( tipoMargen!=null && tipoMargen.equals("9")){
						generarLC15_SI_9 = true;
						//obtiene el certificado origen para enviar en el mensaje
						List<DatoAutocertificacion> listCertificado =  this.getCertiOrigen(dua, serie);
						DatoAutocertificacion datoCertificado = !CollectionUtils.isEmpty(listCertificado)?listCertificado.get(0): null;

						if(datoCertificado!=null){
							certificadoOrigen= datoCertificado.getNumdocumento()!=null ? datoCertificado.getNumdocumento():"";
							certificadoOrigen= certificadoOrigen.concat(" - ").concat(SunatDateUtils.getFormatDate(datoCertificado.getFecemision(), "dd/MM/yyyy"));
						}
					}

				}
				//jenciso fin
			}
			Elementos<DatoRegPrecedencia> regimenes = serie.getListRegPrecedencia();
			if (regimenes!=null) {
				for(DatoRegPrecedencia regimen:regimenes){
					HashMap docupreceDua = new HashMap();
					docupreceDua.put("NUM_SECSERIE", serie.getNumserie());
					docupreceDua.put("COD_ADUANAPRE", regimen.getCodaduapre());
					if (regimen.getAnndeclpre()!=null) {
						if (regimen.getAnndeclpre().length()>=4) {
							docupreceDua.put("ANN_PRESENPRE", regimen.getAnndeclpre().substring(0, 4));
						} else {
							docupreceDua.put("ANN_PRESENPRE", "0000");
						}
					}
					docupreceDua.put("COD_REGIMENPRE", regimen.getCodregipre());
					docupreceDua.put("NUM_CORREDOCPRE", regimen.getNumdeclpre());
					listDocupreceDua.add(docupreceDua);
					// ECANA PAS20181U220400023 Liquidaci�n de la DSEER
					if (dua.getCodregimen().equals("28")){
						HashMap convenioSerie3 = new HashMap();
						convenioSerie3.put("NUM_SECSERIE", serie.getNumserie());
						convenioSerie3.put("COD_TIPCONVENIO", "C");
						convenioSerie3.put("COD_CONVENIO", "4468"); // CL que utilizan las partidas con categoria 4D2 en el SIGAD
						convenioSerie3.put("IND_DEL", "0");
						listConvenioSerie.add(convenioSerie3);
					}
				}
			}
		}
		//Liquida
		paramDocLiq.put("codUsu_modif", "SEIDA");
		paramDocLiq.put("codTipLiqui", lccodTipLiqui);
		paramDocLiq.put("codTipdiligencia", lccodTipdiligencia);
		paramDocLiq.put("cabDeclara", cabDeclara);
		paramDocLiq.put("listDetDeclara", listDetDeclara);
		paramDocLiq.put("listParticipanteDoc", listParticipanteDoc);
		paramDocLiq.put("listConvenioSerie", listConvenioSerie);
		paramDocLiq.put("listDocupreceDua", listDocupreceDua);
		/*P46*/
		paramDocLiq.put("listIndicadoresDua", listIndicadoresDua);
		/*FIN P46*/
		paramDocLiq.put("generaLCTPI100", ( generarLCTPI100 ? "SI" : "NO" ));  //PAS20144E610000076 - 20140304 MATC  Se a�ade en el mapa
		paramDocLiq.put("generarLC15_NO_9", generarLC15_NO_9 ? "SI": "NO");//jenciso RIN05
		paramDocLiq.put("generarLC15_SI_9", generarLC15_SI_9 ? "SI": "NO");//jenciso RIN05
		paramDocLiq.put("certiOrigen", certificadoOrigen);//jenciso RIN05
		//Inicio RIN08 - PECO-Amazonia - Se a�ade en el mapa		
		paramDocLiq.put("generaLC0006", ( generarLC0006 ? "SI" : "NO" ));      
		//Fin RIN08
		LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("liquidaDeclaracionService");
		retorna = liquidaDeclaracionService.preliquidacion(paramDocLiq);
		//Actualiza el flete prorrateado
		listDetDeclara = (List)paramDocLiq.get("listDetDeclara");
		for (int i = 0; i<listDetDeclara.size(); i++){ 
			HashMap detDeclara = (HashMap) listDetDeclara.get(i);
			for(int j = 0; j<declaracion.getDua().getListSeries().size(); j++){
				DatoSerie serie = declaracion.getDua().getListSeries().get(j);
				if (detDeclara.get("NUM_SECSERIE").equals(serie.getNumserie())) {
					serie.setMtofledol((BigDecimal)detDeclara.get("MTO_FLETEDOL"));
					declaracion.getDua().getListSeries().set(j, serie);
				}
			}
		}
		return retorna;

	}

	@SuppressWarnings("unchecked")
	public Map obtenerDiferenciaTributaria(Declaracion declaracion, String codTransaccion, String numOrden, String codUsuario, String tipoDocumentoIdentidadSender, String numeroDocumentoIdentidadSender){
		LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("liquidaDeclaracionService");
		Map mapDifTributos = new HashMap();		 
		String lcAnn_orden = "0000";
		String lcNume_orden = "000000";
		String lccodTipLiqui = " ";
		String lccodTipdiligencia = " ";
		String lcTipoTrans = ConstantesDataCatalogo.TRANSACCION_NUMERACION;

		boolean esPecoAmazonia = false; //RIN 08 - 20150319 

		if (codTransaccion!=null) {
			lcTipoTrans = codTransaccion.substring(2, 4);
		}
		if (numOrden!=null) {
			lcAnn_orden = numOrden.substring(0, 4);
			lcNume_orden = numOrden.substring(4, 10);
		}
		if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_RECTIFICACION)) {
			lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_RECTIFICACION;
		} else if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT) || lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG) || lcTipoTrans.equals("08")) {
			lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_REGULARIZACION;
		} else if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_NUMERACION)) {
			lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_NUMERACION;
		} else {
			return mapDifTributos;
		}

		//Inicio PAS20155E220000081 - mtorralba 20150220 - Se invoca al m�todo con 3 par�metros para el env�os de Regularizaci�n
		Integer lnNum_reliq = 0;
        //if (lccodTipLiqui.equals(ConstantesDataCatalogo.TIPO_LIQUI_REGULARIZACION)) {
        ///    lnNum_reliq = liquidaDeclaracionService.ObtenerNroDeReliq (lccodTipLiqui, declaracion.getNumeroCorrelativo(), false);
        //}
        //else {
			//Inicio RIN 08 - 20150318
               if(lccodTipLiqui.equals(ConstantesDataCatalogo.TIPO_LIQUI_RECTIFICACION) || lccodTipLiqui.equals(ConstantesDataCatalogo.TIPO_LIQUI_REGULARIZACION)){
				//mordonezl RIN08 PASE PAS201830001100016
				// SE ADICIONA PARA CASOS DE DESISTIMIENTO DE PECO Y AMAZONIA EN LA RECTI
				PecoAmazoniaService pecoAmazoniaService = fabricaDeServicios.getService("pecoAmazoniaService");
				Map<Integer,Object> mapaSerieDUA = pecoAmazoniaService.esPECOAmazonia(declaracion);
				String esPecoAmazoniaActual = mapaSerieDUA.get(Integer.valueOf("0")).toString();		
				//PAS201830001100016 - mtorralba 20190201 - Se verifica si antes fue Peco Amazonia
				String esPecoAmazoniaBD = pecoAmazoniaService.esPecoAmazonia(declaracion.getNumeroCorrelativo());
				
				if(!ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(esPecoAmazoniaActual) ||
				   (ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(esPecoAmazoniaActual) && !ConstantesDataCatalogo.PREFERENCIAS_DECL_NINGUN_CONVENIO.equals(esPecoAmazoniaBD))		
				) { // la declaracion que transmite en la recti tiene convenio
					lnNum_reliq = liquidaDeclaracionService.obtenerReliqPecoAmazonia(declaracion.getNumeroCorrelativo());
					if(lnNum_reliq < 0) 
						lnNum_reliq = liquidaDeclaracionService.ObtenerNroDeReliq(lccodTipLiqui, declaracion.getNumeroCorrelativo());
					else
						esPecoAmazonia = true; //RIN 08 - 20150319
				}else{
					lnNum_reliq = liquidaDeclaracionService.ObtenerNroDeReliq (lccodTipLiqui, declaracion.getNumeroCorrelativo());
				}
				
			}
			else			
				lnNum_reliq = liquidaDeclaracionService.ObtenerNroDeReliq (lccodTipLiqui, declaracion.getNumeroCorrelativo());
			//Fin RIN 08
        //} //Cambios pase PAS20191U220100011 - Problemas en la regularizacion - Edu

		//Fin PAS20155E220000081 - mtorralba 20150220 - Se invoca al m�todo con 3 par�metros para el env�os de Regularizaci�n

		MovCabliqdilig tmpMovCabliqdilig = new MovCabliqdilig();
		if (lccodTipLiqui.equals(ConstantesDataCatalogo.TIPO_LIQUI_NUMERACION)) {
			tmpMovCabliqdilig.setAnnDocliq("0000");
			tmpMovCabliqdilig.setNumDocliq("000000");
			tmpMovCabliqdilig.setCodRegDocliq(declaracion.getDua().getCodregimen());
		} else {
			tmpMovCabliqdilig.setAnnDocliq(declaracion.getNumdeclRef().getAnnprese());
			tmpMovCabliqdilig.setNumDocliq(Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre().trim(), 6, '0'));
			tmpMovCabliqdilig.setCodRegDocliq(declaracion.getNumdeclRef().getCodregimen());
		}
		tmpMovCabliqdilig.setAnnOrden(lcAnn_orden);
		tmpMovCabliqdilig.setCodAduDocliq(declaracion.getCodaduana());
		tmpMovCabliqdilig.setCodAgente(numeroDocumentoIdentidadSender);
		tmpMovCabliqdilig.setCodTipLiqui(lccodTipLiqui);
		tmpMovCabliqdilig.setCodTipdiligencia(lccodTipdiligencia);
		tmpMovCabliqdilig.setNumOrden(lcNume_orden);
		tmpMovCabliqdilig.setNumReliq(lnNum_reliq);

		//RIN 08 - 20150319
		if(esPecoAmazonia)
			mapDifTributos = liquidaDeclaracionService.calculaDiferenciaDeudaTrib(declaracion.getNumeroCorrelativo(), tmpMovCabliqdilig, declaracion.getCodaduana(), false, esPecoAmazonia); 
		else
			mapDifTributos = liquidaDeclaracionService.calculaDiferenciaDeudaTrib(declaracion.getNumeroCorrelativo(), tmpMovCabliqdilig, declaracion.getCodaduana());
		//Fin RIN 08

		mapDifTributos.put("movCabliqdilig", tmpMovCabliqdilig);
		return mapDifTributos;
	}

	@SuppressWarnings("unchecked")
	public Map grabaDUAEnPreliq(Declaracion declaracion, String codTransaccion, String numOrden, String numeroDocumentoIdentidadSender) {
		LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("liquidaDeclaracionService");
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDef");
		
		Map resultado = new HashMap();
		resultado.put("GRABACION", "ERROR");
		resultado.put("MENSAJE", " ");

		String lcTipoTrans = ConstantesDataCatalogo.TRANSACCION_NUMERACION;
		String lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_NUMERACION;
		String lccodTipdiligencia = " ";
		DUA dua = declaracion.getDua();
		Map mapDifTributos = new HashMap();
		List lstAutoliquidaciones = new ArrayList();
		if (declaracion.getNumeroCorrelativo()==null) {
			resultado.put("MENSAJE", "NUMERO CORRELATIVO DE DOCUMENTO ES NULO");
			return resultado;
		}
		if (codTransaccion!=null) {
			lcTipoTrans = codTransaccion.substring(2, 4);
		}
		Map<String, Object> params = new HashMap();
		params.put("numeroCorrelativo", declaracion.getNumeroCorrelativo());
		DUA duaTmp = cabDeclaraDAO.selectByNumCorredoc(params);
		//Liquida
		String lcAnn_orden = "0000";
		String lcNume_orden = "000000";
		if (numOrden!=null) {
			lcAnn_orden = numOrden.substring(0, 4);
			lcNume_orden = numOrden.substring(4, 10);
		} 
		if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_RECTIFICACION)) {
			lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_RECTIFICACION;
		} else if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT) || lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG)) {
			lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_REGULARIZACION;
		} 

		HashMap mapDocLiq = new HashMap();
		mapDocLiq.put("numCorreDoc", declaracion.getNumeroCorrelativo());
		mapDocLiq.put("codAduDocliq", declaracion.getCodaduana());
		mapDocLiq.put("annDocliq", duaTmp.getAnnpresen());
		mapDocLiq.put("numDocliq", Cadena.padLeft(duaTmp.getNumdocumento().trim(), 6, '0'));
		mapDocLiq.put("annOrden", lcAnn_orden);
		mapDocLiq.put("numOrden", lcNume_orden);
		mapDocLiq.put("codAgente", numeroDocumentoIdentidadSender);
		// ECANA PAS20181U220400023 Liquidaci�n de la DSEER 
		//mapDocLiq.put("codRegDocliq", dua.getCodregimen());
		mapDocLiq.put("codRegDocliq", dua.getCodregimen().equals("28")?"DC":dua.getCodregimen());
		mapDocLiq.put("codTipLiqui", lccodTipLiqui);
		mapDocLiq.put("codTipdiligencia", lccodTipdiligencia);
		mapDocLiq.put("diferenciaTributos", mapDifTributos);
		mapDocLiq.put("lstAutoliquidaciones", lstAutoliquidaciones);
		liquidaDeclaracionService.grabaDUAEnPreliq(mapDocLiq);
		resultado.put("GRABACION", "OK");
		return resultado;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Map grabaLiquidacion(Declaracion declaracion, String codTransaccion, String numOrden, String numeroDocumentoIdentidadSender){
		//INICIO  RIN08 - PECO-Amazonia Se adiciona el sexto parametro
		return grabaLiquidacion(declaracion, codTransaccion, numOrden, numeroDocumentoIdentidadSender, null, null);
		//FIN RIN08
	}


	@SuppressWarnings("unchecked")
	@Transactional
	public Map grabaLiquidacion(Declaracion declaracion, String codTransaccion, String numOrden, String numeroDocumentoIdentidadSender, Map mapMontos /*montosTPI100*/, Map montosLC0006){//jenciso RIN05
		LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("liquidaDeclaracionService");
		CabDeclaraDAO cabDeclaraDAO = fabricaDeServicios.getService("cabDeclaraDef");
		CabDocliqDAO cabDocliqDAO = fabricaDeServicios.getService("cabDocliqDef");
		
		grabaDUAEnPreliq(declaracion, codTransaccion, numOrden, numeroDocumentoIdentidadSender);

		Map resultado = new HashMap();
		resultado.put("GRABACION", "ERROR");
		resultado.put("MENSAJE", " ");

		String lcTipoTrans = ConstantesDataCatalogo.TRANSACCION_NUMERACION;
		String lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_NUMERACION;
		String lccodTipdiligencia = " ";
		DUA dua = declaracion.getDua();
		Map mapDifTributos = new HashMap();
		List lstAutoliquidaciones = new ArrayList();
		if (declaracion.getNumeroCorrelativo()==null) {
			resultado.put("MENSAJE", "NUMERO CORRELATIVO DE DOCUMENTO ES NULO");
			return resultado;
		}
		if (codTransaccion!=null) {
			lcTipoTrans = codTransaccion.substring(2, 4);
		}
		Map<String, Object> params = new HashMap();
		params.put("numeroCorrelativo", declaracion.getNumeroCorrelativo());
		DUA duaTmp = cabDeclaraDAO.selectByNumCorredoc(params);
		//Liquida
		String lcAnn_orden = "0000";
		String lcNume_orden = "000000";
		if (numOrden!=null) {
			lcAnn_orden = numOrden.substring(0, 4);
			lcNume_orden = numOrden.substring(4, 10);
		} 
		if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_RECTIFICACION)) {
			lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_RECTIFICACION;
		} else if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT) || lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG)) {
			lccodTipLiqui = ConstantesDataCatalogo.TIPO_LIQUI_REGULARIZACION;
		} 

		if (lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_RECTIFICACION) || lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_ANT) || lcTipoTrans.equals(ConstantesDataCatalogo.TRANSACCION_REGULARIZACION_URG)) {
			MovCabliqdilig tmpMovCabliqdilig = new MovCabliqdilig();
			tmpMovCabliqdilig.setAnnDocliq(declaracion.getNumdeclRef().getAnnprese());
			tmpMovCabliqdilig.setAnnOrden(lcAnn_orden);
			tmpMovCabliqdilig.setCodAduDocliq(declaracion.getCodaduana());
			tmpMovCabliqdilig.setCodAgente(numeroDocumentoIdentidadSender);
			tmpMovCabliqdilig.setCodRegDocliq(declaracion.getNumdeclRef().getCodregimen());
			tmpMovCabliqdilig.setCodTipLiqui(lccodTipLiqui);
			tmpMovCabliqdilig.setCodTipdiligencia(lccodTipdiligencia);
			tmpMovCabliqdilig.setNumDocliq(Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre().trim(), 6, '0'));
			tmpMovCabliqdilig.setNumOrden(lcNume_orden);
			// Para obtener el nro de Reliquidaci�n.
			CabDocliq tmpCabDocliq = new CabDocliq();
			tmpCabDocliq.setCodAduDocliq(tmpMovCabliqdilig.getCodAduDocliq());
			tmpCabDocliq.setAnnDocliq(tmpMovCabliqdilig.getAnnDocliq());
			tmpCabDocliq.setNumDocliq(tmpMovCabliqdilig.getNumDocliq());
			tmpCabDocliq.setCodRegDocliq(tmpMovCabliqdilig.getCodRegDocliq());
			tmpCabDocliq.setCodTipLiqui(tmpMovCabliqdilig.getCodTipLiqui());
			tmpCabDocliq.setCodTipdiligencia(tmpMovCabliqdilig.getCodTipdiligencia());
			tmpCabDocliq.setAnnOrden(tmpMovCabliqdilig.getAnnOrden());
			tmpCabDocliq.setNumOrden(tmpMovCabliqdilig.getNumOrden());
			tmpCabDocliq.setCodAgente(tmpMovCabliqdilig.getCodAgente());
			Integer lnNumReliq = 0;
			if (lccodTipLiqui.equals(ConstantesDataCatalogo.TIPO_LIQUI_RECTIFICACION)) {
				lnNumReliq = Integer.valueOf((cabDocliqDAO.selectMaxReliq(tmpCabDocliq)).toString());
			}
			tmpMovCabliqdilig.setNumReliq(lnNumReliq);
			mapDifTributos = liquidaDeclaracionService.calculaDiferenciaDeudaTrib(declaracion.getNumeroCorrelativo(), tmpMovCabliqdilig, declaracion.getCodaduana());

			Map mapCabDeclaraActual = new HashMap();
			mapCabDeclaraActual.put("COD_ADUANA", declaracion.getCodaduana());
			mapCabDeclaraActual.put("ANN_PRESEN", declaracion.getNumdeclRef().getAnnprese());
			mapCabDeclaraActual.put("NUM_DECLARACION", Cadena.padLeft(declaracion.getNumdeclRef().getNumcorre().trim(), 6, '0'));
			mapCabDeclaraActual.put("COD_REGIMEN", declaracion.getNumdeclRef().getCodregimen());
			mapCabDeclaraActual.put("NUM_CORREDOC", declaracion.getNumeroCorrelativo());
			lstAutoliquidaciones = liquidaDeclaracionService.obtenerAutoliquidaciones(mapCabDeclaraActual);

		} else {
			mapDifTributos = null;
		}

		HashMap mapDocLiq = new HashMap();
		mapDocLiq.put("numCorreDoc", declaracion.getNumeroCorrelativo());
		mapDocLiq.put("codAduDocliq", declaracion.getCodaduana());
		mapDocLiq.put("annDocliq", duaTmp.getAnnpresen());
		mapDocLiq.put("numDocliq", Cadena.padLeft(duaTmp.getNumdocumento().trim(), 6, '0'));
		mapDocLiq.put("annOrden", lcAnn_orden);
		mapDocLiq.put("numOrden", lcNume_orden);
		mapDocLiq.put("codAgente", numeroDocumentoIdentidadSender);
		mapDocLiq.put("codRegDocliq", dua.getCodregimen());
		mapDocLiq.put("codTipLiqui", lccodTipLiqui);
		mapDocLiq.put("codTipdiligencia", " ");
		mapDocLiq.put("diferenciaTributos", mapDifTributos);
		mapDocLiq.put("lstAutoliquidaciones", lstAutoliquidaciones);	
		//MATC - 20140303
		// ECANA PAS20181U220400023 Liquidaci�n de la DSEER  - Para calculos de tributos en la nuemracion a la DSEER se le considera con modalidad anticipada
		//if (!(ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER.equals(codTransaccion) || ConstantesDataCatalogo.TRANSACCION_MANIFIESTO_NUMERACION_MDEER.equals(codTransaccion))) {
		if (!SunatStringUtils.include(codTransaccion,
				new String[] { ConstantesDataCatalogo.TRANSACCION_NUMERACION_IMPORTACION_EER,
						ConstantesDataCatalogo.TRANSACCION_MANIFIESTO_NUMERACION_MDEER, TipoTransaccion.TX_0443.value(),
						TipoTransaccion.TX_0444.value(), TipoTransaccion.TX_0446.value() })) {//20190516 jgarciaal no aplica para estas TXs
			//PAS20144E610000076 - Se a�ade un nuevo par�metro en el mapa de par�metros que pasa a grabaLiquidacion
			mapDocLiq.put("MontosTPI100", mapMontos.get("montoTPI100"));//jenciso RIN05
			mapDocLiq.put("montoLC15N9", mapMontos.get("montoLC15N9"));
			mapDocLiq.put("montoLC15S9", mapMontos.get("montoLC15S9"));
			//INICIO RIN 08 - PECO-Amazonia - reutilizamos el Mapa montosTPI100 para ver si corresponde generar LC 0006
			mapDocLiq.put("MontosLC0006", montosLC0006);
			//Fin RIN 08
		}
		//msancheza: RIN P29-Precedente de Mercanc�a Vigente 
		Elementos<DatoSerie> series = declaracion.getDua().getListSeries();		
		boolean esTPN21 = false;		
		for (DatoSerie serie : series) {			
			String serieTPN21 = serie.getCodtratprefe().toString();				
			if(serieTPN21.equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_NACIONAL_TPN21)){
				esTPN21 = true;//basta q una serie sera TPN21 									
			}			
		}
		mapDocLiq.put("esTPN21", esTPN21);

		//INICIO P46 - Donacion
		String codTipoTratamiento = declaracion.getDua().getCodtipotratamiento();
		if (SunatStringUtils.isEqualTo(codTipoTratamiento, ConstantesDataCatalogo.TIPO_TRATAMIENTO_DONACION)){
			List<DatoIndicadores> lstIndicadorImpTotal = getListIndicadorByTipo(dua, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL);
			if (!CollectionUtils.isEmpty(lstIndicadorImpTotal)){
				mapDocLiq.put("tipoIndicador", ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_TOTAL);
			}

			List<DatoIndicadores> lstIndicadorImpParcial = getListIndicadorByTipo(dua, ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL);
			if (!CollectionUtils.isEmpty(lstIndicadorImpParcial)){
				mapDocLiq.put("tipoDeIndicadorParcial", ConstantesDataCatalogo.TIPO_IND_IMPUGNACION_PARCIAL);
			}
		}
		//FIN P46 - Donacion
		return liquidaDeclaracionService.grabaLiquidacion(mapDocLiq);
	}

	public void grabaTrama (Map<String, Object> variablesIngreso) {
		LiquidaDeclaracionService liquidaDeclaracionService = fabricaDeServicios.getService("liquidaDeclaracionService");
		liquidaDeclaracionService.grabaTrama(variablesIngreso);
	}

	//	@SuppressWarnings("unchecked")
	//	public void blanqueaDUAEnPreliq(Declaracion declaracion, String codTransaccion, String numOrden, String numeroDocumentoIdentidadSender) {
	//		
	//		String lcTipoTrans = TRANSACCION_NUMERACION;
	//		String lccodTipLiqui = TIPO_LIQUI_NUMERACION;
	//		String lccodTipdiligencia = " ";
	//		if (codTransaccion!=null) {
	//			lcTipoTrans = codTransaccion.substring(2, 4);
	//		}
	//		if (lcTipoTrans.equals(TRANSACCION_NUMERACION)) {
	//			String lcAnn_orden = "0000";
	//			String lcNume_orden = "000000";
	//			if (numOrden!=null) {
	//				lcAnn_orden = numOrden.substring(0, 4);
	//				lcNume_orden = numOrden.substring(4, 10);
	//			} 
	//			
	//			HashMap mapDocLiq = new HashMap();
	//			mapDocLiq.put("codAduDocliq", declaracion.getCodaduana());
	//			mapDocLiq.put("annDocliq", " ");
	//			mapDocLiq.put("numDocliq", " ");
	//			mapDocLiq.put("annOrden", lcAnn_orden);
	//			mapDocLiq.put("numOrden", lcNume_orden);
	//			mapDocLiq.put("codAgente", numeroDocumentoIdentidadSender);
	//			mapDocLiq.put("codRegDocliq", declaracion.getDua().getCodregimen());
	//			mapDocLiq.put("codTipLiqui", lccodTipLiqui);
	//			mapDocLiq.put("codTipdiligencia", lccodTipdiligencia);
	//			this.liquidaDeclaracionService.blanqueaDUAEnPreliq(mapDocLiq);
	//		}
	//	}
	/*
	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public LiquidaDeclaracionService getLiquidaDeclaracionService() {
		return liquidaDeclaracionService;
	}

	public void setLiquidaDeclaracionService(
			LiquidaDeclaracionService liquidaDeclaracionService) {
		this.liquidaDeclaracionService = liquidaDeclaracionService;
	}

	public MovCabliqdiligDAO getMovCabliqdiligDAO() {
		return movCabliqdiligDAO;
	}

	public void setMovCabliqdiligDAO(MovCabliqdiligDAO movCabliqdiligDAO) {
		this.movCabliqdiligDAO = movCabliqdiligDAO;
	}

	public DeudaDocumDAO getDeudaDocumDAO() {
		return deudaDocumDAO;
	}

	public void setDeudaDocumDAO(DeudaDocumDAO deudaDocumDAO) {
		this.deudaDocumDAO = deudaDocumDAO;
	}

	public CabDocliqDAO getCabDocliqDAO() {
		return cabDocliqDAO;
	}

	public void setCabDocliqDAO(CabDocliqDAO cabDocliqDAO) {
		this.cabDocliqDAO = cabDocliqDAO;
	}

*/


}