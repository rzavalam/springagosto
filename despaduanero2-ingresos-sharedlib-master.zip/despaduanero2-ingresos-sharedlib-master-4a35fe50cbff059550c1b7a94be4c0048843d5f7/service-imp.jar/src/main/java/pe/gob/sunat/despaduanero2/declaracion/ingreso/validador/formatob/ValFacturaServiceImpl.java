package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFacturaref;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

public class ValFacturaServiceImpl extends ValidacionFormatoB implements ValFactura {

	//private CatalogoHelperImpl catalogoHelper = FormatoBServiceImpl.getInstance().getValidadorCatalogo();
	//private ProveedorFuncionesService funcionesService = FormatoBServiceImpl.getInstance().getFuncionesService();

	/**
	 * Validar que la secuencia de facturas no se repita y sea 
	 * mayor a cero, es unica a nivel de todo el formato B
	 * @param declaracion
	 * @return
	 */
    public Map<String, String> numsecfactu(Declaracion declaracion){
        Map<String, String> result = new HashMap<String, String>();

        if (declaracion.isExoneradoFB()) {
            return result;
        }

        int secuencia = 1;
		//amancilla inicio PAS20165E220200137
		if(CollectionUtils.isNotEmpty(declaracion.getListDAVs())){

        for (DAV dav : declaracion.getListDAVs()) {
            for (DatoFactura factura : dav.getListFacturas()) {
                if (factura.getNumsecfactu() == null || factura.getNumsecfactu() != secuencia) {
                	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
                    /*result = catalogoHelper.getErrorMap("05505",
                            new Object[] { 
                            ((DAV) factura.getPadre()).getNumsecuprov(), 
                            factura.getNumsecfactu()!=null?factura.getNumsecfactu():" " });*/
                	
                	//glazaror... usamos catalogoAyudaService.getError
                	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
                	String numeroSecuenciaProveedor =  ((DAV) factura.getPadre()).getNumsecuprov().toString();
                	String numeroSecuenciaFactura = (factura.getNumsecfactu() != null) ? factura.getNumsecfactu().toString() : " ";
                	result = catalogoAyudaService.getError("05505", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura});

                }
                secuencia++;
            }
        }
		}

        return result;
    }

	
	public Map<String, String> numsecfactu(DAV dav, Declaracion declaracion) {		
		java.util.Map<String, String> result = new HashMap<String, String>();

		if( ! declaracion.isExoneradoFB() )
		{
			List<Integer> listSecuencias = new ArrayList<Integer>();
			
			for (DatoFactura factura : dav.getListFacturas()) {
				
				if( !  SunatNumberUtils.isGreaterThanZero(factura.getNumsecfactu()) || 
						! listSecuencias.contains(factura.getNumsecfactu()))
				{
					listSecuencias.add(factura.getNumsecfactu());	
				}else{
					result = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("05505");
				}
			}
		}
		
		return result;
	}
	
	/**
	 * Validar obligatoriamente que se haya transmitido el n�mero de factura.
	 * Validar obligatoriamente que el n�mero de factura declarada en el punto 1.1 
	 * se haya declarado como parte de las series del formato A.
	 * @param  datoFactura
	 * @return map
	 * @pase 
	 */
	public List<Map<String, String>> numfactura(DatoFactura datoFactura) {
		
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		
		if(((Declaracion)datoFactura.getPadre().getPadre()).isExoneradoFB()){
		    return result;
		}
		
		//glazaror... usamos catalogoAyudaService para obtener descripciones de los errores
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String numeroSecuenciaProveedor = ((DAV) datoFactura.getPadre()).getNumsecuprov().toString();
		String numeroSecuenciaFactura = (datoFactura.getNumsecfactu() != null) ? datoFactura.getNumsecfactu().toString() : " ";
		String numeroFactura = (datoFactura.getNumfactura() != null) ? datoFactura.getNumfactura().toString() : " ";
		
		if( SunatStringUtils.isEmpty(datoFactura.getNumfactura())){
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
			/*result.add(catalogoHelper.getErrorMap("30137", new Object[] 
			 	     {((DAV)datoFactura.getPadre()).getNumsecuprov(), 
					    datoFactura.getNumsecfactu(),
					    datoFactura.getNumfactura()!=null?datoFactura.getNumfactura():" "}));*/
			
			//glazaror... usamos catalogoAyudaService.getError
			result.add(catalogoAyudaService.getError("30137", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, numeroFactura}));

		}
		
		List<DatoFacturaref> listadoFacturaRef = ((Declaracion)datoFactura.getPadre().getPadre()).getDua().getListFacturaRef();
		
		boolean existeFacturaEnFA = false;
		
		for (DatoFacturaref facturaRef : listadoFacturaRef){			
			if (SunatStringUtils.isEqualTo(datoFactura.getNumfactura(), facturaRef.getNumfactura())){
			    existeFacturaEnFA = true;			    
			    break;
			}			
		}
		
		if(!existeFacturaEnFA){
			//glazaror... evitamos el uso de catalogoHelper.getErrorMap
		    /*result.add(catalogoHelper.getErrorMap("30622", new Object[] {
		            ((DAV)datoFactura.getPadre()).getNumsecuprov(),
		            datoFactura.getNumsecfactu(),
		            datoFactura.getNumfactura()!=null?datoFactura.getNumfactura():" "}));*/
			
			//glazaror... usamos catalogoAyudaService.getError
			result.add(catalogoAyudaService.getError("30622", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, numeroFactura}));
		}
		
		return result;
	}

public Map<String, String> existeFacturaFAenFB(DatoFacturaref facturaRef){
        Map<String, String> result = new HashMap<String, String>();

        Declaracion declaracion = (Declaracion) facturaRef.getPadre().getPadre();

        if (declaracion.isExoneradoFB()) {
            return result;
        }

        boolean existeFacturaEnFB = false;

        for (DAV dav : declaracion.getListDAVs()) {
            for (DatoFactura factura : dav.getListFacturas()) {
                if (factura.getNumfactura().equals(facturaRef.getNumfactura())) {
                    existeFacturaEnFB = true;
                    break;
                }
            }
        }

        if (!existeFacturaEnFB) {
        	//glazaror... evitar el uso de catalogoHelper.getErrorMap
            /*return catalogoHelper.getErrorMap("30665", 
                    new Object[] {             	
            		facturaRef.getNumsecfactu(),
                    facturaRef.getNumfactura()!=null?facturaRef.getNumfactura():" "});*/
        	//glazaror... usar catalogoAyudaService.getError
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	String numeroSecuenciaFactura = (facturaRef.getNumsecfactu() != null) ? facturaRef.getNumsecfactu().toString() : " ";
			String numeroFactura = (facturaRef.getNumfactura() != null) ? facturaRef.getNumfactura().toString() : " ";
			result = catalogoAyudaService.getError("30665", new String[] { numeroSecuenciaFactura, numeroFactura});
        }

        return result;
    }

	/**
	 * Valida si es Factura, declaracion jurada o contrato
	 * @param factura
	 * @return
	 */
    public Map<String, String> indtipodecl(DatoFactura factura){
        Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
        boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("323",factura.getIndtipodecl()));
        //if (!catalogoHelper.isValid(factura.getIndtipodecl(), "323")){
        if (!validaCatalogo){
            result = getErrorMap("30138",
                    new Object[] { 
                    ((DAV) factura.getPadre()).getNumsecuprov(), 
                    factura.getNumsecfactu(),
                    factura.getIndtipodecl()!=null?factura.getIndtipodecl():" "});
        }
        return result;
    }

	/**
     * Valida que sea un dato num�rico mayor a cero 
     * @param factura
     * @return
     */
    public Map<String, String> cnttotitems(DatoFactura factura){
        Map<String, String> result = new HashMap<String, String>();
        
        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }        
        
        if (SunatNumberUtils.isLessOrEqualsThanZero(factura.getCnttotitems())) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            //result = catalogoHelper.getErrorMap("30139");
        	//glazaror... hacemos uso de catalogoAyudaService.getError
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
			result = catalogoAyudaService.getError("30139");

        }

        return result;
    }

	/**
     * Codigo del incoterm de la determinaci�n del valor 
     * @param factura
     * @return
     */
	public Map<String, String> codincoterm(DatoFactura factura) {
		Map<String, String> result = new HashMap<String, String>();
		
		if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("82",factura.getCodincoterm()));
		//if (!catalogoHelper.isValid(factura.getCodincoterm(), "82")){
		if (!validaCatalogo){
			result = getErrorMap("30140", 
			        new Object[]{			        
					((DAV)factura.getPadre()).getNumsecuprov(), 
					factura.getNumsecfactu(), 
					factura.getCodincoterm()!=null?factura.getCodincoterm():" "});
		}		
		return result;
	}

	/**
	 * Validar que se haya transmitido el nombre del lugar de entrega.
	 * caracteres
	 * @param factura
	 * @return
	 * @pase 
	 */
    public Map<String, String> deslugtrans(DatoFactura factura){
    	Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }

        boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("NN1",SunatStringUtils.substring(factura.getDeslugtrans(),factura.getDeslugtrans().indexOf("-") + 1) ));
        if (SunatStringUtils.indexOf(factura.getDeslugtrans(), "-") ==-1 ||!validaCatalogo)
        		//!catalogoHelper.isValid(SunatStringUtils.substring(factura.getDeslugtrans(),factura.getDeslugtrans().indexOf("-") + 1), "NN1"))
           	{
        	    return getErrorMap("30627", 
                       new Object[] { 
        	           ((DAV) factura.getPadre()).getNumsecuprov(),
        	           factura.getNumsecfactu(), 
        	           factura.getDeslugtrans() });
        	            
        	}
        
        if (!SunatStringUtils.isLengthGreaterThanNumber(SunatStringUtils.substring(factura.getDeslugtrans(),0, factura.getDeslugtrans().indexOf("-")),2))
           {
        				return	getErrorMap("30141", 
        						new Object[] { 
        						((DAV) factura.getPadre()).getNumsecuprov(),
        						factura.getNumsecfactu(), 
        						 factura.getDeslugtrans() });
           }      	        		
                    
        return result;

    }

	/**
     * Valida el Codigo de pais del embarque 
     * @param factura
     * @return
     */
    public Map<String, String> codpaisembar(DatoFactura factura){
        Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
        boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J2",factura.getCodpaisembar()));
        //if (!catalogoHelper.isValid(factura.getCodpaisembar(), "J2")){
        if (!validaCatalogo){
            result = getErrorMap("30143",
                    new Object[] { 
                    ((DAV) factura.getPadre()).getNumsecuprov(), 
                    factura.getNumsecfactu(),
                    factura.getCodpaisembar()!=null?factura.getCodpaisembar():" "});
        }
        return result;
    }

	/**
     * Valida el C�digo de Moneda de Transacci�n
     * @param factura
     * @return
     */
	public Map<String, String> codmoneda(DatoFactura factura) {
		Map<String, String> result = new HashMap<String, String>();
		
        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
        boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("J1",factura.getCodmoneda()));
		//if (!catalogoHelper.isValid(factura.getCodmoneda(), "J1")){
        if (!validaCatalogo){
			result = getErrorMap("30144", new Object[]{ 
					((DAV)factura.getPadre()).getNumsecuprov(),
					factura.getNumsecfactu(),
					factura.getCodmoneda()!=null?factura.getCodmoneda():" "});
		}
		return result;
	}

	
	/**
	 * Verificar que el total de items enviadas por factura
	 * (DatosFactura.cnttotitems) sea igual a la cantidad de items enviadas en
	 * el segmento DatosItem
	 * 
	 * @return
	 */
	@Deprecated
	public Map<String, String> valgralfactfb1(DatoFactura factura){
        Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
		
        if (!SunatNumberUtils.isEqual(factura.getCnttotitems(), factura.getListItems().size())){
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
        	/*result = catalogoHelper.getErrorMap("05635", new Object[]{ 
					((DAV)factura.getPadre()).getNumsecuprov(),
					factura.getCnttotitems(),
					factura.getNumfactura()!=null?factura.getNumfactura():" "});*/
        	
        	//glazaror... usamos catalogAyudaService.getError
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	String numeroSecuenciaProveedor = ((DAV) factura.getPadre()).getNumsecuprov().toString();
        	String cantidadItems = (factura.getCnttotitems() != null) ? factura.getCnttotitems().toString() : " ";
        	String numeroFactura = (factura.getNumfactura() != null) ? factura.getNumfactura().toString() : " ";
        	result = catalogoAyudaService.getError("05635", new String[] {numeroSecuenciaProveedor, cantidadItems, numeroFactura});
		}
        
		return result;
	}

	/**
	 * "Verificar que el valor absoluto de la diferencia entre el total fob
	 * enviadas por factura (DatosFactura.mtofactufob) y la sumatoria del valor
	 * fob por item (DatosItem.mtofobitem) sea menor o igual a 1
	 * 
	 * @param factura
	 * @return
	 */
    public Map<String, String> validarDiferenciaFobFacturaItems(DatoFactura factura){
	
        Map<String, String> result = new HashMap<String, String>();
	
        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
	
        BigDecimal montoTotalFobItems = new BigDecimal(0);

        for (DatoItem item : factura.getListItems()){
            montoTotalFobItems = SunatNumberUtils.sum(montoTotalFobItems, item.getMtofobitem());
        }

        BigDecimal absoluteDiference = SunatNumberUtils.absoluteDiference(montoTotalFobItems, factura.getMtofactufob());

        if (SunatNumberUtils.isGreaterThanParam(absoluteDiference, new BigDecimal(1))) {
        	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
            /*result = catalogoHelper.getErrorMap("05636", 
                    new Object[] { 
                    ((DAV) factura.getPadre()).getNumsecuprov(),
                    factura.getNumsecfactu(), 
                    absoluteDiference.toString() });*/
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        	String numeroSecuenciaProveedor = ((DAV) factura.getPadre()).getNumsecuprov().toString();
        	String numeroSecuenciaFactura = (factura.getNumsecfactu() != null) ? factura.getNumsecfactu().toString() : " ";
        	String absoluteDiferenceAsString = absoluteDiference.toString();
    	
        	//glazaror... usamos catalogoAyudaService.getError
        	result = catalogoAyudaService.getError("05636", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, absoluteDiferenceAsString});
        }

        return result;
    }
	
	//lmvr - RN 170
	public List<Map<String, String>> valPaisAdquiFactura (DAV dav, Declaracion declaracion) {
		List<Map<String, String>> listErr = new ArrayList<Map<String, String>>();
		//RIN13 se regresa a su c�digo anterior
		for (DatoFactura factura : dav.getListFacturas()) {
			/*String codPaisAdqui = " ";
			codPaisAdqui=factura.getListItems().get(0).getCodpaisadqui();*/
			for (DatoItem item : factura.getListItems()) {
			/*BUG 18389 INICIO pase 105 arey*/
			/*if(codPaisAdqui!=" "){
			if(!item.getCodpaisadqui().equals(codPaisAdqui)){
				DatoSerie serie = valItemFB.getSerieCorrespondiente(item, declaracion);
				if (serie != null) {
					listErr.add(catalogoHelper.getErrorMap("30577", new Object[] { serie.getNumserie(), serie.getCodpaisadqui(),item.getCodpaisadqui(), item.getNumsecitem() }));
				}	
			}
			if(listErr!=null && listErr.size()>0){//si hay al menos uno mostrar todo.
				DatoSerie serieIni = valItemFB.getSerieCorrespondiente(factura.getListItems().get(0), declaracion);
				listErr.add(catalogoHelper.getErrorMap("30577", new Object[] { serieIni.getNumserie(), serieIni.getCodpaisadqui(),factura.getListItems().get(0).getCodpaisadqui(),
						factura.getListItems().get(0).getNumsecitem() }));
			}
			}*/
			/*BUG 18389 FIN pase 105 arey*/ 
				ValItemFB valItemFB =   fabricaDeServicios.getService("ValItemFB");
				DatoSerie serie = valItemFB.getSerieCorrespondiente(item, declaracion);
				if (serie != null) {
					if (!SunatStringUtils.isEqualTo(serie.getCodpaisadqui(), item.getCodpaisadqui())) {
						//glazaror... evitamos el uso de catalogoHelper.getErrorMap
						//listErr.add(catalogoHelper.getErrorMap("30577", new Object[] { serie.getNumserie(), serie.getCodpaisadqui(),item.getCodpaisadqui(), item.getNumsecitem() }));
						// SERIE[{0}]: DECLARADOS CON IGUAL N�MERO DE FACTURA Y PROVEEDOR NO PUEDEN TENER PA�S DE ADQUISICI�N DISTINTO. PAIS SERIE [{1}] PA�S ITEM [{2}]
						
						//glazaror... hacemos uso de catalogoAyudaService.getError
						CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
						String numeroSerie = (serie.getNumserie() != null) ? serie.getNumserie().toString() : " ";
						String codigoPaisAdquisicion = (serie.getCodpaisadqui() != null) ? serie.getCodpaisadqui().toString() : " ";
						String codigoPaisAdquisicionItem = (item.getCodpaisadqui() != null) ? item.getCodpaisadqui().toString() : " ";
						String numeroSecuenciaItem = (item.getNumsecitem() != null) ? item.getNumsecitem().toString() : " ";
						listErr.add(catalogoAyudaService.getError("30577", new String[] {numeroSerie, codigoPaisAdquisicion, codigoPaisAdquisicionItem, numeroSecuenciaItem}));

					}
				}				
			}
		}
		
		return listErr;
	}
	
	/**
	 * Valida que envie la fecha de factura del formato B
	 * Adicionalmente �sta no debe ser inferior a la fecha actual
	 * Aplica a transacciones 1001, 1002, 1003, 1005
	 * 2001, 2002, 2003, 2005, 2101, 2102, 2103, 2105
	 * @param arg
	 * @return
	 * @author rbegazo
	 * @pase 2011459 
	 */
    //GGRANADOS FORMB
    //se retira de la TX XX01
	public Map<String, String> fecfactura (Date fecfactura) {
		java.util.Map<String, String> result = new HashMap<String, String>();
		Date fechaActual=new Date(Calendar.getInstance().getTimeInMillis());

		if( fecfactura != null )
		{
			if (fecfactura.getTime() > fechaActual.getTime())
			{
				result = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("05559");
			}
		}
		else
			result = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("00148");					
		return result;
	}
	
	/**
	 * Valida que el n�mero de factura sea �nico por proveedor
	 * Aplica a transacciones: XX01,XX02,XX03,XX05
	 * @param dav
	 * @return
	 * @pase 
	 */	
    public Map<String, String> validarNumeroFacturaNoSeRepite(DAV dav){
        Map<String, String> result = new HashMap<String, String>();

        if (((Declaracion) dav.getPadre()).isExoneradoFB()) {
            return result;
        }
        
        List<DatoFactura> listadoFacturas = dav.getListFacturas();

        for (int i = 0; i < listadoFacturas.size(); i++) {
            for (int j = i + 1; j < listadoFacturas.size(); j++) {
                if (listadoFacturas.get(i).getNumfactura().equals(listadoFacturas.get(j).getNumfactura())) {
                	//glazaror... evitamos el uso de catalogoHelper.getErrorMap
                    /*return catalogoHelper.getErrorMap("30623", 
                            new Object[] { 
                            dav.getNumsecuprov(),
                            listadoFacturas.get(i).getNumsecfactu(), 
                            listadoFacturas.get(i).getNumfactura() });*/
                	
                	//glazaror... hacemos uso de catalogoAyudaService.getError
                	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
                	DatoFactura factura = listadoFacturas.get(i);
                	String numeroSecuenciaProveedor = dav.getNumsecuprov().toString();
                	String numeroSecuenciaFactura = factura.getNumsecfactu().toString();
                	String numeroFactura = factura.getNumfactura();
                	return catalogoAyudaService.getError("30623", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, numeroFactura});
                }
            }
        }
        return result;
    }
	
	/**
	 * Validar obligatoriamente que se haya transmitido la fecha de la factura.
	 * @param factura
	 * @param fechaReferencia
	 * @return
	 */
	public List<Map<String, String>> validarFechaFactura(DatoFactura factura, Date fechaReferencia) {
	
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		
        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
        
        //glazaror... hacer uso de catalogoAyudaService para obtener descripciones de error
        CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        String numeroSecuenciaProveedor = ((DAV) factura.getPadre()).getNumsecuprov().toString();
        String numeroSecuenciaFactura = (factura.getNumsecfactu() != null) ? factura.getNumsecfactu().toString() : " ";
        String numeroFactura = (factura.getNumfactura() != null) ? factura.getNumfactura().toString() : " ";
		
		if(factura.getFecfactura() == null){
			//glazaror... evitamos uso de catalogoHelper.getErrorMap
			/*result.add(catalogoHelper.getErrorMap("30642", new Object[] {
					((DAV)factura.getPadre()).getNumsecuprov(),
					factura.getNumsecfactu(),
					factura.getNumfactura()}));*/
			
			//glazaror... hacemos uso de catalogoAyudaService.getError
			result.add(catalogoAyudaService.getError("30642", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, numeroFactura}));
		}		
		
        //amancillla INC 2015-024044 if (factura.getIndtipodecl().equals("1")) { siempre la parte CTATE al lado izquierdo
		if ("1".equals(factura.getIndtipodecl())) {
        	if (SunatDateUtils.esFecha1MayorQueFecha2(factura.getFecfactura(), fechaReferencia, SunatDateUtils.COMPARA_SOLO_FECHA)) {
        		//glazaror... evitamos uso de catalogoHelper.getErrorMap
                /*result.add(catalogoHelper.getErrorMap("30625",
                        new Object[] { 
                        ((DAV) factura.getPadre()).getNumsecuprov(),
                        factura.getNumsecfactu(), 
                        SunatDateUtils.getFormatDate(factura.getFecfactura(),"dd/MM/yyyy") }));*/
        		//glazaror... hacemos uso de catalogoAyudaService.getError
        		String fechaFactura = SunatDateUtils.getFormatDate(factura.getFecfactura(),"dd/MM/yyyy");
        		result.add(catalogoAyudaService.getError("30625", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, fechaFactura}));
            }
        }
		
		List<DatoFacturaref> listadoFacturaRef = ((Declaracion) factura.getPadre().getPadre()).getDua().getListFacturaRef(); 
		
		for (DatoFacturaref facturaRef : listadoFacturaRef){			
			if (SunatStringUtils.isEqualTo(factura.getNumfactura(), facturaRef.getNumfactura())){
			    if(factura.getFecfactura().getTime() != facturaRef.getFecfactura().getTime()){
			    	//glazaror... evitamos uso de catalogoHelper.getErrorMap
			    	/*result.add(catalogoHelper.getErrorMap("30624",  new Object[] {
	                        ((DAV)factura.getPadre()).getNumsecuprov(),
	                        factura.getNumsecfactu(),   
	                        SunatDateUtils.getFormatDate(factura.getFecfactura(), "dd/MM/yyyy"),
	                        SunatDateUtils.getFormatDate(facturaRef.getFecfactura(), "dd/MM/yyyy"),         
	                        facturaRef.getNumfactura()}));*/
			    	//glazaror... hacemos uso de catalogoAyudaService.getError
			    	String fechaFactura = SunatDateUtils.getFormatDate(factura.getFecfactura(),"dd/MM/yyyy");
			    	String fechaFacturaReferencia = SunatDateUtils.getFormatDate(facturaRef.getFecfactura(),"dd/MM/yyyy");
			    	result.add(catalogoAyudaService.getError("30624", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, fechaFactura, fechaFacturaReferencia, numeroFactura}));
			    }
			    break;
			}			
		}		
		return result;
	}	
	
	
	/**
	 * Validar obligatoriamente que se haya transmitido la fecha de la factura
	 * considerando el Art�culo 145�.- Mercanc�a declarada y encontrada de la GJA-03 LEY GENERAL DE ADUANAS:
	 * Conforme a lo establecido en el segundo p�rrafo del art�culo 145� de la Ley, el due�o o consignatario 
	 * podr� solicitar la rectificaci�n de la declaraci�n aduanera dentro de los tres (03) meses transcurridos 
	 * desde la fecha del otorgamiento del levante en caso encontrara mercanc�a en mayor cantidad o distinta a 
	 * la consignada en la declaraci�n de mercanc�as. La Autoridad Aduanera aceptar� la rectificaci�n de la declaraci�n 
	 * previa presentaci�n de la documentaci�n sustentatoria y del pago de la deuda tributaria aduanera y 
	 * recargos que correspondan. (SAU20153D213000404)
	 * 
	 * Ajustes a la R169 del rin05 � complemento de la numeraci�n: R169 la fecha de factura debe ser menor o igual a la fecha de numeraci�n de la dua, 
	 * solo para las DAMS que no cuenten con canal de control (SAU201510002000195) Pase 56 -arey
	 * @param factura
	 * @param fechaReferencia
	 * @param variablesIngreso
	 * @param declaracionBD
	 * @return
	 */
	public List<Map<String, String>> validarFechaFacturaRecti(DatoFactura factura, Date fechaReferencia, Map<String,Object> variablesIngreso, Declaracion declaracionBD) {
	
		List<Map<String, String>> result = new ArrayList<Map<String,String>>();
		
        if (((Declaracion) factura.getPadre().getPadre()).isExoneradoFB()) {
            return result;
        }
               
        CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
        String numeroSecuenciaProveedor = ((DAV) factura.getPadre()).getNumsecuprov().toString();
        String numeroSecuenciaFactura = (factura.getNumsecfactu() != null) ? factura.getNumsecfactu().toString() : " ";
        String numeroFactura = (factura.getNumfactura() != null) ? factura.getNumfactura().toString() : " ";
		
		if(factura.getFecfactura() == null){
			result.add(catalogoAyudaService.getError("30642", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, numeroFactura}));
		}		
		String codTransaccion = (String)variablesIngreso.get("codTransaccion");
		
		Date fechaAutLevante = declaracionBD.getDua().getFecAutlevante();
		Date fechaPlazoLimite = SunatDateUtils.addMonth(fechaAutLevante, 3);
		
        if (factura.getIndtipodecl().equals("1")) {
        	if(codTransaccion.endsWith("03") && SunatDateUtils.esFecha1MayorQueFecha2(new Date(), fechaPlazoLimite, SunatDateUtils.COMPARA_SOLO_FECHA) && 
        			SunatDateUtils.esFecha1MayorQueFecha2(factura.getFecfactura(), fechaReferencia, SunatDateUtils.COMPARA_SOLO_FECHA)){
        		String fechaFactura = SunatDateUtils.getFormatDate(factura.getFecfactura(),"dd/MM/yyyy");
        		result.add(catalogoAyudaService.getError("35616", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, fechaFactura}));
        	}
        	if(declaracionBD.getDua().getCodCanal()==null || SunatStringUtils.isEmpty(declaracionBD.getDua().getCodCanal().trim())){//adicionado por SAU201510002000195
	        	if (SunatDateUtils.esFecha1MayorQueFecha2(factura.getFecfactura(), fechaReferencia, SunatDateUtils.COMPARA_SOLO_FECHA)) {
	        		String fechaFactura = SunatDateUtils.getFormatDate(factura.getFecfactura(),"dd/MM/yyyy");
	        		result.add(catalogoAyudaService.getError("30625", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, fechaFactura}));
	            }
        	}
        }
        
		
		List<DatoFacturaref> listadoFacturaRef = ((Declaracion) factura.getPadre().getPadre()).getDua().getListFacturaRef(); 
		
		for (DatoFacturaref facturaRef : listadoFacturaRef){			
			if (SunatStringUtils.isEqualTo(factura.getNumfactura(), facturaRef.getNumfactura())){
			    if(factura.getFecfactura().getTime() != facturaRef.getFecfactura().getTime()){
			    	String fechaFactura = SunatDateUtils.getFormatDate(factura.getFecfactura(),"dd/MM/yyyy");
			    	String fechaFacturaReferencia = SunatDateUtils.getFormatDate(facturaRef.getFecfactura(),"dd/MM/yyyy");
			    	result.add(catalogoAyudaService.getError("30624", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, fechaFactura, fechaFacturaReferencia, numeroFactura}));
			    }
			    break;
			}			
		}		
		return result;
	}	
	
	
	
	/**
	 * Validar el monto FOB de la factura debe ser mayor un n�mero mayor a 0.
	 * @param  factura
	 * @return map
	 * @pase 
	 */
    public Map<String, String> mtofactufob(DatoFactura factura){

        Map<String, String> result = new HashMap<String, String>();

        Declaracion declaracion = ((Declaracion) factura.getPadre().getPadre());

        if (declaracion.isExoneradoFB()) {
            return result;
        }

        if (factura.getMtofactufob() == null || !SunatNumberUtils.isGreaterThanZero(factura.getMtofactufob())) {
        	//glazaror... evitar el uso de catalogoHelper.getErrorMap
            /*return catalogoHelper.getErrorMap("30142", 
                    new Object[] { 
                    ((DAV) factura.getPadre()).getNumsecuprov(),
                    factura.getNumsecfactu()!=null?factura.getNumsecfactu():" ", 
                    factura.getMtofactufob()!=null?factura.getMtofactufob():" "});*/
        	
        	CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService) fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
            String numeroSecuenciaProveedor = ((DAV) factura.getPadre()).getNumsecuprov().toString();
        	String numeroSecuenciaFactura = (factura.getNumsecfactu() != null) ? factura.getNumsecfactu().toString() : " ";
        	String montoFacturaFob = (factura.getMtofactufob() != null) ? factura.getMtofactufob().toString() : " ";
        	
			return catalogoAyudaService.getError("30142", new String[] {numeroSecuenciaProveedor, numeroSecuenciaFactura, montoFacturaFob});

        }

        return result;
    }	
	
}
