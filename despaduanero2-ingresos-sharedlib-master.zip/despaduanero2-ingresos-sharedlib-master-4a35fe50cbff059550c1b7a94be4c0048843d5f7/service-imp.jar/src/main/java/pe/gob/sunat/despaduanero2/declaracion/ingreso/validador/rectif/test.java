package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 Validador obj = new Validador();
		 try {
			Method method = obj.getClass().getMethod("validarTPI");
			method.invoke(obj);			
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}

}

class Validador{
	public void validarTPI(){
		System.out.println("validarTPI Uinque");
	}
	
	public void validarTPI(String a){
		System.out.println("validarTPI a:" + a);
	}
	
	public void validarTPI(String a, int b){
		System.out.println("validarTPI a:" + a + " b:" + b);
	}
}


