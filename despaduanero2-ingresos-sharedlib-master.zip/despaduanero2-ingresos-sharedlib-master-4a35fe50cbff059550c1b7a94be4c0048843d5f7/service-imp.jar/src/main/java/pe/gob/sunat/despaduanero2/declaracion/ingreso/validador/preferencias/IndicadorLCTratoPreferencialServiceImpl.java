package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

public class IndicadorLCTratoPreferencialServiceImpl extends ValDuaAbstract	implements IndicadorLCTratoPreferencialService {
	
	//private FabricaDeServicios	fabricaDeServicios;
	
	public static final String TIPO_MARGEN_NUEVE= "9";

	@Override
	@ServicioAnnot(tipo="V",codServicio=3419, descServicio="Dua con indicador 15, requiere el env�o de al menos una serie con TPI correspondiente y tipo de margen 9")
	@ServInstDetAnnot(tipoRpta={0,1},nomAtr={"dua","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3419,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> valIndicadorLCTipoMargen(DUA dua, Date fechaReferencia) {
		// TODO Auto-generated method stub
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		Map<String, String> listError=new HashMap<String, String>();
		boolean validar = false;
		int contador = 0;
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		List<String> serviciosTLC = new ArrayList<String>();
		
		if(indicador15!= null){
			for(DatoSerie serie: dua.getListSeries()){
				if(tpiService.validarServicioTLC(this, serie, fechaReferencia, serviciosTLC)){
					validar=true;
					String tipoMargen = serie.getCodtipomarge();
					if(tipoMargen != null && tipoMargen.equals(TIPO_MARGEN_NUEVE)){
						contador++;
					}
				}
			}
			//por lo menos una serie debe tener el tpi y el margen 9 sino se rechaza
			if(validar && contador==0){
				//Se ha consignado el indicador 15, se requiere el env�o del TPI correspondiente con el tipo de margen 9
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30904");
			}
		}
		
		return listError;
	}

	@Override
	@ServicioAnnot(tipo="V",codServicio=3429, descServicio="Para Dua con indicador 15, las series con TPI correspondiente y tipo de margen vacio o distinto de 9 no deben transmitir datos del CO")
	@ServInstDetAnnot(tipoRpta={0,1},nomAtr={"serie","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3429,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> valIndicadorLCTipoMargenSinDatosCO(DatoSerie serie, Date fechaReferencia , Map<String, Object> variablesIngreso) {

		// TODO Auto-generated method stub
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		Map<String, String> listError=new HashMap<String, String>();
		if(!tpiService.validarServicioTLC(this, serie, fechaReferencia, variablesIngreso)){//actualizado en pase 399

			return listError;
		}
		DUA dua = (DUA)serie.getPadre();
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		String tipoMargen = serie.getCodtipomarge();
		if(indicador15!= null && (tipoMargen==null || !tipoMargen.equals(TIPO_MARGEN_NUEVE))){
			List<DatoAutocertificacion> listCertificado =  this.getCertiOrigen(dua, serie);
			DatoAutocertificacion datoCertificado = !CollectionUtils.isEmpty(listCertificado)?listCertificado.get(0): null;
			if(datoCertificado!=null){
				if(datoCertificado.getCodtipoCO() != null || datoCertificado.getNumdocumento()!=null || datoCertificado.getFecemision()!=null 
						|| datoCertificado.getCodcriterioO()!=null || datoCertificado.getCodffco()!=null)
				//"Serie XXX, Para el indicador 15 si no cuenta con certificado de origen, no debe transmitir ninguno de los datos relacionados con �l (Tipo de certificado, n�mero, fecha, tipo de criterio y n�mero de registro de funcionario)".
				listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30905", new String[]{serie.getNumserie().toString()});
				
			}
			
			
		}
		
		
		return listError;
	}
	
	
	
	@Override
	@ServicioAnnot(tipo="V",codServicio=3461, descServicio="Para Dua con indicador 15, las series con TPI correspondiente y tipo de margen  9 en la serie")
	@ServInstDetAnnot(tipoRpta={0,1},nomAtr={"serie","fechaReferencia"})
	@OrquestaDespaAnnot(codServInstancia=3461,numSecEjec=99,nomClase="pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias")
	public Map<String, String> valIndicadorLCTipoMargenTPI(DatoSerie serie, Date fechaReferencia , Map<String, Object> variablesIngreso) {

		// TODO Auto-generated method stub
		TratoPreferencialInternacionalService tpiService = fabricaDeServicios.getService("tratoPreferencialInternacionalService");
		Map<String, String> listError=new HashMap<String, String>();
		if(!tpiService.validarServicioTLC(this, serie, fechaReferencia, variablesIngreso)){
			return listError;
		}
		DUA dua = (DUA)serie.getPadre();
		String  indicador15 = this.getIndicador(dua,ConstantesDataCatalogo.INDICADOR_LC_TRIBUTOS_LIBERADOS_POR_TPI);
		if(indicador15!= null){
					//valida que se envie el tpi
					if (serie.getCodconvinter() != null && serie.getCodconvinter() != 0) {					
						String tipoMargen = serie.getCodtipomarge();
						//valida que el tipo de margen sea 9
						if(tipoMargen != null && tipoMargen.equals(TIPO_MARGEN_NUEVE)){
							//Serie XX: Se ha consignado el indicador 15 y tipo de margen 9 por cada serie
							listError = ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30916", new String[]{serie.getNumserie().toString()});
						}
					}
		}
	
		return listError;
	}
	
//	private boolean existeDatosCO(DatoSerie serie){
//		boolean existeDatos = false;
//		
//		return existeDatos;
//	}

/*	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}
*/
}
