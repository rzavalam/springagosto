/*
 * Clase que define el servicio de validaciones complejas sobre los regimenes precedentes
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.ArrayList;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
//import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.util.CollectionUtils;
//import org.springframework.util.StringUtils;

//import pe.gob.sunat.despaduanero.despacho.entrada.di.model.dao.DipolizaiDAO;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.DirfCtaCte;//P28-PAS20155E410000032 - bug 23702

import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.Repocer;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.Reposce;
import pe.gob.sunat.despaduanero.despacho.entrada.rp.model.dao.DirfCtaCteDAO;//P28-PAS20155E410000032 - bug 23702
import pe.gob.sunat.despaduanero2.declaracion.model.dao.ConvenioSerieDAO;//P28
import pe.gob.sunat.despaduanero2.util.DateUtil;
//import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.PolizadDAO;
//import pe.gob.sunat.despaduanero.despacho.entrada.sd.model.dao.SeriesdDAO;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.ConstantesGrupoCatalogo;//PAS20181U220200049
import pe.gob.sunat.despaduanero2.declaracion.bean.SerieItemCrmfBean;//P28-PAS20155E410000032 - bug 23702
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.certireposicion.ValRegPrecedenciaReposicionService; //P28
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.mercanciavigente.ValMercanciaVigenteService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.ValItemFB;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.CatalogoHelperImpl;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.FormatoAServiceImpl;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.GetValidacionesService;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.PackageTD;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.ProveedorFuncionesService;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoIndicadores;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetCtacteRegimenDAO;//P28-PAS20155E410000032 - bug 23702
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.IndicadorDUADAO;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
//import pe.gob.sunat.despaduanero2.model.dao.CabSolrectiDAO;
import pe.gob.sunat.despaduanero2.util.ResponseMapManager;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;//P46-PAS20155E410000032-[jlunah]
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.sigad.ingreso.service.CertificadoReposicionService;
import pe.gob.sunat.sigad.ingreso.service.ConsultaDeclaracionImpoConsumoService;

//DZC TPN 21
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_NUMERACION_IMPORTACION_DEFINITIVA;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_URG_IMPORTACION_DEFINITIVA; //P28

import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.ControlVigenciaService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.GetDeclaracionService;
/**
 * The Class ValNegocDuaregapFormA. Clase que define el servicio de validaciones
 * complejas sobre los regimenes precedentes.
 */
public class ValNegocDuaregapFormAServiceImpl extends ValDuaAbstract implements ValNegocDuaregapFormA {

	
	/**
	 * Realiza las validaciones complejas sobre los regimenes precedentes de la
	 * DUA.<br>
	 * Implementacion basada en la Ingenieria Reversa del procedimiento
	 * almacenado SPTD_DUAREGAP
	 * Modificado por glazaror... mejoras 
	 * 
	 * @param declaracion
	 *            Declaracion
	 * @return Lista de errorres
	 */
	@Override
	public List<Map<String, String>> duaRegap(Declaracion declaracion,
			Date fechaReferencia, String codTransaccion) {
		return duaRegap(declaracion, fechaReferencia, codTransaccion, null);
	}
	
	/**
	 * Realiza las validaciones complejas sobre los regimenes precedentes de la
	 * DUA.<br>
	 * Implementacion basada en la Ingenieria Reversa del procedimiento
	 * almacenado SPTD_DUAREGAP
	 * Modificado por glazaror... se trabaja con variablesIngreso
	 * 
	 * @param declaracion
	 *            Declaracion
	 * @return Lista de errorres
	 */
	public List<Map<String, String>> duaRegap(Declaracion declaracion,
			Date fechaReferencia, String codTransaccion, Declaracion declaracionBD) {
		
		ControlVigenciaService controlVigenciaService = (ControlVigenciaService)fabricaDeServicios.getService("controlVigenciaIngresoSevice");
		Date fechaHoy = SunatDateUtils.getCurrentDate();
		boolean esVigenteRIN31 = controlVigenciaService!=null?controlVigenciaService.esVigenteRIN31(fechaHoy):false;


		Elementos<DatoSerie> series = declaracion.getDua().getListSeries();
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		//String codaduanaref = declaracion.getNumdeclRef() != null ? declaracion.getNumdeclRef().getCodaduana() : null;
		String maduana = declaracion.getCodaduana();
		String codCanal = obtenerCanal(declaracion);
		String codRegimen = declaracion.getDua().getCodregimen();
		boolean tieneRegPreDeposito = false;
		boolean tieneRegPreEspeciales = false;
		String codRegimenEspecial = new String();
		boolean tieneErrorRegimenEspecial = false; // csantillan PAS20191U220200002
		
        Map<String, BigDecimal> cantidadAcumuladaCertificado = new HashMap<String, BigDecimal>();
		//msancheza: RIN P29-Precedente de Mercanc�a Vigente
		boolean tieneRegPrecImpoConsumoTPN21 = false;
		Integer cantidadSerieTPN = 0;
		Integer cantidadSerieTotales = 0;
		//ini P28-PAS20155E410000032 - bug 23702
		/*inicio P28-PAS20155E410000032-[jlunah] BUG 3395 Jira*/
		Map<String, Object> mSaldDispAdiItemCrmf = new HashMap<String, Object>();
		List<Map<String, Object>> datosCrmfPorSerie = new ArrayList<Map<String,Object>>();
		obtenerSaldoDisponibleAdicionalXItemCrmf(declaracion, mSaldDispAdiItemCrmf,datosCrmfPorSerie);
		mSaldDispAdiItemCrmf.put("datosCrmfPorSerie", datosCrmfPorSerie);
		/*inicio P28-PAS20155E410000032-[jlunah] BUG 3395 Jira*/
		//fin P28-PAS20155E410000032 - bug 23702
		// RTINEO OPTIMIZACION cache temporal
		Map<String,Object> listDuaCache = new HashMap<String,Object>();
		Map<String,Object> listSeriesCache = new HashMap<String,Object>();
		// RTINEO OPTIMIZACION FIN
		ValRegPrecDepositoService valRegPrecDepositoService =  null;

		//csantillan PAS20191U220200002
		ValRegPrecEspecialesService  valRegPrecEspecialesSevice = fabricaDeServicios.getService("ingreso.ValRegPrecEspeciales");
		if(esVigenteRIN31){
				for(DatoSerie serie:series){
				if(!CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
		  			for(DatoRegPrecedencia regPrec:serie.getListRegPrecedencia()){
		  				if(valRegPrecEspecialesSevice.valRegimenPrecedenteEspecial(regPrec.getCodregipre())){
		  					tieneRegPreEspeciales =true;
		  					break;
		  				}
		  			}
				  }
				}
			}

		for (DatoSerie serie : series) {
			String numeroSerieDecl = serie.getNumserie().toString();
			cantidadSerieTotales++;
			String serieTPN21 = serie.getCodtratprefe().toString();	
			if(serieTPN21.equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_NACIONAL_TPN21)){
				tieneRegPrecImpoConsumoTPN21 = true;//basta q una serie sera TPN21 se activa el indicador para validar cabecera
				cantidadSerieTPN++;
			}
			
			//csantillan PAS20181U220200054 bug_P_SNAA0004-17101
			if(esVigenteRIN31){
			if(ArrayUtils.contains(new String[]{"1001","1003"},codTransaccion)){
				if ( SunatNumberUtils.isEqual(serie.getCodtratprefe(), 332)&&serie.getListRegPrecedencia().size()<1 ) {	
 					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("50223",new String[] {serie.getNumserie().toString()}));
 					return listError;
 				}else if ( SunatNumberUtils.isEqual(serie.getCodtratprefe(), 332)&&!serie.getListRegPrecedencia().get(0).getCodregipre().equals(Constants.REGIMEN_ZOFRATACNA_CZ) ) {
 					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("50223",new String[] {serie.getNumserie().toString()}));		
 					}      					 				     
				}
			}
			if (tieneRegPrecImpoConsumoTPN21 && !Constants.REGIMEN_IMPO_DEFINITIVA.equals(codRegimen)) {		
				//La declaraci�n con TPN 21 solo puede destinarse al r�gimen de importaci�n para el consumo
				listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31886",new String[] {codRegimen}));
				return listError;
			}
			for (DatoRegPrecedencia precedente : serie.getListRegPrecedencia()) {				
				String mregi_proce = precedente.getCodregipre();		

			//csantillan PAS20181U220200054 - validacion de codigo almacen zofratacna
			if(esVigenteRIN31){	
				if(!codTransaccion.equals("1007") && precedente.getCodAlmZofra()!=null) { // A revisar
					if(!precedente.getCodregipre().equals(Constants.REGIMEN_ZOFRATACNA_DZ)&&(!precedente.getCodAlmZofra().trim().isEmpty())){
					listError.add(getDUAError("50221", //00124
							new Object[] { serie.getNumserie().toString(),precedente.getCodregipre()}));
					}else if(precedente.getCodregipre().equals(Constants.REGIMEN_ZOFRATACNA_DZ)&&(precedente.getCodAlmZofra().trim().isEmpty())){
						listError.add(getDUAError("50222", //00124
							new Object[] { serie.getNumserie().toString()}));
						}
					}
				}
				if (Constants.REGIMEN_IMPO_DEFINITIVA.equals(mregi_proce)) {					
					listError.addAll(valDetRegPreImpoConsumo(precedente, numeroSerieDecl));					
					
				}else if ( SunatStringUtils.isEqualTo(mregi_proce, String.valueOf( Constants.REGIMEN_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO ))  ) {
					/**
					 * r2bz Habilitar cuando se tenga las reglas de negocio
					 * requeridas
					 */

				} else if (  SunatStringUtils.isEqualTo(mregi_proce, String.valueOf( Constants.REGIMEN_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO)) ) {
					/**
					 * r2bz Habilitar cuando se tenga las reglas de negocio
					 * requeridas
					 */

				} else if ("29".equals(mregi_proce)) {
					/**
					 * r2bz Habilitar cuando se tenga las reglas de negocio
					 * requeridas
					 */

				} else if (SunatStringUtils.include(mregi_proce, new String[] {
						"50", "51", "52" })) {
					// spvalexpotemporal
				} else if (Constants.REGI_DEPOSITO.equals(mregi_proce)&&!tieneRegPreEspeciales) {
					valRegPrecDepositoService = fabricaDeServicios.getService("ingreso.ValRegPrecDeposito");
					tieneRegPreDeposito = true;
					listError.addAll(valRegPrecDepositoService.valDetRegPreDeposito(declaracion, serie, precedente, fechaReferencia, codTransaccion, codCanal,listDuaCache,listSeriesCache));
				} else if (!esVigenteRIN31&&SunatStringUtils.include(mregi_proce, new String[] {ConstantesDataCatalogo.REG_DMUA, ConstantesDataCatalogo.REG_DUTY_FREE, ConstantesDataCatalogo.ACTA_RETENCION, ConstantesDataCatalogo.ACTA_INCAUTACION})){
						tieneRegPreEspeciales = true;
						codRegimenEspecial = mregi_proce;
				
				}else if(tieneRegPreEspeciales&&!tieneErrorRegimenEspecial&&esVigenteRIN31){// csantillan PAS20181U220200054

					codRegimenEspecial = mregi_proce;

					listError.add(valRegPrecEspecialesSevice.valEnvioManifiesto (declaracion.getDua().getManifiesto(), codRegimenEspecial));
					listError.add(valRegPrecEspecialesSevice.valModalidad(declaracion.getDua().getCodmodalidad(),codRegimenEspecial));
					listError.add(valRegPrecEspecialesSevice.valTipoPrecedenteUnico(declaracion.getDua(),codRegimenEspecial));

					listError.removeIf(p -> p.isEmpty());

					if(!listError.isEmpty()){
						tieneErrorRegimenEspecial = true;
						}

				} else if ("12".equals(mregi_proce)) {
					// spvalreposicion
					/*INICIO-P28 FSW AFMA*/
					//listError.addAll(validarReposicionFranquicia(declaracion, serie, precedente, cantidadAcumuladaCertificado));
					listError.addAll(validarReposicionFranquicia(declaracion, serie, precedente, cantidadAcumuladaCertificado,codTransaccion,
							mSaldDispAdiItemCrmf));//P28-PAS20155E410000032 - bug 23702
					/*FIN-P28 FSW AFMA*/

				} else if ("23".equals(mregi_proce)) {
					// spvalCertInterTempo
				} else if ("72".equals(mregi_proce) && "235".equals(maduana)) {
					// spRegPre72
				//}else if (!SunatStringUtils.include(mregi_proce, new String[]{"24","90","91", "S5", "80", "71", "74"}) && !SunatStringUtils.include(mregi_proce.substring(0, 1),new String[]{"A","R"})){
				} else if ("91".equals(mregi_proce)){//jenciso pase 2014-039
					ValRegPrecCeticosService valRegPrecCeticoService = fabricaDeServicios.getService("ingreso.ValRegPrecCetico");
					listError.addAll(valRegPrecCeticoService.valDetRegPreCeticos(declaracion, serie, precedente, fechaReferencia, codTransaccion));
				} else if (!SunatStringUtils.include(mregi_proce, new String[]{"24","90","91", "S5", "80", "71", "74"}) 
						 && !SunatStringUtils.include(mregi_proce.substring(0, 1),new String[]{"A","R"})){
					listError.add(ResponseMapManager.getErrorResponseMap("5036","REGI_PROCE EN IMPORTACION DEFINITIVA "+mregi_proce));
				}
			}			
		}
		
//		removerMensajeCantidadExcedeSaldoDisponible(listError);//P28-part2 - bug 23702
		
		if (tieneRegPreDeposito) {
			valRegPrecDepositoService = fabricaDeServicios.getService("ingreso.ValRegPrecDeposito");
			listError.addAll(valRegPrecDepositoService.valCabRegPreDeposito(declaracion, fechaReferencia));
		}
		
		if (tieneRegPreEspeciales&&!tieneErrorRegimenEspecial) {
			listError.addAll(valRegPrecEspecialesSevice.validarDatosGenerales(declaracion, fechaReferencia, codRegimenEspecial));
		}

		//msancheza: RIN P29-Precedente de Mercanc�a Vigente
		if (tieneRegPrecImpoConsumoTPN21 ) {
			ValRegprec valRegprec = fabricaDeServicios.getService("ValRegprec");
			//PAS20171U220200005 - mtorralba 20170810 - Inicio
			List<Map<String, String>> listaErroresTPN21 = new ArrayList<Map<String,String>>();
			if ( codTransaccion.equals(TRANS_NUMERACION_IMPORTACION_DEFINITIVA) ){
			/**
			 *  3. ERROR N11.	Que, todas las series sean TPN21
			 */
				//NO TODAS LAS SERIES DE LA DECLARACI�N CONSIGNAN EL TPN 21
				if(cantidadSerieTPN.compareTo(cantidadSerieTotales)>0 ||cantidadSerieTPN.compareTo(cantidadSerieTotales)<0){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31887"));
					//return listError;
				}
				listaErroresTPN21 = valRegprec.valCabRegPreTPN21ImpoConsumo(declaracion, tieneRegPrecImpoConsumoTPN21, fechaReferencia, codTransaccion);
			
			}
			//gmontoya P29
			if ( codTransaccion.equals(TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA) || codTransaccion.equals("1007") || codTransaccion.equals("1009")
					|| codTransaccion.equals("1006")|| codTransaccion.equals("1016") || codTransaccion.equals("1004")|| codTransaccion.equals("1005")|| codTransaccion.equals("1008") || codTransaccion.equals("1010") || codTransaccion.equals("1012")){
				//glazaror... reutilizamos el objeto declaracionBD... para no volver a consultar de base datos
				listaErroresTPN21 = valTransaccionxTPN21(declaracion,codTransaccion,fechaReferencia, declaracionBD);
			}
			
			ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService");
			listaErroresTPN21 = valMercanciaVigenteService.filtraErroresDuplicados(listaErroresTPN21);

			listError.addAll(listaErroresTPN21);
			
			//PAS20171U220200005 - mtorralba 20170810 - Fin

		} //Final TPN21
		
		return listError;    
	}

	//ini P28-PAS20155E410000032 - bug 23702
	public void obtenerSaldoDisponibleAdicionalXItemCrmf(Declaracion declaracion, Map<String, Object> mSaldDispAdiItemCrmf,List<Map<String, Object>> datosCrmfPorSerie) {//P28-PAS20155E410000032-[jlunah] BUG 3395 Jira
		if(declaracion.getNumeroDeclaracion() == null) {
			return;
		}
		CertificadoReposicionService certificadoReposicionService = fabricaDeServicios.getService("sigad.ingreso.CertificadoReposicionService");
		
		Map<String, String> mUnidadItemCrmf = new HashMap<String, String>();
		
		List<DirfCtaCte> lDirfCtaCte = obtenerListaDirfCtaCteXDeclaracion(declaracion);
		List<SerieItemCrmfBean> lSerieItemCrmfBean = obtenerListalSerieItemCrmfBeanXDeclaracion(declaracion);
		
		Elementos<DatoSerie> series = declaracion.getDua().getListSeries();
		for (DatoSerie datoSerie : series) {
			
			Map<String, Object> saldoTransmitidoSerie = new HashMap<String, Object>();//P28-PAS20155E410000032-[jlunah] BUG 3395 Jira
			
		  if(datoSerie.getListRegPrecedencia() != null){
			for (DatoRegPrecedencia datoRegPrecedencia : datoSerie.getListRegPrecedencia()) {
				
				if (ConstantesDataCatalogo.REGIMEN_CERTIFI_REPOSICION.equals(datoRegPrecedencia.getCodregipre())) {
					
					Map<String, String> mItemCrmf = obtenerMapaItemCrmf(datoRegPrecedencia);
					String idItemCrmf = obtenerIdItemCrmf(mItemCrmf);
					String unidadItemCrmf = obtenerUnidadItemCrmf(certificadoReposicionService, mUnidadItemCrmf, idItemCrmf, mItemCrmf);
					BigDecimal cntReservadaNueva = obtenerCntReservadaNueva(datoSerie, unidadItemCrmf);
					BigDecimal cntReservadaAnterior = obtenerCntReservadaAnterior(lDirfCtaCte, lSerieItemCrmfBean, datoSerie);
					
					/*inicio P28-PAS20155E410000032-[jlunah] BUG 3395 Jira*/
					/*Datos del certificado anterior (en BD), de la serie evaluada*/
					DirfCtaCte dirfCtaCteEnBD = obtenerDirfCtaCteXSerie(lDirfCtaCte, datoSerie);
					Map<String, String> certificadoOldMap = obtenerMapaItemCrmf(dirfCtaCteEnBD);
					String idCertificadoOld = "";
					if(!certificadoOldMap.isEmpty()){
						idCertificadoOld = obtenerIdItemCrmf(certificadoOldMap);
					}
					
					saldoTransmitidoSerie.put("serie", datoSerie.getNumserie());
					saldoTransmitidoSerie.put("crmfAnterior", idCertificadoOld);
					saldoTransmitidoSerie.put("crmfActual", idItemCrmf);
					saldoTransmitidoSerie.put("montoAnterior", cntReservadaAnterior);
					saldoTransmitidoSerie.put("montoActual", cntReservadaNueva);
					
					saldoTransmitidoSerie.put("unidadItemCrmfAnterior", dirfCtaCteEnBD == null ? "" : dirfCtaCteEnBD.getRftuni());
					saldoTransmitidoSerie.put("unidadItemCrmfActual", unidadItemCrmf);

					if(idItemCrmf.equals(idCertificadoOld) && cntReservadaNueva.compareTo(cntReservadaAnterior) == 0){//Si no hay cambios en certificado y montos
						saldoTransmitidoSerie.put("conCambioEnCrmfAndMonto", false);
					}else{
						saldoTransmitidoSerie.put("conCambioEnCrmfAndMonto", true);
					}
					/*fin P28-PAS20155E410000032-[jlunah] BUG 3395 Jira*/
					
					BigDecimal saldoDisponibleAdicional = BigDecimal.ZERO;
					if(cntReservadaAnterior.compareTo(cntReservadaNueva) > 0) {
						saldoDisponibleAdicional = cntReservadaAnterior.subtract(cntReservadaNueva);
					}
					
					if(mSaldDispAdiItemCrmf.get(idItemCrmf) != null) {
						saldoDisponibleAdicional = saldoDisponibleAdicional.add((BigDecimal) mSaldDispAdiItemCrmf.get(idItemCrmf));//P28-PAS20155E410000032-[jlunah] BUG 3395 Jira
					}
					mSaldDispAdiItemCrmf.put(idItemCrmf, saldoDisponibleAdicional);
					datosCrmfPorSerie.add(saldoTransmitidoSerie);//P28-PAS20155E410000032-[jlunah] BUG 3395 Jira
					
				}
			}
		  }
		}
		
		
	}
	
	private List<DirfCtaCte> obtenerListaDirfCtaCteXDeclaracion(Declaracion declaracion) {
		DirfCtaCteDAO dirfCtaCteDAO = fabricaDeServicios.getService("despacho.entrada.dirfCtaCteDAO");
		DataSourceContextHolder.setKeyDataSource(declaracion.getCodaduana().trim());//P28-PAS20155E410000032-[jlunah] BUG 3360 en Jira
		
		Map<String, Object> paramsDirfCtaCte = new HashMap<String, Object>();
		paramsDirfCtaCte.put("dicadu", declaracion.getCodaduana());
		paramsDirfCtaCte.put("difano", declaracion.getDua().getAnnorden().toString());
		paramsDirfCtaCte.put("dindcl",  SunatStringUtils.lpad(declaracion.getNumeroDeclaracion().toString(), 6, '0'));
		
		return dirfCtaCteDAO.listCertificadoCuentaCorriente(paramsDirfCtaCte);
	}
	
	private DirfCtaCte obtenerDirfCtaCteXSerie(List<DirfCtaCte> lDirfCtaCte, DatoSerie datoSerie) {
		for(DirfCtaCte dirfCtaCte : lDirfCtaCte) {
			if(SunatNumberUtils.toInteger(dirfCtaCte.getDinser()).intValue() == datoSerie.getNumserie().intValue()
					&& !"S".equals(dirfCtaCte.getDiElim())) {
				return dirfCtaCte;
			}
		}
		
		return null;
	}
	
	private List<SerieItemCrmfBean> obtenerListalSerieItemCrmfBeanXDeclaracion(Declaracion declaracion) {
		DetCtacteRegimenDAO detCtacteRegimenDAO = fabricaDeServicios.getService("declaracion.detCtaCteRegimen");
		
		Map<String, Object> paramsDetCtaCteRegimen = new HashMap<String, Object>();
		paramsDetCtaCteRegimen.put("codAduanaDcl", declaracion.getCodaduana());
		paramsDetCtaCteRegimen.put("annPresenDcl", declaracion.getDua().getAnnpresen());
		paramsDetCtaCteRegimen.put("numDeclaracionDcl", declaracion.getNumeroDeclaracion());
		paramsDetCtaCteRegimen.put("indAnulacion", "1");
		
		return detCtacteRegimenDAO.selectSerieItemCrmfByCrmf(paramsDetCtaCteRegimen);
	}
	
	private SerieItemCrmfBean obtenerSerieItemCrmfBeanXSerie(List<SerieItemCrmfBean> lSerieItemCrmfBean, DatoSerie datoSerie) {
		for(SerieItemCrmfBean serieItemCrmfBean : lSerieItemCrmfBean) {
			if(datoSerie.getNumserie().equals(serieItemCrmfBean.getNumSecSerie())) {
				return serieItemCrmfBean;
			}
		}
		
		return null;
	}
	
	private BigDecimal obtenerCntReservadaAnterior(List<DirfCtaCte> lDirfCtaCte, List<SerieItemCrmfBean> lSerieItemCrmfBean, DatoSerie datoSerie) {
		DirfCtaCte dirfCtaCte = obtenerDirfCtaCteXSerie(lDirfCtaCte, datoSerie);
		SerieItemCrmfBean serieItemCrmfBean = obtenerSerieItemCrmfBeanXSerie(lSerieItemCrmfBean, datoSerie);
		
		BigDecimal rfreco = BigDecimal.ZERO;
		
		/*inicio P28-PAS20155E410000032-[jlunah] BUG 3432 JIRA*/
		if(dirfCtaCte == null && serieItemCrmfBean != null){//si no tiene datos en dirfctacte pero si tiene datos en la tabla temporal
			return rfreco;//considera monto anterior como 0
		}
		/*fin P28-PAS20155E410000032-[jlunah] BUG 3432 JIRA*/
		
		if(dirfCtaCte != null && dirfCtaCte.getRfqreco() != null) {
			rfreco = dirfCtaCte.getRfqreco();
		}
		
		BigDecimal cntDescargada = BigDecimal.ZERO;
		if(serieItemCrmfBean != null && serieItemCrmfBean.getCntDescargada() != null) {
			cntDescargada = serieItemCrmfBean.getCntDescargada();
		}
		
		if(rfreco.compareTo(cntDescargada) == 1) {
			return rfreco;
		} else {
			return cntDescargada;
		}
	}
	
	private Map<String, String> obtenerMapaItemCrmf(DatoRegPrecedencia datoRegPrecedencia) {
		Map<String, String> mItemCrmf = new HashMap<String, String>();
		mItemCrmf.put("rfcadu", datoRegPrecedencia.getCodaduapre());
		mItemCrmf.put("rffano", SunatStringUtils.substringFox(datoRegPrecedencia.getAnndeclpre(), 1, 4));
		mItemCrmf.put("rfncer", SunatStringUtils.lpad(datoRegPrecedencia.getNumdeclpre(), 6, '0'));
		mItemCrmf.put("rfnitem", SunatStringUtils.lpad(String.valueOf(datoRegPrecedencia.getNumserpre()), 3, '0'));
		
		return mItemCrmf;
	}
	
	/*inicio P28-PAS20155E410000032-[jlunah] BUG 3395 Jira*/
	private Map<String, String> obtenerMapaItemCrmf(DirfCtaCte dirfCtaCte) {
		Map<String, String> mItemCrmf = new HashMap<String, String>();
		
		if(dirfCtaCte  != null){
			mItemCrmf.put("rfcadu", dirfCtaCte.getRfcadu());
			mItemCrmf.put("rffano", dirfCtaCte.getRffano());
			mItemCrmf.put("rfncer", dirfCtaCte.getRfncer());
			mItemCrmf.put("rfnitem", dirfCtaCte.getRfnitem());
		}
		return mItemCrmf;
	
	}
	/*fin P28-PAS20155E410000032-[jlunah] BUG 3395 Jira*/
	
	private String obtenerIdItemCrmf(Map<String, String> mItemCrmf) {
		StringBuilder sbIdItemCrmf = new StringBuilder();
		sbIdItemCrmf.append(mItemCrmf.get("rfcadu")).append("-");
		sbIdItemCrmf.append(mItemCrmf.get("rffano")).append("-");
		sbIdItemCrmf.append(mItemCrmf.get("rfncer")).append("-");
		sbIdItemCrmf.append(mItemCrmf.get("rfnitem"));
		
		return sbIdItemCrmf.toString();
	}
	
	private String obtenerUnidadItemCrmf(CertificadoReposicionService certificadoReposicionService,
			Map<String, String> mUnidadItemCrmf, String idItemCrmf, Map<String, String> mItemCrmf) {
		String unidadItemCrmf = "";
		
		if(mUnidadItemCrmf.get(idItemCrmf) != null) {
			unidadItemCrmf = mUnidadItemCrmf.get(idItemCrmf);
		} else {
			Map<String, Object> parametrosSeries = new HashMap<String, Object>();
			parametrosSeries.put("sceAdua", mItemCrmf.get("rfcadu"));
			parametrosSeries.put("sceAnce", mItemCrmf.get("rffano"));
			parametrosSeries.put("sceNcer", mItemCrmf.get("rfncer"));
			parametrosSeries.put("sceItem", SunatNumberUtils.toInteger(mItemCrmf.get("rfnitem")));
			
			List<Reposce> lReposce = certificadoReposicionService.listarSeriesCertificadoReposicion(parametrosSeries);
			
			if(!CollectionUtils.isEmpty(lReposce)) {
				mUnidadItemCrmf.put(idItemCrmf, lReposce.get(0).getSceUni().trim());
				unidadItemCrmf = mUnidadItemCrmf.get(idItemCrmf);
			}
		}
		
		return unidadItemCrmf;
	}
	
	private BigDecimal obtenerCntReservadaNueva(DatoSerie datoSerie, String unidadItemCrmf) {
		BigDecimal cntReservada = BigDecimal.ZERO;
		
		String undFisica = datoSerie.getCodunifis();
//OMA
//		String undEquivalente = datoSerie.getDatoProductoTmp() == null || datoSerie.getDatoProductoTmp().getCodtipoequi() == null?
//						"" : datoSerie.getDatoProductoTmp().getCodtipoequi();
		
		String undEquivalente = datoSerie.getProducto() == null || datoSerie.getProducto().getCodtipoequi() == null?
				"" : datoSerie.getProducto().getCodtipoequi();
		
		if(undFisica.equals(unidadItemCrmf)) {
			cntReservada = datoSerie.getCntunifis();
		} else if(undEquivalente.equals(unidadItemCrmf)) {
//			cntReservada = datoSerie.getDatoProductoTmp() == null || datoSerie.getDatoProductoTmp().getCntunimedidaequi() == null?
//							BigDecimal.ZERO : datoSerie.getDatoProductoTmp().getCntunimedidaequi();
//			
			cntReservada = datoSerie.getProducto() == null || datoSerie.getProducto().getCntunimedidaequi() == null?
					BigDecimal.ZERO : datoSerie.getProducto().getCntunimedidaequi();
		}
	//OMA	
		return cntReservada;
	}
	//fin P28-PAS20155E410000032 - bug 23702
	
	/**
	 * Validaciones correspondientes a la Reposici�n con Mercanc�as con Franquicia Arancelaria.
	 * 
	 * @param declaracion Declaracion
	 * @return Lista de erores
	 */
	/*INICIO-P28 FSW AFMA*/
	//private List<Map<String,String>> validarReposicionFranquicia(Declaracion declaracion, DatoSerie datoSerie, DatoRegPrecedencia datoRegPrecedencia, Map<String, BigDecimal> cantidadAcumuladaCertificado){
	private List<Map<String,String>> validarReposicionFranquicia(Declaracion declaracion, DatoSerie datoSerie, DatoRegPrecedencia datoRegPrecedencia, Map<String, BigDecimal> cantidadAcumuladaCertificado,String codTransaccion,
			Map<String, Object> mSaldDispAdiItemCrmf){//P28-PAS20155E410000032 - bug 23702; P28-PAS20155E410000032-[jlunah] BUG 3395 Jira
	/*FIN-P28 FSW AFMA*/

		
				List<Map<String, String>>  result = new ArrayList<Map<String,String>>();
			//P28
				List<Map<String,String>> retorno = new ArrayList<Map<String,String>>();
				Map<String,Object> datos = new HashMap<String, Object>();
				//boolean existeTransferencia = false;
				boolean indAnulado = false;

				int numSerieDUA = datoSerie.getNumserie();
				String numCertificadoXML = SunatStringUtils.lpad(datoRegPrecedencia.getNumdeclpre(),6,'0');//P28
				String codAduanaXML = datoRegPrecedencia.getCodaduapre();
				String anioCertificadoXML = SunatStringUtils.substringFox(datoRegPrecedencia.getAnndeclpre(), 1,4);
				String codAduaAnioDuaNumCertXML = codAduanaXML+"-"+anioCertificadoXML+"-"+numCertificadoXML;
				String numRucXML = declaracion.getDua().getDeclarante().getNumeroDocumentoIdentidad();
				int numItemXML = datoRegPrecedencia.getNumserpre();
				Integer fecVencimientoXML = SunatDateUtils.getIntegerFromDate(datoRegPrecedencia.getFecvencpre());
				//OMA
				//String undEquivalentesXML = datoSerie.getDatoProductoTmp() == null?"":datoSerie.getDatoProductoTmp().getCodtipoequi() == null?"":datoSerie.getDatoProductoTmp().getCodtipoequi();//P28				
				String undEquivalentesXML = datoSerie.getProducto() == null?"":datoSerie.getProducto().getCodtipoequi() == null?"":datoSerie.getProducto().getCodtipoequi();//P28 PAS20181U220200004
				
				String undFisicaXML = datoSerie.getCodunifis();
				BigDecimal cntFisicaXML = datoSerie.getCntunifis();
				String codAduanaDua = declaracion.getCodaduana().trim();
				//OMA
				//BigDecimal cntEquivalenteXML = datoSerie.getDatoProductoTmp() == null?new BigDecimal(0):datoSerie.getDatoProductoTmp().getCntunimedidaequi() == null?new BigDecimal(0):datoSerie.getDatoProductoTmp().getCntunimedidaequi();				
				BigDecimal cntEquivalenteXML = datoSerie.getProducto() == null?new BigDecimal(0):datoSerie.getProducto().getCntunimedidaequi() == null?new BigDecimal(0):datoSerie.getProducto().getCntunimedidaequi();				//PAS20181U220200004
				Integer fecNume = SunatDateUtils.getIntegerFromDate(declaracion.getDua().getFecdeclaracion());
				Date fecha = DateUtil.getToday();
				Integer fechaActual = SunatDateUtils.getIntegerFromDate(fecha);
				Integer fecNumeracion = fecNume == 0?fechaActual:fecNume;
				
				/**Guardar datos en el Map datos P28*/
				datos.put("numSerieDUA", numSerieDUA);
				datos.put("numCertificadoXML", numCertificadoXML);
				datos.put("codAduanaXML", codAduanaXML);
				datos.put("anioCertificadoXML", anioCertificadoXML);
				datos.put("codAduaAnioDuaNumCertXML", codAduaAnioDuaNumCertXML);
				datos.put("numRucXML", numRucXML);
				datos.put("numItemXML", numItemXML);
				datos.put("fecVencimientoXML", fecVencimientoXML);
				datos.put("undEquivalentesXML", undEquivalentesXML);
				datos.put("undFisicaXML", undFisicaXML);
				datos.put("cntFisicaXML", cntFisicaXML);
				datos.put("codAduanaDua", codAduanaDua);
				datos.put("cntEquivalenteXML", cntEquivalenteXML);
				datos.put("fecNumeracion",fecNumeracion);

				datos.put("numDeclaracion", declaracion.getNumeroDeclaracion());
				datos.put("anioDua", declaracion.getDua().getAnnorden());
				
				/** Parametros de TratoPrefNacServ.listarCertificadoReposicion */
				Map<String, Object> parametrosCert = new HashMap<String, Object>();
				/** Parametros de TratoPrefNacServ.listarSeriesCertificadoReposicion */
				Map<String, Object> parametrosSeries = new HashMap<String, Object>();
				/** Parametros de TratoPrefNacServ.listarCertificadoTransferido */
				//Map<String, Object> parametrosTransf = new HashMap<String, Object>();
				/** Parametros de TratoPrefNacServ.obtenerSaldoDisponibleCertificado */
				//Map<String, Object> parametrosDisp = new HashMap<String, Object>();				
				
				List<Repocer> certificadoReposicion=new ArrayList<Repocer>();
				List<Reposce> listSeriesCertificado=new ArrayList<Reposce>();
				//RepoTra certificadoTransferido=new RepoTra();
				Repocer certificado = new Repocer();
				
				/** Invocando al m�todo listarCertificadoReposicion */
				//pase 433
				parametrosCert.put("cerCert", SunatStringUtils.lpad(numCertificadoXML,6,'0'));
				//parametrosCert.put("cerCert", numCertificadoXML);
				parametrosCert.put("cerAdua", codAduanaXML);
				parametrosCert.put("cerAnce", anioCertificadoXML);
				CertificadoReposicionService certificadoReposicionService = fabricaDeServicios.getService("sigad.ingreso.CertificadoReposicionService");
				certificadoReposicion = certificadoReposicionService.listarCertificadoReposicion(parametrosCert);
				//P28
				ValRegPrecedenciaReposicionService valRegPrecedenciaReposicion = fabricaDeServicios.getService("ValRegPrecedenciaReposicion");

				/** Validar la existencia del n�mero de certificado consignado en la serie de declaraci�n */
				retorno = valRegPrecedenciaReposicion.validaExistenciaCRMF(certificadoReposicion, datos);
				
				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
					return result;
				}
				
				/** Validar que el certificado de reposici�n no se encuentre en estado Anulado */	
				retorno = new ArrayList<Map<String,String>>();
				retorno = valRegPrecedenciaReposicion.validaEstadoCRMF(certificadoReposicion, datos);
				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
					indAnulado=true;
				}
				
				/** Validar que el RUC de la declaraci�n corresponda al beneficiario */
				retorno = new ArrayList<Map<String,String>>();
				retorno = valRegPrecedenciaReposicion.validaRUCBeneficiario(certificadoReposicion, datos);
				
				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
						return result;
				} else {
						if(indAnulado==true){
						return result;
					} 
				}
				
				/** Invocando al m�todo listarSeriesCertificadoReposicion */
				parametrosSeries.put("sceAdua", codAduanaXML);
				parametrosSeries.put("sceNcer", numCertificadoXML);
				parametrosSeries.put("sceAnce", anioCertificadoXML);
				listSeriesCertificado = certificadoReposicionService.listarSeriesCertificadoReposicion(parametrosSeries);
				
				/** Validar que el item consignado para la serie de la declaraci�n exista */
				retorno = new ArrayList<Map<String,String>>();
				retorno = valRegPrecedenciaReposicion.validaExistenciaItem(listSeriesCertificado, datos);
				
				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
				}				
				
					
				/** Validar la fecha de vencimiento consignada en la serie de la declaraci�n */
				retorno = new ArrayList<Map<String, String>>();
				retorno = valRegPrecedenciaReposicion.validaFechaVencimiento(certificadoReposicion, datos);
				
				if (!retorno.isEmpty())
				{
					result.add(retorno.get(0));
				}				
				
				/*INICIO-P28 FSW AFMA*/


		boolean esTPN93incorporador = false;
		if (ConstantesDataCatalogo.TPN_REPOSICION_FRANQUICIA_93.equals(datoSerie.getCodtratprefe())){

			ConvenioSerieDAO convenioSerieDAO = fabricaDeServicios.getService("convenioSerieDAO");

			Map<String, Object> paramSerie = new HashMap<String, Object>();
			paramSerie.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
			paramSerie.put("NUM_SECSERIE", numSerieDUA);

			String[] codConvenio = {"93","  93"};
			paramSerie.put("LIST_COD_CONVENIO",codConvenio);

			paramSerie.put("COD_TIPCONVENIO", "T");
			paramSerie.put("IND_DEL", "0");


			List<HashMap<String,Object>> convenio = (List)convenioSerieDAO.select(paramSerie);
			if(CollectionUtils.isEmpty(convenio)){
				esTPN93incorporador = true;
			}
		}
		        //AFMA PUEDE PARA LO QUE YA FUERON NUMERADOS SE VALIDA CON FEHA DE NUMERACION PUEDE QUE LA FECHA CAMBIE EN OTROS PROCESOS
//				if(TRANS_NUMERACION_IMPORTACION_DEFINITIVA.equals(codTransaccion) || "1016".equals(codTransaccion) || "1003".equals(codTransaccion))
				if(!esTPN93incorporador)
				{
				/** Validar la fecha fin de vigencia del certificado de reposici�n sea mayor o igual a fecha de numeraci�n */
					retorno = new ArrayList<Map<String,String>>();
					retorno = valRegPrecedenciaReposicion.validaFechaVigencia(certificadoReposicion, datos);
				
					if(!retorno.isEmpty()){
						result.add(retorno.get(0));
				    }
				}
				/*FIN-P28 FSW AFMA*/
				/** Validar que solo se puede hacer referencia a un solo item del certificado de reposici�n */
				retorno = new ArrayList<Map<String,String>>();
				retorno = valRegPrecedenciaReposicion.validaUnicoCertificado(datoSerie, datos);
				
				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
				}
				
				/** Validar que el item consignado en la serie de la declaraci�n no se encuentre anulado */
				retorno = new ArrayList<Map<String,String>>();
				retorno = valRegPrecedenciaReposicion.validaEstadoItem(listSeriesCertificado, datos);
				
				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
		    			}

				/** Validar que las unidades fisicas y equivalentes consignadas en la serie coincidan con la CRMF */
				retorno = new ArrayList<Map<String,String>>();
				retorno = valRegPrecedenciaReposicion.validaUndFisicaEquiva(listSeriesCertificado, datos);
				
				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
		    		}
				
				/** Validar que las cantidades fisicas no excedan a la cantidad disponible por item del CRMF */
				datos.put("mSaldDispAdiItemCrmf", mSaldDispAdiItemCrmf);//P28-PAS20155E410000032 - bug 23702
				retorno = new ArrayList<Map<String,String>>();
				retorno = valRegPrecedenciaReposicion.validaCntFisicaEquiva(listSeriesCertificado, datos);
				
				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
				}				

				/** Validar que al consignar el mismo n�mero de certificado e item para diferentes series de la declaraci�n, estas no excedan el saldo disponible por el item del certificado */
				datos.put("declaracion", declaracion);//P28-part2 - bug 23938
				retorno = new ArrayList<Map<String,String>>();
				retorno = valRegPrecedenciaReposicion.validaCntAgrupadaFisicaEquiva(listSeriesCertificado, cantidadAcumuladaCertificado, datos);

				if(!retorno.isEmpty()){
					result.add(retorno.get(0));
		    			}
		    			

		/*INICIO-P28 FSW AFMA*/
		if ( TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA.equals(codTransaccion)
				|| TRANS_REGULARIZACION_URG_IMPORTACION_DEFINITIVA.equals(codTransaccion)
				){
					if(esTPN93incorporador){
						// Buscamos si presenta levante
						CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
						Map<String, Object> params = new HashMap<String, Object>();
						params.put("NUM_CORREDOC",declaracion.getDua().getNumcorredoc());
						Date Fec_levante=cabDeclaraDAO.findFecAutLevante(params);
						boolean tiene_levante= !SunatDateUtils.isDefaultDate(Fec_levante);

						if(tiene_levante){
							//result.add(addError("35619", "Declaraci�n cuenta con Levante Autorizado, no puede incorporar el TPN 93 en la serie: "+numSerieDUA));
							result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35619", new String[]{String.valueOf(numSerieDUA)}));
							return result;
						}

						if(CollectionUtils.isEmpty(certificadoReposicion)){
							result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35008", new String[]{String.valueOf(numSerieDUA) , codAduaAnioDuaNumCertXML}));
							return result;
									}

						/** Validar la fecha fin de vigencia del certificado de reposici�n sea mayor o igual a fecha de rectificacion */
						certificado = certificadoReposicion.get(0);
						Integer fecVencCRMF = (certificado!=null && certificado.getCerFvcto()!=null)?certificado.getCerFvcto():0;
						if(fecVencCRMF<fechaActual){
							//P34 AFMA
							//result.add(addError("35617", "Certificado de Reposici�n  Nro.["+codAduaAnioDuaNumCertXML+ "] de la serie Nro. ["+numSerieDUA+"] se encuentra vencido."));
							result.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("35617", new String[]{codAduaAnioDuaNumCertXML,String.valueOf(numSerieDUA)}));

							return result;
						}
					}
				}
		/*FIN-P28 FSW AFMA*/
		    			
		return result;
				}				
				

	
	/**
	 * Validar el regimen de precedencia 10-Importaci�n a Consumo.
	 * 
	 * @param valTransaccionxTPN21
	 *            DatoRegPrecedencia
	 * @return Lista de errores desarrollado por DZC
	 */
	private List<Map<String, String>> valTransaccionxTPN21(Declaracion declaracion,
			 String codTransaccion,Date fechaReferencia, Declaracion declaracionBD) {
		CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		// Traemos la DUA de BD
		if (declaracionBD == null) {
			declaracionBD = ((GetDeclaracionService)fabricaDeServicios.getService("declaracionService")).getDeclaracion(declaracion.getNumdeclRef().getCodaduana(),
					new Integer(declaracion.getNumdeclRef().getNumcorre()), new Integer(declaracion.getNumdeclRef().getAnnprese()), declaracion.getNumdeclRef().getCodregimen() );
		}
		DUA duaBD =declaracionBD.getDua();
		// Buscamos si presenta levante
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC",duaBD.getNumcorredoc());
		Date Fec_levante=cabDeclaraDAO.findFecAutLevante(params); 
		
		boolean tiene_canal =  duaBD.getCodCanal()!=null?(duaBD.getCodCanal().trim().isEmpty()?false:true):false;//gmontoya P29
		
		//Date Fec_levante=duaBD.getFecAutlevante();
		boolean tiene_levante= !SunatDateUtils.isDefaultDate(Fec_levante);
		// Si realiza retiro de TPN 21 
		int secuencia=0;
		Elementos<DatoSerie> seriesBD = declaracionBD.getDua().getListSeries();
		Elementos<DatoSerie> series = declaracion.getDua().getListSeries();
		boolean AlgunasSeriesNumeradaspresentanAcogimientoTPN21=false;
		boolean AlgunasSeriesRectificadaspresentanAcogimientoTPN21=false;
		boolean TodasSeriesRectificadaspresentaAcogimientoTPN21=false;
		boolean TodasSeriesNumeradaspresentanAcogimientoTPN21=false;
		int cuentaNume=0;
		int cuentaRecti=0;
		// Revisamos si existe o no acogimiento en las series de la numeraci�n
		for (DatoSerie serieBD : seriesBD) {
				 //Presenta retiro de TPN 21
				 if(serieBD.getCodtratprefe().toString().equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_NACIONAL_TPN21)){
					 AlgunasSeriesNumeradaspresentanAcogimientoTPN21=true;
					 cuentaNume=cuentaNume+1;
			 }
		}		 
		if (cuentaNume==seriesBD.size())TodasSeriesNumeradaspresentanAcogimientoTPN21=true;
		
		
		// Recoremos las series trasmitidas en la rectificaci�n
		cuentaRecti=0;
		for (DatoSerie serie : series) {
//			  if(serie.getListRegPrecedencia()!=null && serie.getListRegPrecedencia().size()>0){
//				  for (DatoRegPrecedencia precedente : serie.getListRegPrecedencia()) { //gmontoya P29
						 if(serie.getCodtratprefe().toString().equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_NACIONAL_TPN21)){// && precedente.getCodregipre().equals("10")){
							 AlgunasSeriesRectificadaspresentanAcogimientoTPN21=true;
							 cuentaRecti=cuentaRecti+1;
						 }
//				  }
//			  }
			 
		}
		ValRegprec valRegprec =fabricaDeServicios.getService("ValRegprec");		
		if (cuentaRecti==series.size() || cuentaRecti== cuentaNume)TodasSeriesRectificadaspresentaAcogimientoTPN21=true;
		

		ValMercanciaVigenteService valMercanciaVigenteService = fabricaDeServicios.getService("ingreso.ValMercanciaVigenteService"); 
		
		//gmontoya P29 inicio
		// VALIDACIONES DE ACOGIMIENTO: No tiene TPN21 en numeracion y reci�n se est� a�adiendo el TPN21 en rectificaci�n o diligencia  
		if (!AlgunasSeriesNumeradaspresentanAcogimientoTPN21 && AlgunasSeriesRectificadaspresentanAcogimientoTPN21){// && tiene_levante){ gmontoya P29
			//Si se acoge a TPN 21 , validamos que cuando rectifique no cuente con levante Autorizado
			if(tiene_levante && tiene_canal){
				//listError.add(getDUAError("32000",new Object[]{""})); //'No se puede incluir TPN 21 para una declaraci�n con levante autorizado'
				//PAS20171U220200005 RF30 ATRG Recti:
				String indicadorAsociado = "";
				List<DatoIndicadores> listaIndicadoresEnvio = declaracion.getDua().getListIndicadores();
				DatoIndicadores indicador  = valMercanciaVigenteService.obtenerIndicadorLlaveManoDespachoParcial(listaIndicadoresEnvio);
				
				if(indicador!=null && indicador.getCodigoIndicador().equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_LLAVE_EN_MANO))
					indicadorAsociado="CONTRATO LLAVE EN MANO";
				
				if(indicador!=null && indicador.getCodigoIndicador().equals(ConstantesDataCatalogo.INDICADOR_MERCANCIAVIGENTE_DESPACHOS_PARCIALES))
					indicadorAsociado="MERCANCIA VIGENTE: MAQUINARIA O EQUIPO ARRIBADO A DESPACHOS PARCIALES";
				
				if(SunatStringUtils.isEmpty(indicadorAsociado)){
					listError.add(getDUAError("32053",new Object[]{indicadorAsociado}));  
				}else{
					listError.add(getDUAError("32000",new Object[]{""})); //'No se puede incluir TPN 21 para una declaraci�n con levante autorizado'
				}
			}else{
				
				if(!TodasSeriesRectificadaspresentaAcogimientoTPN21){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31887"));
				}
				
				for (DatoSerie serie : series) {
					// Validamos Regimen precedente
					if(serie.getCodtratprefe().toString().equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_NACIONAL_TPN21) && CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
						listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31913",new String[] {serie.getNumserie().toString()}));
					}
				}   

				//Si presenta algun acogimiento y no tiene levante se realiza el CUS 01.03.01 Validar la declaraci�n precedente de las mercancias vigentes TPN 21
				listError.addAll(valRegprec.valCabRegPreTPN21ImpoConsumo(declaracion, AlgunasSeriesRectificadaspresentanAcogimientoTPN21, fechaReferencia, codTransaccion));
			}			
		}
		else if(AlgunasSeriesNumeradaspresentanAcogimientoTPN21 && !TodasSeriesRectificadaspresentaAcogimientoTPN21) { 
		// VALIDACIONES DE RETIRO: Tiene TPN21 en numeracion y se est� quitando el TPN21 en alguna serie  
			for (DatoSerie serie : series) {
				if(serie.getCodtratprefe().toString().equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_NACIONAL_TPN21)){
					  // Validamos el retiro de TPN 21
					listError.add(getDUAError("32002",new Object[]{serie.getNumserie()})); //'Retire el TPN 21 de la serie {0} de la declaraci�n '							 
				}  
				// Validamos el Retiro de Regimen precedente
				if(serie.getListRegPrecedencia()!=null && serie.getListRegPrecedencia().size()>0){
					for (DatoRegPrecedencia precedente : serie.getListRegPrecedencia()) {
						if(precedente.getCodregipre().equals("10") )listError.add(getDUAError("32001",new Object[]{serie.getNumserie()})); //'Retire la informaci�n del r�gimen precedente 10 de la serie {0} '	
					}
				}
			}   
		}
		else if(AlgunasSeriesNumeradaspresentanAcogimientoTPN21 && TodasSeriesRectificadaspresentaAcogimientoTPN21) {
		//PAS20145E220000399 15/01/2015 - mtorralba
		// VALIDACIONES CUANDO HAY CAMBIOS: Se incluye este bloque para volver a invocar a las validaciones del TPN21, para validar cambios en rectificaci�n o diligencia
			for (DatoSerie serie : series) {
				// Validamos Regimen precedente
				if(serie.getCodtratprefe().toString().equals(ConstantesDataCatalogo.TRATO_PREFERENCIAL_NACIONAL_TPN21) && CollectionUtils.isEmpty(serie.getListRegPrecedencia())){
					listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("31913",new String[] {serie.getNumserie().toString()}));
				}
			}   

			//Si presenta algun acogimiento y no tiene levante se realiza el CUS 01.03.01 Validar la declaraci�n precedente de las mercancias vigentes TPN 21
			listError.addAll(valRegprec.valCabRegPreTPN21ImpoConsumo(declaracion, AlgunasSeriesRectificadaspresentanAcogimientoTPN21, fechaReferencia, codTransaccion));
		}
		return listError;
	}         
	
	/**
	 * Validar el regimen de precedencia 10-Importaci�n a Consumo.
	 * 
	 * @param regimenPrec
	 *            DatoRegPrecedencia
	 * @return Lista de erores
	 */
	private List<Map<String, String>> valDetRegPreImpoConsumo(DatoRegPrecedencia regimenPrec, String numeroSerie) {

		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (Constants.REGIMEN_IMPO_DEFINITIVA.equals(regimenPrec.getCodregipre())) {
			String regimenPrecedencia = (new StringBuffer()).append(regimenPrec.getCodaduapre()).append("-")
					.append(SunatStringUtils.substringFox(
							regimenPrec.getAnndeclpre(), 1, 4)).append("-")
					.append(regimenPrec.getCodregipre()).append("-")
					.append(regimenPrec.getNumdeclpre()).toString();
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("codigoAduana", regimenPrec.getCodaduapre());
			params.put("annoPresentacion", SunatNumberUtils.toInteger(SunatStringUtils.substringFox(regimenPrec.getAnndeclpre(), 1, 4)));
			params.put("codigoRegimen", regimenPrec.getCodregipre());
			params.put("numeroDeclaracion",SunatNumberUtils.toLong(regimenPrec.getNumdeclpre()));
			CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
			DUA dua = cabDeclaraDAO.findDUAByMap(params);//gmontoya IoC
			
			if (dua != null) {
				if ("08".equals(dua.getCodEstdua())) {
					listError.add(getDUAError("0124", new Object[] { numeroSerie, regimenPrecedencia }));
				}
			} else {
				params.clear();
				String anio = SunatStringUtils.substring(regimenPrec.getAnndeclpre(), 2, 4);
				params.put("TABLA", "DI" + anio + "POLIZAI");
				params.put("codigoAduana", regimenPrec.getCodaduapre());
				params.put("annoPresentacion", anio);
				params.put("numeroDeclaracion", regimenPrec.getNumdeclpre());
				ConsultaDeclaracionImpoConsumoService consultaDeclaracionImpoConsumoService = fabricaDeServicios.getService("sigad.ingreso.ConsultaDeclaracionImpoConsumoService");				
				//Object o = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.ds." + regimenPrec.getCodaduapre()));//gmontoya IoC
				//Integer count = dipolizaiDAO.getCountNoLgajadas(params);//gmontoya IoC
				Integer count = consultaDeclaracionImpoConsumoService.countDeclaracionNoLegajadaImpoConsumo(params, regimenPrec.getCodaduapre());
				//swapperDatasource.swap(o);//gmontoya IoC
				
				if (count == 0) {
					listError.add(getDUAError("0124",
							new Object[] { numeroSerie, regimenPrecedencia }));
				}
			}
		}
		return listError;
	}


	private String obtenerCanal(Declaracion declaracion) {
		Map<String, Object> params = new HashMap<String, Object>();
		String codcanal = new String();
		if (declaracion.getDua().getNumcorredoc() != null) {
			CabDeclaraDAO cabDeclaraDAO = (CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO");
			params.put("NUM_CORREDOC", declaracion.getDua().getNumcorredoc());
			Map<String, Object> mapDua = cabDeclaraDAO.findDuaByNumCorreDoc(params);
			codcanal = (String) mapDua.get("COD_CANAL");
		}
		return codcanal;
	}

        
  
   
/**
	 * Graba telelog.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param codigo String
	 * @param mensaje String
	 */
/*	private void grabaTelelog(List<Map<String,String>>listError, String codigo, String mensaje){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		System.out.println("codError: "+codigo);
		System.out.println("msje: "+mensaje);
		listError.add(getErrorMapWithDescription(codigo, mensaje));
	}*/
	
	/**
	 * Graba telelog.
	 * 
	 * @param listError List<Map<String,String>>
	 * @param codigo String
	 * @param params Object[]
	 */
/*	private void grabaTelelog(List<Map<String,String>>listError, String codigo, Object[] params){
		if (codigo.length()<5 && !SunatStringUtils.isEmptyTrim(codigo))
			codigo=SunatStringUtils.lpad(codigo, 5, '0');
		listError.add(getDUAError(codigo, params));
	}
	*/
	/*
	public GetValidacionesService getValidacionesService() {
		return validacionesService;
	}

	public void setValidacionesService(
			GetValidacionesService validacionesService) {
		this.validacionesService = validacionesService;
	}

	public CabDeclaraDAO getCabDeclaraDAO() {
		return cabDeclaraDAO;
	}

	public void setCabDeclaraDAO(CabDeclaraDAO cabDeclaraDAO) {
		this.cabDeclaraDAO = cabDeclaraDAO;
	}

	public PolizadDAO getPolizadDAO() {
		return polizadDAO;
	}

	public void setPolizadDAO(PolizadDAO polizadDAO) {
		this.polizadDAO = polizadDAO;
	}
	
	public CatalogoHelperImpl getCatalogoValidacionService() {
		return catalogoValidacionService;
	}

	public void setCatalogoValidacionService(CatalogoHelperImpl catalogoValidacionService) {
		this.catalogoValidacionService = catalogoValidacionService;
	}

	public IndicadorDUADAO getIndicadorDUADAO() {
		return indicadorDUADAO;
	}

	public void setIndicadorDUADAO(IndicadorDUADAO indicadorDUADAO) {
		this.indicadorDUADAO = indicadorDUADAO;
	}

	public CabSolrectiDAO getSolirectificaDAO() {
		return solirectificaDAO;
	}

	public void setSolirectificaDAO(CabSolrectiDAO solirectificaDAO) {
		this.solirectificaDAO = solirectificaDAO;
	}

	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

	public HotSwappableTargetSource getSwapperDatasource() {
		return swapperDatasource;
	}

	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}

	public DipolizaiDAO getDipolizaiDAO() {
		return dipolizaiDAO;
	}

	public void setDipolizaiDAO(DipolizaiDAO dipolizaiDAO) {
		this.dipolizaiDAO = dipolizaiDAO;
	}

	public DetDeclaraDAO getDetDeclaraDAO() {
		return detDeclaraDAO;
	}

	public void setDetDeclaraDAO(DetDeclaraDAO detDeclaraDAO) {
		this.detDeclaraDAO = detDeclaraDAO;
	}

	public SeriesdDAO getSeriesdDAO() {
		return seriesdDAO;
	}

	public void setSeriesdDAO(SeriesdDAO seriesdDAO) {
		this.seriesdDAO = seriesdDAO;
	}

	public ProveedorFuncionesService getFuncionesService() {
		return funcionesService;
	}

	public void setFuncionesService(ProveedorFuncionesService funcionesService) {
		this.funcionesService = funcionesService;
	}

	public ValItemFB getValItemFB() {
		return valItemFB;
	}

	public void setValItemFB(ValItemFB valItemFB) {
		this.valItemFB = valItemFB;
	}

	public ValNegocNumeracFormA getValNegocNumeracFormA() {
		return valNegocNumeracFormA;
	}

	public void setValNegocNumeracFormA(ValNegocNumeracFormA valNegocNumeracFormA) {
		this.valNegocNumeracFormA = valNegocNumeracFormA;
	}

	public PackageTD getPackageTD() {
		return packageTD;
	}

	public void setPackageTD(PackageTD packageTD) {
		this.packageTD = packageTD;
	}

	public ValRegprec getValRegprec() {
		return valRegprec;
	}

	public void setValRegprec(ValRegprec valRegprec) {
		this.valRegprec = valRegprec;
	}*/

}