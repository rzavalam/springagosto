package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ValidadorAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;


/**
 * 
 * @author lalberti
 * 
 */
public class ValidadorTextilAbstract extends ValidadorAbstract{

  //private static Map<String,String> errors          = new HashMap<String, String>();
  //private static List<String> unComSet = new ArrayList<String>();
  protected static final String COD_SUBGRUPO_FIBRA  = "02";
  protected static final String COD_SUBGRUPO_HILADO = "03";
  protected static final String COD_SUBGRUPO_TELA   = "04";
  protected static final String COD_SUBGRUPO_PRENDA = "05";
  protected static final String COD_SUBGRUPO_OTROS  = "06";
  protected static final String COD_ASOC_PARTIDAS   = "015";
  protected static final String COD_ZZZ             = "1";  

  private int sumaPorcentajes;


  public ValidadorTextilAbstract() {
    super();
    // TODO Auto-generated constructor stub
    this.sumaPorcentajes = 0;
  }

  @Override
  public List<ErrorDescrMinima> ejecutarValidaciones(ModelAbstract objeto, Declaracion dua) throws Exception
  {
    // TODO Auto-generated method stub
    return null;
  }
  

  public List<ErrorDescrMinima> validarFOBVsPesoObs(ModelAbstract object,
                                                    Declaracion dua){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    TextilAbstract textil = (TextilAbstract) object;
    DatoItem item         = obtenerItem(object, dua);
    String partida        = item.getNumpartnandi().toString().substring(0, 4);
    String datoAValidar   = textil.getRelacionFobUnitarioPesoNeto().getValtipdescri();
    //rtineo mejoras, se consulta en sub grupo y almacena en variableIngreso
    Map<String,Object> variablesIngreso = object.getMapCatalogos();
    Boolean esObligatorio = estaEnSubGrupoCatalogo("555", partida, variablesIngreso);
    if( esObligatorio ){
      if(SunatStringUtils.isEmpty(datoAValidar)){
        lst.add(obtenerError("31299", textil.getRelacionFobUnitarioPesoNeto()));
      }else{
        try{
          Float valor = Float.parseFloat(datoAValidar);
          if(valor <= 0 ){
            lst.add(obtenerError("31473",textil.getRelacionFobUnitarioPesoNeto()));
          }
        }catch(NumberFormatException e){
          lst.add(obtenerError("31473",textil.getRelacionFobUnitarioPesoNeto()));
        }
      }
    }
    return lst;
  }

  public List<ErrorDescrMinima> validarUnidadComercial(ModelAbstract object, DatoItem item, List<String> unComSet,String codError)
  {
    List<ErrorDescrMinima> lst       = new ArrayList<ErrorDescrMinima>();
    String datoAValidar              = item.getCodunidcomer();
    Object[] demasArgumentosMSJError = new Object[] {
                                                     object.getNumsecprove(),
                                                     object.getNumsecfact(),
                                                     object.getNumsecitem(),
                                                     "CODUNIDCOMER-UNIDAD COMERCIAL",datoAValidar};
    if (!unComSet.contains(datoAValidar))
    {
      ErrorDescrMinima err = obtenerError(codError,
                                          ErrorDescrMinima.tipoHEAD.HEAD_SIN_DESCR_MINIMA,demasArgumentosMSJError);
      lst.add(err);
    }
    return lst;
  }

  public List<ErrorDescrMinima> validarDuplicidad(ModelAbstract object,
                                                  List<DatoDescrMinima> lstComponentes,
                                                  String codError)
  {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Map<String,DatoDescrMinima> comp = new HashMap<String,DatoDescrMinima>();
    String result = "";
    for(DatoDescrMinima obj:lstComponentes){
      if(obj.getValtipdescri().trim().length()>0){
        String key = obj.getCodtipvalor()+"-"+obj.getValtipdescri().trim().toUpperCase();
        if(!comp.containsKey(key))
          comp.put(key, obj);
        else
          result +="<"+obj.getCodtipdescr()+"> <"+obj.getValtipdescri()+">, ";
      }
    }
    if(result.length()>1){
      Object[] demasArgumentosMSJError = new Object[] {result};
      ErrorDescrMinima err = obtenerError(codError,
                                          ErrorDescrMinima.tipoHEAD.SIN_HEAD,demasArgumentosMSJError);
      lst.add(err);
    }
    return lst;
  }

  public List<ErrorDescrMinima> validarNombreComercial(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarMarcaComercial(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  public List<ErrorDescrMinima> validarModelo(ModelAbstract object){
    return new ArrayList<ErrorDescrMinima>();
  }

  /*
  public static Map<String, String> getErrors() {
    return errors;
  }

  public static void setErrors(Map<String, String> errors) {
    ValidadorTextilAbstract.errors = errors;
  }
  */
/*
  public static List<String> getUnComSet() {
    return unComSet;
  }

  public static void setUnComSet(List<String> unComSet) {
    ValidadorTextilAbstract.unComSet = unComSet;
  }
*/
  public int getSumaPorcentajes() {
    return sumaPorcentajes;
  }

  public void setSumaPorcentajes(int sumaPorcentajes) {
    this.sumaPorcentajes = sumaPorcentajes;
  }
}
