/*
 * Clase que define el servicio de validaciones de Certificado de Origen
 */
package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoValidaService;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;

/**
 * The Class ValAutocer.
 * Clase que define el servicio de validaciones de Certificado de Origen
 */
public class ValAutocerServiceImpl extends ValDuaAbstract implements ValAutocer{
	//private FabricaDeServicios fabricaDeServicios;
	/**
	 * @param String codidcertorigen
	 * @return Map<String, String>
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @deprecated No se encuentra en mapeo DUA vs XML
	 * @param codidcertorigen String
	 * @return Map, El mapa de errores de validaci�n
	 */
	public Map<String, String> codidcertorigen(String codidcertorigen){
		return !SunatStringUtils.isEmptyTrim(codidcertorigen)?new HashMap<String,String>():getDUAError("30069","Error codidcertorigen"+codidcertorigen);
	}

	/**
	 * Valida el Tipo de certificado de origen.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipoCO String. Tipo de certificado de origen.
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> codtipoCO(String codtipoCO){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("1H", codtipoCO))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("1H", codtipoCO));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			//return getDUAError("30070","Error catalogo codtipoCO");
		    return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30070");
	}

	/**
	 * Valida el Tipo de emisor del certificado de origen.<br>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codtipoemisorCO String. Tipo de emisor del certificado de origen.
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> codtipoemisorCO(String codtipoemisorCO){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("1I", codtipoemisorCO))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("1I", codtipoemisorCO));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			//return getDUAError("30071","Error catalogo codtipoemisorCO");
			return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30071");
		
	}

	/**
	 * Valida el Nombre del emisor del certificado de origen.
	 * Valida que el par&aacute;metro siempre tenga un valor.<p>
	 * Esta validacion solo devuleve el mapa vacio.
	 * 
	 * @param nomemisorCO String. Nombre del emisor del certificado de origen.
	 * @return El mapa de errores de validaci�n
	 */

	public Map<String, String> nomemisorCO(String nomemisorCO){
		return new HashMap<String,String>();
	}

	public Map<String, String> nomemisorCO(String nomemisorCO, String numserie, String codTipoCO, String codError){
		//return !SunatStringUtils.isEmptyTrim(nomemisorCO)?new HashMap<String,String>():catalogoHelper.getErrorMap(codError, new String[] {numserie, codTipoCO});
                 return !SunatStringUtils.isEmptyTrim(nomemisorCO)?new HashMap<String,String>():((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codError, new String[] {numserie, codTipoCO});
	}

	/**
	 * Valida el N�mero o identificaci�n del documento de certificado.<br>
	 * Valida que el par&aacute;metro siempre tenga un valor.
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param numdocumento String. N�mero o identificaci�n del documento.
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> numdocumento(String numdocumento){
		return !SunatStringUtils.isEmptyTrim(numdocumento)?new HashMap<String,String>():getDUAError("30073","Error numdocumento"+numdocumento);
	}

	
	/**
	 * Valida que el el N�mero o identificaci�n del documento de certificado, tenga un valor
	 * @param numdocumento
	 * @param numserie
	 * @return
	 */
	public Map<String, String> numdocumento (String numdocumento, String numserie, String codTipoCO){
		if (SunatStringUtils.isEmptyTrim(numdocumento)){
			//return catalogoHelper.getErrorMap("30687", new String[] {numserie, codTipoCO});
                          return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30687", new String[] {numserie, codTipoCO});
		}
		return new HashMap<String, String>();		
	}
	
	
	/**
	 * Valida que la fecha de emision sea valida.<br>
	 * 
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param fecemision Date
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> fecemision(Date fecemision){
		return fecemision!=null?new HashMap<String,String>():getDUAError("30074","Error fecemision:"+fecemision);
	}

	/**
	 * Valida que la fecha de emision sea valida
	 * @param fecemision
	 * @param numserie
	 * @return
	 */
	public Map<String, String> fecemision (Date fecemision, String numserie, String codTipoCO){
		//amancilla PAS20155E220200035 if (SunatDateUtils.getIntegerFromDate(fecemision)== 0){
		if (SunatDateUtils.getIntegerFromDate(fecemision)== 0 || SunatDateUtils.isDefaultDate(fecemision)){
			//return catalogoHelper.getErrorMap("30689", new String[] {numserie,codTipoCO});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30689", new String[] {numserie, codTipoCO}); 
		}
		return new HashMap<String, String>();		
	}
	
	
	/**
	 * Compara la fecha de emision del CO con respecto a una fecha de referencia y adicionalmente si �sta supera el plazo en a�os con respecto a la fecha de emisi�n 
	 * @param fecemision
	 * @param fecreferencia
	 * @param anios
	 * @param numserie
	 * @return
	 */
	public Map<String, String> valfecemisionPlazoAnios (Date fecemision, Date fecreferencia, Integer anios, String numserie, String codErr1, String codErr2){
		if (!SunatDateUtils.esFecha1MayorIgualQueFecha2(fecreferencia, fecemision, "COMPARA_SOLO_FECHA")){			
			//return catalogoHelper.getErrorMap(codErr1, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr1, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		Date fechaCalculada = SunatDateUtils.addYear(fecemision, anios);
		if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecreferencia, fechaCalculada, "COMPARA_SOLO_FECHA")){
			//return catalogoHelper.getErrorMap(codErr2, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"), SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), anios.toString().concat(" A�O(S)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr2, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"), SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), anios.toString().concat(" A�O(S)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		return new HashMap<String, String>();
	}
	
	/**
	 * Compara la fecha de emision del CO con respecto a una fecha de referencia y adicionalmente si �sta supera el plazo en d�as con respecto a la fecha de emisi�n
	 * @param fecemision
	 * @param fecreferencia
	 * @param dias
	 * @param numserie
	 * @return
	 */
	public Map<String, String> valfecemisionPlazoDias (Date fecemision, Date fecreferencia, Integer dias, String numserie, String codErr1, String codErr2){
		if (!SunatDateUtils.esFecha1MayorIgualQueFecha2(fecreferencia, fecemision, "COMPARA_SOLO_FECHA")){
			//return catalogoHelper.getErrorMap(codErr1, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr1, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		Date fechaCalculada = SunatDateUtils.addDay(fecemision, dias);
		if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecreferencia, fechaCalculada, "COMPARA_SOLO_FECHA")){
			//return catalogoHelper.getErrorMap(codErr2, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), dias.toString().concat(" DIA(S)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr2, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), dias.toString().concat(" DIA(S)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		return new HashMap<String, String>();
	}
	

	/**
	 * Compara la fecha de emision del CO con respecto a una fecha de referencia y adicionalmente si �sta supera el plazo en meses con respecto a la fecha de emisi�n
	 * @param fecemision
	 * @param fecreferencia
	 * @param meses
	 * @param numserie
	 * @return
	 */
	public Map<String, String> valfecemisionPlazoMeses (Date fecemision, Date fecreferencia, Integer meses, String numserie, String codErr1, String codErr2){
		if (!SunatDateUtils.esFecha1MayorIgualQueFecha2(fecreferencia, fecemision, "COMPARA_SOLO_FECHA")){
			//return catalogoHelper.getErrorMap(codErr1, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr1, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		Date fechaCalculada = SunatDateUtils.addMonth(fecemision, meses);
		if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecreferencia, fechaCalculada, "COMPARA_SOLO_FECHA")){
			//return catalogoHelper.getErrorMap(codErr2, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), meses.toString().concat(" MES(ES)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr2, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), meses.toString().concat(" MES(ES)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		return new HashMap<String, String>();
	}
	
	/*
	 * lalberti: TLC Corea SIGESI, se separa la validacion de la fecha de mayor a la fecha referencia
	 * */
	public Map<String, String> valfecemisionPlazoMesesSinRestriccion (Date fecemision, Date fecreferencia, Integer meses, String numserie, String codErr){
		Date fechaCalculada = SunatDateUtils.addMonth(fecemision, meses);
		if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecreferencia, fechaCalculada, "COMPARA_SOLO_FECHA")){
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), meses.toString().concat(" MES(ES)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		return new HashMap<String, String>();
	}
	
	public Map<String, String> valfecemisionPlazoDiasSinRestriccion (Date fecemision, Date fecreferencia, Integer dias, String numserie, String codErr){
		Date fechaCalculada = SunatDateUtils.addDay(fecemision, dias);
		if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecreferencia, fechaCalculada, "COMPARA_SOLO_FECHA")){
            return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), dias.toString().concat(" DIA(S)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		return new HashMap<String, String>();
	}
	
	public Map<String, String> valfecemisionPlazoAniosSinRestriccion (Date fecemision, Date fecreferencia, Integer anios, String numserie, String codErr){
		Date fechaCalculada = SunatDateUtils.addYear(fecemision, anios);
		if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecreferencia, fechaCalculada, "COMPARA_SOLO_FECHA")){
	                    return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError(codErr, new String[] {numserie,SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy"), SunatDateUtils.getFormatDate(fechaCalculada, "dd/MM/yyyy"), anios.toString().concat(" A�O(S)"), SunatDateUtils.getFormatDate(fecreferencia, "dd/MM/yyyy")});
		}
		return new HashMap<String, String>();
	}
	//fin TLC Corea
	

	
	/**
	 * Valida la Fecha de inicio del embarque.<br>
	 * Valida la fecha de inicio de embarque para el certificado de origen<p>
	 * Esta validacion solo devuleve el mapa vacio.
	 * @param feciniembarque Date. Fecha de inicio del embarque.
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> feciniembarque(Date feciniembarque){
		return feciniembarque!=null?new HashMap<String,String>():getDUAError("30075","Error feciniembarque:"+feciniembarque);
	}


	/**
	 * Valida que el par&aacute;metro fecfinembarque sea mayor a cero . <p>
	 * Esta validacion solo devuleve el mapa vacio
	 * @param fecfinembarque Date. Fecha de fin del embarque.
	 * @param feciniembarque Date. Fecha de inicio del embarque.
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> fecfinembarque(Date fecfinembarque){
		return fecfinembarque!=null?new HashMap<String,String>():getDUAError("30811","Error fecfinembarque:"+fecfinembarque);
	}

	
	/**
	 * Valida que el par&aacute;metro fecfinembarque sea mayor a cero y que sea mayor a feciniembarque. <p>
	 * Esta validacion solo devuleve el mapa vacio
	 * @param fecfinembarque Date. Fecha de fin del embarque.
	 * @param feciniembarque Date. Fecha de inicio del embarque.
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> fecfinembarque(Date fecfinembarque, Date feciniembarque){
		return (fecfinembarque!=null && SunatDateUtils.compareDate(fecfinembarque,feciniembarque) >= 0)?new HashMap<String,String>():getDUAError("30076","Error feciniembarque:"+feciniembarque);
	}
	
	/**
	 * Valida tanto la fecha de inicio como de fin de embarque
	 * @param fecfinembarque
	 * @param feciniembarque
	 * @return
	 */
	public List<Map<String,String>>  fecinifinembarque(Date fecfinembarque, Date feciniembarque, String numserie){
		List<Map<String,String>> listErr =  new ArrayList<Map<String,String>>();
		//Fecha de inicio embargque debe enviarse
		//rtineo optimizacion, se comento metodo de validacion, por llamadas rest innecesarias
		//TLC Corea: En las diligencias se adiciona validacion q la fecha sea valida
		if (feciniembarque == null || SunatDateUtils.isDefaultDate(feciniembarque)) {
			//listErr.add(catalogoHelper.getErrorMap("30075", new String[] {numserie}));			
                        listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30075", new String[] {numserie}));
		}
		//Fecha de fin de  embargque debe enviarse
		//rtineo optimizacion, se comento metodo de validacion, por llamadas rest innecesarias
		//TLC Corea: En las diligencias se adiciona validacion q la fecha sea valida
		if (fecfinembarque == null || SunatDateUtils.isDefaultDate(fecfinembarque)) {
			//listErr.add(catalogoHelper.getErrorMap("30811", new String[] {numserie}));
                        listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30811", new String[] {numserie}));
			return listErr;
		}
		//Fecha de inicio y fin de  embargque deben ser consistentes
		//rtineo optimizacion, se comento metodo de validacion, por llamadas rest innecesarias
		//logica copiada del metodo Map<String, String> fecfinembarque(Date fecfinembarque, Date feciniembarque)
		if (!(fecfinembarque!=null && SunatDateUtils.compareDate(fecfinembarque,feciniembarque) >= 0)) {
			//listErr.add(catalogoHelper.getErrorMap("30076", new String[] {numserie}));
                        listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30076", new String[] {numserie})); 
			return listErr;
		}
		return listErr;
	}
	
	/**
     * Se encarga de validar que la fehca de inicio y fin de embarque sean correctos (distintos de null y fecha default 01/01/0001).
     * Proyecto msnade236_1
     * @author glazaror
     * @param fechaFinEmbarque fecha de fin de embarque
     * @param fechaInicioEmbarque fecha de inicio de embarque
     * @param numeroSerie numero de la serie evaluada
     * @return errores de validacion
     **/
	@Override
	public List<Map<String,String>> validarFechaInicioFinEmbarque(Date fechaFinEmbarque, Date fechaInicioEmbarque, String numeroSerie){
		List<Map<String,String>> listErr =  new ArrayList<Map<String,String>>();
		if (fechaInicioEmbarque == null || SunatDateUtils.isDefaultDate(fechaInicioEmbarque)) {	
			listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30075", new String[] {numeroSerie}));
		}
		if (fechaInicioEmbarque == null || SunatDateUtils.isDefaultDate(fechaFinEmbarque)) {
			listErr.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30811", new String[] {numeroSerie}));
			return listErr;
		}
		return listErr;
	}
	
	/**
	 * Valida que la fecha de embarque est� comprendida entre la fecha de inicio embarque y la fecha de fin de embarque
	 * @param fecfinembarque
	 * @param feciniembarque
	 * @param fecembarque
	 * @return
	 */
	public Map<String, String> fecembarque(Date feciniembarque, Date fecfinembarque, Date fecembarque, String numserie){
		if (!SunatDateUtils.esFecha1MayorIgualQueFecha2(fecembarque, feciniembarque, SunatDateUtils.COMPARA_SOLO_FECHA)){
			//return catalogoHelper.getErrorMap("30699", new String[] {SunatDateUtils.getFormatDate(feciniembarque, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecembarque, "dd/MM/yyyy"), SunatDateUtils.getFormatDate(fecfinembarque, "dd/MM/yyyy")});
			//return catalogoHelper.getErrorMap("30699", new String[] {numserie, SunatDateUtils.getFormatDate(fecembarque, "dd/MM/yyyy"), "FECHA DE INICIO DE EMBARQUE<".concat(SunatDateUtils.getFormatDate(feciniembarque, "dd/MM/yyyy")).concat(">")});
//cambio gg
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30699", new String[] {numserie, SunatDateUtils.getFormatDate(fecembarque, "dd/MM/yyyy"), "FECHA DE INICIO DE EMBARQUE(".concat(SunatDateUtils.getFormatDate(feciniembarque, "dd/MM/yyyy")).concat(")")});//actualizado a parentesis
		}
		if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecembarque, fecfinembarque, SunatDateUtils.COMPARA_SOLO_FECHA)){
			//return catalogoHelper.getErrorMap("30699", new String[] {numserie, SunatDateUtils.getFormatDate(fecembarque, "dd/MM/yyyy"), "FECHA FIN DE EMBARQUE<".concat(SunatDateUtils.getFormatDate(fecfinembarque, "dd/MM/yyyy")).concat(">")});
//cambio gg
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30699", new String[] {numserie, SunatDateUtils.getFormatDate(fecembarque, "dd/MM/yyyy"), "FECHA FIN DE EMBARQUE(".concat(SunatDateUtils.getFormatDate(fecfinembarque, "dd/MM/yyyy")).concat(")")});//actualizado a parentesis
		}		
		return new HashMap<String,String>();
	}

	/**
	 * Valida que la fecha de Fecha de Emisi�n de la Declaraci�n sea menor o igual a la fecha de embarque, 
	 * @param fecembarque
	 * @param fecreferencia
	 * @return
	 */
	public Map<String, String> fecembarque(Date fecembarque, Date fecemision, String numserie){
		if (!SunatDateUtils.esFecha1MenorIgualQueFecha2(fecemision, fecembarque, SunatDateUtils.COMPARA_SOLO_FECHA)){
			//return catalogoHelper.getErrorMap("30709", new String[] {numserie, SunatDateUtils.getFormatDate(fecembarque, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30709", new String[] {numserie, SunatDateUtils.getFormatDate(fecembarque, "dd/MM/yyyy"),SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
		}
		return new HashMap<String,String>();
	}


	/**
	 * Valida la descripcion de la mercancia<p>
	 * Esta validacion solo devuleve el mapa vacio.
	 * @deprecated No realiza validacion
	 * @param desmercancia String
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> desmercancia(String desmercancia){
//		return !SunatStringUtils.isEmptyTrim(desmercancia)?new HashMap<String,String>():getDUAError("30077","Error desmercancia:"+desmercancia);
		return new HashMap<String,String>();
	}


	/**
	 * Valida se envie el nombre del productor
	 * @param nomproduc
	 * @return
	 */
	public Map<String, String> nomproduc(String nomproduc, String codTipoCO, String numserie ){
		if (!SunatStringUtils.isEmptyTrim(nomproduc)){
			return new HashMap<String,String>();
		} else{
			//return catalogoHelper.getErrorMap("30704", new String[] {numserie, codTipoCO});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30704", new String[] {numserie, codTipoCO});
		}  
	}

	
	/**
	 * Valida el codigo del criterio del certificado de origen.<p>
	 * Si es v&aacute;lido se devuelve new HashMap<String,String>(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codcriterioCO String. Codigo del criterio del certificado de origen.
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> codcriterioCO(String codcriterioCO){
		//if (FormatoAServiceImpl.getInstance().isValidCatalogo("1J", codcriterioCO))
		boolean validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat("1J", codcriterioCO));
		if (validaCatalogo)
			return new HashMap<String,String>();
		else
			//return getDUAError("30078","Error catalogo codcriterioCO");
			return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30078");
		
	}

	/**
	 * Valida que el Indicador de transito o de transbordo siempre tenga un valor.
	 * Esta validacion solo devuleve el mapa vacio.
	 * @deprecated No realiza validacion
	 * @param indtrans String
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> indtrans(String indtrans){
//		return !SunatStringUtils.isEmptyTrim(indtrans)?new HashMap<String,String>():getDUAError("30079","Error indtrans:"+indtrans);
		return new HashMap<String,String>();
	}

	/**
	 * Valida condicionalmente que el codigo del funcionario del certificado de origen tenga un valor numerico.
	 * Si es v&aacute;lido se devuelve new HashMap(), en caso contrario se devuelve un mapa indicando el error.
	 * 
	 * @param codffco String, codigo del funcionario del certificado de origen
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String, String> codffco(String codffco){
		//TDDI Regla 57
		if (!SunatStringUtils.isEmptyTrim(codffco)){
			if (!SunatStringUtils.isNumeric(codffco)){
				return getDUAError("01125","NUME_FFCO - ENVIADO");
				}else
					return new HashMap<String,String>();
		}else{
			return new HashMap<String,String>();
		}
		//return !SunatStringUtils.isEmptyTrim(codffco)?new HashMap<String,String>():getDUAError("30080","NUME_FFCO - ENVIADO"+codffco);
	}

	
	/**
	 * Se obliga a que se envie el el N�mero de registro del funcionario autorizado a emitir el CO 
	 * @param codffco
	 * @return
	 */
	public Map<String, String> valcodffco(String numserie, String codffco){
		//return !SunatStringUtils.isEmptyTrim(codffco)?new HashMap<String,String>():catalogoHelper.getErrorMap("30705", new String[] {numserie});
                return !SunatStringUtils.isEmptyTrim(codffco)?new HashMap<String,String>():((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30705", new String[] {numserie});
	}
	
	
	/**
	 * Valida se envie el n�mero de autorizaci�n de exportador autorizado
	 * @param numautoexp
	 * @return
	 */
	public Map<String, String> numautoexp (String numautoexp,  String numserie){
		//return !SunatStringUtils.isEmptyTrim(numautoexp)?new HashMap<String,String>():catalogoHelper.getErrorMap("30710", new String[] {numserie});
                return !SunatStringUtils.isEmptyTrim(numautoexp)?new HashMap<String,String>():((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30710", new String[] {numserie});
	}
	

	/**
	 * V�lida el n�mero de secuencia del certificado de origen.
	 * 
	 * @param numsecCO Integer, numero de secuencia del certificado de origen
	 * @return El mapa de errores de validaci�n
	 */
	public Map<String,String> numsecCO(Integer numsecCO){
		return numsecCO!=null?(numsecCO>0?new HashMap<String,String>():getDUAError("30283","numsecCO menor o igual a cero")):getDUAError("30283","numsecCO null");
	}
	
	/**
	 * Valida que el n�mero del CO no contemple caracteres de Sin Numero (SN) 
	 * @param numdocumento
	 * @param numserie
	 * @return
	 */
	public Map<String, String> numdocumentoSN (String numdocumento, String numserie){
		String[] arraySN = new String []{"SN", "S/N", "S N", "S\\N"};
		if (SunatStringUtils.isEmptyTrim(numdocumento)){
			//return catalogoHelper.getErrorMap("30687", new String[] {numserie});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30687", new String[] {numserie}); 
		}
		if (SunatStringUtils.include(numdocumento.toUpperCase(), arraySN)){
			//return catalogoHelper.getErrorMap("30690", new String[] {numserie,numdocumento});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30690", new String[] {numserie,numdocumento});
		}
		return new HashMap<String, String>();		
	}
	
	/**
	 * Valida que se envie el numero de documento, fecha de emision, codigo de funcionario a la vez
	 * @param numdocumento
	 * @param fecemision
	 * @param codffco
	 * @param numserie
	 * @return
	 */
	public Map<String, String> combinarNumCOFechaFuncionario(String numdocumento, Date fecemision, String codffco, String numserie, String codTipoCO){
		if (this.numdocumento(numdocumento, numserie, codTipoCO).isEmpty() && 
			this.fecemision(fecemision, numserie, codTipoCO).isEmpty() && 
			this.valcodffco(numserie, codffco).isEmpty()){
			return new HashMap<String, String>();	
		}
		//return catalogoHelper.getErrorMap("30691", new String[] {numserie,codffco, numdocumento, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
                return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30691", new String[] {numserie,codffco, numdocumento, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
	}

	/**
	 * Valida que no se envie el numero de documento, fecha de emision, codigo de funcionario a la vez
	 * @param numdocumento
	 * @param fecemision
	 * @param codffco
	 * @param numserie
	 * @return
	 */
	public Map<String, String> sinCombinarNumCOFechaFuncionario(String numdocumento, Date fecemision, String codffco, String numserie, String codTipoCO){
		if (!this.numdocumento(numdocumento, numserie, codTipoCO).isEmpty() && 
			!this.fecemision(fecemision, numserie, codTipoCO).isEmpty() && 
			!this.valcodffco(numserie,codffco).isEmpty()){
			return new HashMap<String, String>();	
		}
		//return catalogoHelper.getErrorMap("30692", new String[] {numserie, codffco, numdocumento, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
                return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30692", new String[] {numserie, codffco, numdocumento, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")});
	}
	

	/**
	 * Valida la obligatoriedad de numdocumento, fecemision, codtipoemisorCO, nomemisorCO, no debe enviar dichos datos
	 * @param numdocumento
	 * @param fecemision
	 * @param codtipoemisorCO
	 * @param nomemisorCO
	 * @param numserie
	 * @return
	 */
	public List<Map<String, String>> sinEnviarNumCOEmisorFecha(String numdocumento, Date fecemision, String codtipoemisorCO, String nomemisorCO, String numserie, String codTipoCO){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if(numdocumento!=null && !SunatStringUtils.isEmptyTrim(numdocumento)){
			//listError.add(catalogoHelper.getErrorMap("30712", new String[] {numserie,codTipoCO, numdocumento}));
                        listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30712", new String[] {numserie,codTipoCO, numdocumento}));
		}
		//amancilla inicio PAS20165E220200126
		//if(!(SunatDateUtils.getIntegerFromDate(fecemision)== 0)){


		if(!(SunatDateUtils.getIntegerFromDate(fecemision)== 0) && !SunatDateUtils.isDefaultDate(fecemision)){
			//listError.add(catalogoHelper.getErrorMap("30713", new String[] {numserie,codTipoCO, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")}));
                        listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30713", new String[] {numserie,codTipoCO, SunatDateUtils.getFormatDate(fecemision, "dd/MM/yyyy")}));
		}
		if(codtipoemisorCO!=null && !SunatStringUtils.isEmptyTrim(codtipoemisorCO)){
			//listError.add(catalogoHelper.getErrorMap("30714", new String[] {numserie,codTipoCO, codtipoemisorCO}));
                        listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30714", new String[] {numserie,codTipoCO, codtipoemisorCO}));
		}
		if(nomemisorCO!=null && !SunatStringUtils.isEmptyTrim(nomemisorCO)){
			//listError.add(catalogoHelper.getErrorMap("30715", new String[] {numserie,codTipoCO, nomemisorCO}));
                        listError.add(((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30715", new String[] {numserie,codTipoCO, nomemisorCO}));
		}
		return listError;		
	}

	//rtineo optimizacion, sobrecargamos el metodo codmoneda
	/**
	 * valida el codigo de moneda
	 * @param codmoneda
	 * @param numserie
	 * @param variablesIngreso
	 * @return
	 */
	@Override
	public Map<String, String> codmoneda (String codmoneda, String numserie, Map<String,Object> variablesIngreso){
		Map<String, String> result = new HashMap<String, String>();
		boolean validaCatalogo = false;		
		if (variablesIngreso == null) {
			//ejecutamos de manera no optima...
			validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_TIPO_MONEDA_ISO, codmoneda));
		} else {
			//entonces ejecutamos de manera mejorada
			//de lo revisado en una dua a lo mucho pueden existir 2 monedas distintas por lo tanto asi se procese una dua con miles de series solo se deberian ejecutar 2 consultas via rest
			Map<String, Boolean> monedasValidas = (Map<String, Boolean>) variablesIngreso.get("monedasValidas");
			if (monedasValidas == null) {
				monedasValidas = new HashMap<String, Boolean>();
				variablesIngreso.put("monedasValidas", monedasValidas);
			}
			if (monedasValidas.containsKey(codmoneda)) {
				//entonces la moneda ya fue validada anteriormente
				validaCatalogo = monedasValidas.get(codmoneda);
			} else {
				//entonces ejecutamos consulta via rest
				validaCatalogo = CollectionUtils.isEmpty(((CatalogoValidaService)fabricaDeServicios.getService("Ayuda.catalogoValidaService")).validarElementoCat(ConstantesTipoCatalogo.CATALOGO_TIPO_MONEDA_ISO, codmoneda));
				//salvamos el resultado para que no se consulte nuevamente
				monedasValidas.put(codmoneda, validaCatalogo);
			}
		}
//		if (codmoneda == null || !catalogoHelper.isValid(codmoneda, ConstantesTipoCatalogo.CATALOGO_TIPO_MONEDA_ISO)){

        //amancilla inicio PAS20165E220200126
		if (StringUtils.isBlank(codmoneda) || !validaCatalogo){
		//amancilla fin PAS20165E220200126

			//return catalogoHelper.getErrorMap("30720", new String[] {numserie,SunatStringUtils.toNotNull(codmoneda)});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30720", new String[] {numserie,SunatStringUtils.toNotNull(codmoneda)});
		}
		return result;
	}
	
	/**
	 * Valida la moneda de factura este en el cat�logo correspondiente 
	 * @param codmoneda
	 * @return
	 */
	@Deprecated
	public Map<String, String> codmoneda (String codmoneda, String numserie){
		return codmoneda(codmoneda, numserie, null);
	}
	
	/**
	 * Valida que el monto de la factura sea mayor a cero
	 * @param mtofobmon
	 * @return
	 */
	public Map<String, String> mtofobmon (BigDecimal mtofobmon, String numserie){
		Map<String, String> result = new HashMap<String, String>();
		if( !SunatNumberUtils.isGreaterThanZero(mtofobmon)){
			//return catalogoHelper.getErrorMap("30721", new String[] {numserie, SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(mtofobmon))});
                        return ((CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).getError("30721", new String[] {numserie, SunatStringUtils.toNotNull(SunatStringUtils.toStringObj(mtofobmon))});
		}
		return result;
	}
	
	//rtineo optimizacion
	/**
	 * Valida la obligatoriedad de los datos de la factura
	 * @param codmoneda
	 * @param mtofobmon
	 * @param numserie
	 * @param variablesIngreso
	 * @return
	 */
	@Override
	public List<Map<String, String>> valDatosFactura(String codmoneda, BigDecimal mtofobmon, String numserie, Map<String,Object> variablesIngreso){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();		
		listError.add(codmoneda(codmoneda, numserie, variablesIngreso));
		listError.add(mtofobmon(mtofobmon, numserie));	
		return listError;
	}
	//rtineo fin optimizacion
	
	/**
	 * Valida la obligatoriedad de los datos de la factura
	 * @param codmoneda
	 * @param mtofobmon
	 * @return
	 */
	@Deprecated
	public List<Map<String, String>> valDatosFactura(String codmoneda, BigDecimal mtofobmon, String numserie){
		return valDatosFactura(codmoneda, mtofobmon, numserie, null);
	}
	
	//rtineo optimizacion, sobrecargamos los metodos
	/**
	 * Si envia los datos de factura se debe validar 
	 * @param codmoneda
	 * @param mtofobmon
	 * @return
	 */
	@Override
	public List<Map<String, String>> valDatosFacturaCondicional(String codmoneda, BigDecimal mtofobmon, String numserie,Map<String,Object> variablesIngreso){
		List<Map<String, String>> listError = new ArrayList<Map<String, String>>();
		if (!SunatStringUtils.isEmptyTrim(codmoneda)){
			listError.add(codmoneda(codmoneda, numserie,variablesIngreso));
		}
		if (SunatNumberUtils.isGreaterThanZero(mtofobmon)){
			listError.add(mtofobmon(mtofobmon, numserie));	
		}		
		return listError;
	}
	//rtineo fin optimizacion
	
	/**
	 * Si envia los datos de factura se debe validar 
	 * @param codmoneda
	 * @param mtofobmon
	 * @return
	 */
	@Deprecated
	public List<Map<String, String>> valDatosFacturaCondicional(String codmoneda, BigDecimal mtofobmon, String numserie){
		return valDatosFacturaCondicional(codmoneda, mtofobmon, numserie,null);
	}

	/*
	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}

	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}*/
}
