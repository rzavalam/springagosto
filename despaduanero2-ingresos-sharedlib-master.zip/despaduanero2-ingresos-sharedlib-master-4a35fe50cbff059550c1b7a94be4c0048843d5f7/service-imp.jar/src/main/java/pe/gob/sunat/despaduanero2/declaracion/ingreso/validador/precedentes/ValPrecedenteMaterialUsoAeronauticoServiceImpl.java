package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.precedentes;

import org.springframework.util.CollectionUtils;
import pe.gob.sunat.despaduanero.despacho.entrada.me.model.Redma;
import pe.gob.sunat.despaduanero.despacho.entrada.me.model.RedmaSerie;
import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.Constantes;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatoa.ValDuaAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DetDeclaraDAO;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.framework.spring.util.lang.Cadena;
import pe.gob.sunat.sigad.ingreso.service.ConsultaMaterialUsoAeronauticoService;
import pe.gob.sunat.controladuanero2.ingreso.especial.service.MaterialDeUsoAeronauticoService;

import pe.gob.sunat.despaduanero2.diligencia.ingreso.model.ObjectResponseUtil;
import pe.gob.sunat.despaduanero2.declaracion.service.DeclaracionService;
import java.text.SimpleDateFormat;
import java.util.*;

//import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo;

public class ValPrecedenteMaterialUsoAeronauticoServiceImpl extends ValDuaAbstract implements ValPrecedenteMaterialUsoAeronauticoService {




	public List<Map<String, String>> validaMaterialUsoAeronautico(Declaracion declaracion, String puntoDeLlegada, List<DatoSerie> listSeries, String codAduanaOrden, Date fechaReferencia){
		List<Map<String,String>> listMapError=new ArrayList<Map<String,String>>();
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		String codiAduan="";
		String anoPrese= "";
		String codaduanaConex= codAduanaOrden;
		String numeCorre="";
		String numeSeriePrece="";
		listMapError.add(validarPuntoLlegada(puntoDeLlegada));
		ConsultaMaterialUsoAeronauticoService consultaMaterialUsoAeronauticoService = (ConsultaMaterialUsoAeronauticoService)fabricaDeServicios.getService("sigad.ingreso.ConsultaMuaService");
		for(DatoSerie serie:listSeries) {
			if (!CollectionUtils.isEmpty(serie.getListRegPrecedencia())) {
				for (DatoRegPrecedencia regPrec : serie.getListRegPrecedencia()) {
					String strPrecedencia = regPrec.getCodaduapre() + '-' + SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4) + '-' + ConstantesDataCatalogo.REG_DMUA + '-' + regPrec.getNumdeclpre();
					Redma redma = new Redma();
					redma.setAduana(regPrec.getCodaduapre());
					redma.setAno(SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4));
					anoPrese = SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4);
					codiAduan = regPrec.getCodaduapre() != null ? regPrec.getCodaduapre().toString() : "0";
					redma.setNumero(regPrec.getNumdeclpre());
					numeCorre = SunatStringUtils.lpad(regPrec.getNumdeclpre(), 6, '0') != null ? SunatStringUtils.lpad(regPrec.getNumdeclpre(), 6, '0') : "0";
					Integer numSerie = regPrec.getNumserpre();
					numeSeriePrece = String.valueOf(numSerie);
					boolean isMuaSda = true;
					boolean isMuaSigad = true;
					Map<String, Object> params = new HashMap();
					params.put("codigoAduana", regPrec.getCodaduapre());
					params.put("annoPresentacion", SunatStringUtils.substring(regPrec.getAnndeclpre(), 0, 4));
					params.put("codigoRegimen", regPrec.getCodregipre());
					params.put("numeroDeclaracion", regPrec.getNumdeclpre() != null ? regPrec.getNumdeclpre().toString() : "0");
					CabDeclaraDAO cabdeclaraDAO = (CabDeclaraDAO) fabricaDeServicios.getService("cabDeclaraDAO");
					DUA duaBD = cabdeclaraDAO.findDUAByMap(params);
					if (duaBD != null) {
						String msjError = "";
						String numCorredoc = "";
						numCorredoc = duaBD.getNumcorredoc().toString();
						msjError = validarlevanteAutorizado(numCorredoc);//E4
						if (!SunatStringUtils.isEmptyTrim(msjError)) {
							listMapError.add(catalogoAyudaService.getError("37220", new String[]{serie.getNumserie().toString(),strPrecedencia}));
						}
						String estado = duaBD.getCodEstdua() == null ? "00" : duaBD.getCodEstdua();
						if ("08".equals(estado)) {//dam legajada
							listMapError.add(catalogoAyudaService.getError("37221", new String[]{serie.getNumserie().toString(),strPrecedencia}));
						}
						Integer anoMua = duaBD.getAnnpresen();
						String codAduanaMua = duaBD.getCodaduanaorden().toString();
						String numMua = duaBD.getNumdocumento().toString();
						Integer numserieMua=numSerie;

						DatoSerie serieMua = null;
						DetDeclaraDAO detDeclaraDAO = (DetDeclaraDAO) fabricaDeServicios.getService("detDeclaraDAO");
						Map<String, Object> parametrosBusqueda = new HashMap<String, Object>();
						parametrosBusqueda.put("numcorredoc", numCorredoc);
						parametrosBusqueda.put("numsecserie", numSerie);
						List<DatoSerie> result = detDeclaraDAO.findSerieByMap(parametrosBusqueda);
						if (!result.isEmpty()) {
							//serieMua = result.get(0);
							String numeroSerieMua="";
							for(DatoSerie serieMuaPre:result){
								numeroSerieMua= serieMuaPre.getNumserie().toString();
                            }
							if (!numeSeriePrece.equals(numeroSerieMua != null ? numeroSerieMua : "")) {
								listMapError.add(catalogoAyudaService.getError("37229", new String[]{serie.getNumserie().toString(), numeroSerieMua, strPrecedencia}));
							}else{
								if (!codAduanaOrden.equals(codAduanaMua)) {
									listMapError.add(catalogoAyudaService.getError("37209", new String[]{serie.getNumserie().toString(), codAduanaMua, "MATERIAL DE USO AERONAUTICO", strPrecedencia, codAduanaOrden}));
								}
							}
						}else{
                            listMapError.add(catalogoAyudaService.getError("37229", new String[]{serie.getNumserie().toString(), numeSeriePrece, strPrecedencia,}));
                        }


					}else{
						 isMuaSda = false;
					}

					if (!codAduanaOrden.equals(codiAduan)) {
						listMapError.add(catalogoAyudaService.getError("37209", new String[]{serie.getNumserie().toString(), codiAduan, "DE LA DECLARACION DE MATERIAL DE USO AERONAUTICO", strPrecedencia, codAduanaOrden}));
						break;
					}

					/*especiales*/

					/*MaterialDeUsoAeronauticoService materialDeUsoAeronauticoService = fabricaDeServicios.getService("especial.materialDeUsoAeronautico");
					Map<String, Object> mapEspeciales = new HashMap<String, Object>();

					mapEspeciales.put("numeroCorrelativo",new Long(dua.getNumcorredoc().toString()));
					mapEspeciales=materialDeUsoAeronauticoService.obtenerDeclaracionIngresoPrece(mapEspeciales);
					if(mapEspeciales.size()==0){
						isMuaSda=false;
					}else{
						isMuaSda=true;
						String anoMua = mapEspeciales.get("annorden");
						String codAduanaMua = mapEspeciales.get("annorden");
						String numMua = mapEspeciales.get("annorden");
					}*/
					/*fin */
					Redma redma2 = consultaMaterialUsoAeronauticoService.consultarMaterialUsoAeronautico(anoPrese, codiAduan, numeCorre, codaduanaConex, null);
					if (redma2 == null) {
						isMuaSigad=false;
					} else if (redma2.getAduana() != null) {
//						listMapError.add(buscarPrecedenteSDA(Redma));
						isMuaSigad=true;
						String anoMua = redma2.getAno().toString();
						String codAduanaMua = redma2.getAduana().toString();
						String numMua = redma2.getNumero().toString();
						RedmaSerie redma3 = consultaMaterialUsoAeronauticoService.consultarMaterialUsoAeronauticoSerie(anoMua, codAduanaMua, numMua, codaduanaConex, numeSeriePrece);
						if (!numeSeriePrece.equals(redma3 != null ? redma3.getNserie().trim() : "")) {
							listMapError.add(catalogoAyudaService.getError("37229", new String[]{serie.getNumserie().toString(), numeSeriePrece, strPrecedencia,}));
						} else {
							if (!codAduanaOrden.equals(redma2.getAduana())) {
								listMapError.add(catalogoAyudaService.getError("37209", new String[]{serie.getNumserie().toString(), redma2.getAduana(), "MATERIAL DE USO AERONAUTICO", strPrecedencia, codAduanaOrden}));
							}
							if (!(redma2.getFechaVista() > 0 && redma2.getCestado().equals("H0"))) {
								listMapError.add(catalogoAyudaService.getError("37220", new String[]{serie.getNumserie().toString(), strPrecedencia}));
							}
							if (redma2.getCestado().equals("G0")) {
								listMapError.add(catalogoAyudaService.getError("37221", new String[]{serie.getNumserie().toString(), strPrecedencia}));
							}
						}
					} else {
						listMapError.add(catalogoAyudaService.getError("37226", new String[]{serie.getNumserie().toString(), "MATERIAL DE USO AERONAUTICO", strPrecedencia,}));
					}

					if ( !isMuaSigad && !isMuaSda) {
						//Serie [x]: <TipoDocumento> N� AAA-XXXX-RR-YYYYYY no existe
						listMapError.add(catalogoAyudaService.getError("37226", new String[]{serie.getNumserie().toString(), strPrecedencia}));
					}

				}
			}
		}
		return listMapError;
	}


	private String validarlevanteAutorizado(String numCorredocDam) {
		String msjError = "";
		Boolean  levanteAutorizado = false;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NUM_CORREDOC",numCorredocDam);
		Map<String, Object> declaracion = ((CabDeclaraDAO)fabricaDeServicios.getService("cabDeclaraDAO")).findDuaByNumCorreDoc(params);

		if(!CollectionUtils.isEmpty(declaracion)){
			String fechaAutorizacionLevante = new SimpleDateFormat(Constantes.FORMAT_ddMMyyyy).format(declaracion.get("FEC_AUTLEVANTE"));
			if(!fechaAutorizacionLevante.equals(Constantes.DEFAULT_FECHA_BD)){
				levanteAutorizado= true;
			}
		}

		if (levanteAutorizado == false) {
			msjError = "Declaraci�n de Material de Uso Aeron�utico precedente no cuenta con Levante autorizado";
		}

		return msjError;
	}


	private Map<String, String> validarPuntoLlegada (String puntoLlegada){
		CatalogoAyudaService catalogoAyudaService = (CatalogoAyudaService)fabricaDeServicios.getService("Ayuda.catalogoAyudaService");
		Map<String,String> mapError=new HashMap<String,String>();
		String codigoPuntoLLegadaMercancia =puntoLlegada!=null?puntoLlegada.toString():"";
		if (!SunatStringUtils.isEqualTo(codigoPuntoLLegadaMercancia,  ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DMUA)){
			//El punto de llegada para precedente Acta de incautaci�n debe ser Control de Equipajes Internacional
			mapError = catalogoAyudaService.getError("37224",new String[] {codigoPuntoLLegadaMercancia, ConstantesDataCatalogo.CODIGO_PUNTO_LLEGADA_DMUA});
		}
		return mapError;
	}
}
