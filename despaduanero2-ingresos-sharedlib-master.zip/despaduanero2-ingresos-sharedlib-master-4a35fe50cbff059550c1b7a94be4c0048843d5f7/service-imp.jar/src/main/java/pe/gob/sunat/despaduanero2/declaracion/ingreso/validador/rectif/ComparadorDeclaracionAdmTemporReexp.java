package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.rectif;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.bean.DatoRectificacionBean;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.util.Constants;
import pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/*branch 2011-009 hosorio inicio*/
public class ComparadorDeclaracionAdmTemporReexp  extends ComparadorDeclaracion {

	public ComparadorDeclaracionAdmTemporReexp(FabricaDeServicios fabricaDeServicios){
		super(fabricaDeServicios);
	}
	
	public void comparacion(Object rectificado, Object anterior) throws Exception {
		/*branch 2011-009 hosorio fin*/
		Declaracion declaraRecti=(Declaracion)rectificado;
		Declaracion declaraOld=(Declaracion)anterior;
    
		DUA duaRectificado = declaraRecti.getDua();
		DUA duaActual = declaraOld.getDua();
		comparacionCabDeclara(duaRectificado, duaActual);
		comparacionDatoDeclarante(duaRectificado.getDeclarante(), duaActual.getDeclarante());
		comparacionAgente(declaraRecti.getDua(), declaraOld.getDua());
		comparacionDatoPuntoLLegada(duaRectificado.getNumruclugarecep(), duaActual.getNumruclugarecep());
		comparacionManifiesto(duaRectificado.getManifiesto(), duaActual.getManifiesto());
		comparacionListaObservacion(duaRectificado.getListObservaciones(), duaActual.getListObservaciones());
		// 1. Excluir de la verificaci�n de indicadores el segmento indicadores
		// r2bz Si deberian de anularse, PAS20110001128   solo de los transmitios por el usuario
		//if(! "I".equals(tipoComparacion ) ) // Los indicadores no se anulan
			comparacionListaIndicadorDUA(duaRectificado.getListIndicadores(), duaActual.getListIndicadores());
		comparacionListaDocAsociado(duaRectificado.getListOtrosDocSoporte(), duaActual.getListOtrosDocSoporte());
		//r2bz para certificados de origen, dado que se graba tambien en doc_autasoc
		if("I".equals(tipoComparacion ) ) 
			comparacionListaDocAsociado(duaRectificado.getListOtrosDocSoporteCO(),duaActual.getListOtrosDocSoporteCO());

		
		comparacionListaDocAutorizante(duaRectificado.getListDocAutorizantes(), duaActual.getListDocAutorizantes());
		comparacionListaFormaFacturas(duaRectificado.getListFacturaRef(), duaActual.getListFacturaRef());
		comparacionCertiOrigen(duaRectificado.getDatoCertificadoOrigen(), duaActual.getDatoCertificadoOrigen());
		comparacionImpoConsumo(duaRectificado.getPagoElectronico(), duaActual.getPagoElectronico());
		comparacionGralTransito(duaRectificado, duaActual);
		comparacionGralAdmTem(duaRectificado, duaActual);

		// similar a numeracion si no tiene ruc anexo no se toma encuenta
		if (!isEmpty(duaActual.getRucAnexoUbicacion()) || !isEmpty(duaRectificado.getRucAnexoUbicacion()))
			comparacionFinUbicacion(duaRectificado, duaActual);

		comparacionRucAnexoUbicacion(duaRectificado.getRucAnexoUbicacion(), duaActual.getRucAnexoUbicacion());
		comparacionListaseries(duaRectificado.getListSeries(), duaActual.getListSeries());
		comparacionDAV(declaraRecti, declaraOld);
	}

	
	public void comparacionFinUbicacion(DUA duaRecti, DUA duaOld) throws Exception {
		String codTabla = ConstantesDataCatalogo.TABLA_FINYUBICACION;
		Map<String, Object> clave = obtenerClave(codTabla, duaRecti);
		String tipoCambio = evaluarCambioRegistro(duaRecti.getRucAnexoUbicacion(), duaOld.getRucAnexoUbicacion());
		Map<String, DatoRectificacionBean> datos = new HashMap<String, DatoRectificacionBean>();

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "desfinalidad"), datos, "DES_FINALIDAD" );

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "codlocalanexo"), datos, "COD_LOCALANEXO");

		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "rucAnexoUbicacion.numeroDocumentoIdentidad"), datos, "NUM_DOC_LOCMERC");
		
		agregarCambioAtributo(comparaAtributo(duaRecti, duaOld, "rucAnexoUbicacion.tipoDocumentoIdentidad.codDatacat"), datos, "COD_TIPDOCLOCMERC");
		
		// agregarCambioRegistro(codTabla, clave, datos, Constants.IND_REGISTRO_RECTIFICADO);

		agregarCambioRegistro(codTabla, clave, datos, tipoCambio);		
	}
}
