package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

 
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ModelFactory;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DescrPosicion;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima.TipoAtributo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.TipoDescrMinima.findBy;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.CabDeclaraDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.DescrPosicionDAO;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.FormBItemDescriDAO;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
//import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * La Class TransformadorDescrMinimaServiceImpl.
 *
 * @author amancillaa
 * @version 1.0
 * @since 16/12/2013
 */
public class TransformadorDescrMinimaServiceImpl extends IngresoAbstractServiceImpl implements TransformadorDescrMinimaService
{

  //private DescrPosicionDAO descrPosicionDAO;

  //@Autowired
  //private FabricaDeServicios fabricaDeServicios;

  private String registrosActivos ="0";
  protected final Log log = LogFactory.getLog(getClass());

  @Override
  public ModelAbstract
  poblarObjetoDescrMinima(Enum tipoDescrMinima, DatoItem item, Declaracion dua){

    return poblarObjetoDescrMinima(tipoDescrMinima,item,dua,"");
  }
    
  @Override
  public ModelAbstract
  poblarObjetoDescrMinima(Enum tipoDescrMinima, DatoItem item, Declaracion dua, String tipoDiligencia)
  {

    List<DatoDescrMinima> lstDatosXML = item.getListDecrMinima();

    ModelAbstract objeto = null;

    if (!CollectionUtils.isEmpty(lstDatosXML))
    {

      objeto = ModelFactory.crearObjetoDescrMinima(tipoDescrMinima);
      String codMercancia = "";

      codMercancia = objeto.getTipoDescrMnima();

      // este es un punto debil
      if (objeto == null)
      {
        String abreviatura = lstDatosXML.get(0).getCodtipdescr().substring(0, 4);
        objeto = ModelFactory.crearObjetoDescrMinima(TipoDescrMinima.get(abreviatura, findBy.abreviado));

      }

      Long numcorredoc = 0L;
      Integer numsecprove = 0;
      Integer numsecfact = 0;
      Integer numsecitem = 0;
      // se comenta para no Bug 16326 el tipo se setea en el contrucctor no por
      // fuera
      // objeto.setTipoDescrMnima(codMercancia);
      // para que quede grabado en la BD item
      item.setCodtipdescrmin(codMercancia);

      //rtineo mejoras, rectificacion electronica
      Map<String,Object> mapCatalogos=null;
      //rtineo mejoras
      try
      {
        for (DAV dav : dua.getListDAVs())
        {
          for (DatoFactura factura : dav.getListFacturas())
          {
            for (DatoItem item1 : factura.getListItems())
            {
              if (item.getNumsecitem().toString().equals(item1.getNumsecitem().toString()))
              {

                numcorredoc = dav.getNumcorredoc();
                numsecprove = dav.getNumsecuprov();
                numsecfact = factura.getNumsecfactu();
                numsecitem = item.getNumsecitem();
                //rtineo mejoras, rectificacion electronica
                mapCatalogos = item.getMapCatalogos();

                for (DatoDescrMinima descrMinima : item.getListDecrMinima())
                {
                  descrMinima.setNumcorredoc(dav.getNumcorredoc());
                  descrMinima.setNumsecprove(dav.getNumsecuprov());
                  descrMinima.setNumsecfact(factura.getNumsecfactu());
                  descrMinima.setNumsecitem(item.getNumsecitem());
                  descrMinima.setCodmercancia(codMercancia);
                }
              }
            }
          }

        }

        objeto.setNumcorredoc(numcorredoc);
        objeto.setNumsecprove(numsecprove);
        objeto.setNumsecfact(numsecfact);
        objeto.setNumsecitem(numsecitem);
      //rtineo mejoras, rectificacion electronica
        objeto.setMapCatalogos(mapCatalogos);

        /*AQUI DETERMINAR POR POSICIONES (BD) QUE MODELO Y VALIDADOR CORRESPONDE PAS20165E220200137*/

        // amancilla
        List<DescrPosicion> lstEstructuraVigente = obtenerEstructuraVigente(codMercancia,tipoDiligencia,dua,mapCatalogos);

        objeto.poblar(lstDatosXML, lstEstructuraVigente);
        Date fechaIniVigenciaValidador = dua.getDua().getFecdeclaracion()!=null?dua.getDua().getFecdeclaracion():SunatDateUtils.getCurrentDate();
        objeto.setFechaIniVigenciaValidador(fechaIniVigenciaValidador);
        //determinarVersionValidadorEjecutar(objeto,dua);

/*   amancilla se comenta ya no va     if(!SunatStringUtils.isEmpty(tipoDiligencia)){
        	objeto.poblar(lstDatosXML, lstEstructuraVigente);AREY-MIN
	        //objeto.poblar(lstDatosXML, obtenerCatalogoPosicionesParaJavascript(codMercancia));

        }else{
        	//rtineo mejoras, se llama al metodo sobrecargado
        	objeto.poblar(lstDatosXML,lstEstructuraVigente);AREY-MIN
        	//objeto.poblar(lstDatosXML, obtenerCatalogoPosiciones(codMercancia, mapCatalogos));
        }*/

      }
      catch (Exception e)
      {
         log.error("poblarObjetoDescrMinima objeto:"+objeto.toString(),e);
        // devolvemos objeto null
        objeto = null;
      }
    }

    return objeto;
  }



  /**
   * Obtener estructuctura vigente PAS20165E220200137
   *
   * @param codMercancia
   * @param tipoDiligencia
   * @param declaracion
   * @param mapCatalogos
     * @return
     */
  private List<DescrPosicion> obtenerEstructuraVigente(String codMercancia, String tipoDiligencia, Declaracion declaracion, Map mapCatalogos) {

    List<DescrPosicion> lstEstructuraVigente = new ArrayList<DescrPosicion>();
    Date fechaVigenciaEstructura = declaracion.getDua().getFecdeclaracion()!=null?declaracion.getDua().getFecdeclaracion():SunatDateUtils.getCurrentDate();

    if(!SunatStringUtils.isEmpty(tipoDiligencia)){
      lstEstructuraVigente = obtenerCatalogoPosicionesParaJavascript(codMercancia, fechaVigenciaEstructura);
    }else{
      lstEstructuraVigente = obtenerCatalogoPosiciones(codMercancia, mapCatalogos, fechaVigenciaEstructura);
    }

    return lstEstructuraVigente;
  }


  @Override
  public ModelAbstract poblarObjetoDescrMinima(String numCorreDoc, String numSecItem)
  {
    // TODO Auto-generated method stub
    return null;
  }


  @Override
  public ModelAbstract obtenerObjetoDescrMinima(long numCorreDoc, int numSecItem,String tipoDescrMinima, String tipoDiligencia) {

    /*Inicio Descripciones minimas - AREY*/
    FormBItemDescriDAO formbItemdescriDAO= fabricaDeServicios.getService("formBItemDescriDAO");

    Map<String, Object> mapBusqueda=  new HashMap<String, Object>();
    mapBusqueda.put("numcorredoc", new Long(numCorreDoc));
    mapBusqueda.put("numsecitem", new Integer(numSecItem));
    mapBusqueda.put("codmercancia",tipoDescrMinima);
    
    /*adicionado por PAS20165E220200137*/
    if(SunatStringUtils.isEmpty(tipoDiligencia)){
        mapBusqueda.put("inddel", registrosActivos);
    }
    /*PAS20165E220200137*/
    
    List<pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima> lstDatosXML = formbItemdescriDAO.getDescrMinimaByMap(mapBusqueda);

    ModelAbstract objeto =null;

    if (!CollectionUtils.isEmpty(lstDatosXML))
    {
      objeto = ModelFactory.crearObjetoDescrMinima(TipoDescrMinima.get(tipoDescrMinima));
      String codMercancia = "";
      String abreviatura = "";
      abreviatura = lstDatosXML.get(0).getCodtipdescr().substring(0, 4);
      codMercancia = TipoDescrMinima.getAtributo(TipoAtributo.codigoNEW, abreviatura, findBy.abreviado);

      if (objeto == null)
      {
        objeto = ModelFactory.crearObjetoDescrMinima(TipoDescrMinima.get(abreviatura, findBy.abreviado));
      }

      /*AREY-MIN PAS20165E220200137*/
      CabDeclaraDAO declaran = fabricaDeServicios.getService("cabDeclaraDAO");
      Map<String, Object> paramsDua= new HashMap<String, Object>();
	  paramsDua.put("numeroCorrelativo",numCorreDoc);
	  DUA datosDua=declaran.selectByNumCorredoc(paramsDua);
	  Date fechaVigencia = datosDua.getFecdeclaracion(); 
      /*DEBE TOMAR LA FECHA DE LA DAM... BUSCAR DE BD*/
      
      try{

        if(!SunatStringUtils.isEmpty(tipoDiligencia)){
        	//objeto.poblarObj(lstDatosXML, obtenerCatalogoPosicionesParaJavascript(codMercancia));
        	objeto.poblarObj(lstDatosXML, obtenerCatalogoPosicionesParaJavascript(codMercancia,fechaVigencia));/*AREY-MIN*/
        }else{
          //SEIDA
        	//objeto.poblarObj(lstDatosXML, obtenerCatalogoPosiciones(codMercancia));
        	objeto.poblarObj(lstDatosXML, obtenerCatalogoPosiciones(codMercancia, fechaVigencia));/*AREY-MIN*/
        }


      }catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    /*Fin Descripciones minimas*/
    return objeto;

  }


  public ModelAbstract obtenerObjetoDescrMinima(long numCorreDoc, int numSecItem,String tipoDescrMinima){

    return obtenerObjetoDescrMinima(numCorreDoc,numSecItem,tipoDescrMinima,"");
  }

    @Override
  public ModelAbstract obtenerDescrMinima(String numCorreDoc, String numSecItem, Enum<?> tipo)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public ModelAbstract obtenerDescrMinima(DatoItem item, Enum<?> tipo)
  {
    // TODO Auto-generated method stub
    return null;
  }

  /********************* METODOS PRIVADOS ************ **********/
  //rtineo mejoras, se sobrecarga el metodo
  private List<DescrPosicion> obtenerCatalogoPosiciones(String codMercancia,  Date fechaVigencia){
	  //return obtenerCatalogoPosiciones(codMercancia, null);
	  return obtenerCatalogoPosiciones(codMercancia, null, fechaVigencia);/*AREY -MIN*/
  }

  //AREY-MIN adicionado fechaVigencia
  private List<DescrPosicion> obtenerCatalogoPosiciones(String codMercancia, Map<String,Object> variablesIngreso, Date fechaVigencia) {	  
	  DescrPosicionDAO  descrPosicionDAO = fabricaDeServicios.getService("descrPosicionDAO");
	  //rtineo mejoras, variablesIngreso
	  List<DescrPosicion> lstPosiciones = null;
	  if(variablesIngreso != null){
		  //viene de setupDescripcionesMinimas carga por DAM, se mando la fecha. AREY
		  lstPosiciones = ((Map<String,List<DescrPosicion>>)variablesIngreso.get("mapDescrPosicionesCache")).get(codMercancia);
	  }else{
		  Map<String, Object> filtro = new HashMap<String, Object>();
		  filtro.put("COD_MERCANCIA", codMercancia);
		  filtro.put("FEC_VIGENCIA", fechaVigencia);/*AREY-MIN*/
		  lstPosiciones = descrPosicionDAO.lstByCondition(filtro);
	}
    return lstPosiciones;
  }

 	  
  private List<DescrPosicion> obtenerCatalogoPosicionesParaJavascript(String codMercancia, Date fechaVigencia) {
	  DescrPosicionDAO  descrPosicionDAO = fabricaDeServicios.getService("descrPosicionDAO");
      Map<String, Object> filtro = new HashMap<String, Object>();
      filtro.put("COD_MERCANCIA", codMercancia);
      filtro.put("FEC_VIGENCIA", fechaVigencia); /*AREY-MIN*/
      List<DescrPosicion> lstPosiciones = descrPosicionDAO.lstDescrPosicionForJavascript(filtro);
    return lstPosiciones;
  }


  /********************* SET PARA INYECCION ************ **********/
/*

  public void setDescrPosicionDAO(DescrPosicionDAO descrPosicionDAO)
  {
    this.descrPosicionDAO = descrPosicionDAO;
  }
*/
}