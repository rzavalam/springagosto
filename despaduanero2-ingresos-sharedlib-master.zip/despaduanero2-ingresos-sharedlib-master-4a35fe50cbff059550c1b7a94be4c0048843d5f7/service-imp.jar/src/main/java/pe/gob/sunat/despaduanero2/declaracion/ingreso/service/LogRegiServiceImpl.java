package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.dao.DataAccessException;

//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service.RectificacionServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.dao.LogRegiDAO;
import pe.gob.sunat.despaduanero2.util.SunatNumberUtils;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * <p>Title: LogRegServiceImpl</p>
 * <p>Description: Registro de logs en la tabla LOGREGI para Afectaci�n y desafectaci�n de PAGARANTIA </p>
 * <p>Copyright: Copyright (c) 2013</p>
 * <p>Company: SUNAT - INSI</p>
 * @author Daniel Zavaleta
 * @version 1.0 
 */
public class LogRegiServiceImpl extends IngresoAbstractServiceImpl implements LogRegiService{

	//protected final Log log = LogFactory.getLog(getClass());
	//private LogRegiDAO logRegiDAO;
	//private HotSwappableTargetSource swapperDatasource;
	//private FabricaDeServicios fabricaDeServicios;
	/*
   public LogRegiDAO getLogRegiDAO() {
		return logRegiDAO;
	}


	public void setLogRegiDAO(LogRegiDAO logRegiDAO) {
		this.logRegiDAO = logRegiDAO;
	}


	public HotSwappableTargetSource getSwapperDatasource() {
		return swapperDatasource;
	}


	public void setSwapperDatasource(HotSwappableTargetSource swapperDatasource) {
		this.swapperDatasource = swapperDatasource;
	}


	public FabricaDeServicios getFabricaDeServicios() {
		return fabricaDeServicios;
	}


	public void setFabricaDeServicios(FabricaDeServicios fabricaDeServicios) {
		this.fabricaDeServicios = fabricaDeServicios;
	}

*/
/**
    * M�todo que graba log de errore del llamado a las afectaciones de garantias
    * @param Map
    * @return List
    * @throws ServiceException   
    */
	@Override
	public boolean grabaLogGarantia(Map<String, Object> params,Map<String, Object> variables) throws ServiceException {
		if (log.isDebugEnabled())
		      log.debug("Inicio - grabaLogGarantia()");

		    Map MapaLogRegi = new HashMap();
		    String codiAduan=(String)params.get("codi_aduan");
			String funcion=(String)params.get("funcion");
			String respuesta=(String) params.get("respuesta");
			String modulo=(String) params.get("modulo");
		
		  	String cadena="";		  	
		  	if(funcion.equals("PAGARANTIA.fnafectactacte"))cadena=this.getStrfnafectactacte(params, variables);
		  	if(funcion.equals("PAGARANTIA.fnDesafectactacte"))cadena=this.getStrfnDesafectactacte(params, variables);
		  	params.put("desc_error",cadena);// Ingresamos el error
		  	// Resultado Error   
		  
	     if (respuesta.length()>0){
			 if(respuesta.substring(0, 1).equals("1")){
		    	 Integer resultadoInt=(Integer)SunatNumberUtils.toInteger(respuesta.substring(0, 1));
		    	 params.put("nume_error",resultadoInt);
			 }
	    	 
	    	 if(respuesta.substring(0, 1).equals("0")){
			    	respuesta=respuesta.substring(2);
			    	String [] errores= respuesta.split("\\|");
			    	String err="";
			    	if(errores.length>0){
			    		err=errores[0];
			    	}
			    	Integer resultadoInt=(Integer)SunatNumberUtils.toInteger(err);
			       params.put("nume_error",resultadoInt);
			 }
	     };
	    
		//try {
	     	HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.dx.prp1");			
			Object resultSwap = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.dxdaen."+codiAduan));
			LogRegiDAO logRegiDAO = fabricaDeServicios.getService("recaudacion2.logRegiDAO");
			MapaLogRegi =logRegiDAO.getLogRegi(params);
			if(MapaLogRegi==null)
			{
				logRegiDAO.insertaLogRegi(params);	
			}
			else
			{
				String desc_errorBD=(String)MapaLogRegi.get("desc_error");
				params.put("desc_error",desc_errorBD+"; "+cadena);// Ingresamos el error
				logRegiDAO.actualizaLogRegi(params);
			}
			
			swapperDatasource.swap(resultSwap);
 		
		/*}catch (DataAccessException e) { 
		      log.error("error", e);
		      throw new ServiceException(this, new StringBuilder("ERROR - ")
		        .append("Ha ocurrido un error de acceso a BD tabla LogRegi. ")
		        .append("Por favor intente nuevamente").toString());
		      throw e;
	    } catch (Throwable e) {
		      log.error("error", e);
		      throw new ServiceException(this, new StringBuilder("ERROR - ")
		        .append("Ha ocurrido un error en el servicio que registra registraLogReg. ")
		        .append("Por favor intente nuevamente").toString());
		      throw e;
	    } finally {
	    }*/
	    if (log.isDebugEnabled())
	      log.debug("Fin - grabaLogGarantia()");
	    
	    return true; 
	}
	
	/**
	    * M�todo de grabado generico en LOG regi, si es la misma fecha de trasmicion con la grabada en la BD concatena caso contrario inserta
	    * @param Map
	    * @return List
	    * @throws ServiceException   
	    */
		
		public boolean grabaLogGeneral(Map<String, Object> params) throws ServiceException {
			if (log.isDebugEnabled())
			      log.debug("Inicio - grabaLogGeneral() en LOGREGI");

			    Map MapaLogRegi = new HashMap();
			    String codiAduan=(String)params.get("codi_aduan");
		    
			try {
				HotSwappableTargetSource swapperDatasource = (HotSwappableTargetSource)fabricaDeServicios.getService("declaracion.swapper.dx.prp1");	
				Object resultSwap = swapperDatasource.swap(fabricaDeServicios.getService("despaduanero2.dxdaen."+codiAduan));
				if(params!=null) {
					LogRegiDAO logRegiDAO = fabricaDeServicios.getService("recaudacion2.logRegiDAO");
					logRegiDAO.insertaLogRegi(params);	
				}
				swapperDatasource.swap(resultSwap);
	 		
			}catch (DataAccessException e) { 
			      log.error("error", e);
			      throw new ServiceException(this, new StringBuilder("ERROR - ")
			        .append("Ha ocurrido un error de acceso a BD tabla LogRegi [grabaLogGeneral]. ")
			        .append("Por favor intente nuevamente").toString());
		    } catch (Throwable e) {
			      log.error("error", e);
			      throw new ServiceException(this, new StringBuilder("ERROR - ")
			        .append("Ha ocurrido un error en el servicio que registra registraLogReg [grabaLogGeneral]. ")
			        .append("Por favor intente nuevamente").toString());
		    } finally {
		    }
		    if (log.isDebugEnabled())
		      log.debug("Fin - grabaLogGeneral() en LOGREGI");
		    
		    return true; 
		}
	
	public String getStrfnafectactacte(Map<String, Object> params,Map<String, Object> variables) {

		String codiAduan=(String)params.get("codi_aduan");
		String funcion=(String)params.get("funcion");
		String respuesta=(String) params.get("respuesta");
		String modulo=(String) params.get("modulo");
		
	    //Se actualizan ultimos parametros
		if (variables.get("nFECNUMERA")==null){
			variables.put("nFECNUMERA", 0);
	      }
	      if (variables.get("nFECRECTI")==null){
	    	  variables.put("nFECRECTI", 0);
	      }
	      if (variables.get("cTIPOLIQ")==null){
	    	  variables.put("cTIPOLIQ", " ");
	      }
	      //inicio gmontoya 26-08-2011
	      if(variables.get("cANO")!=null && variables.get("cANO").toString().length()>2){
	    	  variables.put("cANO",variables.get("cANO").toString().substring(2));
	      }
		
		  	BigDecimal varDecimal = BigDecimal.ZERO;
		  	String varString = "";
		  	Integer varInteger = 0;
            String parametros="";
	     
		  	varString=variables.get("cRUC")==null?"":(String)variables.get("cRUC");
		  	parametros=parametros+"('"+varString+"'";
		  	varString=variables.get("cADUANA")==null?"":(String)variables.get("cADUANA");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cANO")==null?"":(String)variables.get("cANO");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cREGIMEN")==null?"":(String)variables.get("cREGIMEN");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cNUMERO")==null?"":(String)variables.get("cNUMERO");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cNUMREF")==null?"":(String)variables.get("cNUMREF");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cCDA")==null?"":(String)variables.get("cCDA");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cRUCAGENTE")==null?"":(String)variables.get("cRUCAGENTE");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cORDEN")==null?"":(String)variables.get("cORDEN");
		  	parametros=parametros+",'"+varString+"'";
		  	varDecimal=variables.get("nMONTOA")==null?BigDecimal.ZERO:(BigDecimal) variables.get("nMONTOA");
		  	parametros=parametros+","+varDecimal+"";
		  	varString=variables.get("cMONEDAA")==null?"":(String)variables.get("cMONEDAA");
		  	parametros=parametros+",'"+varString+"'";
		  	varInteger=variables.get("nFECHA1")==null?0:(int)(Integer)variables.get("nFECHA1");
		  	parametros=parametros+","+varInteger+"";
		  	varString=variables.get("cMODULO")==null?"":(String)variables.get("cMODULO");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cTRANS")==null?"":(String)variables.get("cTRANS");
		  	parametros=parametros+",'"+varString+"'";
		  	varInteger=variables.get("nFECNUMERA")==null?0:(int)(Integer)variables.get("nFECNUMERA");
		  	parametros=parametros+","+varInteger+"";
		  	varInteger=variables.get("nFECRECTI")==null?0:(int)(Integer)variables.get("nFECRECTI");
		  	parametros=parametros+","+varInteger+"";
		  	varString=variables.get("cTIPOLIQ")==null?"":(String)variables.get("cTIPOLIQ");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cTIPOEXTIN")==null?"":(String)variables.get("cTIPOEXTIN");
		  	parametros=parametros+",'"+varString+"')";
		    //Armamos la cadena  
		  	String cadena=modulo+": "+funcion+parametros+"="+respuesta;
		  	return cadena; 
	}
	
	
	public String getStrfnDesafectactacte(Map<String, Object> params,Map<String, Object> variables) {

			String codiAduan=(String)params.get("codi_aduan");
			String funcion=(String)params.get("funcion");
			String respuesta=(String) params.get("respuesta");
			String modulo=(String) params.get("modulo");
		
		  	BigDecimal varDecimal = BigDecimal.ZERO;
		  	String varString = "";
		  	Integer varInteger2 = 0;//DZC
		  	BigDecimal varInteger = BigDecimal.ZERO;
            String parametros="";
	     
		  	varString=variables.get("cRUC")==null?"":(String)variables.get("cRUC");
		  	parametros=parametros+"('"+varString+"'";
		  	varString=variables.get("cTIPOEXTIN")==null?"":(String)variables.get("cTIPOEXTIN");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cADUANA")==null?"":(String)variables.get("cADUANA");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cANO")==null?"":(String)variables.get("cANO");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cREGIMEN")==null?"":(String)variables.get("cREGIMEN");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cNUMERO")==null?"":(String)variables.get("cNUMERO");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cCDA")==null?"":(String)variables.get("cCDA");
		  	parametros=parametros+",'"+varString+"'";
		  	varDecimal=variables.get("nMONTO")==null?BigDecimal.ZERO:(BigDecimal) variables.get("nMONTO");
		  	parametros=parametros+","+varDecimal+"";
		  	varString=variables.get("cMONEDA")==null?"":(String)variables.get("cMONEDA");
		  	parametros=parametros+",'"+varString+"'";
		  	varInteger=variables.get("nTIPOCAM")==null?BigDecimal.ZERO:(BigDecimal)variables.get("nTIPOCAM");
		  	parametros=parametros+","+varInteger+"";
		  	varInteger2=variables.get("nFECHA")==null?0:(int)(Integer)variables.get("nFECHA");
		  	parametros=parametros+","+varInteger2+"";
		  	varString=variables.get("cDOCUMENTO")==null?"":(String)variables.get("cDOCUMENTO");
		  	parametros=parametros+",'"+varString+"'";
		  	varString=variables.get("cTRANS")==null?"":(String)variables.get("cTRANS");
		  	parametros=parametros+",'"+varString+"')";		  	
			//Armamos la cadena  
		  	String cadena=modulo+": "+funcion+parametros+"="+respuesta;
		  	return cadena; 
	}


	
}
