package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.service;

import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_ENVIO_COMPLEMENTARIO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANSACCION_NUMERACION;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_ENVIO_COMPLEMENTARIO_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_ENVIO_COMPLEMENTARIO_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_ENVIO_COMPLEMENTARIO_IMPORTACION_DEFINITIVA;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_NUMERACION_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_NUMERACION_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_NUMERACION_DEPOSITO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_NUMERACION_IMPORTACION_DEFINITIVA;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_RECTIFICACION_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_RECTIFICACION_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_RECTIFICACION_DEPOSITO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_DEPOSITO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_URG_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_URG_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_URG_DEPOSITO;
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.TRANS_REGULARIZACION_URG_IMPORTACION_DEFINITIVA;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import pe.gob.sunat.despaduanero2.declaracion.ingreso.service.IngresoAbstractServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.OrquestaDespaAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServInstDetAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.anotaciones.ServicioAnnot;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.respuesta.GenRespuesta;
//import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.respuesta.GenRespuestaTxt;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.utils.ObtenerPantillas;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.SunatStringUtils;
import pe.gob.sunat.tecnologia.receptor.bean.EnvioArchivoBean;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioArchivoDAO;
import freemarker.template.Configuration;
import freemarker.template.TemplateException;
//import pe.gob.sunat.despaduanero2.declaracion.model.dao.TDColasCabDAO;

public class GeneraRespuestaServiceImpl extends IngresoAbstractServiceImpl implements GeneraRespuestaService{
	
	//private GenRespuesta genRespuesta;
	
//	private GenRespuestaTxt genRespuestaTxt;
	
	private String nomArchivo;
	
	private String pathTmp;

	//@Autowired
	//@Qualifier("declaracion.configuracionDeclaracion")
	//private ObtenerPantillas obtenerPantillas;
	
	//@Autowired
	//@Qualifier("declaracion.freemarkerTransactionResponseConfiguration")
	//private Configuration configuration; 
	
	//private EnvioArchivoDAO envioArchivoDAO;
	
//	private TDColasCabDAO tdcolasCabDAO;
	

	@ServicioAnnot(tipo="R",codServicio=3030,descServicio="Servicio de Respuesta")
	@ServInstDetAnnot(tipoRpta={1,1},
			nomAtr={"nroErroresNegocio","variablesIngreso"})
	@OrquestaDespaAnnot(codServInstancia=3030,numSecEjec=360,nomClase="pe.gob.sunat.tecnologia.receptor.model.Mensaje")
	public HashMap<String, String> validacionGeneraRespuestaEnvio(Integer nroErroresNegocio, Map<String, Object> variablesIngreso)
	{
		generaRespuestaEnvio(nroErroresNegocio, variablesIngreso);
		return new HashMap<String, String>();
	}
	public void generaRespuestaEnvio (Integer nroErroresNegocio, Map<String, Object> variablesIngreso) {
		/** NSR: No se lleg� a implementar el Envio alternativo, se comenta el codigo para eliminar dependencias no necesarias**/
//		Long numEnvio 			= (Long) variablesIngreso.get("numEnvio");
//		String lcNumEnvio = numEnvio.toString().trim();
//		if (lcNumEnvio.length()>=12) {
//			generaRespuestaTxt (nroErroresNegocio, variablesIngreso);
//		} else {
			generaRespuestaXML (nroErroresNegocio, variablesIngreso);
//		}
		
	}
	
	private void generaRespuestaXML (Integer nroErroresNegocio, Map<String, Object> variablesIngreso) {
		Integer annEnvio 		= (Integer) variablesIngreso.get("annEnvio");
		Long numEnvio 			= (Long) variablesIngreso.get("numEnvio");
		if (nroErroresNegocio>0) {
			return;
		}
		String resultadoXML = getXMLRespuestaAceptacionDeclaracion(variablesIngreso);
		if (!SunatStringUtils.isEmpty(resultadoXML)) {
			byte[] informacionArchivo = resultadoXML.getBytes();
			try {
				insertarEnvioArchivo("B", informacionArchivo, annEnvio, numEnvio);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}
	
	public String getXMLRespuestaAceptacionDeclaracion (Map<String, Object> variablesIngreso) {
		
		ObtenerPantillas obtenerPantillas = (ObtenerPantillas)fabricaDeServicios.getService("declaracion.configuracionDeclaracion");
		Configuration configuration = (Configuration)fabricaDeServicios.getService("declaracion.freemarkerTransactionResponseConfiguration");
		
		
		String codTransaccion = (String)variablesIngreso.get("codTransaccion");
		
		String resultadoXML = "";
		String templateName = "";
		if (codTransaccion.substring(2, 4).equals(TRANSACCION_NUMERACION) || codTransaccion.substring(2, 4).equals(TRANSACCION_ENVIO_COMPLEMENTARIO)) {
			templateName = obtenerPantillas.getNombrePlantillaRespuestaNumeracion();
		} else {
			templateName = obtenerPantillas.getNombrePlantillaRespuestaRectiRegul();
		}
		
		if (templateName==null) {
			return "";
		}
		Map<String, Object> mapRespuesta =  obtenerRespuestaAceptacionDeclaracion(variablesIngreso);
		if (mapRespuesta.get("encontro").equals("NO")) {
			return "";
		}
		
		try {
			resultadoXML = FreeMarkerTemplateUtils.processTemplateIntoString(configuration.getTemplate(templateName), mapRespuesta);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TemplateException e) {
			e.printStackTrace();
		}
		return resultadoXML;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> obtenerRespuestaAceptacionDeclaracion (Map<String, Object> variablesIngreso) {
		GenRespuesta genRespuesta = (GenRespuesta)fabricaDeServicios.getService("genRespuestaDef");
		Map<String, Object> mapRespuesta =  new HashMap();
		Declaracion declaracion = (Declaracion)variablesIngreso .get("declaracion");
		String codTransaccion = (String)variablesIngreso.get("codTransaccion");
		Long numCorreSol = (Long)variablesIngreso.get("numCorreDocSolicitud");
		if (codTransaccion.equals(TRANS_NUMERACION_IMPORTACION_DEFINITIVA)) {
			mapRespuesta = genRespuesta.obtenerDatosPrincipalesNumeracion(variablesIngreso);
			mapRespuesta = genRespuesta.respuesta1001(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_NUMERACION_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO)) {
			mapRespuesta = genRespuesta.obtenerDatosPrincipalesNumeracion(variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2001(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_NUMERACION_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO)) {
			mapRespuesta = genRespuesta.obtenerDatosPrincipalesNumeracion(variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2101(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_NUMERACION_DEPOSITO)) {
			mapRespuesta = genRespuesta.obtenerDatosPrincipalesNumeracion(variablesIngreso);
			mapRespuesta = genRespuesta.respuesta7001(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_ENVIO_COMPLEMENTARIO_IMPORTACION_DEFINITIVA)) {
			mapRespuesta = genRespuesta.obtenerDatosPrincipalesNumeracion(variablesIngreso);
			mapRespuesta = genRespuesta.respuesta1002(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_ENVIO_COMPLEMENTARIO_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO)) {
			mapRespuesta = genRespuesta.obtenerDatosPrincipalesNumeracion(variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2002(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_ENVIO_COMPLEMENTARIO_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO)) {
			mapRespuesta = genRespuesta.obtenerDatosPrincipalesNumeracion(variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2102(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_RECTIFICACION_IMPORTACION_DEFINITIVA)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			if (!mapRespuesta.get("encontro").equals("NO")) {
				mapRespuesta = genRespuesta.respuesta1003(mapRespuesta);
			}
		} else if (codTransaccion.equals(TRANS_RECTIFICACION_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2003(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_RECTIFICACION_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2103(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_RECTIFICACION_DEPOSITO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta7003(mapRespuesta);
		} else if (codTransaccion.equals(TRANS_REGULARIZACION_IMPORTACION_DEFINITIVA)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta1004(mapRespuesta,variablesIngreso);
		} else if (codTransaccion.equals(TRANS_REGULARIZACION_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2004(mapRespuesta,variablesIngreso);
		} else if (codTransaccion.equals(TRANS_REGULARIZACION_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2104(mapRespuesta,variablesIngreso);
		} else if (codTransaccion.equals(TRANS_REGULARIZACION_DEPOSITO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta7004(mapRespuesta,variablesIngreso);
		}else if (codTransaccion.equals(TRANS_REGULARIZACION_URG_IMPORTACION_DEFINITIVA)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta1005(mapRespuesta,variablesIngreso);
		} else if (codTransaccion.equals(TRANS_REGULARIZACION_URG_ADMISION_TEMPORAL_REEXPORTACION_MISMO_ESTADO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2005(mapRespuesta,variablesIngreso);
		} else if (codTransaccion.equals(TRANS_REGULARIZACION_URG_ADMISION_TEMPORAL_PERFECCIONAMIENTO_ACTIVO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta2105(mapRespuesta,variablesIngreso);
		} else if (codTransaccion.equals(TRANS_REGULARIZACION_URG_DEPOSITO)) {
			mapRespuesta = genRespuesta.obtenerDatosSolicitudRetiRegul(declaracion, codTransaccion, numCorreSol,variablesIngreso);
			mapRespuesta = genRespuesta.respuesta7005(mapRespuesta,variablesIngreso);
		}
		return mapRespuesta;
	}
	
	//NSR: No se lleg� a implmentar el Envio Alternativo, se comenta para elminar dependencias
	//07/02/2011
	/**
	private void generaRespuestaTxt (Integer nroErroresNegocio, Map<String, Object> variablesIngreso) {
		Integer annEnvio 		= (Integer) variablesIngreso.get("annEnvio");
		Long numEnvio 			= (Long) variablesIngreso.get("numEnvio");
		String numOrden 		= (String) variablesIngreso.get("numOrden");
		String numeroDocumentoIdentidadSender = (String) variablesIngreso .get("numeroDocumentoIdentidadSender");
		nomArchivo = annEnvio.toString().concat(Cadena.padLeft(numEnvio.toString(), 13, '0'));
		pathTmp = obtenerPantillas.getDirectorioTmpGenArchivos().concat("/").concat(nomArchivo);
		// Genera archivos de respuesta
		generaArchivo("CTR", genRespuestaTxt.listaResctr01(nroErroresNegocio, numeroDocumentoIdentidadSender));
		if (nroErroresNegocio.equals(0)) {
			Map<String, Object> mapRespuesta =  obtenerRespuestaAceptacionDeclaracion(variablesIngreso);
			if (mapRespuesta.get("encontro").equals("SI")) {
				generaArchivo("HDR", genRespuestaTxt.listaReshdr01(numOrden, mapRespuesta));
			}
		}
		generaArchivo("ERR", genRespuestaTxt.listaReserr01(variablesIngreso));
		// Obteniendo el tama�o de los archivos
		Long lnTamTotal = 0L;
		Long lnTamArcZip = 0L;
		File dirTmp = new File(pathTmp);
		File[] files = dirTmp.listFiles();
		for (int i=0; i<files.length; i++) {
			lnTamTotal = lnTamTotal + files[i].length();
		}
		// Zipea los archivos
		String nomArchivoZip = zipeaArchivo();
		// Se convierte a byte
		File archivoZip = new File(nomArchivoZip);
		lnTamArcZip = archivoZip.length();

		byte[] informacionArchivo = null;;
		try {
			informacionArchivo = getBytesFromFile(archivoZip);
		} catch (IOException e1) {
			e1.printStackTrace();
			return;
		}
		// Se inserta en Env_archivo
		try {
			insertarEnvioArchivo("A", informacionArchivo, annEnvio, numEnvio);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			return;
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		// Se borra directorio y archivos temporales
		borraArchivos(dirTmp);
		// Graba en TdColas_cab
		String lcNomArchivo = Cadena.padLeft(numEnvio.toString().trim(), 13, '0').substring(5, 13);
		TDColasCab tdcolasCab = new TDColasCab();
		tdcolasCab.setArchivo(lcNomArchivo);
		tdcolasCab.setArchZip(" ");
		tdcolasCab.setSizeRpta(lnTamArcZip.toString());
		tdcolasCab.setSizeRptaUnzip(lnTamTotal.toString());
		tdcolasCab.setIndtransfer(Integer.valueOf("5"));
		tdcolasCabDAO.updateFinProcesoParalelo(tdcolasCab);
	}
	**/
	private void insertarEnvioArchivo(String tipoArchivo, byte[] informacionArchivo, Integer anioEnvio, Long numEnvio) throws Exception
	{
		EnvioArchivoDAO envioArchivoDAO = (EnvioArchivoDAO)fabricaDeServicios.getService("envioArchivoDef");
		EnvioArchivoBean envioArchivoBean = new EnvioArchivoBean();
		
		envioArchivoBean.setNumeroEnvio(numEnvio);
		envioArchivoBean.setAnioEnvio(anioEnvio);
		envioArchivoBean.setTipoArchivo(tipoArchivo);
		envioArchivoBean.setInformacionArchivo(informacionArchivo);
		
		envioArchivoDAO.insertarArchivoEnvio(envioArchivoBean);
	}
	/*
	private String zipeaArchivo () {
		String zipFileName = pathTmp.concat("/").concat(nomArchivo).concat(".ZIP");
		byte[] buffer = new byte[18024];
		File dirTmp = new File(pathTmp);
		File[] files = dirTmp.listFiles();
	    try{
	        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFileName));
	        out.setLevel(Deflater.DEFAULT_COMPRESSION);
	        for (int i=0; i<files.length; i++) {
	  	      FileInputStream in = new FileInputStream(files[i]);
	  	      out.putNextEntry(new ZipEntry(files[i].getName()));
	  	      int len;
	  	      while ((len = in.read(buffer)) > 0){
	  	        out.write(buffer, 0, len);
	  	      }
	  	      out.closeEntry();
	  	      in.close();
	        }
	        out.close();
	      }
	      catch (IllegalArgumentException iae){
	        iae.printStackTrace();
	        System.exit(0);
	      }
	      catch (FileNotFoundException fnfe){
	        fnfe.printStackTrace();
	        System.exit(0);
	      }
	      catch (IOException ioe){
	        ioe.printStackTrace();
	        System.exit(0);
	      }
	      return zipFileName;
	}
	
	private void borraArchivos (File path) {
		if (path.exists()) {
		  File[] files = path.listFiles();
          for(int i=0; i<files.length; i++) {
             if(files[i].isDirectory()) {
            	 borraArchivos(files[i]);
             }
             else {
               files[i].delete();
             }
          }
          path.delete();
		}
	}
	
	private void generaArchivo (String tipoArchivo, List<String> lstCadenas) {
		File dirTmp = new File(pathTmp);
		boolean creoDirectotio = true;
		if (!dirTmp.isDirectory()) {
			creoDirectotio = (new File(pathTmp)).mkdir();
		}
		if (!creoDirectotio) {
			return;
		}
		
		if (lstCadenas==null || lstCadenas.size()==0) {
			return;
		}
		String nombreArchivo = nomArchivo.concat(".").concat(tipoArchivo);
		String nombreLargo = pathTmp.concat("/").concat(nombreArchivo);
		FileWriter archivo = null;
        PrintWriter pw = null;
        try
        {
        	archivo = new FileWriter(nombreLargo);
            pw = new PrintWriter(archivo);

            for (String cadena:lstCadenas) {
                pw.println(cadena);
            }

        } catch (Exception e) {
            e.printStackTrace();
            nombreArchivo = "";
        } finally {
           try {
           // Nuevamente aprovechamos el finally para asegurarnos que se cierra el archivo.
           if (null != archivo)
        	   archivo.close();
           } catch (Exception e2) {
              e2.printStackTrace();
              nombreArchivo = "";
           }
        }
	}*/
	
	public static byte[] getBytesFromFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);
    
        // Get the size of the file
        long length = file.length();
    
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
    
        // Create the byte array to hold the data
        byte[] bytes = new byte[(int)length];
    
        // Read in the bytes
        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
               && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
            offset += numRead;
        }
    
        // Ensure all the bytes have been read in
        if (offset < bytes.length) {
            throw new IOException("Could not completely read file "+file.getName());
        }
    
        // Close the input stream and return bytes
        is.close();
        return bytes;
    } 
	
	/*
	public GenRespuesta getGenRespuesta() {
		return genRespuesta;
	}

	public void setGenRespuesta(GenRespuesta genRespuesta) {
		this.genRespuesta = genRespuesta;
	}

	public ObtenerPantillas getObtenerPantillas() {
		return obtenerPantillas;
	}

	public void setObtenerPantillas(ObtenerPantillas obtenerPantillas) {
		this.obtenerPantillas = obtenerPantillas;
	}
   
	public Configuration getConfiguration() {
		return configuration;
	}

	public void setConfiguration(Configuration configuration) {
		this.configuration = configuration;
	}
*/
//	public GenRespuestaTxt getGenRespuestaTxt() {
//		return genRespuestaTxt;
//	}
//
//	public void setGenRespuestaTxt(GenRespuestaTxt genRespuestaTxt) {
//		this.genRespuestaTxt = genRespuestaTxt;
//	}

	/*
	public EnvioArchivoDAO getEnvioArchivoDAO() {
		return envioArchivoDAO;
	}

	public void setEnvioArchivoDAO(EnvioArchivoDAO envioArchivoDAO) {
		this.envioArchivoDAO = envioArchivoDAO;
	}*/
	
//	public TDColasCabDAO getTdcolasCabDAO() {
//		return tdcolasCabDAO;
//	}
//
//	public void setTdcolasCabDAO(TDColasCabDAO tdcolasCabDAO) {
//		this.tdcolasCabDAO = tdcolasCabDAO;
//	}
	
	
}