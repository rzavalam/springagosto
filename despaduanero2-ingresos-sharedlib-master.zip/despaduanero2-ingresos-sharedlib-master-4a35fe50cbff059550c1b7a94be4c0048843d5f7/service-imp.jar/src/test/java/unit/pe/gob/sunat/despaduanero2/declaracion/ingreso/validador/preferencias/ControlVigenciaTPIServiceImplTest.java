package unit.pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.ControlVigenciaTPIService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.ControlVigenciaTPIServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;

/**
 * Test del control de vigencias aplicado por TPI y tipo de certificado.
 * @author glazaror
 */
public class ControlVigenciaTPIServiceImplTest {
	
	private ControlVigenciaTPIService service;
	private static List<Map<String, String>> codigosAsociadosCatalogo = null;
	private static List<Map<String, String>> codigosAsociadosExceptuadosCatalogo = null;
	private static List<String> serviciosActualesNumeracion = null;
	private static List<String> serviciosNuevosNumeracion = null;
	
	private static List<Map<String, Object>> grupoAtributo129 = null;
	private static List<Map<String, Object>> grupoAtributo130 = null;
	private static List<Map<String, Object>> grupoAtributo131 = null;
	private static List<Map<String, Object>> grupoAtributo132 = null;
	private static List<Map<String, Object>> grupoAtributo133 = null;
	private static List<CasoPrueba> casosPrueba = null;
	
	private static final String COD_ATRIBUTO_TIPOCERTIFICADO_1 = "131";
	private static final String COD_ATRIBUTO_TIPOCERTIFICADO_2 = "132";
	private static final String COD_ATRIBUTO_TIPOCERTIFICADO_5 = "133";

	@BeforeClass
	public static void configuracionInicial() {
		configurar();
		cargarCasosPrueba();
	}
	
	@Before
	public void setUp() throws Exception {
		service = new ControlVigenciaTPIServiceImpl();
		FabricaDeServicios fabricaDeServicios = configurarFabricaServicios();
		((ControlVigenciaTPIServiceImpl) service).setFabricaDeServicios(fabricaDeServicios);
	}
	
	/**
	 * Test de casos de control de vigencia aplicados por tpi y tipo de certificado
	 */
	@Test
	public void validarControlVigenciaTest() throws Exception {
		
		int i = 1;
		for (CasoPrueba casoPrueba : casosPrueba) {
			System.out.println("----CASO PRUEBA " + (i) + "-------------------------------------------------------------------------------------------");
			System.out.println("Tipo certificado: " + casoPrueba.getTipoCertificado() + " - fecha certificado: " + DateUtil.dateToStringSilent(casoPrueba.getFechaCertificado(), "dd/MM/yyyy") + " - Fecha actual: " + DateUtil.dateToStringSilent(casoPrueba.getFechaReferencia(), "dd/MM/yyyy"));
			
			Map<String, Object> variablesIngreso = new HashMap<String, Object>();
			variablesIngreso.put("indValidaTLC", "");
			
			//ejecutamos caso prueba servicios actuales
			ejecutarCasosPrueba(casoPrueba, variablesIngreso, serviciosActualesNumeracion, i, casoPrueba.isServicioActualEjecutable(), "ServicioActual");
			//ejecutamos caso prueba servicios nuevos
			ejecutarCasosPrueba(casoPrueba, variablesIngreso, serviciosNuevosNumeracion, i, casoPrueba.isServicioNuevoEjecutable(), "ServicioNuevo");
			i++;
			System.out.println("-----------------------------------------------------------------------------------------------");
		}
	}
	
	private void ejecutarCasosPrueba(CasoPrueba casoPrueba, Map<String, Object> variablesIngreso, List<String> servicios, int i, boolean servicioEjecutable, String etiquetaServicio) {
		for (String codigoServicio : servicios) {
			boolean resultado = service.isServicioVigente(variablesIngreso, casoPrueba.getSerie(), casoPrueba.getFechaReferencia(), codigoServicio);
			boolean resultadoEsperado = servicioEjecutable;
			if (casoPrueba.getServiciosExceptuadosValidacion().contains(codigoServicio)) {
				//si es que el servicio esta exceptuado entonces el resultado debe ser true
				resultadoEsperado = true;
			}
			assertEquals("CasoPrueba " + (i) + ": Para el tipo certificado " + casoPrueba.getTipoCertificado() + " - " + etiquetaServicio + ": " + codigoServicio + " resultado incorrecto...", resultadoEsperado, resultado);
			System.out.println("---------> codigo" + etiquetaServicio + ": " + codigoServicio + " - resultado: " + resultado);
		}
	}
	
	private static void cargarCasosPrueba() {
		casosPrueba = new ArrayList<CasoPrueba>();
		
		List<String> serviciosExceptuadosValidacion = new ArrayList<String>();
		serviciosExceptuadosValidacion.add("3343");//servicio que debe ejecutarse siempre
		serviciosExceptuadosValidacion.add("3464");//servicio que debe ejecutarse siempre
		serviciosExceptuadosValidacion.add("3465");//servicio que debe ejecutarse siempre
		
		//Del 1 al 10 pruebas del tipo de certificado 1
		
		//del 1 al 7 la fecha del certificado <= 31/07/2016
		CasoPrueba casoPrueba1 = new CasoPrueba("1", "01/05/2016", "20/05/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba2 = new CasoPrueba("1", "01/05/2016", "31/07/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba3 = new CasoPrueba("1", "31/07/2016", "31/07/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba4 = new CasoPrueba("1", "01/05/2016", "01/08/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba5 = new CasoPrueba("1", "01/05/2016", "31/12/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba6 = new CasoPrueba("1", "01/05/2016", "01/01/2017", 806, false, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba7 = new CasoPrueba("1", "01/05/2016", "08/01/2017", 806, false, false, serviciosExceptuadosValidacion);
		
		//del 8 al 10 fecha certificado > 31/07/2016
		CasoPrueba casoPrueba8 = new CasoPrueba("1", "01/08/2016", "01/08/2016", 806, true, true, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba9 = new CasoPrueba("1", "08/08/2016", "01/01/2017", 806, true, true, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba10 = new CasoPrueba("1", "02/01/2017", "06/01/2017", 806, true, true, serviciosExceptuadosValidacion);
		
		
		//del 11 al 20 pruebas del tipo de certificado 2
		//del 11 al 17 la fecha del certificado <= 31/07/2016
		CasoPrueba casoPrueba11 = new CasoPrueba("2", "01/05/2016", "20/05/2016", 806, false, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba12 = new CasoPrueba("2", "01/05/2016", "31/07/2016", 806, false, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba13 = new CasoPrueba("2", "31/07/2016", "31/07/2016", 806, false, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba14 = new CasoPrueba("2", "01/05/2016", "01/08/2016", 806, true, true, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba15 = new CasoPrueba("2", "01/05/2016", "31/12/2016", 806, true, true, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba16 = new CasoPrueba("2", "01/05/2016", "01/01/2017", 806, true, true, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba17 = new CasoPrueba("2", "01/05/2016", "08/01/2017", 806, true, true, serviciosExceptuadosValidacion);
		//del 8 al 10 fecha certificado > 31/07/2016
		CasoPrueba casoPrueba18 = new CasoPrueba("2", "01/08/2016", "01/08/2016", 806, true, true, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba19 = new CasoPrueba("2", "08/08/2016", "01/01/2017", 806, true, true, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba20 = new CasoPrueba("2", "02/01/2017", "06/01/2017", 806, true, true, serviciosExceptuadosValidacion);
		
		
		//del 21 al 30 pruebas del tipo de certificado 5
		//del 21 al 27 la fecha del certificado <= 31/07/2016
		CasoPrueba casoPrueba21 = new CasoPrueba("5", "01/05/2016", "20/05/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba22 = new CasoPrueba("5", "01/05/2016", "31/07/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba23 = new CasoPrueba("5", "31/07/2016", "31/07/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba24 = new CasoPrueba("5", "01/05/2016", "01/08/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba25 = new CasoPrueba("5", "01/05/2016", "31/12/2016", 806, true, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba26 = new CasoPrueba("5", "01/05/2016", "01/01/2017", 806, false, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba27 = new CasoPrueba("5", "01/05/2016", "08/01/2017", 806, false, false, serviciosExceptuadosValidacion);
		//del 28 al 30 fecha certificado > 31/07/2016
		CasoPrueba casoPrueba28 = new CasoPrueba("5", "01/08/2016", "01/08/2016", 806, false, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba29 = new CasoPrueba("5", "08/08/2016", "01/01/2017", 806, false, false, serviciosExceptuadosValidacion);
		CasoPrueba casoPrueba30 = new CasoPrueba("5", "02/01/2017", "06/01/2017", 806, false, false, serviciosExceptuadosValidacion);
		
		casosPrueba.add(casoPrueba1);
		casosPrueba.add(casoPrueba2);
		casosPrueba.add(casoPrueba3);
		casosPrueba.add(casoPrueba4);
		casosPrueba.add(casoPrueba5);
		casosPrueba.add(casoPrueba6);
		casosPrueba.add(casoPrueba7);
		casosPrueba.add(casoPrueba8);
		casosPrueba.add(casoPrueba9);
		casosPrueba.add(casoPrueba10);
		
		casosPrueba.add(casoPrueba11);
		casosPrueba.add(casoPrueba12);
		casosPrueba.add(casoPrueba13);
		casosPrueba.add(casoPrueba14);
		casosPrueba.add(casoPrueba15);
		casosPrueba.add(casoPrueba16);
		casosPrueba.add(casoPrueba17);
		casosPrueba.add(casoPrueba18);
		casosPrueba.add(casoPrueba19);
		casosPrueba.add(casoPrueba20);
		
		casosPrueba.add(casoPrueba21);
		casosPrueba.add(casoPrueba22);
		casosPrueba.add(casoPrueba23);
		casosPrueba.add(casoPrueba24);
		casosPrueba.add(casoPrueba25);
		casosPrueba.add(casoPrueba26);
		casosPrueba.add(casoPrueba27);
		casosPrueba.add(casoPrueba28);
		casosPrueba.add(casoPrueba29);
		casosPrueba.add(casoPrueba30);
		
		//
	}
	
	/**
	 * Carga la configuracion del servicio de fabricaDeServicios haciendo uso de Mockito
	 */
	private FabricaDeServicios configurarFabricaServicios() {
		FabricaDeServicios fabricaDeServicios = Mockito.mock(FabricaDeServicios.class);
		CatalogoAyudaService catalogoAyudaService = Mockito.mock(CatalogoAyudaService.class);
		when(catalogoAyudaService.getListaAsociado(eq(ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS), any(Date.class))).thenReturn(codigosAsociadosCatalogo);
		when(catalogoAyudaService.getListaAsociado(eq(ConstantesTipoCatalogo.CATALOGO_RELACION_SERVICIOS_TLCS), any(Date.class))).thenReturn(codigosAsociadosExceptuadosCatalogo);
		
		when(catalogoAyudaService.getDataAtributos(ConstantesAtributo.CODIGO_ATRIBUTO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, null, null)).thenReturn(grupoAtributo129);
		
		when(catalogoAyudaService.getDataAtributos("130", ConstantesGrupoCatalogo.COD_GRUPO_TIPO_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_TIPO_CERTIFICADO, null, null)).thenReturn(grupoAtributo130);
		
		when(catalogoAyudaService.getDataAtributos(COD_ATRIBUTO_TIPOCERTIFICADO_1, ConstantesGrupoCatalogo.COD_GRUPO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_CONTROL_VIGENCIA_TPI, null, null)).thenReturn(grupoAtributo131);
		
		when(catalogoAyudaService.getDataAtributos(COD_ATRIBUTO_TIPOCERTIFICADO_2, ConstantesGrupoCatalogo.COD_GRUPO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_CONTROL_VIGENCIA_TPI, null, null)).thenReturn(grupoAtributo132);
		
		when(catalogoAyudaService.getDataAtributos(COD_ATRIBUTO_TIPOCERTIFICADO_5, ConstantesGrupoCatalogo.COD_GRUPO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_CONTROL_VIGENCIA_TPI, null, null)).thenReturn(grupoAtributo133);
		
		when(fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).thenReturn(catalogoAyudaService);
		
		return fabricaDeServicios;
	}
	
	private static void configurar() {
		//cargamos la lista de servicios actuales y nuevos
		serviciosActualesNumeracion = new ArrayList<String>();
		serviciosActualesNumeracion.add("3381");
		serviciosActualesNumeracion.add("3380");
		serviciosActualesNumeracion.add("3382");
		serviciosActualesNumeracion.add("3433"); 
		serviciosActualesNumeracion.add("3383");
		serviciosActualesNumeracion.add("3375"); 
		serviciosActualesNumeracion.add("3376"); 
		serviciosActualesNumeracion.add("3431");
		serviciosActualesNumeracion.add("3343");//exceptuado del control de vigencias (asociacion 384: servicios exceptuados del control de vigencias)
		serviciosActualesNumeracion.add("3348");
		serviciosActualesNumeracion.add("3358");
		serviciosActualesNumeracion.add("3351");
		serviciosActualesNumeracion.add("3370");
		serviciosActualesNumeracion.add("3354");
		serviciosActualesNumeracion.add("3339");
		serviciosActualesNumeracion.add("3340");
		serviciosActualesNumeracion.add("3341");
		serviciosActualesNumeracion.add("3399");
		serviciosActualesNumeracion.add("3453");
		serviciosActualesNumeracion.add("3419");
		serviciosActualesNumeracion.add("3332");
		serviciosActualesNumeracion.add("3394");
		
		serviciosNuevosNumeracion = new ArrayList<String>();
		serviciosNuevosNumeracion.add("3463");
		serviciosNuevosNumeracion.add("3367");
		serviciosNuevosNumeracion.add("3369");
		serviciosNuevosNumeracion.add("3364");
		serviciosNuevosNumeracion.add("3466");
		serviciosNuevosNumeracion.add("3469");
		serviciosNuevosNumeracion.add("3468");
		serviciosNuevosNumeracion.add("3361");
		serviciosNuevosNumeracion.add("3359");
		serviciosNuevosNumeracion.add("3464");//exceptuado del control de vigencias (asociacion 384: servicios exceptuados del control de vigencias)
		serviciosNuevosNumeracion.add("3465");//exceptuado del control de vigencias (asociacion 384: servicios exceptuados del control de vigencias)
		serviciosNuevosNumeracion.add("3467");
		serviciosNuevosNumeracion.add("3470");
		serviciosNuevosNumeracion.add("3471");
		
		//ahora la asociacion servicios --> asociacion 383 (servicios actuales que pasan por el control de vigencias)... por el momento solo para el tpi 806
		codigosAsociadosCatalogo = new ArrayList<Map<String, String>>();
		for (String codigoServicio : serviciosActualesNumeracion) {
			Map<String, String> mapServicio = new HashMap<String, String>();
			mapServicio.put("cod_datacat", "806");
			mapServicio.put("cod_datacatasoc", codigoServicio);
			codigosAsociadosCatalogo.add(mapServicio);
		}
		
		codigosAsociadosExceptuadosCatalogo = new ArrayList<Map<String, String>>();//asociacion 384
		Map<String, String> mapServicio1 = new HashMap<String, String>();
		mapServicio1.put("cod_datacat", "806");
		mapServicio1.put("cod_datacatasoc", "3343"); //3343: validacion que siempre debe ejecutarse (valida el tipo de certificado transmitido)
		codigosAsociadosExceptuadosCatalogo.add(mapServicio1);
		
		Map<String, String> mapServicio2 = new HashMap<String, String>();
		mapServicio2.put("cod_datacat", "806");
		mapServicio2.put("cod_datacatasoc", "3464"); //3364: validacion que siempre debe ejecutarse (valida plazos)
		codigosAsociadosExceptuadosCatalogo.add(mapServicio2);
		
		Map<String, String> mapServicio3 = new HashMap<String, String>();
		mapServicio3.put("cod_datacat", "806");
		mapServicio3.put("cod_datacatasoc", "3465"); //3365: validacion que siempre debe ejecutarse (valida plazos)
		codigosAsociadosExceptuadosCatalogo.add(mapServicio3);
		
		
		//ahora configuracion de dataatributos
		//atributos
		
		grupoAtributo129 = new ArrayList<Map<String, Object>>();
		Map<String, Object> itemAtributo129 = new HashMap<String, Object>();
		itemAtributo129.put("cod_datacat", "806");
		itemAtributo129.put("val_atributo", "130");
		grupoAtributo129.add(itemAtributo129);
		
		grupoAtributo130 = new ArrayList<Map<String, Object>>();
		Map<String, Object> item1Atributo130 = new HashMap<String, Object>();
		item1Atributo130.put("cod_datacat", "1");
		item1Atributo130.put("val_atributo", COD_ATRIBUTO_TIPOCERTIFICADO_1);
		Map<String, Object> item2Atributo130 = new HashMap<String, Object>();
		item2Atributo130.put("cod_datacat", "2");
		item2Atributo130.put("val_atributo", COD_ATRIBUTO_TIPOCERTIFICADO_2);
		Map<String, Object> item3Atributo130 = new HashMap<String, Object>();
		item3Atributo130.put("cod_datacat", "5");
		item3Atributo130.put("val_atributo", COD_ATRIBUTO_TIPOCERTIFICADO_5);
		grupoAtributo130.add(item1Atributo130);
		grupoAtributo130.add(item2Atributo130);
		grupoAtributo130.add(item3Atributo130);
		
		grupoAtributo131 = new ArrayList<Map<String, Object>>();
		Map<String, Object> item1Atributo131 = new HashMap<String, Object>();
		item1Atributo131.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL);
		item1Atributo131.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item2Atributo131 = new HashMap<String, Object>();
		item2Atributo131.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL);
		item2Atributo131.put("val_atributo", "31/12/2016");
		
		Map<String, Object> item3Atributo131 = new HashMap<String, Object>();
		item3Atributo131.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE);
		item3Atributo131.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item4Atributo131 = new HashMap<String, Object>();
		item4Atributo131.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_RECHAZO_POR_SOBREPASAR_FECHACERTIFICADO_LIMITE);
		item4Atributo131.put("val_atributo", "NO");
		
		grupoAtributo131.add(item1Atributo131);
		grupoAtributo131.add(item2Atributo131);
		grupoAtributo131.add(item3Atributo131);
		grupoAtributo131.add(item4Atributo131);
		
		//
		grupoAtributo132 = new ArrayList<Map<String, Object>>();
		Map<String, Object> item1Atributo132 = new HashMap<String, Object>();
		item1Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL);
		item1Atributo132.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item2Atributo132 = new HashMap<String, Object>();
		item2Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL);
		item2Atributo132.put("val_atributo", "-");
		
		Map<String, Object> item3Atributo132 = new HashMap<String, Object>();
		item3Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE);
		item3Atributo132.put("val_atributo", "-");
		
		Map<String, Object> item4Atributo132 = new HashMap<String, Object>();
		item4Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_RECHAZO_POR_SOBREPASAR_FECHACERTIFICADO_LIMITE);
		item4Atributo132.put("val_atributo", "NO");
		
		Map<String, Object> item5Atributo132 = new HashMap<String, Object>();
		item5Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_EJECUCION_DESDE_FECHALIMITE_VALIDACION_ACTUAL_V1);
		item5Atributo132.put("val_atributo", "SI");
		
		grupoAtributo132.add(item1Atributo132);
		grupoAtributo132.add(item2Atributo132);
		grupoAtributo132.add(item3Atributo132);
		grupoAtributo132.add(item4Atributo132);
		grupoAtributo132.add(item5Atributo132);
		
		//
		grupoAtributo133 = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> item1Atributo133 = new HashMap<String, Object>();
		item1Atributo133.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL);
		item1Atributo133.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item2Atributo133 = new HashMap<String, Object>();
		item2Atributo133.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL);
		item2Atributo133.put("val_atributo", "31/12/2016");
		
		Map<String, Object> item3Atributo133 = new HashMap<String, Object>();
		item3Atributo133.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE);
		item3Atributo133.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item4Atributo133 = new HashMap<String, Object>();
		item4Atributo133.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_RECHAZO_POR_SOBREPASAR_FECHACERTIFICADO_LIMITE);
		item4Atributo133.put("val_atributo", "SI");
		
		grupoAtributo133.add(item1Atributo133);
		grupoAtributo133.add(item2Atributo133);
		grupoAtributo133.add(item3Atributo133);
		grupoAtributo133.add(item3Atributo133);
		
	}
	
	static class CasoPrueba {
		private DatoSerie serie;
		private Date fechaReferencia;
		private boolean servicioActualEjecutable;
		private boolean servicioNuevoEjecutable;
		private List<String> serviciosExceptuadosValidacion;

		public CasoPrueba(String tipoCertificado, String fechaCertificadoAsString, String fechaReferenciaAsString, Integer codigoConvenio, boolean servicioActualEjecutable, boolean servicioNuevoEjecutable, List<String> serviciosExceptuadosValidacion) {
			super();
			this.fechaReferencia = DateUtil.stringToDateSilent(fechaReferenciaAsString, "dd/MM/yyyy");
			this.servicioActualEjecutable = servicioActualEjecutable;
			this.servicioNuevoEjecutable = servicioNuevoEjecutable;
			this.serviciosExceptuadosValidacion = serviciosExceptuadosValidacion;
			configurarSerie(tipoCertificado, fechaCertificadoAsString, codigoConvenio);
		}
		
		private void configurarSerie(String tipoCertificado, String fechaCertificadoAsString, Integer codigoConvenio) {
			this.serie = new DatoSerie();
			this.serie.setCodconvinter(codigoConvenio);
			
			List<DatoAutocertificacion> certificadosOrigen = new ArrayList<DatoAutocertificacion>();
			DatoAutocertificacion certificadoOrigen = new DatoAutocertificacion();
			certificadoOrigen.setCodtipoCO(tipoCertificado);
			certificadoOrigen.setFecemision(DateUtil.stringToDateSilent(fechaCertificadoAsString, "dd/MM/yyyy"));
			certificadosOrigen.add(certificadoOrigen);
			this.serie.setCertificadosOrigen(certificadosOrigen);
		}
		
		public String getTipoCertificado() {
			return serie.getCertificadosOrigen().get(0).getCodtipoCO();
		}
		
		public Date getFechaCertificado() {
			return serie.getCertificadosOrigen().get(0).getFecemision();
		}
		
		public DatoSerie getSerie() {
			return serie;
		}
		
		public void setSerie(DatoSerie serie) {
			this.serie = serie;
		}
		
		public Date getFechaReferencia() {
			return fechaReferencia;
		}
		
		public void setFechaReferencia(Date fechaReferencia) {
			this.fechaReferencia = fechaReferencia;
		}
		
		public boolean isServicioActualEjecutable() {
			return servicioActualEjecutable;
		}

		public void setServicioActualEjecutable(boolean servicioActualEjecutable) {
			this.servicioActualEjecutable = servicioActualEjecutable;
		}

		public boolean isServicioNuevoEjecutable() {
			return servicioNuevoEjecutable;
		}

		public void setServicioNuevoEjecutable(boolean servicioNuevoEjecutable) {
			this.servicioNuevoEjecutable = servicioNuevoEjecutable;
		}
		
		public List<String> getServiciosExceptuadosValidacion() {
			return serviciosExceptuadosValidacion;
		}

		public void setServiciosExceptuadosValidacion(List<String> serviciosExceptuadosValidacion) {
			this.serviciosExceptuadosValidacion = serviciosExceptuadosValidacion;
		}
		
		
	}
}
