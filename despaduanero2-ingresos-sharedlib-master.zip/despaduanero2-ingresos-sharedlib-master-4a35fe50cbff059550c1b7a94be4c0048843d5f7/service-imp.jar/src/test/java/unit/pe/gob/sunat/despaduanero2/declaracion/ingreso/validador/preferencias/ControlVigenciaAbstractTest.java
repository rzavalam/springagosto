package unit.pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.mockito.Mockito;

import pe.gob.sunat.despaduanero2.ayudas.service.CatalogoAyudaService;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesAtributo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesDataCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesGrupoCatalogo;
import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.ControlVigenciaTPIService;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias.ControlVigenciaTPIServiceImpl;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoAutocertificacion;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.util.DateUtil;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;

/**
 * Test generico del control de vigencias aplicado por TPI y tipo de certificado.
 * @author glazaror
 */
public abstract class ControlVigenciaAbstractTest {
	
	protected ControlVigenciaTPIService service;
	protected CatalogoAyudaService catalogoAyudaService;
	protected static List<Map<String, String>> codigosAsociadosCatalogoNumeracion = null;
	protected static List<Map<String, String>> codigosAsociadosCatalogoRectificacion = null;
	protected static List<Map<String, String>> codigosAsociadosExceptuadosCatalogo = null;

	private static List<Map<String, Object>> grupoAtributo129 = null;
	private static List<Map<String, Object>> grupoAtributo130 = null;
	private static List<Map<String, Object>> grupoAtributo131 = null;
	private static List<Map<String, Object>> grupoAtributo132 = null;
	private static List<Map<String, Object>> grupoAtributo133 = null;
	
	private static final String COD_ATRIBUTO_TIPOCERTIFICADO_1 = "131";
	private static final String COD_ATRIBUTO_TIPOCERTIFICADO_2 = "132";
	private static final String COD_ATRIBUTO_TIPOCERTIFICADO_5 = "133";
	
	@BeforeClass
	public static void configuracionInicial() {
		configurar();
	}
	
	@Before
	public void setUp() throws Exception {
		service = new ControlVigenciaTPIServiceImpl();
		FabricaDeServicios fabricaDeServicios = configurarFabricaServicios();
		((ControlVigenciaTPIServiceImpl) service).setFabricaDeServicios(fabricaDeServicios);
	}
	
	protected void ejecutarCasos(String proceso, List<CasoPruebaFecha> casosPruebaGenerales, List<String> serviciosTest, boolean rectificacion) {
		System.out.println("*******************************************************************************************************");
		System.out.println(proceso);
		for (CasoPruebaFecha casoPruebaGeneral : casosPruebaGenerales) {
			String fechaSistemaAsString = DateUtil.dateToStringSilent(casoPruebaGeneral.getFechaSistema(), "dd/MM/yyyy");
			String fechaNumeracionAsString = (casoPruebaGeneral.getFechaNumeracion() != null) ? DateUtil.dateToStringSilent(casoPruebaGeneral.getFechaNumeracion(), "dd/MM/yyyy") : "HOY";
			String fechaCertificadoAsString = DateUtil.dateToStringSilent(casoPruebaGeneral.getFechaCertificado(), "dd/MM/yyyy");
			System.out.println("Caso " + casoPruebaGeneral.getNumeroCaso() + " - Fecha Sistema:" + fechaSistemaAsString + " - Fecha Numeracion: " + fechaNumeracionAsString + " - Fecha Certificado:" + fechaCertificadoAsString);
			List<CasoPruebaTipoCertificado> casosPrueba = casoPruebaGeneral.getCasosPorTipoCertificado();
			for (CasoPruebaTipoCertificado caso : casosPrueba) {
				DatoSerie serie = getSerie(caso.getTipoCertificado(), casoPruebaGeneral.getFechaCertificado(), 806);
				for (String codigoServicioTest : serviciosTest) {
					((ControlVigenciaTPIServiceImpl) service).setFechaSistemaTest(casoPruebaGeneral.getFechaSistema());
					Map<String, Object> variablesIngreso = getVariablesIngreso(casoPruebaGeneral, serie, rectificacion);
					
					boolean servicioVigente = service.isServicioVigente(variablesIngreso, serie, casoPruebaGeneral.getFechaSistema(), codigoServicioTest);
					boolean servicioDebeEjecutarse = caso.getServiciosAplicados().contains(codigoServicioTest);
					System.out.println("------> codigoServicioTest: " + codigoServicioTest + " - servicioVigente: " + servicioVigente + " - servicioDebeEjecutarse: " + servicioDebeEjecutarse);
					Assert.assertEquals(servicioDebeEjecutarse, servicioVigente);
				}
			}
		}
	}
	
	protected DatoSerie getSerie(String tipoCertificado, Date fechaCertificado, Integer codigoConvenio) {
		DatoSerie serie = new DatoSerie();
		serie.setCodconvinter(codigoConvenio);
		serie.setNumserie(1);
		
		List<DatoAutocertificacion> certificadosOrigen = new ArrayList<DatoAutocertificacion>();
		DatoAutocertificacion certificadoOrigen = new DatoAutocertificacion();
		certificadoOrigen.setCodtipoCO(tipoCertificado);
		certificadoOrigen.setFecemision(fechaCertificado);
		certificadosOrigen.add(certificadoOrigen);
		serie.setCertificadosOrigen(certificadosOrigen);
		
		return serie;
	}
	
	protected Map<String, Object> getVariablesIngreso(CasoPruebaFecha caso, DatoSerie serie, boolean rectificacion) {
		Map<String, Object> variablesIngreso = new HashMap<String, Object>();
		variablesIngreso.put("indValidaTLC", "SI");
		
		if (caso.getFechaNumeracion() != null) {
			Declaracion declaracionBD = new Declaracion();
			DUA dua = new DUA();
			dua.setFecdeclaracion(caso.getFechaNumeracion());
			
			Elementos<DatoSerie> series = new Elementos<DatoSerie>();
			
			if (!rectificacion) {
				series.add(serie);
			} else {
				DatoSerie serieOld = new DatoSerie();
				serieOld.setNumserie(serie.getNumserie());
				//primero probamos asumiendo que antes era TPI 802
				serieOld.setCodconvinter(802);
				series.add(serieOld);
			}
			dua.setListSeries(series);
			declaracionBD.setDua(dua);
			
			variablesIngreso.put("declaracionBDParaValidacionTLC", declaracionBD);
		}
		return variablesIngreso;
	}
	
	/**
	 * Carga la configuracion del servicio de fabricaDeServicios haciendo uso de Mockito
	 */
	protected FabricaDeServicios configurarFabricaServicios() {
		FabricaDeServicios fabricaDeServicios = Mockito.mock(FabricaDeServicios.class);
		catalogoAyudaService = Mockito.mock(CatalogoAyudaService.class);
		when(catalogoAyudaService.getListaAsociado(eq(ConstantesTipoCatalogo.CATALOGO_RELACION_SERVICIOS_TLCS), any(Date.class))).thenReturn(codigosAsociadosExceptuadosCatalogo);
		when(catalogoAyudaService.getDataAtributos(ConstantesAtributo.CODIGO_ATRIBUTO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesGrupoCatalogo.GRUPO_TRATADOS_INTERNACIONALES, ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS, null, null)).thenReturn(grupoAtributo129);
		when(catalogoAyudaService.getDataAtributos("130", ConstantesGrupoCatalogo.COD_GRUPO_TIPO_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_TIPO_CERTIFICADO, null, null)).thenReturn(grupoAtributo130);
		when(catalogoAyudaService.getDataAtributos(COD_ATRIBUTO_TIPOCERTIFICADO_1, ConstantesGrupoCatalogo.COD_GRUPO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_CONTROL_VIGENCIA_TPI, null, null)).thenReturn(grupoAtributo131);
		when(catalogoAyudaService.getDataAtributos(COD_ATRIBUTO_TIPOCERTIFICADO_2, ConstantesGrupoCatalogo.COD_GRUPO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_CONTROL_VIGENCIA_TPI, null, null)).thenReturn(grupoAtributo132);
		when(catalogoAyudaService.getDataAtributos(COD_ATRIBUTO_TIPOCERTIFICADO_5, ConstantesGrupoCatalogo.COD_GRUPO_CONTROL_VIGENCIA_TPI_CERTIFICADO, ConstantesTipoCatalogo.CATALOGO_CONTROL_VIGENCIA_TPI, null, null)).thenReturn(grupoAtributo133);
		when(fabricaDeServicios.getService("Ayuda.catalogoAyudaService")).thenReturn(catalogoAyudaService);
		return fabricaDeServicios;
	}
	
	protected static void configurar() {
		//cargamos la lista de servicios actuales y nuevos
		List<String> serviciosActualesNumeracion = new ArrayList<String>();
		serviciosActualesNumeracion.add("3381");//RN 4.a
		serviciosActualesNumeracion.add("3380");//RN 4.a
		serviciosActualesNumeracion.add("3382");//RN 4.a
		serviciosActualesNumeracion.add("3433");//RF1 d) Para el tipo de certificado 4 se mantienen las reglas implementadas
		serviciosActualesNumeracion.add("3383");//RN 4.a
		serviciosActualesNumeracion.add("3375");//RF1 d) Para el tipo de certificado 4 se mantienen las reglas implementadas
		serviciosActualesNumeracion.add("3376");//RF1 d) Para el tipo de certificado 4 se mantienen las reglas implementadas
		serviciosActualesNumeracion.add("3431");//RF1 d) Para el tipo de certificado 4 se mantienen las reglas implementadas
		serviciosActualesNumeracion.add("3343");//RN 2.1 exceptuado del control de vigencias (asociacion 384: servicios exceptuados del control de vigencias)
		serviciosActualesNumeracion.add("3348");//RN 2.5, 2.6, 2.7, 2.8 - proceso numeracion, tipos certificado: 1 y 5
		serviciosActualesNumeracion.add("3358");//RN 2.9 - tipos certificado 1 y 5
		serviciosActualesNumeracion.add("3351");//RF1 b) Para el tipo de certificado 1: se debe transmitir obligatoriamente numero y fecha certificado
		serviciosActualesNumeracion.add("3370");//RN 4.a
		serviciosActualesNumeracion.add("3354");//RN 4.a
		serviciosActualesNumeracion.add("3339");//RN 2.10, 3.12
		serviciosActualesNumeracion.add("3340");//RN 2.10, 3.12
		serviciosActualesNumeracion.add("3341");//RN 2.10, 3.12
		serviciosActualesNumeracion.add("3399");//RN 2.10, 3.12
		serviciosActualesNumeracion.add("3453");//RN 2.10, 3.12
		serviciosActualesNumeracion.add("3419");//RN 2.10, 3.12
		serviciosActualesNumeracion.add("3332");//RN 2.10, 3.12
		serviciosActualesNumeracion.add("3394");//RN 2.10, 3.12
		
		//cargamos la lista de servicios actuales y nuevos
		List<String> serviciosActualesRectificacion = new ArrayList<String>();
		serviciosActualesRectificacion.add("3381");//RN 4.a
		serviciosActualesRectificacion.add("3380");//RN 4.a
		serviciosActualesRectificacion.add("3382");//RN 4.a
		serviciosActualesRectificacion.add("3433");//RF1 d) Para el tipo de certificado 4 se mantienen las reglas implementadas
		serviciosActualesRectificacion.add("3383");//RN 4.a
		serviciosActualesRectificacion.add("3375");//RF1 d) Para el tipo de certificado 4 se mantienen las reglas implementadas
		serviciosActualesRectificacion.add("3376");//RF1 d) Para el tipo de certificado 4 se mantienen las reglas implementadas
		serviciosActualesRectificacion.add("3431");//RF1 d) Para el tipo de certificado 4 se mantienen las reglas implementadas
		serviciosActualesRectificacion.add("3343");//RN 2.1 exceptuado del control de vigencias (asociacion 384: servicios exceptuados del control de vigencias)
		//serviciosActualesRectificacion.add("3348");//RN 2.5, 2.6, 2.7, 2.8 - proceso numeracion, tipos certificado: 1 y 5
		serviciosActualesRectificacion.add("3470");//RN 2.5, 2.6, 2.7, 2.8 - proceso rectificacion/regularizacion, tipos certificado: 1 y 5... reemplaza al 3348
		serviciosActualesRectificacion.add("3358");//RN 2.9 - tipos certificado 1 y 5
		serviciosActualesRectificacion.add("3351");//RF1 b) Para el tipo de certificado 1: se debe transmitir obligatoriamente numero y fecha certificado
		serviciosActualesRectificacion.add("3370");//RN 4.a
		serviciosActualesRectificacion.add("3354");//RN 4.a
		serviciosActualesRectificacion.add("3339");//RN 2.10, 3.12
		serviciosActualesRectificacion.add("3340");//RN 2.10, 3.12
		serviciosActualesRectificacion.add("3341");//RN 2.10, 3.12
		serviciosActualesRectificacion.add("3399");//RN 2.10, 3.12
		serviciosActualesRectificacion.add("3453");//RN 2.10, 3.12
		serviciosActualesRectificacion.add("3419");//RN 2.10, 3.12
		serviciosActualesRectificacion.add("3332");//RN 2.10, 3.12
		serviciosActualesRectificacion.add("3394");//RN 2.10, 3.12
		
		List<String> serviciosNuevosNumeracion = new ArrayList<String>();
		serviciosNuevosNumeracion.add("3463");//RN 3.2 - RF1 b) Para el tipo de certificado 2
		serviciosNuevosNumeracion.add("3367");//RN 2.2
		serviciosNuevosNumeracion.add("3369");//RN 2.3
		serviciosNuevosNumeracion.add("3364");//RN 2.4
		serviciosNuevosNumeracion.add("3466");//RN 2.9 - tipo certificado 2
		serviciosNuevosNumeracion.add("3469");//RN 3.3, 3.4
		serviciosNuevosNumeracion.add("3468");//RN 3.6, 3.7, 3.8, 3.9
		serviciosNuevosNumeracion.add("3361");//RN 3.5, 3.10
		serviciosNuevosNumeracion.add("3359");//RN 3.11
		serviciosNuevosNumeracion.add("3464");//RN 4.a (mensaje error) - exceptuado del control de vigencias (asociacion 384: servicios exceptuados del control de vigencias)
		serviciosNuevosNumeracion.add("3465");//RN 4.b (mensaje error) - exceptuado del control de vigencias (asociacion 384: servicios exceptuados del control de vigencias)
		serviciosNuevosNumeracion.add("3467");//RN 2.5, 2.6, 2.7, 2.8 - proceso numeracion/rectificacion/regularizacion, tipo certificado: 2
		//serviciosNuevosNumeracion.add("3470");//RN 2.5, 2.6, 2.7, 2.8 - proceso rectificacion/regularizacion, tipos certificado: 1 y 5
		//serviciosNuevosNumeracion.add("3471");//servicio de carga de variables... no es parte de validaciones TLC
		
		//ahora la asociacion servicios --> asociacion 383 (servicios actuales que pasan por el control de vigencias)... por el momento solo para el tpi 806... numeracion
		codigosAsociadosCatalogoNumeracion = new ArrayList<Map<String, String>>();
		for (String codigoServicio : serviciosActualesNumeracion) {
			Map<String, String> mapServicio = new HashMap<String, String>();
			mapServicio.put("cod_datacat", "806");
			mapServicio.put("cod_datacatasoc", codigoServicio);
			codigosAsociadosCatalogoNumeracion.add(mapServicio);
		}
		
		//ahora la asociacion servicios --> asociacion 383 (servicios actuales que pasan por el control de vigencias)... por el momento solo para el tpi 806... rectificacion
		codigosAsociadosCatalogoRectificacion = new ArrayList<Map<String, String>>();
		for (String codigoServicio : serviciosActualesRectificacion) {
			Map<String, String> mapServicio = new HashMap<String, String>();
			mapServicio.put("cod_datacat", "806");
			mapServicio.put("cod_datacatasoc", codigoServicio);
			codigosAsociadosCatalogoRectificacion.add(mapServicio);
		}
		
		codigosAsociadosExceptuadosCatalogo = new ArrayList<Map<String, String>>();//asociacion 384
		Map<String, String> mapServicio1 = new HashMap<String, String>();
		mapServicio1.put("cod_datacat", "806");
		mapServicio1.put("cod_datacatasoc", "3343"); //3343: validacion que siempre debe ejecutarse (valida el tipo de certificado transmitido)
		codigosAsociadosExceptuadosCatalogo.add(mapServicio1);
		
		Map<String, String> mapServicio2 = new HashMap<String, String>();
		mapServicio2.put("cod_datacat", "806");
		mapServicio2.put("cod_datacatasoc", "3464"); //3464: validacion que siempre debe ejecutarse (valida plazos)
		codigosAsociadosExceptuadosCatalogo.add(mapServicio2);
		
		Map<String, String> mapServicio3 = new HashMap<String, String>();
		mapServicio3.put("cod_datacat", "806");
		mapServicio3.put("cod_datacatasoc", "3465"); //3465: validacion que siempre debe ejecutarse (valida plazos)
		codigosAsociadosExceptuadosCatalogo.add(mapServicio3);
		
		
		//servicios con vigencia variable (servicios de validacion de plazos)
		List<Map<String, String>> codigosAsociadosVigenciaVariableCatalogo = new ArrayList<Map<String, String>>();//asociacion 384
		Map<String, String> mapServicioVigenciaVariable1 = new HashMap<String, String>();
		mapServicioVigenciaVariable1.put("cod_datacat", "806");
		mapServicioVigenciaVariable1.put("cod_datacatasoc", "3348"); //3348: validacion cuya vigencia puede tomar como referencia fecha actual o fecha de numeracion
		
		Map<String, String> mapServicioVigenciaVariable2 = new HashMap<String, String>();
		mapServicioVigenciaVariable2.put("cod_datacat", "806");
		mapServicioVigenciaVariable2.put("cod_datacatasoc", "3467"); //3467: validacion cuya vigencia puede tomar como referencia fecha actual o fecha de numeracion
		
		Map<String, String> mapServicioVigenciaVariable3 = new HashMap<String, String>();
		mapServicioVigenciaVariable3.put("cod_datacat", "806");
		mapServicioVigenciaVariable3.put("cod_datacatasoc", "3470"); //3470: validacion cuya vigencia puede tomar como referencia fecha actual o fecha de numeracion
		
		codigosAsociadosVigenciaVariableCatalogo.add(mapServicioVigenciaVariable1);
		codigosAsociadosVigenciaVariableCatalogo.add(mapServicioVigenciaVariable2);
		codigosAsociadosVigenciaVariableCatalogo.add(mapServicioVigenciaVariable3);
		
		
		
		//ahora configuracion de dataatributos
		//atributos
		
		grupoAtributo129 = new ArrayList<Map<String, Object>>();
		Map<String, Object> itemAtributo129 = new HashMap<String, Object>();
		itemAtributo129.put("cod_datacat", "806");
		itemAtributo129.put("val_atributo", "130");
		grupoAtributo129.add(itemAtributo129);
		
		grupoAtributo130 = new ArrayList<Map<String, Object>>();
		Map<String, Object> item1Atributo130 = new HashMap<String, Object>();
		item1Atributo130.put("cod_datacat", "1");
		item1Atributo130.put("val_atributo", COD_ATRIBUTO_TIPOCERTIFICADO_1);
		Map<String, Object> item2Atributo130 = new HashMap<String, Object>();
		item2Atributo130.put("cod_datacat", "2");
		item2Atributo130.put("val_atributo", COD_ATRIBUTO_TIPOCERTIFICADO_2);
		Map<String, Object> item3Atributo130 = new HashMap<String, Object>();
		item3Atributo130.put("cod_datacat", "5");
		item3Atributo130.put("val_atributo", COD_ATRIBUTO_TIPOCERTIFICADO_5);
		grupoAtributo130.add(item1Atributo130);
		grupoAtributo130.add(item2Atributo130);
		grupoAtributo130.add(item3Atributo130);
		
		grupoAtributo131 = new ArrayList<Map<String, Object>>();
		Map<String, Object> item1Atributo131 = new HashMap<String, Object>();
		item1Atributo131.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL);
		item1Atributo131.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item2Atributo131 = new HashMap<String, Object>();
		item2Atributo131.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL);
		item2Atributo131.put("val_atributo", "31/12/2016");
		
		Map<String, Object> item3Atributo131 = new HashMap<String, Object>();
		item3Atributo131.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE);
		item3Atributo131.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item4Atributo131 = new HashMap<String, Object>();
		item4Atributo131.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_RECHAZO_POR_SOBREPASAR_FECHACERTIFICADO_LIMITE);
		item4Atributo131.put("val_atributo", "NO");
		
		grupoAtributo131.add(item1Atributo131);
		grupoAtributo131.add(item2Atributo131);
		grupoAtributo131.add(item3Atributo131);
		grupoAtributo131.add(item4Atributo131);
		
		//
		grupoAtributo132 = new ArrayList<Map<String, Object>>();
		Map<String, Object> item1Atributo132 = new HashMap<String, Object>();
		item1Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL);
		item1Atributo132.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item2Atributo132 = new HashMap<String, Object>();
		item2Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL);
		item2Atributo132.put("val_atributo", "-");
		
		Map<String, Object> item3Atributo132 = new HashMap<String, Object>();
		item3Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE);
		item3Atributo132.put("val_atributo", "-");
		
		Map<String, Object> item4Atributo132 = new HashMap<String, Object>();
		item4Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_RECHAZO_POR_SOBREPASAR_FECHACERTIFICADO_LIMITE);
		item4Atributo132.put("val_atributo", "SI");
		
		Map<String, Object> item5Atributo132 = new HashMap<String, Object>();
		item5Atributo132.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_EJECUCION_DESDE_FECHALIMITE_VALIDACION_ACTUAL_V1);
		item5Atributo132.put("val_atributo", "SI");
		
		grupoAtributo132.add(item1Atributo132);
		grupoAtributo132.add(item2Atributo132);
		grupoAtributo132.add(item3Atributo132);
		grupoAtributo132.add(item4Atributo132);
		grupoAtributo132.add(item5Atributo132);
		
		//
		grupoAtributo133 = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> item1Atributo133 = new HashMap<String, Object>();
		item1Atributo133.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_ACTUAL);
		item1Atributo133.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item2Atributo133 = new HashMap<String, Object>();
		item2Atributo133.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHA_LIMITE_VALIDACION_EXCEPCIONAL);
		item2Atributo133.put("val_atributo", "31/12/2016");
		
		Map<String, Object> item3Atributo133 = new HashMap<String, Object>();
		item3Atributo133.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_FECHACERTIFICADO_LIMITE);
		item3Atributo133.put("val_atributo", "31/07/2016");
		
		Map<String, Object> item4Atributo133 = new HashMap<String, Object>();
		item4Atributo133.put("cod_datacat", ConstantesDataCatalogo.CODIGO_VARIABLE_RECHAZO_POR_SOBREPASAR_FECHACERTIFICADO_LIMITE);
		item4Atributo133.put("val_atributo", "NO");
		
		grupoAtributo133.add(item1Atributo133);
		grupoAtributo133.add(item2Atributo133);
		grupoAtributo133.add(item3Atributo133);
		grupoAtributo133.add(item3Atributo133);
		
	}
	
	static class CasoPruebaTipoCertificado {
		private String tipoCertificado;
		private List<String> serviciosAplicados;
		
		public CasoPruebaTipoCertificado(String tipoCertificado, List<String> serviciosAplicados) {
			super();
			this.tipoCertificado = tipoCertificado;
			this.serviciosAplicados = serviciosAplicados;
		}
		
		public String getTipoCertificado() {
			return tipoCertificado;
		}
		
		public void setTipoCertificado(String tipoCertificado) {
			this.tipoCertificado = tipoCertificado;
		}
		
		public List<String> getServiciosAplicados() {
			return serviciosAplicados;
		}
		
		public void setServiciosAplicados(List<String> serviciosAplicados) {
			this.serviciosAplicados = serviciosAplicados;
		}
	}
	
	static class CasoPruebaFecha {
		private Integer numeroCaso;
		private Date fechaSistema;
		private Date fechaCertificado;
		private Date fechaNumeracion;
		private List<CasoPruebaTipoCertificado> casosPorTipoCertificado;
		
		public CasoPruebaFecha(Integer numeroCaso, String fechaSistemaAsString, String fechaCertificadoAsString, String fechaNumeracionAsString) {
			super();
			this.numeroCaso = numeroCaso;
			this.fechaSistema = DateUtil.stringToDateSilent(fechaSistemaAsString, "dd/MM/yyyy");
			this.fechaCertificado = DateUtil.stringToDateSilent(fechaCertificadoAsString, "dd/MM/yyyy");
			this.fechaNumeracion = DateUtil.stringToDateSilent(fechaNumeracionAsString, "dd/MM/yyyy");
			this.casosPorTipoCertificado = new ArrayList<CasoPruebaTipoCertificado>();
		}
		
		public void addCasoPrueba(String tipoCertificado, List<String> serviciosAplicados) {
			CasoPruebaTipoCertificado caso = new CasoPruebaTipoCertificado(tipoCertificado, serviciosAplicados);
			casosPorTipoCertificado.add(caso);
		}
		
		public Integer getNumeroCaso() {
			return numeroCaso;
		}

		public void setNumeroCaso(Integer numeroCaso) {
			this.numeroCaso = numeroCaso;
		}
		
		public Date getFechaSistema() {
			return fechaSistema;
		}

		public void setFechaSistema(Date fechaSistema) {
			this.fechaSistema = fechaSistema;
		}

		public Date getFechaCertificado() {
			return fechaCertificado;
		}

		public void setFechaCertificado(Date fechaCertificado) {
			this.fechaCertificado = fechaCertificado;
		}

		public Date getFechaNumeracion() {
			return fechaNumeracion;
		}

		public void setFechaNumeracion(Date fechaNumeracion) {
			this.fechaNumeracion = fechaNumeracion;
		}

		/**
		 * @return the casosPorTipoCertificado
		 */
		public List<CasoPruebaTipoCertificado> getCasosPorTipoCertificado() {
			return casosPorTipoCertificado;
		}

		/**
		 * @param casosPorTipoCertificado the casosPorTipoCertificado to set
		 */
		public void setCasosPorTipoCertificado(List<CasoPruebaTipoCertificado> casosPorTipoCertificado) {
			this.casosPorTipoCertificado = casosPorTipoCertificado;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ ((numeroCaso == null) ? 0 : numeroCaso.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CasoPruebaFecha other = (CasoPruebaFecha) obj;
			if (numeroCaso == null) {
				if (other.numeroCaso != null)
					return false;
			} else if (!numeroCaso.equals(other.numeroCaso))
				return false;
			return true;
		}
	}
	
}
