package unit.pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DescrPosicion;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.neumaticos.model.Neumatico;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima;

public class TransformadorDescrMinimaServiceImplTest {

  protected final Log log = LogFactory.getLog(getClass());

  // private DescrMinNeumaticos neumatico = null;

  // @BeforeClass
  public void configuracionInicial()
  {
    // Nothing todo here.
    System.out.println("Iniciando Test...");

    DatoDescrMinima nombre = new DatoDescrMinima();
    nombre.setCodtipvalor("1");
    nombre.setCodtipdescr("NE00001");
    nombre.setValtipdescri("Nombre Comercial Neum�tico");

    DatoDescrMinima ancho = new DatoDescrMinima();
    ancho.setCodtipvalor("1");
    ancho.setCodtipdescr("NE00008");
    ancho.setValtipdescri("123456.363");

    DatoDescrMinima relacionAspecto = new DatoDescrMinima();
    relacionAspecto.setCodtipvalor("1");
    relacionAspecto.setCodtipdescr("NE00009");
    relacionAspecto.setValtipdescri("relacionAspecto");

    DatoDescrMinima nomenclatura = new DatoDescrMinima();

    nomenclatura.setCodtipvalor("0");
    nomenclatura.setCodtipdescr("NE00007");
    nomenclatura.setValtipdescri("nomenclatura");

    List<DatoDescrMinima> lstDatos = new ArrayList<DatoDescrMinima>();
    lstDatos.add(nombre);
    lstDatos.add(ancho);
    lstDatos.add(relacionAspecto);
    lstDatos.add(nomenclatura);

    List<DescrPosicion> lstPosiciones = new ArrayList<DescrPosicion>();
    DescrPosicion posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00001");
    posicion.setNombreAtributoDelObjeto("nombreComercial");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00002");
    posicion.setNombreAtributoDelObjeto("marcaComercial");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00003");
    posicion.setNombreAtributoDelObjeto("modelo");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00004");
    posicion.setNombreAtributoDelObjeto("uso");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00005");
    posicion.setNombreAtributoDelObjeto("primerMaterial");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00006");
    posicion.setNombreAtributoDelObjeto("segundoMaterial");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00007");
    posicion.setNombreAtributoDelObjeto("tipoNomenclatura");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00008");
    posicion.setNombreAtributoDelObjeto("anchoSeccion");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00009");
    posicion.setNombreAtributoDelObjeto("relacionAspectoSerie");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00010");
    posicion.setNombreAtributoDelObjeto("diametroAro");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00011");
    posicion.setNombreAtributoDelObjeto("tipoConstruccion");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00012");
    posicion.setNombreAtributoDelObjeto("indiceCapacidadCarga");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00013");
    posicion.setNombreAtributoDelObjeto("limiteVelocidad");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00014");
    posicion.setNombreAtributoDelObjeto("codigoSeguridad");
    lstPosiciones.add(posicion);

    Neumatico neumatico = new Neumatico();
    // neumatico.addDatos(lstDatos);
    // neumatico.addPosiciones(lstPosiciones);
    // this.neumatico = neumatico;
    System.out.println("initMethod.....1");

  }

  @AfterClass
  public void configuracionFinal()
  {
    // Nothing todo here.
    System.out.println("Terminando Test...");
  }

  @DataProvider(name = "initMethod1")
  public Object[][] initData() throws Exception
  {

    DatoDescrMinima nombre = new DatoDescrMinima();
    nombre.setCodtipvalor("1");
    nombre.setCodtipdescr("NE00001");
    nombre.setValtipdescri("Nombre Comercial Neum�tico");

    DatoDescrMinima ancho = new DatoDescrMinima();
    ancho.setCodtipvalor("1");
    ancho.setCodtipdescr("NE00008");
    ancho.setValtipdescri("123456.363");

    DatoDescrMinima relacionAspecto = new DatoDescrMinima();
    relacionAspecto.setCodtipvalor("1");
    relacionAspecto.setCodtipdescr("NE00009");
    relacionAspecto.setValtipdescri("relacionAspecto");

    DatoDescrMinima nomenclatura = new DatoDescrMinima();

    nomenclatura.setCodtipvalor("0");
    nomenclatura.setCodtipdescr("NE00007");
    nomenclatura.setValtipdescri("nomenclatura");

    List<DatoDescrMinima> lstDatos = new ArrayList<DatoDescrMinima>();
    lstDatos.add(nombre);
    lstDatos.add(ancho);
    lstDatos.add(relacionAspecto);
    lstDatos.add(nomenclatura);

    List<DescrPosicion> lstPosiciones = new ArrayList<DescrPosicion>();
    DescrPosicion posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00001");
    posicion.setNombreAtributoDelObjeto("nombreComercial");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00002");
    posicion.setNombreAtributoDelObjeto("marcaComercial");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00003");
    posicion.setNombreAtributoDelObjeto("modelo");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00004");
    posicion.setNombreAtributoDelObjeto("uso");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00005");
    posicion.setNombreAtributoDelObjeto("primerMaterial");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00006");
    posicion.setNombreAtributoDelObjeto("segundoMaterial");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00007");
    posicion.setNombreAtributoDelObjeto("tipoNomenclatura");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00008");
    posicion.setNombreAtributoDelObjeto("anchoSeccion");
    lstPosiciones.add(posicion);


    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00009");
    posicion.setNombreAtributoDelObjeto("relacionAspectoSerie");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00010");
    posicion.setNombreAtributoDelObjeto("diametroAro");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00011");
    posicion.setNombreAtributoDelObjeto("tipoConstruccion");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00012");
    posicion.setNombreAtributoDelObjeto("indiceCapacidadCarga");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00013");
    posicion.setNombreAtributoDelObjeto("limiteVelocidad");
    lstPosiciones.add(posicion);

    posicion = new DescrPosicion();

    posicion.setCodigoCampo("NE00014");
    posicion.setNombreAtributoDelObjeto("codigoSeguridad");
    lstPosiciones.add(posicion);

    Neumatico neumatico = new Neumatico();
    neumatico.poblar(lstDatos, lstPosiciones);
    // neumatico.addPosiciones(lstPosiciones);

    System.out.println("initMethod1.....2");


    return new Object[][] { { neumatico} };
  }


  @Test(dataProvider = "initMethod1")
  public void poblarObjetoDescrMinima(Neumatico neumatico) throws Exception
  {
    System.out.println(neumatico.toString());
    log.info("empieza1" + neumatico.toString());

    System.out.println("nombre aqui:" +
        neumatico.getNombreComercial().getCodtipdescr());
    System.out.println("ancho:" +
        neumatico.getAnchoSeccion().getCodtipdescr());
    log.info("nombre aqui22:" +
        neumatico.getNombreComercial().getCodtipdescr());
    log.info("ancho:" +
        neumatico.getAnchoSeccion().getCodtipdescr() + " valor" + neumatico.getAnchoSeccion().getValtipdescri());

    Assert.assertTrue(true);

    /*
    log.info("empieza");

    List<DatoDescrMinima> lstDatos =  neumatico.getLstDatos();
    for (DatoDescrMinima dato : lstDatos)
    {
      String codigo = dato.getCodtipdescr();
      DescrPosicion posicion = neumatico.findPosicionByCampo(codigo);
      String nombreCampo = posicion.getNombreAtributoDelObjeto();

      List<Method> list = ReflectionUtil.findSetters(Neumatico.class);
      int i =1;
      for(Method method: list){


      }

      ReflectionUtil.set(neumatico, nombreCampo, dato);*/
    /*
      Class<?> classHandle = Class.forName(className);
      Object myObject = classHandle.newInstance();
      set(myObject, "salary", 15);
      set(myObject, "firstname", "John");

      Class<?> classHandle = Class.forName(className);
Object myObject = classHandle.newInstance();
int salary = get(myObject, "salary");
String firstname = get(myObject, "firstname");
     */


  }

  /*
   * log.info("neumatico:"+neumatico.getNombreComercial().getValtipdescri());
   * log.info("neumatico:"+neumatico.getAnchoSeccion().getValtipdescri());
   * log.info
   * ("neumatico:"+neumatico.getRelacionAspectoSerie().getValtipdescri());
   * log.info("neumatico:"+neumatico.getTipoNomenclatura().getValtipdescri());
   * 
   * 
   * }
   */

  /*
   * @DataProvider(name = "initMethod1")
   * 
   * @Test public void poblarObjetoDescrMinima1(Neumatico neumatico) throws
   * Exception {
   * 
   * System.out.println("nombre aqui:" +
   * neumatico.getNombreComercial().getCodtipdescr());
   * System.out.println("ancho:" +
   * neumatico.getAnchoSeccion().getCodtipdescr()); log.info("nombre aqui22:" +
   * neumatico.getNombreComercial().getCodtipdescr()); log.info("ancho:" +
   * neumatico.getAnchoSeccion().getCodtipdescr());
   * 
   * Assert.assertTrue(true); }
   */
}
