package unit.pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.preferencias;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import pe.gob.sunat.despaduanero2.ayudas.util.ConstantesTipoCatalogo;

/**
 * Test del control de vigencias aplicado por TPI y tipo de certificado 5.
 * @author glazaror
 */
public class ControlVigenciaTipoCertificado5Test extends ControlVigenciaAbstractTest {
	
	private static List<String> serviciosTipoCertificado1NumeracionAll = Arrays.asList("3343", "3348", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3348", "3358", "3370", "3354", "3464");
	private static List<String> serviciosTipoCertificado1OtrosAll = Arrays.asList("3343", "3470", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3348", "3358", "3370", "3354", "3464");
	
	//del caso 1 al 5
	@Test
	public void testNumeracion() {
		when(catalogoAyudaService.getListaAsociado(eq(ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS), any(Date.class))).thenReturn(codigosAsociadosCatalogoNumeracion);
		List<CasoPruebaFecha> casosPruebaGenerales = getCasosNumeracion();
		ejecutarCasos("NUMERACION", casosPruebaGenerales, serviciosTipoCertificado1NumeracionAll, false);
	}
	
	//del caso 6 al 16
	@Test
	public void testOtrosProcesosRectificandoTPI() {
		when(catalogoAyudaService.getListaAsociado(eq(ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS), any(Date.class))).thenReturn(codigosAsociadosCatalogoRectificacion);
		List<CasoPruebaFecha> casosPruebaGenerales = getCasosRectificacionModificandoDatosCriticos();
		ejecutarCasos("RECTIFICACION (rectificando datos criticos del certificado)", casosPruebaGenerales, serviciosTipoCertificado1OtrosAll, true);
	}
	
	//del caso 17 al 18
	@Test
	public void testOtrosProcesosSinRectificarTPI() {
		when(catalogoAyudaService.getListaAsociado(eq(ConstantesTipoCatalogo.CATALOGO_RELACION_TLCS), any(Date.class))).thenReturn(codigosAsociadosCatalogoRectificacion);
		List<CasoPruebaFecha> casosPruebaGenerales = getCasosRectificacionSinModificarDatosCriticos();
		ejecutarCasos("RECTIFICACION (sin rectificar datos criticos del certificado)", casosPruebaGenerales, serviciosTipoCertificado1OtrosAll, false);
	}

	private List<CasoPruebaFecha> getCasosNumeracion() {
		//fecha sistema, fecha certificado, fecha numeracion 
		//PROCESO NUMERACION
		CasoPruebaFecha casoPrueba1 = new CasoPruebaFecha(1, "30/07/2016", null, null);//fecha numeracion <= 31 julio 2016
		CasoPruebaFecha casoPrueba2 = new CasoPruebaFecha(2, "30/08/2016", "20/07/2016", null);//fecha numeracion between 01 agosto 2016 y 31 diciembre 2016. fecha certificado <= 31 julio 2016
		CasoPruebaFecha casoPrueba3 = new CasoPruebaFecha(3, "30/08/2016", "10/08/2016", null);//fecha numeracion between 01 agosto 2016 y 31 diciembre 2016. fecha certificado >= 31 julio 2016
		CasoPruebaFecha casoPrueba4 = new CasoPruebaFecha(4, "20/01/2017", "20/07/2016", null);//fecha numeracion >= 01 enero 2017. fecha certificado <= 31 julio 2016
		CasoPruebaFecha casoPrueba5 = new CasoPruebaFecha(5, "20/01/2017", "10/08/2016", null);//fecha numeracion >= 01 enero 2017. fecha certificado >= 01 agosto 2016
		
		//PROCESO NUMERACION: DEL CASO 1 AL 5
		//Caso1 - Tipo certificado 5:  
		casoPrueba1.addCasoPrueba("5", Arrays.asList("3343", "3348", "3464", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3358", "3370", "3354"));
		//Caso2 - Tipo certificado 5: 
		casoPrueba2.addCasoPrueba("5", Arrays.asList("3343", "3348", "3464", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3358", "3370", "3354"));
		//Caso3 - Tipo certificado 5: 
		casoPrueba3.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		//Caso4 - Tipo certificado 5: 
		casoPrueba4.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		//Caso5 - Tipo certificado 5: 
		casoPrueba5.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		
		List<CasoPruebaFecha> casosPrueba = Arrays.asList(casoPrueba1, casoPrueba2, casoPrueba3, casoPrueba4, casoPrueba5);
		return casosPrueba;
	}
	
	private List<CasoPruebaFecha> getCasosRectificacionModificandoDatosCriticos() {
		//OTROS PROCESOS: RECTIFICANDO TPI o TIPO CERTIFICADO o FECHA CERTIFICADO
		//fecha numeracion <= 31 julio 2016
		//		fecha actual <= 31 julio 2016
		CasoPruebaFecha casoPrueba6 = new CasoPruebaFecha(6, "31/07/2016", "28/07/2016", "30/07/2016");//fecha numeracion <= 31 julio 2016, fecha actual <= 31 julio 2016
		//		fecha actual entre 01 agosto 2016 y 31 diciembre 2016
		CasoPruebaFecha casoPrueba7 = new CasoPruebaFecha(7, "04/08/2016", "28/07/2016", "31/07/2016");//fecha numeracion <= 31 julio 2016, fecha actual between 01 agosto 2016 y 31 diciembre 2016, fecha certificado <= 31 julio 2016
		CasoPruebaFecha casoPrueba8 = new CasoPruebaFecha(8, "04/08/2016", "02/08/2016", "31/07/2016");//fecha numeracion <= 31 julio 2016, fecha actual between 01 agosto 2016 y 31 diciembre 2016, fecha certificado >= 01 agosto 2016
		
		//		fecha actual >= 01 enero 2017
		CasoPruebaFecha casoPrueba9 = new CasoPruebaFecha(9, "10/01/2017", "28/07/2016", "31/07/2016");//fecha numeracion <= 31 julio 2016, fecha certificado <= 31 julio 2016
		CasoPruebaFecha casoPrueba10 = new CasoPruebaFecha(10, "10/01/2017", "15/08/2016", "31/07/2016");//fecha numeracion <= 31 julio 2016, fecha certificado >= 01 agosto 2016
		
		//fecha numeracion between 01 agosto 2016 y 31 diciembre 2016
		//		fecha actual between 01 agosto 2016 y 31 diciembre 2016
		CasoPruebaFecha casoPrueba11 = new CasoPruebaFecha(11, "20/08/2016", "15/07/2016", "10/08/2016");//fecha certificado <= 31 julio 2016
		CasoPruebaFecha casoPrueba12 = new CasoPruebaFecha(12, "20/08/2016", "07/08/2016", "10/08/2016");//fecha certificado >= 01 agosto 2016
		
		//		fecha actual >= 01 enero 2017
		CasoPruebaFecha casoPrueba13 = new CasoPruebaFecha(13, "20/01/2017", "15/07/2016", "10/08/2016");//fecha certificado <= 31 julio 2016
		CasoPruebaFecha casoPrueba14 = new CasoPruebaFecha(14, "20/01/2017", "07/08/2016", "10/08/2016");//fecha certificado >= 01 agosto 2016
		
		//fecha numeracion >= 01 enero 2017 y fecha actual >= 01 enero 2017
		CasoPruebaFecha casoPrueba15 = new CasoPruebaFecha(15, "20/01/2017", "15/07/2016", "10/01/2017");//fecha certificado <= 31 julio 2016
		CasoPruebaFecha casoPrueba16 = new CasoPruebaFecha(16, "20/01/2017", "15/08/2016", "10/01/2017");//fecha certificado >= 01 agosto 2016
		
		//Caso6 - Tipo certificado 5: 
		casoPrueba6.addCasoPrueba("5", Arrays.asList("3343", "3470", "3464", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3358", "3370", "3354"));
		//Caso7 - Tipo certificado 5: 
		casoPrueba7.addCasoPrueba("5", Arrays.asList("3343", "3470", "3464", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3358", "3370", "3354"));
		//Caso8 - Tipo certificado 5: 
		casoPrueba8.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		//Caso9 - Tipo certificado 5: 
		casoPrueba9.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		//Caso10 - Tipo certificado 5: 
		casoPrueba10.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		
		//Caso11 - Tipo certificado 5: 
		casoPrueba11.addCasoPrueba("5", Arrays.asList("3343", "3470", "3464", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3358", "3370", "3354"));
		//Caso12 - Tipo certificado 5: 
		casoPrueba12.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		//Caso13 - Tipo certificado 5: 
		casoPrueba13.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		//Caso14 - Tipo certificado 5: 
		casoPrueba14.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		//Caso15 - Tipo certificado 5: 
		casoPrueba15.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		//Caso16 - Tipo certificado 5: 
		casoPrueba16.addCasoPrueba("5", Arrays.asList("3343", "3464"));
		
		List<CasoPruebaFecha> casosPrueba = Arrays.asList(casoPrueba6, casoPrueba7, casoPrueba8, casoPrueba9, casoPrueba10, casoPrueba11, casoPrueba12, casoPrueba13, casoPrueba14, casoPrueba15, casoPrueba16);
		
		return casosPrueba;
	}
	
	private List<CasoPruebaFecha> getCasosRectificacionSinModificarDatosCriticos() {
		//OTROS PROCESOS: SIN RECTIFICAR TPI o TIPO CERTIFICADO o FECHA CERTIFICADO (casos extremos)
		//fecha numeracion <= 31 julio 2016 y fecha certificado <= 31 julio 2016 y fecha actual >= 01 enero 2017
		CasoPruebaFecha casoPrueba17 = new CasoPruebaFecha(17, "10/01/2017", "28/07/2016", "30/07/2016");
		//fecha numeracion entre 01 agosto 2016 y 31 diciembre 2016 y fecha certificado <= 31 julio 2016 y fecha actual >= 01 enero 2017
		CasoPruebaFecha casoPrueba18 = new CasoPruebaFecha(18, "10/01/2017", "28/07/2016", "10/08/2016");
		
		//Caso17 - Tipo certificado 5: 
		casoPrueba17.addCasoPrueba("5", Arrays.asList("3343", "3470", "3464", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3358", "3370", "3354"));
		//Caso18 - Tipo certificado 5: 
		casoPrueba18.addCasoPrueba("5", Arrays.asList("3343", "3470", "3464", "3339", "3340", "3341", "3399", "3453", "3419", "3332", "3381", "3380", "3382", "3383", "3358", "3370", "3354"));
		
		List<CasoPruebaFecha> casosPrueba = Arrays.asList(casoPrueba17, casoPrueba18);
		return casosPrueba;
	}
}
