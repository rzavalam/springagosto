package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.neumaticos;


import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.neumaticos.model.Neumatico;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorNeumaticosIntegration extends AbstractServiceTest {
  @Autowired
  @Qualifier("ValidadorNeumatico")
  private ValidadorNeumatico validador;

  @Autowired
  @Qualifier("framework.fabricaDeServicios")
  private FabricaDeServicios fabricaDeServicios;

  @Autowired
  @Qualifier("Ayuda.ayudaServiceCache")
  private AyudaServiceCache ayudaServiceCache;

  private Map<String,List<String>> getDuaFromXML(String filename) throws Exception{
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    Declaracion dua = new Declaracion();
    Mensaje mensaje1001;

    String numeroTransaccion = "1001";

    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

    Map<String, Object> parametros = new HashMap<String, Object>();

    parametros.put("numeroTransaccion", numeroTransaccion);

    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);

    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);

    assertNotNull(mensaje1001);
    dua = (Declaracion) mensaje1001.getDocumento();

    dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();

    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima> listaDescripcionMinimas =
        dua.getListDAVs().get(0).getListFacturas().get(0)
        .getListItems().get(0).getListDecrMinima();

    for (pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima dato : listaDescripcionMinimas)
    {
      List<String> data = new ArrayList<String>();
      data.add(0, dato.getCodtipvalor());
      data.add(1,dato.getValtipdescri());
      valores.put(dato.getCodtipdescr(), data);
    }
    return valores;
  }

  @DataProvider ( name = "aduamerica_caso93")
  private Object[][] aduanamerica_caso93() throws Exception{
    Neumatico neumatico              = new Neumatico();

    DatoDescrMinima nombreProducto   = new DatoDescrMinima();
    DatoDescrMinima marcaProducto    = new DatoDescrMinima();
    DatoDescrMinima modeloProducto   = new DatoDescrMinima();
    DatoDescrMinima usoComercial     = new DatoDescrMinima();
    DatoDescrMinima materialCarcasa  = new DatoDescrMinima();
    DatoDescrMinima nomenclatura     = new DatoDescrMinima();
    DatoDescrMinima anchoSeccion     = new DatoDescrMinima();
    DatoDescrMinima serie            = new DatoDescrMinima();
    DatoDescrMinima diametro         = new DatoDescrMinima();
    DatoDescrMinima tipoConstruccion = new DatoDescrMinima();
    DatoDescrMinima indiceCarga      = new DatoDescrMinima();
    DatoDescrMinima codigoVelocidad  = new DatoDescrMinima();
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlNeumaticos/XML_NEUMATICOS_CP01.xml";
    valores = getDuaFromXML(filename);

    nombreProducto.setCodtipvalor(valores.get("NE0001").get(0));
    nombreProducto.setCodtipdescr("NE0001");
    nombreProducto.setValtipdescri(valores.get("NE0001").get(1));

    marcaProducto.setCodtipvalor(valores.get("NE0002").get(0));
    marcaProducto.setCodtipdescr("NE0002");
    marcaProducto.setValtipdescri(valores.get("NE0002").get(1));

    modeloProducto.setCodtipvalor(valores.get("NE0003").get(0));
    modeloProducto.setCodtipdescr("NE0003");
    modeloProducto.setValtipdescri(valores.get("NE0003").get(1));

    usoComercial.setCodtipvalor(valores.get("NE0004").get(0));
    usoComercial.setCodtipdescr("NE0004");
    usoComercial.setValtipdescri(valores.get("NE0004").get(1));

    materialCarcasa.setCodtipvalor(valores.get("NE0005").get(0));
    materialCarcasa.setCodtipdescr("NE0005");
    materialCarcasa.setValtipdescri(valores.get("NE0005").get(1));

    nomenclatura.setCodtipvalor(valores.get("NE0007").get(0));
    nomenclatura.setCodtipdescr("NE0007");
    nomenclatura.setValtipdescri(valores.get("NE0007").get(1));

    anchoSeccion.setCodtipvalor(valores.get("NE0008").get(0));
    anchoSeccion.setCodtipdescr("NE0008");
    anchoSeccion.setValtipdescri(valores.get("NE0008").get(1));

    serie.setCodtipvalor(valores.get("NE0009").get(0));
    serie.setCodtipdescr("NE0009");
    serie.setValtipdescri(valores.get("NE0009").get(1));

    diametro.setCodtipvalor(valores.get("NE0010").get(0));
    diametro.setCodtipdescr("NE0010");
    diametro.setValtipdescri(valores.get("NE0010").get(1));

    tipoConstruccion.setCodtipvalor(valores.get("NE0011").get(0));
    tipoConstruccion.setCodtipdescr("NE0011");
    tipoConstruccion.setValtipdescri(valores.get("NE0011").get(1));

    indiceCarga.setCodtipvalor(valores.get("NE0012").get(0));
    indiceCarga.setCodtipdescr("NE0012");
    indiceCarga.setValtipdescri(valores.get("NE0012").get(1));

    codigoVelocidad.setCodtipvalor(valores.get("NE0013").get(0));
    codigoVelocidad.setCodtipdescr("NE0013");
    codigoVelocidad.setValtipdescri(valores.get("NE0013").get(1));

    neumatico.setNombreComercial(nombreProducto);
    neumatico.setMarcaComercial(marcaProducto);
    neumatico.setModelo(modeloProducto);
    neumatico.setUso(usoComercial);
    neumatico.setPrimerMaterial(materialCarcasa);
    neumatico.setTipoNomenclatura(nomenclatura);
    neumatico.setAnchoSeccion(anchoSeccion);
    neumatico.setRelacionAspectoSerie(serie);
    neumatico.setDiametroAro(diametro);
    neumatico.setTipoConstruccion(tipoConstruccion);
    neumatico.setIndiceCapacidadCarga(indiceCarga);
    neumatico.setLimiteVelocidad(codigoVelocidad);

    return new Object[][]{{neumatico}};
  }

  @Test(dataProvider="aduamerica_caso93")
  public void validarUsoAduamerica_caso93Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarUso(neumatico),lstError);
  }

  @Test(dataProvider="aduamerica_caso93")
  public void validarAnchoSeccionAduamerica_caso93Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAnchoSeccion(neumatico),lstError);
  }

  @Test(dataProvider="aduamerica_caso93")
  public void validarAspectoSerieAduamerica_caso93Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarRelacionAspectoSerie(neumatico),lstError);
  }

  @DataProvider ( name = "aduamerica_caso94")
  private Object[][] aduanamerica_caso94() throws Exception{
    Neumatico neumatico = new Neumatico();

    DatoDescrMinima nombreProducto    = new DatoDescrMinima();
    DatoDescrMinima marcaProducto     = new DatoDescrMinima();
    DatoDescrMinima modeloProducto    = new DatoDescrMinima();
    DatoDescrMinima usoComercial      = new DatoDescrMinima();
    DatoDescrMinima materialCarcasa   = new DatoDescrMinima();
    DatoDescrMinima tipoNomenclatura  = new DatoDescrMinima();
    DatoDescrMinima anchoSeccion      = new DatoDescrMinima();
    DatoDescrMinima serie             = new DatoDescrMinima();
    DatoDescrMinima diametro          = new DatoDescrMinima();
    DatoDescrMinima tipoConstruccion  = new DatoDescrMinima();
    DatoDescrMinima indiceCarga       = new DatoDescrMinima();
    DatoDescrMinima codigoVelocidad   = new DatoDescrMinima();
    Map<String,List<String>> valores  = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlNeumaticos/XML_NEUMATICOS_CP02.xml";
    valores = getDuaFromXML(filename);


    nombreProducto.setCodtipvalor(valores.get("NE0001").get(0));
    nombreProducto.setCodtipdescr("NE0001");
    nombreProducto.setValtipdescri(valores.get("NE0001").get(1));

    marcaProducto.setCodtipvalor(valores.get("NE0002").get(0));
    marcaProducto.setCodtipdescr("NE0002");
    marcaProducto.setValtipdescri(valores.get("NE0002").get(1));

    modeloProducto.setCodtipvalor(valores.get("NE0003").get(0));
    modeloProducto.setCodtipdescr("NE0003");
    modeloProducto.setValtipdescri(valores.get("NE0003").get(1));

    usoComercial.setCodtipvalor(valores.get("NE0004").get(0));
    usoComercial.setCodtipdescr("NE0004");
    usoComercial.setValtipdescri(valores.get("NE0004").get(1));

    materialCarcasa.setCodtipvalor(valores.get("NE0005").get(0));
    materialCarcasa.setCodtipdescr("NE0005");
    materialCarcasa.setValtipdescri(valores.get("NE0005").get(1));

    tipoNomenclatura.setCodtipvalor(valores.get("NE0007").get(0));
    tipoNomenclatura.setCodtipdescr("NE0007");
    tipoNomenclatura.setValtipdescri(valores.get("NE0007").get(1));

    anchoSeccion.setCodtipvalor(valores.get("NE0008").get(0));
    anchoSeccion.setCodtipdescr("NE0008");
    anchoSeccion.setValtipdescri(valores.get("NE0008").get(1));

    serie.setCodtipvalor(valores.get("NE0009").get(0));
    serie.setCodtipdescr("NE0009");
    serie.setValtipdescri(valores.get("NE0009").get(1));

    diametro.setCodtipvalor(valores.get("NE0010").get(0));
    diametro.setCodtipdescr("NE0010");
    diametro.setValtipdescri(valores.get("NE0010").get(1));

    tipoConstruccion.setCodtipvalor(valores.get("NE0011").get(0));
    tipoConstruccion.setCodtipdescr("NE0011");
    tipoConstruccion.setValtipdescri(valores.get("NE0011").get(1));

    indiceCarga.setCodtipvalor(valores.get("NE0012").get(0));
    indiceCarga.setCodtipdescr("NE0012");
    indiceCarga.setValtipdescri(valores.get("NE0012").get(1));

    codigoVelocidad.setCodtipvalor(valores.get("NE0013").get(0));
    codigoVelocidad.setCodtipdescr("NE0013");
    codigoVelocidad.setValtipdescri(valores.get("NE0013").get(1));

    neumatico.setNombreComercial(nombreProducto);
    neumatico.setMarcaComercial(marcaProducto);
    neumatico.setModelo(modeloProducto);
    neumatico.setUso(usoComercial);
    neumatico.setPrimerMaterial(materialCarcasa);
    neumatico.setTipoNomenclatura(tipoNomenclatura);
    neumatico.setAnchoSeccion(anchoSeccion);
    neumatico.setRelacionAspectoSerie(serie);
    neumatico.setDiametroAro(diametro);
    neumatico.setTipoConstruccion(tipoConstruccion);
    neumatico.setIndiceCapacidadCarga(indiceCarga);
    neumatico.setLimiteVelocidad(codigoVelocidad);

    return new Object[][]{{ neumatico }};
  }

  @Test(dataProvider="aduamerica_caso94")
  public void validarAnchoSeccionAduamerica_caso94Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAnchoSeccion(neumatico),lstError);
  }

  @Test(dataProvider="aduamerica_caso94")
  public void validarAspectoSerieAduamerica_caso94Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarRelacionAspectoSerie(neumatico),lstError);
  }

  @DataProvider ( name = "aduamerica_caso95")
  private Object[][] aduanamerica_caso95() throws Exception{
    Neumatico neumatico = new Neumatico();

    DatoDescrMinima nombreProducto   = new DatoDescrMinima();
    DatoDescrMinima marcaProducto    = new DatoDescrMinima();
    DatoDescrMinima modeloProducto   = new DatoDescrMinima();
    DatoDescrMinima usoComercial     = new DatoDescrMinima();
    DatoDescrMinima materialCarcasa  = new DatoDescrMinima();
    DatoDescrMinima tipoNomenclatura = new DatoDescrMinima();
    DatoDescrMinima anchoSeccion     = new DatoDescrMinima();
    DatoDescrMinima serie            = new DatoDescrMinima();
    DatoDescrMinima diametro         = new DatoDescrMinima();
    DatoDescrMinima tipoConstruccion = new DatoDescrMinima();
    DatoDescrMinima indiceCarga      = new DatoDescrMinima();
    DatoDescrMinima codigoVelocidad  = new DatoDescrMinima();

    Map<String,List<String>> valores = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlNeumaticos/XML_NEUMATICOS_CP03.xml";
    valores = getDuaFromXML(filename);

    nombreProducto.setCodtipvalor(valores.get("NE0001").get(0));
    nombreProducto.setCodtipdescr("NE0001");
    nombreProducto.setValtipdescri(valores.get("NE0001").get(1));

    marcaProducto.setCodtipvalor(valores.get("NE0002").get(0));
    marcaProducto.setCodtipdescr("NE0002");
    marcaProducto.setValtipdescri(valores.get("NE0002").get(1));

    modeloProducto.setCodtipvalor(valores.get("NE0003").get(0));
    modeloProducto.setCodtipdescr("NE0003");
    modeloProducto.setValtipdescri(valores.get("NE0003").get(1));

    usoComercial.setCodtipvalor(valores.get("NE0004").get(0));
    usoComercial.setCodtipdescr("NE0004");
    usoComercial.setValtipdescri(valores.get("NE0004").get(1));

    materialCarcasa.setCodtipvalor(valores.get("NE0005").get(0));
    materialCarcasa.setCodtipdescr("NE0005");
    materialCarcasa.setValtipdescri(valores.get("NE0005").get(1));

    tipoNomenclatura.setCodtipvalor(valores.get("NE0007").get(0));
    tipoNomenclatura.setCodtipdescr("NE0007");
    tipoNomenclatura.setValtipdescri(valores.get("NE0007").get(1));

    anchoSeccion.setCodtipvalor(valores.get("NE0008").get(0));
    anchoSeccion.setCodtipdescr("NE0008");
    anchoSeccion.setValtipdescri(valores.get("NE0008").get(1));

    serie.setCodtipvalor(valores.get("NE0009").get(0));
    serie.setCodtipdescr("NE0009");
    serie.setValtipdescri(valores.get("NE0009").get(1));

    diametro.setCodtipvalor(valores.get("NE0010").get(0));
    diametro.setCodtipdescr("NE0010");
    diametro.setValtipdescri(valores.get("NE0010").get(1));

    tipoConstruccion.setCodtipvalor(valores.get("NE0011").get(0));
    tipoConstruccion.setCodtipdescr("NE0011");
    tipoConstruccion.setValtipdescri(valores.get("NE0011").get(1));

    indiceCarga.setCodtipvalor(valores.get("NE0012").get(0));
    indiceCarga.setCodtipdescr("NE0012");
    indiceCarga.setValtipdescri(valores.get("NE0012").get(1));

    codigoVelocidad.setCodtipvalor(valores.get("NE0013").get(0));
    codigoVelocidad.setCodtipdescr("NE0013");
    codigoVelocidad.setValtipdescri(valores.get("NE0013").get(1));

    neumatico.setNombreComercial(nombreProducto);
    neumatico.setMarcaComercial(marcaProducto);
    neumatico.setModelo(modeloProducto);
    neumatico.setUso(usoComercial);
    neumatico.setPrimerMaterial(materialCarcasa);
    neumatico.setTipoNomenclatura(tipoNomenclatura);
    neumatico.setAnchoSeccion(anchoSeccion);
    neumatico.setRelacionAspectoSerie(serie);
    neumatico.setDiametroAro(diametro);
    neumatico.setTipoConstruccion(tipoConstruccion);
    neumatico.setIndiceCapacidadCarga(indiceCarga);
    neumatico.setLimiteVelocidad(codigoVelocidad);

    return new Object[][]{{neumatico}};
  }

  @Test (dataProvider = "aduamerica_caso95")
  public void validarAnchoSeccionAduamerica_caso95Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAnchoSeccion(neumatico),lstError);
  }

  @Test(dataProvider="aduamerica_caso95")
  public void validarAspectoSerieAduamerica_caso95Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarRelacionAspectoSerie(neumatico),lstError);
  }

  @DataProvider (name = "aduamerica_caso96")
  private Object[][] aduamerica_caso96() throws Exception{
    Neumatico neumatico               = new Neumatico();
    DatoDescrMinima nombreProducto    = new DatoDescrMinima();
    DatoDescrMinima marcaProducto     = new DatoDescrMinima();
    DatoDescrMinima modeloProducto    = new DatoDescrMinima();
    DatoDescrMinima usoComercial      = new DatoDescrMinima();
    DatoDescrMinima materialCarcasa   = new DatoDescrMinima();
    DatoDescrMinima tipoNomenclatura  = new DatoDescrMinima();
    DatoDescrMinima anchoSeccion      = new DatoDescrMinima();
    DatoDescrMinima serie             = new DatoDescrMinima();
    DatoDescrMinima diametro          = new DatoDescrMinima();
    DatoDescrMinima tipoConstruccion  = new DatoDescrMinima();
    DatoDescrMinima indiceCarga       = new DatoDescrMinima();
    DatoDescrMinima codigoVelocidad   = new DatoDescrMinima();

    Map<String,List<String>> valores  = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlNeumaticos/XML_NEUMATICOS_CP04.xml";
    valores = getDuaFromXML(filename);

    nombreProducto.setCodtipvalor(valores.get("NE0001").get(0));
    nombreProducto.setCodtipdescr("NE0001");
    nombreProducto.setValtipdescri(valores.get("NE0001").get(1));

    marcaProducto.setCodtipvalor(valores.get("NE0002").get(0));
    marcaProducto.setCodtipdescr("NE0002");
    marcaProducto.setValtipdescri(valores.get("NE0002").get(1));

    modeloProducto.setCodtipvalor(valores.get("NE0003").get(0));
    modeloProducto.setCodtipdescr("NE0003");
    modeloProducto.setValtipdescri(valores.get("NE0003").get(1));

    usoComercial.setCodtipvalor(valores.get("NE0004").get(0));
    usoComercial.setCodtipdescr("NE0004");
    usoComercial.setValtipdescri(valores.get("NE0004").get(1));

    materialCarcasa.setCodtipvalor(valores.get("NE0005").get(0));
    materialCarcasa.setCodtipdescr("NE0005");
    materialCarcasa.setValtipdescri(valores.get("NE0005").get(1));

    tipoNomenclatura.setCodtipvalor(valores.get("NE0007").get(0));
    tipoNomenclatura.setCodtipdescr("NE0007");
    tipoNomenclatura.setValtipdescri(valores.get("NE0007").get(1));

    anchoSeccion.setCodtipvalor(valores.get("NE0008").get(0));
    anchoSeccion.setCodtipdescr("NE0008");
    anchoSeccion.setValtipdescri(valores.get("NE0008").get(1));

    serie.setCodtipvalor(valores.get("NE0009").get(0));
    serie.setCodtipdescr("NE0009");
    serie.setValtipdescri(valores.get("NE0009").get(1));

    diametro.setCodtipvalor(valores.get("NE0010").get(0));
    diametro.setCodtipdescr("NE0010");
    diametro.setValtipdescri(valores.get("NE0010").get(1));

    tipoConstruccion.setCodtipvalor(valores.get("NE0011").get(0));
    tipoConstruccion.setCodtipdescr("NE0011");
    tipoConstruccion.setValtipdescri(valores.get("NE0011").get(1));

    indiceCarga.setCodtipvalor(valores.get("NE0012").get(0));
    indiceCarga.setCodtipdescr("NE0012");
    indiceCarga.setValtipdescri(valores.get("NE0012").get(1));

    codigoVelocidad.setCodtipvalor(valores.get("NE0013").get(0));
    codigoVelocidad.setCodtipdescr("NE0013");
    codigoVelocidad.setValtipdescri(valores.get("NE0013").get(1));

    neumatico.setNombreComercial(nombreProducto);
    neumatico.setMarcaComercial(marcaProducto);
    neumatico.setModelo(modeloProducto);
    neumatico.setUso(usoComercial);
    neumatico.setPrimerMaterial(materialCarcasa);
    neumatico.setTipoNomenclatura(tipoNomenclatura);
    neumatico.setAnchoSeccion(anchoSeccion);
    neumatico.setRelacionAspectoSerie(serie);
    neumatico.setDiametroAro(diametro);
    neumatico.setTipoConstruccion(tipoConstruccion);
    neumatico.setIndiceCapacidadCarga(indiceCarga);
    neumatico.setLimiteVelocidad(codigoVelocidad);

    return new Object[][]{{ neumatico }};
  }

  @Test (dataProvider = "aduamerica_caso96")
  public void validarAnchoSeccionAduamerica_caso96Test(ModelAbstract neumatico){
    Assert.assertEquals(validador.validarAnchoSeccion(neumatico).size(),1);
  }

  @Test(dataProvider="aduamerica_caso96")
  public void validarAspectoSerieAduamerica_caso96Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarRelacionAspectoSerie(neumatico),lstError);
  }

  @DataProvider (name="aduamerica_caso97")
  private Object[][] aduamerica_caso97() throws Exception{
    Neumatico neumatico                = new Neumatico();
    DatoDescrMinima nombreProducto     = new DatoDescrMinima();
    DatoDescrMinima marcaProducto      = new DatoDescrMinima();
    DatoDescrMinima modeloProducto     = new DatoDescrMinima();
    DatoDescrMinima usoComercial       = new DatoDescrMinima();
    DatoDescrMinima materialCarcasa    = new DatoDescrMinima();
    DatoDescrMinima tipoNomenclatura   = new DatoDescrMinima();
    DatoDescrMinima anchoSeccion       = new DatoDescrMinima();
    DatoDescrMinima serie              = new DatoDescrMinima();
    DatoDescrMinima diametro           = new DatoDescrMinima();
    DatoDescrMinima tipoConstruccion   = new DatoDescrMinima();
    DatoDescrMinima indiceCarga        = new DatoDescrMinima();
    DatoDescrMinima codigoVelocidad    = new DatoDescrMinima();

    Map<String,List<String>> valores   = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlNeumaticos/XML_NEUMATICOS_CP05.xml";
    valores = getDuaFromXML(filename);

    nombreProducto.setCodtipvalor(valores.get("NE0001").get(0));
    nombreProducto.setCodtipdescr("NE0001");
    nombreProducto.setValtipdescri(valores.get("NE0001").get(1));

    marcaProducto.setCodtipvalor(valores.get("NE0002").get(0));
    marcaProducto.setCodtipdescr("NE0002");
    marcaProducto.setValtipdescri(valores.get("NE0002").get(1));

    modeloProducto.setCodtipvalor(valores.get("NE0003").get(0));
    modeloProducto.setCodtipdescr("NE0003");
    modeloProducto.setValtipdescri(valores.get("NE0003").get(1));

    usoComercial.setCodtipvalor(valores.get("NE0004").get(0));
    usoComercial.setCodtipdescr("NE0004");
    usoComercial.setValtipdescri(valores.get("NE0004").get(1));

    materialCarcasa.setCodtipvalor(valores.get("NE0005").get(0));
    materialCarcasa.setCodtipdescr("NE0005");
    materialCarcasa.setValtipdescri(valores.get("NE0005").get(1));

    tipoNomenclatura.setCodtipvalor(valores.get("NE0007").get(0));
    tipoNomenclatura.setCodtipdescr("NE0007");
    tipoNomenclatura.setValtipdescri(valores.get("NE0007").get(1));

    anchoSeccion.setCodtipvalor(valores.get("NE0007").get(0));
    anchoSeccion.setCodtipdescr("NE0008");
    anchoSeccion.setValtipdescri(valores.get("NE0008").get(1));

    serie.setCodtipvalor(valores.get("NE0009").get(0));
    serie.setCodtipdescr("NE0009");
    serie.setValtipdescri(valores.get("NE0009").get(1));

    diametro.setCodtipvalor(valores.get("NE0010").get(0));
    diametro.setCodtipdescr("NE0010");
    diametro.setValtipdescri(valores.get("NE0010").get(1));

    tipoConstruccion.setCodtipvalor(valores.get("NE0011").get(0));
    tipoConstruccion.setCodtipdescr("NE0011");
    tipoConstruccion.setValtipdescri(valores.get("NE0011").get(1));

    indiceCarga.setCodtipvalor(valores.get("NE0012").get(0));
    indiceCarga.setCodtipdescr("NE0012");
    indiceCarga.setValtipdescri(valores.get("NE0012").get(1));

    codigoVelocidad.setCodtipvalor(valores.get("NE0013").get(0));
    codigoVelocidad.setCodtipdescr("NE0013");
    codigoVelocidad.setValtipdescri(valores.get("NE0013").get(1));

    neumatico.setNombreComercial(nombreProducto);
    neumatico.setMarcaComercial(marcaProducto);
    neumatico.setModelo(modeloProducto);
    neumatico.setUso(usoComercial);
    neumatico.setPrimerMaterial(materialCarcasa);
    neumatico.setTipoNomenclatura(tipoNomenclatura);
    neumatico.setAnchoSeccion(anchoSeccion);
    neumatico.setRelacionAspectoSerie(serie);
    neumatico.setDiametroAro(diametro);
    neumatico.setTipoConstruccion(tipoConstruccion);
    neumatico.setIndiceCapacidadCarga(indiceCarga);
    neumatico.setLimiteVelocidad(codigoVelocidad);

    return new Object[][]{{ neumatico }};
  }

  @Test (dataProvider = "aduamerica_caso97")
  public void validarAnchoSeccionAduamerica_caso97Test(ModelAbstract neumatico){
    Assert.assertEquals(validador.validarAnchoSeccion(neumatico).size(),1);
  }

  @Test(dataProvider="aduamerica_caso97")
  public void validarAspectoSerieAduamerica_caso97Test(ModelAbstract neumatico){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarRelacionAspectoSerie(neumatico),lstError);
  }
}
