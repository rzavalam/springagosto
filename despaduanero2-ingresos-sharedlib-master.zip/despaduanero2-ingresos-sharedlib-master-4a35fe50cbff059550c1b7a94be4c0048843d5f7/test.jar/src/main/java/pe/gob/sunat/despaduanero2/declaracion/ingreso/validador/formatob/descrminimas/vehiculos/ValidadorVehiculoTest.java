package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.vehiculos;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorVehiculoTest extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorVehiculo")
  private ValidadorVehiculo validador;

  public static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
  private Vehiculo          vehiculo;
  private Declaracion		declaracion;

  @BeforeClass
  public void initData() throws Exception{
    System.out.println("LOAD TEST UNITARIOS ...");

    Vehiculo vehiculo = new Vehiculo();
    Declaracion declaracion = new Declaracion();
    DUA dua = new DUA();
    DatoSerie datoserie = new DatoSerie();
    DatoRegPrecedencia datoregprecedencia = new DatoRegPrecedencia();
    // CodRegimenPrecedente
    datoregprecedencia.setCodregipre("91");
    //Trato preferencial
    Elementos<DatoSerie> listDatoSerie = new Elementos<DatoSerie>();
    Elementos<DatoSerieItem> listSerieItems = new Elementos<DatoSerieItem>();
    Elementos<DatoRegPrecedencia> listRegPrecedencia = new Elementos<DatoRegPrecedencia>();
    listRegPrecedencia.add(datoregprecedencia);
    datoserie.setListRegPrecedencia(listRegPrecedencia);
    //Trato preferencial
    datoserie.setCodtratprefe(100); // ítem de la serie que le corresponde
    // Codestamer
    datoserie.setCodestamerca("20");
    // paisOrigen
    datoserie.setCodpaisorige("JP");
    //numSerie
    datoserie.setNumserie(123);
    listDatoSerie.add(datoserie);
    dua.setListSeries(listDatoSerie);
    //fechaNumeracion
    Integer year = 2010;
    Date fecNumeracion = sdf.parse("2010-01-01");
    fecNumeracion.setYear(year);
    dua.setFecNumeracion(fecNumeracion);
    //fechaTermino
    Date fechaTermino = sdf.parse("2013-01-01");
    DatoManifiesto manif = new DatoManifiesto();
    manif.setFectermino(fechaTermino);
    dua.setManifiesto(manif);
    //Fechaembarque
    Date fecembarque01 = sdf.parse("2013-01-01");
    Date fecembarque02 = sdf.parse("2012-08-01");
    Elementos<DatoDocTransporte> ListDocumentos = new Elementos<DatoDocTransporte>();
    DatoDocTransporte documento1 = new DatoDocTransporte();
    documento1.setFecembarque(fecembarque01);
    DatoDocTransporte documento2 = new DatoDocTransporte();
    documento2.setFecembarque(fecembarque02);
    ListDocumentos.add(documento1);
    ListDocumentos.add(documento2);
    dua.setListDocTransporte(ListDocumentos);
    //TipoParticipante
    DataCatalogo cod_participante = new DataCatalogo();
    cod_participante.setCodDatacat("45");
    Participante participante =  new Participante();
    participante.setTipoParticipante(cod_participante);
    dua.setDeclarante(participante);
    //Codigo Aduana
    dua.setCodaduanaorden("018");
    //Numero Documento
    dua.setNumdocumento("12656845");
    declaracion.setDua(dua);

    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumsecitem(3);
    // Año fabrica
    item.setAnnfabrica("2013");
    //Estado mercancia
    item.setCodestamer("20");
    // paisOrigen
    item.setCodpaisorige("JP");

    DatoSerieItem datoSerieItem = new DatoSerieItem();
    datoSerieItem.setNumserie(123);
    listSerieItems.add(datoSerieItem);
    item.setListSerieItems(listSerieItems);
    lstitem.add(item);
    factu.setListItems(lstitem);
    lstFactu.add(factu);
    dav.setListFacturas(lstFactu);
    listDAVs.add(dav);
    declaracion.setListDAVs(listDAVs);

    //Nombre comercial = Categoria
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    nombreComercial.setValtipdescri("M2"); // L1/L2/L3/L4/L5/M/M1/M2/M3/N/N1/N2/N3/O/O1/O2/O3/O4
    nombreComercial.setNumsecitem(3);
    vehiculo.setNombreComercial(nombreComercial);
    //Carroceria
    DatoDescrMinima carroceria = new DatoDescrMinima();
    carroceria.setValtipdescri("BAD"); //001,863,AMB,ARE,ART,ASF,AUX,BAD,BAR,BHO,BIA,BMT,BOB,BOM,CAB,CAN.CBA,CCG,CEL,CHC,CHM...
    vehiculo.setCarroceria(carroceria);
    //Marca Comercial
    DatoDescrMinima marcaComercial = new DatoDescrMinima();
    marcaComercial.setValtipdescri("5R"); //001,5R,A-1,A1,AAA,AAC,LAN,LCA,LCH,LCN,ZYX,ZZZ,min
    vehiculo.setMarcaComercial(marcaComercial);
    //Modelo
    DatoDescrMinima modelo = new DatoDescrMinima();
    modelo.setValtipdescri("G25"); //001,002,003,004,005,006,007,008,009,00A,00B,00C...
    vehiculo.setModelo(modelo);
    //ColorPrincipal
    DatoDescrMinima colorPrincipal = new DatoDescrMinima();
    colorPrincipal.setValtipdescri("AMA"); //868,AMA,ANA,AZU,BEI,BLA,CEL,CRE,DOR,FUC....
    vehiculo.setColorPrincipal(colorPrincipal);
    //ColorSecundario
    DatoDescrMinima colorSecundario = new DatoDescrMinima();
    colorSecundario.setValtipdescri("FUC"); //868,AMA,ANA,AZU,BEI,BLA,CEL,CRE,DOR,FUC....
    vehiculo.setColorSecundario(colorSecundario);
    //numeroHomologacionMTC
    DatoDescrMinima numeroHomologacionMTC = new DatoDescrMinima();
    numeroHomologacionMTC.setValtipdescri("ABCDE12345"); //NO HAY CATALOGO
    vehiculo.setNumeroHomologacionMTC(numeroHomologacionMTC);
    //IndicadorSNTT
    DatoDescrMinima indicadorSNTT = new DatoDescrMinima();
    indicadorSNTT.setValtipdescri("0"); //0,1
    vehiculo.setIndicadorSNTT(indicadorSNTT);
    //TipoCombustible
    DatoDescrMinima tipoCombustible = new DatoDescrMinima();
    tipoCombustible.setValtipdescri(""); //ACE,BDS,BIE,BIL,BIN,CCO,DSL,DUE,DUL,DUN,ELT,ETA,FLX,GLP,GNL,GNV,GSL,HDB,HGB,HID,SOL
    vehiculo.setTipoCombustible(tipoCombustible);
    //Categoria
    DatoDescrMinima categoria = new DatoDescrMinima();
    categoria.setValtipdescri("M2"); // L1/L2/L3/L4/L5/M/M1/M2/M3/N/N1/N2/N3/O/O1/O2/O3/O4
    vehiculo.setCategoria(categoria);
    //NumeroChasis
    DatoDescrMinima numeroChasis = new DatoDescrMinima();
    numeroChasis.setValtipdescri("CHM"); //NO HAY CATALOGO
    vehiculo.setNumeroChasis(numeroChasis);
    //Version
    DatoDescrMinima version = new DatoDescrMinima();
    version.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setVersion(version);
    //NumeroCilindros
    DatoDescrMinima numeroCilindros = new DatoDescrMinima();
    numeroCilindros.setValtipdescri("0"); //NO HAY CATALOGO
    vehiculo.setNumeroCilindros(numeroCilindros);
    //TipoMoto
    DatoDescrMinima tipoMoto = new DatoDescrMinima();
    tipoMoto.setValtipdescri(""); //DCD,TTR,PIS,CRU,SCO
    vehiculo.setTipoMoto(tipoMoto);
    //CilindradaCC
    DatoDescrMinima cilindradaCC = new DatoDescrMinima();
    cilindradaCC.setValtipdescri("30"); //NO HAY CATALOGO
    vehiculo.setCilindradaCC(cilindradaCC);
    //TipoEncendido
    DatoDescrMinima tipoEncendido = new DatoDescrMinima();
    tipoEncendido.setValtipdescri(""); //CHI,COM,ZZZ
    //tipoEncendido.setCodtipvalor("CAMPOENCENDIDO123452"); //NO HAY CATALOGO
    vehiculo.setTipoEncendido(tipoEncendido);
    //NumeroAsientos
    DatoDescrMinima numeroAsientos = new DatoDescrMinima();
    numeroAsientos.setValtipdescri("8"); //NO HAY CATALOGO
    vehiculo.setNumeroAsientos(numeroAsientos);
    //CantidadEjes
    DatoDescrMinima cantidadEjes = new DatoDescrMinima();
    cantidadEjes.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setCantidadEjes(cantidadEjes);
    //FormulaRodante - TipoTraccion
    DatoDescrMinima tipoTraccion = new DatoDescrMinima();
    tipoTraccion.setValtipdescri(""); //104,108,2X1,3X1,3X2,4X2,4X4,62B,62C,6X2,6X4,6X6,824,826,84B,84C,864,8x2,8X4
    vehiculo.setTipoTraccion(tipoTraccion);
    //NumeroMotor
    DatoDescrMinima numeroMotor = new DatoDescrMinima();
    numeroMotor.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setNumeroMotor(numeroMotor);
    //PesoMaximoEjeDelantero
    DatoDescrMinima pesoMaximoEjeDelantero = new DatoDescrMinima();
    pesoMaximoEjeDelantero.setValtipdescri("16000"); //NO HAY CATALOGO
    vehiculo.setPesoMaximoEjeDelantero(pesoMaximoEjeDelantero);
    //PesoMaximoEjePosterior1
    DatoDescrMinima pesoMaximoEjePosterior1 = new DatoDescrMinima();
    pesoMaximoEjePosterior1.setValtipdescri("24000"); //NO HAY CATALOGO
    vehiculo.setPesoMaximoEjePosterior1(pesoMaximoEjePosterior1);
    //PesoMaximoEjePosterior2
    DatoDescrMinima pesoMaximoEjePosterior2 = new DatoDescrMinima();
    pesoMaximoEjePosterior2.setValtipdescri("26000"); //NO HAY CATALOGO
    vehiculo.setPesoMaximoEjePosterior2(pesoMaximoEjePosterior2);
    //PesoMaximoEjePosterior3
    DatoDescrMinima pesoMaximoEjePosterior3 = new DatoDescrMinima();
    pesoMaximoEjePosterior3.setValtipdescri("23000"); //NO HAY CATALOGO
    vehiculo.setPesoMaximoEjePosterior3(pesoMaximoEjePosterior3);
    //LargoMM
    DatoDescrMinima largoMM = new DatoDescrMinima();
    largoMM.setValtipdescri("24000"); //NO HAY CATALOGO
    vehiculo.setLargoMM(largoMM);
    //AnchoMM
    DatoDescrMinima anchoMM = new DatoDescrMinima();
    anchoMM.setValtipdescri("27000"); //NO HAY CATALOGO
    vehiculo.setAnchoMM(anchoMM);
    //AltoMM
    DatoDescrMinima altoMM = new DatoDescrMinima();
    altoMM.setValtipdescri("4301"); //NO HAY CATALOGO
    vehiculo.setAltoMM(altoMM);
    //NumeroCambiosDeCaja
    DatoDescrMinima numeroCambiosDeCaja = new DatoDescrMinima();
    numeroCambiosDeCaja.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setNumeroCambiosDeCaja(numeroCambiosDeCaja);
    //RelacionPotenciaPesoBruto
    DatoDescrMinima relacionPotenciaPesoBruto = new DatoDescrMinima();
    relacionPotenciaPesoBruto.setValtipdescri("3.15"); //NO HAY CATALOGO
    vehiculo.setRelacionPotenciaPesoBruto(relacionPotenciaPesoBruto);
    //PesoBrutoCombinado
    DatoDescrMinima pesoBrutoCombinado = new DatoDescrMinima();
    pesoBrutoCombinado.setValtipdescri("1000,20"); //NO HAY CATALOGO
    vehiculo.setPesoBrutoCombinado(pesoBrutoCombinado);
    //PesoBrutoKG
    DatoDescrMinima pesoBrutoKG = new DatoDescrMinima();
    pesoBrutoKG.setValtipdescri("1234569"); //NO HAY CATALOGO
    vehiculo.setPesoBrutoKG(pesoBrutoKG);
    //PesoNetoKG
    DatoDescrMinima pesoNetoKG = new DatoDescrMinima();
    pesoNetoKG.setValtipdescri("1234567"); //NO HAY CATALOGO
    vehiculo.setPesoNetoKG(pesoNetoKG);
    //CargaUtilKG
    DatoDescrMinima cargaUtilKG = new DatoDescrMinima();
    cargaUtilKG.setValtipdescri("60"); //NO HAY CATALOGO
    vehiculo.setCargaUtilKG(cargaUtilKG);
    //NumeroPasajeros
    DatoDescrMinima numeroPasajeros = new DatoDescrMinima();
    numeroPasajeros.setValtipdescri("7"); //NO HAY CATALOGO
    vehiculo.setNumeroPasajeros(numeroPasajeros);
    //PotenciaMotorKW
    DatoDescrMinima potenciaMotorKW = new DatoDescrMinima();
    potenciaMotorKW.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setPotenciaMotorKW(potenciaMotorKW);
    //PotenciaMotorRPM
    DatoDescrMinima potenciaMotorRPM = new DatoDescrMinima();
    potenciaMotorRPM.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setPotenciaMotorRPM(potenciaMotorRPM);
    //TipoTransmicion
    DatoDescrMinima tipoTransmicion = new DatoDescrMinima();
    tipoTransmicion.setValtipdescri(""); // AUT,CVT,MEC,SAT
    vehiculo.setTipoTransmision(tipoTransmicion);
    //MedidaAros
    DatoDescrMinima medidaAros = new DatoDescrMinima();
    medidaAros.setValtipdescri("30/80"); //NO HAY CATALOGO
    vehiculo.setMedidaAros(medidaAros);
    //MedidaNeumaticos1
    DatoDescrMinima medidaNeumaticos1 = new DatoDescrMinima();
    medidaNeumaticos1.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setMedidaNeumaticos1(medidaNeumaticos1);
    //MedidaNeumaticos2
    DatoDescrMinima medidaNeumaticos2 = new DatoDescrMinima();
    medidaNeumaticos2.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setMedidaNeumaticos2(medidaNeumaticos2);
    //DistanciaEntreEjes
    DatoDescrMinima distanciaEntreEjes = new DatoDescrMinima();
    distanciaEntreEjes.setValtipdescri("99"); //NO HAY CATALOGO
    vehiculo.setDistanciaEntreEjes(distanciaEntreEjes);
    //MarcaCarroceria
    DatoDescrMinima marcaCarroceria = new DatoDescrMinima();
    marcaCarroceria.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setMarcaCarroceria(marcaCarroceria);
    //NumeroPuertas
    DatoDescrMinima numeroPuertas = new DatoDescrMinima();
    numeroPuertas.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setNumeroPuertas(numeroPuertas);
    //RefrigeracionMotor
    DatoDescrMinima refrigeracionMotor = new DatoDescrMinima();
    refrigeracionMotor.setValtipdescri("EAI"); //EAI,ELI
    vehiculo.setRefrigeracionMotor(refrigeracionMotor);
    //TipoFrenoDelantero
    DatoDescrMinima tipoFrenoDelantero = new DatoDescrMinima();
    tipoFrenoDelantero.setValtipdescri("TAM"); //TAM,DIS
    vehiculo.setTipoFrenoDelantero(tipoFrenoDelantero);
    //TipoFrenoPosterior
    DatoDescrMinima tipoFrenoPosterior = new DatoDescrMinima();
    tipoFrenoPosterior.setValtipdescri("DIS"); //TAM,DIS
    vehiculo.setTipoFrenoPosterior(tipoFrenoPosterior);
    //NumeroRuedas
    DatoDescrMinima numeroRuedas = new DatoDescrMinima();
    numeroRuedas.setValtipdescri("3"); //NO HAY CATALOGO
    vehiculo.setNumeroRuedas(numeroRuedas);
    //ModeloDelFabricante
    DatoDescrMinima modeloDelFabricante = new DatoDescrMinima();
    modeloDelFabricante.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setModeloDelFabricante(modeloDelFabricante);
    //FobPaisExportacion
    DatoDescrMinima fobPaisExportacion = new DatoDescrMinima();
    fobPaisExportacion.setValtipdescri(""); // NO HAY CATALOGO
    vehiculo.setFobPaisExportacion(fobPaisExportacion);
    //GastosReparacion
    DatoDescrMinima gastosReparacion = new DatoDescrMinima();
    gastosReparacion.setValtipdescri(""); // NO HAY CATALOGO
    vehiculo.setGastosReparacion(gastosReparacion);
    //Extension
    DatoDescrMinima extension = new DatoDescrMinima();
    extension.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setExtension(extension);
    //AnnoModelo
    DatoDescrMinima annoModelo = new DatoDescrMinima();
    annoModelo.setValtipdescri("2013"); //NO HAY CATALOGO
    vehiculo.setAnnoModelo(annoModelo);
    //SuspensionDelantero
    DatoDescrMinima suspencionDelantera = new DatoDescrMinima();
    suspencionDelantera.setValtipdescri("123456789ABCDEFGHIJKLMNOPQRST"); //NO HAY CATALOGO
    vehiculo.setSuspencionDelantera(suspencionDelantera);
    //SuspensionPosterior
    DatoDescrMinima suspencionPorterior = new DatoDescrMinima();
    suspencionPorterior.setValtipdescri("ABCDEFGHIJKLMNOPQRST123456789"); //NO HAY CATALOGO
    vehiculo.setSuspencionPorterior(suspencionPorterior);
    //NombreFabricante
    DatoDescrMinima nombreFabricante = new DatoDescrMinima();
    nombreFabricante.setValtipdescri("123456789ABCDEFGHIJKLMNOPQRST"); //NO HAY CATALOGO
    vehiculo.setNombreFabricante(nombreFabricante);
    //NumeroCarroceria
    DatoDescrMinima numeroSerieCarroceria = new DatoDescrMinima();
    numeroSerieCarroceria.setValtipdescri("ABCDEFGHIJKLMNOPQ34567"); //NO HAY CATALOGO
    vehiculo.setNumeroSerieCarroceria(numeroSerieCarroceria);
    //Revisa1
    DatoDescrMinima numeroRevisa1 = new DatoDescrMinima();
    numeroRevisa1.setValtipdescri("10730186424"); //NO HAY CATALOGO
    vehiculo.setNumeroRevisa1(numeroRevisa1);
    //NumeroVIN
    DatoDescrMinima numeroVIN = new DatoDescrMinima();
    numeroVIN.setValtipdescri(""); //NO HAY CATALOGO
    vehiculo.setNumeroVIN(numeroVIN);
    //codigoExoneracionVIN
    DatoDescrMinima codigoExoneracionVIN = new DatoDescrMinima();
    codigoExoneracionVIN.setValtipdescri("01"); //01,02,03,04..
    vehiculo.setCodigoExoneracionVIN(codigoExoneracionVIN);
    //ListaAccesorios
    DatoDescrMinima accesorio = new DatoDescrMinima();
    List<DatoDescrMinima> listtAccesorios = new ArrayList<DatoDescrMinima>();
    accesorio.setValtipdescri("AAL"); //001,AAL,ABS,ACD,ALI,ALM,AMP,ANT,ASE,ATB,BLP,BRE,BSA,CAL,CET,CLM,CPV,CTC,CUE,DCC,DCD,DHA,DVD,ECR,EEL...
    listtAccesorios.add(accesorio);
    accesorio.setValtipdescri("ALM");
    listtAccesorios.add(accesorio);
    vehiculo.setListaAccesorios(listtAccesorios);
    //Kilometraje
    DatoDescrMinima kilometraje = new DatoDescrMinima();
    kilometraje.setValtipdescri("1234567,12"); //NO HAY CATALOGO
    kilometraje.setCtipo("1");
    vehiculo.setKilometraje(kilometraje);
    vehiculo.setNumsecitem(3);
    this.declaracion = declaracion;
    this.vehiculo = vehiculo;
  }

  @Test
  public void testValidarCarroceria(){
    System.out.println("Ingreso al Test -testValidarCarroceria-");
    String carroceria = vehiculo.getCarroceria().getValtipdescri();
    System.out.println("Carroceria: " + carroceria);
    Assert.assertEquals(validador.estaEnCatalogo(carroceria,"V3"),true);
  }
  @Test
  public void testValidarMarcaComercial(){
    System.out.println("Ingreso al Test -testValidarMarcaComercial-");
    String marcaComercial = vehiculo.getMarcaComercial().getValtipdescri();
    System.out.println("MarcaComercial: " + marcaComercial);
    Assert.assertEquals(validador.estaEnCatalogo(marcaComercial,"V2"),true);
  }
  @Test
  public void testValidarModelo(){
    System.out.println("Ingreso al Test -testValidarModelo-");
    String modelo = vehiculo.getModelo().getValtipdescri();
    System.out.println("Modelo: " + modelo);
    Assert.assertEquals(validador.estaEnCatalogo(modelo,"VB"),true);
  }
  @Test
  public void testValidarColorPrincipal(){
    System.out.println("Ingreso al Test -testValidarColorPrincipal-");
    String colorPrincipal = vehiculo.getColorPrincipal().getValtipdescri();
    System.out.println("ColorPrincipal: " + colorPrincipal);
    Assert.assertEquals(validador.estaEnCatalogo(colorPrincipal,"V4"),true);
  }
  @Test
  public void testValidarColorSecundario(){
    System.out.println("Ingreso al Test -testValidarColorSecundario-");
    String colorSecundario = vehiculo.getColorSecundario().getValtipdescri();
    System.out.println("ColorSecundario: " + colorSecundario);
    Assert.assertEquals(validador.estaEnCatalogo(colorSecundario,"V4"),true);
  }
  @Test
  public void testValidarIndicadorSNTT(){
    System.out.println("Ingreso al Test -testValidarIndicadorSNTT-");
    String indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri();
    System.out.println("IndicadorSNTT: " + indicadorSNTT);
    Assert.assertEquals(validador.estaEnCatalogo(indicadorSNTT,"VC"),true);
  }
  @Test
  public void testValidarNumeroHomologacionMTC(){
    System.out.println("Ingreso al Test -testValidarNumeroHomologacionMTC-");
    System.out.println("NumeroHomologacionMTC: " + vehiculo.getNumeroHomologacionMTC().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroHomologacionMTC(vehiculo).size(),0);
  }
  @Test
  public void testValidarTipoCombustible(){
    System.out.println("Ingreso al Test -testValidarTipoCombustible-");
    System.out.println("TipoCombustible: " + vehiculo.getTipoCombustible().getValtipdescri());
    Assert.assertEquals(validador.validarTipoCombustible(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroMotor(){
    System.out.println("Ingreso al Test -testValidarNumeroMotor-");
    System.out.println("NumeroMotor: " + vehiculo.getNumeroMotor().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroMotor(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroCilindros(){
    System.out.println("Ingreso al Test -testValidarNumeroCilindros-");
    System.out.println("NumeroCilindros: " + vehiculo.getNumeroCilindros().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroCilindros(vehiculo).size(),1);
  }
  @Test
  public void testValidarMoto(){
    System.out.println("Ingreso al Test -testValidarMoto-");
    System.out.println("Moto: " + vehiculo.getNumeroMotor().getValtipdescri());
    Assert.assertEquals(validador.validarMoto(vehiculo).size(),0);
  }
  @Test
  public void testValidarCilindradaCC(){
    System.out.println("Ingreso al Test -testValidarCilindradaCC-");
    System.out.println("CilindradaCC: " + vehiculo.getNumeroCilindros().getValtipdescri());
    Assert.assertEquals(validador.validarCilindradaCC(vehiculo).size(),1);
  }
  @Test
  public void testValidarFormulaRodante(){
    System.out.println("Ingreso al Test -testValidarFormulaRodante-");
    System.out.println("FormulaRodante: " + vehiculo.getTipoTraccion().getValtipdescri());
    Assert.assertEquals(validador.validarFormulaRodante(vehiculo).size(),1);
  }
  @Test
  public void testValidarVersion(){
    System.out.println("Ingreso al Test -testValidarVersion-");
    System.out.println("Version: " + vehiculo.getVersion().getValtipdescri());
    Assert.assertEquals(validador.validarVersion(vehiculo).size(),1);
  }
  @Test
  public void testValidarTipoEncendido(){
    System.out.println("Ingreso al Test -testValidarTipoEncendido-");
    System.out.println("TipoEncendido: " + vehiculo.getTipoEncendido().getValtipdescri());
    Assert.assertEquals(validador.validarTipoEncendido(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroAsientos(){
    System.out.println("Ingreso al Test -testValidarNumeroAsientos-");
    System.out.println("NumeroAsientos: " + vehiculo.getNumeroAsientos().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroAsientos(vehiculo).size(),1);
  }
  @Test
  public void testValidarCantidadEjes(){
    System.out.println("Ingreso al Test -testValidarCantidadEjes-");
    System.out.println("CantidadEjes: " + vehiculo.getCantidadEjes().getValtipdescri());
    Assert.assertEquals(validador.validarCantidadEjes(vehiculo).size(),1);
  }
  @Test
  public void testValidarPesoMaximoEjeDelantero(){
    System.out.println("Ingreso al Test -testValidarPesoMaximoEjeDelantero-");
    System.out.println("PesoMaximoEjeDelantero: " + vehiculo.getPesoMaximoEjeDelantero().getValtipdescri());
    Assert.assertEquals(validador.validarPesoMaximoEjeDelantero(vehiculo).size(),1);
  }
  @Test
  public void testValidarPesoMaximoEjePosterior1(){
    System.out.println("Ingreso al Test -testValidarPesoMaximoEjePosterior1-");
    System.out.println("PesoMaximoEjePosterior1: " + vehiculo.getPesoMaximoEjePosterior1().getValtipdescri());
    Assert.assertEquals(validador.validarPesoMaximoEjePosterior1(vehiculo).size(),1);
  }
  @Test
  public void testvalidarPesoMaximoEjePosterior2(){
    System.out.println("Ingreso al Test -testvalidarPesoMaximoEjePosterior2-");
    System.out.println("PesoMaximoEjePosterior2: " + vehiculo.getPesoMaximoEjePosterior2().getValtipdescri());
    Assert.assertEquals(validador.validarPesoMaximoEjePosterior2(vehiculo).size(),1);
  }
  @Test
  public void testValidarPesoMaximoEjePosterior3(){
    System.out.println("Ingreso al Test -testValidarPesoMaximoEjePosterior3-");
    System.out.println("PesoMaximoEjePosterior3: " + vehiculo.getPesoMaximoEjePosterior3().getValtipdescri());
    Assert.assertEquals(validador.validarPesoMaximoEjePosterior3(vehiculo).size(),1);
  }
  @Test
  public void testValidarLargoMM(){
    System.out.println("Ingreso al Test -testValidarLargoMM-");
    System.out.println("LargoMM: " + vehiculo.getLargoMM().getValtipdescri());
    Assert.assertEquals(validador.validarLargoMM(vehiculo).size(),1);
  }
  @Test
  public void testValidarAnchoMM(){
    System.out.println("Ingreso al Test -testValidarAnchoMM-");
    System.out.println("ValidarAnchoMM: " + vehiculo.getAnchoMM().getValtipdescri());
    Assert.assertEquals(validador.validarAnchoMM(vehiculo).size(),1);
  }
  @Test
  public void testValidarAlturaMM(){
    System.out.println("Ingreso al Test -testValidarAlturaMM-");
    System.out.println("AlturaMM: " + vehiculo.getAltoMM().getValtipdescri());
    Assert.assertEquals(validador.validarAlturaMM(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroCambiosDeCaja(){
    System.out.println("Ingreso al Test -testValidarNumeroCambiosDeCaja-");
    System.out.println("NumeroCambiosDeCaja: " + vehiculo.getNumeroCambiosDeCaja().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroCambiosDeCaja(vehiculo).size(),1);
  }
  @Test
  public void testValidarPotenciaPesoBruto(){
    System.out.println("Ingreso al Test -testValidarPotenciaPesoBruto-");
    System.out.println("ValidarPotenciaPesoBruto: " + vehiculo.getRelacionPotenciaPesoBruto().getValtipdescri());
    Assert.assertEquals(validador.validarPotenciaPesoBruto(vehiculo).size(),1);
  }
  @Test
  public void testValidarPesoBrutoCombinado(){
    System.out.println("Ingreso al Test -testValidarPesoBrutoCombinado-");
    System.out.println("ValidarPesoBrutoCombinado: " + vehiculo.getPesoBrutoCombinado().getValtipdescri());
    Assert.assertEquals(validador.validarPesoBrutoCombinado(vehiculo).size(),1);
  }
  @Test
  public void testValidarPesoBrutoKG(){
    System.out.println("Ingreso al Test -testValidarPesoBrutoKG-");
    System.out.println("PesoBrutoKG: " + vehiculo.getPesoBrutoKG().getValtipdescri());
    Assert.assertEquals(validador.validarPesoBrutoKG(vehiculo).size(),1);
  }
  @Test
  public void testValidarPesoNetoKG(){
    System.out.println("Ingreso al Test -testValidarPesoNetoKG-");
    System.out.println("ValidarPesoNetoKG: " + vehiculo.getPesoNetoKG().getValtipdescri());
    Assert.assertEquals(validador.validarPesoNetoKG(vehiculo).size(),1);
  }
  @Test
  public void testValidarCargaUtilKG(){
    System.out.println("Ingreso al Test -testValidarCargaUtilKG-");
    System.out.println("CargaUtilKG: " + vehiculo.getCargaUtilKG().getValtipdescri());
    Assert.assertEquals(validador.validarCargaUtilKG(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroPasajeros(){
    System.out.println("Ingreso al Test -testValidarNumeroPasajeros-");
    System.out.println("NumeroPasajeros: " + vehiculo.getNumeroPasajeros().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroPasajeros(vehiculo).size(),1);
  }
  @Test
  public void testValidarPotenciaMotorKW(){
    System.out.println("Ingreso al Test -testValidarPotenciaMotorKW-");
    System.out.println("PotenciaMotorKW: " + vehiculo.getPotenciaMotorKW().getValtipdescri());
    Assert.assertEquals(validador.validarPotenciaMotorKW(vehiculo).size(),1);
  }
  @Test
  public void testValidarPotenciaMotorRPM(){
    System.out.println("Ingreso al Test -testValidarPotenciaMotorRPM-");
    System.out.println("PotenciaMotorRPM: " + vehiculo.getPotenciaMotorRPM().getValtipdescri());
    Assert.assertEquals(validador.validarPotenciaMotorRPM(vehiculo).size(),1);
  }
  @Test
  public void testValidarTipoTransmision(){
    System.out.println("Ingreso al Test -testValidarTipoTransmision-");
    System.out.println("TipoTransmision: " + vehiculo.getTipoTransmision().getValtipdescri());
    Assert.assertEquals(validador.validarTipoTransmision(vehiculo).size(),1);
  }
  @Test
  public void testValidarMedidaAros(){
    System.out.println("Ingreso al Test -testValidarMedidaAros-");
    System.out.println("MedidaAros: " + vehiculo.getMedidaAros().getValtipdescri());
    Assert.assertEquals(validador.validarMedidaAros(vehiculo).size(),0);
  }
  @Test
  public void testValidarMedidaNeumaticos1(){
    System.out.println("Ingreso al Test -testValidarMedidaNeumaticos1-");
    System.out.println("MedidaNeumaticos1: " + vehiculo.getMedidaNeumaticos1().getValtipdescri());
    Assert.assertEquals(validador.validarMedidaNeumaticos1(vehiculo).size(),1);
  }
  @Test
  public void testValidarMedidaNeumaticos2(){
    System.out.println("Ingreso al Test -testValidarMedidaNeumaticos2-");
    System.out.println("MedidaNeumaticos2: " + vehiculo.getMedidaNeumaticos2().getValtipdescri());
    Assert.assertEquals(validador.validarMedidaNeumaticos2(vehiculo).size(),1);
  }
  @Test
  public void testValidarDistanciaEntreEjes(){
    System.out.println("Ingreso al Test -testValidarDistanciaEntreEjes-");
    System.out.println("DistanciaEntreEjes: " + vehiculo.getDistanciaEntreEjes().getValtipdescri());
    Assert.assertEquals(validador.validarDistanciaEntreEjes(vehiculo).size(),1);
  }
  @Test
  public void testValidarMarcaCarroceria(){
    System.out.println("Ingreso al Test -testValidarMarcaCarroceria-");
    System.out.println("MarcaCarroceria: " + vehiculo.getMarcaCarroceria().getValtipdescri());
    Assert.assertEquals(validador.validarMarcaCarroceria(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroPuertas(){
    System.out.println("Ingreso al Test -testValidarNumeroPuertas-");
    System.out.println("NumeroPuertas: " + vehiculo.getNumeroPuertas().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroPuertas(vehiculo).size(),1);
  }
  @Test
  public void testValidarRefrigeracionMotor(){
    System.out.println("Ingreso al Test -testValidarRefrigeracionMotor-");
    System.out.println("RefrigeracionMotor: " + vehiculo.getRefrigeracionMotor().getValtipdescri());
    Assert.assertEquals(validador.validarRefrigeracionMotor(vehiculo).size(),0);
  }
  @Test
  public void testValidarTipoFrenoDelantero(){
    System.out.println("Ingreso al Test -testValidarTipoFrenoDelantero-");
    System.out.println("TipoFrenoDelantero: " + vehiculo.getTipoFrenoDelantero().getValtipdescri());
    Assert.assertEquals(validador.validarTipoFrenoDelantero(vehiculo).size(),0);
  }
  @Test
  public void testValidarTipoFrenoPosterior(){
    System.out.println("Ingreso al Test -testValidarTipoFrenoPosterior-");
    System.out.println("TipoFrenoPosterior: " + vehiculo.getTipoFrenoPosterior().getValtipdescri());
    Assert.assertEquals(validador.validarTipoFrenoPosterior(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroRuedas(){
    System.out.println("Ingreso al Test -testValidarNumeroRuedas-");
    System.out.println("NumeroRuedas: " + vehiculo.getNumeroRuedas().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroRuedas(vehiculo).size(),1);
  }
  @Test
  public void testValidarModeloDelFabricante(){
    System.out.println("Ingreso al Test -testValidarModeloDelFabricante-");
    System.out.println("ModeloDelFabricante: " + vehiculo.getModeloDelFabricante().getValtipdescri());
    Assert.assertEquals(validador.validarModeloDelFabricante(vehiculo).size(),0);
  }
  @Test
  public void testValidarFobPaisExportacion(){
    System.out.println("Ingreso al Test -testValidarFobPaisExportacion-");
    System.out.println("FobPaisExportacion: " + vehiculo.getFobPaisExportacion().getValtipdescri());
    Assert.assertEquals(validador.validarFobPaisExportacion(vehiculo, declaracion).size(),1);
  }
  @Test
  public void testValidarGastosReparacion(){
    System.out.println("Ingreso al Test -testValidarGastosReparacion-");
    System.out.println("GastosReparacion: " + vehiculo.getGastosReparacion().getValtipdescri());
    Assert.assertEquals(validador.validarGastosReparacion(vehiculo, declaracion).size(),1);
  }
  @Test
  public void testValidarExtension(){
    System.out.println("Ingreso al Test -testValidarExtension-");
    System.out.println("Extension: " + vehiculo.getExtension().getValtipdescri());
    Assert.assertEquals(validador.validarExtension(vehiculo, declaracion).size(),1);
  }
  @Test
  public void testValidarAnnoFabricacion(){
    System.out.println("Ingreso al Test -testValidarAnnoFabricacion-");
    System.out.println("AnnoFabricacion: ---");
    Assert.assertEquals(validador.validarAnnoFabricacion(vehiculo, declaracion).size(),1);
  }
  @Test
  public void testValidarAnnModelo(){
    System.out.println("Ingreso al Test -testValidarAnnModelo-");
    System.out.println("AnnModelo: " + vehiculo.getAnnoModelo().getValtipdescri());
    Assert.assertEquals(validador.validarAnnModelo(vehiculo, declaracion).size(),1);
  }
  @Test
  public void testValidarSuspencionDelantera(){
    System.out.println("Ingreso al Test -testValidarSuspencionDelantera-");
    System.out.println("SuspencionDelantera: " + vehiculo.getSuspencionDelantera().getValtipdescri());
    Assert.assertEquals(validador.validarSuspencionDelantera(vehiculo).size(),1);
  }
  @Test
  public void testValidarSuspencionPorterior(){
    System.out.println("Ingreso al Test -testValidarSuspencionPorterior-");
    System.out.println("SuspencionPorterior: " + vehiculo.getSuspencionPorterior().getValtipdescri());
    Assert.assertEquals(validador.validarSuspencionPosterior(vehiculo).size(),1);
  }

  @Test
  public void testValidarNombreDelFabricante(){
    System.out.println("Ingreso al Test -testValidarNombreDelFabricante-");
    System.out.println("NombreDelFabricante: " + vehiculo.getNombreFabricante().getValtipdescri());
    Assert.assertEquals(validador.validarNombreDelFabricante(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroCarroceria(){
    System.out.println("Ingreso al Test -testValidarNumeroCarroceria-");
    System.out.println("ValidarNumeroCarroceria: " + vehiculo.getCarroceria().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroCarroceria(vehiculo).size(),0);
  }
  @Test
  public void testValidarRevisa1(){
    System.out.println("Ingreso al Test -testValidarRevisa1-");
    System.out.println("Revisa1: " + vehiculo.getNumeroRevisa1().getValtipdescri());
    Assert.assertEquals(validador.validarRevisa1(vehiculo, declaracion).size(),1);
  }
  @Test
  public void testValidarNumeroChasis(){
    System.out.println("Ingreso al Test -testValidarNumeroChasis-");
    System.out.println("NumeroChasis: " + vehiculo.getNumeroChasis().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroChasis(vehiculo).size(),0);
  }
  @Test
  public void testValidarCategoria(){
    System.out.println("Ingreso al Test -testValidarCategoria-");
    System.out.println("Categoria: " + vehiculo.getCategoria().getValtipdescri());
    Assert.assertEquals(validador.validarCategoria(vehiculo).size(),0);
  }
  @Test
  public void testValidarCorrelacion(){
    System.out.println("Ingreso al Test -testValidarCorrelacion-");
    Assert.assertEquals(validador.validarCorrelacion(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroVIM(){
    System.out.println("Ingreso al Test -testValidarNumeroVIM-");
    System.out.println("NumeroVIM: " + vehiculo.getNumeroVIN().getValtipdescri());
    Assert.assertEquals(validador.validarNumeroVIN(vehiculo).size(),1);
  }
  @Test
  public void testValidarCodigoExoneracionVIM(){
    System.out.println("Ingreso al Test -testValidarCodigoExoneracionVIM-");
    System.out.println("CodigoExoneracionVIM: " + vehiculo.getNumeroVIN().getValtipdescri());
    Assert.assertEquals(validador.validarCodigoExoneracionVIN(vehiculo,declaracion).size(),2);
  }
  @Test
  public void testValidarListaAccesorios(){
    System.out.println("Ingreso al Test -testValidarListaAccesorios-");
    System.out.println("ListaAccesorios: " + vehiculo.getNumeroVIN().getValtipdescri());
    Assert.assertEquals(validador.validarListaAccesorios(vehiculo).size(),1);
  }
  @Test
  public void testValidarKilometraje(){
    System.out.println("Ingreso al Test -testValidarKilometraje-");
    System.out.println("Kilometraje: " + vehiculo.getKilometraje().getValtipdescri());
    Assert.assertEquals(validador.validarKilometraje(vehiculo, declaracion).size(),0);
  }
}