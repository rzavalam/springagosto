package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.reproduccion;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproControlador;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorReproControladorTest extends AbstractServiceTest{

  @Autowired
  @Qualifier("ValidadorReproControlador")
  private ValidadorReproControlador validador = new ValidadorReproControlador();
  private ReproControlador  controladores = new ReproControlador() ;
  private Declaracion declaracion = new Declaracion();

  @BeforeClass
  public void initData() throws ParseException{

    ReproControlador controlador = new ReproControlador();

    DatoDescrMinima cantMax = new DatoDescrMinima();
    cantMax.setValtipdescri("CantMaxLectoresDiscoOpticos");
    controladores.setCantMaxLectoresDiscoOpticos(cantMax);

    DUA dua = new DUA();
    declaracion.setDua(dua);

    this.controladores = controlador;
  }

  @DataProvider (name="initData1")
  public Object[][] initData1() throws ParseException{

    ReproControlador reproAbstracts = new ReproControlador();

    DatoDescrMinima nombreCom = new DatoDescrMinima();
    nombreCom.setNumsecitem(1);
    nombreCom.setCodtipvalor("0");
    nombreCom.setCodtipdescr("DUC");
    nombreCom.setValtipdescri("DUC");
    reproAbstracts.setNombreComercial(nombreCom);


    Declaracion dua = new Declaracion();
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("U");
    item.setNumpartnandi(new Long(8521100000L));
    lstitem.add(item);
    factu.setListItems(lstitem);
    lstFactu.add(factu);
    dav.setListFacturas(lstFactu);
    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    //

    return new Object[][]{{reproAbstracts, dua}};
  }
  @Test (dataProvider="initData1")
  public void testValidarUnidadComercial(ReproControlador reproAbstracts, Declaracion dua){
    Assert.assertEquals(validador.validarUnidadComercial(reproAbstracts, dua).size(),0);
  }

  @Test (dataProvider="initData1")
  public void testValidarNombreComercial(ReproControlador reproAbstracts, Declaracion dua)
  {
    System.out.println(" *Test ValidarNombreComercial: ");
    System.out.println(" Nombre Comercial Reproduccion: " +reproAbstracts.getNombreComercial().getValtipdescri());
    Assert.assertEquals(validador.validarNombreComercial(reproAbstracts,dua).size(),0);
  }

  @Test
  public void testValidarCantMax()
  {
    Assert.assertEquals(validador.validarCantMaxLectoresDiscoOpticos(controladores).size(),0);
  }

}

