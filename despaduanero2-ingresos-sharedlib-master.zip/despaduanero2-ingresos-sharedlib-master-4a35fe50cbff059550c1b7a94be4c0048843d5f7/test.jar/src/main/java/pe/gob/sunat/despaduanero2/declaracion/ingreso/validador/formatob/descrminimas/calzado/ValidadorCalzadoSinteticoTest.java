package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzado;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoPlasticoSintetico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzados.ValidadorCalzadoPlasticoSintetico;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorCalzadoSinteticoTest extends AbstractServiceTest {

	  @Autowired
	  @Qualifier("ValidadorCalzadoPlasticoSintetico")
	  private ValidadorCalzadoPlasticoSintetico validador = new ValidadorCalzadoPlasticoSintetico();

	  private final static String TEXTO = "1";
	  private final static String CATALOGO = "0";
	  
	  @DataProvider(name="initData98")
	  private Object[][] initData98(){
	  Declaracion dua = new Declaracion();
	  CalzadoPlasticoSintetico calzado = new CalzadoPlasticoSintetico();
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo  = new DatoDescrMinima();
	  DatoDescrMinima materiaParteSuperior = new DatoDescrMinima();
	  DatoDescrMinima talla  = new DatoDescrMinima();
	  DatoDescrMinima composicionSuela = new DatoDescrMinima();
	  DatoDescrMinima composicionForro = new DatoDescrMinima();
	  DatoDescrMinima usuario = new DatoDescrMinima();
	  DatoDescrMinima construccion = new DatoDescrMinima();
	  DatoDescrMinima compoMaterialSintetico1erCompo = new DatoDescrMinima();

	  DUA dam = new DUA();
	  dam.setNumcorredoc(new Long(1));
	  Elementos<DAV> listDAVs = new Elementos<DAV>();

	  DAV dav = new DAV();
	  dav.setNumcorredoc(new Long(1));
	  dav.setNumcodsecprove(new Long(1));

	  Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	  DatoFactura factu = new DatoFactura();
	  factu.setNumcorredoc(new Long(1));
	  factu.setNumfactura("1");
	  factu.setNumsecfactu(1);
	  factu.setNumsecprove(1);

	    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	    DatoItem item = new DatoItem();
	    item.setNumcorredoc(new Long(1));
	    item.setNumfact("1");
	    item.setNumsecitem(1);
	    item.setNumsecprove(1);
	    item.setNumpartnandi(new Long(6403190000L));
	    item.setCodunidcomer("NI SET NI U");
	    lstitem.add(item);
	    calzado.setNumsecitem(1);

	    factu.setListItems(lstitem);
	    lstFactu.add(factu);

	    dav.setListFacturas(lstFactu);

	    listDAVs.add(dav);
	    dua.setListDAVs(listDAVs);
	    dua.setDua(dam);

	    nombreComercial.setCodtipvalor(CATALOGO);
	    nombreComercial.setCodtipdescr("CA0200");
	    nombreComercial.setValtipdescri("ZAP"); //CDP

	    marcaComercial.setCodtipvalor(TEXTO);
	    marcaComercial.setCodtipdescr("CA0201");
	    marcaComercial.setValtipdescri("Nike");

	    modelo.setCodtipvalor(TEXTO);
	    modelo.setCodtipdescr("CA0202");
	    modelo.setValtipdescri("525166 – 173");

	    materiaParteSuperior.setCodtipvalor(CATALOGO);
	    materiaParteSuperior.setCodtipdescr("CA0203");
	    materiaParteSuperior.setValtipdescri("CUS"); //CUR
	    
	    compoMaterialSintetico1erCompo.setCodtipvalor(CATALOGO);
	    compoMaterialSintetico1erCompo.setCodtipdescr("CA0204");
	    compoMaterialSintetico1erCompo.setValtipdescri("");

	    composicionSuela.setCodtipvalor(CATALOGO);
	    composicionSuela.setCodtipdescr("CA0207");
	    composicionSuela.setValtipdescri("CAU");

	    composicionForro.setCodtipvalor(CATALOGO);
	    composicionForro.setCodtipdescr("CA0208");
	    composicionForro.setValtipdescri("TSI");

	    usuario.setCodtipvalor(CATALOGO);
	    usuario.setCodtipdescr("CA0210");
	    usuario.setValtipdescri("CAB");

	    talla.setCodtipvalor(TEXTO);
	    talla.setCodtipdescr("CA0211");
	    talla.setValtipdescri("10.5");

	    construccion.setCodtipvalor(CATALOGO);
	    construccion.setCodtipdescr("CA0212");
	    construccion.setValtipdescri("ACO");

	    calzado.setNombreComercial(nombreComercial);
	    calzado.setMarcaComercial(marcaComercial);
	    calzado.setModelo(modelo);
	    calzado.setMaterialParteSuperior(materiaParteSuperior);
	    calzado.setComposicionDeLaSuela(composicionSuela);
	    calzado.setComposicionForro(composicionForro);
	    calzado.setUsuarioCalzado(usuario);
	    calzado.setTallaCalzado(talla);
	    calzado.setCompoMaterialSistentico1erComp(compoMaterialSintetico1erCompo);
	    calzado.setConstruccionCalzado(construccion);

	    return new Object[][]{{calzado, dua}};
	  }

	  @Test(dataProvider = "initData98")
	  public void validarNombreComercialTest(ModelAbstract object, Declaracion dua){
		DatoItem item = validador.obtenerItem(object, dua);
	    Assert.assertEquals(validador.validarNombreComercial(object, item).size(), 3);
	  }

	  @Test(dataProvider = "initData98")
	  public void validarUnidadComercialTest(ModelAbstract object, Declaracion dua){
		DatoItem item = validador.obtenerItem(object, dua);
	    Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 1);
	  }

	  @Test(dataProvider = "initData98")
	  public void validarMarcaComercialTest(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarMarcaComercial(object).size(), 0);
	  }

	  @Test(dataProvider = "initData98")
	  public void validarModeloTest(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarModelo(object).size(), 0);
	  }

	  @Test(dataProvider = "initData98")
	  public void validarTallaTest(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarTallaCalzado(object).size(), 0);
	  }

	  @Test(dataProvider = "initData98")
	  public void validarConstruccionTest(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarConstruccion(object).size(), 1);
	  }


	  @DataProvider(name="initData100")
	  private Object[][] initData100(){
	    Declaracion dua = new Declaracion();
	    CalzadoPlasticoSintetico calzado = new CalzadoPlasticoSintetico();
	    DatoDescrMinima nombreComercial = new DatoDescrMinima();
	    DatoDescrMinima marcaComercial = new DatoDescrMinima();
	    DatoDescrMinima modelo         = new DatoDescrMinima();
	    DatoDescrMinima materialSuperior = new DatoDescrMinima();
	    DatoDescrMinima composicionSuela = new DatoDescrMinima();
	    DatoDescrMinima usuario = new DatoDescrMinima();
	    DatoDescrMinima talla = new DatoDescrMinima();
	    DatoDescrMinima compoMaterialSintetico1erComp = new DatoDescrMinima();
	    DatoDescrMinima construccion = new DatoDescrMinima();

	    DUA dam = new DUA();
	    dam.setNumcorredoc(new Long(1));
	    Elementos<DAV> listDAVs = new Elementos<DAV>();

	    DAV dav = new DAV();
	    dav.setNumcorredoc(new Long(1));
	    dav.setNumcodsecprove(new Long(1));

	    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	    DatoFactura factu = new DatoFactura();
	    factu.setNumcorredoc(new Long(1));
	    factu.setNumfactura("1");
	    factu.setNumsecfactu(1);
	    factu.setNumsecprove(1);

	    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	    DatoItem item = new DatoItem();
	    item.setNumcorredoc(new Long(1));
	    item.setNumfact("1");
	    item.setNumsecitem(1);
	    item.setNumsecprove(1);
	    item.setNumpartnandi(new Long(6401920000L));
	    item.setCodunidcomer("2U");
	    lstitem.add(item);
	    calzado.setNumsecitem(1);

	    factu.setListItems(lstitem);
	    lstFactu.add(factu);

	    dav.setListFacturas(lstFactu);

	    listDAVs.add(dav);
	    dua.setListDAVs(listDAVs);
	    dua.setDua(dam);

	    nombreComercial.setCodtipvalor(CATALOGO);
	    nombreComercial.setCodtipdescr("CA0200");
	    nombreComercial.setValtipdescri("BSI");

	    marcaComercial.setCodtipvalor(TEXTO);
	    marcaComercial.setCodtipdescr("CA0201");
	    marcaComercial.setValtipdescri("Panoply");

	    modelo.setCodtipvalor(TEXTO);
	    modelo.setCodtipdescr("CA0202");
	    modelo.setValtipdescri("Amazone SR");

	    materialSuperior.setCodtipvalor(CATALOGO);
	    materialSuperior.setCodtipdescr("CA0203");
	    materialSuperior.setValtipdescri("MAD");

	    composicionSuela.setCodtipvalor(CATALOGO);
	    composicionSuela.setCodtipdescr("CA0210");
	    composicionSuela.setValtipdescri("PVC");
	    
	    compoMaterialSintetico1erComp.setCodtipvalor(CATALOGO);
	    compoMaterialSintetico1erComp.setCodtipdescr("CA0204");
	    compoMaterialSintetico1erComp.setValtipdescri("");

	    usuario.setCodtipvalor(CATALOGO);
	    usuario.setCodtipdescr("CA0212");
	    usuario.setValtipdescri("DAM");

	    talla.setCodtipvalor(TEXTO);
	    talla.setCodtipdescr("CA0213");
	    talla.setValtipdescri("3656522");

	    construccion.setCodtipvalor(CATALOGO);
	    construccion.setCodtipdescr("CA0214");
	    construccion.setValtipdescri("INY");

	    calzado.setNombreComercial(nombreComercial);
	    calzado.setMarcaComercial(marcaComercial);
	    calzado.setModelo(modelo);
	    calzado.setMaterialParteSuperior(materialSuperior);
	    calzado.setCompoMaterialSistentico1erComp(compoMaterialSintetico1erComp);
	    calzado.setComposicionDeLaSuela(composicionSuela);
	    calzado.setTallaCalzado(talla);
	    calzado.setUsuarioCalzado(usuario);
	    calzado.setConstruccionCalzado(construccion);

	    return new Object[][]{{calzado, dua}};
	  }

	  @Test(dataProvider="initData100")
	  public void validarNombreComercial100Test(ModelAbstract object, Declaracion dua){
		DatoItem item = validador.obtenerItem(object, dua);
	    Assert.assertEquals(validador.validarNombreComercial(object, item).size(), 0);
	  }

	  @Test(dataProvider="initData100")
	  public void validarMarcaComercial100Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarMarcaComercial(object).size(), 0);
	  }

	  @Test(dataProvider = "initData100")
	  public void validarModelo100Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarModelo(object), new ArrayList<ErrorDescrMinima>());
	  }

	  @Test(dataProvider="initData100")
	  public void validarMaterialSuperior(ModelAbstract object, Declaracion dua){
		DatoItem item = validador.obtenerItem(object, dua);
	    Assert.assertEquals(validador.validarMaterialParteSuperior(object,item).size(), 0);
	  }

	  @Test(dataProvider="initData100")
	  public void validarComposicionSuela100Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarComposicionDeLaSuela(object).size(), 0);
	  }

	  @Test(dataProvider = "initData100")
	  public void validarUsusario100Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarUsarioCalzado(object).size(), 0);
	  }

	  @Test(dataProvider = "initData100")
	  public void validarTalla1233Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarTallaCalzado(object).size(), 0);
	  }

	  @Test(dataProvider = "initData100")
	  public void validarConstruccion100Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarConstruccion(object).size(), 0);
	  }
	  
	  @DataProvider(name="initData107")
	  private Object[][] initData107(){
	    Declaracion dua = new Declaracion();
	    CalzadoPlasticoSintetico calzado = new CalzadoPlasticoSintetico();
	    DatoDescrMinima nombreComercial = new DatoDescrMinima();
	    DatoDescrMinima marcaComercial = new DatoDescrMinima();
	    DatoDescrMinima modelo         = new DatoDescrMinima();
	    DatoDescrMinima materialSuperior = new DatoDescrMinima();
	    DatoDescrMinima composicionSuela = new DatoDescrMinima();
	    DatoDescrMinima composicionForro = new DatoDescrMinima();
	    DatoDescrMinima usuario = new DatoDescrMinima();
	    DatoDescrMinima talla = new DatoDescrMinima();
	    DatoDescrMinima compoMaterialSistentico1erComp = new DatoDescrMinima();
	    DatoDescrMinima construccion = new DatoDescrMinima();

	    DUA dam = new DUA();
	    dam.setNumcorredoc(new Long(1));
	    Elementos<DAV> listDAVs = new Elementos<DAV>();

	    DAV dav = new DAV();
	    dav.setNumcorredoc(new Long(1));
	    dav.setNumcodsecprove(new Long(1));

	    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	    DatoFactura factu = new DatoFactura();
	    factu.setNumcorredoc(new Long(1));
	    factu.setNumfactura("1");
	    factu.setNumsecfactu(1);
	    factu.setNumsecprove(1);

	    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	    DatoItem item = new DatoItem();
	    item.setNumcorredoc(new Long(1));
	    item.setNumfact("1");
	    item.setNumsecitem(1);
	    item.setNumsecprove(1);
	    item.setNumpartnandi(new Long(6402999000L));
	    item.setCodunidcomer("2U");
	    lstitem.add(item);
	    calzado.setNumsecitem(1);

	    factu.setListItems(lstitem);
	    lstFactu.add(factu);

	    dav.setListFacturas(lstFactu);

	    listDAVs.add(dav);
	    dua.setListDAVs(listDAVs);
	    dua.setDua(dam);

	    nombreComercial.setCodtipvalor(CATALOGO);
	    nombreComercial.setCodtipdescr("CA0200");
	    nombreComercial.setValtipdescri("ZAP");

	    marcaComercial.setCodtipvalor(TEXTO);
	    marcaComercial.setCodtipdescr("CA0201");
	    marcaComercial.setValtipdescri("560978");

	    modelo.setCodtipvalor(TEXTO);
	    modelo.setCodtipdescr("CA0202");
	    modelo.setValtipdescri("ADIDAS");

	    materialSuperior.setCodtipvalor(CATALOGO);
	    materialSuperior.setCodtipdescr("CA0203");
	    materialSuperior.setValtipdescri("CUS");

	    composicionSuela.setCodtipvalor(CATALOGO);
	    composicionSuela.setCodtipdescr("CA0210");
	    composicionSuela.setValtipdescri("CAU");
	    
	    composicionForro.setCodtipvalor(CATALOGO);
	    composicionForro.setCodtipdescr("CA0211");
	    composicionForro.setValtipdescri("TSI");

	    usuario.setCodtipvalor(CATALOGO);
	    usuario.setCodtipdescr("CA0212");
	    usuario.setValtipdescri("DAM");

	    talla.setCodtipvalor(TEXTO);
	    talla.setCodtipdescr("CA0213");
	    talla.setValtipdescri("36000-36000");

	    construccion.setCodtipvalor(CATALOGO);
	    construccion.setCodtipdescr("CA0214");
	    construccion.setValtipdescri("CEM");
	    
	    compoMaterialSistentico1erComp.setCodtipvalor(CATALOGO);
	    compoMaterialSistentico1erComp.setCodtipdescr("CA0204");
	    compoMaterialSistentico1erComp.setValtipdescri("");

	    calzado.setNombreComercial(nombreComercial);
	    calzado.setMarcaComercial(marcaComercial);
	    calzado.setModelo(modelo);
	    calzado.setMaterialParteSuperior(materialSuperior);
	    calzado.setComposicionDeLaSuela(composicionSuela);
	    calzado.setComposicionForro(composicionForro);
	    calzado.setTallaCalzado(talla);
	    calzado.setUsuarioCalzado(usuario);
	    calzado.setCompoMaterialSistentico1erComp(compoMaterialSistentico1erComp);
	    calzado.setConstruccionCalzado(construccion);

	    return new Object[][]{{calzado, dua}};
	  }
	  
	  @Test(dataProvider="initData107")
	  public void validarNombreComercial107Test(ModelAbstract object, Declaracion dua){
		DatoItem item = validador.obtenerItem(object, dua);
	    Assert.assertEquals(validador.validarNombreComercial(object, item).size(), 1);
	  }

	  @Test(dataProvider="initData107")
	  public void validarMarcaComercial107Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarMarcaComercial(object).size(), 0);
	  }

	  @Test(dataProvider = "initData107")
	  public void validarModelo107Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarModelo(object), new ArrayList<ErrorDescrMinima>());
	  }

	  @Test(dataProvider="initData107")
	  public void validarMaterialSuperior107Test(ModelAbstract object, Declaracion dua){
		DatoItem item = validador.obtenerItem(object, dua);
	    Assert.assertEquals(validador.validarMaterialParteSuperior(object,item).size(), 0);
	  }

	  @Test(dataProvider="initData107")
	  public void validarComposicionSuela107Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarComposicionDeLaSuela(object).size(), 0);
	  }

	  @Test(dataProvider = "initData107")
	  public void validarUsusario107Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarUsarioCalzado(object).size(), 0);
	  }

	  @Test(dataProvider = "initData107")
	  public void validarTalla107Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarTallaCalzado(object).size(), 0);
	  }

	  @Test(dataProvider = "initData107")
	  public void validarConstruccion107Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarConstruccion(object).size(), 0);
	  }
	  
	  @DataProvider(name="initData108")
	  private Object[][] initData108(){
	    Declaracion dua = new Declaracion();
	    CalzadoPlasticoSintetico calzado = new CalzadoPlasticoSintetico();
	    DatoDescrMinima nombreComercial = new DatoDescrMinima();
	    DatoDescrMinima marcaComercial = new DatoDescrMinima();
	    DatoDescrMinima modelo         = new DatoDescrMinima();
	    DatoDescrMinima materialSuperior = new DatoDescrMinima();
	    DatoDescrMinima composicionSuela = new DatoDescrMinima();
	    DatoDescrMinima composicionForro = new DatoDescrMinima();
	    DatoDescrMinima usuario = new DatoDescrMinima();
	    DatoDescrMinima talla = new DatoDescrMinima();
	    DatoDescrMinima compoMaterialSistentico1erComp = new DatoDescrMinima();
	    DatoDescrMinima construccion = new DatoDescrMinima();

	    DUA dam = new DUA();
	    dam.setNumcorredoc(new Long(1));
	    Elementos<DAV> listDAVs = new Elementos<DAV>();

	    DAV dav = new DAV();
	    dav.setNumcorredoc(new Long(1));
	    dav.setNumcodsecprove(new Long(1));

	    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	    DatoFactura factu = new DatoFactura();
	    factu.setNumcorredoc(new Long(1));
	    factu.setNumfactura("1");
	    factu.setNumsecfactu(1);
	    factu.setNumsecprove(1);

	    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	    DatoItem item = new DatoItem();
	    item.setNumcorredoc(new Long(1));
	    item.setNumfact("1");
	    item.setNumsecitem(1);
	    item.setNumsecprove(1);
	    item.setNumpartnandi(new Long(6402999000L));
	    item.setCodunidcomer("2U");
	    lstitem.add(item);
	    calzado.setNumsecitem(1);

	    factu.setListItems(lstitem);
	    lstFactu.add(factu);

	    dav.setListFacturas(lstFactu);

	    listDAVs.add(dav);
	    dua.setListDAVs(listDAVs);
	    dua.setDua(dam);

	    nombreComercial.setCodtipvalor(CATALOGO);
	    nombreComercial.setCodtipdescr("CA0200");
	    nombreComercial.setValtipdescri("ZAP");

	    marcaComercial.setCodtipvalor(TEXTO);
	    marcaComercial.setCodtipdescr("CA0201");
	    marcaComercial.setValtipdescri("AZALEIA");

	    modelo.setCodtipvalor(TEXTO);
	    modelo.setCodtipdescr("CA0202");
	    modelo.setValtipdescri("AGITY 775");

	    materialSuperior.setCodtipvalor(CATALOGO);
	    materialSuperior.setCodtipdescr("CA0203");
	    materialSuperior.setValtipdescri("PLA");

	    composicionSuela.setCodtipvalor(CATALOGO);
	    composicionSuela.setCodtipdescr("CA0210");
	    composicionSuela.setValtipdescri("CAU");
	    
	    composicionForro.setCodtipvalor(CATALOGO);
	    composicionForro.setCodtipdescr("CA0211");
	    composicionForro.setValtipdescri("TSI");

	    usuario.setCodtipvalor(CATALOGO);
	    usuario.setCodtipdescr("CA0212");
	    usuario.setValtipdescri("UNI");

	    talla.setCodtipvalor(TEXTO);
	    talla.setCodtipdescr("CA0213");
	    talla.setValtipdescri("34000-43000");

	    construccion.setCodtipvalor(CATALOGO);
	    construccion.setCodtipdescr("CA0214");
	    construccion.setValtipdescri("CEM");
	    
	    compoMaterialSistentico1erComp.setCodtipvalor(CATALOGO);
	    compoMaterialSistentico1erComp.setCodtipdescr("CA0204");
	    compoMaterialSistentico1erComp.setValtipdescri("POL");

	    calzado.setNombreComercial(nombreComercial);
	    calzado.setMarcaComercial(marcaComercial);
	    calzado.setModelo(modelo);
	    calzado.setMaterialParteSuperior(materialSuperior);
	    calzado.setComposicionDeLaSuela(composicionSuela);
	    calzado.setComposicionForro(composicionForro);
	    calzado.setTallaCalzado(talla);
	    calzado.setUsuarioCalzado(usuario);
	    calzado.setCompoMaterialSistentico1erComp(compoMaterialSistentico1erComp);
	    calzado.setConstruccionCalzado(construccion);

	    return new Object[][]{{calzado, dua}};
	   }
	  
	  @Test(dataProvider="initData108")
	  public void validarNombreComercial108Test(ModelAbstract object, Declaracion dua){
		DatoItem item = validador.obtenerItem(object, dua);
	    Assert.assertEquals(validador.validarNombreComercial(object, item).size(), 0);
	  }

	  @Test(dataProvider="initData108")
	  public void validarMarcaComercial108Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarMarcaComercial(object).size(), 0);
	  }

	  @Test(dataProvider = "initData108")
	  public void validarModelo108Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarModelo(object), new ArrayList<ErrorDescrMinima>());
	  }

	  @Test(dataProvider="initData108")
	  public void validarMaterialSuperior108Test(ModelAbstract object, Declaracion dua){
		DatoItem item = validador.obtenerItem(object, dua);
	    Assert.assertEquals(validador.validarMaterialParteSuperior(object,item).size(), 0);
	  }

	  @Test(dataProvider="initData108")
	  public void validarComposicionSuela108Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarComposicionDeLaSuela(object).size(), 0);
	  }

	  @Test(dataProvider = "initData108")
	  public void validarUsusario108Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarUsarioCalzado(object).size(), 0);
	  }

	  @Test(dataProvider = "initData108")
	  public void validarTalla108Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarTallaCalzado(object).size(), 0);
	  }

	  @Test(dataProvider = "initData108")
	  public void validarConstruccion108Test(ModelAbstract object, Declaracion dua){
	    Assert.assertEquals(validador.validarConstruccion(object).size(), 0);
	  }
}
