package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.cierres;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreCremallera;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorCierreCremalleraTest extends AbstractServiceTest {
	
	 @Autowired
	 @Qualifier("ValidadorCierreCremallera")
	 private ValidadorCierreCremallera validador;

	 private CierreCremallera		cierreCremallera;
	 private Declaracion	declaracion;
	 
	 @BeforeClass
	 public void initData() throws Exception{
		 System.out.println("LOAD TEST UNITARIOS ...");
		 CierreCremallera cierreCremallera = new CierreCremallera();
		 //nombreComercial
		 DatoDescrMinima nombreComercial = new DatoDescrMinima();
		 nombreComercial.setValtipdescri("CRE"); //CRE,LLA,TIR
		 cierreCremallera.setNombreComercial(nombreComercial);		 
		 //marcaComercial
		 DatoDescrMinima marcaComercial = new DatoDescrMinima();
		 marcaComercial.setValtipdescri("marcacomercial"); //NO HAY CATALOGO
		 cierreCremallera.setMarcaComercial(marcaComercial);		 
		 //modelo
		 DatoDescrMinima modelo = new DatoDescrMinima();
		 modelo.setValtipdescri("modelo"); //NO HAY CATALOGO
		 cierreCremallera.setModelo(modelo);
		 //tipoCierre
		 DatoDescrMinima tipoCierre = new DatoDescrMinima();
		 tipoCierre.setValtipdescri("SEP"); //DVI;FIJ;SEP
		 cierreCremallera.setTipoCierre(tipoCierre);	 
		 //composicionCinta
		 DatoDescrMinima composicionCinta = new DatoDescrMinima();
		 composicionCinta.setValtipdescri("01"); //01,02,03,04...
		 cierreCremallera.setComposicionCinta(composicionCinta);		 
		 //presentacionCinta
		 DatoDescrMinima presentacionCinta = new DatoDescrMinima();
		 presentacionCinta.setValtipdescri("02"); //01,02,03,04...
		 cierreCremallera.setPresentacionCinta(presentacionCinta);		 		 
		 //tipoLlave
		 DatoDescrMinima tipoLlave = new DatoDescrMinima();
		 tipoLlave.setValtipdescri("SAT"); //AUT,NLO,REV,SAT...
		 cierreCremallera.setTipoLlave(tipoLlave);		 
		 //materialLlave
		 DatoDescrMinima materialLlave = new DatoDescrMinima();
		 materialLlave.setValtipdescri("COB"); //ALU,AZI,COB
		 cierreCremallera.setMaterialLlave(materialLlave);		 
		 //tamanoCremallera
		 DatoDescrMinima tamanoCremallera = new DatoDescrMinima();
		 tamanoCremallera.setValtipdescri("18"); //NO HAY CATALOGO
		 cierreCremallera.setTamanoCremallera(tamanoCremallera);		 
		 //materialDientes
		 DatoDescrMinima materialDientes = new DatoDescrMinima();
		 materialDientes.setValtipdescri("COB"); //ALU,AZI,COB
		 cierreCremallera.setMaterialDientes(materialDientes);		 
		 //tamanoDientes
		 DatoDescrMinima tamanoDientes = new DatoDescrMinima();
		 tamanoDientes.setValtipdescri("25"); //NO HAY CATALOGO
		 cierreCremallera.setTamanoDientes(tamanoDientes);		 
		 //UnidadComercial
		 Declaracion declaracion = new Declaracion();
		 Elementos<DAV> listDAVs = new Elementos<DAV>();
		 DAV dav = new DAV();
		 Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
		 DatoFactura factu = new DatoFactura();
		 Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
		 DatoItem item = new DatoItem();
		 item.setNumsecitem(3);
		 item.setCodunidcomer("12U"); 
		 item.setNumpartnandi(8506101100L);
		 lstitem.add(item);
		 factu.setListItems(lstitem);
		 lstFactu.add(factu);
		 dav.setListFacturas(lstFactu);
		 listDAVs.add(dav);
		 declaracion.setListDAVs(listDAVs);
		 cierreCremallera.setNumsecitem(3);
		 this.declaracion = declaracion;
		 this.cierreCremallera = cierreCremallera;
		  }	 
	 
	 	@Test
	 	public void testValidarUnidadComercial(){
	 		Assert.assertEquals(validador.validarUnidadComercial(cierreCremallera, declaracion).size(),0);
	 	} 
	 	@Test
	 	public void testValidarNombreComercial(){
	 		Assert.assertEquals(validador.validarNombreComercial(cierreCremallera).size(),0);
	 	} 	 	
	 	@Test
	 	public void testValidarMarcaComercial(){
	 		Assert.assertEquals(validador.validarMarcaComercial(cierreCremallera).size(),0);
	 	} 	
	 	@Test
	 	public void testValidarModelo(){
	 		Assert.assertEquals(validador.validarModelo(cierreCremallera).size(),0);
	 	} 		 	
	 	@Test
	 	public void testValidarTipoCierre(){
	 	    String tipoCierre = cierreCremallera.getTipoCierre().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(tipoCierre,"CD"),true);
	 	  }
	 	@Test
	 	public void testValidarComposicionCinta(){
	 	    String composicionCinta = cierreCremallera.getComposicionCinta().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(composicionCinta,"M1"),true);
	 	  }
	 	@Test
	 	public void testValidarPresentacionCinta(){
	 	    String presentacionCinta = cierreCremallera.getPresentacionCinta().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(presentacionCinta,"M3"),true);
	 	  }
	 	@Test
	 	public void testValidarTipoLlave(){
	 	    String tipoLlave = cierreCremallera.getTipoLlave().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(tipoLlave,"CC"),true);
	 	  }
	 	@Test
	 	public void testValidarMaterialLlave(){
	 	    String materialLlave = cierreCremallera.getMaterialLlave().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(materialLlave,"CB"),true);
	 	  }	 	
	 	@Test
	 	public void testValidarTamanoCremallera(){
	 		Assert.assertEquals(validador.validarTamanoCremallera(cierreCremallera).size(),0);
	 	} 	 	
	 	@Test
	 	public void testValidarMaterialDientes(){
	 	    String materialDientes = cierreCremallera.getMaterialDientes().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(materialDientes,"CB"),true);
	 	  }		 	
	 	@Test
	 	public void testValidarTamanoDientes(){
	 		Assert.assertEquals(validador.validarTamanoDientes(cierreCremallera).size(),0);
	 	}	 	
}