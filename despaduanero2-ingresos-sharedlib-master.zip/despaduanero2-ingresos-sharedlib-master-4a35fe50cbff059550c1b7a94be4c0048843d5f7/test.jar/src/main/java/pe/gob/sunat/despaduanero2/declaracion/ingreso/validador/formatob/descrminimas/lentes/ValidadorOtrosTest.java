package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.lentes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorOtrosTest extends AbstractServiceTest{
	@Autowired
	@Qualifier("ValidadorLentesOtros")
	private ValidadorLentesOtros validador;

	private static final String TEXTO    = "1";
	private static final String CATALOGO = "0";

	
	@DataProvider(name = "initEnlaceAduanero_119")
	public Object[][] initEnlaceAduanero_119(){
	  LentesOtros otros = new LentesOtros();
	  DatoDescrMinima nombreComercial =  new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima materialLente = new DatoDescrMinima();
	  DatoDescrMinima seriesDeMedida = new DatoDescrMinima();
	  DatoDescrMinima tipoLente = new DatoDescrMinima();
	  DatoDescrMinima usoLenteContacto = new DatoDescrMinima();
	  DatoDescrMinima numeroFocos = new DatoDescrMinima();
	  DatoDescrMinima tipoNumeroFocos = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoDescrMinima tratamiento = new DatoDescrMinima();
	  DatoDescrMinima acabado = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  
	  item.setNumpartnandi(new Long(9001400000L));
	  
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("LE0100");
	  nombreComercial.setValtipdescri("LCR");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LE0101");
	  marcaComercial.setValtipdescri("AO Safety");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LE0102");
	  modelo.setValtipdescri("Sport");
	  
	  materialLente.setCodtipvalor(CATALOGO);
	  materialLente.setCodtipdescr("LE0103");
	  materialLente.setValtipdescri("CRT");
	  
	  seriesDeMedida.setCodtipvalor(CATALOGO);
	  seriesDeMedida.setCodtipdescr("LE0104");
	  seriesDeMedida.setValtipdescri("S2");
	  
	  tipoLente.setCodtipvalor(CATALOGO);
	  tipoLente.setCodtipdescr("LE0105");
	  tipoLente.setValtipdescri("");
	  
	  usoLenteContacto.setCodtipvalor(CATALOGO);
	  usoLenteContacto.setCodtipdescr("LE0106");
	  usoLenteContacto.setValtipdescri("");
	  
	  numeroFocos.setCodtipvalor(CATALOGO);
	  numeroFocos.setCodtipdescr("LE0107");
	  numeroFocos.setValtipdescri("MFC");
	  
	  tipoNumeroFocos.setCodtipvalor(CATALOGO);
	  tipoNumeroFocos.setCodtipdescr("LE0107");
	  tipoNumeroFocos.setValtipdescri("ESF");
	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LE0108");
	  color.setValtipdescri("BLA");
	  
	  tratamiento.setCodtipvalor(CATALOGO);
	  tratamiento.setCodtipdescr("LE0109");
	  tratamiento.setValtipdescri("ARF");
	  
	  acabado.setCodtipvalor(CATALOGO);
	  acabado.setCodtipdescr("LE0110");
	  acabado.setValtipdescri("TRM");
	  
	  otros.setNombreComercial(nombreComercial);
	  otros.setMarcaComercial(marcaComercial);
	  otros.setModelo(modelo);
	  otros.setMaterialLente(materialLente);
	  otros.setSeriesDeMedida(seriesDeMedida);
	  otros.setTipoLente(tipoLente);
	  otros.setUsoLenteContacto(usoLenteContacto);
	  otros.setNumeroFocos(numeroFocos);
	  otros.setTipoNumeroFocos(tipoNumeroFocos);
	  otros.setColor(color);
	  otros.setTratamiento(tratamiento);
	  otros.setAcabado(acabado);
	  
	  return new Object[][]{{otros,item}};
	}
	
	@Test(dataProvider = "initEnlaceAduanero_119")
	  public void testValidarNombreComercial(ModelAbstract otros, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(otros, item).size(),0);
	  }
	@Test(dataProvider = "initEnlaceAduanero_119")
	  public void testvalidarSeriesDeMedida(ModelAbstract otros, DatoItem item){
	    Assert.assertEquals(validador.validarSeriesDeMedida(otros).size(),0);
	  }
	@Test(dataProvider = "initEnlaceAduanero_119")
	  public void testvalidarTipoLente(ModelAbstract otros, DatoItem item){
	    Assert.assertEquals(validador.validarTipoLente(otros).size(),0);
	  }
	@Test(dataProvider = "initEnlaceAduanero_119")
	  public void testvalidarNroFocos(ModelAbstract otros, DatoItem item){
	    Assert.assertEquals(validador.validarNroFocos(otros).size(),0);
	  }
	@Test(dataProvider = "initEnlaceAduanero_119")
	  public void testvalidarColor(ModelAbstract otros, DatoItem item){
	    Assert.assertEquals(validador.validarColor(otros).size(),0);
	  }
	@Test(dataProvider = "initEnlaceAduanero_119")
	  public void testvalidarTratamiento(ModelAbstract otros, DatoItem item){
	    Assert.assertEquals(validador.validarColor(otros).size(),0);
	  }
	@Test(dataProvider = "initEnlaceAduanero_119")
	  public void testvalidarMediddas(ModelAbstract otros, DatoItem item){
	    Assert.assertEquals(validador.validarMedida(otros).size(),0);
	  }
	
	@DataProvider(name = "initEnlaceAduanero_122")
	public Object[][] initEnlaceAduanero_122(){
	  LentesOtros otros = new LentesOtros();
	  DatoDescrMinima nombreComercial =  new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima materialLente = new DatoDescrMinima();
	  DatoDescrMinima seriesDeMedida = new DatoDescrMinima();
	  DatoDescrMinima tipoLente = new DatoDescrMinima();
	  DatoDescrMinima usoLenteContacto = new DatoDescrMinima();
	  DatoDescrMinima numeroFocos = new DatoDescrMinima();
	  DatoDescrMinima tipoNumeroFocos = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoDescrMinima tratamiento = new DatoDescrMinima();
	  DatoDescrMinima acabado = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  
	  item.setNumpartnandi(new Long(9001400000L));
	  
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("LE0100");
	  nombreComercial.setValtipdescri("LCR");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LE0101");
	  marcaComercial.setValtipdescri("Panorama");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LE0102");
	  modelo.setValtipdescri("PGX");
	  
	  materialLente.setCodtipvalor(CATALOGO);
	  materialLente.setCodtipdescr("LE0103");
	  materialLente.setValtipdescri("CRT");
	  
	  seriesDeMedida.setCodtipvalor(CATALOGO);
	  seriesDeMedida.setCodtipdescr("LE0104");
	  seriesDeMedida.setValtipdescri("S3");
	  
	  tipoLente.setCodtipvalor(CATALOGO);
	  tipoLente.setCodtipdescr("LE0105");
	  tipoLente.setValtipdescri("");
	  
	  usoLenteContacto.setCodtipvalor(CATALOGO);
	  usoLenteContacto.setCodtipdescr("LE0106");
	  usoLenteContacto.setValtipdescri("");
	  
	  numeroFocos.setCodtipvalor(CATALOGO);
	  numeroFocos.setCodtipdescr("LE0107");
	  numeroFocos.setValtipdescri("MFC");
	  
	  tipoNumeroFocos.setCodtipvalor(CATALOGO);
	  tipoNumeroFocos.setCodtipdescr("LE0107");
	  tipoNumeroFocos.setValtipdescri("ESF");
	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LE0108");
	  color.setValtipdescri("BLA");
	  
	  tratamiento.setCodtipvalor(CATALOGO);
	  tratamiento.setCodtipdescr("LE0109");
	  tratamiento.setValtipdescri("ARF");
	  
	  acabado.setCodtipvalor(CATALOGO);
	  acabado.setCodtipdescr("LE0110");
	  acabado.setValtipdescri("STM");
	  
	  otros.setNombreComercial(nombreComercial);
	  otros.setMarcaComercial(marcaComercial);
	  otros.setModelo(modelo);
	  otros.setMaterialLente(materialLente);
	  otros.setSeriesDeMedida(seriesDeMedida);
	  otros.setTipoLente(tipoLente);
	  otros.setUsoLenteContacto(usoLenteContacto);
	  otros.setNumeroFocos(numeroFocos);
	  otros.setTipoNumeroFocos(tipoNumeroFocos);
	  otros.setColor(color);
	  otros.setTratamiento(tratamiento);
	  otros.setAcabado(acabado);
	  
	  return new Object[][]{{otros,item}};
	}
}
