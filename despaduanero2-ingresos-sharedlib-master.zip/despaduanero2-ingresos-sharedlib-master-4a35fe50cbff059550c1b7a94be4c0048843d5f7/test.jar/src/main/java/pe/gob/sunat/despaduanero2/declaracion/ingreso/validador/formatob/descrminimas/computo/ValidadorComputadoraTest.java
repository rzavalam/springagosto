package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoComputadora;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorComputadoraTest extends AbstractServiceTest{
	@Autowired
	@Qualifier("ValidadorComputoComputadora")
	private ValidadorComputoComputadora validador = new ValidadorComputoComputadora();

	private static final String TEXTO    = "1";
	private static final String CATALOGO = "0";

	@DataProvider (name = "initData126")
	private Object[][] initData126(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();	
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima tipoComputadora = new DatoDescrMinima();
	  DatoDescrMinima tipoProcesador = new DatoDescrMinima();
	  DatoDescrMinima tipoMonitor = new DatoDescrMinima();
	  DatoDescrMinima tipoTeclado = new DatoDescrMinima();
	  DatoDescrMinima velocidadProcesador = new DatoDescrMinima();
	  DatoDescrMinima velocidadLectura = new DatoDescrMinima();
	  DatoDescrMinima velocidadGrabacion = new DatoDescrMinima();
	  DatoDescrMinima capacidadRAM = new DatoDescrMinima();
	  DatoDescrMinima capacidadDiscoDuro = new DatoDescrMinima();
	  DatoDescrMinima tamanoMonitor = new DatoDescrMinima();
	  ComputoComputadora computadora = new ComputoComputadora();
	  Declaracion dua = new Declaracion();
	  DatoItem item = new DatoItem();
	  item.setNumpartnandi(new Long(8471300000L));
	  
	  computadora.setNumsecitem(1);
	  
	  DUA dam = new DUA();
	  dam.setNumcorredoc(new Long(1));
	  Elementos<DAV> listDAVs = new Elementos<DAV>();

	  DAV dav = new DAV();
	  dav.setNumcorredoc(new Long(1));
	  dav.setNumcodsecprove(new Long(1));

	  Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	  DatoFactura factu = new DatoFactura();
	  factu.setNumcorredoc(new Long(1));
	  factu.setNumfactura("1");
	  factu.setNumsecfactu(1);
	  factu.setNumsecprove(1);

	    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	    item.setNumcorredoc(new Long(1));
	    item.setNumfact("1");
	    item.setNumsecitem(1);
	    item.setNumsecprove(1);
	    item.setCodunidcomer("U");
	    lstitem.add(item);

	    factu.setListItems(lstitem);
	    lstFactu.add(factu);

	    dav.setListFacturas(lstFactu);

	    listDAVs.add(dav);
	    dua.setListDAVs(listDAVs);
	    dua.setDua(dam);
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("CO0100");
	  nombreComercial.setValtipdescri("COM");
	  
	  marcaComercial.setCodtipvalor(CATALOGO);
	  marcaComercial.setCodtipdescr("CO0101");
	  marcaComercial.setValtipdescri("DEL");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("CO0102");
	  modelo.setValtipdescri("INSPIRON 15R");
	  
	  tipoComputadora.setCodtipvalor(CATALOGO);
	  tipoComputadora.setCodtipdescr("CO0103");
	  tipoComputadora.setValtipdescri("POR");
	  
	  tipoProcesador.setCodtipvalor(CATALOGO);
	  tipoProcesador.setCodtipdescr("CO0104");
	  tipoProcesador.setValtipdescri("153");
	  
	  tipoMonitor.setCodtipvalor(CATALOGO);
	  tipoMonitor.setCodtipdescr("CO0105");
	  tipoMonitor.setValtipdescri("LCD");
	  
	  tipoTeclado.setCodtipvalor(CATALOGO);
	  tipoTeclado.setCodtipdescr("CO0106");
	  tipoTeclado.setValtipdescri("MUL");
	  
	  velocidadProcesador.setCodtipvalor(CATALOGO);
	  velocidadProcesador.setCodtipdescr("CO0107");
	  velocidadProcesador.setValtipdescri("MM5");
	  
	  velocidadLectura.setCodtipvalor(CATALOGO);
	  velocidadLectura.setCodtipdescr("CO0108");
	  velocidadLectura.setValtipdescri("08X");
	  
	  velocidadGrabacion.setCodmercancia(CATALOGO);
	  velocidadGrabacion.setCodtipdescr("CO0109");
	  velocidadGrabacion.setValtipdescri("08X");

	  capacidadRAM.setCodtipvalor(CATALOGO);
	  capacidadRAM.setCodtipdescr("CO0110");
	  capacidadRAM.setValtipdescri("4GB");
	  
	  capacidadDiscoDuro.setCodtipvalor(CATALOGO);
	  capacidadDiscoDuro.setCodtipdescr("CO0111");
	  capacidadDiscoDuro.setValtipdescri("500");
	  
	  tamanoMonitor.setCodtipvalor(CATALOGO);
	  tamanoMonitor.setCodtipdescr("CO0112");
	  tamanoMonitor.setValtipdescri("156");
	  
	  computadora.setNombreComercial(nombreComercial);
	  computadora.setMarcaComercial(marcaComercial);
	  computadora.setModelo(modelo);
	  computadora.setTipoComputadora(tipoComputadora);
	  computadora.setTipoProcesador(tipoProcesador);
	  computadora.setTipoMonitor(tipoMonitor);
	  computadora.setTipoProcesador(tipoProcesador);
	  computadora.setTipoMonitor(tipoMonitor);
	  computadora.setTipoTeclado(tipoTeclado);
	  computadora.setVelocidadProcesador(velocidadProcesador);
	  computadora.setVelocidadLectura(velocidadLectura);
	  computadora.setVelocidadGrabacion(velocidadGrabacion);
	  computadora.setCapacidadRAM(capacidadRAM);
	  computadora.setTamanoMonitor(tamanoMonitor);
	  	  
	  return new Object[][]{{ computadora, dua}};
	}
	
	@Test(dataProvider = "initData126")
	  public void validarNombreComercialTest(ModelAbstract object, Declaracion dua) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(object, dua).size(), 0);
	  }
	
	@DataProvider (name = "initData127")
	private Object[][] initData127(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();	
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima tipoComputadora = new DatoDescrMinima();
	  DatoDescrMinima tipoProcesador = new DatoDescrMinima();
	  DatoDescrMinima tipoMonitor = new DatoDescrMinima();
	  DatoDescrMinima tipoTeclado = new DatoDescrMinima();
	  DatoDescrMinima velocidadProcesador = new DatoDescrMinima();
	  DatoDescrMinima velocidadLectura = new DatoDescrMinima();
	  DatoDescrMinima velocidadGrabacion = new DatoDescrMinima();
	  DatoDescrMinima capacidadRAM = new DatoDescrMinima();
	  DatoDescrMinima capacidadDiscoDuro = new DatoDescrMinima();
	  DatoDescrMinima tamanoMonitor = new DatoDescrMinima();
	  ComputoComputadora computadora = new ComputoComputadora();
	  Declaracion dua = new Declaracion();
	  DatoItem item = new DatoItem();
	  item.setNumpartnandi(new Long(8471300000L));
	  
	  computadora.setNumsecitem(1);
	  
	  DUA dam = new DUA();
	  dam.setNumcorredoc(new Long(1));
	  Elementos<DAV> listDAVs = new Elementos<DAV>();

	  DAV dav = new DAV();
	  dav.setNumcorredoc(new Long(1));
	  dav.setNumcodsecprove(new Long(1));

	  Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	  DatoFactura factu = new DatoFactura();
	  factu.setNumcorredoc(new Long(1));
	  factu.setNumfactura("1");
	  factu.setNumsecfactu(1);
	  factu.setNumsecprove(1);

	    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	    item.setNumcorredoc(new Long(1));
	    item.setNumfact("1");
	    item.setNumsecitem(1);
	    item.setNumsecprove(1);
	    item.setCodunidcomer("U");
	    lstitem.add(item);

	    factu.setListItems(lstitem);
	    lstFactu.add(factu);

	    dav.setListFacturas(lstFactu);

	    listDAVs.add(dav);
	    dua.setListDAVs(listDAVs);
	    dua.setDua(dam);
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("CO0100");
	  nombreComercial.setValtipdescri("COM");
	  
	  marcaComercial.setCodtipvalor(CATALOGO);
	  marcaComercial.setCodtipdescr("CO0101");
	  marcaComercial.setValtipdescri("APP");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("CO0102");
	  modelo.setValtipdescri("A1416");
	  
	  tipoComputadora.setCodtipvalor(CATALOGO);
	  tipoComputadora.setCodtipdescr("CO0103");
	  tipoComputadora.setValtipdescri("PAL");
	  
	  tipoProcesador.setCodtipvalor(CATALOGO);
	  tipoProcesador.setCodtipdescr("CO0104");
	  tipoProcesador.setValtipdescri("100");
	  
	  tipoMonitor.setCodtipvalor(CATALOGO);
	  tipoMonitor.setCodtipdescr("CO0105");
	  tipoMonitor.setValtipdescri("LED");
	  
	  tipoTeclado.setCodtipvalor(CATALOGO);
	  tipoTeclado.setCodtipdescr("CO0106");
	  tipoTeclado.setValtipdescri("TSC");
	  
	  velocidadProcesador.setCodtipvalor(CATALOGO);
	  velocidadProcesador.setCodtipdescr("CO0107");
	  velocidadProcesador.setValtipdescri("M10");
	  
//	  velocidadLectura.setCodtipvalor(CATALOGO);
//	  velocidadLectura.setCodtipdescr("CO0108");
//	  velocidadLectura.setValtipdescri("08X");
	  
//	  velocidadGrabacion.setCodmercancia(CATALOGO);
//	  velocidadGrabacion.setCodtipdescr("CO0109");
//	  velocidadGrabacion.setValtipdescri("08X");

	  capacidadRAM.setCodtipvalor(CATALOGO);
	  capacidadRAM.setCodtipdescr("CO0110");
	  capacidadRAM.setValtipdescri("4GB");
	  
	  capacidadDiscoDuro.setCodtipvalor(CATALOGO);
	  capacidadDiscoDuro.setCodtipdescr("CO0111");
	  capacidadDiscoDuro.setValtipdescri("500");
	  
	  tamanoMonitor.setCodtipvalor(CATALOGO);
	  tamanoMonitor.setCodtipdescr("CO0112");
	  tamanoMonitor.setValtipdescri("700");
	  
	  computadora.setNombreComercial(nombreComercial);
	  computadora.setMarcaComercial(marcaComercial);
	  computadora.setModelo(modelo);
	  computadora.setTipoComputadora(tipoComputadora);
	  computadora.setTipoProcesador(tipoProcesador);
	  computadora.setTipoMonitor(tipoMonitor);
	  computadora.setTipoProcesador(tipoProcesador);
	  computadora.setTipoMonitor(tipoMonitor);
	  computadora.setTipoTeclado(tipoTeclado);
	  computadora.setVelocidadProcesador(velocidadProcesador);
	  computadora.setVelocidadLectura(velocidadLectura);
	  computadora.setVelocidadGrabacion(velocidadGrabacion);
	  computadora.setCapacidadRAM(capacidadRAM);
	  computadora.setTamanoMonitor(tamanoMonitor);
	  	  
	  return new Object[][]{{ computadora, dua}};
	}
	
	@Test(dataProvider = "initData127")
	  public void validarNombreComercial127Test(ModelAbstract object, Declaracion dua) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(object, dua).size(), 0);
	  }
	
	@DataProvider (name = "initData130")
	private Object[][] initData130(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();	
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima tipoComputadora = new DatoDescrMinima();
	  DatoDescrMinima tipoProcesador = new DatoDescrMinima();
	  DatoDescrMinima tipoMonitor = new DatoDescrMinima();
	  DatoDescrMinima tipoTeclado = new DatoDescrMinima();
	  DatoDescrMinima velocidadProcesador = new DatoDescrMinima();
	  DatoDescrMinima velocidadLectura = new DatoDescrMinima();
	  DatoDescrMinima velocidadGrabacion = new DatoDescrMinima();
	  DatoDescrMinima capacidadRAM = new DatoDescrMinima();
	  DatoDescrMinima capacidadDiscoDuro = new DatoDescrMinima();
	  DatoDescrMinima tamanoMonitor = new DatoDescrMinima();
	  ComputoComputadora computadora = new ComputoComputadora();
	  Declaracion dua = new Declaracion();
	  DatoItem item = new DatoItem();
	  item.setNumpartnandi(new Long(8471300000L));
	  
	  computadora.setNumsecitem(1);
	  
	  DUA dam = new DUA();
	  dam.setNumcorredoc(new Long(1));
	  Elementos<DAV> listDAVs = new Elementos<DAV>();

	  DAV dav = new DAV();
	  dav.setNumcorredoc(new Long(1));
	  dav.setNumcodsecprove(new Long(1));

	  Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	  DatoFactura factu = new DatoFactura();
	  factu.setNumcorredoc(new Long(1));
	  factu.setNumfactura("1");
	  factu.setNumsecfactu(1);
	  factu.setNumsecprove(1);

	    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	    item.setNumcorredoc(new Long(1));
	    item.setNumfact("1");
	    item.setNumsecitem(1);
	    item.setNumsecprove(1);
	    item.setCodunidcomer("U");
	    lstitem.add(item);

	    factu.setListItems(lstitem);
	    lstFactu.add(factu);

	    dav.setListFacturas(lstFactu);

	    listDAVs.add(dav);
	    dua.setListDAVs(listDAVs);
	    dua.setDua(dam);
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("CO0100");
	  nombreComercial.setValtipdescri("COM");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("CO0101");
	  marcaComercial.setValtipdescri("LENOVO");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("CO0102");
	  modelo.setValtipdescri("2AS");
	  
	  tipoComputadora.setCodtipvalor(CATALOGO);
	  tipoComputadora.setCodtipdescr("CO0103");
	  tipoComputadora.setValtipdescri("POR");
	  
	  tipoProcesador.setCodtipvalor(CATALOGO);
	  tipoProcesador.setCodtipdescr("CO0104");
	  tipoProcesador.setValtipdescri("");
	  
	  tipoMonitor.setCodtipvalor(CATALOGO);
	  tipoMonitor.setCodtipdescr("CO0105");
	  tipoMonitor.setValtipdescri("LHD");
	  
	  tipoTeclado.setCodtipvalor(CATALOGO);
	  tipoTeclado.setCodtipdescr("CO0106");
	  tipoTeclado.setValtipdescri("STA");
	  
	  velocidadProcesador.setCodtipvalor(CATALOGO);
	  velocidadProcesador.setCodtipdescr("CO0107");
	  velocidadProcesador.setValtipdescri("MM5");
	  
	  velocidadLectura.setCodtipvalor(CATALOGO);
	  velocidadLectura.setCodtipdescr("CO0108");
	  velocidadLectura.setValtipdescri("24X");
	  
	  velocidadGrabacion.setCodmercancia(CATALOGO);
	  velocidadGrabacion.setCodtipdescr("CO0109");
	  velocidadGrabacion.setValtipdescri("24X");

	  capacidadRAM.setCodtipvalor(CATALOGO);
	  capacidadRAM.setCodtipdescr("CO0110");
	  capacidadRAM.setValtipdescri("");
	  
	  capacidadDiscoDuro.setCodtipvalor(CATALOGO);
	  capacidadDiscoDuro.setCodtipdescr("CO0111");
	  capacidadDiscoDuro.setValtipdescri("128");
	  
	  tamanoMonitor.setCodtipvalor(CATALOGO);
	  tamanoMonitor.setCodtipdescr("CO0112");
	  tamanoMonitor.setValtipdescri("140");
	  
	  computadora.setNombreComercial(nombreComercial);
	  computadora.setMarcaComercial(marcaComercial);
	  computadora.setModelo(modelo);
	  computadora.setTipoComputadora(tipoComputadora);
	  computadora.setTipoProcesador(tipoProcesador);
	  computadora.setTipoMonitor(tipoMonitor);
	  computadora.setTipoProcesador(tipoProcesador);
	  computadora.setTipoMonitor(tipoMonitor);
	  computadora.setTipoTeclado(tipoTeclado);
	  computadora.setVelocidadProcesador(velocidadProcesador);
	  computadora.setVelocidadLectura(velocidadLectura);
	  computadora.setVelocidadGrabacion(velocidadGrabacion);
	  computadora.setCapacidadRAM(capacidadRAM);
	  computadora.setTamanoMonitor(tamanoMonitor);
	  	  
	  return new Object[][]{{ computadora, dua }};
	}
	
	@Test(dataProvider = "initData130")
	  public void validarNombreComercial130Test(ModelAbstract object, Declaracion dua) throws Exception{
		//Validaciones del receptor no estan siendo capturadas.
	    Assert.assertEquals(validador.ejecutarValidaciones(object, dua).size(), 0);
	  }
}
