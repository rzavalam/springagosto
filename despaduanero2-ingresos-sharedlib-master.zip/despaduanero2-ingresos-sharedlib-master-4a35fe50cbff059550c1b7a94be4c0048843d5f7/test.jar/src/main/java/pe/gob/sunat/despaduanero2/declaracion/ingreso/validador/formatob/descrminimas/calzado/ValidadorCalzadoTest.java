package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoCueroNatural;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzados.ValidadorCalzadoCueroNatural;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;


/**
 * 
 * @author lalberti
 * 
 */
public class ValidadorCalzadoTest extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorCalzadoCueroNatural")
  private ValidadorCalzadoCueroNatural validador = new ValidadorCalzadoCueroNatural();

  private final static String TEXTO = "1";
  private final static String CATALOGO = "0";

  @DataProvider(name="initData99")
  private Object[][] initData99(){
    Declaracion dua = new Declaracion();
    CalzadoCueroNatural calzado = new CalzadoCueroNatural();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo          = new DatoDescrMinima();
    DatoDescrMinima materialSuperior = new DatoDescrMinima();
    DatoDescrMinima origenCuero    = new DatoDescrMinima();
    DatoDescrMinima acabado        = new DatoDescrMinima();
    DatoDescrMinima composicionSuela = new DatoDescrMinima();
    DatoDescrMinima composicionForro = new DatoDescrMinima();
    DatoDescrMinima usuario = new DatoDescrMinima();
    DatoDescrMinima talla = new DatoDescrMinima();
    DatoDescrMinima construccion = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("CA0100");
    nombreComercial.setValtipdescri("CDP");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("CA0101");
    marcaComercial.setValtipdescri("REEF");

    modelo.setCodtipvalor(TEXTO);
    modelo.setCodtipdescr("CA0102");
    modelo.setValtipdescri("Lanzoroti Le");

    materialSuperior.setCodtipvalor(CATALOGO);
    materialSuperior.setCodtipdescr("CA0103");
    materialSuperior.setValtipdescri("CUS");

    origenCuero.setCodtipvalor(CATALOGO);
    origenCuero.setCodtipdescr("CA0104");
    origenCuero.setValtipdescri("BOV");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("CA0106");
    acabado.setValtipdescri("NAT");

    composicionSuela.setCodtipvalor(CATALOGO);
    composicionSuela.setCodtipdescr("CA0108");
    composicionSuela.setValtipdescri("CAU");

    composicionForro.setCodtipvalor(CATALOGO);
    composicionForro.setCodtipdescr("CA0109");
    composicionForro.setValtipdescri("TSI");

    usuario.setCodtipvalor(CATALOGO);
    usuario.setCodtipdescr("CA0110");
    usuario.setValtipdescri("CAB");

    talla.setCodtipvalor(TEXTO);
    talla.setCodtipdescr("CA0111");
    talla.setValtipdescri("09");

    construccion.setCodtipvalor(CATALOGO);
    construccion.setCodtipdescr("CA0112");
    construccion.setValtipdescri("CEM");

    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setNumpartnandi(new Long(6403190000L));
    item.setCodunidcomer("NI SET NI U");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    calzado.setNombreComercial(nombreComercial);
    calzado.setMarcaComercial(marcaComercial);
    calzado.setModelo(modelo);
    calzado.setMaterialParteSuperior(materialSuperior);
    //calzado.setOrigenCuero(origenCuero);
    calzado.setComposicionDeLaSuela(composicionSuela);
    calzado.setComposicionForro(composicionForro);
    calzado.setUsuarioCalzado(usuario);
    calzado.setTallaCalzado(talla);
    calzado.setConstruccionCalzado(construccion);

    return new Object[][]{{calzado, dua}};
  }

  @Test(dataProvider = "initData99")
  public void validarNombreComercial99Test(ModelAbstract object, Declaracion dua){
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(validador.validarNombreComercial(object, item).size(), 1);
  }

  @Test(dataProvider = "initData99")
  public void validarMarcaComercial(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarMarcaComercial(object).size(),0);
  }

  @Test(dataProvider = "initData99")
  public void ValidarModelo(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarModelo(object).size(), 0);
  }

  @Test(dataProvider="initData99")
  public void ValidarUnidadComercial(ModelAbstract object, Declaracion dua)
  {
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 1);
  }

  @Test(dataProvider = "initData99")
  public void ValidarOrigenCuero(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarOrigenCuero(object).size(), 0);
  }

  @Test(dataProvider = "initData99")
  public void validarAcabado99Test(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarAcabadosCuero(object).size(), 0);
  }

  @Test(dataProvider = "initData99")
  public void validarComposicionSuela99(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarComposicionDeLaSuela(object).size(), 0);
  }

  @DataProvider (name = "initData101")
  private Object[][] initData101(){
	  
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial  = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima materialParteSuperior = new DatoDescrMinima();
	  DatoDescrMinima origenCuero = new DatoDescrMinima();
	  DatoDescrMinima porcentajeOrigenCuero = new DatoDescrMinima();
	  DatoDescrMinima acabadosCuero = new DatoDescrMinima();
	  DatoDescrMinima porcentajeAcabadoCuero = new DatoDescrMinima();
	  DatoDescrMinima composicionSuela = new DatoDescrMinima();
	  DatoDescrMinima composicionForro = new DatoDescrMinima();
	  DatoDescrMinima usuarioCalzado = new DatoDescrMinima();
	  DatoDescrMinima tallaCalzado = new DatoDescrMinima();
	  DatoDescrMinima construccionCalzado = new DatoDescrMinima();
	  
	  CalzadoCueroNatural calzado = new CalzadoCueroNatural();

	  DatoItem item = new DatoItem();
	  item.setNumcorredoc(new Long(1));
	  item.setNumfact("1");
	  item.setNumsecitem(1);
	  item.setNumsecprove(1);
	  item.setNumpartnandi(new Long(6403999000L));
	  item.setCodunidcomer("2U");
	  
	  calzado.setNumsecitem(1);
	  
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("CA0100");
	  nombreComercial.setValtipdescri("SAN");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("CA0101");
	  marcaComercial.setValtipdescri("Carolina Herrera");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("CA0102");
	  modelo.setValtipdescri("32HEDINEPDF879");
	  
	  materialParteSuperior.setCodtipvalor(CATALOGO);
	  materialParteSuperior.setCodtipdescr("CA0103");
	  materialParteSuperior.setValtipdescri("CUN");
	  
	  origenCuero.setCodtipvalor(CATALOGO);
	  origenCuero.setCodtipdescr("CA0104");
	  origenCuero.setValtipdescri("REP");
	  
	  composicionSuela.setCodtipvalor(CATALOGO);
	  composicionSuela.setCodtipdescr("CA0108");
	  composicionSuela.setValtipdescri("CUE");
	  
	  usuarioCalzado.setCodtipvalor(CATALOGO);
	  usuarioCalzado.setCodtipdescr("CA0110");
	  usuarioCalzado.setValtipdescri("DAM");
	  
	  tallaCalzado.setCodtipvalor(TEXTO);
	  tallaCalzado.setCodtipdescr("CA0111");
	  tallaCalzado.setValtipdescri("33");
	  
	  construccionCalzado.setCodtipvalor(CATALOGO);
	  construccionCalzado.setCodtipdescr("CA0112");
	  construccionCalzado.setValtipdescri("ACO");
	  
	  calzado.setNombreComercial(nombreComercial);
	  calzado.setMarcaComercial(marcaComercial);
	  calzado.setModelo(modelo);
	  calzado.setMaterialParteSuperior(materialParteSuperior);
	  calzado.setOrigenCuero(origenCuero);
	  calzado.setPorcentajeOrigenCuero(porcentajeOrigenCuero);
	  calzado.setAcabadosCuero(acabadosCuero);
	  calzado.setPorcentajeAcabadoCuero(porcentajeAcabadoCuero);
	  calzado.setAcabadosCuero(acabadosCuero);
	  calzado.setPorcentajeAcabadoCuero(porcentajeAcabadoCuero);
	  calzado.setComposicionDeLaSuela(composicionSuela);
	  calzado.setComposicionForro(composicionForro);
	  calzado.setUsuarioCalzado(usuarioCalzado);
	  calzado.setUsuarioCalzado(usuarioCalzado);
	  calzado.setTallaCalzado(tallaCalzado);
	  calzado.setConstruccionCalzado(construccionCalzado);
	  
	  return new Object[][]{{calzado, item}};
  }
  
  @Test(dataProvider = "initData101")
  public void validarNombreComercial101Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarNombreComercial(object, item).size(), 1);
  }

  @Test(dataProvider = "initData101")
  public void validarMarcaComercial101Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarMarcaComercial(object).size(),0);
  }

  @Test(dataProvider = "initData101")
  public void ValidarModelo101Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarModelo(object).size(), 0);
  }

  @Test(dataProvider="initData101")
  public void ValidarUnidadComercial101Test(ModelAbstract object, DatoItem item)
  {
    Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 0);
  }
  
  @Test(dataProvider = "initData101")
  public void ValidarOrigenCuero101Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarOrigenCuero(object).size(), 0);
  }

  @Test(dataProvider = "initData101")
  public void validarComposicionSuela101Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarComposicionDeLaSuela(object).size(), 0);
  }
  
  @DataProvider (name = "initData102")
  private Object[][] initData102(){
	  
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial  = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima materialParteSuperior = new DatoDescrMinima();
	  DatoDescrMinima origenCuero = new DatoDescrMinima();
	  DatoDescrMinima porcentajeOrigenCuero = new DatoDescrMinima();
	  DatoDescrMinima acabadosCuero = new DatoDescrMinima();
	  DatoDescrMinima porcentajeAcabadoCuero = new DatoDescrMinima();
	  DatoDescrMinima composicionSuela = new DatoDescrMinima();
	  DatoDescrMinima composicionForro = new DatoDescrMinima();
	  DatoDescrMinima usuarioCalzado = new DatoDescrMinima();
	  DatoDescrMinima tallaCalzado = new DatoDescrMinima();
	  DatoDescrMinima construccionCalzado = new DatoDescrMinima();
	  
	  CalzadoCueroNatural calzado = new CalzadoCueroNatural();

	  DatoItem item = new DatoItem();
	  item.setNumcorredoc(new Long(1));
	  item.setNumfact("1");
	  item.setNumsecitem(1);
	  item.setNumsecprove(1);
	  item.setNumpartnandi(new Long(6403999000L));
	  item.setCodunidcomer("M");
	  
	  calzado.setNumsecitem(1);
	  
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("CA0100");
	  nombreComercial.setValtipdescri("CCS");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("CA0101");
	  marcaComercial.setValtipdescri("Hush Puppies");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("CA0102");
	  modelo.setValtipdescri("Aron");
	  
	  materialParteSuperior.setCodtipvalor(CATALOGO);
	  materialParteSuperior.setCodtipdescr("CA0103");
	  materialParteSuperior.setValtipdescri("CUN");
	  
	  origenCuero.setCodtipvalor(CATALOGO);
	  origenCuero.setCodtipdescr("CA0104");
	  origenCuero.setValtipdescri("BOV");
	  
	  composicionSuela.setCodtipvalor(CATALOGO);
	  composicionSuela.setCodtipdescr("CA0108");
	  composicionSuela.setValtipdescri("CAU");
	  
	  usuarioCalzado.setCodtipvalor(CATALOGO);
	  usuarioCalzado.setCodtipdescr("CA0110");
	  usuarioCalzado.setValtipdescri("CAB");
	  
	  tallaCalzado.setCodtipvalor(TEXTO);
	  tallaCalzado.setCodtipdescr("CA0111");
	  tallaCalzado.setValtipdescri("");
	  
	  construccionCalzado.setCodtipvalor(CATALOGO);
	  construccionCalzado.setCodtipdescr("CA0112");
	  construccionCalzado.setValtipdescri("ACO");
	  
	  calzado.setNombreComercial(nombreComercial);
	  calzado.setMarcaComercial(marcaComercial);
	  calzado.setModelo(modelo);
	  calzado.setMaterialParteSuperior(materialParteSuperior);
	  calzado.setOrigenCuero(origenCuero);
	  calzado.setPorcentajeOrigenCuero(porcentajeOrigenCuero);
	  calzado.setAcabadosCuero(acabadosCuero);
	  calzado.setPorcentajeAcabadoCuero(porcentajeAcabadoCuero);
	  calzado.setAcabadosCuero(acabadosCuero);
	  calzado.setPorcentajeAcabadoCuero(porcentajeAcabadoCuero);
	  calzado.setComposicionDeLaSuela(composicionSuela);
	  calzado.setComposicionForro(composicionForro);
	  calzado.setUsuarioCalzado(usuarioCalzado);
	  calzado.setUsuarioCalzado(usuarioCalzado);
	  calzado.setTallaCalzado(tallaCalzado);
	  calzado.setConstruccionCalzado(construccionCalzado);
	  
	  return new Object[][]{{calzado, item}};
  }
  
  @Test(dataProvider = "initData102")
  public void validarNombreComercial102Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarNombreComercial(object, item).size(), 0);
  }

  @Test(dataProvider = "initData102")
  public void validarMarcaComercial102Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarMarcaComercial(object).size(),0);
  }

  @Test(dataProvider = "initData102")
  public void ValidarModelo102Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarModelo(object).size(), 0);
  }

  @Test(dataProvider="initData102")
  public void ValidarUnidadComercial102Test(ModelAbstract object, DatoItem item)
  {
    Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 1);
  }
  
  @Test(dataProvider = "initData102")
  public void ValidarOrigenCuero102Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarOrigenCuero(object).size(), 0);
  }

  @Test(dataProvider = "initData102")
  public void validarComposicionSuela102Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarComposicionDeLaSuela(object).size(), 0);
  }
  
}
