package pe.gob.sunat.despaduanero2.declaracion.ingreso.service;

import static org.testng.Assert.assertNotNull;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.compression.ZipUtil;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.tecnologia.receptor.bean.EnvioArchivoBean;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.model.dao.EnvioArchivoDAO;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class GetDeclaracionTest extends AbstractServiceTest{

	@Autowired
	@Qualifier("framework.fabricaDeServicios")
	private FabricaDeServicios fabricaDeServicios;

	@Autowired
	@Qualifier("Ayuda.ayudaServiceCache")
	private AyudaServiceCache  ayudaServiceCache;

	@Autowired
	@Qualifier("manifiesto.envioArchivoDAO")
	private EnvioArchivoDAO envioArchivoDAO;

	
	@Autowired
	@Qualifier("receptor.zipUtil")
	private ZipUtil zipHelper;

	private static Mensaje mensaje;
	private static Declaracion declaracion;

	private String fileName = new String();
	private String destination = new String();
	private static String numeroTransaccion = "1001";
	private static String numeroEnvio = "18761";
	private static String annoEnvio   = "2014";


	private String obtenerXMLDeclaracion() throws Exception{		
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("numeroTicket", numeroEnvio);
		paramsMap.put("anhoEnvio", annoEnvio);
		paramsMap.put("tipoArchivo", "E");
		this.obtenerArchivoPorNumeroTicket(paramsMap);
		String fileXML = this.descomprimirArchivo();
		return fileXML;
	}

	public EnvioArchivoBean obtenerConsultaNumeroTicket(Map<String, Object> paramsMap) {
		EnvioArchivoBean envioArchivo = null;
		try {
			envioArchivo = this.envioArchivoDAO.obtenerArchivoEnvio(paramsMap);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return envioArchivo;
	}
	
	public File obtenerArchivoPorNumeroTicket(Map<String, Object> paramsMap) {
		EnvioArchivoBean envioArchivo = null;
		envioArchivo = obtenerConsultaNumeroTicket(paramsMap);
		File dest = null;
		try
		{
			if (envioArchivo != null) {
				FileOutputStream fos = new FileOutputStream(fileName);
				fos.write(envioArchivo.getInformacionArchivo());
				fos.flush();
				fos.close();
				dest = new File(fileName);
			}
		}
		catch (Exception e)
		{
			System.out.println("Error en la generacion del archivo :" + e.getMessage());
			e.printStackTrace();
		}

		return dest;
	}
	
	private  String descomprimirArchivo() throws Exception {
		List<String> nombres = null;
		String resultado = null;
		try {
			nombres = this.zipHelper.unZipFiles(fileName, destination);
		}
	    catch (Exception e) {
	      e.printStackTrace();
	    }
		Iterator<String> localIterator = nombres.iterator(); if (localIterator.hasNext()) { String nombre = (String)localIterator.next();
	      resultado = nombre;
	    }
	    return resultado;
	}


	@BeforeClass
	public void initData() throws Exception{

		Map<String, Object>  parametros = new HashMap<String, Object>();
		destination = "/data1/sigad/envios/descomprimido/";
		fileName = "/data1/sigad/envios/temporal/" + UUID.randomUUID().toString() + annoEnvio + "-" + numeroEnvio + ".zip";
		assertNotNull(fabricaDeServicios, "No se cargo la fabrica de servicios desde el contexto");	
		String fileXML = obtenerXMLDeclaracion();		
		ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");
		parametros.put("numeroTransaccion", numeroTransaccion);
		List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);
		XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
		xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);
		mensaje = xmlConvertirObjetosUtil.convertir(listaReglas, fileXML, numeroTransaccion);
		assertNotNull(mensaje);
		declaracion = (Declaracion) mensaje.getDocumento();		
	}

	@Test
	public void testGetDeclaracion() {
		System.out.println("declaracion " + declaracion.getCodaduana());
		System.out.println(pe.gob.sunat.framework.spring.util.conversion.SojoUtil.toJson(declaracion));	    		
	}
}
