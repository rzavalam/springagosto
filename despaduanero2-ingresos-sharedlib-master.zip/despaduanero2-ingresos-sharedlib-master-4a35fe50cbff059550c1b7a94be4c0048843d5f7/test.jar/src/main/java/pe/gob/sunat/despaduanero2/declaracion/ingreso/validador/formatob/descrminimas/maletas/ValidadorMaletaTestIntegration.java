package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.maletas;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.maletas.model.Maleta;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorMaletaTestIntegration extends AbstractServiceTest {
  @Autowired
  @Qualifier("ValidadorMaleta")
  private ValidadorMaleta validador;

  @Autowired
  @Qualifier("framework.fabricaDeServicios")
  private FabricaDeServicios fabricaDeServicios;

  @Autowired
  @Qualifier("Ayuda.ayudaServiceCache")
  private AyudaServiceCache ayudaServiceCache;

  private Map<String,List<String>> getDuaFromXML(String filename) throws Exception{
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    Declaracion dua = new Declaracion();
    Mensaje mensaje1001;

    String numeroTransaccion = "1001";

    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

    Map<String, Object> parametros = new HashMap<String, Object>();

    parametros.put("numeroTransaccion", numeroTransaccion);

    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);

    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);

    assertNotNull(mensaje1001);
    dua = (Declaracion) mensaje1001.getDocumento();

    dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();

    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima> listaDescripcionMinimas =
        dua.getListDAVs().get(0).getListFacturas().get(0)
        .getListItems().get(0).getListDecrMinima();

    for (pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima dato : listaDescripcionMinimas)
    {
      List<String> data = new ArrayList<String>();
      data.add(0, dato.getCodtipvalor());
      data.add(1,dato.getValtipdescri());
      valores.put(dato.getCodtipdescr(), data);
    }
    return valores;
  }
  
  @DataProvider ( name = "enlace_aduanero145")
  private Object[][] enlace_aduanero145() throws Exception{
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipo1erComp = new DatoDescrMinima();
    DatoDescrMinima subTipo1erComp = new DatoDescrMinima();
    DatoDescrMinima porcentaje1erComp = new DatoDescrMinima();
    DatoDescrMinima composicionForro = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima cantidad1erAccesorio = new DatoDescrMinima();
    DatoDescrMinima primerAccesorio = new DatoDescrMinima();
    DatoDescrMinima segundaAplicacion = new DatoDescrMinima();
    DatoDescrMinima cantidad2daAplicacion = new DatoDescrMinima();
    DatoDescrMinima medidas = new DatoDescrMinima();
    DatoDescrMinima presentacion = new DatoDescrMinima();
    DatoDescrMinima peso = new DatoDescrMinima();
    DatoDescrMinima uso = new DatoDescrMinima();
    DatoDescrMinima primeraAplicacion = new DatoDescrMinima();
    DatoDescrMinima cantidad1raAplicacion = new DatoDescrMinima();
    DatoDescrMinima terceraAplicacion = new DatoDescrMinima();
    DatoDescrMinima cantidad3raAplicacion =  new DatoDescrMinima();
    
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlMaletas/XML_MALETAS_CP00.xml";
    valores = getDuaFromXML(filename);
    
    
    nombreComercial.setCodtipvalor(valores.get("MA0000").get(0));
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri(valores.get("MA0000").get(1));
    
    marcaComercial.setCodtipvalor(valores.get("MA0001").get(0));
    marcaComercial.setCodtipdescr("MA0001");
    marcaComercial.setValtipdescri(valores.get("MA0001").get(1));
    
    modelo.setCodtipvalor(valores.get("MA0002").get(0));
    modelo.setCodtipdescr("MA0002");
    modelo.setValtipdescri(valores.get("MA0002").get(1));
    
    tipo1erComp.setCodtipvalor(valores.get("MA0003").get(0));
    tipo1erComp.setCodtipdescr("MA0003");
    tipo1erComp.setValtipdescri(valores.get("MA0003").get(1));
    
    subTipo1erComp.setCodtipvalor(valores.get("MA0004").get(0));
    subTipo1erComp.setCodtipdescr("MA0004");
    subTipo1erComp.setValtipdescri(valores.get("MA0004").get(1));
    
    porcentaje1erComp.setCodtipvalor(valores.get("MA0005").get(0));
    porcentaje1erComp.setCodtipdescr("MA0005");
    porcentaje1erComp.setValtipdescri(valores.get("MA0005").get(1));
    
    composicionForro.setCodtipvalor(valores.get("MA0012").get(0));
    composicionForro.setCodtipdescr("MA0012");
    composicionForro.setValtipdescri(valores.get("MA0012").get(1));
    
    primerAcabado.setCodtipvalor(valores.get("MA0013").get(0));
    primerAcabado.setCodtipdescr("MA0013");
    primerAcabado.setValtipdescri(valores.get("MA0013").get(1));
    
    primerAccesorio.setCodtipvalor(valores.get("MA0015").get(0));
    primerAccesorio.setCodtipdescr("MA0015");
    primerAccesorio.setValtipdescri(valores.get("MA0015").get(1));
    
    cantidad1erAccesorio.setCodtipvalor(valores.get("MA0016").get(0));
    cantidad1erAccesorio.setCodtipdescr("MA0016");
    cantidad1erAccesorio.setValtipdescri(valores.get("MA0016").get(1));
    
    primeraAplicacion.setCodtipvalor(valores.get("MA0021").get(0));
    primeraAplicacion.setCodtipdescr("MA0021");
    primeraAplicacion.setValtipdescri(valores.get("MA0021").get(1));
    
    cantidad1raAplicacion.setCodtipvalor(valores.get("MA0022").get(0));
    cantidad1raAplicacion.setCodtipdescr("MA0022");
    cantidad1raAplicacion.setValtipdescri(valores.get("MA0022").get(1));
    
    segundaAplicacion.setCodtipvalor(valores.get("MA0023").get(0));
    segundaAplicacion.setCodtipdescr("MA0023");
    segundaAplicacion.setValtipdescri(valores.get("MA0023").get(1));
    
    cantidad2daAplicacion.setCodtipvalor(valores.get("MA0024").get(0));
    cantidad2daAplicacion.setCodtipdescr("MA0024");
    cantidad2daAplicacion.setValtipdescri(valores.get("MA0024").get(1));
    
    terceraAplicacion.setCodtipvalor(valores.get("MA0025").get(0));
    terceraAplicacion.setCodtipdescr("MA0025");
    terceraAplicacion.setValtipdescri(valores.get("MA0025").get(1));
    
    cantidad3raAplicacion.setCodtipvalor(valores.get("MA0026").get(0));
    cantidad3raAplicacion.setCodtipdescr("MA0026");
    cantidad3raAplicacion.setValtipdescri(valores.get("MA0026").get(1));
    
    medidas.setCodtipvalor(valores.get("MA0017").get(0));
    medidas.setCodtipdescr("MA0017");
    medidas.setValtipdescri(valores.get("MA0017").get(1));
    
    presentacion.setCodtipvalor(valores.get("MA0018").get(0));
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri(valores.get("MA0018").get(1));
    
    peso.setCodtipvalor(valores.get("MA0019").get(0));
    peso.setCodtipdescr("MA0019");
    peso.setValtipdescri(valores.get("MA0019").get(1));
    
    uso.setCodtipvalor(valores.get("MA0019").get(0));
    uso.setCodtipdescr("MA0019");
    uso.setValtipdescri(valores.get("MA0019").get(1));
    
    maleta.setNombreComercial(nombreComercial);
    maleta.setMarcaComercial(marcaComercial);
    maleta.setModelo(modelo);
    maleta.setTipo1erComp(tipo1erComp);
    maleta.setSubTipo1erComp(subTipo1erComp);
    maleta.setPorcentaje1erComp(porcentaje1erComp);
    maleta.setComposicionForro(composicionForro);
    maleta.setPrimerAcabado(primerAcabado);
    maleta.setPrimerAccesorio(primerAccesorio);
    maleta.setCantidad1erAccesorio(cantidad1erAccesorio);
    maleta.setPrimeraAplicacion(primeraAplicacion);
    maleta.setSegundaAplicacion(segundaAplicacion);
    maleta.setTerceraAplicacion(terceraAplicacion);
    maleta.setCantidad1erAplicacion(cantidad1raAplicacion);
    maleta.setCantidad2daAplicacion(segundaAplicacion);
    maleta.setCantidad3erAplicacion(cantidad3raAplicacion);
    maleta.setMedidas(medidas);
    
    
    return new Object[][]{{maleta}};
  }
  
  @Test(dataProvider="enlace_aduanero145")
  public void validarAccesorios(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAccesorios(maleta),lstError);
  }
  
  @Test(dataProvider="enlace_aduanero145")
  public void validarAplicaciones(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(maleta),lstError);
  }

  @Test(dataProvider="enlace_aduanero145")
  public void validarMaterialMaletas(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMaterialMaletas(maleta),lstError);
  }
  
  @Test(dataProvider="enlace_aduanero145")
  public void validarMedidas(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(maleta),lstError);
  }
  
  @DataProvider ( name = "enlace_aduanero146")
  private Object[][] enlace_aduanero146() throws Exception{
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipo1erComp = new DatoDescrMinima();
    DatoDescrMinima subTipo1erComp = new DatoDescrMinima();
    DatoDescrMinima porcentaje1erComp = new DatoDescrMinima();
    DatoDescrMinima composicionForro = new DatoDescrMinima();
    DatoDescrMinima tipo2doComp = new DatoDescrMinima();
    DatoDescrMinima subTipo2doComp = new DatoDescrMinima();
    DatoDescrMinima porcentaje2doComp = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima cantidad1erAccesorio = new DatoDescrMinima();
    DatoDescrMinima primerAccesorio = new DatoDescrMinima();
    DatoDescrMinima medidas = new DatoDescrMinima();
    DatoDescrMinima presentacion = new DatoDescrMinima();
    DatoDescrMinima peso = new DatoDescrMinima();
    DatoDescrMinima uso = new DatoDescrMinima();
    DatoDescrMinima primeraAplicacion = new DatoDescrMinima();
    DatoDescrMinima cantidad1raAplicacion = new DatoDescrMinima();
    
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlMaletas/XML_MALETAS_CP01.xml";
    valores = getDuaFromXML(filename);
    
    
    nombreComercial.setCodtipvalor(valores.get("MA0000").get(0));
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri(valores.get("MA0000").get(1));
    
    marcaComercial.setCodtipvalor(valores.get("MA0001").get(0));
    marcaComercial.setCodtipdescr("MA0001");
    marcaComercial.setValtipdescri(valores.get("MA0001").get(1));
    
    modelo.setCodtipvalor(valores.get("MA0002").get(0));
    modelo.setCodtipdescr("MA0002");
    modelo.setValtipdescri(valores.get("MA0002").get(1));
    
    tipo1erComp.setCodtipvalor(valores.get("MA0003").get(0));
    tipo1erComp.setCodtipdescr("MA0003");
    tipo1erComp.setValtipdescri(valores.get("MA0003").get(1));
    
    subTipo1erComp.setCodtipvalor(valores.get("MA0004").get(0));
    subTipo1erComp.setCodtipdescr("MA0004");
    subTipo1erComp.setValtipdescri(valores.get("MA0004").get(1));
    
    porcentaje1erComp.setCodtipvalor(valores.get("MA0005").get(0));
    porcentaje1erComp.setCodtipdescr("MA0005");
    porcentaje1erComp.setValtipdescri(valores.get("MA0005").get(1));
    
    tipo2doComp.setCodtipvalor(valores.get("MA0006").get(0));
    tipo2doComp.setCodtipdescr("MA0006");
    tipo2doComp.setValtipdescri(valores.get("MA0006").get(1));
    
    subTipo2doComp.setCodtipvalor(valores.get("MA0007").get(0));
    subTipo2doComp.setCodtipdescr("MA0007");
    subTipo2doComp.setValtipdescri(valores.get("MA0007").get(1));
    
    porcentaje2doComp.setCodtipvalor(valores.get("MA0008").get(0));
    porcentaje2doComp.setCodtipdescr("MA0008");
    porcentaje2doComp.setValtipdescri(valores.get("MA0008").get(1));
    
    composicionForro.setCodtipvalor(valores.get("MA0012").get(0));
    composicionForro.setCodtipdescr("MA0012");
    composicionForro.setValtipdescri(valores.get("MA0012").get(1));
    
    primerAcabado.setCodtipvalor(valores.get("MA0013").get(0));
    primerAcabado.setCodtipdescr("MA0013");
    primerAcabado.setValtipdescri(valores.get("MA0013").get(1));
    
    primerAccesorio.setCodtipvalor(valores.get("MA0015").get(0));
    primerAccesorio.setCodtipdescr("MA0015");
    primerAccesorio.setValtipdescri(valores.get("MA0015").get(1));
    
    cantidad1erAccesorio.setCodtipvalor(valores.get("MA0016").get(0));
    cantidad1erAccesorio.setCodtipdescr("MA0016");
    cantidad1erAccesorio.setValtipdescri(valores.get("MA0016").get(1));
    
    primeraAplicacion.setCodtipvalor(valores.get("MA0021").get(0));
    primeraAplicacion.setCodtipdescr("MA0021");
    primeraAplicacion.setValtipdescri(valores.get("MA0021").get(1));
    
    cantidad1raAplicacion.setCodtipvalor(valores.get("MA0022").get(0));
    cantidad1raAplicacion.setCodtipdescr("MA0022");
    cantidad1raAplicacion.setValtipdescri(valores.get("MA0022").get(1));
    
    medidas.setCodtipvalor(valores.get("MA0017").get(0));
    medidas.setCodtipdescr("MA0017");
    medidas.setValtipdescri(valores.get("MA0017").get(1));
    
    presentacion.setCodtipvalor(valores.get("MA0018").get(0));
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri(valores.get("MA0018").get(1));
    
    peso.setCodtipvalor(valores.get("MA0019").get(0));
    peso.setCodtipdescr("MA0019");
    peso.setValtipdescri(valores.get("MA0019").get(1));
    
    uso.setCodtipvalor(valores.get("MA0019").get(0));
    uso.setCodtipdescr("MA0019");
    uso.setValtipdescri(valores.get("MA0019").get(1));
    
    maleta.setNombreComercial(nombreComercial);
    maleta.setMarcaComercial(marcaComercial);
    maleta.setModelo(modelo);
    maleta.setTipo1erComp(tipo1erComp);
    maleta.setSubTipo1erComp(subTipo1erComp);
    maleta.setPorcentaje1erComp(porcentaje1erComp);
    maleta.setComposicionForro(composicionForro);
    maleta.setTipo2doComp(tipo2doComp);
    maleta.setSubTipo2doComp(subTipo2doComp);
    maleta.setPorcentaje2doComp(porcentaje2doComp);
    maleta.setPrimerAcabado(primerAcabado);
    maleta.setPrimerAccesorio(primerAccesorio);
    maleta.setCantidad1erAccesorio(cantidad1erAccesorio);
    maleta.setPrimeraAplicacion(primeraAplicacion);
    maleta.setCantidad1erAplicacion(cantidad1raAplicacion);
    maleta.setMedidas(medidas);
    
    
    return new Object[][]{{maleta}};
  }
  
  @Test(dataProvider="enlace_aduanero146")
  public void validarAccesorios146(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAccesorios(maleta),lstError);
  }
  
  @Test(dataProvider="enlace_aduanero146")
  public void validarAplicaciones146(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(maleta),lstError);
  }

  @Test(dataProvider="enlace_aduanero146")
  public void validarMaterialMaletas146(ModelAbstract maleta){
    Assert.assertEquals(validador.validarMaterialMaletas(maleta).size(),0);
  }
  
  @Test(dataProvider="enlace_aduanero146")
  public void validarMedidas146(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(maleta),lstError);
  }
  @DataProvider ( name = "rapiaduanas_147")
  private Object[][] rapiaduanas_147() throws Exception{
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipo1erComp = new DatoDescrMinima();
    DatoDescrMinima subTipo1erComp = new DatoDescrMinima();
    DatoDescrMinima porcentaje1erComp = new DatoDescrMinima();
    DatoDescrMinima tipo2doComp = new DatoDescrMinima();
    DatoDescrMinima subTipo2doComp = new DatoDescrMinima();
    DatoDescrMinima porcentaje2doComp = new DatoDescrMinima();
    DatoDescrMinima composicionForro = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima cantidad1erAccesorio = new DatoDescrMinima();
    DatoDescrMinima primerAccesorio = new DatoDescrMinima();
    DatoDescrMinima medidas = new DatoDescrMinima();
    DatoDescrMinima presentacion = new DatoDescrMinima();
    DatoDescrMinima peso = new DatoDescrMinima();
    DatoDescrMinima uso = new DatoDescrMinima();
    DatoDescrMinima primeraAplicacion = new DatoDescrMinima();
    DatoDescrMinima cantidad1raAplicacion = new DatoDescrMinima();
    
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlMaletas/XML_MALETAS_CP02.xml";
    valores = getDuaFromXML(filename);
    
    
    nombreComercial.setCodtipvalor(valores.get("MA0000").get(0));
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri(valores.get("MA0000").get(1));
    
    marcaComercial.setCodtipvalor(valores.get("MA0001").get(0));
    marcaComercial.setCodtipdescr("MA0001");
    marcaComercial.setValtipdescri(valores.get("MA0001").get(1));
    
    modelo.setCodtipvalor(valores.get("MA0002").get(0));
    modelo.setCodtipdescr("MA0002");
    modelo.setValtipdescri(valores.get("MA0002").get(1));
    
    tipo1erComp.setCodtipvalor(valores.get("MA0003").get(0));
    tipo1erComp.setCodtipdescr("MA0003");
    tipo1erComp.setValtipdescri(valores.get("MA0003").get(1));
    
    subTipo1erComp.setCodtipvalor(valores.get("MA0004").get(0));
    subTipo1erComp.setCodtipdescr("MA0004");
    subTipo1erComp.setValtipdescri(valores.get("MA0004").get(1));
    
    porcentaje1erComp.setCodtipvalor(valores.get("MA0005").get(0));
    porcentaje1erComp.setCodtipdescr("MA0005");
    porcentaje1erComp.setValtipdescri(valores.get("MA0005").get(1));
    
    tipo2doComp.setCodtipvalor(valores.get("MA0006").get(0));
    tipo2doComp.setCodtipdescr("MA0006");
    tipo2doComp.setValtipdescri(valores.get("MA0006").get(1));
    
    subTipo2doComp.setCodtipvalor(valores.get("MA0007").get(0));
    subTipo2doComp.setCodtipdescr("MA0007");
    subTipo2doComp.setValtipdescri(valores.get("MA0007").get(1));
    
    porcentaje2doComp.setCodtipvalor(valores.get("MA0008").get(0));
    porcentaje2doComp.setCodtipdescr("MA0008");
    porcentaje2doComp.setValtipdescri(valores.get("MA0008").get(1));
    
    composicionForro.setCodtipvalor(valores.get("MA0012").get(0));
    composicionForro.setCodtipdescr("MA0012");
    composicionForro.setValtipdescri(valores.get("MA0012").get(1));
    
    primerAcabado.setCodtipvalor(valores.get("MA0013").get(0));
    primerAcabado.setCodtipdescr("MA0013");
    primerAcabado.setValtipdescri(valores.get("MA0013").get(1));
    
    primerAccesorio.setCodtipvalor(valores.get("MA0015").get(0));
    primerAccesorio.setCodtipdescr("MA0015");
    primerAccesorio.setValtipdescri(valores.get("MA0015").get(1));
    
    cantidad1erAccesorio.setCodtipvalor(valores.get("MA0016").get(0));
    cantidad1erAccesorio.setCodtipdescr("MA0016");
    cantidad1erAccesorio.setValtipdescri(valores.get("MA0016").get(1));
    
    primeraAplicacion.setCodtipvalor(valores.get("MA0021").get(0));
    primeraAplicacion.setCodtipdescr("MA0021");
    primeraAplicacion.setValtipdescri(valores.get("MA0021").get(1));
    
    cantidad1raAplicacion.setCodtipvalor(valores.get("MA0022").get(0));
    cantidad1raAplicacion.setCodtipdescr("MA0022");
    cantidad1raAplicacion.setValtipdescri(valores.get("MA0022").get(1));
    
    medidas.setCodtipvalor(valores.get("MA0017").get(0));
    medidas.setCodtipdescr("MA0017");
    medidas.setValtipdescri(valores.get("MA0017").get(1));
    
    presentacion.setCodtipvalor(valores.get("MA0018").get(0));
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri(valores.get("MA0018").get(1));
    
    peso.setCodtipvalor(valores.get("MA0019").get(0));
    peso.setCodtipdescr("MA0019");
    peso.setValtipdescri(valores.get("MA0019").get(1));
    
    uso.setCodtipvalor(valores.get("MA0019").get(0));
    uso.setCodtipdescr("MA0019");
    uso.setValtipdescri(valores.get("MA0019").get(1));
    
    maleta.setNombreComercial(nombreComercial);
    maleta.setMarcaComercial(marcaComercial);
    maleta.setModelo(modelo);
    maleta.setTipo1erComp(tipo1erComp);
    maleta.setSubTipo1erComp(subTipo1erComp);
    maleta.setPorcentaje1erComp(porcentaje1erComp);
    maleta.setTipo2doComp(tipo2doComp);
    maleta.setSubTipo2doComp(subTipo2doComp);
    maleta.setPorcentaje2doComp(porcentaje2doComp);
    maleta.setComposicionForro(composicionForro);
    maleta.setPrimerAcabado(primerAcabado);
    maleta.setPrimerAccesorio(primerAccesorio);
    maleta.setCantidad1erAccesorio(cantidad1erAccesorio);
    maleta.setPrimeraAplicacion(primeraAplicacion);
    maleta.setCantidad1erAplicacion(cantidad1raAplicacion);
    maleta.setMedidas(medidas);
    
    
    return new Object[][]{{maleta}};
  
  }
  
  @Test(dataProvider="rapiaduanas_147")
  public void validarAccesorios147(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAccesorios(maleta),lstError);
  }
  
  @Test(dataProvider="rapiaduanas_147")
  public void validarAplicaciones147(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(maleta),lstError);
  }

  @Test(dataProvider="rapiaduanas_147")
  public void validarMaterialMaletas147(ModelAbstract maleta){
    List<ErrorDescrMinima> lstError = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMaterialMaletas(maleta),lstError);
  }
  
  @Test(dataProvider="rapiaduanas_147")
  public void validarMedidas147(ModelAbstract maleta){
    Assert.assertEquals(validador.validarMedidas(maleta).size(),1);
  }
  
}
