package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilHilado;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

/*
 * @author lalberti
 */
public class ValidadorTextilHiladoTest extends AbstractServiceTest {
  @Autowired
  @Qualifier("ValidadorTextilHilado")
  private ValidadorTextilHilado validador = new ValidadorTextilHilado();
  private static final String CATALOGO = "0";
  private static final String TEXTO    = "1";

  @DataProvider( name = "initDataHyC67" )
  private Object[][] initDataUnidaComercialInvalido(){
    TextilHilado hilado              = new TextilHilado();
    Declaracion dua                  = new Declaracion();

    DatoDescrMinima nombreComercial  = new DatoDescrMinima();
    DatoDescrMinima marcaComercial   = new DatoDescrMinima();
    DatoDescrMinima modelo           = new DatoDescrMinima();
    DatoDescrMinima tipoFibra        = new DatoDescrMinima();
    DatoDescrMinima tipoHilado       = new DatoDescrMinima();
    DatoDescrMinima CompoHilado1erComp = new DatoDescrMinima();
    DatoDescrMinima compoHilado1erPorc = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion   = new DatoDescrMinima();
    DatoDescrMinima primerAcabado      = new DatoDescrMinima();
    DatoDescrMinima presentacion       = new DatoDescrMinima();
    DatoDescrMinima densidadLineal     = new DatoDescrMinima();
    DatoDescrMinima estructuraFisica   = new DatoDescrMinima();

    hilado.setNumcorredoc(new Long(1));
    hilado.setNumsecfact(1);
    hilado.setNumsecitem(1);
    hilado.setNumsecprove(1);

    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("KG");
    item.setNumpartnandi(new Long(5402330000L));
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    nombreComercial.setCodtipvalor(TEXTO);
    nombreComercial.setCodtipdescr("TE0200");
    nombreComercial.setValtipdescri("Filamento Poliester Texturizado");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("TE0201");
    marcaComercial.setValtipdescri("S/M");

    modelo.setCodtipvalor(TEXTO);
    modelo.setCodtipdescr("TE0202");
    modelo.setValtipdescri("S/M");

    tipoFibra.setCodtipvalor(CATALOGO);
    tipoFibra.setCodtipdescr("TE0203");
    tipoFibra.setValtipdescri("");

    tipoHilado.setCodtipvalor(CATALOGO);
    tipoHilado.setCodmercancia("TE0204");
    tipoHilado.setValtipdescri("");

    CompoHilado1erComp.setCodtipvalor(CATALOGO);
    CompoHilado1erComp.setCodtipdescr("TE0205");
    CompoHilado1erComp.setValtipdescri("");

    compoHilado1erPorc.setCodtipvalor(TEXTO);
    compoHilado1erPorc.setCodtipdescr("TE0206");
    compoHilado1erPorc.setValtipdescri("0");

    gradoElaboracion.setCodtipvalor(CATALOGO);
    gradoElaboracion.setCodtipdescr("TE207");
    gradoElaboracion.setValtipdescri("CRU");

    primerAcabado.setCodtipvalor(CATALOGO);
    primerAcabado.setCodtipdescr("TE0208");
    primerAcabado.setValtipdescri("APL");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("TE210");
    presentacion.setValtipdescri("BOB");

    densidadLineal.setCodtipvalor(TEXTO);
    densidadLineal.setCodtipdescr("TE0211");
    densidadLineal.setValtipdescri("1233.12345");

    estructuraFisica.setCodtipvalor(TEXTO);
    estructuraFisica.setCodtipvalor("TE0212");
    estructuraFisica.setValtipdescri("RENDIMIENTO DEL 150/48 ES DE 60,000 MTS/KILO FABRICACION DE HILOS Y TELAS. torsión S y 96 filamentos por cabo");

    hilado.setNombreComercial(nombreComercial);
    hilado.setMarcaComercial(marcaComercial);
    hilado.setModelo(modelo);
    hilado.setTipoFibra(tipoFibra);
    hilado.setTipoHilado(tipoHilado);
    hilado.setGradoElaboracion(gradoElaboracion);
    hilado.setPrimerAcabado(primerAcabado);
    hilado.setPresentacion(presentacion);
    hilado.setDencidadLineal(densidadLineal);
//    hilado.setEstructuraFisicaYUso(estructuraFisica);
    hilado.setCompoHiladoPorcen1erComp(compoHilado1erPorc);

    return new Object[][]{{ hilado, dua }};
  }

  @Test (dataProvider = "initDataHyC67")
  public void validarUnidaComercialInvalido(ModelAbstract object,
                                            Declaracion dua){
//    DatoItem item =  dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
//    Assert.assertEquals(validador.validarUnidadComercial(object, item).size(),0);
  }

  @Test (dataProvider = "initDataHyC67")
  public void validarDensidadLineal(ModelAbstract object,
                                    Declaracion dua){
    Assert.assertEquals(validador.validarDensidadLineal(object).get(0).getCodigo(),"31368");
  }

  @Test (dataProvider = "initDataHyC67")
  public void validarSumaPorcentaje(ModelAbstract object,
                                    Declaracion dua){
    Assert.assertEquals(validador.validarSumaPorcenComp(object).get(0).getCodigo(),"31369");
  }

  @DataProvider(name = "initDataIA84")
  private Object[][] initDataIA84(){

    Declaracion dua = new Declaracion();
    DatoItem item = new DatoItem();
    DUA dam = new DUA();
    TextilHilado hilado = new TextilHilado();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipoFibra = new DatoDescrMinima();
    DatoDescrMinima tipoHilado = new DatoDescrMinima();
    DatoDescrMinima compo1erComponente = new DatoDescrMinima();
    DatoDescrMinima compo1erPorcentaje = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();

    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    hilado.setNumcorredoc(new Long(1));
    hilado.setNumsecfact(1);
    hilado.setNumsecitem(1);
    hilado.setNumsecprove(1);

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();

    item.setNumpartnandi(new Long(54041110));
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("KG");
    item.setCodestamer("99");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    nombreComercial.setCodtipvalor(TEXTO);
    nombreComercial.setCodtipdescr("");
    nombreComercial.setValtipdescri("Hilados de Tejer");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("");
    marcaComercial.setValtipdescri("INVIOSTA");

    modelo.setCodtipvalor(TEXTO);
    modelo.setCodtipdescr("");
    modelo.setValtipdescri("162C");

    tipoFibra.setCodtipvalor(CATALOGO);
    tipoFibra.setCodtipdescr("");
    tipoFibra.setValtipdescri("FIL");

    tipoHilado.setCodtipvalor(CATALOGO);
    tipoHilado.setCodtipdescr("");
    tipoHilado.setValtipdescri("SEN");

    compo1erComponente.setCodtipvalor(CATALOGO);
    compo1erComponente.setCodtipdescr("");
    compo1erComponente.setValtipdescri("PU");

    compo1erPorcentaje.setCodtipvalor(TEXTO);
    compo1erPorcentaje.setCodtipdescr("");
    compo1erPorcentaje.setValtipdescri("100");

    gradoElaboracion.setCodtipvalor(CATALOGO);
    gradoElaboracion.setCodtipdescr("");
    gradoElaboracion.setValtipdescri("CRU");

    primerAcabado.setCodtipvalor(CATALOGO);
    primerAcabado.setCodtipdescr("");
    primerAcabado.setValtipdescri("");

    hilado.setNombreComercial(nombreComercial);
    hilado.setMarcaComercial(marcaComercial);
    hilado.setModelo(modelo);

    hilado.setTipoHilado(tipoHilado);
    hilado.setCompoHilado1erComp(compo1erComponente);

    hilado.setCompoHiladoPorcen2doComp(compo1erPorcentaje);
    hilado.setPrimerAcabado(primerAcabado);

    return new Object[][]{{hilado, dua}};
  }

  @Test(dataProvider="initDataIA84")
  public void validarUnidadComercial84Test(ModelAbstract object, Declaracion dua){
//    DatoItem item= dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
//    Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 0);
  }

  @DataProvider(name="initDataDyG67")
  private Object[][] initDataDyG67(){

    TextilHilado hilado = new TextilHilado();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipoFibra = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima uso = new DatoDescrMinima();
    DatoDescrMinima presentacion = new DatoDescrMinima();
    DatoDescrMinima densidad = new DatoDescrMinima();

    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("KG");
    item.setNumpartnandi(new Long(5402330000L));
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    nombreComercial.setCodtipvalor(TEXTO);
    nombreComercial.setCodtipdescr("");
    nombreComercial.setValtipdescri("FILAMENTO POLYESTER TEXTURIZADO");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("");
    marcaComercial.setValtipdescri("S/M");

    modelo.setCodtipvalor(TEXTO);
    modelo.setCodtipdescr("");
    modelo.setValtipdescri("S/M");

    tipoFibra.setCodtipvalor(CATALOGO);
    tipoFibra.setCodtipdescr("");
    tipoFibra.setValtipdescri("");

    primerAcabado.setCodtipvalor(TEXTO);
    primerAcabado.setCodtipdescr("");
    primerAcabado.setValtipdescri("TEXTURIZADO");

    gradoElaboracion.setCodtipvalor(CATALOGO);
    gradoElaboracion.setCodtipdescr("");
    gradoElaboracion.setValtipdescri("CRU");

    uso.setCodtipvalor(TEXTO);
    uso.setCodtipdescr("");
    uso.setValtipdescri("RENDIMIENTO DEL 150/48 ES DE 60,000 MTS/KILO FABRICACION DE HILOS Y TELAS. torsión S y 96 filamentos por cabo");

    densidad.setCodtipvalor(TEXTO);
    densidad.setCodtipdescr("");
    densidad.setValtipdescri("0");

    presentacion.setValtipdescri(CATALOGO);
    presentacion.setCodtipdescr("");
    presentacion.setValtipdescri("BOB");

    hilado.setNombreComercial(nombreComercial);
    hilado.setMarcaComercial(marcaComercial);
    hilado.setModelo(modelo);
    hilado.setTipoFibra(tipoFibra);
//    hilado.setEstructuraFisicaYUso(uso);
    hilado.setGradoElaboracion(gradoElaboracion);
    hilado.setDencidadLineal(densidad);
    hilado.setPresentacion(presentacion);
    hilado.setPrimerAcabado(primerAcabado);

    return new Object[][]{{hilado,dua}};
  }

  @Test(dataProvider="initDataDyG67")
  public void validarUnidadComercial67(ModelAbstract object, Declaracion dua){
//    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
//    Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 0);
  }

  @Test(dataProvider = "initDataDyG67")
  public void validarDesnsidadLineal67(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarDensidadLineal(object).size(),0);
  }

  @Test(dataProvider = "initDataDyG67")
  public void validarSumaPorcentajes67(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarSumaPorcenComp(object).size(), 0);
  }
}
