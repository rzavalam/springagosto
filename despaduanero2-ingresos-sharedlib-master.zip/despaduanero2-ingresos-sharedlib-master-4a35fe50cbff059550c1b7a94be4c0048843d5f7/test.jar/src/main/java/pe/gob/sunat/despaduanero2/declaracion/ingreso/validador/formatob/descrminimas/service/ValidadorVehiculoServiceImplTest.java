package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.service;
 
import static pe.gob.sunat.despaduanero2.util.ConstantesDataCatalogo.REG_IMPO_CONSUMO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.model.DataCatalogo; 
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoDocTransporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoManifiesto;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoOtroDocSoporte;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPago;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoPagoTrans;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoRegPrecedencia;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerie;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.despaduanero2.model.Participante;
import pe.gob.sunat.despaduanero2.util.SunatDateUtils;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorVehiculoServiceImplTest extends AbstractServiceTest  {

  protected final Log log = LogFactory.getLog(getClass());
  public static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
  private Declaracion declaracion;
  private Vehiculo    vehiculo;

@Autowired
private FabricaDeServicios fabricaDeServicios; 

@Autowired
@Qualifier("ValidadorVehiculoService")
private ValidadorVehiculoService validadorVehic;

@BeforeClass
public void initData() throws Exception
  {
		    System.out.println("LOAD TEST UNITARIOS ... ");

		    Vehiculo vehiculo = new Vehiculo();
		    Declaracion declaracion = new Declaracion();
		    DUA dua = new DUA();
		    DatoSerie datoserie = new DatoSerie();
		    DatoRegPrecedencia datoregprecedencia = new DatoRegPrecedencia();
		    // CodRegimenPrecedente
		    datoregprecedencia.setCodregipre("91");
		    //Trato preferencial
		    Elementos<DatoSerie> listDatoSerie = new Elementos<DatoSerie>();
		    Elementos<DatoSerieItem> listSerieItems = new Elementos<DatoSerieItem>();
		    Elementos<DatoRegPrecedencia> listRegPrecedencia = new Elementos<DatoRegPrecedencia>();
		    listRegPrecedencia.add(datoregprecedencia);
		    datoserie.setListRegPrecedencia(listRegPrecedencia);
		    //Trato preferencial
		    datoserie.setCodtratprefe(100); // �tem de la serie que le corresponde
		    // Codestamer
		    datoserie.setCodestamerca("20");
		    // paisOrigen
		    datoserie.setCodpaisorige("JP");
		    //numSerie
		    datoserie.setNumserie(1);
		    datoserie.setCodliberatorio(2002);
		    listDatoSerie.add(datoserie);
		    dua.setListSeries(listDatoSerie);
		    
		    //dato de Otro doc Soporte
		    DatoOtroDocSoporte datoSoporte = new DatoOtroDocSoporte();
		    Elementos<DatoOtroDocSoporte> listDatoSoporte = new Elementos<DatoOtroDocSoporte>();
		    datoSoporte.setNumserie(1);
		    datoSoporte.setCodtipoproceso("P");
		    datoSoporte.setCodtipodocasoc("02");
		    datoSoporte.setAnndocasoc("2013");
		    datoSoporte.setNumdocasoc("01");
		    datoSoporte.setNumsecdocum(22);
		    datoSoporte.setFecdocasoc(new Date(20130511));
		    
		    listDatoSoporte.add(datoSoporte);
		    dua.setListOtrosDocSoporte(listDatoSoporte);
		    
		    //fechaNumeracion
		   // Integer year = 2010;
		    Date fecNumeracion = sdf.parse("2009-05-01"); 
		    dua.setFecNumeracion(fecNumeracion);
		    //fechaTermino
		    Date fechaTermino = sdf.parse("2014-05-21");
		    DatoManifiesto manif = new DatoManifiesto();
		    manif.setFectermino(fechaTermino); 
		    dua.setManifiesto(manif);
		    //Fechaembarque
		    Date fecembarque01 = sdf.parse("2010-01-01");
		    Date fecembarque02 = sdf.parse("2009-08-01");
		    Elementos<DatoDocTransporte> ListDocumentos = new Elementos<DatoDocTransporte>();
		    DatoDocTransporte documento1 = new DatoDocTransporte();
		    documento1.setFecembarque(fecembarque01);
		    documento1.setNumserie(1);
		    documento1.setNumsecdoctrans(223);			
		    DatoDocTransporte documento2 = new DatoDocTransporte();
		    documento2.setFecembarque(fecembarque02);
		    documento2.setNumserie(2);
		    documento1.setNumsecdoctrans(423);		 
		    ListDocumentos.add(documento1);
		    ListDocumentos.add(documento2);
		    dua.setListDocTransporte(ListDocumentos);
		    //TipoParticipante
		    DataCatalogo cod_participante = new DataCatalogo();
		    cod_participante.setCodDatacat("45");
		    Participante participante =  new Participante();
		    participante.setTipoParticipante(cod_participante);
		    participante.setNumeroDocumentoIdentidad("20165465009");
		    dua.setDeclarante(participante);
		    //Codigo Aduana
		    dua.setCodaduanaorden("018");
		    //Numero Documento
		    dua.setNumdocumento("12656845");
		    dua.setCodtipotratamiento("4"); 
		    dua.setCodregimen("10"); 
		    DatoPago pago = new DatoPago();
		    DatoPagoTrans pagoDatoPagoTrans = new DatoPagoTrans();
		    pagoDatoPagoTrans.setFeccarcr(SunatDateUtils.getDateFromInteger(20090501));
		    pago.setPagoTransaccion(pagoDatoPagoTrans);
		    dua.setPago(pago);
		    declaracion.setDua(dua);

		    Elementos<DAV> listDAVs = new Elementos<DAV>();
		    DAV dav = new DAV();
		    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
		    DatoFactura factu = new DatoFactura();
		    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
		    DatoItem item = new DatoItem();
		    item.setNumpartnandi(new Long("8703900090"));
		    item.setNumsecitem(3);
		    item.setNumsecprove(2);
		    item.setNumsecfact(33);
		    // A�o fabrica
		    item.setAnnfabrica("2008");
		    //Estado mercancia
		    item.setCodestamer("20");
		    // paisOrigen
		    item.setCodpaisorige("JP");

		    DatoSerieItem datoSerieItem = new DatoSerieItem();
		    datoSerieItem.setNumserie(1);
		    listSerieItems.add(datoSerieItem);
		    item.setListSerieItems(listSerieItems);
		    lstitem.add(item);
		    factu.setListItems(lstitem);
		    lstFactu.add(factu);
		    dav.setListFacturas(lstFactu);
		    listDAVs.add(dav);
		    declaracion.setListDAVs(listDAVs);
   	    
		    //Nombre comercial = Categoria
		    DatoDescrMinima nombreComercial = new DatoDescrMinima();
		    nombreComercial.setValtipdescri("M2"); // L1/L2/L3/L4/L5/M/M1/M2/M3/N/N1/N2/N3/O/O1/O2/O3/O4
		    nombreComercial.setNumsecitem(3);
		    vehiculo.setNombreComercial(nombreComercial);
		    //setNombreComercial(nombreComercial);
		    //Carroceria
		    DatoDescrMinima carroceria = new DatoDescrMinima();
		    carroceria.setValtipdescri("BAD"); //001,863,AMB,ARE,ART,ASF,AUX,BAD,BAR,BHO,BIA,BMT,BOB,BOM,CAB,CAN.CBA,CCG,CEL,CHC,CHM...
		    vehiculo.setCarroceria(carroceria);
		    //Marca Comercial
		    DatoDescrMinima marcaComercial = new DatoDescrMinima();
		    marcaComercial.setValtipdescri("5R"); //001,5R,A-1,A1,AAA,AAC,LAN,LCA,LCH,LCN,ZYX,ZZZ,min
		    vehiculo.setMarcaComercial(marcaComercial);
		    //Modelo
		    DatoDescrMinima modelo = new DatoDescrMinima();
		    modelo.setValtipdescri("G25"); //001,002,003,004,005,006,007,008,009,00A,00B,00C...
		    vehiculo.setModelo(modelo);
		    //ColorPrincipal
		    DatoDescrMinima colorPrincipal = new DatoDescrMinima();
		    colorPrincipal.setValtipdescri("AMA"); //868,AMA,ANA,AZU,BEI,BLA,CEL,CRE,DOR,FUC....
		    vehiculo.setColorPrincipal(colorPrincipal);
		    //ColorSecundario
		    DatoDescrMinima colorSecundario = new DatoDescrMinima();
		    colorSecundario.setValtipdescri("FUC"); //868,AMA,ANA,AZU,BEI,BLA,CEL,CRE,DOR,FUC....
		    vehiculo.setColorSecundario(colorSecundario);
		    //numeroHomologacionMTC
		    DatoDescrMinima numeroHomologacionMTC = new DatoDescrMinima();
		    numeroHomologacionMTC.setValtipdescri("ABCDE12345"); //NO HAY CATALOGO
		    vehiculo.setNumeroHomologacionMTC(numeroHomologacionMTC);
		    //IndicadorSNTT
		    DatoDescrMinima indicadorSNTT = new DatoDescrMinima();
		    indicadorSNTT.setValtipdescri("0"); //0,1
		    vehiculo.setIndicadorSNTT(indicadorSNTT);
		    //TipoCombustible
		    DatoDescrMinima tipoCombustible = new DatoDescrMinima();
		    tipoCombustible.setValtipdescri(""); //ACE,BDS,BIE,BIL,BIN,CCO,DSL,DUE,DUL,DUN,ELT,ETA,FLX,GLP,GNL,GNV,GSL,HDB,HGB,HID,SOL
		    vehiculo.setTipoCombustible(tipoCombustible);
		    //Categoria
		    DatoDescrMinima categoria = new DatoDescrMinima();
		    categoria.setValtipdescri("M2"); // L1/L2/L3/L4/L5/M/M1/M2/M3/N/N1/N2/N3/O/O1/O2/O3/O4
		    vehiculo.setCategoria(categoria);
		    //NumeroChasis
		    DatoDescrMinima numeroChasis = new DatoDescrMinima();
		    numeroChasis.setValtipdescri("CHM"); //NO HAY CATALOGO
		    vehiculo.setNumeroChasis(numeroChasis);
		    //Version
		    DatoDescrMinima version = new DatoDescrMinima();
		    version.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setVersion(version);
		    //NumeroCilindros
		    DatoDescrMinima numeroCilindros = new DatoDescrMinima();
		    numeroCilindros.setValtipdescri("0"); //NO HAY CATALOGO
		    vehiculo.setNumeroCilindros(numeroCilindros);
		    //TipoMoto
		    DatoDescrMinima tipoMoto = new DatoDescrMinima();
		    tipoMoto.setValtipdescri(""); //DCD,TTR,PIS,CRU,SCO
		    vehiculo.setTipoMoto(tipoMoto);
		    //CilindradaCC
		    DatoDescrMinima cilindradaCC = new DatoDescrMinima();
		    cilindradaCC.setValtipdescri("30"); //NO HAY CATALOGO
		    vehiculo.setCilindradaCC(cilindradaCC);
		    //TipoEncendido
		    DatoDescrMinima tipoEncendido = new DatoDescrMinima();
		    tipoEncendido.setValtipdescri(""); //CHI,COM,ZZZ
		    //tipoEncendido.setCodtipvalor("CAMPOENCENDIDO123452"); //NO HAY CATALOGO
		    vehiculo.setTipoEncendido(tipoEncendido);
		    //NumeroAsientos
		    DatoDescrMinima numeroAsientos = new DatoDescrMinima();
		    numeroAsientos.setValtipdescri("8"); //NO HAY CATALOGO
		    vehiculo.setNumeroAsientos(numeroAsientos);
		    //CantidadEjes
		    DatoDescrMinima cantidadEjes = new DatoDescrMinima();
		    cantidadEjes.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setCantidadEjes(cantidadEjes);
		    //FormulaRodante - TipoTraccion
		    DatoDescrMinima tipoTraccion = new DatoDescrMinima();
		    tipoTraccion.setValtipdescri(""); //104,108,2X1,3X1,3X2,4X2,4X4,62B,62C,6X2,6X4,6X6,824,826,84B,84C,864,8x2,8X4
		    vehiculo.setTipoTraccion(tipoTraccion);
		    //NumeroMotor
		    DatoDescrMinima numeroMotor = new DatoDescrMinima();
		    numeroMotor.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setNumeroMotor(numeroMotor);
		    //PesoMaximoEjeDelantero
		    DatoDescrMinima pesoMaximoEjeDelantero = new DatoDescrMinima();
		    pesoMaximoEjeDelantero.setValtipdescri("16000"); //NO HAY CATALOGO
		    vehiculo.setPesoMaximoEjeDelantero(pesoMaximoEjeDelantero);
		    //PesoMaximoEjePosterior1
		    DatoDescrMinima pesoMaximoEjePosterior1 = new DatoDescrMinima();
		    pesoMaximoEjePosterior1.setValtipdescri("24000"); //NO HAY CATALOGO
		    vehiculo.setPesoMaximoEjePosterior1(pesoMaximoEjePosterior1);
		    //PesoMaximoEjePosterior2
		    DatoDescrMinima pesoMaximoEjePosterior2 = new DatoDescrMinima();
		    pesoMaximoEjePosterior2.setValtipdescri("26000"); //NO HAY CATALOGO
		    vehiculo.setPesoMaximoEjePosterior2(pesoMaximoEjePosterior2);
		    //PesoMaximoEjePosterior3
		    DatoDescrMinima pesoMaximoEjePosterior3 = new DatoDescrMinima();
		    pesoMaximoEjePosterior3.setValtipdescri("23000"); //NO HAY CATALOGO
		    vehiculo.setPesoMaximoEjePosterior3(pesoMaximoEjePosterior3);
		    //LargoMM
		    DatoDescrMinima largoMM = new DatoDescrMinima();
		    largoMM.setValtipdescri("24000"); //NO HAY CATALOGO
		    vehiculo.setLargoMM(largoMM);
		    //AnchoMM
		    DatoDescrMinima anchoMM = new DatoDescrMinima();
		    anchoMM.setValtipdescri("27000"); //NO HAY CATALOGO
		    vehiculo.setAnchoMM(anchoMM);
		    //AltoMM
		    DatoDescrMinima altoMM = new DatoDescrMinima();
		    altoMM.setValtipdescri("4301"); //NO HAY CATALOGO
		    vehiculo.setAltoMM(altoMM);
		    //NumeroCambiosDeCaja
		    DatoDescrMinima numeroCambiosDeCaja = new DatoDescrMinima();
		    numeroCambiosDeCaja.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setNumeroCambiosDeCaja(numeroCambiosDeCaja);
		    //RelacionPotenciaPesoBruto
		    DatoDescrMinima relacionPotenciaPesoBruto = new DatoDescrMinima();
		    relacionPotenciaPesoBruto.setValtipdescri("3.15"); //NO HAY CATALOGO
		    vehiculo.setRelacionPotenciaPesoBruto(relacionPotenciaPesoBruto);
		    //PesoBrutoCombinado
		    DatoDescrMinima pesoBrutoCombinado = new DatoDescrMinima();
		    pesoBrutoCombinado.setValtipdescri("1000,20"); //NO HAY CATALOGO
		    vehiculo.setPesoBrutoCombinado(pesoBrutoCombinado);
		    //PesoBrutoKG
		    DatoDescrMinima pesoBrutoKG = new DatoDescrMinima();
		    pesoBrutoKG.setValtipdescri("1234569"); //NO HAY CATALOGO
		    vehiculo.setPesoBrutoKG(pesoBrutoKG);
		    //PesoNetoKG
		    DatoDescrMinima pesoNetoKG = new DatoDescrMinima();
		    pesoNetoKG.setValtipdescri("1234567"); //NO HAY CATALOGO
		    vehiculo.setPesoNetoKG(pesoNetoKG);
		    //CargaUtilKG
		    DatoDescrMinima cargaUtilKG = new DatoDescrMinima();
		    cargaUtilKG.setValtipdescri("60"); //NO HAY CATALOGO
		    vehiculo.setCargaUtilKG(cargaUtilKG);
		    //NumeroPasajeros
		    DatoDescrMinima numeroPasajeros = new DatoDescrMinima();
		    numeroPasajeros.setValtipdescri("7"); //NO HAY CATALOGO
		    vehiculo.setNumeroPasajeros(numeroPasajeros);
		    //PotenciaMotorKW
		    DatoDescrMinima potenciaMotorKW = new DatoDescrMinima();
		    potenciaMotorKW.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setPotenciaMotorKW(potenciaMotorKW);
		    //PotenciaMotorRPM
		    DatoDescrMinima potenciaMotorRPM = new DatoDescrMinima();
		    potenciaMotorRPM.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setPotenciaMotorRPM(potenciaMotorRPM);
		    //TipoTransmicion
		    DatoDescrMinima tipoTransmicion = new DatoDescrMinima();
		    tipoTransmicion.setValtipdescri(""); // AUT,CVT,MEC,SAT
		    vehiculo.setTipoTransmision(tipoTransmicion);
		    //MedidaAros
		    DatoDescrMinima medidaAros = new DatoDescrMinima();
		    medidaAros.setValtipdescri("30/80"); //NO HAY CATALOGO
		    vehiculo.setMedidaAros(medidaAros);
		    //MedidaNeumaticos1
		    DatoDescrMinima medidaNeumaticos1 = new DatoDescrMinima();
		    medidaNeumaticos1.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setMedidaNeumaticos1(medidaNeumaticos1);
		    //MedidaNeumaticos2
		    DatoDescrMinima medidaNeumaticos2 = new DatoDescrMinima();
		    medidaNeumaticos2.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setMedidaNeumaticos2(medidaNeumaticos2);
		    //DistanciaEntreEjes
		    DatoDescrMinima distanciaEntreEjes = new DatoDescrMinima();
		    distanciaEntreEjes.setValtipdescri("99"); //NO HAY CATALOGO
		    vehiculo.setDistanciaEntreEjes(distanciaEntreEjes);
		    //MarcaCarroceria
		    DatoDescrMinima marcaCarroceria = new DatoDescrMinima();
		    marcaCarroceria.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setMarcaCarroceria(marcaCarroceria);
		    //NumeroPuertas
		    DatoDescrMinima numeroPuertas = new DatoDescrMinima();
		    numeroPuertas.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setNumeroPuertas(numeroPuertas);
		    //RefrigeracionMotor
		    DatoDescrMinima refrigeracionMotor = new DatoDescrMinima();
		    refrigeracionMotor.setValtipdescri("EAI"); //EAI,ELI
		    vehiculo.setRefrigeracionMotor(refrigeracionMotor);
		    //TipoFrenoDelantero
		    DatoDescrMinima tipoFrenoDelantero = new DatoDescrMinima();
		    tipoFrenoDelantero.setValtipdescri("TAM"); //TAM,DIS
		    vehiculo.setTipoFrenoDelantero(tipoFrenoDelantero);
		    //TipoFrenoPosterior
		    DatoDescrMinima tipoFrenoPosterior = new DatoDescrMinima();
		    tipoFrenoPosterior.setValtipdescri("DIS"); //TAM,DIS
		    vehiculo.setTipoFrenoPosterior(tipoFrenoPosterior);
		    //NumeroRuedas
		    DatoDescrMinima numeroRuedas = new DatoDescrMinima();
		    numeroRuedas.setValtipdescri("3"); //NO HAY CATALOGO
		    vehiculo.setNumeroRuedas(numeroRuedas);
		    //ModeloDelFabricante
		    DatoDescrMinima modeloDelFabricante = new DatoDescrMinima();
		    modeloDelFabricante.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setModeloDelFabricante(modeloDelFabricante);
		    //FobPaisExportacion
		    DatoDescrMinima fobPaisExportacion = new DatoDescrMinima();
		    fobPaisExportacion.setValtipdescri(""); // NO HAY CATALOGO
		    vehiculo.setFobPaisExportacion(fobPaisExportacion);
		    //GastosReparacion
		    DatoDescrMinima gastosReparacion = new DatoDescrMinima();
		    gastosReparacion.setValtipdescri(""); // NO HAY CATALOGO
		    vehiculo.setGastosReparacion(gastosReparacion);
		    //Extension
		    DatoDescrMinima extension = new DatoDescrMinima();
		    extension.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setExtension(extension);
		    //AnnoModelo
		    DatoDescrMinima annoModelo = new DatoDescrMinima();
		    annoModelo.setValtipdescri("2013"); //NO HAY CATALOGO
		    vehiculo.setAnnoModelo(annoModelo);
		    //SuspensionDelantero
		    DatoDescrMinima suspencionDelantera = new DatoDescrMinima();
		    suspencionDelantera.setValtipdescri("123456789ABCDEFGHIJKLMNOPQRST"); //NO HAY CATALOGO
		    vehiculo.setSuspencionDelantera(suspencionDelantera);
		    //SuspensionPosterior
		    DatoDescrMinima suspencionPorterior = new DatoDescrMinima();
		    suspencionPorterior.setValtipdescri("ABCDEFGHIJKLMNOPQRST123456789"); //NO HAY CATALOGO
		    vehiculo.setSuspencionPorterior(suspencionPorterior);
		    //NombreFabricante
		    DatoDescrMinima nombreFabricante = new DatoDescrMinima();
		    nombreFabricante.setValtipdescri("123456789ABCDEFGHIJKLMNOPQRST"); //NO HAY CATALOGO
		    vehiculo.setNombreFabricante(nombreFabricante);
		    //NumeroCarroceria
		    DatoDescrMinima numeroSerieCarroceria = new DatoDescrMinima();
		    numeroSerieCarroceria.setValtipdescri("ABCDEFGHIJKLMNOPQ34567"); //NO HAY CATALOGO
		    vehiculo.setNumeroSerieCarroceria(numeroSerieCarroceria);
		    //Revisa1
		    DatoDescrMinima numeroRevisa1 = new DatoDescrMinima();
		    numeroRevisa1.setValtipdescri("10730186424"); //NO HAY CATALOGO
		    vehiculo.setNumeroRevisa1(numeroRevisa1);
		    //NumeroVIN
		    DatoDescrMinima numeroVIN = new DatoDescrMinima();
		    numeroVIN.setValtipdescri(""); //NO HAY CATALOGO
		    vehiculo.setNumeroVIN(numeroVIN);
		    //codigoExoneracionVIN
		    DatoDescrMinima codigoExoneracionVIN = new DatoDescrMinima();
		    codigoExoneracionVIN.setValtipdescri("01"); //01,02,03,04..
		    vehiculo.setCodigoExoneracionVIN(codigoExoneracionVIN);
		    //ListaAccesorios
		    DatoDescrMinima accesorio = new DatoDescrMinima();
		    List<DatoDescrMinima> listtAccesorios = new ArrayList<DatoDescrMinima>();
		    accesorio.setValtipdescri("AAL"); //001,AAL,ABS,ACD,ALI,ALM,AMP,ANT,ASE,ATB,BLP,BRE,BSA,CAL,CET,CLM,CPV,CTC,CUE,DCC,DCD,DHA,DVD,ECR,EEL...
		    listtAccesorios.add(accesorio);
		    accesorio.setValtipdescri("ALM");
		    listtAccesorios.add(accesorio);
		    vehiculo.setListaAccesorios(listtAccesorios);
		    //Kilometraje
		    DatoDescrMinima kilometraje = new DatoDescrMinima();
		    kilometraje.setValtipdescri("1234567,12"); //NO HAY CATALOGO
		    kilometraje.setCtipo("1");
		    kilometraje.setCodtipdescr("VE0030");
		    vehiculo.setKilometraje(kilometraje);
		    vehiculo.setNumsecitem(3);
		    this.declaracion = declaracion;
		    this.vehiculo = vehiculo;		    
  }

// @Test
 public void testExcepcionReqMinimosCalidad() throws Exception
 {
	System.out.println("Ingreso al Test -testExcepcionReqMinimosCalidad-");
	DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
	item.setNumpartnandi(new Long("8703900090"));
	String indicadorSNTT="1";
	
	 List<Map<String, Object>>lstDatoSerie= new ArrayList<Map<String, Object>>();
	    Map<String, Object> mapDatoSerie = new HashMap<String, Object>();
	    mapDatoSerie.put("numSerie", 1);
		mapDatoSerie.put("codLiberatorio", "2002");
	    mapDatoSerie.put("docTranspId", 1);
		mapDatoSerie.put("fechaEmbarque", sdf.parse("2013-05-11"));
	    mapDatoSerie.put("docSoporteId",22);
		mapDatoSerie.put("numSecProve",33256);
		mapDatoSerie.put("numSecFactura",2);
		mapDatoSerie.put("numSecItem",1);		
		lstDatoSerie.add(mapDatoSerie);
	Assert.assertEquals(validadorVehic.esExceptuadoReqMinimosCalidad(item, declaracion, indicadorSNTT, lstDatoSerie),true);
 }

//@Test 
 public void testValidarVehiculoSiniestrado() throws Exception 
 {
    System.out.println("Ingreso al Test -testValidarVehiculoSiniestrado");
	DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
	item.setNumpartnandi(new Long("8803210010")); 	
	item.setCodestamer("25"); //siniestrada
		
	Date fecembarque01 = sdf.parse("2014-05-01"); 
	    Elementos<DatoDocTransporte> ListDocumentos = new Elementos<DatoDocTransporte>();
	    DatoDocTransporte documento1 = new DatoDocTransporte();
	    documento1.setFecembarque(fecembarque01);
	    documento1.setNumserie(1);
	    documento1.setNumsecdoctrans(223);	
	    ListDocumentos.add(documento1);
	    DUA dua = new DUA();
	    dua.setListDocTransporte(ListDocumentos);
	    	    	    
	    DatoSerie datoserie = new DatoSerie();
	    Elementos<DatoSerie> listDatoSerie = new Elementos<DatoSerie>();
	    datoserie.setNumserie(1);
	    datoserie.setCodliberatorio(3000);
	    listDatoSerie.add(datoserie);
	    dua.setListSeries(listDatoSerie);
		   
	    DatoOtroDocSoporte datoSoporte = new DatoOtroDocSoporte();
	    Elementos<DatoOtroDocSoporte> listDatoSoporte = new Elementos<DatoOtroDocSoporte>();
	    //datoSoporte.setNumserie(1);
	    datoSoporte.setCodtipoproceso("P");
	    datoSoporte.setCodtipodocasoc("02");
	    datoSoporte.setAnndocasoc("2013");
	    datoSoporte.setNumdocasoc("01");
	    datoSoporte.setNumsecdocum(22);
	    datoSoporte.setFecdocasoc(sdf.parse("2013-05-11"));
	    listDatoSoporte.add(datoSoporte);
	    DatoOtroDocSoporte datoSoporte1 = new DatoOtroDocSoporte();
	    datoSoporte1.setCodtipodocasoc("3");
	    datoSoporte1.setNumdocasoc("223");  
	    listDatoSoporte.add(datoSoporte1);
	    DatoOtroDocSoporte datoSoporte2 = new DatoOtroDocSoporte();
	    datoSoporte2.setCodtipodocasoc("4");
	    datoSoporte2.setNumdocasoc("02");  
	    listDatoSoporte.add(datoSoporte1);
	    dua.setListOtrosDocSoporte(listDatoSoporte);
	    dua.setCodregimen("10");
	    declaracion.setDua(dua);	    
	    
	    List<Map<String, Object>>lstDatoSerie= new ArrayList<Map<String, Object>>();
	    Map<String, Object> mapDatoSerie = new HashMap<String, Object>();
	    mapDatoSerie.put("numSerie", 1);
		mapDatoSerie.put("codLiberatorio", "312");
	    mapDatoSerie.put("docTranspId", 1);
	    mapDatoSerie.put("docSoporteId",22);
		mapDatoSerie.put("fechaEmbarque", sdf.parse("2013-05-11"));
		mapDatoSerie.put("numSecProve",33256);
		mapDatoSerie.put("numSecFactura",2);
		mapDatoSerie.put("numSecItem",1);			
		lstDatoSerie.add(mapDatoSerie);
	Assert.assertEquals(validadorVehic.validarVehiculoSiniestrado(item, declaracion, lstDatoSerie).size(),1);// error 31813
 }
 
//@Test
 public void testValidarKmVehiculoTipo1MenorKm() throws Exception
 {
	 System.out.println("Ingreso al Test -testValidarKmVehiculoTipo1MenorKm-");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
		
	 //GRUPO CATEG.VEHIC.TIPO ENCENDIDO:COM/CHI,SNTT<>1, SPN TIPO USO:VA1/VAL Y FECLLEGADA>2007/02/24 (KM<)
	 	item.setNumpartnandi(new Long("8701200000"));   //Tipo Uso VA1
	 
		    Map<String, Object> mapDatosVehiculo = new HashMap<String, Object>();

			mapDatosVehiculo.put("tipoEncendido","CHI");
			mapDatosVehiculo.put("categoria","L3");
			mapDatosVehiculo.put("indicadorSNTT","0");
			mapDatosVehiculo.put("kilometraje","80000");
			mapDatosVehiculo.put("numSecItem",1);
			mapDatosVehiculo.put("numSecFactura",2);
			mapDatosVehiculo.put("numSecProve",33256);
			
		    Assert.assertEquals(validadorVehic.validarKmVehiculo(item, declaracion,mapDatosVehiculo, 1).size(),1);	//error 31816
 }
 
// @Test
 public void testValidarKmVehiculoTipo1MayorKm() throws Exception
 {
	 System.out.println("Ingreso al Test -testValidarKmVehiculoTipo1MayorKm-");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
		
	 //GRUPO CATEG.VEHIC.TIPO ENCENDIDO:COM/CHI,SNTT<>1, SPN TIPO USO:VA1/VAL Y FECLLEGADA>2007/02/24 (KM>)
	 item.setNumpartnandi(new Long("8701200000"));   //Tipo Uso VA1	 
		
		    Map<String, Object> mapDatosVehiculo = new HashMap<String, Object>();

			mapDatosVehiculo.put("tipoEncendido","CHI");
			mapDatosVehiculo.put("categoria","M1SD");
			mapDatosVehiculo.put("indicadorSNTT","0");
			mapDatosVehiculo.put("kilometraje","90000");	
			mapDatosVehiculo.put("numSecItem",1);
			mapDatosVehiculo.put("numSecFactura",2);
			mapDatosVehiculo.put("numSecProve",33256);		
		
		    Assert.assertEquals(validadorVehic.validarKmVehiculo(item, declaracion,mapDatosVehiculo, 1).size(),1);	//error 31816
 }
 
// @Test
 public void testValidarKmVehiculoTipo1Chispa() throws Exception
 {
	 System.out.println("Ingreso al Test -testValidarKmVehiculoTipo2-");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
	 
	 //GRUPO CATEG.VEHIC.TIPO ENCENDIDO:CHI, SNTT<>1, SPN DE TIPO USO:VA1/VAL Y FECLLEGADA>2007/02/24	 
	 item.setNumpartnandi(new Long("8701200000"));   //Tipo Uso VA1
	    Map<String, Object> mapDatosVehiculo = new HashMap<String, Object>();

		mapDatosVehiculo.put("tipoEncendido","CHI");
		mapDatosVehiculo.put("categoria","M2SE");
		mapDatosVehiculo.put("indicadorSNTT","0");
		mapDatosVehiculo.put("kilometraje","100000");
		mapDatosVehiculo.put("numSecItem",1);
		mapDatosVehiculo.put("numSecFactura",2);
		mapDatosVehiculo.put("numSecProve",33256);

	 Assert.assertEquals(validadorVehic.validarKmVehiculo(item, declaracion, mapDatosVehiculo, 1).size(),1); //error 31816
}
 
//@Test
public void testValidarKmVehiculoTipo1Compresion() throws Exception
{
	 System.out.println("Ingreso al Test -testValidarKmVehiculoTipo3-");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
	 
	 //GRUPO CATEG.VEHIC.TIPO ENCENDIDO:COM, SNTT<>1, SPN DE TIPO USO:VA1/VAL Y FECLLEGADA>2007/02/24 
	 item.setNumpartnandi(new Long("8701200000"));   //Tipo Uso VA1
	 
	    Map<String, Object> mapDatosVehiculo = new HashMap<String, Object>();

		mapDatosVehiculo.put("tipoEncendido","COM");
		mapDatosVehiculo.put("categoria","N2SA");
		mapDatosVehiculo.put("indicadorSNTT","0");
		mapDatosVehiculo.put("kilometraje","300000");
		mapDatosVehiculo.put("numSecItem",1);
		mapDatosVehiculo.put("numSecFactura",2);
		mapDatosVehiculo.put("numSecProve",33256);

	 Assert.assertEquals(validadorVehic.validarKmVehiculo(item, declaracion, mapDatosVehiculo, 1).size(),1); //error 31816
}

//@Test
public void testValidarKmVehiculoTipo2() throws Exception
{
	 System.out.println("Ingreso al Test -testValidarKmVehiculoTipo4-");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
	 
	 //GRUPO CATEG.VEHIC.TIPO ENCENDIDO:COM, SNTT<>1, SPN DE TIPO USO:VA1/VAL Y FECLLEGADA>2007/02/24 
	 item.setNumpartnandi(new Long("8701200000"));   //Tipo Uso VA1
	 
	    Map<String, Object> mapDatosVehiculo = new HashMap<String, Object>();

		mapDatosVehiculo.put("tipoEncendido","ZZZ");
		mapDatosVehiculo.put("categoria","N2SA");
		mapDatosVehiculo.put("indicadorSNTT","0");
		mapDatosVehiculo.put("kilometraje","0");
		mapDatosVehiculo.put("numSecItem",1);
		mapDatosVehiculo.put("numSecFactura",2);
		mapDatosVehiculo.put("numSecProve",33256);
		
	 Assert.assertEquals(validadorVehic.validarKmVehiculo(item, declaracion,mapDatosVehiculo, 2).size(),1); //error 31817
}
 
 
//@Test
 public void testValidarProhibicionImpoConsumo() throws Exception
{
	 System.out.println("Ingreso al Test -testValidarProhibicionImpoConsumo-");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
	 //Partida con tipo_uso PRO y ref CC en cat_refpartidas
	item.setNumpartnandi(new Long("8703900090"));   //Tipo Uso PRO
		  Date fecembarque01 = sdf.parse("2010-05-01"); 
		    Elementos<DatoDocTransporte> ListDocumentos = new Elementos<DatoDocTransporte>();
		    DatoDocTransporte documento1 = new DatoDocTransporte();
		    documento1.setFecembarque(fecembarque01);
		    documento1.setNumserie(1);
		    documento1.setNumsecdoctrans(223);	
		    ListDocumentos.add(documento1);
		    DUA dua = new DUA();
		    dua.setListDocTransporte(ListDocumentos);
		    	    	    
		    DatoSerie datoserie = new DatoSerie();
		    Elementos<DatoSerie> listDatoSerie = new Elementos<DatoSerie>();
		    datoserie.setNumserie(1);
		    datoserie.setCodliberatorio(3000);
		    listDatoSerie.add(datoserie);
		    dua.setListSeries(listDatoSerie);

		    DatoOtroDocSoporte datoSoporte = new DatoOtroDocSoporte();
		    Elementos<DatoOtroDocSoporte> listDatoSoporte = new Elementos<DatoOtroDocSoporte>();
		    datoSoporte.setNumserie(1);
		    datoSoporte.setCodtipoproceso("P");
		    datoSoporte.setCodtipodocasoc("02");
		    datoSoporte.setAnndocasoc("2013");
		    datoSoporte.setNumdocasoc("01");
		    datoSoporte.setFecdocasoc(new Date(20130511));
		    listDatoSoporte.add(datoSoporte);
		    dua.setListOtrosDocSoporte(listDatoSoporte);
		    dua.setCodregimen("10");  
		    Date fecNumeracion = sdf.parse("2009-05-01"); 
		    dua.setFecNumeracion(fecNumeracion);
		    declaracion.setDua(dua);
		    
	  List<Map<String, Object>>lstDatoSerie= new ArrayList<Map<String, Object>>();
	    Map<String, Object> mapDatoSerie = new HashMap<String, Object>();
	    mapDatoSerie.put("numSerie", 1);
	    mapDatoSerie.put("docTranspId", 1);
		mapDatoSerie.put("fechaEmbarque", sdf.parse("2013-05-11"));
	    mapDatoSerie.put("docSoporteId",22);
		mapDatoSerie.put("numSecProve",33256);
		mapDatoSerie.put("numSecFactura",2);
		mapDatoSerie.put("numSecItem",1);			
		lstDatoSerie.add(mapDatoSerie);

	    Map<String, Object> mapDatosVehiculo = new HashMap<String, Object>();
		mapDatosVehiculo.put("tipoEncendido","COM");
		mapDatosVehiculo.put("categoria","N2SA");
		
	 Assert.assertEquals(validadorVehic.validarProhibicionImpoConsumo(item, declaracion, mapDatosVehiculo, lstDatoSerie).size(),0);
}
 
//@Test
 public void testValidarCodigoLib() throws Exception
 {
	//para codigo liberatorio 3302
	 System.out.println("Ingreso al Test -testvalidarRestriccionFuncExtranjerosCodigoLib-");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
	 item.setNumpartnandi(new Long("8703900522"));
	 
	  Date fecembarque01 = sdf.parse("2019-05-01"); 
	    Elementos<DatoDocTransporte> ListDocumentos = new Elementos<DatoDocTransporte>();
	    DatoDocTransporte documento1 = new DatoDocTransporte();
	    documento1.setFecembarque(fecembarque01);
	    documento1.setNumserie(1);
	    documento1.setNumsecdoctrans(223);	
	    ListDocumentos.add(documento1);
	    DUA dua = new DUA();
	    dua.setListDocTransporte(ListDocumentos);
	    	    	    
	    DatoOtroDocSoporte datoSoporte = new DatoOtroDocSoporte();
	    Elementos<DatoOtroDocSoporte> listDatoSoporte = new Elementos<DatoOtroDocSoporte>();
	    datoSoporte.setNumserie(1);
	    datoSoporte.setCodtipoproceso("P");
	    datoSoporte.setCodtipodocasoc("02");
	    datoSoporte.setAnndocasoc("2013");
	    datoSoporte.setNumdocasoc("01");
	    //datoSoporte.setNumsecdocum(22);
	    datoSoporte.setFecdocasoc(sdf.parse("2013-05-11"));
	    listDatoSoporte.add(datoSoporte);
	    dua.setListOtrosDocSoporte(listDatoSoporte);
	    dua.setCodregimen("10"); 
	    declaracion.setDua(dua);	      
	    
		  List<Map<String, Object>>lstDatoSerie= new ArrayList<Map<String, Object>>();
		    Map<String, Object> mapDatoSerie = new HashMap<String, Object>();
		    mapDatoSerie.put("numSerie", 1);
			mapDatoSerie.put("codLiberatorio", 3302);
		    mapDatoSerie.put("docTranspId", 1);
			mapDatoSerie.put("fechaEmbarque", sdf.parse("2013-05-11"));
		  //  mapDatoSerie.put("docSoporteId",22);
			mapDatoSerie.put("numSecProve",33256);
			mapDatoSerie.put("numSecFactura",2);
			mapDatoSerie.put("numSecItem",1);			
			lstDatoSerie.add(mapDatoSerie);
	 Assert.assertEquals(validadorVehic.validarRestriccionFuncExtranjeros(item, declaracion,lstDatoSerie).size(),2); //se espera error 31826 y 31827
 }
 
 
 //@Test
 public void testValidarRestriccionFuncExtranjerosAntiguedadMayor() throws Exception
 {
	 System.out.println("Ingreso al Test -testValidarRestriccionFuncExtranjerosAntiguedadMayor-");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);		
	 item.setNumpartnandi(new Long("8703900522"));	 
	  Date fecembarque01 = sdf.parse("2014-05-28"); 
	    Elementos<DatoDocTransporte> ListDocumentos = new Elementos<DatoDocTransporte>();
	    DatoDocTransporte documento1 = new DatoDocTransporte();
	    documento1.setFecembarque(fecembarque01);
	    documento1.setNumserie(1);
	    documento1.setNumsecdoctrans(223);	
	    ListDocumentos.add(documento1);
	    DUA dua = new DUA();
	    dua.setListDocTransporte(ListDocumentos);
	    	    	    
	    DatoOtroDocSoporte datoSoporte = new DatoOtroDocSoporte();
	    Elementos<DatoOtroDocSoporte> listDatoSoporte = new Elementos<DatoOtroDocSoporte>();
	    datoSoporte.setNumserie(1);
	    datoSoporte.setCodtipoproceso("P");
	    datoSoporte.setCodtipodocasoc("02");
	    datoSoporte.setAnndocasoc("2013");
	    datoSoporte.setNumdocasoc("01");
	    datoSoporte.setNumsecdocum(22);
	    datoSoporte.setFecdocasoc(sdf.parse("2013-05-11"));
	    listDatoSoporte.add(datoSoporte);
	    dua.setListOtrosDocSoporte(listDatoSoporte);
	    dua.setCodregimen("10"); 
	    declaracion.setDua(dua);
	     
		  List<Map<String, Object>>lstDatoSerie= new ArrayList<Map<String, Object>>();
		    Map<String, Object> mapDatoSerie = new HashMap<String, Object>();
		    mapDatoSerie.put("numSerie", 1);
			mapDatoSerie.put("codLiberatorio", 3302);
		    mapDatoSerie.put("docTranspId", 1);
			mapDatoSerie.put("fechaEmbarque", sdf.parse("2013-05-11"));
		    mapDatoSerie.put("docSoporteId",22);
			mapDatoSerie.put("numSecProve",33256);
			mapDatoSerie.put("numSecFactura",2);
			mapDatoSerie.put("numSecItem",1);		
			lstDatoSerie.add(mapDatoSerie);
	 Assert.assertEquals(validadorVehic.validarRestriccionFuncExtranjeros(item, declaracion, lstDatoSerie).size(),1); //se espera error 31815 (>5años)
 }
 
 //@Test
 public void testValidarRestriccionFuncExtranjerosAntiguedadMenor() throws Exception
 {
	 System.out.println("Ingreso al Test -testValidarRestriccionFuncExtranjerosAntiguedadMenor");
	 DatoItem item = declaracion.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);	
	
	 item.setNumpartnandi(new Long("8703319020"));
	  Date fecembarque01 = sdf.parse("2011-05-28"); 
	    Elementos<DatoDocTransporte> ListDocumentos = new Elementos<DatoDocTransporte>();
	    DatoDocTransporte documento1 = new DatoDocTransporte();
	    documento1.setFecembarque(fecembarque01);
	    documento1.setNumserie(1);
	    documento1.setNumsecdoctrans(223);	
	    ListDocumentos.add(documento1);
	    DUA dua = new DUA();
	    dua.setListDocTransporte(ListDocumentos);
	    	    	    
	 /*   DatoSerie datoserie = new DatoSerie();
	    Elementos<DatoSerie> listDatoSerie = new Elementos<DatoSerie>();
	    datoserie.setNumserie(1);
	    datoserie.setCodliberatorio(3302);
	    listDatoSerie.add(datoserie);
	    dua.setListSeries(listDatoSerie);*/
	    
	    DatoOtroDocSoporte datoSoporte = new DatoOtroDocSoporte();
	    Elementos<DatoOtroDocSoporte> listDatoSoporte = new Elementos<DatoOtroDocSoporte>();
	    datoSoporte.setNumserie(1);
	    datoSoporte.setCodtipoproceso("P");
	    datoSoporte.setCodtipodocasoc("02");
	    datoSoporte.setAnndocasoc("2013");
	    datoSoporte.setNumdocasoc("01");
	    datoSoporte.setNumsecdocum(22);
	    datoSoporte.setFecdocasoc(sdf.parse("2013-05-11"));
	    listDatoSoporte.add(datoSoporte);
	    dua.setListOtrosDocSoporte(listDatoSoporte);
	    dua.setCodregimen("10"); 
	    declaracion.setDua(dua);
	    	  	    
		  List<Map<String, Object>>lstDatoSerie= new ArrayList<Map<String, Object>>();
		    Map<String, Object> mapDatoSerie = new HashMap<String, Object>();
		    mapDatoSerie.put("numSerie", 1);
			mapDatoSerie.put("codLiberatorio", 3302);
		    mapDatoSerie.put("docTranspId", 1);
			mapDatoSerie.put("fechaEmbarque", sdf.parse("2013-05-11"));
		    mapDatoSerie.put("docSoporteId",22);
			mapDatoSerie.put("numSecProve",33256);
			mapDatoSerie.put("numSecFactura",2);
			mapDatoSerie.put("numSecItem",1);	
			lstDatoSerie.add(mapDatoSerie);
	Assert.assertEquals(validadorVehic.validarRestriccionFuncExtranjeros(item, declaracion,lstDatoSerie).size(),2); //se espera error 31814 (>2años) y 31826
 } 
 
 
}
