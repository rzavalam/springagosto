package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ceramicos;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ceramicos.model.Ceramico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorCeramicoTestIntegration extends AbstractServiceTest{
	@Autowired
	@Qualifier("ValidadorCeramico")
	private ValidadorCeramico validador;
	  
	@Autowired
	@Qualifier("framework.fabricaDeServicios")
	private FabricaDeServicios fabricaDeServicios;
	private static Mensaje		mensaje1001;
	private static Declaracion	declaracion1001;
		
	@Autowired
	@Qualifier("Ayuda.ayudaServiceCache")
	private AyudaServiceCache	ayudaServiceCache;
		
	private Ceramico          ceramicos;
	private Declaracion		declaracion;
		
	@BeforeClass
	public void initData() throws Exception{
	System.out.println("CARGANDO TEST INTEGRADO (CON XML) ...");
			  
	assertNotNull(fabricaDeServicios, "No se cargo la fabrica de servicios desde el contexto");

	String filename = "src/test/java/xmlCeramicos/XML_CERAMICOS_CP01.xml";
	//String filename = "src/test/java/xmlVehiculos/XML_CERAMICOS_CP02.xml";
	//String filename = "src/test/java/xmlVehiculos/XML_CERAMICOS_CP03.xml";
	String numeroTransaccion = "1001";

	ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");
	Map<String, Object> parametros = null;
	parametros = new HashMap<String, Object>();
	parametros.put("numeroTransaccion", numeroTransaccion);
	List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);
	//Verificar la Existencia de Reglas
	assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
	XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
	xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);
	mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);
	//Verificar que Convirtio el XML a Mensaje
	assertNotNull(mensaje1001);
	declaracion1001 = (Declaracion) mensaje1001.getDocumento();
	//---------CERAMICOS------------//			  
    Integer item_numseitem = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getNumsecitem();
    Ceramico ceramico = new Ceramico();
    String codigo, valor;
    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima>  listaDescripcionMinimas = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getListDecrMinima();
    for(pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima descripcion : listaDescripcionMinimas){
        codigo =  descripcion.getCodtipdescr().trim();
        valor = descripcion.getValtipdescri().trim();
        Integer codigo_int = Integer.parseInt(codigo.substring(4,6));
        System.out.println("Descripcion minima  --> " + codigo + " -> " + valor);
        switch (codigo_int) {
        case 0:   DatoDescrMinima nombrecomercial = new DatoDescrMinima();
        		  nombrecomercial.setValtipdescri(valor);
        		  nombrecomercial.setNumsecitem(item_numseitem);
        		  ceramico.setNombreComercial(nombrecomercial);
        		  ceramico.setNumsecitem(item_numseitem);
        		  break;
        case 1:   DatoDescrMinima marcaComercial = new DatoDescrMinima();marcaComercial.setValtipdescri(valor);ceramico.setMarcaComercial(marcaComercial);break;
        case 2:   DatoDescrMinima modelo = new DatoDescrMinima();modelo.setValtipdescri(valor);ceramico.setModelo(modelo);break;
        case 3:   DatoDescrMinima acabados = new DatoDescrMinima();acabados.setValtipdescri(valor);ceramico.setAcabados(acabados);break;
        case 4:   DatoDescrMinima materiaPrima1 = new DatoDescrMinima();materiaPrima1.setValtipdescri(valor);ceramico.setMateriaPrima1(materiaPrima1);break;
        case 5:   DatoDescrMinima materiaPrima2 = new DatoDescrMinima();materiaPrima2.setValtipdescri(valor);ceramico.setMateriaPrima2(materiaPrima2);break;
        case 6:   DatoDescrMinima materiaPrima3 = new DatoDescrMinima();materiaPrima3.setValtipdescri(valor);ceramico.setMateriaPrima3(materiaPrima3);break;
        case 7:   DatoDescrMinima materiaPrima4 = new DatoDescrMinima();materiaPrima4.setValtipdescri(valor);ceramico.setMateriaPrima4(materiaPrima4);break;
        case 8:   DatoDescrMinima materiaPrima5 = new DatoDescrMinima();materiaPrima5.setValtipdescri(valor);ceramico.setMateriaPrima5(materiaPrima5);break;
        case 9:   DatoDescrMinima moldeo = new DatoDescrMinima();moldeo.setValtipdescri(valor);ceramico.setMoldeo(moldeo);break;
        case 10:  DatoDescrMinima coccion = new DatoDescrMinima();coccion.setValtipdescri(valor);ceramico.setCoccion(coccion);break;
        case 11:  DatoDescrMinima uso = new DatoDescrMinima();uso.setValtipdescri(valor);ceramico.setUso(uso);break;
        case 12:  DatoDescrMinima color = new DatoDescrMinima();color.setValtipdescri(valor);ceramico.setColor(color);break;
        case 13:  DatoDescrMinima gradoDimensionYEspesor = new DatoDescrMinima();gradoDimensionYEspesor.setValtipdescri(valor);ceramico.setGradoDimensionYEspesor(gradoDimensionYEspesor);break;
        case 14:  DatoDescrMinima capacidadAbsorcionAgua = new DatoDescrMinima();capacidadAbsorcionAgua.setValtipdescri(valor);ceramico.setCapacidadAbsorcionAgua(capacidadAbsorcionAgua);break;
        default:  break;
        }    	
      }
      this.declaracion = declaracion1001;
      this.ceramicos = ceramico;	
   }

	  @Test
	  public void testValidarUnidadComercial(){
		  System.out.println("Ingreso al Test -testValidarUnidadComercial-");
		  Assert.assertEquals(validador.validarUnidadComercialCeramicos(ceramicos,declaracion).size(),1);
	  }

	  @Test
	  public void testValidarNombreProductoCeramico(){
		  System.out.println("Ingreso al Test -testValidarNombreProductoCeramico-");
		  Assert.assertEquals(validador.validarNombreProductoCeramico(ceramicos, declaracion).size(),1);
	  }

	  @Test
	  public void testValidarMarcaComercialCeramicos(){
		  System.out.println("Ingreso al Test -testValidarMarcaComercialCeramicos-");
		  Assert.assertEquals(validador.validarMarcaComercialCeramicos(ceramicos).size(),0);
	  }

	  @Test
	  public void testValidarModeloComercialCeramicos(){
		  System.out.println("Ingreso al Test -testValidarModeloComercialCeramicos-");
		  Assert.assertEquals(validador.validarModeloComercialCeramicos(ceramicos).size(),0);
	  }

	  @Test
	  public void testValidarAcabadoProductoCeramico(){
		  System.out.println("Ingreso al Test -testValidarAcabadoProductoCeramico-");
		  String acabados = ceramicos.getAcabados().getValtipdescri();
		  Assert.assertEquals(validador.noEstaEnCatalogo(acabados,"449"),false);
	  }

	  @Test
	  public void testValidarMateriaPrimaCeramicos(){
		  System.out.println("Ingreso al Test -testValidarMateriaPrimaCeramicos-");
		  Assert.assertEquals(validador.validarMateriaPrimaCeramicos(ceramicos).size(),0);
	  }

	  @Test
	  public void testValidarMoldeoCeramico(){
		  System.out.println("Ingreso al Test -testValidarMoldeoCeramico-");
		  String moldeo = ceramicos.getMoldeo().getValtipdescri();
		  Assert.assertEquals(validador.noEstaEnCatalogo(moldeo,"451"),false);
	  }

	  @Test
	  public void testValidarCoccionCeramico(){
		  System.out.println("Ingreso al Test -testValidarCoccionCeramico-");
		  String coccion = ceramicos.getCoccion().getValtipdescri();
		  Assert.assertEquals(validador.noEstaEnCatalogo(coccion,"452"),false);
	  }

	  @Test
	  public void testValidarUsoCeramico(){
		  System.out.println("Ingreso al Test -testValidarUsoCeramico-");
		  String uso = ceramicos.getUso().getValtipdescri();
		  Assert.assertEquals(validador.noEstaEnCatalogo(uso,"453"),false);
	  }

	  @Test
	  public void testValidarColorCeramico(){
		  System.out.println("Ingreso al Test -testValidarColorCeramico-");
		  String color = ceramicos.getColor().getValtipdescri();
		  Assert.assertEquals(validador.noEstaEnCatalogo(color,"454"),false);
	  }

	  @Test
	  public void testValidarDimensionesCeramicos(){
		  System.out.println("Ingreso al Test -testValidarDimensionesCeramicos-");
		  Assert.assertEquals(validador.validarDimensionesCeramicos(ceramicos).size(),0);
	  }

	  @Test
	  public void testValidarCapacidadAbsorcionCeramico(){
		  System.out.println("Ingreso al Test -testValidarCapacidadAbsorcionCeramico-");
		  String capAbsorcion = ceramicos.getCapacidadAbsorcionAgua().getValtipdescri();
		  Assert.assertEquals(validador.noEstaEnCatalogo(capAbsorcion,"455"),false);
	  }	
}