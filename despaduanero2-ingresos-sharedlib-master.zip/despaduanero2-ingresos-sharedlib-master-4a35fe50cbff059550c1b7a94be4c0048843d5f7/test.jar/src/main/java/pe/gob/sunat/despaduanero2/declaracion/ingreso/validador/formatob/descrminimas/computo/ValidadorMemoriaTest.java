package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoMemoria;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorMemoriaTest extends AbstractServiceTest{
  @Autowired
  @Qualifier("ValidadorComputoMemoria")
  private ValidadorComputoMemoria validador = new ValidadorComputoMemoria();

  private final static String TEXTO = "1";
  private final static String CATALOGO = "0";
	  
  @DataProvider(name="initData128")
  private Object[][] initData128(){
	ComputoMemoria memoria = new ComputoMemoria();
	Declaracion dua = new Declaracion();
	DatoDescrMinima nombreComercial = new DatoDescrMinima();
	DatoDescrMinima marcaComercial = new DatoDescrMinima();
	DatoDescrMinima modelo = new DatoDescrMinima();
	DatoDescrMinima tipoMemoria = new DatoDescrMinima();
	DatoDescrMinima tipoMemoriaRAM = new DatoDescrMinima();
	DatoDescrMinima velocidadBus = new DatoDescrMinima();
	DatoDescrMinima capacidadMemoria = new DatoDescrMinima();
	DatoDescrMinima moduloMemoria = new DatoDescrMinima();
	DatoItem item = new DatoItem();
	memoria.setNumsecitem(1);
	    
	DUA dam = new DUA();
	dam.setNumcorredoc(new Long(1));
	Elementos<DAV> listDAVs = new Elementos<DAV>();

	DAV dav = new DAV();
	dav.setNumcorredoc(new Long(1));
	dav.setNumcodsecprove(new Long(1));

	Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	DatoFactura factu = new DatoFactura();
	factu.setNumcorredoc(new Long(1));
	factu.setNumfactura("1");
	factu.setNumsecfactu(1);
	factu.setNumsecprove(1);

	Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	item.setNumcorredoc(new Long(1));
	item.setNumfact("1");
	item.setNumsecitem(1);
	item.setNumsecprove(1);
	item.setCodunidcomer("U");
	item.setNumpartnandi(new Long(8473300000L));
	lstitem.add(item);

	factu.setListItems(lstitem);
	lstFactu.add(factu);
	dav.setListFacturas(lstFactu);
	listDAVs.add(dav);
	dua.setListDAVs(listDAVs);
	dua.setDua(dam);
		    
    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("CO0700");
    nombreComercial.setValtipdescri("MEM");
    
    marcaComercial.setCodtipvalor(CATALOGO);
    marcaComercial.setCodtipdescr("CO0701");
    marcaComercial.setValtipdescri("HPC");

    modelo.setCodtipvalor(TEXTO);
	modelo.setCodtipdescr("CO0702");
    modelo.setValtipdescri("2-GB PC3");
	    
    tipoMemoria.setCodtipvalor(CATALOGO);
    tipoMemoria.setCodtipdescr("CO0703");
    tipoMemoria.setValtipdescri("RAM");
	    
    tipoMemoriaRAM.setCodtipvalor(CATALOGO);
    tipoMemoriaRAM.setCodtipdescr("CO0704");
    tipoMemoriaRAM.setValtipdescri("DDS");
	    
    velocidadBus.setCodtipvalor(CATALOGO);
    velocidadBus.setCodtipdescr("CO0705");
    velocidadBus.setValtipdescri("330");
		  
    capacidadMemoria.setCodtipvalor(CATALOGO);
    capacidadMemoria.setCodtipdescr("CO0706");
    capacidadMemoria.setValtipdescri("2GB");
	    
    moduloMemoria.setCodtipvalor(CATALOGO);
    moduloMemoria.setCodtipdescr("CO0707");
    moduloMemoria.setValtipdescri("DIM");
	    
    memoria.setNombreComercial(nombreComercial);
    memoria.setMarcaComercial(marcaComercial);
    memoria.setModelo(modelo);
    memoria.setTipoMemoria(tipoMemoria);
    memoria.setTipoMemoriaRAM(tipoMemoriaRAM);
    memoria.setVelocidadBUS(velocidadBus);
    memoria.setCapacidadMemoria(capacidadMemoria);
    memoria.setModuloMemoria(moduloMemoria);
		  
    return new Object[][]{{ memoria, dua }};
  }
	
  @Test(dataProvider = "initData128")
  public void validarNombreComercial128Test(ModelAbstract object, Declaracion dua) throws Exception{
	 Assert.assertEquals(validador.ejecutarValidaciones(object, dua).size(), 0);
  }
}
