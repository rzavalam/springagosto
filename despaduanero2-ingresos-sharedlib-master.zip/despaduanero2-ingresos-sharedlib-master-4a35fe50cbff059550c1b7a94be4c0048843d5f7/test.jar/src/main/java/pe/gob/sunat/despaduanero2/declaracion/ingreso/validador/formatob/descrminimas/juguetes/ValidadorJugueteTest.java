package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.juguetes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.juguetes.model.Juguete;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorJugueteTest extends AbstractServiceTest{
	@Autowired
	  @Qualifier("ValidadorJuguete")
	  private ValidadorJuguete validador;

	  private Juguete          juguetes;
	  private Declaracion		declaracion;

	  @DataProvider(name = "initMethod")
	  public Object[][] initData(){

	    Juguete juguete = new Juguete();

	    DatoDescrMinima unidComer = new DatoDescrMinima();
	    unidComer.setValtipdescri("12U");

	    DatoDescrMinima nombJuguete = new DatoDescrMinima();
	    nombJuguete.setValtipdescri("Juguete de ruedas");
	    juguete.setNombreComercial(nombJuguete);

	    DatoDescrMinima marCom = new DatoDescrMinima();
	    marCom.setValtipdescri("Marca Comercial");
	    juguete.setMarcaComercial(marCom);

	    DatoDescrMinima modeloCom = new DatoDescrMinima();
	    modeloCom.setValtipdescri("Modelo");
	    juguete.setModelo(modeloCom);

	    DatoDescrMinima codigo = new DatoDescrMinima();
	    codigo.setValtipdescri("Codigo Mercancia");
	    juguete.setCodigoMercancia(codigo);


	    DatoDescrMinima dimension = new DatoDescrMinima();
	    dimension.setValtipdescri("Dimensiones");
	    juguete.setDimensiones(dimension);


	    DatoDescrMinima accesorios = new DatoDescrMinima();
	    accesorios.setValtipdescri("Accesorios");
	    juguete.setAccesorios(accesorios);

	    DatoDescrMinima fuenteMov = new DatoDescrMinima();
	    fuenteMov.setValtipdescri("Cuerda");
	    juguete.setFuente(fuenteMov);

	    DatoDescrMinima usuario = new DatoDescrMinima();
	    usuario.setValtipdescri("Bebe");
	    juguete.setUsuario(usuario);

	    DatoDescrMinima presentacion = new DatoDescrMinima();
	    presentacion.setValtipdescri("Blister");
	    juguete.setModoPresentacion(presentacion);

	    DUA dua = new DUA();
	    declaracion.setDua(dua);
	    return new Object[][] { { juguetes} };
	  }

	  @Test(dataProvider = "initMethod")
	  public void testValidarUnidadComercial(Juguete  juguetes)
	  {
	    Assert.assertEquals(validador.validarUnidadComercialJuguetes(juguetes,declaracion).size(),1);
	  }

	  @Test(dataProvider = "initMethod")
	  public void testValidarNombreJuguete(Juguete  juguetes)
	  {
	    String nombJugue = juguetes.getNombreComercial().getValtipdescri();
	    Assert.assertEquals(validador.noEstaEnCatalogo(nombJugue,"456"),false);
	  }

	  @Test(dataProvider = "initMethod")
	  public void testValidarMarcaComercialJuguete(Juguete  juguetes)
	  {
	    Assert.assertEquals(validador.validarMarcaComercialJuguete(juguetes).size(),1);
	  }

	  @Test(dataProvider = "initMethod")
	  public void testValidarModeloComercialJuguetes(Juguete  juguetes)
	  {
	    Assert.assertEquals(validador.validarModeloComercialJuguetes(juguetes).size(),1);
	  }


	  @Test(dataProvider = "initMethod")
	  public void testValidarDimensionesJuguetes(Juguete  juguetes)
	  {
	    Assert.assertEquals(validador.validarDimensionesJuguetes(juguetes).size(),1);
	  }


	  @Test(dataProvider = "initMethod")
	  public void testValidarAccesoriosJuguetes(Juguete  juguetes)
	  {
	    Assert.assertEquals(validador.validarAccesoriosJuguetes(juguetes).size(),1);
	  }

	  @Test(dataProvider = "initMethod")
	  public void testValidarFuenteMovimientoJuguete(Juguete  juguetes)
	  {
	    String fuenteMov = juguetes.getFuente().getValtipdescri();
	    Assert.assertEquals(validador.noEstaEnCatalogo(fuenteMov,"464"),false);
	  }

	  @Test(dataProvider = "initMethod")
	  public void testValidarUsuarioJuguete(Juguete  juguetes)
	  {
	    String usuarioJugue = juguetes.getUsuario().getValtipdescri();
	    Assert.assertEquals(validador.noEstaEnCatalogo(usuarioJugue,"465"),false);
	  }

	  @Test(dataProvider = "initMethod")
	  public void testValidarPresentacionJuguete(Juguete  juguetes)
	  {
	    String presenJugue = juguetes.getModoPresentacion().getValtipdescri();
	    Assert.assertEquals(validador.noEstaEnCatalogo(presenJugue,"466"),false);
	  }
}