package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzado;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoCueroNatural;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzados.ValidadorCalzadoCueroNatural;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorCalzadoNaturalTestIntegration extends AbstractServiceTest{
	
	  @Autowired
	  @Qualifier("ValidadorCalzadoCueroNatural")
	  private ValidadorCalzadoCueroNatural validador;

	  @Autowired
	  @Qualifier("framework.fabricaDeServicios")
	  private FabricaDeServicios fabricaDeServicios;

	  @Autowired
	  @Qualifier("Ayuda.ayudaServiceCache")
	  private AyudaServiceCache ayudaServiceCache;
	  private Declaracion dua;

	  private Map<String,List<String>> getDuaFromXML(String filename) throws Exception{
	    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	    dua = new Declaracion();
	    Mensaje mensaje1001;

	    String numeroTransaccion = "1001";

	    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

	    Map<String, Object> parametros = new HashMap<String, Object>();

	    parametros.put("numeroTransaccion", numeroTransaccion);

	    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);

	    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
	    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
	    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

	    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);

	    assertNotNull(mensaje1001);
	    dua = (Declaracion) mensaje1001.getDocumento();

	    dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();

	    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima> listaDescripcionMinimas =
	        dua.getListDAVs().get(0).getListFacturas().get(0)
	        .getListItems().get(0).getListDecrMinima();

	    for (pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima dato : listaDescripcionMinimas)
	    {
	      List<String> data = new ArrayList<String>();
	      data.add(0, dato.getCodtipvalor());
	      data.add(1,dato.getValtipdescri());
	      valores.put(dato.getCodtipdescr(), data);
	    }
	    return valores;
	  }
	  
	  
	  private Object[][] initData(Map<String,List<String>> valores ){
		  DatoDescrMinima nombreComercial = new DatoDescrMinima();	
		  DatoDescrMinima marcaComercial = new DatoDescrMinima();
		  DatoDescrMinima modelo = new DatoDescrMinima();
		  DatoDescrMinima materialParteSuperior = new DatoDescrMinima();
		  DatoDescrMinima origenCuero = new DatoDescrMinima();
		  DatoDescrMinima porcentajeOrigenCuero = new DatoDescrMinima();
		  DatoDescrMinima acabadosCuero = new DatoDescrMinima();
		  DatoDescrMinima porcentajeAcabadoCuero = new DatoDescrMinima();
		  DatoDescrMinima composicionDeSuela = new DatoDescrMinima();
		  DatoDescrMinima composicionForro = new DatoDescrMinima();
		  DatoDescrMinima usuarioCalzado= new DatoDescrMinima();
		  DatoDescrMinima tallaCalzado = new DatoDescrMinima();
		  DatoDescrMinima construccionCalzado = new DatoDescrMinima();
		  
		CalzadoCueroNatural calzado = new CalzadoCueroNatural();
	    calzado.setNumsecitem(1);
		  
	    nombreComercial.setCodtipvalor(valores.get("CA0100").get(0));
	    nombreComercial.setCodtipdescr("CA0100");
	    nombreComercial.setValtipdescri(valores.get("CA0100").get(1));
	    
	    marcaComercial.setCodtipvalor(valores.get("CA0101").get(0));
	    marcaComercial.setCodtipdescr("CA0101");
	    marcaComercial.setValtipdescri(valores.get("CA0101").get(1));
	    
	    modelo.setCodtipvalor(valores.get("CA0102").get(0));
	    modelo.setCodtipdescr("CA0102");
	    modelo.setValtipdescri(valores.get("CA0102").get(1));
	    
	    materialParteSuperior.setCodtipvalor(valores.get("CA0103").get(0));
	    materialParteSuperior.setCodtipdescr("CA0103");
	    materialParteSuperior.setValtipdescri(valores.get("CA0103").get(1));

	    origenCuero.setCodtipvalor(valores.get("CA0104").get(0));
	    origenCuero.setCodtipdescr("CA0104");
	    origenCuero.setValtipdescri(valores.get("CA0104").get(1));

	    porcentajeOrigenCuero.setCodtipvalor(valores.get("CA0105").get(0));
	    porcentajeOrigenCuero.setCodtipdescr("CA0105");
	    porcentajeOrigenCuero.setValtipdescri(valores.get("CA0105").get(1));

	    acabadosCuero.setCodtipvalor(valores.get("CA0106").get(0));
	    acabadosCuero.setCodtipdescr("CA0106");
	    acabadosCuero.setValtipdescri(valores.get("CA0106").get(1));

	    porcentajeAcabadoCuero.setCodtipvalor(valores.get("CA0107").get(0));
	    porcentajeAcabadoCuero.setCodtipdescr("CA0107");
	    porcentajeAcabadoCuero.setValtipdescri(valores.get("CA0107").get(1));

	    composicionDeSuela.setCodtipvalor(valores.get("CA0108").get(0));
	    composicionDeSuela.setCodtipdescr("CA0108");
	    composicionDeSuela.setValtipdescri(valores.get("CA0108").get(1));

	    composicionForro.setCodtipvalor(valores.get("CA0109").get(0));
	    composicionForro.setCodtipdescr("CA0109");
	    composicionForro.setValtipdescri(valores.get("CA0109").get(1));
	    
	    usuarioCalzado.setCodtipvalor(valores.get("CA0110").get(0));
	    usuarioCalzado.setCodtipdescr("CA0110");
	    usuarioCalzado.setValtipdescri(valores.get("CA0110").get(1));
	    
	    tallaCalzado.setCodtipvalor(valores.get("CA0111").get(0));
	    tallaCalzado.setCodtipdescr("CA0111");
	    tallaCalzado.setValtipdescri(valores.get("CA0111").get(1));
	    
	    construccionCalzado.setCodtipvalor(valores.get("CA0112").get(0));
	    construccionCalzado.setCodtipdescr("CA0112");
	    construccionCalzado.setValtipdescri(valores.get("CA0112").get(1));

	    calzado.setNombreComercial(nombreComercial);
	    calzado.setMarcaComercial(marcaComercial);
	    calzado.setModelo(modelo);
	    calzado.setMaterialParteSuperior(materialParteSuperior);
	    calzado.setOrigenCuero(origenCuero);
	    calzado.setPorcentajeOrigenCuero(porcentajeOrigenCuero);
	    calzado.setAcabadosCuero(acabadosCuero);
	    calzado.setPorcentajeAcabadoCuero(porcentajeAcabadoCuero);
	    calzado.setComposicionDeLaSuela(composicionDeSuela);
	    calzado.setComposicionForro(composicionForro);
	    calzado.setUsuarioCalzado(usuarioCalzado);
	    calzado.setTallaCalzado(tallaCalzado);
	    calzado.setConstruccionCalzado(construccionCalzado);
	    
		return new Object[][]{{ calzado }};
	  }
	  
	  @DataProvider ( name = "initData99")
	  private Object[][] initData99()  throws Exception{
		  Map<String,List<String>> valores = new HashMap<String,List<String>>();
		  String filename = "src/test/java/xmlCalzado/XML_CALZADO_CP00.xml";
		  valores = getDuaFromXML(filename);
		  return initData(valores);
	  }
	  
	  @Test(dataProvider = "initData99")
	  public void ejecutarValidaciones99Test(ModelAbstract object) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(object, dua).size(), 0);
	  }
	  
	  @DataProvider ( name = "initData101")
	  private Object[][] initData101()  throws Exception{
		  Map<String,List<String>> valores = new HashMap<String,List<String>>();
		  String filename = "src/test/java/xmlCalzado/XML_CALZADO_CP01.xml";
		  valores = getDuaFromXML(filename);
		  return initData(valores);
	  }
	  
	  @Test(dataProvider = "initData101")
	  public void ejecutarValidaciones101Test(ModelAbstract object) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(object, dua).size(), 1);
	  }
	  
	  @DataProvider ( name = "initData102")
	  private Object[][] initData102()  throws Exception{
		  Map<String,List<String>> valores = new HashMap<String,List<String>>();
		  String filename = "src/test/java/xmlCalzado/XML_CALZADO_CP02.xml";
		  valores = getDuaFromXML(filename);
		  return initData(valores);
	  }
	  
	  @Test(dataProvider = "initData102")
	  public void ejecutarValidaciones102Test(ModelAbstract object) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(object, dua).size(), 2);
	  }
}
