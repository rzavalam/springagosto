package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilPrenda;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

/*
 * @author lalberti
 */
public class ValidadorTextilPrendaTest extends AbstractServiceTest {
  @Autowired
  @Qualifier("ValidadorTextilPrenda")
  private ValidadorTextilPrenda validador = new ValidadorTextilPrenda();
  private static final String CATALOGO = "0";
  private static final String TEXTO    = "1";

  @DataProvider(name="initDataTest70")
  private Object[][] initDataTest70(){
    TextilPrenda prenda             = new TextilPrenda();
    Declaracion dua                 = new Declaracion();
    DUA dam                         = new DUA();
    DAV dav                         = new DAV();
    DatoItem item                   = new DatoItem();
    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    Elementos<DatoItem> lstitem     = new Elementos<DatoItem>();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo          = new DatoDescrMinima();
    DatoDescrMinima tipoTela        = new DatoDescrMinima();
    DatoDescrMinima compoConf1er    = new DatoDescrMinima();
    DatoDescrMinima porcentConf1er  = new DatoDescrMinima();
    DatoDescrMinima gradoElabo      = new DatoDescrMinima();
    DatoDescrMinima acabado1er      = new DatoDescrMinima();
    DatoDescrMinima mangaSup        = new DatoDescrMinima();
    DatoDescrMinima cuelloSup       = new DatoDescrMinima();
    DatoDescrMinima delanteSup      = new DatoDescrMinima();
    DatoDescrMinima internaSup      = new DatoDescrMinima();
    DatoDescrMinima largoSup        = new DatoDescrMinima();
    DatoDescrMinima bolsilloSup     = new DatoDescrMinima();
    DatoDescrMinima cinturaSup      = new DatoDescrMinima();
    DatoDescrMinima aplicacion      = new DatoDescrMinima();
    DatoDescrMinima complementos    = new DatoDescrMinima();

    prenda.setNumcorredoc(new Long(1));
    prenda.setNumsecitem(1);
    prenda.setNumsecprove(1);
    prenda.setNumsecprove(1);

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("TE0400");
    nombreComercial.setValtipdescri("CAS");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("TE0401");
    marcaComercial.setValtipdescri("FHB");

    modelo.setCodtipvalor(TEXTO);
    modelo.setCodtipdescr("TE0402");
    modelo.setValtipdescri("A11");

    tipoTela.setCodtipvalor(CATALOGO);
    tipoTela.setCodtipdescr("TE0403");
    tipoTela.setValtipdescri("TRA");

    compoConf1er.setCodtipvalor(CATALOGO);
    compoConf1er.setCodtipdescr("TE0404");
    compoConf1er.setValtipdescri("PES");

    porcentConf1er.setCodtipvalor(TEXTO);
    porcentConf1er.setCodtipdescr("TE0405");
    porcentConf1er.setValtipdescri("100");

    gradoElabo.setCodtipvalor(CATALOGO);
    gradoElabo.setCodtipdescr("TE0408");
    gradoElabo.setValtipdescri("TEN");

    acabado1er.setCodtipvalor(CATALOGO);
    acabado1er.setCodtipdescr("TE0409");
    acabado1er.setValtipdescri("LAV");

    mangaSup.setCodtipvalor(CATALOGO);
    mangaSup.setCodtipdescr("TE0413");
    mangaSup.setValtipdescri("ML");

    cuelloSup.setCodtipvalor(CATALOGO);
    cuelloSup.setCodtipdescr("TE0414");
    cuelloSup.setValtipdescri("CUO");

    delanteSup.setCodtipvalor(CATALOGO);
    delanteSup.setCodtipdescr("TE0415");
    delanteSup.setValtipdescri("ATC");

    internaSup.setCodtipvalor(CATALOGO);
    internaSup.setCodtipdescr("TE0416");
    internaSup.setValtipdescri("CFO");

    largoSup.setCodtipvalor(CATALOGO);
    largoSup.setCodtipdescr("TE0417");
    largoSup.setValtipdescri("MMU");

    bolsilloSup.setCodtipvalor(CATALOGO);
    bolsilloSup.setCodtipdescr("TE0418");
    bolsilloSup.setValtipdescri("CBO");

    cinturaSup.setCodtipvalor(CATALOGO);
    cinturaSup.setCodtipdescr("TE0419");
    cinturaSup.setValtipdescri("PRE");

    aplicacion.setCodtipvalor(CATALOGO);
    aplicacion.setCodtipdescr("TE0437");
    aplicacion.setValtipdescri("ADO");

    complementos.setCodtipvalor(CATALOGO);
    complementos.setCodtipdescr("RE0438");
    complementos.setValtipdescri("CCI");

    prenda.setNombreComercial(nombreComercial);
    prenda.setMarcaComercial(marcaComercial);
    prenda.setModelo(modelo);
    prenda.setTipoTela(tipoTela);
    prenda.setCompoConfeccion1erComp(compoConf1er);
    prenda.setCompoConfeccionPorcen1erComp(porcentConf1er);
    prenda.setGradoElaboracion(gradoElabo);
    prenda.setPrimerAcabado(acabado1er);
    prenda.setTipoMangaSuperior(mangaSup);
    prenda.setTipoCuelloSuperior(cuelloSup);
    prenda.setParteDelanteraSuperior(delanteSup);
    prenda.setParteInternaSuperior(internaSup);
    prenda.setLargoPrendaSuperior(largoSup);
    prenda.setBolsillosSuperior(bolsilloSup);
    prenda.setCinturaSuperior(cinturaSup);
    prenda.setAplicacionesPrendasVestir(aplicacion);
    prenda.setComplementoPrendasVestir(complementos);

    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("U");
    item.setNumpartnandi(new Long(6112930000L));
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    return new Object[][]{{prenda,dua}};
  }
  @Test(dataProvider = "initDataTest70")
  public void initDataTest70validarTipoTela(TextilPrenda prenda, Declaracion dua){
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(validador.validarTipoTela(prenda, item).get(0).getCodigo(), "31309");
  }

  //  @Test(dataProvider = "initDataTest70")
  //  public void initDataTest70TestUnidadComercial(TextilPrenda prenda, Declaracion dua){
  //    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
  //    Assert.assertEquals(validador.validarUnidadComercial(prenda, item).size(), 0);
  //  }
  //  @Test(dataProvider = "initDataTest70")
  //  public void initDataTest70TestTipo(TextilPrenda prenda, Declaracion dua){
  ////    Assert.assertEquals(validador.validarTipo(prenda, dua).size(), 0);
  //  }
  //  @Test(dataProvider = "initDataTest70")
  //  public void initDataTest70TestUnidadConstruccionSuperior(TextilPrenda prenda, Declaracion dua){
  //    Assert.assertEquals(validador.validarConstruccionSuperior(prenda).size(), 0);
  //  }

  // 71. La empresa XYZ pretende numerar una DUA solicitando a consumo
  // la siguiente prenda clasificada en la SPN 6302.60.00.00,
  // Toalla, marca Luckytex, modelo S/M, es de tejido con bucles sin
  // cortar por ambas caras, 100% algodón, teñido en un solo color,
  // sin elástico, rectangular, sin relleno, sin complementos
  // de gramaje: 320 g/m2, con bordes cocidos, en forma de figuras,
  // de dimensiones: 70 x 140 cm. de ancho y largo respectivamente,
  // 80 unidades, para baño.

  @DataProvider (name = "initDataTest71")
  private Object[][] initDataTest71(){
    return new Object[][]{{}};
  }

  //  @DataProvider( name = "initDataUnidaComercialInvalido" )
  //  private Object[][] initDataUnidaComercialInvalido(){
  //    TextilPrenda prenda              = new TextilPrenda();
  //    DatoDescrMinima nombreComercial  = new DatoDescrMinima();
  //    DatoItem item                    = new DatoItem();
  //
  //    item.setCodunidcomer("NI U NI 2U NI 12U");
  //    nombreComercial.setCodtipvalor(CATALOGO);
  //    nombreComercial.setCodtipdescr("001");
  //
  //    prenda.setNombreComercial(nombreComercial);
  //
  //    return new Object[][]{{ prenda, item }};
  //  }
  //
  //  @Test (dataProvider = "initDataUnidaComercialInvalido")
  // public void validarUnidaComercialInvalido(ModelAbstract object,
  //                                            DatoItem item){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    ErrorDescrMinima e = new ErrorDescrMinima("31303",
  //                         "La unidad comercial de prendas de vestir y " +
  //                         "confecciones debe ser U, 2U o 12U.");
  //    lst.add(e);
  //    Assert.assertEquals(lst, validador.validarUnidadComercial(object, item));
  //  }
  //
  //  @DataProvider( name = "initDataUnidaComercialVacio" )
  //  private Object[][] initDataUnidaComercialVacio(){
  //    TextilPrenda prenda              = new TextilPrenda();
  //    DatoDescrMinima nombreComercial  = new DatoDescrMinima();
  //    DatoItem item                    = new DatoItem();
  //
  //    nombreComercial.setCodtipvalor(CATALOGO);
  //    nombreComercial.setCodtipdescr("001");
  //
  //    prenda.setNombreComercial(nombreComercial);
  //
  //    return new Object[][]{{ prenda, item }};
  //  }
  //
  //  @Test (dataProvider = "initDataUnidaComercialVacio")
  // public void validarUnidaComercialVacio(ModelAbstract object,
  //                                            DatoItem item){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    ErrorDescrMinima e = new ErrorDescrMinima("31303",
  //                         "La unidad comercial de prendas de vestir y " +
  //                         "confecciones debe ser U, 2U o 12U.");
  //    lst.add(e);
  //    Assert.assertEquals(lst, validador.validarUnidadComercial(object, item));
  //  }
  //
  //  @DataProvider( name = "initDataUnidaComercial" )
  //  private Object[][] initDataUnidaComercial(){
  //    TextilPrenda prenda              = new TextilPrenda();
  //    DatoDescrMinima nombreComercial  = new DatoDescrMinima();
  //    DatoItem item                    = new DatoItem();
  //
  //    item.setCodunidcomer("12U");
  //    nombreComercial.setCodtipvalor(CATALOGO);
  //    nombreComercial.setCodtipdescr("001");
  //
  //    prenda.setNombreComercial(nombreComercial);
  //
  //    return new Object[][]{{ prenda, item }};
  //  }
  //
  //  @Test (dataProvider = "initDataUnidaComercial")
  //  public void validarUnidaComercial(ModelAbstract object, DatoItem item){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    Assert.assertEquals(lst, validador.validarUnidadComercial(object, item));
  //  }
  //
  //  @DataProvider( name = "initDataNombreComCJNInvalido" )
  //  private Object[][] initDataNombreComCJNInvalido(){
  //    TextilPrenda prenda               = new TextilPrenda();
  //    DatoDescrMinima nombreComercial   = new DatoDescrMinima();
  //    DatoDescrMinima nroPiezasSuperior = new DatoDescrMinima();
  //    DatoDescrMinima nroPiezasInferior = new DatoDescrMinima();
  //
  //
  //    nombreComercial.setCodtipvalor(CATALOGO);
  //    nombreComercial.setCodtipdescr("CJN");
  //
  //    nroPiezasSuperior.setCodtipvalor(TEXTO);
  //    nroPiezasSuperior.setValtipdescri("50");
  //
  //    nroPiezasInferior.setCodtipvalor(TEXTO);
  //    nroPiezasInferior.setValtipdescri("3");
  //
  //    prenda.setNombreComercial(nombreComercial);
  //
  //    return new Object[][]{{ prenda }};
  //  }
  //
  //  @Test (dataProvider = "initDataNombreComCJNInvalido")
  //  public void validarNombreComCJNInvalido(ModelAbstract object){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  // ErrorDescrMinima e = new ErrorDescrMinima("31307",
  // "El número de piezas del conjunto y/o el número de piezas " +
  // "de la parte superior o inferior es inválido.");
  //    lst.add(e);
  //    Assert.assertEquals(lst, validador.validarNombreComercial(object));
  //  }
  //
  //  @DataProvider( name = "initDataNombreComCJN" )
  //  private Object[][] initDataNombreComCJN(){
  //    TextilPrenda prenda               = new TextilPrenda();
  //    DatoDescrMinima nombreComercial   = new DatoDescrMinima();
  //    DatoDescrMinima nroPiezasSuperior = new DatoDescrMinima();
  //    DatoDescrMinima nroPiezasInferior = new DatoDescrMinima();
  //
  //
  //    nombreComercial.setCodtipvalor(CATALOGO);
  //    nombreComercial.setCodtipdescr("CJN");
  //
  //    nroPiezasSuperior.setCodtipvalor(TEXTO);
  //    nroPiezasSuperior.setValtipdescri("5");
  //
  //    nroPiezasInferior.setCodtipvalor(TEXTO);
  //    nroPiezasInferior.setValtipdescri("3");
  //
  //    prenda.setNombreComercial(nombreComercial);
  //
  //    return new Object[][]{{ prenda }};
  //  }
  //
  //  @Test (dataProvider = "initDataNombreComCJN")
  //  public void validarNombreComCJN(ModelAbstract object){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    Assert.assertEquals(lst, validador.validarNombreComercial(object));
  //  }
  //
  //  @DataProvider( name = "initDataTipoTelaInvalido" )
  //  private Object[][] initDataTipoTelaInvalido(){
  //    TextilPrenda prenda          = new TextilPrenda();
  //    DatoDescrMinima tipoTela     = new DatoDescrMinima();
  //    Declaracion dua              = new Declaracion();
  //
  //    DUA dam = new DUA();
  //    dam.setNumcorredoc(new Long(1));
  //    Elementos<DAV> listDAVs = new Elementos<DAV>();
  //    DAV dav = new DAV();
  //    dav.setNumcorredoc(new Long(1));
  //    dav.setNumcodsecprove(new Long(1));
  //
  //    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
  //    DatoFactura factu = new DatoFactura();
  //    factu.setNumcorredoc(new Long(1));
  //    factu.setNumfactura("1");
  //    factu.setNumsecfactu(1);
  //    factu.setNumsecprove(1);
  //
  //    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
  //    DatoItem item = new DatoItem();
  //    item.setNumcorredoc(new Long(1));
  //    item.setNumfact("1");
  //    item.setNumsecitem(1);
  //    item.setNumsecprove(1);
  //    item.setCodunidcomer("SET");
  //    item.setNumpartnandi(new Long(6005320000L));
  //    lstitem.add(item);
  //
  //    factu.setListItems(lstitem);
  //    lstFactu.add(factu);
  //
  //    dav.setListFacturas(lstFactu);
  //
  //    listDAVs.add(dav);
  //    dua.setListDAVs(listDAVs);
  //    dua.setDua(dam);
  //
  //    tipoTela.setCodtipvalor(CATALOGO);
  //    tipoTela.setCodtipdescr("LSL");
  //
  //    prenda.setTipoTela(tipoTela);
  //
  //    return new Object[][]{{ prenda, dua }};
  //  }
  //
  //  @Test (dataProvider = "initDataTipoTelaInvalido")
  //  public void validarTipoTelaInvalido(ModelAbstract object, Declaracion dua){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    ErrorDescrMinima e         = new ErrorDescrMinima("31308",
  //                                    "El tipo de tela de prendas de vestir y " +
  // "confecciones no corresponde al catálogo.");
  //    lst.add(e);
  //    Assert.assertEquals(lst, validador.validarTipo(object, dua));
  //  }
  //
  //  @DataProvider( name = "initDataTipoTelaNoPTO" )
  //  private Object[][] initDataTipoTelaNoPTO(){
  //    TextilPrenda prenda          = new TextilPrenda();
  //    DatoDescrMinima tipoTela     = new DatoDescrMinima();
  //    Declaracion dua              = new Declaracion();
  //
  //    DUA dam = new DUA();
  //    dam.setNumcorredoc(new Long(1));
  //    Elementos<DAV> listDAVs = new Elementos<DAV>();
  //    DAV dav = new DAV();
  //    dav.setNumcorredoc(new Long(1));
  //    dav.setNumcodsecprove(new Long(1));
  //
  //    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
  //    DatoFactura factu = new DatoFactura();
  //    factu.setNumcorredoc(new Long(1));
  //    factu.setNumfactura("1");
  //    factu.setNumsecfactu(1);
  //    factu.setNumsecprove(1);
  //
  //    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
  //    DatoItem item = new DatoItem();
  //    item.setNumcorredoc(new Long(1));
  //    item.setNumfact("1");
  //    item.setNumsecitem(1);
  //    item.setNumsecprove(1);
  //    item.setCodunidcomer("SET");
  //    item.setNumpartnandi(new Long(6105320000L));
  //    lstitem.add(item);
  //
  //    factu.setListItems(lstitem);
  //    lstFactu.add(factu);
  //
  //    dav.setListFacturas(lstFactu);
  //
  //    listDAVs.add(dav);
  //    dua.setListDAVs(listDAVs);
  //    dua.setDua(dam);
  //
  //    tipoTela.setCodtipvalor(CATALOGO);
  //    tipoTela.setCodtipdescr("CHE");
  //
  //    prenda.setTipoTela(tipoTela);
  //
  //    return new Object[][]{{ prenda, dua }};
  //  }
  //
  //  @Test (dataProvider = "initDataTipoTelaNoPTO")
  //  public void validarTipoTelaNoPTO(ModelAbstract object, Declaracion dua){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    ErrorDescrMinima e         = new ErrorDescrMinima("31309",
  // "Debe enviar el código PTO del tipo de tela de prendas " +
  //                    "de vestir y confecciones si declara las partidas asociadas " +
  // "al capítulo 61 o las SPN asociadas a las partidas  6212.");
  //    lst.add(e);
  //    Assert.assertEquals(lst, validador.validarTipo(object, dua));
  //  }
  //
  //  @DataProvider( name = "initDataTipoTelaPTONoCapitulo" )
  //  private Object[][] initDataTipoTelaPTONoCapitulo(){
  //    TextilPrenda prenda          = new TextilPrenda();
  //    DatoDescrMinima tipoTela     = new DatoDescrMinima();
  //    Declaracion dua              = new Declaracion();
  //
  //    DUA dam = new DUA();
  //    dam.setNumcorredoc(new Long(1));
  //    Elementos<DAV> listDAVs = new Elementos<DAV>();
  //    DAV dav = new DAV();
  //    dav.setNumcorredoc(new Long(1));
  //    dav.setNumcodsecprove(new Long(1));
  //
  //    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
  //    DatoFactura factu = new DatoFactura();
  //    factu.setNumcorredoc(new Long(1));
  //    factu.setNumfactura("1");
  //    factu.setNumsecfactu(1);
  //    factu.setNumsecprove(1);
  //
  //    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
  //    DatoItem item = new DatoItem();
  //    item.setNumcorredoc(new Long(1));
  //    item.setNumfact("1");
  //    item.setNumsecitem(1);
  //    item.setNumsecprove(1);
  //    item.setCodunidcomer("SET");
  //    item.setNumpartnandi(new Long(6005320000L));
  //    lstitem.add(item);
  //
  //    factu.setListItems(lstitem);
  //    lstFactu.add(factu);
  //
  //    dav.setListFacturas(lstFactu);
  //
  //    listDAVs.add(dav);
  //    dua.setListDAVs(listDAVs);
  //    dua.setDua(dam);
  //
  //    tipoTela.setCodtipvalor(CATALOGO);
  //    tipoTela.setCodtipdescr("PTO");
  //
  //    prenda.setTipoTela(tipoTela);
  //
  //    return new Object[][]{{ prenda, dua }};
  //  }
  //
  //  @Test (dataProvider = "initDataTipoTelaPTONoCapitulo")
  //  public void validarTipoTelaPTONoCapitulo(ModelAbstract object, Declaracion dua){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    ErrorDescrMinima e         = new ErrorDescrMinima("31310",
  // "No debe enviar el código PTO del tipo de tela de " +
  //                    "prendas de vestir y confecciones si declara las " +
  // "partidas asociadas distintas al capítulo 61 o a las " +
  //                    "partidas  6212.");
  //    lst.add(e);
  //    Assert.assertEquals(lst, validador.validarTipo(object, dua));
  //  }
  //
  //  @DataProvider( name = "initDataTipoTelaSP_6302NoTCB" )
  //  private Object[][] initDataTipoTelaSP_6302NoTCB(){
  //    TextilPrenda prenda          = new TextilPrenda();
  //    DatoDescrMinima tipoTela     = new DatoDescrMinima();
  //    Declaracion dua              = new Declaracion();
  //
  //    DUA dam = new DUA();
  //    dam.setNumcorredoc(new Long(1));
  //    Elementos<DAV> listDAVs = new Elementos<DAV>();
  //    DAV dav = new DAV();
  //    dav.setNumcorredoc(new Long(1));
  //    dav.setNumcodsecprove(new Long(1));
  //
  //    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
  //    DatoFactura factu = new DatoFactura();
  //    factu.setNumcorredoc(new Long(1));
  //    factu.setNumfactura("1");
  //    factu.setNumsecfactu(1);
  //    factu.setNumsecprove(1);
  //
  //    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
  //    DatoItem item = new DatoItem();
  //    item.setNumcorredoc(new Long(1));
  //    item.setNumfact("1");
  //    item.setNumsecitem(1);
  //    item.setNumsecprove(1);
  //    item.setCodunidcomer("SET");
  //    item.setNumpartnandi(new Long(6302600000L));
  //    lstitem.add(item);
  //
  //    factu.setListItems(lstitem);
  //    lstFactu.add(factu);
  //
  //    dav.setListFacturas(lstFactu);
  //
  //    listDAVs.add(dav);
  //    dua.setListDAVs(listDAVs);
  //    dua.setDua(dam);
  //
  //    tipoTela.setCodtipvalor(CATALOGO);
  //    tipoTela.setCodtipdescr("CHE");
  //
  //    prenda.setTipoTela(tipoTela);
  //
  //    return new Object[][]{{ prenda, dua }};
  //  }
  //
  //  @Test (dataProvider = "initDataTipoTelaSP_6302NoTCB")
  //  public void validarTipoTelaSP_6302NoTCB(ModelAbstract object, Declaracion dua){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    ErrorDescrMinima e         = new ErrorDescrMinima("31311",
  // "Debe enviar el código TCB del tipo de tela de prendas " +
  //                    "de vestir y confecciones si declara la SPN 6302600000.");
  //    lst.add(e);
  //    Assert.assertEquals(lst, validador.validarTipo(object, dua));
  //  }
  //
  //  @DataProvider( name = "initDataTipoTelaTCBNoSP_6302" )
  //  private Object[][] initDataTipoTelaTCBNoSP_6302(){
  //    TextilPrenda prenda          = new TextilPrenda();
  //    DatoDescrMinima tipoTela     = new DatoDescrMinima();
  //    Declaracion dua              = new Declaracion();
  //
  //    DUA dam = new DUA();
  //    dam.setNumcorredoc(new Long(1));
  //    Elementos<DAV> listDAVs = new Elementos<DAV>();
  //    DAV dav = new DAV();
  //    dav.setNumcorredoc(new Long(1));
  //    dav.setNumcodsecprove(new Long(1));
  //
  //    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
  //    DatoFactura factu = new DatoFactura();
  //    factu.setNumcorredoc(new Long(1));
  //    factu.setNumfactura("1");
  //    factu.setNumsecfactu(1);
  //    factu.setNumsecprove(1);
  //
  //    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
  //    DatoItem item = new DatoItem();
  //    item.setNumcorredoc(new Long(1));
  //    item.setNumfact("1");
  //    item.setNumsecitem(1);
  //    item.setNumsecprove(1);
  //    item.setCodunidcomer("SET");
  //    item.setNumpartnandi(new Long(6002600000L));
  //    lstitem.add(item);
  //
  //    factu.setListItems(lstitem);
  //    lstFactu.add(factu);
  //
  //    dav.setListFacturas(lstFactu);
  //
  //    listDAVs.add(dav);
  //    dua.setListDAVs(listDAVs);
  //    dua.setDua(dam);
  //
  //    tipoTela.setCodtipvalor(CATALOGO);
  //    tipoTela.setCodtipdescr("TCB");
  //
  //    prenda.setTipoTela(tipoTela);
  //
  //    return new Object[][]{{ prenda, dua }};
  //  }
  //
  //  @Test (dataProvider = "initDataTipoTelaTCBNoSP_6302")
  //  public void validarTipoTelaTCBNoSP_6302(ModelAbstract object, Declaracion dua){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    ErrorDescrMinima e         = new ErrorDescrMinima("31312",
  // "No debe enviar el código TCB del tipo de tela de prendas " +
  //                    "de vestir y confecciones si declara una SPN distinta " +
  //                    "a la 6302600000.");
  //    lst.add(e);
  //    Assert.assertEquals(lst, validador.validarTipo(object, dua));
  //  }
  //
  //  @DataProvider( name = "initDataTipoTelaOtros" )
  //  private Object[][] initDataTipoTelaOtros(){
  //    TextilPrenda prenda          = new TextilPrenda();
  //    DatoDescrMinima tipoTela     = new DatoDescrMinima();
  //    Declaracion dua              = new Declaracion();
  //
  //    DUA dam = new DUA();
  //    dam.setNumcorredoc(new Long(1));
  //    Elementos<DAV> listDAVs = new Elementos<DAV>();
  //    DAV dav = new DAV();
  //    dav.setNumcorredoc(new Long(1));
  //    dav.setNumcodsecprove(new Long(1));
  //
  //    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
  //    DatoFactura factu = new DatoFactura();
  //    factu.setNumcorredoc(new Long(1));
  //    factu.setNumfactura("1");
  //    factu.setNumsecfactu(1);
  //    factu.setNumsecprove(1);
  //
  //    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
  //    DatoItem item = new DatoItem();
  //    item.setNumcorredoc(new Long(1));
  //    item.setNumfact("1");
  //    item.setNumsecitem(1);
  //    item.setNumsecprove(1);
  //    item.setCodunidcomer("SET");
  //    item.setNumpartnandi(new Long(5907000000L));
  //    lstitem.add(item);
  //
  //    factu.setListItems(lstitem);
  //    lstFactu.add(factu);
  //
  //    dav.setListFacturas(lstFactu);
  //
  //    listDAVs.add(dav);
  //    dua.setListDAVs(listDAVs);
  //    dua.setDua(dam);
  //
  //    tipoTela.setCodtipvalor(CATALOGO);
  //    tipoTela.setCodtipdescr("CHE");
  //
  //    prenda.setTipoTela(tipoTela);
  //
  //    return new Object[][]{{ prenda, dua }};
  //  }
  //
  //  @Test (dataProvider = "initDataTipoTelaOtros")
  //  public void validarTipoTelaOtros(ModelAbstract object, Declaracion dua){
  //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
  //    Assert.assertEquals(lst, validador.validarTipo(object, dua));
  //  }
}
