package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.pilas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.pilas.model.Pila;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorPilaTest extends AbstractServiceTest{
	
 @Autowired
 @Qualifier("ValidadorPila")
 private ValidadorPila validador;

 private Pila			pila;
 private Declaracion	declaracion;	
	  
 @BeforeClass
 public void initData() throws Exception{
	 System.out.println("LOAD TEST UNITARIOS ...");
	 Pila pila = new Pila();
	 //nombre Comercial
	 DatoDescrMinima nombreComercial = new DatoDescrMinima();
	 nombreComercial.setValtipdescri("nombreComercial"); //NO HAY CATALOGO
	 pila.setNombreComercial(nombreComercial);
	 //marca Comercial
	 DatoDescrMinima marcaComercial = new DatoDescrMinima();
	 marcaComercial.setValtipdescri("marcacomercial"); //NO HAY CATALOGO
	 pila.setMarcaComercial(marcaComercial);
	 //modelo
	 DatoDescrMinima modelo = new DatoDescrMinima();
	 modelo.setValtipdescri("modelo"); //NO HAY CATALOGO
	 pila.setModelo(modelo);
	 //tipo
	 DatoDescrMinima tipo = new DatoDescrMinima();
	 tipo.setValtipdescri("MNR"); //MNR,MLR,HGO,AGO,LIT,OZN,ZZZ
	 pila.setTipo(tipo);	 
	 //formato
	 DatoDescrMinima formato = new DatoDescrMinima();
	 formato.setValtipdescri("CIL"); //CIL,BOT,CUR,ZZZ 
	 pila.setFormato(formato);	 	 
	 //designacion
	 DatoDescrMinima designacion = new DatoDescrMinima();
	 designacion.setValtipdescri("A001"); //A001,A002,A003,A004,A005,A007,....I064,I065,I066,I067 
	 pila.setDesignacion(designacion);	 	 
	 //voltaje
	 DatoDescrMinima voltaje = new DatoDescrMinima();
	 voltaje.setValtipdescri("voltejo"); //NO HAY CATALOGO
	 pila.setVoltaje(voltaje);	 
	 //UnidadComercial
	 Declaracion declaracion = new Declaracion();
	 Elementos<DAV> listDAVs = new Elementos<DAV>();
	 DAV dav = new DAV();
	 Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
	 DatoFactura factu = new DatoFactura();
	 Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
	 DatoItem item = new DatoItem();
	 item.setNumsecitem(3);
	 item.setCodunidcomer("12U"); 
	 item.setNumpartnandi(8506101100L);
	 lstitem.add(item);
	 factu.setListItems(lstitem);
	 lstFactu.add(factu);
	 dav.setListFacturas(lstFactu);
	 listDAVs.add(dav);
	 declaracion.setListDAVs(listDAVs);
	 pila.setNumsecitem(3);
	 this.declaracion = declaracion;
	 this.pila = pila;
	  }

 	@Test
 	public void testValidarUnidadComercial(){
 		Assert.assertEquals(validador.validarUnidadComercial(pila, declaracion).size(),0);
 	}
 	
 	@Test
 	public void testValidarNombreComercial(){
 		Assert.assertEquals(validador.validarNombreComercial(pila).size(),1);
 	} 	
 	
 	@Test
 	public void testValidarMarcaComercial(){
 		Assert.assertEquals(validador.validarMarcaComercial(pila).size(),0);
 	} 	
 	
 	@Test
 	public void testValidarModelo(){
 		Assert.assertEquals(validador.validarModelo(pila).size(),0);
 	} 	
 	
 	@Test
 	public void testValidarTipo(){
 	    String tipo = pila.getTipo().getValtipdescri(); 
 	    Assert.assertEquals(validador.estaEnCatalogo(tipo,"TA"),true);
 	  } 	
	
 	@Test
 	public void testValidarFormato(){
 	    String formato = pila.getFormato().getValtipdescri(); 
 	    Assert.assertEquals(validador.estaEnCatalogo(formato,"TB"),true);
 	  } 	
	
 	@Test
 	public void testValidarDesignacion(){
 	    String designacion = pila.getDesignacion().getValtipdescri(); 
 	    Assert.assertEquals(validador.estaEnCatalogo(designacion,"TC"),true);
 	  }
	
 	@Test
 	public void testValidarVoltaje(){
 		Assert.assertEquals(validador.validarVoltaje(pila).size(),0);
 	} 	
	
 	@Test
 	public void testValidarCorrelacionTipoYFormaConSubPartida(){
 		Assert.assertEquals(validador.validarCorrelacionTipoYFormaConSubPartida(pila, declaracion).size(),1);
 	}
}