package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.cierres;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreOtros;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorCierreOtrosTest extends AbstractServiceTest {
	
	 @Autowired
	 @Qualifier("ValidadorCierreOtros")
	 private ValidadorCierreOtros validador;

	 private CierreOtros		cierreOtros;
	 private Declaracion	declaracion;	

	 @BeforeClass
	 public void initData() throws Exception{
		 System.out.println("LOAD TEST UNITARIOS ...");
		 CierreOtros cierreOtros = new CierreOtros();
		 //nombreComercial
		 DatoDescrMinima nombreComercial = new DatoDescrMinima();
		 nombreComercial.setValtipdescri("CRE"); //CRE,LLA,TIR
		 cierreOtros.setNombreComercial(nombreComercial);		 
		 //marcaComercial
		 DatoDescrMinima marcaComercial = new DatoDescrMinima();
		 marcaComercial.setValtipdescri("marcacomercial"); //NO HAY CATALOGO
		 cierreOtros.setMarcaComercial(marcaComercial);		 
		 //modelo
		 DatoDescrMinima modelo = new DatoDescrMinima();
		 modelo.setValtipdescri("modelo"); //NO HAY CATALOGO
		 cierreOtros.setModelo(modelo);
		 //composicionCinta
		 DatoDescrMinima composicionCinta = new DatoDescrMinima();
		 composicionCinta.setValtipdescri("01"); //01,02,03,04...
		 cierreOtros.setComposicionCinta(composicionCinta);		 
		 //presentacionCinta
		 DatoDescrMinima presentacionCinta = new DatoDescrMinima();
		 presentacionCinta.setValtipdescri("02"); //01,02,03,04...
		 cierreOtros.setPresentacionCinta(presentacionCinta);		 		 
		 //materialDientes
		 DatoDescrMinima materialDientes = new DatoDescrMinima();
		 materialDientes.setValtipdescri("COB"); //ALU,AZI,COB
		 cierreOtros.setMaterialDientes(materialDientes);		 
		 //tamanoDientes
		 DatoDescrMinima tamanoDientes = new DatoDescrMinima();
		 tamanoDientes.setValtipdescri("25"); //NO HAY CATALOGO
		 cierreOtros.setTamanoDientes(tamanoDientes);
		 //tipoLlave
		 DatoDescrMinima tipoLlave = new DatoDescrMinima();
		 tipoLlave.setValtipdescri("SAT"); //AUT,NLO,REV,SAT...
		 cierreOtros.setTipoLlave(tipoLlave);		 
		 //materialLlave
		 DatoDescrMinima materialLlave = new DatoDescrMinima();
		 materialLlave.setValtipdescri("COB"); //ALU,AZI,COB
		 cierreOtros.setMaterialLlave(materialLlave);		 
		 //UnidadComercial
		 Declaracion declaracion = new Declaracion();
		 Elementos<DAV> listDAVs = new Elementos<DAV>();
		 DAV dav = new DAV();
		 Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
		 DatoFactura factu = new DatoFactura();
		 Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
		 DatoItem item = new DatoItem();
		 item.setNumsecitem(3);
		 item.setCodunidcomer("12U"); 
		 item.setNumpartnandi(8506101100L);
		 lstitem.add(item);
		 factu.setListItems(lstitem);
		 lstFactu.add(factu);
		 dav.setListFacturas(lstFactu);
		 listDAVs.add(dav);
		 declaracion.setListDAVs(listDAVs);
		 cierreOtros.setNumsecitem(3);
		 this.declaracion = declaracion;
		 this.cierreOtros = cierreOtros;
		  }	 

	 	@Test
	 	public void testValidarUnidadComercial(){
	 		Assert.assertEquals(validador.validarUnidadComercial(cierreOtros, declaracion).size(),0);
	 	} 	 
	 	@Test
	 	public void testValidarNombreComercial(){
	 		Assert.assertEquals(validador.validarNombreComercial(cierreOtros).size(),0);
	 	} 	 	
	 	@Test
	 	public void testValidarMarcaComercial(){
	 		Assert.assertEquals(validador.validarMarcaComercial(cierreOtros).size(),0);
	 	} 	
	 	@Test
	 	public void testValidarModelo(){
	 		Assert.assertEquals(validador.validarModelo(cierreOtros).size(),0);
	 	} 	 
	 	@Test
	 	public void testValidarComposicionCinta(){
	 		Assert.assertEquals(validador.validarComposicionCinta(cierreOtros).size(),0);
	 	} 
	 	@Test
	 	public void testValidarPresentacionCinta(){
	 		Assert.assertEquals(validador.validarPresentacionCinta(cierreOtros).size(),0);
	 	} 
	 	@Test
	 	public void testValidarMaterialDientes(){
	 		Assert.assertEquals(validador.validarMaterialDientes(cierreOtros).size(),0);
	 	} 	 	
	 	@Test
	 	public void testValidarTamanoDientes(){
	 		Assert.assertEquals(validador.validarTamanoDientes(cierreOtros).size(),0);
	 	} 		 	
	 	@Test
	 	public void testValidarTipoLlave(){
	 		Assert.assertEquals(validador.validarTipoLlave(cierreOtros).size(),1);
	 	} 		 	
	 	@Test
	 	public void testValidarMaterialLlave(){
	 		Assert.assertEquals(validador.validarMaterialLlave(cierreOtros).size(),1);
	 	} 
}
