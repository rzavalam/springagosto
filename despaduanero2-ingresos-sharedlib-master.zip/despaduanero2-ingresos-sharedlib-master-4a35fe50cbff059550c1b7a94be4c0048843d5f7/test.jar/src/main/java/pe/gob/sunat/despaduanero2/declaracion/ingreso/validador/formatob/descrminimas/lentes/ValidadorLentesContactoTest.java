package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.lentes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesContacto;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorLentesContactoTest extends AbstractServiceTest{
	@Autowired
	@Qualifier("ValidadorLentesContacto")
	private ValidadorLentesContacto validador;

	private static final String TEXTO    = "1";
	private static final String CATALOGO = "0";

	
	@DataProvider(name = "initEnlaceAduanero_120")
	public Object[][] initEnlaceAduanero_120(){
	  LentesContacto contacto = new LentesContacto();
	  DatoDescrMinima nombreComercial =  new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima materialLente = new DatoDescrMinima();
	  DatoDescrMinima tipoLente = new DatoDescrMinima();
	  DatoDescrMinima rangoDeMedida = new DatoDescrMinima();
	  DatoDescrMinima usoLenteContacto = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  
	  item.setNumpartnandi(new Long(9001300000L));
	  
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("LE0300");
	  nombreComercial.setValtipdescri("LCC");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LE0301");
	  marcaComercial.setValtipdescri("Vistakon");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LE0302");
	  modelo.setValtipdescri("Acuvue");
	  
	  materialLente.setCodtipvalor(CATALOGO);
	  materialLente.setCodtipdescr("LE0303");
	  materialLente.setValtipdescri("HEM");
	  	  
	  tipoLente.setCodtipvalor(CATALOGO);
	  tipoLente.setCodtipdescr("LE0305");	
	  tipoLente.setValtipdescri("BLD");
	  
	  usoLenteContacto.setCodtipvalor(CATALOGO);
	  usoLenteContacto.setCodtipdescr("LE0306");
	  usoLenteContacto.setValtipdescri("CON");
	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LE0309");
	  color.setValtipdescri("BLA");
	  
	  rangoDeMedida.setCodtipvalor(TEXTO);
	  rangoDeMedida.setCodtipdescr("LE0312");
	  rangoDeMedida.setValtipdescri("3.25-4.00");
	  
	  contacto.setNombreComercial(nombreComercial);
	  contacto.setMarcaComercial(marcaComercial);
	  contacto.setModelo(modelo);
	  contacto.setMaterialLente(materialLente);
	  contacto.setTipoLente(tipoLente);
	  contacto.setUsoLenteContacto(usoLenteContacto);
	  contacto.setColor(color);
	  contacto.setRangoDeMedida(rangoDeMedida);
	  contacto.setTratamiento(new DatoDescrMinima());
	  contacto.setNumeroFocos(new DatoDescrMinima());
	  contacto.setAcabado(new DatoDescrMinima());
	  contacto.setSeriesDeMedida(new DatoDescrMinima());
	  
	  
	  return new Object[][]{{contacto,item}};
	}
	
	@Test(dataProvider = "initEnlaceAduanero_120")
	  public void testValidarNombreComercial120(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(contacto, item).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_120")
	  public void testValidaMaterial120(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarMaterial(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_120")
	  public void testValidaSeriesDeMedida120(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarSeriesDeMedida(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_120")
	  public void testValidaTipoDeLente120(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarTipoLente(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_120")
	  public void testValidaNroFocos120(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarNroFocos(contacto).size(),0);
	  }

	@Test(dataProvider = "initEnlaceAduanero_120")
	  public void testValidaColor120(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarColor(contacto).size(),0);
	  }

	@Test(dataProvider = "initEnlaceAduanero_120")
	  public void testValidaTratamiento120(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarTratamiento(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_120")
	  public void testValidaAcabado120(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarAcabado(contacto).size(),0);
	  }
	
	@DataProvider(name = "initEnlaceCostmar_123")
	public Object[][] initEnlaceCostmar_123(){
	  LentesContacto contacto = new LentesContacto();
	  DatoDescrMinima nombreComercial =  new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima materialLente = new DatoDescrMinima();
	  DatoDescrMinima tipoLente = new DatoDescrMinima();
	  DatoDescrMinima rangoDeMedida = new DatoDescrMinima();
	  DatoDescrMinima usoLenteContacto = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  
	  item.setNumpartnandi(new Long(9001300000L));
	  
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("LE0300");
	  nombreComercial.setValtipdescri("LCC");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LE0301");
	  marcaComercial.setValtipdescri("Vistakon");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LE0302");
	  modelo.setValtipdescri("Silicone");
	  
	  materialLente.setCodtipvalor(CATALOGO);
	  materialLente.setCodtipdescr("LE0303");
	  materialLente.setValtipdescri("SIL");
	  	  
	  tipoLente.setCodtipvalor(CATALOGO);
	  tipoLente.setCodtipdescr("LE0305");	
	  tipoLente.setValtipdescri("BLD");
	  
	  usoLenteContacto.setCodtipvalor(CATALOGO);
	  usoLenteContacto.setCodtipdescr("LE0306");
	  usoLenteContacto.setValtipdescri("DES");
	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LE0309");
	  color.setValtipdescri("BLA");
	  
	  rangoDeMedida.setCodtipvalor(TEXTO);
	  rangoDeMedida.setCodtipdescr("LE0312");
	  rangoDeMedida.setValtipdescri("1.10-2.00");
	  
	  contacto.setNombreComercial(nombreComercial);
	  contacto.setMarcaComercial(marcaComercial);
	  contacto.setModelo(modelo);
	  contacto.setMaterialLente(materialLente);
	  contacto.setTipoLente(tipoLente);
	  contacto.setUsoLenteContacto(usoLenteContacto);
	  contacto.setColor(color);
	  contacto.setRangoDeMedida(rangoDeMedida);
	  contacto.setTratamiento(new DatoDescrMinima());
	  contacto.setNumeroFocos(new DatoDescrMinima());
	  contacto.setAcabado(new DatoDescrMinima());
	  contacto.setSeriesDeMedida(new DatoDescrMinima());
	  
	  
	  return new Object[][]{{contacto,item}};
	}
	
	@Test(dataProvider = "initEnlaceCostmar_123")
	  public void testValidarNombreComercial123(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(contacto, item).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceCostmar_123")
	  public void testValidaMaterial123(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarMaterial(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceCostmar_123")
	  public void testValidaSeriesDeMedida123(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarSeriesDeMedida(contacto).size(),1);
	  }
	
	@Test(dataProvider = "initEnlaceCostmar_123")
	  public void testValidaTipoDeLente123(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarTipoLente(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceCostmar_123")
	  public void testValidaNroFocos123(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarNroFocos(contacto).size(),0);
	  }

	@Test(dataProvider = "initEnlaceCostmar_123")
	  public void testValidaColor123(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarColor(contacto).size(),0);
	  }

	@Test(dataProvider = "initEnlaceCostmar_123")
	  public void testValidaTratamiento123(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarTratamiento(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceCostmar_123")
	  public void testValidaAcabado123(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarAcabado(contacto).size(),0);
	  }
	
}
