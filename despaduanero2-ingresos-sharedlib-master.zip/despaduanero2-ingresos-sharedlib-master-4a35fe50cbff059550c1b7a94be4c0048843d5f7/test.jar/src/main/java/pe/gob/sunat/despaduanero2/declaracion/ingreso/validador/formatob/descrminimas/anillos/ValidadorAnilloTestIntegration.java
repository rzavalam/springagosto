package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.anillos;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.anillos.model.Anillo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorAnilloTestIntegration extends AbstractServiceTest{

  @Autowired
  @Qualifier("ValidadorAnillo")
  private ValidadorAnillo validador;

  @Autowired
  @Qualifier("framework.fabricaDeServicios")
  private FabricaDeServicios fabricaDeServicios;
  private static Mensaje mensaje1001;
  private static Declaracion declaracion1001;

  @Autowired
  @Qualifier("Ayuda.ayudaServiceCache")
  private AyudaServiceCache            ayudaServiceCache;


  private Anillo          anillo;


  @BeforeClass
  public void initData() throws Exception{

    System.out.println("LOAD TEST UNITARIOS ...");

    assertNotNull(fabricaDeServicios, "No se cargo la fabrica de servicios desde el contexto");
    // String filename = "src/test/java/xmlOther/Reg10_560114_cal.xml";
    String filename = "src/test/java/xmlAnillos/ANILLOS.xml";
    String numeroTransaccion = "1001";
    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");
    Map<String, Object> parametros = null;
    parametros = new HashMap<String, Object>();
    parametros.put("numeroTransaccion", numeroTransaccion);
    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);
    //Verificar la Existencia de Reglas
    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);
    //Verificar que Convirtio el XML a Mensaje
    assertNotNull(mensaje1001);
    declaracion1001 = (Declaracion) mensaje1001.getDocumento();
    System.out.println("declaracion " + declaracion1001.getCodaduana());

    System.out.println(pe.gob.sunat.framework.spring.util.conversion.SojoUtil.toJson(declaracion1001));

    declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();

    anillo = new Anillo();
    String codigo, valor;
    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima>  listaDescripcionMinimas = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getListDecrMinima();

    for(pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima descripcion : listaDescripcionMinimas){
      codigo =  descripcion.getCodtipdescr().trim();
      valor  =  descripcion.getValtipdescri().trim();
      Integer codigo_int = Integer.parseInt(codigo.substring(5,6));
      switch (codigo_int) {
      case 0:
        DatoDescrMinima nombreCom = new DatoDescrMinima();
        nombreCom.setValtipdescri(valor);
      nombreCom.setNumsecitem(declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getNumsecitem());
        anillo.setNombreComercial(nombreCom);
        break;
      case 1:   DatoDescrMinima marcaComercial = new DatoDescrMinima(); marcaComercial.setValtipdescri(valor);  anillo.setMarcaComercial(marcaComercial);break;
      case 2:   DatoDescrMinima modelo = new DatoDescrMinima(); modelo.setValtipdescri(valor);  anillo.setModelo(modelo);break;
      case 3:   DatoDescrMinima tipoanillos = new DatoDescrMinima(); tipoanillos.setValtipdescri(valor); anillo.setTipoAnillos(tipoanillos);break;
      case 4:   DatoDescrMinima matFab = new DatoDescrMinima(); matFab.setValtipdescri(valor); anillo.setMaterialFabricacion(matFab);break;
      case 5:   DatoDescrMinima acabadoAni = new DatoDescrMinima();acabadoAni.setValtipdescri(valor);anillo.setAcabado(acabadoAni);break;
      case 6:   DatoDescrMinima usoAni = new DatoDescrMinima(); usoAni.setValtipdescri(valor);anillo.setUso(usoAni);break;
      case 7:   DatoDescrMinima dimension = new DatoDescrMinima();dimension.setValtipdescri(valor);anillo.setDimension(dimension);

      }
    }

  }

  @Test
  public void testValidarUnidadComercial()
  {

    //por el momento '0'
    validador.validarUnidadComercial(anillo ,declaracion1001).size();
    Assert.assertEquals(validador.validarUnidadComercial(anillo ,declaracion1001).size(),1);
  }

  @Test
  public void testValidarNombreComercial()
  {
    System.out.println(" *Test ValidarNombreComercial: ");
    System.out.print(" Nombre Comercial Anillos: " +anillo.getNombreComercial().getValtipdescri());
    //por el momento '0'
    Assert.assertEquals(validador.validarNombreComercial(anillo).size(),0);
  }

  @Test
  public void testValidarMarcaComercial()
  {
    System.out.println(" *Test ValidarMarcaComercial: ");
    System.out.print(" Marca Comercial anillos: " +anillo.getMarcaComercial().getValtipdescri());
    //por el momento '0'
    Assert.assertEquals(validador.validarMarcaComercial(anillo).size(),0);
  }

  @Test
  public void testValidarModelo()
  {
    //     System.out.println(" *Test ValidarModelo: ");
    System.out.println(" Modelo de anillos: " +anillo.getModelo().getValtipdescri());
    //por el momento '0'
    Assert.assertEquals(validador.validarModelo(anillo).size(),0);
  }

  @Test
  public void testValidarTipo()
  {
    System.out.println(" *Test ValidarTipo: ");
    String tipo = anillo.getTipoAnillos().getValtipdescri();
    System.out.print(" Tipo de anillos: " +tipo);
    Assert.assertEquals(validador.estaEnCatalogo(tipo,"TD"),false);
  }

  @Test
  public void testValidarMatFab()
  {
    System.out.println(" *Test ValidarMaterialFabricacion: ");
    String matFab = anillo.getMaterialFabricacion().getValtipdescri();
    System.out.print(" Material Fabricacion: " +matFab);
    Assert.assertEquals(validador.estaEnCatalogo(matFab, "TE"), false);
  }

  @Test
  public void testValidarAcab()
  {
    System.out.println(" *Test ValidarAcabado: ");
    String acabado = anillo.getAcabado().getValtipdescri();
    System.out.print(" Acabado anillos: " +acabado);
    Assert.assertEquals(validador.noEstaEnCatalogo(acabado,"TF"),true);
  }

  @Test
  public void testValidarUso()
  {
    System.out.println(" *Test ValidarUso: ");
    String uso = anillo.getUso().getValtipdescri();
    System.out.print(" Uso anillos: " + uso);
    Assert.assertEquals(validador.noEstaEnCatalogo(uso,"TG"),true);
  }

  @Test
  public void testValidarDimension()
  {
    System.out.println(" *Test ValidarDimension: ");
    System.out.print(" Dimension de anillos: " +anillo.getDimension().getValtipdescri());
    //Por mientras '0'
    Assert.assertEquals(validador.validarDimension(anillo).size(),0);
  }
}

