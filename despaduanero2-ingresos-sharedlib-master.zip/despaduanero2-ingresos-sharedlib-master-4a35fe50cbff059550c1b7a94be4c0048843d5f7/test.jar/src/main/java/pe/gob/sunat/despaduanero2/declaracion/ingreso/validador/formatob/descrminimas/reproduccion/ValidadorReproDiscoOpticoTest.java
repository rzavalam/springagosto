package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.reproduccion;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.reproduccion.model.ReproDiscoOptico;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorReproDiscoOpticoTest extends AbstractServiceTest{

  @Autowired
  @Qualifier("ValidadorReproDiscoOptico")
  private ValidadorReproDiscoOptico validador = new ValidadorReproDiscoOptico();
  private ReproDiscoOptico discosOpticos =  new ReproDiscoOptico();
  private Declaracion   declaracion = new Declaracion();

  @BeforeClass
  public void initData() throws ParseException{

    ReproDiscoOptico discosOptico = new ReproDiscoOptico();

    DatoDescrMinima tipo = new DatoDescrMinima();
    tipo.setValtipdescri("DVD");
    discosOptico.setTipoDisco(tipo);

    DatoDescrMinima longitud = new DatoDescrMinima();
    longitud.setValtipdescri("06C");
    discosOptico.setLongitudDiametro(longitud);

    DatoDescrMinima capacidad = new DatoDescrMinima();
    capacidad.setValtipdescri("40G");
    discosOptico.setCapacidadAlmacenamiento(capacidad);

    DatoDescrMinima tipoEmpaque = new DatoDescrMinima();
    tipoEmpaque.setValtipdescri("Tipo empaque");
    discosOptico.setTipoEmpaque(tipoEmpaque);

    DatoDescrMinima discosXEmpaque = new DatoDescrMinima();
    discosXEmpaque.setValtipdescri("Discos X Empaque");
    discosOptico.setDiscosXEmpaque(discosXEmpaque);

    DatoDescrMinima numeroEmpaques = new DatoDescrMinima();
    numeroEmpaques.setValtipdescri("Numero Empaques");
    discosOptico.setNumeroEmpaques(numeroEmpaques);

    DatoDescrMinima formato = new DatoDescrMinima();
    formato.setValtipdescri("");
    discosOptico.setFormato(formato);

    DUA dua = new DUA();
    declaracion.setDua(dua);

    this.discosOpticos = discosOptico;
  }

  @DataProvider (name="initData1")
  public Object[][] initData1() throws ParseException{

    ReproDiscoOptico reproAbstracts = new ReproDiscoOptico();

    DatoDescrMinima nombreCom = new DatoDescrMinima();
    nombreCom.setNumsecitem(1);
    nombreCom.setCodtipvalor("0");
    nombreCom.setCodtipdescr("DUC");
    nombreCom.setValtipdescri("DUC");
    reproAbstracts.setNombreComercial(nombreCom);


    Declaracion dua = new Declaracion();
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("U");
    item.setNumpartnandi(new Long(8521100000L));
    lstitem.add(item);
    factu.setListItems(lstitem);
    lstFactu.add(factu);
    dav.setListFacturas(lstFactu);
    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    //

    return new Object[][]{{reproAbstracts, dua}};
  }
  @Test (dataProvider="initData1")
  public void testValidarUnidadComercial(ReproDiscoOptico reproAbstracts, Declaracion dua){
    Assert.assertEquals(validador.validarUnidadComercial(reproAbstracts, dua).size(),0);
  }

  @Test (dataProvider="initData1")
  public void testValidarNombreComercial(ReproDiscoOptico reproAbstracts, Declaracion dua)
  {
    System.out.println(" *Test ValidarNombreComercial: ");
    System.out.println(" Nombre Comercial Reproduccion: " +reproAbstracts.getNombreComercial().getValtipdescri());
    Assert.assertEquals(validador.validarNombreComercial(reproAbstracts,dua).size(),0);
  }


  @Test
  public void testValidarTipoDisco()
  {
    String tipoDisco = discosOpticos.getTipoDisco().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(tipoDisco,"2O"),true);
  }

  @Test
  public void testValidarLongitudDisco()
  {
    String longitudDisco = discosOpticos.getLongitudDiametro().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(longitudDisco,"3O"),false);
  }

  @Test
  public void testValidarCapacidadDisco()
  {
    String capacidadDisco = discosOpticos.getCapacidadAlmacenamiento().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(capacidadDisco,"4O"),false);
  }
  @Test
  public void testValidarTipoEmpaqueDisco()
  {
    String tipoDisco = discosOpticos.getTipoEmpaque().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(tipoDisco, "502"), true);
  }

  @Test
  public void testValidarDiscoXEmpaque()
  {
    Assert.assertEquals(validador.validarDiscosXEmpaque(discosOpticos).size(), 0);
  }

  @Test
  public void testValidarNumeroEmpaque()
  {
    Assert.assertEquals(validador.validarNumeroEmpaques(discosOpticos).size(),0);
  }

  @Test
  public void testValidarFormatoDisco()
  {
    Assert.assertEquals(validador.validarFormato(this.discosOpticos).size(),1);
  }

}