package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.fomatob.descrminimas.sanitarios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioInodoro;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.sanitarios.ValidadorSanitarioInodoro;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorSanitarioInodoroTest extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorSanitarioInodoro")
  private ValidadorSanitarioInodoro validador;

  private SanitarioInodoro	sanitarioInodoro;

  @BeforeClass
  public void initData() throws Exception{
    System.out.println("LOAD TEST UNITARIOS ...");
    SanitarioInodoro sanitarioInodoro = new SanitarioInodoro();
    //NombreComercial
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    nombreComercial.setValtipdescri("INO"); // INO,CTK,LAV,FGD,PDL,SPL,BDT,URI,BÑA,ZZZ
    sanitarioInodoro.setNombreComercial(nombreComercial);
    //Tipo
    DatoDescrMinima tipo = new DatoDescrMinima();
    tipo.setValtipdescri("MMM"); //IOP,IDP,TTA,TFX
    sanitarioInodoro.setTipo(tipo);
    //Valvula
    DatoDescrMinima valvula = new DatoDescrMinima();
    valvula.setValtipdescri("VAS"); //VAS,VSF,SVL
    sanitarioInodoro.setValvula(valvula);
    //ConsumoAgua
    DatoDescrMinima consumoAgua = new DatoDescrMinima();
    consumoAgua.setValtipdescri("HHH"); //AEF,BCS,AHR
    sanitarioInodoro.setConsumoAgua(consumoAgua);
    //AroInodoro
    DatoDescrMinima aroInodoro = new DatoDescrMinima();
    aroInodoro.setValtipdescri("IAR"); //IAR,IAE,ZZZ
    sanitarioInodoro.setAroInodoro(aroInodoro);
    //Usuario
    DatoDescrMinima usuario = new DatoDescrMinima();
    usuario.setValtipdescri("IDS"); // IAD,ICH,IDS,INÑ
    sanitarioInodoro.setUsuario(usuario);
    //Accionamiento
    DatoDescrMinima accionamiento = new DatoDescrMinima();
    accionamiento.setValtipdescri("PLU"); //PLU,DPL,MNJ,CDN
    sanitarioInodoro.setAccionamiento(accionamiento);
    //Asiento
    DatoDescrMinima asiento = new DatoDescrMinima();
    asiento.setValtipdescri("SAS"); //ACN,ACA,SAS
    sanitarioInodoro.setAsiento(asiento);
    //MaterialAsiento
    DatoDescrMinima materialAsiento = new DatoDescrMinima();
    materialAsiento.setValtipdescri("MMX"); //PPL,MMX,MDR,ZZZ
    sanitarioInodoro.setMaterialAsiento(materialAsiento);

    this.sanitarioInodoro = sanitarioInodoro;
  }

  @Test
  public void testValidarAroInodoro(){
    System.out.println("Ingreso al Test -testValidarAroInodoro-");
    String aroInodoro = sanitarioInodoro.getAroInodoro().getValtipdescri();
    System.out.println("AroInodoro: " + aroInodoro);
    Assert.assertEquals(validador.estaEnCatalogo(aroInodoro,"427"),true);
  }

  @Test
  public void testValidarUsuario(){
    System.out.println("Ingreso al Test -testValidarUsuario-");
    String usuario = sanitarioInodoro.getUsuario().getValtipdescri();
    System.out.println("Usuario: " + usuario);
    Assert.assertEquals(validador.estaEnCatalogo(usuario,"428"),true);
  }

  @Test
  public void testValidarAccionamiento(){
    System.out.println("Ingreso al Test -testValidarAccionamiento-");
    String accionamiento = sanitarioInodoro.getAccionamiento().getValtipdescri();
    System.out.println("Accionamiento: " + accionamiento);
    Assert.assertEquals(validador.estaEnCatalogo(accionamiento,"429"),true);
  }

  @Test
  public void testValidarAsiento(){
    System.out.println("Ingreso al Test -testValidarAsiento-");
    String asiento = sanitarioInodoro.getAsiento().getValtipdescri();
    System.out.println("Asiento: " + asiento);
    Assert.assertEquals(validador.estaEnCatalogo(asiento,"431"),true);
  }

  @Test
  public void testValidarMaterialAsiento(){
    System.out.println("Ingreso al Test -testValidarMaterialAsiento-");
    String materialAsiento = sanitarioInodoro.getMaterialAsiento().getValtipdescri();
    System.out.println("MaterialAsiento: " + materialAsiento);
    Assert.assertEquals(validador.estaEnCatalogo(materialAsiento,"432"),true);
  }

  @Test
  public void testValidarTipo(){
    System.out.println("Ingreso al Test -testValidarTipo-");
    String nombreComercial = sanitarioInodoro.getNombreComercial().getValtipdescri();
    String tipo = sanitarioInodoro.getTipo().getValtipdescri();
    System.out.println("NombreComercial/Tipo: " + nombreComercial+"/"+tipo);
    Assert.assertEquals(validador.validartipo(sanitarioInodoro).size(),1);
  }

  @Test
  public void testValidarValvula(){
    System.out.println("Ingreso al Test -testValidarValvula-");
    String valvula = sanitarioInodoro.getValvula().getValtipdescri();
    System.out.println("Valvula: " + valvula);
    Assert.assertEquals(validador.validarValvula(sanitarioInodoro).size(),0);
  }

  @Test
  public void testValidarConsumoAgua(){
    System.out.println("Ingreso al Test -testValidarConsumoAgua-");
    String consumoAgua = sanitarioInodoro.getConsumoAgua().getValtipdescri();
    System.out.println("consumoAgua: " + consumoAgua);
    Assert.assertEquals(validador.validarConsumoAgua(sanitarioInodoro).size(),1);
  }

}
