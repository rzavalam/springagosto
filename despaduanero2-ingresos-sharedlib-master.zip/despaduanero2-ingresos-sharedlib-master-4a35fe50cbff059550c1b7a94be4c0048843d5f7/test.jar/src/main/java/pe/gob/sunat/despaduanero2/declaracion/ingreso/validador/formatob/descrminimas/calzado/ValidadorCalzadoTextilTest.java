package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.calzados.model.CalzadoTextil;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.calzados.ValidadorCalzadoTextil;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorCalzadoTextilTest extends AbstractServiceTest {

	  @Autowired
	  @Qualifier("ValidadorCalzadoTextil")
	  private ValidadorCalzadoTextil validador = new ValidadorCalzadoTextil();

	  private final static String TEXTO = "1";
	  private final static String CATALOGO = "0";

	 @DataProvider(name="initData103")
	  private Object[][] initData103(){
	    CalzadoTextil calzado = new CalzadoTextil();
	    DatoDescrMinima nombreComercial = new DatoDescrMinima();
	    DatoDescrMinima marcaComercial = new DatoDescrMinima();
	    DatoDescrMinima modelo         = new DatoDescrMinima();
	    DatoDescrMinima materialSuperior = new DatoDescrMinima();
	    DatoDescrMinima tipoTejido = new DatoDescrMinima();
	    DatoDescrMinima composicionTejido = new DatoDescrMinima();
	    DatoDescrMinima composicionSuela = new DatoDescrMinima();
	    DatoDescrMinima composicionForro = new DatoDescrMinima();
	    DatoDescrMinima usuarioCalzado = new DatoDescrMinima();
	    DatoDescrMinima tallaCalzado = new DatoDescrMinima();
	    DatoDescrMinima construccionCalzado = new DatoDescrMinima();
	    
  	    DatoItem item = new DatoItem();
	    item.setNumcorredoc(new Long(1));
	    item.setNumfact("1");
	    item.setNumsecitem(1);
	    item.setNumsecprove(1);
	    item.setNumpartnandi(new Long(6404190000L));
	    item.setCodunidcomer("2U");

	    nombreComercial.setCodtipvalor(CATALOGO);
	    nombreComercial.setCodtipdescr("CA0300");
	    nombreComercial.setValtipdescri("CDP");

	    marcaComercial.setCodtipvalor(TEXTO);
	    marcaComercial.setCodtipdescr("CA0301");
	    marcaComercial.setValtipdescri("ZARA");

	    modelo.setCodtipvalor(TEXTO);
	    modelo.setCodtipdescr("CA0302");
	    modelo.setValtipdescri("5519/282");

	    materialSuperior.setCodtipvalor(CATALOGO);
	    materialSuperior.setCodtipdescr("CA0303");
	    materialSuperior.setValtipdescri("PLA");

	    tipoTejido.setCodtipvalor(CATALOGO);
	    tipoTejido.setCodtipdescr("CA0304");
	    tipoTejido.setValtipdescri("TRA");
	    
	    composicionTejido.setCodtipvalor(CATALOGO);
	    composicionTejido.setCodtipdescr("CA0306");
	    composicionTejido.setValtipdescri("COT");
	    	    	    
	    composicionSuela.setCodtipvalor(CATALOGO);
	    composicionSuela.setCodtipdescr("CA0308");
	    composicionSuela.setValtipdescri("CAU");
	    
	    composicionForro.setCodtipvalor(CATALOGO);
	    composicionForro.setCodtipdescr("CA0309");
	    composicionForro.setValtipdescri("ALG");
	    
	    usuarioCalzado.setCodtipvalor(CATALOGO);
	    usuarioCalzado.setCodtipdescr("CA03010");
	    usuarioCalzado.setValtipdescri("CAB");
	    
	    tallaCalzado.setCodtipvalor(TEXTO);
	    tallaCalzado.setCodtipdescr("CA03011");
	    tallaCalzado.setValtipdescri("40000-44000");
	    
	    construccionCalzado.setCodtipvalor(CATALOGO);
	    construccionCalzado.setCodtipdescr("CA0312");
	    construccionCalzado.setValtipdescri("CEM");
	    
	    calzado.setNombreComercial(nombreComercial);
	    calzado.setMarcaComercial(marcaComercial);
	    calzado.setModelo(modelo);
	    calzado.setMaterialParteSuperior(materialSuperior);
	    calzado.setTipoTejido(tipoTejido);
	    calzado.setComposicionTejido(composicionTejido);
	    calzado.setComposicionDeLaSuela(composicionSuela);
	    calzado.setComposicionForro(composicionForro);
	    calzado.setUsuarioCalzado(usuarioCalzado);
	    calzado.setTallaCalzado(tallaCalzado);
	    calzado.setConstruccionCalzado(construccionCalzado);

	    return new Object[][]{{calzado, item}};
	  }
	 
	 @Test(dataProvider = "initData103")
	  public void validarNombreComercial103Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(object,item).size(), 2);
	  }
	 
	 @Test(dataProvider = "initData103")
	  public void validarModelo103Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarModelo(object).size(), 0);
	  }
	 	 
	 @Test(dataProvider = "initData103")
	  public void validarConstruccion103Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarConstruccion(object).size(), 0);
	  }
	 
	 @DataProvider(name="initData104")
	  private Object[][] initData104(){
	  CalzadoTextil calzado = new CalzadoTextil();
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo         = new DatoDescrMinima();
	  DatoDescrMinima materialSuperior = new DatoDescrMinima();
	  DatoDescrMinima tipoTejido = new DatoDescrMinima();
	  DatoDescrMinima composicionTejido = new DatoDescrMinima();
	  DatoDescrMinima composicionSuela = new DatoDescrMinima();
	  DatoDescrMinima composicionForro = new DatoDescrMinima();
	  DatoDescrMinima usuarioCalzado = new DatoDescrMinima();
	  DatoDescrMinima tallaCalzado = new DatoDescrMinima();
	  DatoDescrMinima construccionCalzado = new DatoDescrMinima();
	    
 	  DatoItem item = new DatoItem();
	  item.setNumcorredoc(new Long(1));
	  item.setNumfact("1");
	  item.setNumsecitem(1);
	  item.setNumsecprove(1);
	  item.setNumpartnandi(new Long(6404190000L));
	  item.setCodunidcomer("2U");

	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("CA0300");
	  nombreComercial.setValtipdescri("ALP");

	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("CA0301");
	  marcaComercial.setValtipdescri("Beira Rio");

	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("CA0302");
	  modelo.setValtipdescri("8109.309");

	  materialSuperior.setCodtipvalor(CATALOGO);
	  materialSuperior.setCodtipdescr("CA0303");
	  materialSuperior.setValtipdescri("TEX");

	  tipoTejido.setCodtipvalor(CATALOGO);
	  tipoTejido.setCodtipdescr("CA0304");
	  tipoTejido.setValtipdescri("TPO");
	    
	  composicionTejido.setCodtipvalor(CATALOGO);
	  composicionTejido.setCodtipdescr("CA0306");
	  composicionTejido.setValtipdescri("PES");
	    	    	    
	  composicionSuela.setCodtipvalor(CATALOGO);
	  composicionSuela.setCodtipdescr("CA0308");
	  composicionSuela.setValtipdescri("CAU");
	    
	  usuarioCalzado.setCodtipvalor(CATALOGO);
	  usuarioCalzado.setCodtipdescr("CA03010");
	  usuarioCalzado.setValtipdescri("DAM");
	    
	  tallaCalzado.setCodtipvalor(TEXTO);
	  tallaCalzado.setCodtipdescr("CA03011");
	  tallaCalzado.setValtipdescri("33000-40000");
	    
	  construccionCalzado.setCodtipvalor(CATALOGO);
	  construccionCalzado.setCodtipdescr("CA0312");
	  construccionCalzado.setValtipdescri("CEM");
	    
	  calzado.setNombreComercial(nombreComercial);
	  calzado.setMarcaComercial(marcaComercial);
	  calzado.setModelo(modelo);
	  calzado.setMaterialParteSuperior(materialSuperior);
	  calzado.setTipoTejido(tipoTejido);
	  calzado.setComposicionTejido(composicionTejido);
	  calzado.setComposicionDeLaSuela(composicionSuela);
	  calzado.setComposicionForro(composicionForro);
	  calzado.setUsuarioCalzado(usuarioCalzado);
	  calzado.setTallaCalzado(tallaCalzado);
	  calzado.setConstruccionCalzado(construccionCalzado);

	  return new Object[][]{{calzado, item}};
	}
	 
	 @Test(dataProvider = "initData104")
	  public void validarNombreComercial104Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(object,item).size(), 0);
	  }
	 
	 @Test(dataProvider = "initData104")
	  public void validarModelo104Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarModelo(object).size(), 0);
	  }
	 
	 @Test(dataProvider = "initData104")
	  public void validarConstruccion104Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarConstruccion(object).size(), 0);
	  }
	 
	 @DataProvider(name="initData105")
	  private Object[][] initData105(){
	  CalzadoTextil calzado = new CalzadoTextil();
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo         = new DatoDescrMinima();
	  DatoDescrMinima materialSuperior = new DatoDescrMinima();
	  DatoDescrMinima tipoTejido = new DatoDescrMinima();
	  DatoDescrMinima composicionTejido = new DatoDescrMinima();
	  DatoDescrMinima composicionSuela = new DatoDescrMinima();
	  DatoDescrMinima composicionForro = new DatoDescrMinima();
	  DatoDescrMinima usuarioCalzado = new DatoDescrMinima();
	  DatoDescrMinima tallaCalzado = new DatoDescrMinima();
	  DatoDescrMinima construccionCalzado = new DatoDescrMinima();
	    
	  DatoItem item = new DatoItem();
	  item.setNumcorredoc(new Long(1));
	  item.setNumfact("1");
	  item.setNumsecitem(1);
	  item.setNumsecprove(1);
	  item.setNumpartnandi(new Long(6404190000L));
	  item.setCodunidcomer("2U");

	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("CA0300");
	  nombreComercial.setValtipdescri("ZAP");

	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("CA0301");
	  marcaComercial.setValtipdescri("CLASSICA");

	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("CA0302");
	  modelo.setValtipdescri("ML8032H");

	  materialSuperior.setCodtipvalor(CATALOGO);
	  materialSuperior.setCodtipdescr("CA0303");
	  materialSuperior.setValtipdescri("TEX");

	  tipoTejido.setCodtipvalor(CATALOGO);
	  tipoTejido.setCodtipdescr("CA0304");
	  tipoTejido.setValtipdescri("TEL");
	    
	  composicionTejido.setCodtipvalor(CATALOGO);
	  composicionTejido.setCodtipdescr("CA0306");
	  composicionTejido.setValtipdescri("SED");
	    	    	    
	  composicionSuela.setCodtipvalor(CATALOGO);
	  composicionSuela.setCodtipdescr("CA0308");
	  composicionSuela.setValtipdescri("CAU");
	  
	  composicionForro.setCodtipvalor(CATALOGO);
	  composicionForro.setCodtipdescr("CA0308");
	  composicionForro.setValtipdescri("ALG");
	    
	  usuarioCalzado.setCodtipvalor(CATALOGO);
	  usuarioCalzado.setCodtipdescr("CA03010");
	  usuarioCalzado.setValtipdescri("CAB");
	    
	  tallaCalzado.setCodtipvalor(TEXTO);
	  tallaCalzado.setCodtipdescr("CA03011");
	  tallaCalzado.setValtipdescri("40000-44000");
	    
	  construccionCalzado.setCodtipvalor(CATALOGO);
	  construccionCalzado.setCodtipdescr("CA0312");
	  construccionCalzado.setValtipdescri("CEM");
	    
	  calzado.setNombreComercial(nombreComercial);
	  calzado.setMarcaComercial(marcaComercial);
	  calzado.setModelo(modelo);
	  calzado.setMaterialParteSuperior(materialSuperior);
	  calzado.setTipoTejido(tipoTejido);
	  calzado.setComposicionTejido(composicionTejido);
	  calzado.setComposicionDeLaSuela(composicionSuela);
	  calzado.setComposicionForro(composicionForro);
	  calzado.setUsuarioCalzado(usuarioCalzado);
	  calzado.setTallaCalzado(tallaCalzado);
	  calzado.setConstruccionCalzado(construccionCalzado);

	  return new Object[][]{{calzado, item}};
	}
	 
	 @Test(dataProvider = "initData105")
	  public void validarNombreComercial105Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(object,item).size(), 0);
	  }
	 
	 @Test(dataProvider = "initData105")
	  public void validarModelo105Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarModelo(object).size(), 0);
	  }
	 
	 @Test(dataProvider = "initData105")
	  public void validarConstruccion105Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarConstruccion(object).size(), 0);
	  }
	 
	 @DataProvider(name="initData106")
	  private Object[][] initData106(){
	  CalzadoTextil calzado = new CalzadoTextil();
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo         = new DatoDescrMinima();
	  DatoDescrMinima materialSuperior = new DatoDescrMinima();
	  DatoDescrMinima tipoTejido = new DatoDescrMinima();
	  DatoDescrMinima composicionTejido = new DatoDescrMinima();
	  DatoDescrMinima composicionSuela = new DatoDescrMinima();
	  DatoDescrMinima composicionForro = new DatoDescrMinima();
	  DatoDescrMinima usuarioCalzado = new DatoDescrMinima();
	  DatoDescrMinima tallaCalzado = new DatoDescrMinima();
	  DatoDescrMinima construccionCalzado = new DatoDescrMinima();
	    
	  DatoItem item = new DatoItem();
	  item.setNumcorredoc(new Long(1));
	  item.setNumfact("1");
	  item.setNumsecitem(1);
	  item.setNumsecprove(1);
	  item.setNumpartnandi(new Long(6404190000L));
	  item.setCodunidcomer("2U");

	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("CA0300");
	  nombreComercial.setValtipdescri("ZAP");

	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("CA0301");
	  marcaComercial.setValtipdescri("NEW ORO");

	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("CA0302");
	  modelo.setValtipdescri("VH1208C");

	  materialSuperior.setCodtipvalor(CATALOGO);
	  materialSuperior.setCodtipdescr("CA0303");
	  materialSuperior.setValtipdescri("TEX");

	  tipoTejido.setCodtipvalor(CATALOGO);
	  tipoTejido.setCodtipdescr("CA0304");
	  tipoTejido.setValtipdescri("OVI");
	    
	  composicionTejido.setCodtipvalor(CATALOGO);
	  composicionTejido.setCodtipdescr("CA0306");
	  composicionTejido.setValtipdescri("COT");
	    	    	    
	  composicionSuela.setCodtipvalor(CATALOGO);
	  composicionSuela.setCodtipdescr("CA0308");
	  composicionSuela.setValtipdescri("CAU");
	  
	  composicionForro.setCodtipvalor(CATALOGO);
	  composicionForro.setCodtipdescr("CA0308");
	  composicionForro.setValtipdescri("ALG");
	    
	  usuarioCalzado.setCodtipvalor(CATALOGO);
	  usuarioCalzado.setCodtipdescr("CA03010");
	  usuarioCalzado.setValtipdescri("CAB");
	    
	  tallaCalzado.setCodtipvalor(TEXTO);
	  tallaCalzado.setCodtipdescr("CA03011");
	  tallaCalzado.setValtipdescri("40000-44000");
	    
	  construccionCalzado.setCodtipvalor(CATALOGO);
	  construccionCalzado.setCodtipdescr("CA0312");
	  construccionCalzado.setValtipdescri("CEM");
	    
	  calzado.setNombreComercial(nombreComercial);
	  calzado.setMarcaComercial(marcaComercial);
	  calzado.setModelo(modelo);
	  calzado.setMaterialParteSuperior(materialSuperior);
	  calzado.setTipoTejido(tipoTejido);
	  calzado.setComposicionTejido(composicionTejido);
	  calzado.setComposicionDeLaSuela(composicionSuela);
	  calzado.setComposicionForro(composicionForro);
	  calzado.setUsuarioCalzado(usuarioCalzado);
	  calzado.setTallaCalzado(tallaCalzado);
	  calzado.setConstruccionCalzado(construccionCalzado);
	  calzado.setCompoMaterialTejido1erComp(new DatoDescrMinima());
	  calzado.setCompoMaterialTejidoPorcen1erComp(new DatoDescrMinima());

	  return new Object[][]{{calzado, item}};
	}
	 
	 @Test(dataProvider = "initData106")
	  public void validarNombreComercial106Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(object,item).size(), 0);
	  }
	 
	 @Test(dataProvider = "initData106")
	  public void validarModelo106Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarModelo(object).size(), 0);
	  }
	 
	 @Test(dataProvider = "initData106")
	  public void validarConstruccion106Test(ModelAbstract object, DatoItem item){
	    Assert.assertEquals(validador.validarConstruccion(object).size(), 0);
	  }
}
