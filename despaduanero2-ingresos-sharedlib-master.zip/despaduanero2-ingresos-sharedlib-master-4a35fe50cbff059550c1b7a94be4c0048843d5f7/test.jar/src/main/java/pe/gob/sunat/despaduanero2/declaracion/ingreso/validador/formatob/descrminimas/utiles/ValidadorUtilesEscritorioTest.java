package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.utiles;

import java.util.ArrayList;

import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.utiles.model.UtilesEscritorio;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorUtilesEscritorioTest extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorUtilesEscritorio")
  private final ValidadorUtilesEscritorio validador = new ValidadorUtilesEscritorio();

  private static final String TEXTO = "1";
  private static final String CATALOGO = "0";

  //Cinta de Embalaje
  @DataProvider( name = "initDataInterAmericanService_179")
  private Object[][] initDataInterAmericanService_179(){
    UtilesEscritorio util           = new UtilesEscritorio();

    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modeloComercial = new DatoDescrMinima();
    DatoDescrMinima color           = new DatoDescrMinima();
    DatoDescrMinima acabado         = new DatoDescrMinima();
    DatoDescrMinima dimensiones     = new DatoDescrMinima();
    DatoDescrMinima pesoUnitario    = new DatoDescrMinima();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoDescrMinima composicion     = new DatoDescrMinima();
    DatoDescrMinima aplicacion      = new DatoDescrMinima();
    DatoItem item = new DatoItem();

    item.setNumpartnandi(new Long(39191000000L));

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0100");
    nombreComercial.setValtipdescri("011");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("UT0101");
    marcaComercial.setValtipdescri("Alteux");

    modeloComercial.setCodtipvalor(TEXTO);
    modeloComercial.setCodtipdescr("UT0102");
    modeloComercial.setValtipdescri("S/M");

    color.setCodtipvalor(CATALOGO);
    color.setCodtipdescr("UT0105");
    color.setValtipdescri("002");  // Ojo que en la especificación dice
    // Transparente

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("UT0107");
    acabado.setValtipdescri("003");

    dimensiones.setCodtipvalor(TEXTO);
    dimensiones.setCodtipdescr("UT0108");
    dimensiones.setValtipdescri("200.00m");

    pesoUnitario.setCodtipvalor(TEXTO);
    pesoUnitario.setCodtipdescr("UT0109");
    pesoUnitario.setValtipdescri("650g");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("UT0111");
    presentacion.setValtipdescri("004"); //Ojo que en la especificacion dice caja x 36 rollos, consultar como se manejara eso.

    composicion.setCodtipvalor(CATALOGO);
    composicion.setCodtipdescr("UT0103");
    composicion.setValtipdescri("013"); // En la especificacion indica: Materia
    // plástica: Polímero de propileno, que
    // no hay en la tabla.

    aplicacion.setCodtipvalor(CATALOGO);
    aplicacion.setCodtipdescr("UT0110");
    aplicacion.setValtipdescri("002"); //No hay la opcion Uso general, temporalmente se puso industrial

    util.setNombreComercial(nombreComercial);
    util.setMarcaComercial(marcaComercial);
    util.setModelo(modeloComercial);
    util.setColor(color);
    util.setAcabado(acabado);
    util.setDimensiones(dimensiones);
    util.setModoPresentacion(presentacion);
    util.setPrimerComponente(composicion);
    util.setUso(presentacion);

    return new Object[][]{{ util, item }};
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void nombreComercial_179Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarNombre(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void  marcaComercial_179Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarMarcaComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void modeloComercial_179Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarModeloComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void color_179Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarColor(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void acabado_179Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAcabado(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void dimensiones_179Test(ModelAbstract object, DatoItem item){
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31269",
    //          "Las dimensiones deben cumplir el formato 999.99mX999.99mmX999.99mm");
    //    lst.add(error);
    Assert.assertEquals(1, validador.validarDimensiones(object, item).size());
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void presentacion_179Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarPresentacion(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void composicion_179Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarComposicionMercancia(object, item));
  }

  @Test(dataProvider = "initDataInterAmericanService_179")
  public void aplicacion_179Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAplicacionUso(object));
  }

  @DataProvider( name="initDataInterAmericanService_180")
  private Object[][] initDataInterAmenricanService_180(){

    UtilesEscritorio util = new UtilesEscritorio();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modeloComercial = new DatoDescrMinima();
    DatoDescrMinima color           = new DatoDescrMinima();
    DatoDescrMinima descrColor      = new DatoDescrMinima();
    DatoDescrMinima acabado         = new DatoDescrMinima();
    DatoDescrMinima dimensiones     = new DatoDescrMinima();
    DatoDescrMinima pesoUnitario    = new DatoDescrMinima();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoDescrMinima composicion     = new DatoDescrMinima();
    DatoDescrMinima aplicacion      = new DatoDescrMinima();
    DatoItem item                   = new DatoItem();

    item.setCodunidcomer("SET");
    item.setNumpartnandi(new Long(32131010000L));

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0100");
    nombreComercial.setValtipdescri("049");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("UT0101");
    marcaComercial.setValtipdescri("Creativas");

    modeloComercial.setCodtipvalor(TEXTO);
    modeloComercial.setCodtipdescr("UT0102");
    modeloComercial.setValtipdescri("S/N");

    color.setCodtipvalor(CATALOGO);
    color.setCodtipdescr("UT0105");
    color.setValtipdescri("001");

    descrColor.setCodtipvalor(TEXTO);
    descrColor.setCodtipdescr("UT0106");
    descrColor.setValtipdescri("BLANCO");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("UT0107");
    acabado.setValtipdescri("001");

    dimensiones.setCodtipvalor(TEXTO);
    dimensiones.setCodtipdescr("UT0108");
    dimensiones.setValtipdescri("19X3.8X4.8");

    pesoUnitario.setCodtipvalor(TEXTO);
    pesoUnitario.setCodtipdescr("UT0109");
    pesoUnitario.setValtipdescri("0.421g");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("UT0111");
    presentacion.setValtipdescri("004");

    composicion.setCodtipvalor(CATALOGO);
    composicion.setCodtipdescr("UT0103");
    composicion.setValtipdescri("024"); //Ojo que realmente dice Resina Viniilica no Resinas melaminicas
    //LA especificacion de pruebas indica que debe ser el cod 028, pero ese cod no existe, consultar si hay que actualizar

    aplicacion.setCodtipvalor(CATALOGO);
    aplicacion.setCodtipdescr("UT0110");
    aplicacion.setValtipdescri("001");

    util.setNombreComercial(nombreComercial);
    util.setMarcaComercial(marcaComercial);
    util.setModelo(modeloComercial);
    util.setColor(color);
    util.setDescripcionColor(descrColor);
    util.setAcabado(acabado);
    util.setDimensiones(dimensiones);
    util.setModoPresentacion(presentacion);
    util.setPrimerComponente(composicion);
    util.setUso(aplicacion);

    return new Object[][]{{ util, item}};
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void nombreComercial_180Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarNombre(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void  marcaComercial_180Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarMarcaComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void modeloComercial_180Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarModeloComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void color_180Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarColor(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void acabado_180Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAcabado(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void dimensiones_180Test(ModelAbstract object, DatoItem item){
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31203",
    //        "Mensaje: Las dimensiones deben cumplir el formato 999.99mmX999.99mmX999.99mm");
    //    lst.add(error);
    Assert.assertEquals(1, validador.validarDimensiones(object, item).size());
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void presentacion_180Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarPresentacion(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void composicion_180Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarComposicionMercancia(object, item));
  }

  @Test(dataProvider = "initDataInterAmericanService_180")
  public void aplicacion_180Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAplicacionUso(object));
  }

  @DataProvider (name = "initDataInterAmericanService_182")
  private Object[][] initDataInterAmericanService_182(){
    DatoItem item                   = new DatoItem();
    UtilesEscritorio util           = new UtilesEscritorio();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modeloComercial = new DatoDescrMinima();
    DatoDescrMinima color           = new DatoDescrMinima();
    DatoDescrMinima descrColor      = new DatoDescrMinima();
    DatoDescrMinima acabado         = new DatoDescrMinima();
    DatoDescrMinima dimensiones     = new DatoDescrMinima();
    DatoDescrMinima volumenUnitario = new DatoDescrMinima();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoDescrMinima composicion     = new DatoDescrMinima();
    DatoDescrMinima uso             = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0100");
    nombreComercial.setValtipdescri("023");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("UT0101");
    marcaComercial.setValtipdescri("Super Glub");

    modeloComercial.setCodtipvalor(TEXTO);
    modeloComercial.setCodtipdescr("UT0102");
    modeloComercial.setValtipdescri("S/M");

    color.setCodtipvalor(CATALOGO);
    color.setCodtipdescr("UT0105");
    color.setValtipdescri("001");

    descrColor.setCodtipvalor(TEXTO);
    descrColor.setCodtipdescr("UT0106");
    descrColor.setValtipdescri("001");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("UT0107");
    acabado.setValtipdescri("");

    dimensiones.setCodtipvalor(TEXTO);
    dimensiones.setCodtipdescr("UT0108");
    dimensiones.setValtipdescri("105 X 25 X 25");

    volumenUnitario.setCodtipvalor(TEXTO);
    volumenUnitario.setCodtipdescr("UT0109");
    volumenUnitario.setValtipdescri("58.1");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("UT0111");
    presentacion.setValtipdescri("005");

    composicion.setCodtipvalor(TEXTO);
    composicion.setCodtipdescr("UT0103");
    composicion.setValtipdescri("Polipropileno"); // No hay polipropileno, se
    // puso otros

    uso.setCodtipvalor(CATALOGO);
    uso.setCodtipdescr("UT0110");
    uso.setValtipdescri("001");

    item.setNumpartnandi(new Long(35061000000L));

    util.setNombreComercial(nombreComercial);
    util.setMarcaComercial(marcaComercial);
    util.setModelo(modeloComercial);
    util.setColor(color);
    util.setDescripcionColor(descrColor);
    util.setAcabado(acabado);
    util.setDimensiones(dimensiones);
    util.setModoPresentacion(presentacion);
    util.setPrimerComponente(composicion);
    util.setUso(uso);

    return new Object[][]{{ util, item }};
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void nombreComercial_182Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarNombre(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void  marcaComercial_182Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarMarcaComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void modeloComercial_182Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarModeloComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void color_182Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarColor(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void acabado_182Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAcabado(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void dimensiones_182Test(ModelAbstract object, DatoItem item){
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31203",
    //        "Mensaje: Las dimensiones deben cumplir el formato 999.99mmX999.99mmX999.99mm");
    //    lst.add(error);
    Assert.assertEquals(1, validador.validarDimensiones(object, item).size());
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void presentacion_182Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarPresentacion(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void composicion_182Test(ModelAbstract object, DatoItem item){
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31195",
    // "Mensaje: Código del componente declarado no corresponde al catálogo");
    //    lst.add(error);
    Assert.assertEquals(0, validador.validarComposicionMercancia(object, item).size());
  }

  @Test(dataProvider = "initDataInterAmericanService_182")
  public void aplicacion_182Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAplicacionUso(object));
  }

  @DataProvider (name = "initDataInterAmericanService_184")
  private Object[][] initDataInterAmericanService_184(){
    UtilesEscritorio util = new UtilesEscritorio();
    DatoDescrMinima nombreComercial   = new DatoDescrMinima();
    DatoDescrMinima marcaComercial    = new DatoDescrMinima();
    DatoDescrMinima modeloComercial   = new DatoDescrMinima();
    DatoDescrMinima color             = new DatoDescrMinima();
    DatoDescrMinima descrColor        = new DatoDescrMinima();
    DatoDescrMinima accesorios        = new DatoDescrMinima();
    DatoDescrMinima dimensiones       = new DatoDescrMinima();
    DatoDescrMinima pesoUnitario      = new DatoDescrMinima();
    DatoDescrMinima presentacion      = new DatoDescrMinima();
    DatoDescrMinima composicion       = new DatoDescrMinima();
    DatoDescrMinima uso               = new DatoDescrMinima();
    DatoItem item                     = new DatoItem();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0100");
    nombreComercial.setValtipdescri("021");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("UT0101");
    marcaComercial.setValtipdescri("Plastic");

    modeloComercial.setCodtipvalor(TEXTO);
    modeloComercial.setCodtipdescr("UT0102");
    modeloComercial.setValtipdescri("3BMT");

    color.setCodtipvalor(CATALOGO);
    color.setCodtipdescr("UT0105");
    color.setValtipdescri("001");

    descrColor.setCodtipvalor(TEXTO);
    descrColor.setCodtipdescr("UT0106");
    descrColor.setValtipdescri("NEgro");

    // Ojo los accesorios no se especifican para Utiles de Escritorio,
    //se especifican para utiles Otros, pero no esta dentro de esa categoria
    accesorios.setCodtipvalor(CATALOGO);
    accesorios.setCodtipdescr("UT0218");
    accesorios.setValtipdescri("");

    dimensiones.setCodtipvalor(TEXTO);
    dimensiones.setCodtipdescr("UT0108");
    dimensiones.setValtipdescri("210 X 297");

    pesoUnitario.setCodtipvalor(TEXTO);
    pesoUnitario.setCodtipdescr("UT0109");
    pesoUnitario.setValtipdescri("1");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("UT0111");
    presentacion.setValtipdescri("003");

    composicion.setCodtipvalor(CATALOGO);
    composicion.setCodtipdescr("UT0103");
    composicion.setValtipdescri("017");

    uso.setCodtipvalor(CATALOGO);
    uso.setCodtipdescr("UT0110");
    uso.setValtipdescri("001");

    item.setNumpartnandi(new Long(39261000000L));

    util.setNombreComercial(nombreComercial);
    util.setMarcaComercial(marcaComercial);
    util.setModelo(modeloComercial);
    util.setColor(color);
    util.setDescripcionColor(descrColor);
    util.setDimensiones(dimensiones);
    util.setModoPresentacion(presentacion);
    util.setPrimerComponente(composicion);
    util.setUso(uso);

    return new Object[][]{{ util, item }};
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void nombreComercial_184Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarNombre(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void  marcaComercial_184Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarMarcaComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void modeloComercial_184Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarModeloComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void color_184Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarColor(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void acabado_184Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAcabado(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void dimensiones_184Test(ModelAbstract object, DatoItem item){
    //    List<ErrorDescrMinima> lst  =  new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31203",
    //        "Mensaje: Las dimensiones deben cumplir el formato 999.99mmX999.99mmX999.99mm");
    //    lst.add(error);
    Assert.assertEquals(1, validador.validarDimensiones(object, item).size());
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void presentacion_184Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarPresentacion(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void composicion_184Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarComposicionMercancia(object, item));
  }

  @Test(dataProvider = "initDataInterAmericanService_184")
  public void aplicacion_184Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAplicacionUso(object));
  }

  @DataProvider(
                name = "initDataValidarUnidadComercialInvalido")
  private Object[][] initDataValidarUnidadComercialInvalido() {
    UtilesEscritorio utiles = new UtilesEscritorio();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    nombreComercial.setNumcorredoc(new Long(1));
    // nombreComercial.setNumfact("1");
    nombreComercial.setNumsecfact(1);
    nombreComercial.setNumsecitem(1);
    nombreComercial.setNumsecprove(1);
    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("Valor");

    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("NI SET NI U");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    utiles.setNombreComercial(nombreComercial);

    return new Object[][] { { utiles, dua } };
  }

  @Test(
        dataProvider = "initDataValidarUnidadComercialInvalido")
  public void validarUnidadComercialInvalidoTest(ModelAbstract objeto,
                                                 Declaracion dua) {
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0); 
    Assert.assertEquals(1, validador.validarUnidadComercial(objeto, item).size());
  }

  @DataProvider(
                name = "initDataValidarUnidadComercialUnidad")
  private Object[][] initDataValidarUnidadComercialUnidad() {
    UtilesEscritorio utiles = new UtilesEscritorio();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    nombreComercial.setNumcorredoc(new Long(1));
    // nombreComercial.setNumfact("1");
    nombreComercial.setNumsecfact(1);
    nombreComercial.setNumsecitem(1);
    nombreComercial.setNumsecprove(1);
    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("");
    nombreComercial.setValtipdescri("");

    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("U");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    utiles.setNombreComercial(nombreComercial);

    return new Object[][] { { utiles, dua } };
  }

  @Test(
        dataProvider = "initDataValidarUnidadComercialUnidad")
  public void validarUnidadComercialUnidadTest(ModelAbstract objeto,
                                               Declaracion dua) {
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarUnidadComercial(objeto, item));
  }

  @DataProvider(
                name = "initDataValidarUnidadComercialJuego")
  private Object[][] initDataValidarUnidadComercialJuego() {
    UtilesEscritorio utiles = new UtilesEscritorio();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    nombreComercial.setNumcorredoc(new Long(1));
    // nombreComercial.setNumfact("1");
    nombreComercial.setNumsecfact(1);
    nombreComercial.setNumsecitem(1);
    nombreComercial.setNumsecprove(1);

    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("SET");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    utiles.setNombreComercial(nombreComercial);

    return new Object[][] { { utiles, dua } };
  }

  @Test(
        dataProvider = "initDataValidarUnidadComercialJuego")
  public void validarUnidadComercialJuegoTest(ModelAbstract objeto,
                                              Declaracion dua) {
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarUnidadComercial(objeto, item));
  }

  @DataProvider(
                name = "initDataValidar1raComposicion")
  private Object[][] initDataValidar1raComposicion() {
    UtilesEscritorio utiles          = new UtilesEscritorio();
    DatoDescrMinima primerComponente = new DatoDescrMinima();
    DatoItem item                    = new DatoItem();

    primerComponente.setCodtipvalor(CATALOGO);
    primerComponente.setCodtipdescr("UT0103");
    primerComponente.setValtipdescri("009");

    item.setNumpartnandi(new Long(1));

    utiles.setPrimerComponente(primerComponente);

    return new Object[][] { { utiles, item } };
  }

  @Test(
        dataProvider = "initDataValidar1raComposicion")
  public void validar1raComposicionTest(ModelAbstract objeto, DatoItem item) {
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarComposicionMercancia(objeto, item));
  }

  @DataProvider(
                name = "initDataValidar2daComposicionSP_1")
  private Object[][] initDataValidar2daComposicionSP_1() {
    UtilesEscritorio utiles           = new UtilesEscritorio();
    DatoDescrMinima primerComponente  = new DatoDescrMinima();
    DatoDescrMinima segundoComponente = new DatoDescrMinima();
    DatoItem item                     = new DatoItem();

    primerComponente.setCodtipvalor(CATALOGO);
    primerComponente.setCodtipdescr("UT0103");
    primerComponente.setValtipdescri("009");

    segundoComponente.setCodtipvalor(CATALOGO);
    segundoComponente.setCodtipdescr("UT0104");
    segundoComponente.setValtipdescri("001");

    item.setNumpartnandi(new Long(32131010000L));

    utiles.setPrimerComponente(primerComponente);
    utiles.setSegundoComponente(segundoComponente);

    return new Object[][] { { utiles, item } };
  }

  @Test(
        dataProvider = "initDataValidar2daComposicionSP_1")
  public void validar2daComposicionSP_1Test(ModelAbstract objeto, DatoItem item) {
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarComposicionMercancia(objeto, item));
  }

  @DataProvider(
                name = "initDataValidar2daComposicionSP_2")
  private Object[][] initDataValidar2daComposicionSP_2() {
    UtilesEscritorio utiles           = new UtilesEscritorio();
    DatoDescrMinima primerComponente  = new DatoDescrMinima();
    DatoDescrMinima segundoComponente = new DatoDescrMinima();
    DatoItem item                     = new DatoItem();

    primerComponente.setCodtipvalor(CATALOGO);
    primerComponente.setCodtipdescr("UT0103");
    primerComponente.setValtipdescri("009");

    item.setNumpartnandi(new Long(96084000000L));

    utiles.setPrimerComponente(primerComponente);
    utiles.setSegundoComponente(segundoComponente);

    return new Object[][] { { utiles , item } };
  }

  /*
   * Consultar que ocurre cuando se envia una subpartida incorrecta o ningun
   * codigo con la subpartida del array 1
   */
  @Test(
        dataProvider = "initDataValidar2daComposicionSP_2")
  public void validar2daComposicionSP_2Test(ModelAbstract objeto,
                                            DatoItem item) {
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarComposicionMercancia(objeto, item));
  }

  @DataProvider(
                name = "initDataValidarColorSinDescripcion")
  private Object[][] initDataValidarColorSinDescripcion() {
    UtilesEscritorio utiles = new UtilesEscritorio();
    DatoDescrMinima color = new DatoDescrMinima();
    DatoDescrMinima descrColor = new DatoDescrMinima();

    color.setCodtipvalor(CATALOGO);
    color.setCodtipdescr("UT0105");
    color.setValtipdescri("001");

    utiles.setColor(color);
    utiles.setDescripcionColor(descrColor);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarColorSinDescripcion")
  public void validarColorSinDescripcionTest(ModelAbstract objeto) {
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima(
    //        "31200",
    // "Mensaje: Descripción del color del producto debe ser " +
    //        "mayor o igual a 3 caracteres");
    //    lst.add(error);
    Assert.assertEquals(1, validador.validarColor(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarColor")
  private Object[][] initDataValidarColor() {
    UtilesEscritorio utiles = new UtilesEscritorio();
    DatoDescrMinima color = new DatoDescrMinima();

    color.setCodtipvalor(CATALOGO);
    color.setCodtipdescr("UT0105");
    color.setValtipdescri("002");

    utiles.setColor(color);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarColor")
  public void validarColorTest(ModelAbstract objeto) {
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(), validador.validarColor(objeto));
  }

  /*
   * validarDimensionesUtiles
   */

  @DataProvider(
                name = "initDataValidarDimensionesUtilesNoSP_3919Invalido")
  private Object[][] initDataValidarDimensionesUtilesNoSP_3919Invalido() {
    UtilesEscritorio utiles   = new UtilesEscritorio();
    DatoDescrMinima dimension = new DatoDescrMinima();
    DatoItem item             = new DatoItem();

    dimension.setCodtipvalor(TEXTO);
    dimension.setCodtipdescr("UT0108");
    dimension.setValtipdescri("9.6gr/63.54698kgr/100mm");

    item.setNumpartnandi(new Long(1));

    utiles.setDimensiones(dimension);

    return new Object[][] { { utiles, item } };
  }

  @Test(
        dataProvider = "initDataValidarDimensionesUtilesNoSP_3919Invalido")
  public void validarDimensionesUtilesNoSP_3919InvalidoTest(ModelAbstract objeto,
                                                            DatoItem item) {
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31203",
    //        "Mensaje: Las dimensiones deben cumplir el formato " +
    //        "999.99mmX999.99mmX999.99mm");
    //    lst.add(error);
    Assert.assertEquals(1, validador.validarDimensiones(objeto, item).size());
  }

  @DataProvider(
                name = "initDataValidarDimensionesUtilesSP_3919Invalido")
  private Object[][] initDataValidarDimensionesUtilesSP_3919Invalido() {
    UtilesEscritorio utiles   = new UtilesEscritorio();
    DatoDescrMinima dimension = new DatoDescrMinima();
    DatoItem item             = new DatoItem();


    dimension.setCodtipvalor(TEXTO);
    dimension.setCodtipdescr("UT0108");
    dimension.setValtipdescri("9.60mmX63.54mmX100.00mm");

    item.setNumpartnandi(new Long(39191000000L));

    utiles.setDimensiones(dimension);

    return new Object[][] { { utiles, item } };
  }

  @Test(
        dataProvider = "initDataValidarDimensionesUtilesSP_3919Invalido")
  public void validarDimensionesUtilesSP_3919InvalidoTest(ModelAbstract objeto,
                                                          DatoItem item) {
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31269",
    //        "Mensaje: Las dimensiones deben cumplir el formato " +
    //        "999.99mX999.99mmX999.99mm");
    //    lst.add(error);
    Assert
    .assertEquals(1, validador.validarDimensiones(objeto, item).size());
  }

  @DataProvider(
                name = "initDataValidarPiezas")
  private Object[][] initDataValidarPiezas() {
    UtilesEscritorio utiles = new UtilesEscritorio();
    DatoDescrMinima piezas = new DatoDescrMinima();

    piezas.setCodtipvalor(TEXTO);
    piezas.setCodtipdescr("UT0112");
    piezas.setValtipdescri("10");

    utiles.setCantidadPiezas(piezas);
    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarPiezas")
  public void validarPiezasTest(ModelAbstract objeto) {
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarCantidadPiezas(objeto));
  }
}
