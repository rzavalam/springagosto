package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.ceramicos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.ceramicos.model.Ceramico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoSerieItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorCeramicoTest extends AbstractServiceTest{

  @Autowired
  @Qualifier("ValidadorCeramico")
  private ValidadorCeramico validador;

  private Ceramico          ceramicos;
  private Declaracion		declaracion;

  @BeforeClass
  public void initData() throws Exception{
	System.out.println("LOAD TEST UNITARIOS ...");

    Ceramico ceramico = new Ceramico();
    Declaracion declaracion = new Declaracion();
    //Unidad Comercial
    DatoDescrMinima unidComer = new DatoDescrMinima();
    unidComer.setValtipdescri("M2");
    //Nombre Producto
    DatoDescrMinima nombreCom = new DatoDescrMinima();
    nombreCom.setValtipdescri("BSE");//BSE,BES,LST,INT...(Catalogo 509)
    ceramico.setNombreComercial(nombreCom);
    //Marca Comercial
    DatoDescrMinima marcaCom = new DatoDescrMinima();
    marcaCom.setValtipdescri("Marca Comercial");
    ceramico.setMarcaComercial(marcaCom);
    //Modelo comercial
    DatoDescrMinima modeloCom = new DatoDescrMinima();
    modeloCom.setValtipdescri("Modelo Ceramicos");
    ceramico.setModelo(modeloCom);
    //Acabado 
    DatoDescrMinima acabadoCer = new DatoDescrMinima();
    acabadoCer.setValtipdescri("PEM");//PEM,CES,CBR,PRS...(Catalogo 449)
    ceramico.setAcabados(acabadoCer);
    //Materia Prima1
    DatoDescrMinima materiaPrima1 = new DatoDescrMinima();
    materiaPrima1.setValtipdescri("ARC");//ARC,FLD,MIC,CAL,BNT,TLC,CUZ (Catalogo 450)
    ceramico.setMateriaPrima1(materiaPrima1);
    //Materia Prima2
    DatoDescrMinima materiaPrima2 = new DatoDescrMinima();
    materiaPrima1.setValtipdescri("FLD");//ARC,FLD,MIC,CAL,BNT,TLC,CUZ (Catalogo 450)
    ceramico.setMateriaPrima2(materiaPrima2);
    //Materia Prima3
    DatoDescrMinima materiaPrima3 = new DatoDescrMinima();
    materiaPrima3.setValtipdescri("MIC");//ARC,FLD,MIC,CAL,BNT,TLC,CUZ (Catalogo 450)
    ceramico.setMateriaPrima3(materiaPrima3);
    //Materia Prima4
    DatoDescrMinima materiaPrima4 = new DatoDescrMinima();
    materiaPrima4.setValtipdescri("CAL");//ARC,FLD,MIC,CAL,BNT,TLC,CUZ (Catalogo 450)
    ceramico.setMateriaPrima4(materiaPrima4);
    //Materia Prima5
    DatoDescrMinima materiaPrima5 = new DatoDescrMinima();
    materiaPrima5.setValtipdescri("BNT");//ARC,FLD,MIC,CAL,BNT,TLC,CUZ (Catalogo 450)
    ceramico.setMateriaPrima5(materiaPrima5);    
    //Moldeo
    DatoDescrMinima moldeo = new DatoDescrMinima();
    moldeo.setValtipdescri("BEX");//BEX,BPN,BFO (Catalogo 451)
    ceramico.setMoldeo(moldeo);
    //Coccion
    DatoDescrMinima coccion = new DatoDescrMinima();
    coccion.setValtipdescri("BTF");//BMC,BBC,BTF (Catalogo 452)
    ceramico.setCoccion(coccion);
    //Uso
    DatoDescrMinima uso = new DatoDescrMinima();
    uso.setValtipdescri("PAV");//REV,PAV,ESP (Catalogo 453)
    ceramico.setUso(uso);
    //Color
    DatoDescrMinima color = new DatoDescrMinima();
    color.setValtipdescri("ALM");//BLN,GRS,VRD,CEL... (Catalogo 454)
    ceramico.setColor(color);
    //Dimensiones
    DatoDescrMinima dimension = new DatoDescrMinima();
    dimension.setValtipdescri("Grado Dimension Y Espesor");
    ceramico.setGradoDimensionYEspesor(dimension);
    //Capacidad Absorcion
    DatoDescrMinima capacidad = new DatoDescrMinima();
    capacidad.setValtipdescri("004");//001,002,003,004,005 (Catalogo 455)
    ceramico.setCapacidadAbsorcionAgua(capacidad);
    
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumsecitem(3);
    // Año fabrica
    item.setAnnfabrica("2013");
    //Estado mercancia
    item.setCodestamer("20");
    // paisOrigen
    item.setCodpaisorige("JP");  
    //Unidad comercial
    item.setCodunidcomer("SET"); 
    Long partida = 6907100000L;	
    item.setNumpartnandi(partida);
    Elementos<DatoSerieItem> listSerieItems = new Elementos<DatoSerieItem>();    
    DatoSerieItem datoSerieItem = new DatoSerieItem();
    datoSerieItem.setNumserie(123);
    listSerieItems.add(datoSerieItem);
    item.setListSerieItems(listSerieItems);
    lstitem.add(item);
    factu.setListItems(lstitem);
    lstFactu.add(factu);
    dav.setListFacturas(lstFactu);
    listDAVs.add(dav);
    declaracion.setListDAVs(listDAVs);    
    ceramico.setNumsecitem(3);
    
    DUA dua = new DUA();
    declaracion.setDua(dua);
    
    this.declaracion = declaracion;
    this.ceramicos = ceramico;
  }


  @Test(dataProvider = "initMethod")
  public void testValidarUnidadComercial(Ceramico ceramicos)
  {
   Assert.assertEquals(validador.validarUnidadComercialCeramicos(ceramicos,declaracion).size(),1);
  }
  
  @Test
  public void testValidarUnidadComercial(){
	  System.out.println("Ingreso al Test -testValidarUnidadComercial-");
	  Assert.assertEquals(validador.validarUnidadComercialCeramicos(ceramicos, declaracion).size(),0);
  }

  @Test
  public void testValidarNombreProductoCeramico(){
	  System.out.println("Ingreso al Test -testValidarNombreProductoCeramico-");
	  Assert.assertEquals(validador.validarNombreProductoCeramico(ceramicos, declaracion).size(),0);
  }

  @Test
  public void testValidarMarcaComercialCeramicos(){
	  System.out.println("Ingreso al Test -testValidarMarcaComercialCeramicos-");
	  Assert.assertEquals(validador.validarMarcaComercialCeramicos(ceramicos).size(),0);
  }


  @Test(dataProvider = "initMethod")
  public void testValidarModeloComercialCeramicos(Ceramico ceramicos)
  {
    Assert.assertEquals(validador.validarModeloComercialCeramicos(ceramicos).size(),1);
  }
  
  @Test
  public void testValidarModeloComercialCeramicos(){
	  System.out.println("Ingreso al Test -testValidarModeloComercialCeramicos-");
	  Assert.assertEquals(validador.validarModeloComercialCeramicos(ceramicos).size(),0);
  }


  @Test(dataProvider = "initMethod")
  public void testValidarAcabadoProductoCeramico(Ceramico ceramicos)
  {
    String acabados = ceramicos.getAcabados().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(acabados,"449"),false);
  }
  
  @Test
  public void testValidarAcabadoProductoCeramico(){
	  System.out.println("Ingreso al Test -testValidarAcabadoProductoCeramico-");
	  String acabados = ceramicos.getAcabados().getValtipdescri();
	  Assert.assertEquals(validador.noEstaEnCatalogo(acabados,"449"),false);
  }


  @Test
  public void testValidarMateriaPrimaCeramicos(){
	  System.out.println("Ingreso al Test -testValidarMateriaPrimaCeramicos-");
	  Assert.assertEquals(validador.validarMateriaPrimaCeramicos(ceramicos).size(),1);
  }


  @Test(dataProvider = "initMethod")
  public void testValidarMoldeoCeramico(Ceramico ceramicos)
  {
    String moldeo = ceramicos.getMoldeo().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(moldeo,"451"),false);
  }
  
  @Test
  public void testValidarMoldeoCeramico(){
	  System.out.println("Ingreso al Test -testValidarMoldeoCeramico-");
	  String moldeo = ceramicos.getMoldeo().getValtipdescri();
	  Assert.assertEquals(validador.noEstaEnCatalogo(moldeo,"451"),false);
  }


  @Test(dataProvider = "initMethod")
  public void testValidarCoccionCeramico(Ceramico ceramicos)
  {
    String coccion = ceramicos.getCoccion().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(coccion,"452"),false);
  }
  
  @Test
  public void testValidarCoccionCeramico(){
	  System.out.println("Ingreso al Test -testValidarCoccionCeramico-");
	  String coccion = ceramicos.getCoccion().getValtipdescri();
	  Assert.assertEquals(validador.noEstaEnCatalogo(coccion,"452"),false);
  }


  // Se agrego uso a ceramico.java en DECLARACION
  @Test(dataProvider = "initMethod")
  public void testValidarUsoCeramico(Ceramico ceramicos)
  {
    String uso = ceramicos.getUso().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(uso,"453"),false);
  }
  
  @Test
  public void testValidarUsoCeramico(){
	  System.out.println("Ingreso al Test -testValidarUsoCeramico-");
	  String uso = ceramicos.getUso().getValtipdescri();
	  Assert.assertEquals(validador.noEstaEnCatalogo(uso,"453"),false);
  }


  @Test(dataProvider = "initMethod")
  public void tsetValidarColorCeramico(Ceramico ceramicos)
  {
    String color = ceramicos.getColor().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(color,"454"),false);
  }
  
  @Test
  public void testValidarColorCeramico(){
	  System.out.println("Ingreso al Test -testValidarColorCeramico-");
	  String color = ceramicos.getColor().getValtipdescri();
	  Assert.assertEquals(validador.noEstaEnCatalogo(color,"454"),false);
  }


  @Test(dataProvider = "initMethod")
  public void testValidarDimensionesCeramicos(Ceramico ceramicos)
  {
    Assert.assertEquals(validador.validarDimensionesCeramicos(ceramicos).size(),1);
  }
  @Test
  public void testValidarDimensionesCeramicos(){
	  System.out.println("Ingreso al Test -testValidarDimensionesCeramicos-");
	  Assert.assertEquals(validador.validarDimensionesCeramicos(ceramicos).size(),0);
  }


  @Test(dataProvider = "initMethod")
  public void testValidarCapacidadAbsorcionCeramico(Ceramico ceramicos)
  {
    String capAbsorcion = ceramicos.getCapacidadAbsorcionAgua().getValtipdescri();
    Assert.assertEquals(validador.noEstaEnCatalogo(capAbsorcion,"455"),false);
  }
  
  @Test
  public void testValidarCapacidadAbsorcionCeramico(){
	  System.out.println("Ingreso al Test -testValidarCapacidadAbsorcionCeramico-");
	  String capAbsorcion = ceramicos.getCapacidadAbsorcionAgua().getValtipdescri();
	  Assert.assertEquals(validador.noEstaEnCatalogo(capAbsorcion,"455"),false);
  }
}