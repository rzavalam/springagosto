package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilTela;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

/*
 * @author lalberti
 */
public class ValidadorTextilTelaTest extends AbstractServiceTest {
  @Autowired
  @Qualifier("ValidadorTextilTela")
  private ValidadorTextilTela validador = new ValidadorTextilTela();
  private static final String CATALOGO = "0";
  private static final String TEXTO    = "1";

  @DataProvider( name = "initDataDyG66")
  private Object[][] initDataDyG65(){
    Declaracion dua                  = new Declaracion();
    TextilTela tela                  = new TextilTela();
    DatoDescrMinima nombreComercial  = new DatoDescrMinima();
    DatoDescrMinima marcaComercial   = new DatoDescrMinima();
    DatoDescrMinima modelo           = new DatoDescrMinima();
    DatoDescrMinima tipoTela         = new DatoDescrMinima();
    DatoDescrMinima comp1Valor       = new DatoDescrMinima();
    DatoDescrMinima comp1Porcentaje  = new DatoDescrMinima();
    DatoDescrMinima comp2Valor       = new DatoDescrMinima();
    DatoDescrMinima comp2Porcentaje  = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima primerAcabado    = new DatoDescrMinima();
    DatoDescrMinima gramaje          = new DatoDescrMinima();
    DatoDescrMinima anchoTela        = new DatoDescrMinima();
    DatoDescrMinima construccion     = new DatoDescrMinima();
    DatoDescrMinima fob              = new DatoDescrMinima();
    DatoDescrMinima uso              = new DatoDescrMinima();
    DatoDescrMinima materiaPlastica  = new DatoDescrMinima();
    DatoDescrMinima espesorMateria   = new DatoDescrMinima();

    tela.setNumcorredoc(new Long(1));
    tela.setNumsecfact(1);
    tela.setNumsecitem(1);
    tela.setNumsecprove(1);

    fob.setCodtipvalor(TEXTO);
    fob.setCodtipdescr("TE0322");
    fob.setValtipdescri("37297.92");

    nombreComercial.setCodtipvalor(TEXTO);
    nombreComercial.setCodtipdescr("TE0300");
    nombreComercial.setValtipdescri("Tela qqq");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("TE0301");
    marcaComercial.setValtipdescri("S/M");

    modelo.setCodtipvalor(TEXTO);
    modelo.setCodtipdescr("TE0302");
    modelo.setValtipdescri("S/M");

    tipoTela.setCodtipvalor(CATALOGO);
    tipoTela.setCodtipdescr("TE0303");
    tipoTela.setValtipdescri("PTO");

    comp1Valor.setCodtipvalor(CATALOGO);
    comp1Valor.setCodtipdescr("TE0304");
    comp1Valor.setValtipdescri("PES");

    comp1Porcentaje.setCodtipvalor(TEXTO);
    comp1Porcentaje.setCodtipdescr("TE0305");
    comp1Porcentaje.setValtipdescri("98");

    comp2Valor.setCodtipvalor(CATALOGO);
    comp2Valor.setCodtipdescr("TE0306");
    comp2Valor.setValtipdescri("PU");

    comp2Porcentaje.setCodtipvalor(TEXTO);
    comp2Porcentaje.setCodtipdescr("TE0307");
    comp2Porcentaje.setValtipdescri("200");

    gradoElaboracion.setCodtipvalor(CATALOGO);
    gradoElaboracion.setCodtipdescr("TE0308");
    gradoElaboracion.setCodtipdescr("TEN");

    primerAcabado.setCodtipvalor(CATALOGO);
    primerAcabado.setCodtipdescr("TE0309");
    primerAcabado.setValtipdescri("SAN");

    gramaje.setCodtipvalor(TEXTO);
    gramaje.setCodtipdescr("TE0313");
    gramaje.setValtipdescri("325.46");

    anchoTela.setCodtipvalor(TEXTO);
    anchoTela.setCodtipdescr("TE03014");
    anchoTela.setValtipdescri("0");

    construccion.setCodtipvalor(CATALOGO);
    construccion.setCodtipdescr("TE0320");
    construccion.setCodtipdescr("COM");

    uso.setCodtipvalor(TEXTO);
    uso.setCodtipdescr("TE315");
    uso.setValtipdescri("Industria Textil!!!#$##$");

    materiaPlastica.setCodtipvalor(CATALOGO);
    materiaPlastica.setCodtipvalor("TE0311");
    materiaPlastica.setValtipdescri("");

    espesorMateria.setCodtipdescr(TEXTO);
    espesorMateria.setCodtipdescr("TE0312");
    espesorMateria.setValtipdescri("dsfsdfdsfd");

    tela.setNombreComercial(nombreComercial);
    tela.setMarcaComercial(marcaComercial);
    tela.setModelo(modelo);
    tela.setTipoTela(tipoTela);
    tela.setCompoTela1erComp(comp1Valor);
    tela.setCompoTelaPorcen1erComp(comp1Porcentaje);
    tela.setCompoTela2doComp(comp2Valor);
    tela.setCompoTelaPorcen2doComp(comp2Porcentaje);
    tela.setConstruccionTela(construccion);
    tela.setGradoElaboracion(gradoElaboracion);
    tela.setPrimerAcabado(primerAcabado);
    tela.setGramaje(gramaje);
    tela.setAnchoTela(anchoTela);
    tela.setUsoTela(uso);
    tela.setRelacionFobUnitarioPesoNeto(fob);
    tela.setComposicionMateriaPlastica(materiaPlastica);
    tela.setEspesorMateriaPlastica(espesorMateria);

    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("M");
    item.setNumpartnandi(new Long(6001520000L));
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    return new Object[][]{{ tela,dua }};
  }

  @Test (dataProvider = "initDataDyG66")
  public void validarTipoTela(ModelAbstract object,
                              Declaracion dua){
    Assert.assertEquals(validador.validarTipoTela(object, dua).size(),0);
  }

  @Test (dataProvider = "initDataDyG66")
  public void validarComposicionMateriaPlastica(ModelAbstract object,
                                                Declaracion dua){
    Assert.assertEquals(validador.validarComposicionMateriaPlastica(object,dua).size(),0);
  }

  @Test (dataProvider = "initDataDyG66")
  public void validarEspesorMateriaPlastica(ModelAbstract object,
                                            Declaracion dua){
    Assert.assertEquals(validador.validarEspesorMateriaPlastica(object,dua).size(),0);
  }

  @Test (dataProvider = "initDataDyG66")
  public void validarUsoTela(ModelAbstract object,
                             Declaracion dua){
    Assert.assertEquals(validador.validarUsoTela(object).get(0).getCodigo(),"31323");
  }

  @Test (dataProvider = "initDataDyG66")
  public void validarAnchoTela(ModelAbstract object,
                               Declaracion dua){
    Assert.assertEquals(validador.validarAnchoTela(object).get(0).getCodigo(),"31372");
  }

  @Test (dataProvider = "initDataDyG66")
  public void validarSumaPorcentajes(ModelAbstract object,
                                     Declaracion dua){
    Assert.assertEquals(validador.ValidarSumaPorcenComp(object).get(0).getCodigo(),"31373");
  }

  @DataProvider(name = "initDataNK66")
  private Object[][] initDataNK66(){
    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("M");
    item.setNumpartnandi(new Long(5407520000L));
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    TextilTela tela = new TextilTela();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo          = new DatoDescrMinima();
    DatoDescrMinima tipoTela        = new DatoDescrMinima();
    DatoDescrMinima compo1erComponente = new DatoDescrMinima();
    DatoDescrMinima compo1erPorcentaje = new DatoDescrMinima();
    DatoDescrMinima compo2doComponente = new DatoDescrMinima();
    DatoDescrMinima compo2doPorcentaje = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima primerAcabado   = new DatoDescrMinima();
    DatoDescrMinima gramaje  = new DatoDescrMinima();
    DatoDescrMinima ancho = new DatoDescrMinima();
    DatoDescrMinima uso = new DatoDescrMinima();
    DatoDescrMinima espesor = new DatoDescrMinima();

    tela.setNumsecitem(1);
    tela.setNumcorredoc(new Long(1));
    tela.setNumsecprove(1);
    tela.setNumsecfact(1);

    nombreComercial.setCodtipvalor(TEXTO);
    nombreComercial.setCodtipdescr("");
    nombreComercial.setValtipdescri("");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("");
    marcaComercial.setValtipdescri("S/M");

    modelo.setCodtipvalor(TEXTO);
    modelo.setCodtipdescr("");
    modelo.setValtipdescri("S/M");

    tipoTela.setCodtipvalor(CATALOGO);
    tipoTela.setCodtipdescr("");
    tipoTela.setValtipdescri("PTO");

    compo1erComponente.setCodtipvalor(CATALOGO);
    compo1erComponente.setCodtipdescr("");
    compo1erComponente.setValtipdescri("PES");

    compo1erPorcentaje.setCodtipvalor(TEXTO);
    compo1erPorcentaje.setCodtipdescr("");
    compo1erPorcentaje.setValtipdescri("98");

    compo2doComponente.setCodtipvalor(CATALOGO);
    compo2doComponente.setCodtipdescr("");
    compo2doComponente.setValtipdescri("PU");

    compo2doPorcentaje.setCodtipvalor(TEXTO);
    compo2doPorcentaje.setCodtipdescr("");
    compo2doPorcentaje.setValtipdescri("2");
    gradoElaboracion.setCodtipvalor(CATALOGO);
    gradoElaboracion.setCodtipdescr("");
    gradoElaboracion.setValtipdescri("TEN");

    primerAcabado.setCodtipvalor(CATALOGO);
    primerAcabado.setCodtipdescr("");
    primerAcabado.setValtipdescri("SAN");

    gramaje.setCodtipvalor(TEXTO);
    gramaje.setCodtipdescr("");
    gramaje.setValtipdescri("325.46");

    ancho.setCodtipvalor(TEXTO);
    ancho.setCodtipdescr("");
    ancho.setValtipdescri("1.48");

    uso.setCodtipvalor(TEXTO);
    uso.setCodtipdescr("");
    uso.setValtipdescri("INDUSTRIA TEXTIL");

    espesor.setCodtipvalor(TEXTO);
    espesor.setCodtipdescr("");
    espesor.setValtipdescri("");

    tela.setNombreComercial(nombreComercial);
    tela.setMarcaComercial(marcaComercial);
    tela.setModelo(modelo);
    tela.setTipoTela(tipoTela);
    tela.setGradoElaboracion(gradoElaboracion);
    tela.setPrimerAcabado(primerAcabado);
    tela.setGramaje(gramaje);
    tela.setAnchoTela(ancho);
    tela.setUsoTela(uso);
    tela.setEspesorMateriaPlastica(espesor);

    return new Object[][]{{tela,dua}};
  }

  @Test(dataProvider= "initDataNK66")
  public void validarTipoTelaIA66Test(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarTipoTela(object, dua).size(), 1);
  }

  //  @Test(dataProvider="initDataNK66")
  //  public void ValidarComposicionTela66TEst(ModelAbstract object, Declaracion dua){
  //    Assert.assertEquals(validador.validarComposicionMateriaPlastica(object, dua).size(), 0);
  //  }

  @Test(dataProvider="initDataNK66")
  public void validarUso66(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarAnchoTela(object).size(), 0);
  }

  @Test(dataProvider="initDataNK66")
  public void validarAncho66(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarAnchoTela(object).size(), 0);
  }

  @Test(dataProvider="initDataNK66")
  public void validarEspesor66(ModelAbstract object, Declaracion dua){
    Assert.assertEquals(validador.validarEspesorMateriaPlastica(object, dua).size(), 0);
  }

}
