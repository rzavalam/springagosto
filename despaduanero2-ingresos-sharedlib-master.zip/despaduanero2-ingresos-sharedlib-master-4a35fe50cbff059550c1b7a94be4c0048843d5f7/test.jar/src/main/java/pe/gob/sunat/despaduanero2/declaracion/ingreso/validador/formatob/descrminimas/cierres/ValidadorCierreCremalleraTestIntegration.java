package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.cierres;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.cierres.model.CierreCremallera;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorCierreCremalleraTestIntegration extends AbstractServiceTest {

	 @Autowired
	 @Qualifier("ValidadorCierreCremallera")
	 private ValidadorCierreCremallera validador;

	 @Autowired
	 @Qualifier("framework.fabricaDeServicios")
	 private FabricaDeServicios fabricaDeServicios;
	 private static Mensaje               mensaje1001;
	 private static Declaracion           declaracion1001;

	 @Autowired
	 @Qualifier("Ayuda.ayudaServiceCache")
	 private AyudaServiceCache            ayudaServiceCache;

	 private CierreCremallera		cierreCremallera;
	 private Declaracion	declaracion;	
	
	  @BeforeClass
	  public void initData() throws Exception{
	    System.out.println("CARGANDO TEST INTEGRADO (CON XML) ...");

	    assertNotNull(fabricaDeServicios, "No se cargo la fabrica de servicios desde el contexto");
	    String filename = "src/test/java/xmlCierres/XML_CIERRES_CP01.xml";
	    String numeroTransaccion = "1001";

	    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

	    Map<String, Object> parametros = null;

	    parametros = new HashMap<String, Object>();
	    parametros.put("numeroTransaccion", numeroTransaccion);
	    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);
	    //Verificar la Existencia de Reglas
	    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
	    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
	    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

	    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);
	    //Verificar que Convirtio el XML a Mensaje
	    assertNotNull(mensaje1001);
	    declaracion1001 = (Declaracion) mensaje1001.getDocumento();

	    // ---------CIERRE CREMALLERA------------//
	    Integer item_numseitem = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getNumsecitem();
	    CierreCremallera cierreCremallera = new CierreCremallera();
	    String codigo, valor;
	    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima>  listaDescripcionMinimas = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getListDecrMinima();
	    for(pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima descripcion : listaDescripcionMinimas){
	      codigo =  descripcion.getCodtipdescr().trim();
	      valor = descripcion.getValtipdescri().trim();
	      Integer codigo_int = Integer.parseInt(codigo.substring(4,6));
	      System.out.println("Descripcion minima  --> " + codigo + " -> " + valor);
	      switch (codigo_int) {
	      
	      case 0:   DatoDescrMinima nombrecomercial = new DatoDescrMinima();
	      nombrecomercial.setValtipdescri(valor);
	      nombrecomercial.setNumsecitem(item_numseitem);
	      cierreCremallera.setNombreComercial(nombrecomercial);
	      cierreCremallera.setNumsecitem(item_numseitem);
	        break;
	      case 1:   DatoDescrMinima marcaComercial = new DatoDescrMinima();marcaComercial.setValtipdescri(valor);cierreCremallera.setMarcaComercial(marcaComercial);break;
	      case 2:   DatoDescrMinima modelo = new DatoDescrMinima();modelo.setValtipdescri(valor);cierreCremallera.setModelo(modelo);break;
	      case 3:   DatoDescrMinima tipoCierre = new DatoDescrMinima();tipoCierre.setValtipdescri(valor);cierreCremallera.setTipoCierre(tipoCierre);break;
	      case 4:   DatoDescrMinima composicionCinta = new DatoDescrMinima();composicionCinta.setValtipdescri(valor);cierreCremallera.setComposicionCinta(composicionCinta);break;
	      case 5:   DatoDescrMinima presentacionCinta = new DatoDescrMinima();presentacionCinta.setValtipdescri(valor);cierreCremallera.setPresentacionCinta(presentacionCinta);break;
	      case 6:   DatoDescrMinima tipoLlave = new DatoDescrMinima();tipoLlave.setValtipdescri(valor);cierreCremallera.setTipoLlave(tipoLlave);break;
	      case 7:   DatoDescrMinima materialLlave = new DatoDescrMinima();materialLlave.setValtipdescri(valor);cierreCremallera.setMaterialLlave(materialLlave);break;
	      case 8:   DatoDescrMinima tamanoCremallera = new DatoDescrMinima();tamanoCremallera.setValtipdescri(valor);cierreCremallera.setTamanoCremallera(tamanoCremallera);break;
	      case 9:   DatoDescrMinima materialDientes = new DatoDescrMinima();materialDientes.setValtipdescri(valor);cierreCremallera.setMaterialDientes(materialDientes);break;
	      case 10:   DatoDescrMinima tamanoDientes = new DatoDescrMinima();tamanoDientes.setValtipdescri(valor);cierreCremallera.setTamanoDientes(tamanoDientes);break;
	      default:  break;
	      }
	    }

	    this.declaracion = declaracion1001;
	    this.cierreCremallera = cierreCremallera;
	  }	 

	 	@Test
	 	public void testValidarUnidadComercial(){
	 		Assert.assertEquals(validador.validarUnidadComercial(cierreCremallera, declaracion).size(),0);
	 	} 
	 	@Test
	 	public void testValidarNombreComercial(){
	 		Assert.assertEquals(validador.validarNombreComercial(cierreCremallera).size(),0);
	 	} 	 	
	 	@Test
	 	public void testValidarMarcaComercial(){
	 		Assert.assertEquals(validador.validarMarcaComercial(cierreCremallera).size(),0);
	 	} 	
	 	@Test
	 	public void testValidarModelo(){
	 		Assert.assertEquals(validador.validarModelo(cierreCremallera).size(),0);
	 	} 		 	
	 	@Test
	 	public void testValidarTipoCierre(){
	 	    String tipoCierre = cierreCremallera.getTipoCierre().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(tipoCierre,"CD"),true);
	 	  }
	 	@Test
	 	public void testValidarComposicionCinta(){
	 	    String composicionCinta = cierreCremallera.getComposicionCinta().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(composicionCinta,"M1"),true);
	 	  }
	 	@Test
	 	public void testValidarPresentacionCinta(){
	 	    String presentacionCinta = cierreCremallera.getPresentacionCinta().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(presentacionCinta,"M3"),true);
	 	  }
	 	@Test
	 	public void testValidarTipoLlave(){
	 	    String tipoLlave = cierreCremallera.getTipoLlave().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(tipoLlave,"CC"),true);
	 	  }
	 	@Test
	 	public void testValidarMaterialLlave(){
	 	    String materialLlave = cierreCremallera.getMaterialLlave().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(materialLlave,"CB"),true);
	 	  }	 	
	 	@Test
	 	public void testValidarTamanoCremallera(){
	 		Assert.assertEquals(validador.validarTamanoCremallera(cierreCremallera).size(),0);
	 	} 	 	
	 	@Test
	 	public void testValidarMaterialDientes(){
	 	    String materialDientes = cierreCremallera.getMaterialDientes().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(materialDientes,"CB"),true);
	 	  }		 	
	 	@Test
	 	public void testValidarTamanoDientes(){
	 		Assert.assertEquals(validador.validarTamanoDientes(cierreCremallera).size(),0);
	 	}	  
}
