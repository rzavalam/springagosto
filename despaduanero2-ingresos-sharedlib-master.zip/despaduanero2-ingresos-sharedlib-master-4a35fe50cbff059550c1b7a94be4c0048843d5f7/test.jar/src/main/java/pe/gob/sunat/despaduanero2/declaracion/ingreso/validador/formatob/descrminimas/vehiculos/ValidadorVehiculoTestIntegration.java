package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.vehiculos;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.vehiculos.model.Vehiculo;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorVehiculoTestIntegration extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorVehiculo")
  private ValidadorVehiculo validador;

  @Autowired
  @Qualifier("framework.fabricaDeServicios")
  private FabricaDeServicios fabricaDeServicios;
  private static Mensaje			mensaje1001;
  private static Declaracion      	declaracion1001;

  @Autowired
  @Qualifier("Ayuda.ayudaServiceCache")
  private AyudaServiceCache		ayudaServiceCache;

  public static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
  private Vehiculo			vehiculo;
  private Declaracion		declaracion;

  @BeforeClass
  public void initData() throws Exception{
    System.out.println("CARGANDO TEST INTEGRADO (CON XML) ...");

    assertNotNull(fabricaDeServicios, "No se cargo la fabrica de servicios desde el contexto");

    // String filename = "src/test/java/xmlOther/Reg10_560114_cal.xml";
    String filename = "src/test/java/xmlVehiculos/XML_VEHICULOS_CP02.xml";
    //String filename = "src/test/java/xmlVehiculos/XML_VEHICULOS_CP03.xml";
    //String filename = "src/test/java/xmlVehiculos/XML_VEHICULOS_CP04.xml";
    String numeroTransaccion = "1001";

    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

    Map<String, Object> parametros = null;

    parametros = new HashMap<String, Object>();
    parametros.put("numeroTransaccion", numeroTransaccion);
    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);
    //Verificar la Existencia de Reglas
    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);
    //Verificar que Convirtio el XML a Mensaje
    assertNotNull(mensaje1001);
    declaracion1001 = (Declaracion) mensaje1001.getDocumento();

    //---------VEHICULO------------//
    Integer item_numseitem = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getNumsecitem();
    Vehiculo vehiculo = new Vehiculo();
    String codigo, valor;
    List<DatoDescrMinima> listtAccesorios = new ArrayList<DatoDescrMinima>();
    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima>  listaDescripcionMinimas = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getListDecrMinima();
    for(pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima descripcion : listaDescripcionMinimas){
      codigo =  descripcion.getCodtipdescr().trim();
      valor = descripcion.getValtipdescri().trim();
      Integer codigo_int = Integer.parseInt(codigo.substring(4,6));
      System.out.println("Descripcion minima  --> " + codigo + " -> " + valor);
      switch (codigo_int) {
      case 0:   DatoDescrMinima categoria = new DatoDescrMinima();
      DatoDescrMinima nombrecomercial = new DatoDescrMinima();
      categoria.setValtipdescri(valor);
      vehiculo.setCategoria(categoria);
      nombrecomercial.setValtipdescri(valor);
      nombrecomercial.setNumsecitem(item_numseitem);
      vehiculo.setNombreComercial(nombrecomercial);
      vehiculo.setNumsecitem(item_numseitem);
      break;
      case 1:   DatoDescrMinima marcaComercial = new DatoDescrMinima();marcaComercial.setValtipdescri(valor);vehiculo.setMarcaComercial(marcaComercial);break;
      case 2:   DatoDescrMinima modelo = new DatoDescrMinima();modelo.setValtipdescri(valor);vehiculo.setModelo(modelo);break;
      case 3:   DatoDescrMinima carroceria = new DatoDescrMinima();carroceria.setValtipdescri(valor);vehiculo.setCarroceria(carroceria);break;
      case 4:   DatoDescrMinima colorPrincipal = new DatoDescrMinima();colorPrincipal.setValtipdescri(valor);vehiculo.setColorPrincipal(colorPrincipal);break;
      case 5:   DatoDescrMinima tipoCombustible = new DatoDescrMinima();tipoCombustible.setValtipdescri(valor);vehiculo.setTipoCombustible(tipoCombustible);break;
      case 6:   DatoDescrMinima colorSecundario = new DatoDescrMinima();colorSecundario.setValtipdescri(valor);vehiculo.setColorSecundario(colorSecundario);break;
      case 7:   DatoDescrMinima indicadorSNTT = new DatoDescrMinima();indicadorSNTT.setValtipdescri(valor);vehiculo.setIndicadorSNTT(indicadorSNTT);break;
      case 8:   DatoDescrMinima version = new DatoDescrMinima();version.setValtipdescri(valor);vehiculo.setVersion(version);break;
      case 9:   DatoDescrMinima tipoMoto = new DatoDescrMinima();tipoMoto.setValtipdescri(valor);vehiculo.setTipoMoto(tipoMoto);break;
      case 10:  DatoDescrMinima cilindradaCC = new DatoDescrMinima();cilindradaCC.setValtipdescri(valor);vehiculo.setCilindradaCC(cilindradaCC);break;
      case 11:  DatoDescrMinima numeroChasis = new DatoDescrMinima();numeroChasis.setValtipdescri(valor);vehiculo.setNumeroChasis(numeroChasis);break;
      case 12:  DatoDescrMinima numeroVIN = new DatoDescrMinima();numeroVIN.setValtipdescri(valor);vehiculo.setNumeroVIN(numeroVIN);break;
      case 13:  DatoDescrMinima codigoExoneracionVIN = new DatoDescrMinima();codigoExoneracionVIN.setValtipdescri(valor);vehiculo.setCodigoExoneracionVIN(codigoExoneracionVIN);break;
      case 14:  DatoDescrMinima numeroMotor = new DatoDescrMinima();numeroMotor.setValtipdescri(valor);vehiculo.setNumeroMotor(numeroMotor);break;
      case 15:  DatoDescrMinima numeroCilindros = new DatoDescrMinima();numeroCilindros.setValtipdescri(valor);vehiculo.setNumeroCilindros(numeroCilindros);break;
      case 16:  DatoDescrMinima tipoEncendido = new DatoDescrMinima();tipoEncendido.setValtipdescri(valor);vehiculo.setTipoEncendido(tipoEncendido);break;
      case 17:  DatoDescrMinima numeroAsientos = new DatoDescrMinima();numeroAsientos.setValtipdescri(valor);vehiculo.setNumeroAsientos(numeroAsientos);break;
      case 18:  DatoDescrMinima cantidadEjes = new DatoDescrMinima();cantidadEjes.setValtipdescri(valor);vehiculo.setCantidadEjes(cantidadEjes);break;
      case 19:  DatoDescrMinima tipoTraccion = new DatoDescrMinima();tipoTraccion.setValtipdescri(valor);vehiculo.setTipoTraccion(tipoTraccion);break;
      case 20:  DatoDescrMinima tipoTransmision = new DatoDescrMinima();tipoTransmision.setValtipdescri(valor);vehiculo.setTipoTransmision(tipoTransmision);break;
      case 21:  DatoDescrMinima numeroPasajeros = new DatoDescrMinima();numeroPasajeros.setValtipdescri(valor);vehiculo.setNumeroPasajeros(numeroPasajeros);break;
      case 22:  DatoDescrMinima potenciaMotorKW = new DatoDescrMinima();potenciaMotorKW.setValtipdescri(valor);vehiculo.setPotenciaMotorKW(potenciaMotorKW);break;
      case 23:  DatoDescrMinima potenciaMotorRPM = new DatoDescrMinima();potenciaMotorRPM.setValtipdescri(valor);vehiculo.setPotenciaMotorRPM(potenciaMotorRPM);break;
      case 24:  DatoDescrMinima relacionPotenciaPesoBruto = new DatoDescrMinima();relacionPotenciaPesoBruto.setValtipdescri(valor);vehiculo.setRelacionPotenciaPesoBruto(relacionPotenciaPesoBruto);break;
      case 25:  DatoDescrMinima pesoBrutoCombinado = new DatoDescrMinima();pesoBrutoCombinado.setValtipdescri(valor);vehiculo.setPesoBrutoCombinado(pesoBrutoCombinado);break;
      case 26:  DatoDescrMinima pesoBrutoKG = new DatoDescrMinima();pesoBrutoKG.setValtipdescri(valor);vehiculo.setPesoBrutoKG(pesoBrutoKG);break;
      case 27:  DatoDescrMinima pesoNetoKG = new DatoDescrMinima();pesoNetoKG.setValtipdescri(valor);vehiculo.setPesoNetoKG(pesoNetoKG);break;
      case 28:  DatoDescrMinima cargaUtilKG = new DatoDescrMinima();cargaUtilKG.setValtipdescri(valor);vehiculo.setCargaUtilKG(cargaUtilKG);break;
      case 29:  DatoDescrMinima annoModelo = new DatoDescrMinima();annoModelo.setValtipdescri(valor);vehiculo.setAnnoModelo(annoModelo);break;
      case 30:  DatoDescrMinima kilometraje = new DatoDescrMinima();kilometraje.setValtipdescri(valor);vehiculo.setKilometraje(kilometraje);break;
      case 31:  DatoDescrMinima modeloDelFabricante = new DatoDescrMinima();modeloDelFabricante.setValtipdescri(valor);vehiculo.setModeloDelFabricante(modeloDelFabricante);break;
      case 32:  DatoDescrMinima Accesorios1 = new DatoDescrMinima();Accesorios1.setValtipdescri(valor);listtAccesorios.add(Accesorios1);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 33:  DatoDescrMinima Accesorios2 = new DatoDescrMinima();Accesorios2.setValtipdescri(valor);listtAccesorios.add(Accesorios2);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 34:  DatoDescrMinima Accesorios3 = new DatoDescrMinima();Accesorios3.setValtipdescri(valor);listtAccesorios.add(Accesorios3);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 35:  DatoDescrMinima Accesorios4 = new DatoDescrMinima();Accesorios4.setValtipdescri(valor);listtAccesorios.add(Accesorios4);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 36:  DatoDescrMinima Accesorios5 = new DatoDescrMinima();Accesorios5.setValtipdescri(valor);listtAccesorios.add(Accesorios5);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 37:  DatoDescrMinima Accesorios6 = new DatoDescrMinima();Accesorios6.setValtipdescri(valor);listtAccesorios.add(Accesorios6);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 38:  DatoDescrMinima Accesorios7 = new DatoDescrMinima();Accesorios7.setValtipdescri(valor);listtAccesorios.add(Accesorios7);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 39:  DatoDescrMinima Accesorios8 = new DatoDescrMinima();Accesorios8.setValtipdescri(valor);listtAccesorios.add(Accesorios8);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 40:  DatoDescrMinima Accesorios9 = new DatoDescrMinima();Accesorios9.setValtipdescri(valor);listtAccesorios.add(Accesorios9);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 41:  DatoDescrMinima Accesorios10 = new DatoDescrMinima();Accesorios10.setValtipdescri(valor);listtAccesorios.add(Accesorios10);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 42:  DatoDescrMinima Accesorios11 = new DatoDescrMinima();Accesorios11.setValtipdescri(valor);listtAccesorios.add(Accesorios11);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 43:  DatoDescrMinima Accesorios12 = new DatoDescrMinima();Accesorios12.setValtipdescri(valor);listtAccesorios.add(Accesorios12);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 44:  DatoDescrMinima Accesorios13 = new DatoDescrMinima();Accesorios13.setValtipdescri(valor);listtAccesorios.add(Accesorios13);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 45:  DatoDescrMinima Accesorios14 = new DatoDescrMinima();Accesorios14.setValtipdescri(valor);listtAccesorios.add(Accesorios14);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 46:  DatoDescrMinima Accesorios15 = new DatoDescrMinima();Accesorios15.setValtipdescri(valor);listtAccesorios.add(Accesorios15);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 47:  DatoDescrMinima Accesorios16 = new DatoDescrMinima();Accesorios16.setValtipdescri(valor);listtAccesorios.add(Accesorios16);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 48:  DatoDescrMinima Accesorios17 = new DatoDescrMinima();Accesorios17.setValtipdescri(valor);listtAccesorios.add(Accesorios17);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 49:  DatoDescrMinima Accesorios18 = new DatoDescrMinima();Accesorios18.setValtipdescri(valor);listtAccesorios.add(Accesorios18);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 50:  DatoDescrMinima Accesorios19 = new DatoDescrMinima();Accesorios19.setValtipdescri(valor);listtAccesorios.add(Accesorios19);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 51:  DatoDescrMinima Accesorios20 = new DatoDescrMinima();Accesorios20.setValtipdescri(valor);listtAccesorios.add(Accesorios20);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 52:  DatoDescrMinima Accesorios21 = new DatoDescrMinima();Accesorios21.setValtipdescri(valor);listtAccesorios.add(Accesorios21);vehiculo.setListaAccesorios(listtAccesorios);break;
      case 53:  DatoDescrMinima numeroHomologacionMTC = new DatoDescrMinima();numeroHomologacionMTC.setValtipdescri(valor);vehiculo.setNumeroHomologacionMTC(numeroHomologacionMTC);break;
      case 54:  DatoDescrMinima largoMM = new DatoDescrMinima();largoMM.setValtipdescri(valor);vehiculo.setLargoMM(largoMM);break;
      case 55:  DatoDescrMinima anchoMM = new DatoDescrMinima();anchoMM.setValtipdescri(valor);vehiculo.setAnchoMM(anchoMM);break;
      case 56:  DatoDescrMinima altoMM = new DatoDescrMinima();altoMM.setValtipdescri(valor);vehiculo.setAltoMM(altoMM);break;
      case 57:  DatoDescrMinima suspencionDelantera = new DatoDescrMinima();suspencionDelantera.setValtipdescri(valor);vehiculo.setSuspencionDelantera(suspencionDelantera);break;
      case 58:  DatoDescrMinima suspencionPorterior = new DatoDescrMinima();suspencionPorterior.setValtipdescri(valor);vehiculo.setSuspencionPorterior(suspencionPorterior);break;
      case 59:  DatoDescrMinima numeroCambiosDeCaja = new DatoDescrMinima();numeroCambiosDeCaja.setValtipdescri(valor);vehiculo.setNumeroCambiosDeCaja(numeroCambiosDeCaja);break;
      case 60:  DatoDescrMinima numeroPuertas = new DatoDescrMinima();numeroPuertas.setValtipdescri(valor);vehiculo.setNumeroPuertas(numeroPuertas);break;
      case 61:  DatoDescrMinima refrigeracionMotor = new DatoDescrMinima();refrigeracionMotor.setValtipdescri(valor);vehiculo.setRefrigeracionMotor(refrigeracionMotor);break;
      case 62:  DatoDescrMinima tipoFrenoDelantero = new DatoDescrMinima();tipoFrenoDelantero.setValtipdescri(valor);vehiculo.setTipoFrenoDelantero(tipoFrenoDelantero);break;
      case 63:  DatoDescrMinima tipoFrenoPosterior = new DatoDescrMinima();tipoFrenoPosterior.setValtipdescri(valor);vehiculo.setTipoFrenoPosterior(tipoFrenoPosterior);break;
      case 64:  DatoDescrMinima nombreFabricante = new DatoDescrMinima();nombreFabricante.setValtipdescri(valor);vehiculo.setNombreFabricante(nombreFabricante);break;
      case 65:  DatoDescrMinima numeroRuedas = new DatoDescrMinima();numeroRuedas.setValtipdescri(valor);vehiculo.setNumeroRuedas(numeroRuedas);break;
      case 66:  DatoDescrMinima medidaAros = new DatoDescrMinima();medidaAros.setValtipdescri(valor);vehiculo.setMedidaAros(medidaAros);break;
      case 67:  DatoDescrMinima medidaNeumaticos1 = new DatoDescrMinima();medidaNeumaticos1.setValtipdescri(valor);vehiculo.setMedidaNeumaticos1(medidaNeumaticos1);break;
      case 68:  DatoDescrMinima medidaNeumaticos2 = new DatoDescrMinima();medidaNeumaticos2.setValtipdescri(valor);vehiculo.setMedidaNeumaticos2(medidaNeumaticos2);break;
      case 69:  DatoDescrMinima distanciaEntreEjes = new DatoDescrMinima();distanciaEntreEjes.setValtipdescri(valor);vehiculo.setDistanciaEntreEjes(distanciaEntreEjes);break;
      case 70:  DatoDescrMinima marcaCarroceria = new DatoDescrMinima();marcaCarroceria.setValtipdescri(valor);vehiculo.setMarcaCarroceria(marcaCarroceria);break;
      case 71:  DatoDescrMinima numeroSerieCarroceria = new DatoDescrMinima();numeroSerieCarroceria.setValtipdescri(valor);vehiculo.setNumeroSerieCarroceria(numeroSerieCarroceria);break;
      case 72:  DatoDescrMinima pesoMaxEjeDelantero = new DatoDescrMinima();pesoMaxEjeDelantero.setValtipdescri(valor);vehiculo.setPesoMaximoEjeDelantero(pesoMaxEjeDelantero);break;
      case 73:  DatoDescrMinima pesoMaxEjePosterior1 = new DatoDescrMinima();pesoMaxEjePosterior1.setValtipdescri(valor);vehiculo.setPesoMaximoEjePosterior1(pesoMaxEjePosterior1);break;
      case 74:  DatoDescrMinima pesoMaxEjePosterior2 = new DatoDescrMinima();pesoMaxEjePosterior2.setValtipdescri(valor);vehiculo.setPesoMaximoEjePosterior2(pesoMaxEjePosterior2);break;
      case 75:  DatoDescrMinima pesoMaxEjePosterior3 = new DatoDescrMinima();pesoMaxEjePosterior3.setValtipdescri(valor);vehiculo.setPesoMaximoEjePosterior3(pesoMaxEjePosterior3);break;
      case 76:  DatoDescrMinima numeroRevisa1 = new DatoDescrMinima();numeroRevisa1.setValtipdescri(valor);vehiculo.setNumeroRevisa1(numeroRevisa1);break;
      case 77:  DatoDescrMinima fobPaisExportacion = new DatoDescrMinima();fobPaisExportacion.setValtipdescri(valor);vehiculo.setFobPaisExportacion(fobPaisExportacion);break;
      case 78:  DatoDescrMinima gastosReparacion = new DatoDescrMinima();gastosReparacion.setValtipdescri(valor);vehiculo.setGastosReparacion(gastosReparacion);break;
      case 79:  DatoDescrMinima extension = new DatoDescrMinima();extension.setValtipdescri(valor);vehiculo.setExtension(extension);break;
      default:  break;
      }
    }

    this.declaracion = declaracion1001;
    this.vehiculo = vehiculo;
  }

  @Test
  public void testValidarCarroceria(){
    String carroceria = vehiculo.getCarroceria().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(carroceria,"V3"),true);
  }
  @Test
  public void testValidarMarcaComercial(){
    String marcaComercial = vehiculo.getMarcaComercial().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(marcaComercial,"V2"),true);
  }
  @Test
  public void testValidarModelo(){
    String modelo = vehiculo.getModelo().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(modelo,"VB"),true);
  }
  @Test
  public void testValidarColorPrincipal(){
    String colorPrincipal = vehiculo.getColorPrincipal().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(colorPrincipal,"V4"),true);
  }
  @Test
  public void testValidarColorSecundario(){
    String colorSecundario = vehiculo.getColorSecundario().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(colorSecundario,"V4"),true);
  }
  @Test
  public void testValidarIndicadorSNTT(){
    String indicadorSNTT = vehiculo.getIndicadorSNTT().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(indicadorSNTT,"VC"),true);
  }
  @Test
  public void testValidarNumeroHomologacionMTC(){
    Assert.assertEquals(validador.validarNumeroHomologacionMTC(vehiculo).size(),0);
  }
  @Test
  public void testValidarTipoCombustible(){
    Assert.assertEquals(validador.validarTipoCombustible(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroMotor(){
    Assert.assertEquals(validador.validarNumeroMotor(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroCilindros(){
    Assert.assertEquals(validador.validarNumeroCilindros(vehiculo).size(),0);
  }
  @Test
  public void testValidarMoto(){
    Assert.assertEquals(validador.validarMoto(vehiculo).size(),0);
  }
  @Test
  public void testValidarCilindradaCC(){
    Assert.assertEquals(validador.validarCilindradaCC(vehiculo).size(),0);
  }
  @Test
  public void testValidarFormulaRodante(){
    Assert.assertEquals(validador.validarFormulaRodante(vehiculo).size(),0);
  }
  @Test
  public void testValidarVersion(){
    Assert.assertEquals(validador.validarVersion(vehiculo).size(),0);
  }
  @Test
  public void testValidarTipoEncendido(){
    Assert.assertEquals(validador.validarTipoEncendido(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroAsientos(){
    Assert.assertEquals(validador.validarNumeroAsientos(vehiculo).size(),0);
  }
  @Test
  public void testValidarCantidadEjes(){
    Assert.assertEquals(validador.validarCantidadEjes(vehiculo).size(),0);
  }
  @Test
  public void testValidarPesoMaximoEjeDelantero(){
    Assert.assertEquals(validador.validarPesoMaximoEjeDelantero(vehiculo).size(),0);
  }
  @Test
  public void testValidarPesoMaximoEjePosterior1(){
    Assert.assertEquals(validador.validarPesoMaximoEjePosterior1(vehiculo).size(),0);
  }
  @Test
  public void testvalidarPesoMaximoEjePosterior2(){
    Assert.assertEquals(validador.validarPesoMaximoEjePosterior2(vehiculo).size(),0);
  }
  @Test
  public void testValidarPesoMaximoEjePosterior3(){
    Assert.assertEquals(validador.validarPesoMaximoEjePosterior3(vehiculo).size(),0);
  }
  @Test
  public void testValidarLargoMM(){
    Assert.assertEquals(validador.validarLargoMM(vehiculo).size(),0);
  }
  @Test
  public void testValidarAnchoMM(){
    Assert.assertEquals(validador.validarAnchoMM(vehiculo).size(),0);
  }
  @Test
  public void testValidarAlturaMM(){
    Assert.assertEquals(validador.validarAlturaMM(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroCambiosDeCaja(){
    Assert.assertEquals(validador.validarNumeroCambiosDeCaja(vehiculo).size(),0);
  }
  @Test
  public void testValidarPotenciaPesoBruto(){
    Assert.assertEquals(validador.validarPotenciaPesoBruto(vehiculo).size(),0);
  }
  @Test
  public void testValidarPesoBrutoCombinado(){
    Assert.assertEquals(validador.validarPesoBrutoCombinado(vehiculo).size(),0);
  }
  @Test
  public void testValidarPesoBrutoKG(){
    Assert.assertEquals(validador.validarPesoBrutoKG(vehiculo).size(),0);
  }
  @Test
  public void testValidarPesoNetoKG(){
    Assert.assertEquals(validador.validarPesoNetoKG(vehiculo).size(),0);
  }
  @Test
  public void testValidarCargaUtilKG(){
    Assert.assertEquals(validador.validarCargaUtilKG(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroPasajeros(){
    Assert.assertEquals(validador.validarNumeroPasajeros(vehiculo).size(),0);
  }
  @Test
  public void testValidarPotenciaMotorKW(){
    Assert.assertEquals(validador.validarPotenciaMotorKW(vehiculo).size(),0);
  }
  @Test
  public void testValidarPotenciaMotorRPM(){
    Assert.assertEquals(validador.validarPotenciaMotorRPM(vehiculo).size(),0);
  }
  @Test
  public void testValidarTipoTransmision(){
    Assert.assertEquals(validador.validarTipoTransmision(vehiculo).size(),0);
  }
  @Test
  public void testValidarMedidaAros(){
    Assert.assertEquals(validador.validarMedidaAros(vehiculo).size(),0);
  }
  @Test
  public void testValidarMedidaNeumaticos1(){
    Assert.assertEquals(validador.validarMedidaNeumaticos1(vehiculo).size(),0);
  }
  @Test
  public void testValidarMedidaNeumaticos2(){
    Assert.assertEquals(validador.validarMedidaNeumaticos2(vehiculo).size(),0);
  }
  @Test
  public void testValidarDistanciaEntreEjes(){
    Assert.assertEquals(validador.validarDistanciaEntreEjes(vehiculo).size(),0);
  }
  @Test
  public void testValidarMarcaCarroceria(){
    Assert.assertEquals(validador.validarMarcaCarroceria(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroPuertas(){
    Assert.assertEquals(validador.validarNumeroPuertas(vehiculo).size(),0);
  }
  @Test
  public void testValidarRefrigeracionMotor(){
    Assert.assertEquals(validador.validarRefrigeracionMotor(vehiculo).size(),0);
  }
  @Test
  public void testValidarTipoFrenoDelantero(){
    Assert.assertEquals(validador.validarTipoFrenoDelantero(vehiculo).size(),0);
  }
  @Test
  public void testValidarTipoFrenoPosterior(){
    Assert.assertEquals(validador.validarTipoFrenoPosterior(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroRuedas(){
    Assert.assertEquals(validador.validarNumeroRuedas(vehiculo).size(),0);
  }
  @Test
  public void testValidarModeloDelFabricante(){
    Assert.assertEquals(validador.validarModeloDelFabricante(vehiculo).size(),0);
  }
  @Test
  public void testValidarFobPaisExportacion(){
    Assert.assertEquals(validador.validarFobPaisExportacion(vehiculo, declaracion).size(),0);
  }
  @Test
  public void testValidarGastosReparacion(){
    Assert.assertEquals(validador.validarGastosReparacion(vehiculo, declaracion).size(),0);
  }
  @Test
  public void testValidarExtension(){
    Assert.assertEquals(validador.validarExtension(vehiculo, declaracion).size(),0);
  }
  @Test
  public void testValidarAnnoFabricacion(){
    Assert.assertEquals(validador.validarAnnoFabricacion(vehiculo, declaracion).size(),0);
  }
  @Test
  public void testValidarAnnModelo(){
    Assert.assertEquals(validador.validarAnnModelo(vehiculo, declaracion).size(),0);
  }
  @Test
  public void testValidarSuspencionDelantera(){
    Assert.assertEquals(validador.validarSuspencionDelantera(vehiculo).size(),0);
  }
  @Test
  public void testValidarSuspencionPorterior(){
    Assert.assertEquals(validador.validarSuspencionPosterior(vehiculo).size(),0);
  }
  @Test
  public void testValidarNombreDelFabricante(){
    Assert.assertEquals(validador.validarNombreDelFabricante(vehiculo).size(),0);
  }
  @Test
  public void testValidarNumeroCarroceria(){
    Assert.assertEquals(validador.validarNumeroCarroceria(vehiculo).size(),0);
  }
  @Test
  public void testValidarRevisa1(){
    Assert.assertEquals(validador.validarRevisa1(vehiculo, declaracion).size(),0);
  }
  @Test
  public void testValidarNumeroChasis(){
    Assert.assertEquals(validador.validarNumeroChasis(vehiculo).size(),0);
  }
  @Test
  public void testValidarCategoria(){
    Assert.assertEquals(validador.validarCategoria(vehiculo).size(),0);
  }
  @Test
  public void testValidarCorrelacion(){
    Assert.assertEquals(validador.validarCorrelacion(vehiculo).size(),1);
  }
  @Test
  public void testValidarNumeroVIM(){
    Assert.assertEquals(validador.validarNumeroVIN(vehiculo).size(),0);
  }
  @Test
  public void testValidarCodigoExoneracionVIM(){
    Assert.assertEquals(validador.validarCodigoExoneracionVIN(vehiculo,declaracion).size(),0);
  }
  @Test
  public void testValidarListaAccesorios(){
    Assert.assertEquals(validador.validarListaAccesorios(vehiculo).size(),0);
  }
  @Test
  public void testValidarKilometraje(){
    Assert.assertEquals(validador.validarKilometraje(vehiculo, declaracion).size(),0);
  }
}