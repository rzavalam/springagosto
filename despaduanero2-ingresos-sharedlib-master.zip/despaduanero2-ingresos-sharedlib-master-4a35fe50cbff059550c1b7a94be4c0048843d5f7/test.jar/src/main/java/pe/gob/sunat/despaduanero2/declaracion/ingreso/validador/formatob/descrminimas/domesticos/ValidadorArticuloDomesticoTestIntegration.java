package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.domesticos;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.domesticos.model.ArticuloDomestico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorArticuloDomesticoTestIntegration extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorArticuloDomestico")
  private ValidadorArticuloDomestico validador;

  @Autowired
  @Qualifier("framework.fabricaDeServicios")
  private FabricaDeServicios fabricaDeServicios;
  private static Mensaje               mensaje1001;
  private static Declaracion           declaracion1001;

  @Autowired
  @Qualifier("Ayuda.ayudaServiceCache")
  private AyudaServiceCache            ayudaServiceCache;

  private ArticuloDomestico		articuloDomestico;
  private Declaracion			declaracion;

  @BeforeClass
  public void initData() throws Exception{
    System.out.println("CARGANDO TEST INTEGRADO (CON XML) ...");

    assertNotNull(fabricaDeServicios, "No se cargo la fabrica de servicios desde el contexto");
    String filename = "src/test/java/xmlDomesticos/XML_DOMESTICOS_CP01.xml";
    String numeroTransaccion = "1001";

    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

    Map<String, Object> parametros = null;

    parametros = new HashMap<String, Object>();
    parametros.put("numeroTransaccion", numeroTransaccion);
    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);
    //Verificar la Existencia de Reglas
    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);
    //Verificar que Convirtio el XML a Mensaje
    assertNotNull(mensaje1001);
    declaracion1001 = (Declaracion) mensaje1001.getDocumento();

    // ---------DOMESTICO------------//
    Integer item_numseitem = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getNumsecitem();
    ArticuloDomestico articuloDomestico = new ArticuloDomestico();
    String codigo, valor;
    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima>  listaDescripcionMinimas = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getListDecrMinima();
    for(pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima descripcion : listaDescripcionMinimas){
      codigo =  descripcion.getCodtipdescr().trim();
      valor = descripcion.getValtipdescri().trim();
      Integer codigo_int = Integer.parseInt(codigo.substring(4,6));
      System.out.println("Descripcion minima  --> " + codigo + " -> " + valor);
      switch (codigo_int) {
      case 0:   DatoDescrMinima nombrecomercial = new DatoDescrMinima();
      nombrecomercial.setValtipdescri(valor);
      nombrecomercial.setNumsecitem(item_numseitem);
      articuloDomestico.setNombreComercial(nombrecomercial);
      articuloDomestico.setNumsecitem(item_numseitem);
        break;
      case 1:   DatoDescrMinima marcaComercial = new DatoDescrMinima();marcaComercial.setValtipdescri(valor);articuloDomestico.setMarcaComercial(marcaComercial);break;
      case 2:   DatoDescrMinima modelo = new DatoDescrMinima();modelo.setValtipdescri(valor);articuloDomestico.setModelo(modelo);break;
      case 3:   DatoDescrMinima primerComponente = new DatoDescrMinima();primerComponente.setValtipdescri(valor);articuloDomestico.setPrimerComponente(primerComponente);break;
      case 4:   DatoDescrMinima segundoComponente = new DatoDescrMinima();segundoComponente.setValtipdescri(valor);articuloDomestico.setSegundoComponente(segundoComponente);break;
      case 5:   DatoDescrMinima acabado = new DatoDescrMinima();acabado.setValtipdescri(valor);articuloDomestico.setAcabado(acabado);break;
      case 6:   DatoDescrMinima color = new DatoDescrMinima();color.setValtipdescri(valor);articuloDomestico.setColor(color);break;
      case 7:   DatoDescrMinima accesorios = new DatoDescrMinima();accesorios.setValtipdescri(valor);articuloDomestico.setAccesorios(accesorios);break;
      case 8:   DatoDescrMinima modoPresentacion = new DatoDescrMinima();modoPresentacion.setValtipdescri(valor);articuloDomestico.setModoPresentacion(modoPresentacion);break;
      case 9:   DatoDescrMinima pesoVolumen = new DatoDescrMinima();pesoVolumen.setValtipdescri(valor);articuloDomestico.setPesoVolumen(pesoVolumen);break;
      case 10:  DatoDescrMinima unidadMedidaPesoVolumen = new DatoDescrMinima();unidadMedidaPesoVolumen.setValtipdescri(valor);articuloDomestico.setUnidadMedidaPesoVolumen(unidadMedidaPesoVolumen);break;      
      default:  break;
      }
    }

    this.declaracion = declaracion1001;
    this.articuloDomestico = articuloDomestico;
  }

  @Test
  public void testValidarUnidadComercialUtiles(){
    Assert.assertEquals(validador.validarUnidadComercial(articuloDomestico, declaracion).size(),0);
  }
  @Test
  public void testValidarNombreArticuloDomestico(){
    String nombre = articuloDomestico.getNombreComercial().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(nombre, "473"), true);
  }
  @Test
  public void testValidarComposicionArticulosDomesticos(){
    String composicion = articuloDomestico.getPrimerComponente().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(composicion,"474"),true);
  }
  @Test
  public void testValidarAcabadoArticulosDomesticos(){
    String acabado = articuloDomestico.getAcabado().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(acabado,"475"),true);
  }
  @Test
  public void testValidarColorArticuloDomestico(){
    String color = articuloDomestico.getColor().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(color,"476"),true);
  }
  @Test
  public void testValidarAccesoriosArticulosDomesticos(){
    String accesorio = articuloDomestico.getAccesorios().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(accesorio,"477"),false);
  }
  @Test
  public void testValidarPresentacionCantidadPiezasArticulosDomesticos(){
    Assert.assertEquals(validador.validarPresentacionCantidadPiezas(articuloDomestico, declaracion).size(),0);
  }
  @Test
  public void testValidarPesoVolumenArticulosDomesticos(){
    Assert.assertEquals(validador.validarPesoVolumen(articuloDomestico).size(),0);
  }
  @Test
  public void testValidarUnidadMedidaPesoVolumen(){
    String UnidadMedidaPesoVolumen = articuloDomestico.getUnidadMedidaPesoVolumen().getValtipdescri(); 
    Assert.assertEquals(validador.estaEnCatalogo(UnidadMedidaPesoVolumen,"29"),true);
  }    
}
