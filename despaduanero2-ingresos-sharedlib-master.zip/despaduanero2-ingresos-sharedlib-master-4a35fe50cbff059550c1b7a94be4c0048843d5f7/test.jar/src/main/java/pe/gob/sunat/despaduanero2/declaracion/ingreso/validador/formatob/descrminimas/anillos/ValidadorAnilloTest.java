package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.anillos;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.anillos.model.Anillo;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorAnilloTest extends AbstractServiceTest{

  @Autowired
  @Qualifier("ValidadorAnillo")
  private ValidadorAnillo validador;

  private Anillo          anillos;
  private Declaracion	  declaracion;

  @BeforeClass
  public void initData() throws ParseException{	  
	System.out.println("LOAD TEST UNITARIOS ...");
    Anillo anillos = new Anillo();
    /*Nombre Comercial Anillo*/
    DatoDescrMinima nombreCom = new DatoDescrMinima();
    nombreCom.setValtipdescri("OJALILLOS");
    nombreCom.setNumsecitem(3);
    anillos.setNombreComercial(nombreCom);
    /*Marca Comercial Anillo*/
    DatoDescrMinima marcaCom = new DatoDescrMinima();
    marcaCom.setValtipdescri("MAXI");
    anillos.setMarcaComercial(marcaCom);
    /*Modelo Anillo*/
    DatoDescrMinima modelo = new DatoDescrMinima();
    modelo.setValtipdescri("PREMIUM");
    anillos.setMarcaComercial(modelo);
    /*Tipo Anillos*/
    DatoDescrMinima tipo = new DatoDescrMinima();
    tipo.setValtipdescri("CON");
    anillos.setTipoAnillos(tipo);
    /*Material de Fabricación*/
    DatoDescrMinima matFab = new DatoDescrMinima();
    matFab.setValtipdescri("ACE");
    anillos.setMaterialFabricacion(matFab);
    /*Acabado*/
    DatoDescrMinima acabadoAni = new DatoDescrMinima();
    acabadoAni.setValtipdescri("COF");
    anillos.setAcabado(acabadoAni);
    /*Uso*/
    DatoDescrMinima usoAni = new DatoDescrMinima();
    usoAni.setValtipdescri("CAL");
    anillos.setUso(usoAni);
    /*Dimension*/
    DatoDescrMinima dimension = new DatoDescrMinima();
    dimension.setValtipdescri("CON 8mm DE DIAMETRO EXTERIOR");
    anillos.setDimension(dimension);

    Declaracion declaracion = new Declaracion();
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();

    //UnidadComercial//
    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumsecitem(1);
    item.setCodunidcomer("12U"); //NO HAY CATALOGO
    lstitem.add(item);
    factu.setListItems(lstitem);
    lstFactu.add(factu);
    dav.setListFacturas(lstFactu);
    listDAVs.add(dav);
    declaracion.setListDAVs(listDAVs);
    anillos.setNumsecitem(1);
    this.declaracion = declaracion;
    this.anillos = anillos;
    
  }

  @Test
  public void testValidarUnidadComercial()
  {
    //por el momento '0'
    Assert.assertEquals(validador.validarUnidadComercial(anillos, declaracion).size(),0);
  }

  @Test
  public void testValidarNombreComercial()
  {
    System.out.println(" *Test ValidarNombreComercial: ");
    System.out.println(" Nombre Comercial Anillos: " +anillos.getNombreComercial().getValtipdescri());
    //por el momento '0'
    Assert.assertEquals(validador.validarNombreComercial(anillos).size(),0);
  }

  @Test
  public void testValidarMarcaComercial()
  {
    System.out.println(" *Test ValidarMarcaComercial: ");
    System.out.println(" Marca Comercial anillos: " +anillos.getMarcaComercial().getValtipdescri());
    //por el momento '0'
    Assert.assertEquals(validador.validarMarcaComercial(anillos).size(),0);
  }

  @Test
  public void testValidarModelo()
  {
     System.out.println(" *Test ValidarModelo: ");
    //	 System.out.println(" Modelo de anillos: " +anillos.getModelo().getValtipdescri());
       Assert.assertEquals(validador.validarModelo(anillos).size(),0);
  }

  @Test
  public void testValidarTipo()
  {
    System.out.println(" *Test ValidarTipo: ");
    String tipo = anillos.getTipoAnillos().getValtipdescri();
    System.out.println(" Tipo de anillos: " +tipo);
    Assert.assertEquals(validador.estaEnCatalogo(tipo,"TD"),true);
  }

  @Test
  public void testValidarMatFab()
  {
    System.out.println(" *Test ValidarMaterialFabricacion: ");
    String matFab = anillos.getMaterialFabricacion().getValtipdescri();
    System.out.println(" Material Fabricacion: " +matFab);
    Assert.assertEquals(validador.estaEnCatalogo(matFab, "TE"),true);
  }

  @Test
  public void testValidarAcab()
  {
    System.out.println(" *Test ValidarAcabado: ");
    String acabado = anillos.getAcabado().getValtipdescri();
    System.out.println(" Acabado anillos: " +acabado);
    Assert.assertEquals(validador.noEstaEnCatalogo(acabado,"TF"),false);
  }

  @Test
  public void testValidarUso()
  {
    System.out.println(" *Test ValidarUso: ");
    String uso = anillos.getUso().getValtipdescri();
    System.out.println(" Uso anillos: " + uso);
    Assert.assertEquals(validador.noEstaEnCatalogo(uso,"TG"),false);
  }

  @Test
  public void testValidarDimension()
  {
    System.out.println(" *Test ValidarDimension: ");
    System.out.println(" Dimension de anillos: " +anillos.getDimension().getValtipdescri());   
    Assert.assertEquals(validador.validarDimension(anillos).size(),0);
  }
}