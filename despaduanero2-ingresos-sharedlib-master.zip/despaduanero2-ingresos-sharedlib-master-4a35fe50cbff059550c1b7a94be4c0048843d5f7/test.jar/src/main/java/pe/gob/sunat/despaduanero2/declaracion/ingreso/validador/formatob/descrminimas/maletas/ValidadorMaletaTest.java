package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.maletas;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.maletas.model.Maleta;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */

public class ValidadorMaletaTest extends AbstractServiceTest{


  @Autowired
  @Qualifier("ValidadorMaleta")
  private final ValidadorMaleta validador = new ValidadorMaleta();
  private final static String CATALOGO = "0";
  private final static String TEXTO    = "1";

  @DataProvider (name = "initDataEnlaceAduanero_145")
  private Object[][] initDataEnlaceAduanero_145(){

    DatoItem item = new DatoItem();
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreProducto  = new DatoDescrMinima();
    DatoDescrMinima marcaProducto   = new DatoDescrMinima();
    DatoDescrMinima modeloProducto  = new DatoDescrMinima();
    DatoDescrMinima tipoMaterialExterno = new DatoDescrMinima();
    DatoDescrMinima subtipoMaterialExterno = new DatoDescrMinima();
    DatoDescrMinima primerPorcentage = new DatoDescrMinima();
    DatoDescrMinima tipoSegMaterialExt = new DatoDescrMinima();
    DatoDescrMinima subtipoSegMaterialExt = new DatoDescrMinima();
    DatoDescrMinima segundoPorcentage   = new DatoDescrMinima();
    DatoDescrMinima forro           = new DatoDescrMinima();
    DatoDescrMinima acabado         = new DatoDescrMinima();
    DatoDescrMinima accesorios      = new DatoDescrMinima();
    DatoDescrMinima cantidadAccesorios = new DatoDescrMinima();
    DatoDescrMinima primerAplicacion= new DatoDescrMinima();
    DatoDescrMinima cantidad1Aplicacion = new DatoDescrMinima();
    DatoDescrMinima segundaAplicacion = new DatoDescrMinima();
    DatoDescrMinima cantidad2Aplicacion = new DatoDescrMinima();
    DatoDescrMinima terceraAplicacion = new DatoDescrMinima();
    DatoDescrMinima cantidad3Aplicacion = new DatoDescrMinima();
    DatoDescrMinima medidas           = new DatoDescrMinima();
    DatoDescrMinima presentacion      = new DatoDescrMinima();
    DatoDescrMinima peso              = new DatoDescrMinima();

    nombreProducto.setCodtipvalor(CATALOGO);
    nombreProducto.setCodtipdescr("MA0000");
    nombreProducto.setValtipdescri("004");

    marcaProducto.setCodtipvalor(TEXTO);
    marcaProducto.setCodtipdescr("MA0001");
    marcaProducto.setValtipdescri("ZYOL & ZAKY");

    modeloProducto.setCodtipvalor(TEXTO);
    modeloProducto.setCodtipdescr("MA0002");
    modeloProducto.setValtipdescri("4315");

    tipoMaterialExterno.setCodtipvalor(CATALOGO);
    tipoMaterialExterno.setCodtipdescr("MA0003");
    tipoMaterialExterno.setValtipdescri("001");

    subtipoMaterialExterno.setCodtipvalor(CATALOGO);
    subtipoMaterialExterno.setCodtipdescr("MA0004");
    subtipoMaterialExterno.setValtipdescri("101");

    primerPorcentage.setCodtipvalor(TEXTO);
    primerPorcentage.setCodtipdescr("MA0005");
    primerPorcentage.setValtipdescri("100");

    tipoSegMaterialExt.setCodtipvalor(CATALOGO);
    tipoSegMaterialExt.setCodtipdescr("MA0006");
    tipoSegMaterialExt.setValtipdescri("002");

    subtipoSegMaterialExt.setCodtipvalor(CATALOGO);
    subtipoSegMaterialExt.setCodtipdescr("MA0007");
    subtipoSegMaterialExt.setValtipdescri("201");

    segundoPorcentage.setCodtipvalor(TEXTO);
    segundoPorcentage.setCodtipdescr("MA0008");
    segundoPorcentage.setValtipdescri("0");

    forro.setCodtipvalor(CATALOGO);
    forro.setCodtipdescr("MA0012");
    forro.setValtipdescri("007");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("MA0013");
    acabado.setValtipdescri("001");

    accesorios.setCodtipvalor(CATALOGO);
    accesorios.setCodtipdescr("MA0015");
    accesorios.setValtipdescri("001");

    cantidadAccesorios.setCodtipvalor(TEXTO);
    cantidadAccesorios.setCodtipdescr("MA0016");
    cantidadAccesorios.setValtipdescri("2");

    primerAplicacion.setCodtipvalor(CATALOGO);
    primerAplicacion.setCodtipdescr("MA0021");
    primerAplicacion.setValtipdescri("003");

    cantidad1Aplicacion.setCodtipvalor(TEXTO);
    cantidad1Aplicacion.setCodtipdescr("MA0022");
    cantidad1Aplicacion.setValtipdescri("3");

    segundaAplicacion.setCodtipvalor(CATALOGO);
    segundaAplicacion.setCodtipdescr("MA0023");
    segundaAplicacion.setValtipdescri("009");

    cantidad2Aplicacion.setCodtipvalor(TEXTO);
    cantidad2Aplicacion.setCodtipdescr("MA0024");
    cantidad2Aplicacion.setValtipdescri("1");

    terceraAplicacion.setCodtipvalor(CATALOGO);
    terceraAplicacion.setCodtipdescr("MA0025");
    terceraAplicacion.setValtipdescri("006");

    cantidad3Aplicacion.setCodtipvalor(TEXTO);
    cantidad3Aplicacion.setCodtipdescr("MA0026");
    cantidad3Aplicacion.setValtipdescri("1");

    medidas.setCodtipvalor(TEXTO);
    medidas.setCodtipdescr("MA0017");
    medidas.setValtipdescri("15.0''x13.0''x6.0''");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("001");

    peso.setCodtipvalor(TEXTO);
    peso.setCodtipdescr("MA0019");
    peso.setValtipdescri("550.00");

    item.setCodunidcomer("SET");

    maleta.setNombreComercial(nombreProducto);
    maleta.setMarcaComercial(marcaProducto);
    maleta.setModelo(modeloProducto);
    maleta.setTipo1erComp(tipoMaterialExterno);
    maleta.setSubTipo1erComp(subtipoMaterialExterno);
    maleta.setPorcentaje1erComp(primerPorcentage);
    maleta.setTipo2doComp(tipoSegMaterialExt);
    maleta.setSubTipo2doComp(subtipoSegMaterialExt);
    maleta.setPorcentaje2doComp(segundoPorcentage);
    maleta.setComposicionForro(forro);
    maleta.setPrimerAcabado(acabado);
    maleta.setPrimerAccesorio(accesorios);
    maleta.setCantidad1erAccesorio(cantidadAccesorios);
    maleta.setPrimeraAplicacion(primerAplicacion);
    maleta.setCantidad1erAplicacion(cantidad1Aplicacion);
    maleta.setSegundaAplicacion(segundaAplicacion);
    maleta.setCantidad2daAplicacion(cantidad2Aplicacion);
    maleta.setTerceraAplicacion(terceraAplicacion);
    maleta.setCantidad3erAplicacion(cantidad3Aplicacion);
    maleta.setMedidas(medidas);
    maleta.setPresentacion(presentacion);
    maleta.setPeso(peso);

    return new Object[][]{{ maleta, item}};
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestUnidadComercual(ModelAbstract object,
                                                    DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarUnidadComercial(object, item), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestComponentes(ModelAbstract object,
                                                DatoItem item){
    Assert.assertEquals(validador.validarMaterialMaletas(object).size(), 0);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestForro(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarTipoComposicionForro(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestAcabado(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAcabados(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestAccesorios(ModelAbstract object,
                                               DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAccesorios(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestAplicaciones(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestMedidas(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestPresentacion(ModelAbstract object,
                                                 DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object, item).size(), 0);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_145")
  public void enlaceAduanero_145TestPEso(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarPeso(object), lst);
  }

  @DataProvider (name = "initDataEnlaceAduanero_146")
  private Object[][] initDataEnlaceAduanero_146(){
    Maleta maleta = new Maleta();
    DatoItem item = new DatoItem();

    DatoDescrMinima nombreProducto       = new DatoDescrMinima();
    DatoDescrMinima marcaProducto        = new DatoDescrMinima();
    DatoDescrMinima modeloProducto       = new DatoDescrMinima();
    DatoDescrMinima tipoprimMaterial     = new DatoDescrMinima();
    DatoDescrMinima subtipoprimMaterial  = new DatoDescrMinima();
    DatoDescrMinima primeraCantidad      = new DatoDescrMinima();
    DatoDescrMinima tiposegunMaterial    = new DatoDescrMinima();
    DatoDescrMinima subtiposegunMaterial = new DatoDescrMinima();
    DatoDescrMinima segunCantidad        = new DatoDescrMinima();
    DatoDescrMinima tipoterMaterial      = new DatoDescrMinima();
    DatoDescrMinima subtipoterMaterial   = new DatoDescrMinima();
    DatoDescrMinima terCantidad          = new DatoDescrMinima();
    DatoDescrMinima forro                = new DatoDescrMinima();
    DatoDescrMinima acabado              = new DatoDescrMinima();
    DatoDescrMinima accesorio            = new DatoDescrMinima();
    DatoDescrMinima cantidadAccesorio = new DatoDescrMinima();
    DatoDescrMinima aplicacion        = new DatoDescrMinima();
    DatoDescrMinima cantidadAplic     = new DatoDescrMinima();
    DatoDescrMinima medidas           = new DatoDescrMinima();
    DatoDescrMinima presentacion      = new DatoDescrMinima();
    DatoDescrMinima peso              = new DatoDescrMinima();

    nombreProducto.setCodtipvalor(CATALOGO);
    nombreProducto.setCodtipdescr("MA0000");
    nombreProducto.setValtipdescri("002");

    marcaProducto.setCodtipvalor(TEXTO);
    marcaProducto.setCodtipdescr("MA0001");
    marcaProducto.setValtipdescri("S/M");

    modeloProducto.setCodtipvalor(TEXTO);
    modeloProducto.setCodtipdescr("MA0002");
    modeloProducto.setValtipdescri("BG40511");

    tipoprimMaterial.setCodtipvalor(CATALOGO);
    tipoprimMaterial.setCodtipdescr("MA0003");
    tipoprimMaterial.setValtipdescri("002");

    subtipoprimMaterial.setCodtipvalor(CATALOGO);
    subtipoprimMaterial.setCodtipdescr("MA0004");
    subtipoprimMaterial.setValtipdescri("201");

    primeraCantidad.setCodtipvalor(TEXTO);
    primeraCantidad.setCodtipdescr("MA0005");
    primeraCantidad.setValtipdescri("80");

    tiposegunMaterial.setCodtipvalor(CATALOGO);
    tiposegunMaterial.setCodtipdescr("MA0006");
    tiposegunMaterial.setValtipdescri("002");

    subtiposegunMaterial.setCodtipvalor(CATALOGO);
    subtiposegunMaterial.setCodtipdescr("MA0007");
    subtiposegunMaterial.setValtipdescri("212");

    segunCantidad.setCodtipvalor(TEXTO);
    segunCantidad.setCodtipdescr("MA0008");
    segunCantidad.setValtipdescri("20");

    tipoterMaterial.setCodtipvalor(CATALOGO);
    tipoterMaterial.setCodtipdescr("MA0009");
    tipoterMaterial.setValtipdescri("002");

    subtipoterMaterial.setCodtipvalor(CATALOGO);
    subtipoterMaterial.setCodtipdescr("MA0010");
    subtipoterMaterial.setValtipdescri("206");

    terCantidad.setCodtipvalor(TEXTO);
    terCantidad.setCodtipdescr("MA0011");
    terCantidad.setValtipdescri("0");

    forro.setCodtipvalor(CATALOGO);
    forro.setCodtipdescr("MA0012");
    forro.setValtipdescri("007");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("MA0013");
    acabado.setValtipdescri("010");

    accesorio.setCodtipvalor(CATALOGO);
    accesorio.setCodtipdescr("MA0015");
    accesorio.setValtipdescri("001");

    cantidadAccesorio.setCodtipvalor(TEXTO);
    cantidadAccesorio.setCodtipdescr("MA0016");
    cantidadAccesorio.setValtipdescri("1");

    aplicacion.setCodtipvalor(CATALOGO);
    aplicacion.setCodtipdescr("MA0021");
    aplicacion.setValtipdescri("003");

    cantidadAplic.setCodtipvalor(TEXTO);
    cantidadAplic.setCodtipdescr("MA0022");
    cantidadAplic.setValtipdescri("1");

    medidas.setCodtipvalor(TEXTO);
    medidas.setCodtipdescr("MA0017");
    medidas.setValtipdescri("11.0''x8.0''x2.0''");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("003");

    peso.setCodtipvalor(TEXTO);
    peso.setCodtipdescr("MA0019");
    peso.setValtipdescri("120");

    item.setCodunidcomer("SET");
    item.setNumpartnandi(new Long(420232000));

    maleta.setNombreComercial(nombreProducto);
    maleta.setMarcaComercial(marcaProducto);
    maleta.setModelo(modeloProducto);
    maleta.setTipo1erComp(tipoprimMaterial);
    maleta.setSubTipo1erComp(subtipoterMaterial);
    maleta.setPorcentaje1erComp(primeraCantidad);
    maleta.setTipo2doComp(tiposegunMaterial);
    maleta.setSubTipo2doComp(subtiposegunMaterial);
    maleta.setPorcentaje2doComp(segunCantidad);
    maleta.setTipo3erComp(tipoterMaterial);
    maleta.setSubTipo3erComp(subtipoterMaterial);
    maleta.setPorcentaje3erComp(terCantidad);
    maleta.setComposicionForro(forro);
    maleta.setPrimerAcabado(acabado);
    maleta.setPrimerAccesorio(accesorio);
    maleta.setCantidad1erAccesorio(cantidadAccesorio);
    maleta.setPrimeraAplicacion(aplicacion);
    maleta.setCantidad1erAplicacion(cantidadAplic);
    maleta.setMedidas(medidas);
    maleta.setPresentacion(presentacion);
    maleta.setPeso(peso);

    return new Object[][]{{ maleta, item}};
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestNombreComercial(ModelAbstract object,
                                                    DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarNombreComercial(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestMarcaComercial(ModelAbstract object,
                                                   DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMarcaComercial(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestModeloComercial(ModelAbstract object,
                                                    DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarModelo(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestUnidadComercial(ModelAbstract object,
                                                    DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarUnidadComercial(object, item), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestComponentes(ModelAbstract object,
                                                DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMaterialMaletas(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestForro(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarTipoComposicionForro(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestAcabado(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAcabados(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestAccesorios(ModelAbstract object,
                                               DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAccesorios(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestAplicaciones(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestMedidas(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(object), lst);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestPresentacion(ModelAbstract object,
                                                 DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object, item).size(), 0);
  }

  @Test (dataProvider = "initDataEnlaceAduanero_146")
  public void enlaceAduanero_146TestPEso(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarPeso(object), lst);
  }

  @DataProvider (name = "initDataRapiaduanas_147")
  private Object[][] initDataRapiaduanas_147(){

    Maleta maleta  = new Maleta();
    DatoItem item = new DatoItem();

    DatoDescrMinima nombreProducto = new DatoDescrMinima();
    DatoDescrMinima marcaProducto  = new DatoDescrMinima();
    DatoDescrMinima modeloProducto = new DatoDescrMinima();
    DatoDescrMinima tip1Composicion = new DatoDescrMinima();
    DatoDescrMinima sub1Composicion = new DatoDescrMinima();
    DatoDescrMinima porcPrimComp   = new DatoDescrMinima();
    DatoDescrMinima tip2Composicion = new DatoDescrMinima();
    DatoDescrMinima sub2Composicion = new DatoDescrMinima();
    DatoDescrMinima porcSegComp    = new DatoDescrMinima();
    DatoDescrMinima tip3Composicion = new DatoDescrMinima();
    DatoDescrMinima sub3Composicion = new DatoDescrMinima();
    DatoDescrMinima porcTerComp    = new DatoDescrMinima();
    DatoDescrMinima forro          = new DatoDescrMinima();
    DatoDescrMinima acabado        = new DatoDescrMinima();
    DatoDescrMinima accesorio      = new DatoDescrMinima();
    DatoDescrMinima cantAccesorio  = new DatoDescrMinima();
    DatoDescrMinima aplicacion     = new DatoDescrMinima();
    DatoDescrMinima cantAplicacion = new DatoDescrMinima();
    DatoDescrMinima medidas        = new DatoDescrMinima();
    DatoDescrMinima presentacion   = new DatoDescrMinima();
    DatoDescrMinima peso           = new DatoDescrMinima();

    nombreProducto.setCodtipvalor(CATALOGO);
    nombreProducto.setCodtipdescr("MA0000");
    nombreProducto.setValtipdescri("027");

    marcaProducto.setCodtipvalor(CATALOGO);
    marcaProducto.setCodtipdescr("MA0001");
    marcaProducto.setValtipdescri("SAMSONITE");

    modeloProducto.setCodtipvalor(TEXTO);
    modeloProducto.setCodtipdescr("MA0002");
    modeloProducto.setValtipdescri("B-LITE");

    tip1Composicion.setCodtipvalor(CATALOGO);
    tip1Composicion.setCodtipdescr("MA0003");
    tip1Composicion.setValtipdescri("003");

    sub1Composicion.setCodtipvalor(CATALOGO);
    sub1Composicion.setCodtipdescr("MA0004");
    sub1Composicion.setValtipdescri("301");

    porcPrimComp.setCodtipvalor(TEXTO);
    porcPrimComp.setCodtipdescr("MA0005");
    porcPrimComp.setValtipdescri("0");

    tip2Composicion.setCodtipvalor(CATALOGO);
    tip2Composicion.setCodtipdescr("MA0006");
    tip2Composicion.setValtipdescri("003");

    sub2Composicion.setCodtipvalor(CATALOGO);
    sub2Composicion.setCodtipdescr("MA0007");
    sub2Composicion.setValtipdescri("302");

    porcSegComp.setCodtipvalor(TEXTO);
    porcSegComp.setCodtipdescr("MA0008");
    porcSegComp.setValtipdescri("50");

    tip3Composicion.setCodtipvalor(CATALOGO);
    tip3Composicion.setCodtipdescr("MA0009");
    tip3Composicion.setValtipdescri("002");

    sub3Composicion.setCodtipvalor(CATALOGO);
    sub3Composicion.setCodtipdescr("MA0010");
    sub3Composicion.setValtipdescri("208");

    porcTerComp.setCodtipvalor(TEXTO);
    porcTerComp.setCodtipdescr("MA0011");
    porcTerComp.setValtipdescri("50");

    forro.setCodtipvalor(CATALOGO);
    forro.setCodtipdescr("MA0014");
    forro.setValtipdescri("007");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("MA0013");
    acabado.setValtipdescri("010");

    accesorio.setCodtipvalor(TEXTO);
    accesorio.setCodtipdescr("MA0015");
    accesorio.setValtipdescri("Candado");

    cantAccesorio.setCodtipvalor(TEXTO);
    cantAccesorio.setCodtipdescr("MA0016");
    cantAccesorio.setValtipdescri("1");

    aplicacion.setCodtipvalor(CATALOGO);
    aplicacion.setCodtipdescr("MA0021");
    aplicacion.setValtipdescri("003");

    cantAplicacion.setCodtipvalor(TEXTO);
    cantAplicacion.setCodtipdescr("MA0022");
    cantAplicacion.setValtipdescri("2");

    medidas.setCodtipvalor(TEXTO);
    medidas.setCodtipdescr("MA0017");
    medidas.setValtipdescri("22.0''");

    presentacion.setCodtipvalor(TEXTO);
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("7 piezas"); //7 piezas no existe en el catalogo

    peso.setCodtipvalor(TEXTO);
    peso.setCodtipdescr("MA0019");
    peso.setValtipdescri("300.00");

    item.setCodunidcomer("SET");
    item.setNumpartnandi(new Long(420212100));

    maleta.setNombreComercial(nombreProducto);
    maleta.setMarcaComercial(marcaProducto);
    maleta.setModelo(modeloProducto);
    maleta.setTipo1erComp(tip1Composicion);
    maleta.setSubTipo1erComp(sub1Composicion);
    maleta.setPorcentaje1erComp(porcPrimComp);
    maleta.setTipo2doComp(tip2Composicion);
    maleta.setSubTipo2doComp(sub2Composicion);
    maleta.setPorcentaje2doComp(porcSegComp);
    maleta.setTipo3erComp(tip3Composicion);
    maleta.setSubTipo3erComp(sub3Composicion);
    maleta.setPorcentaje3erComp(porcTerComp);
    maleta.setComposicionForro(forro);
    maleta.setPrimerAcabado(acabado);
    maleta.setPrimerAccesorio(accesorio);
    maleta.setCantidad1erAccesorio(cantAccesorio);
    maleta.setPrimeraAplicacion(aplicacion);
    maleta.setCantidad1erAplicacion(cantAplicacion);
    maleta.setMedidas(medidas);
    maleta.setPresentacion(presentacion);
    maleta.setPeso(peso);

    return new Object[][]{{ maleta, item }};
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestNombreComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarNombreComercial(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestMarcaComercial(ModelAbstract object,
                                                DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMarcaComercial(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestModeloComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarModelo(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestUnidadComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarUnidadComercial(object, item), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestComponentes(ModelAbstract object,
                                             DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMaterialMaletas(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestForro(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarTipoComposicionForro(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestAcabado(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAcabados(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestAccesorios(ModelAbstract object,
                                            DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAccesorios(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestAplicaciones(ModelAbstract object,
                                              DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestMedidas(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestPresentacion(ModelAbstract object,
                                              DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object, item).size(), 0);
  }

  @Test (dataProvider = "initDataRapiaduanas_147")
  public void rapiAduanas_147TestPEso(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarPeso(object), lst);
  }

  @DataProvider (name = "initDataRapiaduanas_148")
  private Object[][] initDataRapiAduanas_148(){

    Maleta   maleta  = new Maleta();
    DatoItem item    = new DatoItem();

    DatoDescrMinima nombreProducto  = new DatoDescrMinima();
    DatoDescrMinima marcaProducto   = new DatoDescrMinima();
    DatoDescrMinima modeloProducto  = new DatoDescrMinima();
    DatoDescrMinima tipo1Material   = new DatoDescrMinima();
    DatoDescrMinima sub1Material    = new DatoDescrMinima();
    DatoDescrMinima porc1Material   = new DatoDescrMinima();
    DatoDescrMinima tipo2Material   = new DatoDescrMinima();
    DatoDescrMinima sub2Marerial    = new DatoDescrMinima();
    DatoDescrMinima porc2Material   = new DatoDescrMinima();
    DatoDescrMinima forro           = new DatoDescrMinima();
    DatoDescrMinima acabado         = new DatoDescrMinima();
    DatoDescrMinima accesorio       = new DatoDescrMinima();
    DatoDescrMinima cantAccesorio   = new DatoDescrMinima();
    DatoDescrMinima aplicacion      = new DatoDescrMinima();
    DatoDescrMinima cantAplicacion  = new DatoDescrMinima();
    DatoDescrMinima medidas         = new DatoDescrMinima();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoDescrMinima peso            = new DatoDescrMinima();

    nombreProducto.setCodtipvalor(CATALOGO);
    nombreProducto.setCodtipdescr("MA0000");
    nombreProducto.setCodtipdescr("004");

    marcaProducto.setCodtipvalor(TEXTO);
    marcaProducto.setCodtipdescr("MA0001");
    marcaProducto.setValtipdescri("CREPIER");

    modeloProducto.setCodtipvalor(TEXTO);
    modeloProducto.setCodtipdescr("MA0002");
    modeloProducto.setValtipdescri("Alfa");

    tipo1Material.setCodtipvalor(CATALOGO);
    tipo1Material.setCodtipdescr("MA0003");
    tipo1Material.setValtipdescri("003");

    sub1Material.setCodtipvalor(CATALOGO);
    sub1Material.setCodtipdescr("MA0004");
    sub1Material.setValtipdescri("301");

    porc1Material.setCodtipvalor(TEXTO);
    porc1Material.setCodtipdescr("MA0005");
    porc1Material.setValtipdescri("50");

    tipo2Material.setCodtipvalor(CATALOGO);
    tipo2Material.setCodtipdescr("MA0006");
    tipo2Material.setValtipdescri("002");

    sub2Marerial.setCodtipvalor(CATALOGO);
    sub2Marerial.setCodtipdescr("MA0007");
    sub2Marerial.setValtipdescri("208");

    porc2Material.setCodtipvalor(TEXTO);
    porc2Material.setCodtipdescr("MA0008");
    porc2Material.setValtipdescri("60");

    forro.setCodtipvalor(CATALOGO);
    forro.setCodtipdescr("MA0012");
    forro.setValtipdescri("007");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("MA0013");
    acabado.setValtipdescri("010");

    accesorio.setCodtipvalor(CATALOGO);
    accesorio.setCodtipdescr("MA0015");
    accesorio.setValtipdescri("001");

    cantAccesorio.setCodtipvalor(TEXTO);
    cantAccesorio.setCodtipdescr("MA0016");
    cantAccesorio.setValtipdescri("1");

    aplicacion.setCodtipvalor(CATALOGO);
    aplicacion.setCodtipdescr("MA0021");
    aplicacion.setValtipdescri("003");

    cantAplicacion.setCodtipvalor(TEXTO);
    cantAplicacion.setCodtipdescr("MA0022");
    cantAplicacion.setValtipdescri("2");

    medidas.setCodtipvalor(TEXTO);
    medidas.setCodtipdescr("MA0017");
    medidas.setValtipdescri("10.0''x18.0''x5.0''");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("003");

    peso.setCodtipvalor(TEXTO);
    peso.setCodtipdescr("MA0019");
    peso.setValtipdescri("100.00");

    item.setNumpartnandi(new Long(4202220000L));
    item.setCodunidcomer("SET");

    maleta.setNombreComercial(nombreProducto);
    maleta.setMarcaComercial(marcaProducto);
    maleta.setModelo(modeloProducto);
    maleta.setTipo1erComp(tipo1Material);
    maleta.setSubTipo1erComp(sub1Material);
    maleta.setPorcentaje1erComp(porc1Material);
    maleta.setTipo2doComp(tipo2Material);
    maleta.setSubTipo2doComp(sub2Marerial);
    maleta.setPorcentaje2doComp(porc2Material);
    maleta.setComposicionForro(forro);
    maleta.setPrimerAcabado(acabado);
    maleta.setPrimeraAplicacion(aplicacion);
    maleta.setCantidad1erAplicacion(cantAplicacion);
    maleta.setPrimerAccesorio(accesorio);
    maleta.setCantidad1erAccesorio(cantAccesorio);
    maleta.setMedidas(medidas);
    maleta.setPresentacion(presentacion);
    maleta.setPeso(peso);

    return new Object[][]{{ maleta, item }};
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestNombreComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarNombreComercial(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestMarcaComercial(ModelAbstract object,
                                                DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMarcaComercial(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestModeloComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarModelo(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestUnidadComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarUnidadComercial(object, item), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestComponentes(ModelAbstract object,
                                             DatoItem item){
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31116",
    //      "La suma de los porcentajes de tipo de material de superficie exterior" +
    // " debe ser 100% en las descripciones mínimas de maletas, " +
    //      "mochilas, bolsos en el Formato B");
    //    lst.add(error);
    Assert.assertEquals(validador.validarMaterialMaletas(object).size(), 1);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestForro(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarTipoComposicionForro(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestAcabado(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAcabados(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestAccesorios(ModelAbstract object,
                                            DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAccesorios(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestAplicaciones(ModelAbstract object,
                                              DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestMedidas(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestPresentacion(ModelAbstract object,
                                              DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object, item).size(), 0);
  }

  @Test (dataProvider = "initDataRapiaduanas_148")
  public void rapiAduanas_148TestPEso(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarPeso(object), lst);
  }

  @DataProvider ( name = "initDataRapiaduanas_149" )
  private Object[][] initDataRapiaduanas_149(){

    Maleta maleta = new Maleta();
    DatoItem item = new DatoItem();

    DatoDescrMinima nombreProducto  = new DatoDescrMinima();
    DatoDescrMinima marcaProducto   = new DatoDescrMinima();
    DatoDescrMinima modeloProducto  = new DatoDescrMinima();
    DatoDescrMinima tipo1Material   = new DatoDescrMinima();
    DatoDescrMinima subTipo1Material = new DatoDescrMinima();
    DatoDescrMinima porc1Material   = new DatoDescrMinima();
    DatoDescrMinima tipo2Material   = new DatoDescrMinima();
    DatoDescrMinima subTipo2Material = new DatoDescrMinima();
    DatoDescrMinima porc2Material   = new DatoDescrMinima();
    DatoDescrMinima forro           = new DatoDescrMinima();
    DatoDescrMinima acabado         = new DatoDescrMinima();
    DatoDescrMinima accesorio       = new DatoDescrMinima();
    DatoDescrMinima cantAccesorio   = new DatoDescrMinima();
    DatoDescrMinima aplicacion      = new DatoDescrMinima();
    DatoDescrMinima cantAplicacion  = new DatoDescrMinima();
    DatoDescrMinima medidas         = new DatoDescrMinima();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoDescrMinima peso            = new DatoDescrMinima();

    nombreProducto.setCodtipvalor(CATALOGO);
    nombreProducto.setCodtipdescr("MA0000");
    nombreProducto.setValtipdescri("027");

    marcaProducto.setCodtipvalor(TEXTO);
    marcaProducto.setCodtipdescr("MA0001");
    marcaProducto.setValtipdescri("SAMSONITE");

    modeloProducto.setCodtipvalor(TEXTO);
    modeloProducto.setCodtipdescr("MA0002");
    modeloProducto.setValtipdescri("B-LITE");

    tipo1Material.setCodtipvalor(CATALOGO);
    tipo1Material.setCodtipdescr("MA0003");
    tipo1Material.setValtipdescri("003");

    subTipo1Material.setCodtipvalor(CATALOGO);
    subTipo1Material.setCodtipdescr("MA0004");
    subTipo1Material.setValtipdescri("301");

    porc1Material.setCodtipvalor(TEXTO);
    porc1Material.setCodtipdescr("MA0005");
    porc1Material.setValtipdescri("50");

    tipo2Material.setCodtipvalor(CATALOGO);
    tipo2Material.setCodtipdescr("MA0006");
    tipo2Material.setValtipdescri("002");

    subTipo2Material.setCodtipvalor(CATALOGO);
    subTipo2Material.setCodtipdescr("MA0007");
    subTipo2Material.setValtipdescri("208");

    porc2Material.setCodtipvalor(TEXTO);
    porc2Material.setCodtipdescr("MA0008");
    porc2Material.setValtipdescri("50");

    forro.setCodtipvalor(CATALOGO);
    forro.setCodtipdescr("MA0012");
    forro.setValtipdescri("007");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("MA0013");
    acabado.setValtipdescri("010");

    accesorio.setCodtipvalor(TEXTO);
    accesorio.setCodtipdescr("MA0015");
    accesorio.setValtipdescri("Candado");

    cantAccesorio.setCodtipvalor(TEXTO);
    cantAccesorio.setCodtipdescr("MA0016");
    cantAccesorio.setValtipdescri("1");

    aplicacion.setCodtipvalor(CATALOGO);
    aplicacion.setCodtipdescr("MA0021");
    aplicacion.setValtipdescri("003");

    cantAplicacion.setCodtipvalor(TEXTO);
    cantAplicacion.setCodtipdescr("MA0022");
    cantAplicacion.setValtipdescri("5");

    medidas.setCodtipvalor(TEXTO);
    medidas.setCodtipdescr("MA0017");
    medidas.setValtipdescri("22.0\"");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("");

    peso.setCodtipvalor(TEXTO);
    peso.setCodtipdescr("MA0019");
    peso.setValtipdescri("300.00");

    item.setCodunidcomer("SET");
    item.setNumpartnandi(new Long(42021210000L));

    maleta.setNombreComercial(nombreProducto);
    maleta.setMarcaComercial(marcaProducto);
    maleta.setModelo(modeloProducto);
    maleta.setTipo1erComp(tipo1Material);
    maleta.setTipo2doComp(tipo2Material);
    maleta.setSubTipo1erComp(subTipo1Material);
    maleta.setSubTipo2doComp(subTipo2Material);
    maleta.setPorcentaje1erComp(porc1Material);
    maleta.setPorcentaje2doComp(porc2Material);
    maleta.setComposicionForro(forro);
    maleta.setPrimerAcabado(acabado);
    maleta.setPrimerAccesorio(accesorio);
    maleta.setCantidad1erAccesorio(cantAccesorio);
    maleta.setPrimeraAplicacion(aplicacion);
    maleta.setCantidad1erAplicacion(cantAplicacion);
    maleta.setMedidas(medidas);
    maleta.setPresentacion(presentacion);
    maleta.setPeso(peso);

    return new Object[][]{{ maleta, item }};
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestNombreComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarNombreComercial(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestMarcaComercial(ModelAbstract object,
                                                DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMarcaComercial(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestModeloComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarModelo(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestUnidadComercial(ModelAbstract object,
                                                 DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarUnidadComercial(object, item), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestComponentes(ModelAbstract object,
                                             DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMaterialMaletas(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestForro(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarTipoComposicionForro(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestAcabado(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAcabados(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestAccesorios(ModelAbstract object,
                                            DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAccesorios(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestAplicaciones(ModelAbstract object,
                                              DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestMedidas(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(object), lst);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestPresentacion(ModelAbstract object,
                                              DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object, item).size(), 1);
  }

  @Test (dataProvider = "initDataRapiaduanas_149")
  public void rapiAduanas_149TestPEso(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarPeso(object), lst);
  }

  /*
   * Tests validarUnidadComercialMaletas
   */
  @DataProvider(name = "initDataValidarUnidadComercialMaletasSinDatos")
  private Object[][] initDataValidarUnidadComercialMaletasSinDatos(){
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    nombreComercial.setNumcorredoc(new Long(1));
    nombreComercial.setNumsecfact(1);
    nombreComercial.setNumsecitem(1);
    nombreComercial.setNumsecprove(1);
    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("001");

    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);
    maleta.setNombreComercial(nombreComercial);

    return new Object[][] { { maleta,dua } };
  }

  @DataProvider(name = "initDataValidarUnidadComercialMaletasInvalidas")
  private Object[][] initDataValidarUnidadComercialMaletasInvalidas(){
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    nombreComercial.setNumcorredoc(new Long(1));
    nombreComercial.setNumsecfact(1);
    nombreComercial.setNumsecitem(1);
    nombreComercial.setNumsecprove(1);
    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("001");

    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("J");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);
    maleta.setNombreComercial(nombreComercial);

    return new Object[][] { { maleta,dua } };
  }

  @DataProvider(name = "initDataValidarUnidadComercialMaletas")
  private Object[][] initDataValidarUnidadComercialMaletas(){
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    nombreComercial.setNumcorredoc(new Long(1));
    nombreComercial.setNumsecfact(1);
    nombreComercial.setNumsecitem(1);
    nombreComercial.setNumsecprove(1);

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("001");

    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("set");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);
    maleta.setNombreComercial(nombreComercial);
    return new Object[][] { { maleta,dua } };
  }

  @Test(dataProvider = "initDataValidarUnidadComercialMaletasSinDatos")
  public void testValidarUnidadComercialMaletasSinDatos(ModelAbstract object,
                                                        Declaracion dua){
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0)
        .getListItems().get(0);
    Assert.assertEquals(validador.validarUnidadComercial(object,item).size(), 1);
  }

  @Test(dataProvider = "initDataValidarUnidadComercialMaletasInvalidas")
  public void testValidarUnidadComercialMaletasInvalidas(ModelAbstract object,
                                                         Declaracion dua){
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0)
        .getListItems().get(0);
    Assert.assertEquals(validador.validarUnidadComercial(object,item).size(), 1);
  }
  @Test(dataProvider = "initDataValidarUnidadComercialMaletas")
  public void testValidarUnidadComercialMaletas(ModelAbstract object,
                                                Declaracion dua){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0)
        .getListItems().get(0);
    Assert.assertEquals(validador.validarUnidadComercial(object,item), lst);
  }

  /*
   * Tests validarNombreComercial
   */
  @DataProvider(name = "initDataValidarNombreComercialSinDatos")
  public Object[][] initDataValidarNombreComercialSinDatos(){
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    maleta.setNombreComercial(nombreComercial);
    return new Object[][] { { maleta } };
  }

  @DataProvider(name = "initDataValidarNombreComercialInvalido")
  public Object[][] initDataValidarNombreComercialInvalido(){
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("554");
    maleta.setNombreComercial(nombreComercial);
    return new Object[][] { { maleta } };
  }

  @DataProvider(name = "initDataValidarNombreComercial")
  public Object[][] initDataValidarNombreComercial(){
    Maleta maleta = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    nombreComercial.setCodtipvalor("0");
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("033");
    maleta.setNombreComercial(nombreComercial);
    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidarNombreComercialInvalido")
  public void testValidarNombreComercialMaletasInvalido(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarNombreComercial(object), lst);
  }

  @Test(dataProvider = "initDataValidarNombreComercial")
  public void testValidarNombreComercialMaletas(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarNombreComercial(object), lst);
  }
  /*
   * Tests validarMateriales
   */

  @DataProvider(name = "initDataValidar1erMaterial")
  public Object[][] initDataValidar1erMaterial(){
    Maleta maleta                        = new Maleta();
    DatoDescrMinima primerMaterial       = new DatoDescrMinima();
    DatoDescrMinima tipo1erMaterial      = new DatoDescrMinima();
    DatoDescrMinima porcentaje1erMaterial= new DatoDescrMinima();
    DatoDescrMinima subTipo1erMaterial   = new DatoDescrMinima();

    tipo1erMaterial.setCodtipvalor(CATALOGO);
    tipo1erMaterial.setCodtipdescr("MA0003");
    tipo1erMaterial.setValtipdescri("001");
    subTipo1erMaterial.setCodtipvalor(CATALOGO);
    subTipo1erMaterial.setCodtipdescr("MA0004");
    subTipo1erMaterial.setValtipdescri("105");
    porcentaje1erMaterial.setCodtipvalor(TEXTO);
    porcentaje1erMaterial.setCodtipdescr("MA0005");
    porcentaje1erMaterial.setValtipdescri("100");

    maleta.setNombreComercial(primerMaterial);
    maleta.setTipo1erComp(tipo1erMaterial);
    maleta.setSubTipo1erComp(subTipo1erMaterial);
    maleta.setPorcentaje1erComp(porcentaje1erMaterial);

    return new Object[][] { { maleta } };
  }
  @Test(dataProvider = "initDataValidar1erMaterial")
  public void testValidar1erMaterial(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMaterialMaletas(object), lst);
  }

  @DataProvider(name = "initDataValidar2doMaterialSumaIncorrecta")
  public Object[][] initDataValidar2doMaterialSumaIncorrecta(){
    Maleta maleta                        = new Maleta();
    DatoDescrMinima tipo1erMaterial      = new DatoDescrMinima();
    DatoDescrMinima porcentaje1erMaterial= new DatoDescrMinima();
    DatoDescrMinima subTipo1erMaterial   = new DatoDescrMinima();
    DatoDescrMinima tipo2doMaterial      = new DatoDescrMinima();
    DatoDescrMinima subTipo2doMaterial   = new DatoDescrMinima();
    DatoDescrMinima porcentaje2doMaterial= new DatoDescrMinima();

    tipo1erMaterial.setCodtipvalor(CATALOGO);
    tipo1erMaterial.setCodtipdescr("MA0003");
    tipo1erMaterial.setValtipdescri("001");
    subTipo1erMaterial.setCodtipvalor(CATALOGO);
    subTipo1erMaterial.setCodtipdescr("MA0004");
    subTipo1erMaterial.setValtipdescri("105");
    porcentaje1erMaterial.setCodtipvalor(TEXTO);
    porcentaje1erMaterial.setCodtipdescr("MA0005");
    porcentaje1erMaterial.setValtipdescri("100");
    tipo2doMaterial.setCodtipvalor(CATALOGO);
    tipo2doMaterial.setCodtipdescr("MA0006");
    tipo2doMaterial.setValtipdescri("002");
    porcentaje2doMaterial.setCodtipvalor(CATALOGO);
    porcentaje2doMaterial.setCodtipdescr("MA0007");
    porcentaje2doMaterial.setValtipdescri("100");
    subTipo2doMaterial.setCodtipvalor(CATALOGO);
    subTipo2doMaterial.setCodtipdescr("MA0008");
    subTipo2doMaterial.setValtipdescri("201");

    maleta.setTipo1erComp(tipo1erMaterial);
    maleta.setSubTipo1erComp(subTipo1erMaterial);
    maleta.setPorcentaje1erComp(porcentaje1erMaterial);
    maleta.setTipo2doComp(tipo2doMaterial);
    maleta.setSubTipo2doComp(subTipo2doMaterial);
    maleta.setPorcentaje2doComp(porcentaje2doMaterial);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidar2doMaterialSumaIncorrecta")
  public void testValidar2doMaterialSumaIncorrecta(ModelAbstract object){
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima("31116",
    //                             "La suma de los porcentajes de tipo de " +
    //                             "material de superficie exterior debe ser " +
    // "100% en las descripciones mínimas de maletas, " +
    //                             "mochilas, bolsos en el Formato B");
    //    lst.add(error);
    Assert.assertEquals(validador.validarMaterialMaletas(object).size(), 1);
  }

  @DataProvider(name = "initDataValidar2doMaterial")
  public Object[][] initDataValidar2doMaterial(){
    Maleta maleta                        = new Maleta();
    DatoDescrMinima tipo1erMaterial      = new DatoDescrMinima();
    DatoDescrMinima porcentaje1erMaterial= new DatoDescrMinima();
    DatoDescrMinima subTipo1erMaterial   = new DatoDescrMinima();
    DatoDescrMinima tipo2doMaterial      = new DatoDescrMinima();
    DatoDescrMinima subTipo2doMaterial   = new DatoDescrMinima();
    DatoDescrMinima porcentaje2doMaterial= new DatoDescrMinima();

    tipo1erMaterial.setCodtipvalor(CATALOGO);
    tipo1erMaterial.setCodtipdescr("MA0003");
    tipo1erMaterial.setValtipdescri("001");
    subTipo1erMaterial.setCodtipvalor(CATALOGO);
    subTipo1erMaterial.setCodtipdescr("MA0004");
    subTipo1erMaterial.setValtipdescri("105");
    porcentaje1erMaterial.setCodtipvalor(TEXTO);
    porcentaje1erMaterial.setCodtipdescr("MA0005");
    porcentaje1erMaterial.setValtipdescri("45");
    tipo2doMaterial.setCodtipvalor(CATALOGO);
    tipo2doMaterial.setCodtipdescr("MA0006");
    tipo2doMaterial.setValtipdescri("002");
    porcentaje2doMaterial.setCodtipvalor(TEXTO);
    porcentaje2doMaterial.setCodtipdescr("MA0007");
    porcentaje2doMaterial.setValtipdescri("55");
    subTipo2doMaterial.setCodtipvalor(CATALOGO);
    subTipo2doMaterial.setCodtipdescr("MA0008");
    subTipo2doMaterial.setValtipdescri("201");

    maleta.setTipo1erComp(tipo1erMaterial);
    maleta.setSubTipo1erComp(subTipo1erMaterial);
    maleta.setPorcentaje1erComp(porcentaje1erMaterial);
    maleta.setTipo2doComp(tipo2doMaterial);
    maleta.setSubTipo2doComp(subTipo2doMaterial);
    maleta.setPorcentaje2doComp(porcentaje2doMaterial);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidar2doMaterial")
  public void testValidar2doMaterial(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMaterialMaletas(object), lst);
  }

  @DataProvider(name = "initDataValidar3erMaterialSinPorcentaje")
  public Object[][] initDataValidar3erMaterialSinPorcentaje(){
    Maleta maleta               = new Maleta();
    DatoDescrMinima tipo1erMaterial      = new DatoDescrMinima();
    DatoDescrMinima porcentaje1erMaterial= new DatoDescrMinima();
    DatoDescrMinima subTipo1erMaterial   = new DatoDescrMinima();
    DatoDescrMinima tipo2doMaterial      = new DatoDescrMinima();
    DatoDescrMinima subTipo2doMaterial   = new DatoDescrMinima();
    DatoDescrMinima porcentaje2doMaterial= new DatoDescrMinima();
    DatoDescrMinima tipo3erMaterial      = new DatoDescrMinima();
    DatoDescrMinima subTipo3erMaterial   = new DatoDescrMinima();
    DatoDescrMinima porcentaje3erMaterial= new DatoDescrMinima();

    tipo1erMaterial.setCodtipvalor(CATALOGO);
    tipo1erMaterial.setCodtipdescr("MA0003");
    tipo1erMaterial.setValtipdescri("001");
    subTipo1erMaterial.setCodtipvalor(CATALOGO);
    subTipo1erMaterial.setCodtipdescr("MA0004");
    subTipo1erMaterial.setValtipdescri("105");
    porcentaje1erMaterial.setCodtipvalor(TEXTO);
    porcentaje1erMaterial.setCodtipdescr("MA0005");
    porcentaje1erMaterial.setValtipdescri("50");
    tipo2doMaterial.setCodtipvalor(CATALOGO);
    tipo2doMaterial.setCodtipdescr("MA0006");
    tipo2doMaterial.setValtipdescri("002");
    porcentaje2doMaterial.setCodtipvalor(CATALOGO);
    porcentaje2doMaterial.setCodtipdescr("MA0008");
    porcentaje2doMaterial.setValtipdescri("50");
    subTipo2doMaterial.setCodtipvalor(CATALOGO);
    subTipo2doMaterial.setCodtipdescr("MA0007");
    subTipo2doMaterial.setValtipdescri("201");
    tipo3erMaterial.setCodtipvalor(CATALOGO);
    tipo3erMaterial.setCodtipdescr("MA0009");
    tipo3erMaterial.setValtipdescri("002");
    subTipo3erMaterial.setCodtipvalor(CATALOGO);
    subTipo3erMaterial.setCodtipdescr("MA0010");
    subTipo3erMaterial.setValtipdescri("203");
    porcentaje3erMaterial.setCodtipvalor(TEXTO);
    porcentaje3erMaterial.setCodtipdescr("MA0011");
    porcentaje3erMaterial.setValtipdescri("");

    maleta.setTipo1erComp(tipo1erMaterial);
    maleta.setSubTipo1erComp(subTipo1erMaterial);
    maleta.setPorcentaje1erComp(porcentaje1erMaterial);
    maleta.setTipo2doComp(tipo2doMaterial);
    maleta.setSubTipo2doComp(subTipo2doMaterial);
    maleta.setPorcentaje2doComp(porcentaje2doMaterial);
    maleta.setTipo3erComp(tipo3erMaterial);
    maleta.setSubTipo3erComp(subTipo3erMaterial);
    maleta.setPorcentaje3erComp(porcentaje3erMaterial);

    return new Object[][] { { maleta } };
  }
  @Test(dataProvider = "initDataValidar3erMaterialSinPorcentaje")
  public void testValidar3erMaterialSinPorcentaje(ModelAbstract object){
    //    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    //    ErrorDescrMinima error = new ErrorDescrMinima( "31115",
    //                             "Debe enviar porcentaje de tipo de material " +
    //                             "del tercer componente de superficie exterior " +
    // "en las descripciones mínimas de maletas, " +
    //                             "mochilas, bolsos en el Formato B");
    //    lst.add(error);
    Assert.assertEquals(validador.validarMaterialMaletas(object).size(), 1);
  }
 
  @DataProvider(name = "initDataValidar3erMaterialOtros")
  public Object[][] initDataValidar3erMaterialOtros(){
    Maleta maleta                        = new Maleta();
    DatoDescrMinima tipo1erMaterial      = new DatoDescrMinima();
    DatoDescrMinima porcentaje1erMaterial= new DatoDescrMinima();
    DatoDescrMinima subTipo1erMaterial   = new DatoDescrMinima();
    DatoDescrMinima tipo2doMaterial      = new DatoDescrMinima();
    DatoDescrMinima subTipo2doMaterial   = new DatoDescrMinima();
    DatoDescrMinima porcentaje2doMaterial= new DatoDescrMinima();
    DatoDescrMinima tipo3erMaterial      = new DatoDescrMinima();
    DatoDescrMinima subTipo3erMaterial   = new DatoDescrMinima();
    DatoDescrMinima porcentaje3erMaterial= new DatoDescrMinima();

    tipo1erMaterial.setCodtipvalor(CATALOGO);
    tipo1erMaterial.setCodtipdescr("MA0003");
    tipo1erMaterial.setValtipdescri("001");

    subTipo1erMaterial.setCodtipvalor(CATALOGO);
    subTipo1erMaterial.setCodtipdescr("MA0004");
    subTipo1erMaterial.setValtipdescri("105");

    porcentaje1erMaterial.setCodtipvalor(TEXTO);
    porcentaje1erMaterial.setCodtipdescr("MA0005");
    porcentaje1erMaterial.setValtipdescri("40");

    tipo2doMaterial.setCodtipvalor(CATALOGO);
    tipo2doMaterial.setCodtipdescr("MA0006");
    tipo2doMaterial.setValtipdescri("002");

    porcentaje2doMaterial.setCodtipvalor(CATALOGO);
    porcentaje2doMaterial.setCodtipdescr("MA0007");
    porcentaje2doMaterial.setValtipdescri("30");

    subTipo2doMaterial.setCodtipvalor(CATALOGO);
    subTipo2doMaterial.setCodtipdescr("MA0008");
    subTipo2doMaterial.setValtipdescri("201");

    tipo3erMaterial.setCodtipvalor(TEXTO);
    tipo3erMaterial.setCodtipdescr("MA0009");
    tipo3erMaterial.setValtipdescri("MATERIAL XXX");

    porcentaje3erMaterial.setCodtipvalor(TEXTO);
    porcentaje3erMaterial.setCodtipdescr("MA0010");
    porcentaje3erMaterial.setValtipdescri("003");

    subTipo3erMaterial.setCodtipvalor(TEXTO);
    subTipo3erMaterial.setCodtipdescr("MA0011");
    subTipo3erMaterial.setValtipdescri("");

    maleta.setTipo1erComp(tipo1erMaterial);
    maleta.setSubTipo1erComp(subTipo1erMaterial);
    maleta.setPorcentaje1erComp(porcentaje1erMaterial);
    maleta.setTipo2doComp(tipo2doMaterial);
    maleta.setSubTipo2doComp(subTipo2doMaterial);
    maleta.setPorcentaje2doComp(porcentaje2doMaterial);
    maleta.setTipo3erComp(tipo3erMaterial);
    maleta.setSubTipo3erComp(subTipo3erMaterial);
    maleta.setPorcentaje3erComp(porcentaje3erMaterial);

    return new Object[][] { { maleta } };
  }

  /*
   * Tests validarMedidasMaletas
   */
  @DataProvider(name = "initDataValidarMedidasMaletasSinDatos")
  public Object[][] initDataValidarMedidasMaletasSinDatos(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima medida          = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("027");
    medida.setCodtipvalor(TEXTO);
    medida.setCodtipdescr("MA0017");
    medida.setValtipdescri("");
    maleta.setNombreComercial(nombreComercial);
    maleta.setMedidas(medida);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidarMedidasMaletasSinDatos")
  public void testValidarMedidasMaletasSinDatos(ModelAbstract object){
    Assert.assertEquals(validador.validarMedidas(object).size(), 1);
  }

  @DataProvider(name = "initDataValidarMedidasMaletasAltoInvalido")
  public Object[][] initDataValidarMedidasMaletasAltoInvalido(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima medida          = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("027");
    medida.setCodtipvalor(TEXTO);
    medida.setCodtipdescr("MA0017");
    medida.setValtipdescri("1234567890");
    maleta.setNombreComercial(nombreComercial);
    maleta.setMedidas(medida);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidarMedidasMaletasAltoInvalido")
  public void testValidarMedidasMaletasAltoInvalido(ModelAbstract object){
    Assert.assertEquals(validador.validarMedidas(object).size(), 1);
  }

  @DataProvider(name = "initDataValidarMedidasMaletasAlto")
  public Object[][] initDataValidarMedidasMaletasAlto(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima medida          = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("027");
    medida.setCodtipvalor(TEXTO);
    medida.setCodtipdescr("MA0017");
    medida.setValtipdescri("999.9''");
    maleta.setNombreComercial(nombreComercial);
    maleta.setMedidas(medida);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidarMedidasMaletasAlto")
  public void testValidarMedidasMaletasAlto(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(object), lst);
  }

  @DataProvider(name = "initDataValidarMedidasSinDatos")
  public Object[][] initDataValidarMedidasSinDatos(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima medida          = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("028");
    medida.setCodtipvalor(TEXTO);
    medida.setCodtipdescr("MA0017");
    medida.setValtipdescri("");
    maleta.setNombreComercial(nombreComercial);
    maleta.setMedidas(medida);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidarMedidasSinDatos")
  public void testValidarMedidasSinDatos(ModelAbstract object){
    Assert.assertEquals(validador.validarMedidas(object).size(), 1);
  }

  @DataProvider(name = "initDataValidarMedidasInvalido")
  public Object[][] initDataValidarMedidasInvalido(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima medida          = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("028");
    medida.setCodtipvalor(TEXTO);
    medida.setCodtipdescr("MA0017");
    medida.setValtipdescri("999.9''x99.6542");
    maleta.setNombreComercial(nombreComercial);
    maleta.setMedidas(medida);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidarMedidasInvalido")
  public void testValidarMedidasInvalido(ModelAbstract object){
    Assert.assertEquals(validador.validarMedidas(object).size(), 1);
  }

  @DataProvider(name = "initDataValidarMedidas")
  public Object[][] initDataValidarMedidas(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima medida          = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("MA0000");
    nombreComercial.setValtipdescri("028");
    medida.setCodtipvalor(TEXTO);
    medida.setCodtipdescr("MA0017");
    medida.setValtipdescri("999.9''x99.6''x6.1''");
    maleta.setNombreComercial(nombreComercial);
    maleta.setMedidas(medida);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidarMedidas")
  public void testValidarMedidas(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarMedidas(object), lst);
  }

  /*
   * Tests validarPresentacion
   */
  @DataProvider(name = "initDataValidarPresentacionSETPresentacionVacia")
  public Object[][] initDataValidarPresentacionSETPresentacionVacia(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("");

    DatoItem item                   = new DatoItem();

    item.setCodunidcomer("SET");

    maleta.setPresentacion(presentacion);

    return new Object[][] { { maleta, item } };
  }

  @Test(dataProvider = "initDataValidarPresentacionSETPresentacionVacia")
  public void testValidarPresentacionSETPresentacionVacia(ModelAbstract object,
                                                          DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object,item).size(), 1);
  }

  @DataProvider(name = "initDataValidarPresentacionSETInvalido")
  public Object[][] initDataValidarPresentacionSETInvalido(){
    Maleta maleta = new Maleta();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoItem item                   = new DatoItem();

    item.setCodunidcomer("SET");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("001");

    maleta.setPresentacion(presentacion);

    return new Object[][] { { maleta, item } };
  }

  @Test(dataProvider = "initDataValidarPresentacionSETInvalido")
  public void testValidarPresentacionSETInvalido(ModelAbstract object,
                                                 DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object,item).size(), 0);
  }

  @DataProvider(name = "initDataValidarPresentacionSET")
  public Object[][] initDataValidarPresentacionSET(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoItem item                   = new DatoItem();

    item.setCodunidcomer("SET");

    presentacion.setCodtipvalor("0");
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("004");

    maleta.setPresentacion(presentacion);

    return new Object[][] { { maleta,item } };
  }

  @Test(dataProvider = "initDataValidarPresentacionSET")
  public void testValidarPresentacionSET(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object, item).size(), 0);
  }

  @DataProvider(name = "initDataValidarPresentacionOtroConDatos")
  public Object[][] initDataValidarPresentacionOtroConDatos(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoItem item                   = new DatoItem();

    item.setCodunidcomer("12U");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("MA0018");
    presentacion.setValtipdescri("004");

    maleta.setPresentacion(presentacion);

    return new Object[][] { { maleta, item } };
  }

  @Test(dataProvider = "initDataValidarPresentacionOtroConDatos")
  public void testValidarPresentacionOtroConDatos(ModelAbstract object,
                                                  DatoItem item){
    Assert.assertEquals(validador.validarPresentacion(object, item).size(), 1);
  }

  @DataProvider(name = "initDataValidarPresentacionOtro")
  public Object[][] initDataValidarPresentacionOtro(){
    Maleta maleta                   = new Maleta();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoItem item                   = new DatoItem();

    item.setCodunidcomer("12U");

    maleta.setPresentacion(presentacion);

    return new Object[][] { { maleta, item } };
  }

  @Test(dataProvider = "initDataValidarPresentacionOtro")
  public void testValidarPresentacionOtro(ModelAbstract object, DatoItem item){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarPresentacion(object,item), lst);
  }
  
  /*
   * Tests validarAplicacionesMaletas
   */
 

  @DataProvider(name = "initDataValidar2daAplicacionSinCantidad")
  public Object[][] initDataValidar2daAplicacionSinCantidad(){
    Maleta maleta                         = new Maleta();
    DatoDescrMinima primeraAplicacion     = new DatoDescrMinima();
    DatoDescrMinima cantidad1raAplicacion = new DatoDescrMinima();
    DatoDescrMinima segundaAplicacion     = new DatoDescrMinima();
    DatoDescrMinima cantidad2daAplicacion = new DatoDescrMinima();

    primeraAplicacion.setCodtipvalor(CATALOGO);
    primeraAplicacion.setCodtipdescr("MA0021");
    primeraAplicacion.setValtipdescri("010");
    cantidad1raAplicacion.setCodtipvalor(TEXTO);
    cantidad1raAplicacion.setCodtipdescr("MA0022");
    cantidad1raAplicacion.setValtipdescri("");

    segundaAplicacion.setCodtipvalor(CATALOGO);
    segundaAplicacion.setCodtipdescr("MA0023");
    segundaAplicacion.setValtipdescri("009");

    maleta.setPrimeraAplicacion(primeraAplicacion);
    maleta.setCantidad1erAplicacion(cantidad1raAplicacion);
    maleta.setSegundaAplicacion(segundaAplicacion);
    maleta.setCantidad2daAplicacion(cantidad2daAplicacion);
    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidar2daAplicacionSinCantidad")
  public void testValidar2daAplicacionSinCantidad(ModelAbstract object){
    Assert.assertEquals(validador.validarAplicaciones(object).size(), 1);
  }

  @DataProvider(name = "initDataValidar2daAplicacion")
  public Object[][] initDataValidar2daAplicacion(){
    Maleta maleta                         = new Maleta();
    DatoDescrMinima primeraAplicacion     = new DatoDescrMinima();
    DatoDescrMinima cantidad1raAplicacion = new DatoDescrMinima();
    DatoDescrMinima segundaAplicacion     = new DatoDescrMinima();
    DatoDescrMinima cantidad2daAplicacion = new DatoDescrMinima();

    primeraAplicacion.setCodtipvalor(CATALOGO);
    primeraAplicacion.setCodtipdescr("MA0021");
    primeraAplicacion.setValtipdescri("010");
    cantidad1raAplicacion.setCodtipvalor(TEXTO);
    cantidad1raAplicacion.setCodtipdescr("MA0022");
    cantidad1raAplicacion.setValtipdescri("50");

    segundaAplicacion.setCodtipvalor(CATALOGO);
    segundaAplicacion.setCodtipdescr("MA0023");
    segundaAplicacion.setValtipdescri("009");

    cantidad2daAplicacion.setCodtipvalor(TEXTO);
    cantidad2daAplicacion.setCodtipdescr("MA0024");
    cantidad2daAplicacion.setValtipdescri("50");

    maleta.setPrimeraAplicacion(primeraAplicacion);
    maleta.setCantidad1erAplicacion(cantidad1raAplicacion);
    maleta.setSegundaAplicacion(segundaAplicacion);
    maleta.setCantidad2daAplicacion(cantidad2daAplicacion);
    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidar2daAplicacion")
  public void testValidar2daAplicacion(ModelAbstract object){
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(validador.validarAplicaciones(object), lst);
  }


  @DataProvider(name = "initDataValidar3raAplicacionSinCantidad")
  public Object[][] initDataValidar3raAplicacionSinCantidad(){
    Maleta maleta = new Maleta();
    DatoDescrMinima primeraAplicacion     = new DatoDescrMinima();
    DatoDescrMinima cantidad1raAplicacion = new DatoDescrMinima();
    DatoDescrMinima segundaAplicacion     = new DatoDescrMinima();
    DatoDescrMinima cantidad2daAplicacion = new DatoDescrMinima();
    DatoDescrMinima terceraAplicacion     = new DatoDescrMinima();
    DatoDescrMinima cantidad3raAplicacion = new DatoDescrMinima();

    primeraAplicacion.setCodtipvalor(CATALOGO);
    primeraAplicacion.setCodtipdescr("MA0021");
    primeraAplicacion.setValtipdescri("010");
    cantidad1raAplicacion.setCodtipvalor(TEXTO);
    cantidad1raAplicacion.setCodtipdescr("MA0022");
    cantidad1raAplicacion.setValtipdescri("50");

    segundaAplicacion.setCodtipvalor(CATALOGO);
    segundaAplicacion.setCodtipdescr("MA0023");
    segundaAplicacion.setValtipdescri("009");

    cantidad2daAplicacion.setCodtipvalor(TEXTO);
    cantidad2daAplicacion.setCodtipdescr("MA0024");
    cantidad2daAplicacion.setValtipdescri("25");

    terceraAplicacion.setCodtipvalor(CATALOGO);
    terceraAplicacion.setCodtipdescr("MA0025");
    terceraAplicacion.setValtipdescri("003");
    cantidad3raAplicacion.setCodtipvalor(TEXTO);
    cantidad3raAplicacion.setCodtipdescr("MA0026");
    cantidad3raAplicacion.setValtipdescri("");

    maleta.setPrimeraAplicacion(primeraAplicacion);
    maleta.setCantidad1erAplicacion(cantidad1raAplicacion);
    maleta.setSegundaAplicacion(segundaAplicacion);
    maleta.setCantidad2daAplicacion(cantidad2daAplicacion);
    maleta.setTerceraAplicacion(terceraAplicacion);
    maleta.setCantidad3erAplicacion(cantidad3raAplicacion);

    return new Object[][] { { maleta } };
  }

  @Test(dataProvider = "initDataValidar3raAplicacionSinCantidad")
  public void testValidar3raAplicacionSinCantidad(ModelAbstract object){
    Assert.assertEquals(validador.validarAplicaciones(object).size(), 1);
  }
}