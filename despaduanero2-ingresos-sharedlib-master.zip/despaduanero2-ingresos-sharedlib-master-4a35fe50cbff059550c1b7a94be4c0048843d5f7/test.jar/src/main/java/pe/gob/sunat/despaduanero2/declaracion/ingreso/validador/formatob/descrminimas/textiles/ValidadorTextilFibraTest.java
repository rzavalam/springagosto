package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilFibra;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

/*
 * @author lalberti
 */
public class ValidadorTextilFibraTest extends AbstractServiceTest {
  @Autowired
  @Qualifier("ValidadorTextilFibra")
  private ValidadorTextilFibra validador = new ValidadorTextilFibra();
  private static final String CATALOGO = "0";
  private static final String TEXTO    = "1";


  @DataProvider (name="initDataDyG67")
  private Object[][] initDataDyG67(){

    TextilFibra fibra = new TextilFibra();
    DatoItem item     = new DatoItem();
    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    DatoDescrMinima nombreComercial   = new DatoDescrMinima();
    DatoDescrMinima marcaComercial    = new DatoDescrMinima();
    DatoDescrMinima modelo            = new DatoDescrMinima();
    DatoDescrMinima tipoFibra         = new DatoDescrMinima();
    DatoDescrMinima comp1Valor        = new DatoDescrMinima();
    DatoDescrMinima comp1Porcentaje   = new DatoDescrMinima();
    DatoDescrMinima comp2Valor        = new DatoDescrMinima();
    DatoDescrMinima comp2Porcentaje   = new DatoDescrMinima();
    DatoDescrMinima preparacion       = new DatoDescrMinima();
    DatoDescrMinima presentacion      = new DatoDescrMinima();
    DatoDescrMinima estructuraFisica  = new DatoDescrMinima();
    DatoDescrMinima claseYUso         = new DatoDescrMinima();
    DatoDescrMinima relacionFOB       = new DatoDescrMinima();
    DatoDescrMinima certificado       = new DatoDescrMinima();

    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    fibra.setNumcorredoc(new Long(1));
    fibra.setNumsecfact(1);
    fibra.setNumsecitem(1);
    fibra.setNumsecprove(1);

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();

    item.setNumpartnandi(new Long(58101360000L));
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("U");
    item.setCodestamer("99");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    //Fibra Artificial
    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("TE0100");
    nombreComercial.setValtipdescri("FBA");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("TE0101");
    marcaComercial.setValtipdescri("S/M");

    modelo.setCodtipvalor(TEXTO);
    modelo.setCodtipdescr("TE0102");
    modelo.setValtipdescri("S/M");

    //Filamento o fibra continua
    tipoFibra.setCodtipvalor(CATALOGO);
    tipoFibra.setCodtipdescr("TE0103");
    tipoFibra.setValtipdescri("FIL");

    //Poliester
    comp1Valor.setCodtipvalor(CATALOGO);
    comp1Valor.setCodtipdescr("TE0104");
    comp1Valor.setValtipdescri("PES");

    //50%
    comp1Porcentaje.setCodtipvalor(TEXTO);
    comp1Porcentaje.setCodtipdescr("TE0105");
    comp1Porcentaje.setValtipdescri("150");

    //Algodon
    comp2Valor.setCodtipvalor(CATALOGO);
    comp2Valor.setCodtipdescr("TE0106");
    comp2Valor.setValtipdescri("CO");

    //50%
    comp2Porcentaje.setCodtipvalor(TEXTO);
    comp2Porcentaje.setCodtipdescr("TE0107");
    comp2Porcentaje.setValtipdescri("50");

    //Texturizado
    preparacion.setCodtipvalor(CATALOGO);
    preparacion.setCodtipdescr("TE0108");
    preparacion.setValtipdescri("TEX");

    //Pacas
    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("TE0109");
    presentacion.setValtipdescri("PAC");

    estructuraFisica.setCodtipvalor(TEXTO);
    estructuraFisica.setCodtipdescr("TE0110");
    estructuraFisica.setValtipdescri("$#%&/");

    claseYUso.setCodtipvalor(TEXTO);
    claseYUso.setCodtipdescr("TE0111");
    claseYUso.setValtipdescri("\"#$%&/()");

    relacionFOB.setCodtipvalor(TEXTO);
    relacionFOB.setCodtipdescr("TE0112");
    relacionFOB.setValtipdescri("5");

    certificado.setCodtipvalor(TEXTO);
    certificado.setCodtipdescr("TE0113");
    certificado.setValtipdescri("");

    fibra.setRelacionFobUnitarioPesoNeto(relacionFOB);
//    fibra.setNumeroCertificado2daCalidad(certificado);
    fibra.setNombreComercial(nombreComercial);
    fibra.setMarcaComercial(marcaComercial);
    fibra.setModelo(modelo);
    fibra.setTipoFibra(tipoFibra);
    fibra.setCompoFibra1erComp(comp1Valor);
    fibra.setCompoFibraPorcen1erComp(comp1Porcentaje);
    fibra.setCompoFibra2doComp(comp2Valor);
    fibra.setCompoFibraPorcen2doComp(comp2Porcentaje);
    fibra.setPreparacion(preparacion);
    fibra.setPresentacion(presentacion);
    fibra.setEstructuraFisica(estructuraFisica);
    fibra.setClaseVariedadYUso(claseYUso);

    return new Object[][]{{fibra,dua}};
  }

  //  OJO PENDIENTE PORQUE NO SE PUDO REALIZAR LAS VALIDADICONES DEL METODO REFERENTE A GRUPOS
  //
  //  @Test (dataProvider = "initDataDyG67")
  // public void validarFOBVsPesoObs(ModelAbstract object,
  //                                            Declaracion dua){
  //    Assert.assertEquals(validador.validarFOBVsPesoObs(object, dua).size(),0);
  //  }

  @Test (dataProvider = "initDataDyG67")
  public void validarUnidaComercialInvalido(ModelAbstract object,
                                            Declaracion dua){
//    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
//    Assert.assertEquals(validador.validarUnidadComercial(object, item).get(0).getCodigo(),"31300");
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarNombreComercial(ModelAbstract object,
                                     Declaracion dua){
    Assert.assertEquals(validador.validarNombreComercial(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarMarcaComercial(ModelAbstract object,
                                    Declaracion dua){
    Assert.assertEquals(validador.validarMarcaComercial(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarModelo(ModelAbstract object,
                            Declaracion dua){
    Assert.assertEquals(validador.validarModelo(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarTipoFibra(ModelAbstract object,
                               Declaracion dua){
    Assert.assertEquals(validador.validarTipoFibra(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarCompo1erComponente(ModelAbstract object,
                                        Declaracion dua){
    Assert.assertEquals(validador.validarCompoFibra1erComp(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarCompo1erPorcentaje(ModelAbstract object,
                                        Declaracion dua){
    Assert.assertEquals(validador.validarCompoFibraPorcen1erComp(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarCompo2doComponente(ModelAbstract object,
                                        Declaracion dua){
    Assert.assertEquals(validador.validarCompoFibra2doComp(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarCompo2doPorcentaje(ModelAbstract object,
                                        Declaracion dua){
    Assert.assertEquals(validador.validarCompoFibraPorcen2doComp(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarPresentacion(ModelAbstract object,
                                  Declaracion dua){
    Assert.assertEquals(validador.validarPresentacion(object).size(),0);
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarEstructuraFisica(ModelAbstract object,
                                      Declaracion dua){
    Assert.assertEquals(validador.validarEstructuraFisica(object).get(0).getCodigo(),"31320");
  }

  @Test (dataProvider = "initDataDyG67")
  public void validarClaseYUso(ModelAbstract object,
                               Declaracion dua){
    Assert.assertEquals(validador.validarClaseYUso(object).get(0).getCodigo(),"31321");
  }

//  @Test (dataProvider = "initDataDyG67")
//  public void validarCertificadoCalidad(ModelAbstract object,
//                                        Declaracion dua){
//    Assert.assertEquals(validador.validadorNumeroCertificado2daCalidad(object, dua).get(0).getCodigo(),"31367");
//  }

  @Test (dataProvider = "initDataDyG67")
  public void validarSumaPorcentajes(ModelAbstract object,
                                     Declaracion dua){
    Assert.assertEquals(validador.validarSumaPorcentaje(object).get(0).getCodigo(),"31319");
  }

}