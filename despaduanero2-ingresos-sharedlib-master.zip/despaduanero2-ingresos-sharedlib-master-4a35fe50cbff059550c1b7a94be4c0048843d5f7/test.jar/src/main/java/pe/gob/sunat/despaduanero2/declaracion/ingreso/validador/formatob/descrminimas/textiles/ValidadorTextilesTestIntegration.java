package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.textiles;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilHilado;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilPrenda;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.textiles.model.TextilTela;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorTextilesTestIntegration extends AbstractServiceTest {
  
  @Autowired
  @Qualifier("ValidadorTextilFibra")
  private ValidadorTextilFibra validadorFibra;
  
  @Autowired
  @Qualifier("ValidadorTextilHilado")
  private ValidadorTextilHilado validadorHilado;
  
  @Autowired
  @Qualifier("ValidadorTextilTela")
  private ValidadorTextilTela validadorTela;
  
  @Autowired
  @Qualifier("ValidadorTextilPrenda")
  private ValidadorTextilPrenda validadorPrenda;
  
  @Autowired
  @Qualifier("framework.fabricaDeServicios")
  private FabricaDeServicios fabricaDeServicios;

  @Autowired
  @Qualifier("Ayuda.ayudaServiceCache")
  private AyudaServiceCache ayudaServiceCache;
  
  private Declaracion dua = new Declaracion(); 
  
  
  private Map<String,List<String>> getDuaFromXML(String filename) throws Exception{
    dua = new Declaracion();
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();   
    Mensaje mensaje1001;

    String numeroTransaccion = "1001";

    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

    Map<String, Object> parametros = new HashMap<String, Object>();

    parametros.put("numeroTransaccion", numeroTransaccion);

    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);

    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);

    assertNotNull(mensaje1001);
    dua = (Declaracion) mensaje1001.getDocumento();

    dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();
    

    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima> listaDescripcionMinimas =
        dua.getListDAVs().get(0).getListFacturas().get(0)
        .getListItems().get(0).getListDecrMinima();

    for (pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima dato : listaDescripcionMinimas)
    {
      List<String> data = new ArrayList<String>();
      data.add(0, dato.getCodtipvalor());
      data.add(1,dato.getValtipdescri());
      valores.put(dato.getCodtipdescr(), data);
    }
    return valores;
  }
  
  @DataProvider ( name = "millennium65")
  private Object[][] millennium65() throws Exception{
    TextilTela tela = new TextilTela();
    
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipoTela =  new DatoDescrMinima();
    DatoDescrMinima compoTela1erComp = new DatoDescrMinima();
    DatoDescrMinima compoTelaPorcen1erComp = new DatoDescrMinima();
    DatoDescrMinima compoTela2doComp = new DatoDescrMinima();
    DatoDescrMinima compoTelaPorcen2doComp = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima gramaje = new DatoDescrMinima();
    DatoDescrMinima anchoTela = new DatoDescrMinima();
    DatoDescrMinima usoTela = new DatoDescrMinima();
    DatoDescrMinima tituloHilado = new DatoDescrMinima();
    DatoDescrMinima fob = new DatoDescrMinima();
    
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlTextiles/XML_TEXTIL_CP00.xml";
    valores = getDuaFromXML(filename);
    
    tela.setNumsecitem(1);
    tela.setNumcorredoc(new Long(1));
    tela.setNumsecprove(1);
    tela.setNumsecfact(1);
    
    nombreComercial.setNumcorredoc(new Long(1L));
    nombreComercial.setNumsecitem(1);
    nombreComercial.setCodtipvalor(valores.get("TE0300").get(0));
    nombreComercial.setCodtipdescr("TE0300");
    nombreComercial.setValtipdescri(valores.get("TE0300").get(1));
    
    marcaComercial.setCodtipvalor(valores.get("TE0301").get(0));
    marcaComercial.setCodtipdescr("TE0301");
    marcaComercial.setValtipdescri(valores.get("TE0301").get(1));
    
    modelo.setCodtipvalor(valores.get("TE0302").get(0));
    modelo.setCodtipdescr("TE0302");
    modelo.setValtipdescri(valores.get("TE0302").get(1));
    
    tipoTela.setCodtipvalor(valores.get("TE0303").get(0));
    tipoTela.setCodtipdescr("TE0303");
    tipoTela.setValtipdescri(valores.get("TE0303").get(1));
    
    compoTela1erComp.setCodtipvalor(valores.get("TE0304").get(0));
    compoTela1erComp.setCodtipdescr("TE0304");
    compoTela1erComp.setValtipdescri(valores.get("TE0304").get(1));
    
    compoTelaPorcen1erComp.setCodtipvalor(valores.get("TE0305").get(0));
    compoTelaPorcen1erComp.setCodtipdescr("TE0305");
    compoTelaPorcen1erComp.setValtipdescri(valores.get("TE0305").get(1));
    
    compoTela2doComp.setCodtipvalor(valores.get("TE0306").get(0));
    compoTela2doComp.setCodtipdescr("TE0306");
    compoTela2doComp.setValtipdescri(valores.get("TE0306").get(1));
    
    compoTelaPorcen2doComp.setCodtipvalor(valores.get("TE0307").get(0));
    compoTelaPorcen2doComp.setCodtipdescr("TE0307");
    compoTelaPorcen2doComp.setValtipdescri(valores.get("TE0307").get(1));
    
    gradoElaboracion.setCodtipvalor(valores.get("TE0308").get(0));
    gradoElaboracion.setCodtipdescr("TE0308");
    gradoElaboracion.setValtipdescri(valores.get("TE0308").get(1));
    
    primerAcabado.setCodtipvalor(valores.get("TE0309").get(0));
    primerAcabado.setCodtipdescr("TE0309");
    primerAcabado.setValtipdescri(valores.get("TE0309").get(1));
    
    gramaje.setCodtipvalor(valores.get("TE0313").get(0));
    gramaje.setCodtipdescr("TE0313");
    gramaje.setValtipdescri(valores.get("TE0313").get(1));
    
    anchoTela.setCodtipvalor(valores.get("TE0314").get(0));
    anchoTela.setCodtipdescr("TE0314");
    anchoTela.setValtipdescri(valores.get("TE0314").get(1));
    
    usoTela.setCodtipvalor(valores.get("TE0315").get(0));
    usoTela.setCodtipdescr("TE0315");
    usoTela.setValtipdescri(valores.get("TE0315").get(1));
    
    tituloHilado.setCodtipvalor(valores.get("TE0321").get(0));
    tituloHilado.setCodtipdescr("TE0321");
    tituloHilado.setValtipdescri(valores.get("TE0321").get(1));
    
    fob.setCodtipvalor(valores.get("TE0322").get(0));
    fob.setCodtipdescr("TE0322");
    fob.setValtipdescri(valores.get("TE0322").get(1));
    
    tela.setNombreComercial(nombreComercial);
    tela.setMarcaComercial(marcaComercial);
    tela.setModelo(modelo);
    tela.setTipoTela(tipoTela);
    tela.setCompoTela1erComp(compoTela1erComp);
    tela.setCompoTelaPorcen1erComp(compoTelaPorcen1erComp);
    tela.setCompoTela2doComp(compoTela2doComp);
    tela.setCompoTelaPorcen2doComp(compoTelaPorcen2doComp);
    tela.setGradoElaboracion(gradoElaboracion);
    tela.setGramaje(gramaje);
    tela.setAnchoTela(anchoTela);
    tela.setUsoTela(usoTela);
    tela.setTituloHilado(tituloHilado);
    tela.setRelacionFobUnitarioPesoNeto(fob);
    
    return new Object[][]{{tela}};
  }
  
  @Test(dataProvider="millennium65")
  public void validarFOBVsPesoObs(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarFOBVsPesoObs(tela,dua).size(),1);
  }
  
  @Test(dataProvider="millennium65")
  public void validarTipoTela(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarTipoTela(tela,dua).size(),0);
  }
  
  @Test(dataProvider="millennium65")
  public void validarEspesorMateriaPlastica(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarEspesorMateriaPlastica(tela,dua).size(),0);
  }
  
  @Test(dataProvider="millennium65")
  public void validarComposicionMateriaPlastica(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarComposicionMateriaPlastica(tela,dua).size(),0);
  }
  
  @Test(dataProvider="millennium65")
  public void ValidarSumaPorcenComp(ModelAbstract tela){
    Assert.assertEquals(validadorTela.ValidarSumaPorcenComp(tela).size(),0);
  }
  
  @DataProvider( name = "nikotelas66" )
  private Object[][] nikotelas66() throws Exception{
    TextilTela tela = new TextilTela();
    
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipoTela =  new DatoDescrMinima();
    DatoDescrMinima compoTela1erComp = new DatoDescrMinima();
    DatoDescrMinima compoTelaPorcen1erComp = new DatoDescrMinima();
    DatoDescrMinima compoTela2doComp = new DatoDescrMinima();
    DatoDescrMinima compoTelaPorcen2doComp = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima gramaje = new DatoDescrMinima();
    DatoDescrMinima anchoTela = new DatoDescrMinima();
    DatoDescrMinima usoTela = new DatoDescrMinima();
    DatoDescrMinima fob = new DatoDescrMinima();
    
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlTextiles/XML_TEXTIL_CP01.xml";
    valores = getDuaFromXML(filename);
    
    tela.setNumsecitem(1);
    tela.setNumcorredoc(new Long(1));
    tela.setNumsecprove(1);
    tela.setNumsecfact(1);
    
    nombreComercial.setNumcorredoc(new Long(1L));
    nombreComercial.setNumsecitem(1);
    nombreComercial.setCodtipvalor(valores.get("TE0300").get(0));
    nombreComercial.setCodtipdescr("TE0300");
    nombreComercial.setValtipdescri(valores.get("TE0300").get(1));
    
    marcaComercial.setCodtipvalor(valores.get("TE0301").get(0));
    marcaComercial.setCodtipdescr("TE0301");
    marcaComercial.setValtipdescri(valores.get("TE0301").get(1));
    
    modelo.setCodtipvalor(valores.get("TE0302").get(0));
    modelo.setCodtipdescr("TE0302");
    modelo.setValtipdescri(valores.get("TE0302").get(1));
    
    tipoTela.setCodtipvalor(valores.get("TE0303").get(0));
    tipoTela.setCodtipdescr("TE0303");
    tipoTela.setValtipdescri(valores.get("TE0303").get(1));
    
    compoTela1erComp.setCodtipvalor(valores.get("TE0304").get(0));
    compoTela1erComp.setCodtipdescr("TE0304");
    compoTela1erComp.setValtipdescri(valores.get("TE0304").get(1));
    
    compoTelaPorcen1erComp.setCodtipvalor(valores.get("TE0305").get(0));
    compoTelaPorcen1erComp.setCodtipdescr("TE0305");
    compoTelaPorcen1erComp.setValtipdescri(valores.get("TE0305").get(1));
    
    compoTela2doComp.setCodtipvalor(valores.get("TE0306").get(0));
    compoTela2doComp.setCodtipdescr("TE0306");
    compoTela2doComp.setValtipdescri(valores.get("TE0306").get(1));
    
    compoTelaPorcen2doComp.setCodtipvalor(valores.get("TE0307").get(0));
    compoTelaPorcen2doComp.setCodtipdescr("TE0307");
    compoTelaPorcen2doComp.setValtipdescri(valores.get("TE0307").get(1));
    
    gradoElaboracion.setCodtipvalor(valores.get("TE0308").get(0));
    gradoElaboracion.setCodtipdescr("TE0308");
    gradoElaboracion.setValtipdescri(valores.get("TE0308").get(1));
    
    primerAcabado.setCodtipvalor(valores.get("TE0309").get(0));
    primerAcabado.setCodtipdescr("TE0309");
    primerAcabado.setValtipdescri(valores.get("TE0309").get(1));
    
    gramaje.setCodtipvalor(valores.get("TE0313").get(0));
    gramaje.setCodtipdescr("TE0313");
    gramaje.setValtipdescri(valores.get("TE0313").get(1));
    
    anchoTela.setCodtipvalor(valores.get("TE0314").get(0));
    anchoTela.setCodtipdescr("TE0314");
    anchoTela.setValtipdescri(valores.get("TE0314").get(1));
    
    usoTela.setCodtipvalor(valores.get("TE0315").get(0));
    usoTela.setCodtipdescr("TE0315");
    usoTela.setValtipdescri(valores.get("TE0315").get(1));
    
    fob.setCodtipvalor(valores.get("TE0322").get(0));
    fob.setCodtipdescr("TE0322");
    fob.setValtipdescri(valores.get("TE0322").get(1));
    
    tela.setNombreComercial(nombreComercial);
    tela.setMarcaComercial(marcaComercial);
    tela.setModelo(modelo);
    tela.setTipoTela(tipoTela);
    tela.setCompoTela1erComp(compoTela1erComp);
    tela.setCompoTelaPorcen1erComp(compoTelaPorcen1erComp);
    tela.setCompoTela2doComp(compoTela2doComp);
    tela.setCompoTelaPorcen2doComp(compoTelaPorcen2doComp);
    tela.setGradoElaboracion(gradoElaboracion);
    tela.setGramaje(gramaje);
    tela.setAnchoTela(anchoTela);
    tela.setUsoTela(usoTela);
    tela.setRelacionFobUnitarioPesoNeto(fob);
    
    return new Object[][]{{tela}};
  }
  
  @Test(dataProvider="nikotelas66")
  public void validarFOBVsPesoObs66(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarFOBVsPesoObs(tela,dua).size(),0);
  }
  
  @Test(dataProvider="nikotelas66")
  public void validarTipoTela66(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarTipoTela(tela,dua).size(),1);
  }
  
  @Test(dataProvider="nikotelas66")
  public void validarEspesorMateriaPlastica66(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarEspesorMateriaPlastica(tela,dua).size(),0);
  }
  
  @Test(dataProvider="nikotelas66")
  public void validarComposicionMateriaPlastica66(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarComposicionMateriaPlastica(tela,dua).size(),0);
  }
  
  @Test(dataProvider="nikotelas66")
  public void ValidarSumaPorcenComp66(ModelAbstract tela){
    Assert.assertEquals(validadorTela.ValidarSumaPorcenComp(tela).size(),0);
  }
  
  @DataProvider( name = "steel68" )
  private Object[][] steel68() throws Exception{
    TextilTela tela = new TextilTela();
    
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipoTela =  new DatoDescrMinima();
    DatoDescrMinima compoTela1erComp = new DatoDescrMinima();
    DatoDescrMinima compoTelaPorcen1erComp = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima gramaje = new DatoDescrMinima();
    DatoDescrMinima anchoTela = new DatoDescrMinima();
    DatoDescrMinima usoTela = new DatoDescrMinima();
    DatoDescrMinima fob = new DatoDescrMinima();
    
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlTextiles/XML_TEXTIL_CP02.xml";
    valores = getDuaFromXML(filename);
    
    tela.setNumsecitem(1);
    tela.setNumcorredoc(new Long(1));
    tela.setNumsecprove(1);
    tela.setNumsecfact(1);
    
    nombreComercial.setNumcorredoc(new Long(1L));
    nombreComercial.setNumsecitem(1);
    nombreComercial.setCodtipvalor(valores.get("TE0300").get(0));
    nombreComercial.setCodtipdescr("TE0300");
    nombreComercial.setValtipdescri(valores.get("TE0300").get(1));
    
    marcaComercial.setCodtipvalor(valores.get("TE0301").get(0));
    marcaComercial.setCodtipdescr("TE0301");
    marcaComercial.setValtipdescri(valores.get("TE0301").get(1));
    
    modelo.setCodtipvalor(valores.get("TE0302").get(0));
    modelo.setCodtipdescr("TE0302");
    modelo.setValtipdescri(valores.get("TE0302").get(1));
    
    tipoTela.setCodtipvalor(valores.get("TE0303").get(0));
    tipoTela.setCodtipdescr("TE0303");
    tipoTela.setValtipdescri(valores.get("TE0303").get(1));
    
    compoTela1erComp.setCodtipvalor(valores.get("TE0304").get(0));
    compoTela1erComp.setCodtipdescr("TE0304");
    compoTela1erComp.setValtipdescri(valores.get("TE0304").get(1));
    
    compoTelaPorcen1erComp.setCodtipvalor(valores.get("TE0305").get(0));
    compoTelaPorcen1erComp.setCodtipdescr("TE0305");
    compoTelaPorcen1erComp.setValtipdescri(valores.get("TE0305").get(1)); 
    
    gradoElaboracion.setCodtipvalor(valores.get("TE0308").get(0));
    gradoElaboracion.setCodtipdescr("TE0308");
    gradoElaboracion.setValtipdescri(valores.get("TE0308").get(1));
    
    primerAcabado.setCodtipvalor(valores.get("TE0309").get(0));
    primerAcabado.setCodtipdescr("TE0309");
    primerAcabado.setValtipdescri(valores.get("TE0309").get(1));
    
    gramaje.setCodtipvalor(valores.get("TE0313").get(0));
    gramaje.setCodtipdescr("TE0313");
    gramaje.setValtipdescri(valores.get("TE0313").get(1));
    
    anchoTela.setCodtipvalor(valores.get("TE0314").get(0));
    anchoTela.setCodtipdescr("TE0314");
    anchoTela.setValtipdescri(valores.get("TE0314").get(1));
    
    usoTela.setCodtipvalor(valores.get("TE0315").get(0));
    usoTela.setCodtipdescr("TE0315");
    usoTela.setValtipdescri(valores.get("TE0315").get(1));
    
    fob.setCodtipvalor(valores.get("TE0322").get(0));
    fob.setCodtipdescr("TE0322");
    fob.setValtipdescri(valores.get("TE0322").get(1));
    
    tela.setNombreComercial(nombreComercial);
    tela.setMarcaComercial(marcaComercial);
    tela.setModelo(modelo);
    tela.setTipoTela(tipoTela);
    tela.setCompoTela1erComp(compoTela1erComp);
    tela.setCompoTelaPorcen1erComp(compoTelaPorcen1erComp);
    tela.setGradoElaboracion(gradoElaboracion);
    tela.setGramaje(gramaje);
    tela.setAnchoTela(anchoTela);
    tela.setUsoTela(usoTela);
    tela.setRelacionFobUnitarioPesoNeto(fob);
    
    return new Object[][]{{tela}};
  }
  
  @Test(dataProvider="steel68")
  public void validarFOBVsPesoObs68(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarFOBVsPesoObs(tela,dua).size(),0);
  }
  
  @Test(dataProvider="steel68")
  public void validarTipoTela68(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarTipoTela(tela,dua).size(),1);
  }
  
  @Test(dataProvider="steel68")
  public void validarEspesorMateriaPlastica68(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarEspesorMateriaPlastica(tela,dua).size(),0);
  }
  
  @Test(dataProvider="steel68")
  public void validarComposicionMateriaPlastica68(ModelAbstract tela){
    Assert.assertEquals(validadorTela.validarComposicionMateriaPlastica(tela,dua).size(),0);
  }
  
  @Test(dataProvider="steel68")
  public void ValidarSumaPorcenComp68(ModelAbstract tela){
    Assert.assertEquals(validadorTela.ValidarSumaPorcenComp(tela).size(),0);
  }
  
  @DataProvider( name = "steel69" )
  private Object[][] steel69() throws Exception{
    TextilHilado hilado = new TextilHilado();
    
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipoFibra =  new DatoDescrMinima();
    DatoDescrMinima tipoHilado =  new DatoDescrMinima();    
    DatoDescrMinima compoHilado1erComp = new DatoDescrMinima();
    DatoDescrMinima compoHiladoPorcen1erComp = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima presentacion = new DatoDescrMinima();
    DatoDescrMinima densidadLineal = new DatoDescrMinima();
    DatoDescrMinima estructuraFíscaUso = new DatoDescrMinima();
    DatoDescrMinima fob = new DatoDescrMinima();
    
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlTextiles/XML_TEXTIL_CP03.xml";
    valores = getDuaFromXML(filename);
    
    hilado.setNumsecitem(1);
    hilado.setNumcorredoc(new Long(1));
    hilado.setNumsecprove(1);
    hilado.setNumsecfact(1);
    
    nombreComercial.setCodtipvalor(valores.get("TE0200").get(0));
    nombreComercial.setCodtipdescr("TE0200");
    nombreComercial.setValtipdescri(valores.get("TE0200").get(1));
    
    marcaComercial.setCodtipvalor(valores.get("TE0201").get(0));
    marcaComercial.setCodtipdescr("TE0201");
    marcaComercial.setValtipdescri(valores.get("TE0201").get(1));
    
    modelo.setCodtipvalor(valores.get("TE0202").get(0));
    modelo.setCodtipdescr("TE0202");
    modelo.setValtipdescri(valores.get("TE0202").get(1));
    
    tipoFibra.setCodtipvalor(valores.get("TE0203").get(0));
    tipoFibra.setCodtipdescr("TE0203");
    tipoFibra.setValtipdescri(valores.get("TE0203").get(1));
    
    tipoHilado.setCodtipvalor(valores.get("TE0204").get(0));
    tipoHilado.setCodtipdescr("TE0204");
    tipoHilado.setValtipdescri(valores.get("TE0204").get(1));
    
    compoHilado1erComp.setCodtipvalor(valores.get("TE0205").get(0));
    compoHilado1erComp.setCodtipdescr("TE0205");
    compoHilado1erComp.setValtipdescri(valores.get("TE0205").get(1));
    
    compoHiladoPorcen1erComp.setCodtipvalor(valores.get("TE0206").get(0));
    compoHiladoPorcen1erComp.setCodtipdescr("TE0206");
    compoHiladoPorcen1erComp.setValtipdescri(valores.get("TE0206").get(1));
    
    gradoElaboracion.setCodtipvalor(valores.get("TE0207").get(0));
    gradoElaboracion.setCodtipdescr("TE0207");
    gradoElaboracion.setValtipdescri(valores.get("TE0207").get(1));
    
    primerAcabado.setCodtipvalor(valores.get("TE0208").get(0));
    primerAcabado.setCodtipdescr("TE0208");
    primerAcabado.setValtipdescri(valores.get("TE0208").get(1));
    
    presentacion.setCodtipvalor(valores.get("TE0210").get(0));
    presentacion.setCodtipdescr("TE0210");
    presentacion.setValtipdescri(valores.get("TE0210").get(1));
    
    densidadLineal.setCodtipvalor(valores.get("TE0211").get(0));
    densidadLineal.setCodtipdescr("TE0211");
    densidadLineal.setValtipdescri(valores.get("TE0211").get(1));
    
    estructuraFíscaUso.setCodtipvalor(valores.get("TE0212").get(0));
    estructuraFíscaUso.setCodtipdescr("TE0212");
    estructuraFíscaUso.setValtipdescri(valores.get("TE0212").get(1));
    
    fob.setCodtipvalor(valores.get("TE0219").get(0));
    fob.setCodtipdescr("TE0219");
    fob.setValtipdescri(valores.get("TE0219").get(1));
    
    hilado.setNombreComercial(nombreComercial);
    hilado.setMarcaComercial(marcaComercial);
    hilado.setModelo(modelo);
    hilado.setTipoFibra(tipoFibra);
    hilado.setTipoHilado(tipoHilado);
    hilado.setCompoHilado1erComp(compoHilado1erComp);
    hilado.setCompoHiladoPorcen1erComp(compoHiladoPorcen1erComp);
    hilado.setGradoElaboracion(gradoElaboracion);
    hilado.setGradoElaboracion(gradoElaboracion);
    hilado.setPrimerAcabado(primerAcabado);
    hilado.setPresentacion(presentacion);
    hilado.setDencidadLineal(densidadLineal);
//    hilado.setEstructuraFisicaYUso(estructuraFíscaUso);
    hilado.setRelacionFobUnitarioPesoNeto(fob);
    
    return new Object[][]{{hilado}};
  }
  
  @Test(dataProvider="steel69")
  public void validarUnidadComercial69(ModelAbstract hilado){
//    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
//    Assert.assertEquals(validadorHilado.validarUnidadComercial(hilado, item).size(),0);
  }
  
  @Test(dataProvider="steel69")
  public void validarFOBVsPesoObs69(ModelAbstract hilado){
    Assert.assertEquals(validadorHilado.validarFOBVsPesoObs(hilado,dua).size(),0);
  }
  
  @Test(dataProvider="steel69")
  public void validarSumaPorcenComp69(ModelAbstract hilado){
    Assert.assertEquals(validadorHilado.validarSumaPorcenComp(hilado).size(),0);
  }

  @DataProvider( name = "testCase70" )
  private Object[][] testCase70() throws Exception{
    TextilPrenda prenda = new TextilPrenda();
    
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modelo = new DatoDescrMinima();
    DatoDescrMinima tipoTela =  new DatoDescrMinima();
    DatoDescrMinima compoPrenda1erComp = new DatoDescrMinima();
    DatoDescrMinima compoPrendaPorcen1erComp = new DatoDescrMinima();
    DatoDescrMinima primerAcabado = new DatoDescrMinima();
    DatoDescrMinima gradoElaboracion = new DatoDescrMinima();
    DatoDescrMinima pesoUnitario = new DatoDescrMinima();
    DatoDescrMinima tipoMangaSup = new DatoDescrMinima();
    DatoDescrMinima tipoCuello = new DatoDescrMinima();
    DatoDescrMinima parteDelanteraSup = new DatoDescrMinima();
    DatoDescrMinima parteInternaSup = new DatoDescrMinima();
    DatoDescrMinima largoPrendaSuperior = new DatoDescrMinima();
    DatoDescrMinima bolsillosSuperior = new DatoDescrMinima();
    DatoDescrMinima cinturaSuperior = new DatoDescrMinima();
    DatoDescrMinima medidaPresentacion = new DatoDescrMinima();
    DatoDescrMinima uso = new DatoDescrMinima();
    DatoDescrMinima aplicaciones = new DatoDescrMinima();
    DatoDescrMinima complementos = new DatoDescrMinima();
    DatoDescrMinima fob = new DatoDescrMinima();
    
    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
    String filename = "src/test/java/xmlTextiles/XML_TEXTIL_CP05.xml";
    valores = getDuaFromXML(filename);
    
    prenda.setNumsecitem(1);
    prenda.setNumcorredoc(new Long(1));
    prenda.setNumsecprove(1);
    prenda.setNumsecfact(1);
    
    nombreComercial.setCodtipvalor(valores.get("TE0400").get(0));
    nombreComercial.setCodtipdescr("TE0400");
    nombreComercial.setValtipdescri(valores.get("TE0400").get(1));
    
    marcaComercial.setCodtipvalor(valores.get("TE0401").get(0));
    marcaComercial.setCodtipdescr("TE0401");
    marcaComercial.setValtipdescri(valores.get("TE0401").get(1));
    
    modelo.setCodtipvalor(valores.get("TE0402").get(0));
    modelo.setCodtipdescr("TE0402");
    modelo.setValtipdescri(valores.get("TE0402").get(1));
    
    tipoTela.setCodtipvalor(valores.get("TE0403").get(0));
    tipoTela.setCodtipdescr("TE0403");
    tipoTela.setValtipdescri(valores.get("TE0403").get(1));
    
    compoPrenda1erComp.setCodtipvalor(valores.get("TE0404").get(0));
    compoPrenda1erComp.setCodtipdescr("TE0404");
    compoPrenda1erComp.setValtipdescri(valores.get("TE0404").get(1));
    
    compoPrendaPorcen1erComp.setCodtipvalor(valores.get("TE0405").get(0));
    compoPrendaPorcen1erComp.setCodtipdescr("TE0405");
    compoPrendaPorcen1erComp.setValtipdescri(valores.get("TE0405").get(1));
    
    gradoElaboracion.setCodtipvalor(valores.get("TE0408").get(0));
    gradoElaboracion.setCodtipdescr("TE0408");
    gradoElaboracion.setValtipdescri(valores.get("TE0408").get(1));
    
    primerAcabado.setCodtipvalor(valores.get("TE0409").get(0));
    primerAcabado.setCodtipdescr("TE0409");
    primerAcabado.setValtipdescri(valores.get("TE0409").get(1));
    
    pesoUnitario.setCodtipvalor(valores.get("TE0412").get(0));
    pesoUnitario.setCodtipdescr("TE0412");
    pesoUnitario.setValtipdescri(valores.get("TE0412").get(1));
    
    tipoMangaSup.setCodtipvalor(valores.get("TE0413").get(0));
    tipoMangaSup.setCodtipdescr("TE0413");
    tipoMangaSup.setValtipdescri(valores.get("TE0413").get(1));
    
    tipoCuello.setCodtipvalor(valores.get("TE0414").get(0));
    tipoCuello.setCodtipdescr("TE0414");
    tipoCuello.setValtipdescri(valores.get("TE0414").get(1));
    
    parteDelanteraSup.setCodtipvalor(valores.get("TE0415").get(0));
    parteDelanteraSup.setCodtipdescr("TE0415");
    parteDelanteraSup.setValtipdescri(valores.get("TE0415").get(1));
    
    parteInternaSup.setCodtipvalor(valores.get("TE0416").get(0));
    parteInternaSup.setCodtipdescr("TE0416");
    parteInternaSup.setValtipdescri(valores.get("TE0416").get(1));
    
    largoPrendaSuperior.setCodtipvalor(valores.get("TE0417").get(0));
    largoPrendaSuperior.setCodtipdescr("TE0417");
    largoPrendaSuperior.setValtipdescri(valores.get("TE0417").get(1));
    
    largoPrendaSuperior.setCodtipvalor(valores.get("TE0417").get(0));
    largoPrendaSuperior.setCodtipdescr("TE0417");
    largoPrendaSuperior.setValtipdescri(valores.get("TE0417").get(1));
    
    bolsillosSuperior.setCodtipvalor(valores.get("TE0418").get(0));
    bolsillosSuperior.setCodtipdescr("TE0418");
    bolsillosSuperior.setValtipdescri(valores.get("TE0418").get(1));
    
    cinturaSuperior.setCodtipvalor(valores.get("TE0419").get(0));
    cinturaSuperior.setCodtipdescr("TE0419");
    cinturaSuperior.setValtipdescri(valores.get("TE0419").get(1));
    
    medidaPresentacion.setCodtipvalor(valores.get("TE0429").get(0));
    medidaPresentacion.setCodtipdescr("TE0429");
    medidaPresentacion.setValtipdescri(valores.get("TE0429").get(1));
    
    medidaPresentacion.setCodtipvalor(valores.get("TE0429").get(0));
    medidaPresentacion.setCodtipdescr("TE0429");
    medidaPresentacion.setValtipdescri(valores.get("TE0429").get(1));
    
    aplicaciones.setCodtipvalor(valores.get("TE0437").get(0));
    aplicaciones.setCodtipdescr("TE0437");
    aplicaciones.setValtipdescri(valores.get("TE0437").get(1));
    
    complementos.setCodtipvalor(valores.get("TE0438").get(0));
    complementos.setCodtipdescr("TE0438");
    complementos.setValtipdescri(valores.get("TE0438").get(1));
    
    fob.setCodtipvalor(valores.get("TE0450").get(0));
    fob.setCodtipdescr("TE0450");
    fob.setValtipdescri(valores.get("TE0450").get(1));
    
    prenda.setNombreComercial(nombreComercial);
    prenda.setMarcaComercial(marcaComercial);
    prenda.setModelo(modelo);
    prenda.setTipoTela(tipoTela);
    prenda.setCompoConfeccion1erComp(compoPrenda1erComp);
    prenda.setCompoConfeccionPorcen1erComp(compoPrendaPorcen1erComp);
    prenda.setGradoElaboracion(gradoElaboracion);
    prenda.setPrimerAcabado(primerAcabado);
    prenda.setPesoUnitario(pesoUnitario);
    prenda.setTipoMangaSuperior(tipoMangaSup);
    prenda.setTipoCuelloSuperior(tipoCuello);
    prenda.setParteDelanteraSuperior(parteDelanteraSup);
    prenda.setParteInternaSuperior(parteInternaSup);
    prenda.setLargoPrendaSuperior(largoPrendaSuperior);
    prenda.setBolsillosSuperior(bolsillosSuperior);
    prenda.setCinturaSuperior(cinturaSuperior);
    prenda.setMedidasYPresentaciones(medidaPresentacion);
    prenda.setUso(uso);
    prenda.setAplicacionesPrendasVestir(aplicaciones);
    prenda.setComplementoPrendasVestir(complementos);
    prenda.setRelacionFobUnitarioPesoNeto(fob);
    
    return new Object[][]{{prenda}};
  }
  
  @Test(dataProvider="testCase70")
  public void validarTipoTela70(ModelAbstract prenda){
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(validadorPrenda.validarTipoTela(prenda,item).size(),0);
  }
  
  @Test(dataProvider="testCase70")
  public void validarFOBVsPesoObs70(ModelAbstract prenda){
    Assert.assertEquals(validadorPrenda.validarFOBVsPesoObs(prenda,dua).size(),0);
  }
  
  @Test(dataProvider="testCase70")
  public void validarPesoUnitario70(ModelAbstract prenda){
    Assert.assertEquals(validadorPrenda.validarPesoUnitario(prenda).size(),0);
  }
  
  @Test(dataProvider="testCase70")
  public void validarConstruccionSuperior70(ModelAbstract prenda){
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(validadorPrenda.validarConstruccionSuperior(prenda,item).size(),0);
  }
}

