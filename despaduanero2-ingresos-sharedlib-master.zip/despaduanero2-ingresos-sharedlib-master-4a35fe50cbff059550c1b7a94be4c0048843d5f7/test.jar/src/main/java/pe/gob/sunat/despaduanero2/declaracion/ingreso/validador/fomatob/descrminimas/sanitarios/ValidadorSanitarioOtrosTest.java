package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.fomatob.descrminimas.sanitarios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioOtros;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.sanitarios.ValidadorSanitarioOtros;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorSanitarioOtrosTest extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorSanitarioOtros")
  private ValidadorSanitarioOtros validador;

  private SanitarioOtros	sanitarioOtros;

  @BeforeClass
  public void initData() throws Exception{
    System.out.println("LOAD TEST UNITARIOS ...");
    SanitarioOtros sanitarioOtros = new SanitarioOtros();
    //NombreComercial
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    nombreComercial.setValtipdescri("URI"); // INO,CTK,LAV,FGD,PDL,SPL,BDT,URI,BÑA,ZZZ
    sanitarioOtros.setNombreComercial(nombreComercial);
    //Tipo
    DatoDescrMinima tipo = new DatoDescrMinima();
    tipo.setValtipdescri("MMM"); //TAT,TBJ,LCP,LSP,LSE,LPL,BUO,BTO,CTI,STR
    sanitarioOtros.setTipo(tipo);
    //Valvula
    DatoDescrMinima valvula = new DatoDescrMinima();
    valvula.setValtipdescri("VAS"); //VAS,VSF,SVL
    sanitarioOtros.setValvula(valvula);
    //consumoAgua
    DatoDescrMinima consumoAgua = new DatoDescrMinima();
    consumoAgua.setValtipdescri("YYY"); //AEF,BCS
    sanitarioOtros.setConsumoAgua(consumoAgua);

    this.sanitarioOtros = sanitarioOtros;
  }

  @Test
  public void testValidarTipo(){
    System.out.println("Ingreso al Test -testValidarTipo-");
    String nombreComercial = sanitarioOtros.getNombreComercial().getValtipdescri();
    String tipo = sanitarioOtros.getTipo().getValtipdescri();
    System.out.println("NombreComercial/Tipo: " + nombreComercial+"/"+tipo);
    Assert.assertEquals(validador.validartipo(sanitarioOtros).size(),1);
  }

  @Test
  public void testValidarValvula(){
    System.out.println("Ingreso al Test -testValidarValvula-");
    String valvula = sanitarioOtros.getValvula().getValtipdescri();
    System.out.println("Valvula: " + valvula);
    Assert.assertEquals(validador.validarValvula(sanitarioOtros).size(),0);
  }

  @Test
  public void testValidarConsumoAgua(){
    System.out.println("Ingreso al Test -testValidarConsumoAgua-");
    String consumoAgua = sanitarioOtros.getConsumoAgua().getValtipdescri();
    System.out.println("consumoAgua: " + consumoAgua);
    Assert.assertEquals(validador.validarConsumoAgua(sanitarioOtros).size(),1);
  }

}
