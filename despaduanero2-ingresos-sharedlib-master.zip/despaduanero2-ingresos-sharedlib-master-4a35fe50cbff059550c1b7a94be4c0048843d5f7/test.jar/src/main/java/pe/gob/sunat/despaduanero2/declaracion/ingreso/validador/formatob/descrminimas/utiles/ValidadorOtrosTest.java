package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.utiles;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ErrorDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.utiles.model.UtilesOtros;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorOtrosTest extends AbstractServiceTest {
  @Autowired
  @Qualifier("ValidadorUtilesOtros")
  private ValidadorUtilesOtros validador = new ValidadorUtilesOtros();

  private static final String TEXTO = "1";
  private static final String CATALOGO = "0";


  @DataProvider ( name ="initDataInterAmericanService_181")
  private Object[][] initDataInterAmericanService_181(){
    UtilesOtros util = new UtilesOtros();

    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modeloComercial = new DatoDescrMinima();
    DatoDescrMinima acabado         = new DatoDescrMinima();
    DatoDescrMinima dimensiones     = new DatoDescrMinima();
    DatoDescrMinima volumenUnitario = new DatoDescrMinima();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoDescrMinima materialExterno = new DatoDescrMinima();
    DatoDescrMinima materialInterno = new DatoDescrMinima();
    DatoDescrMinima dureza          = new DatoDescrMinima();
    DatoDescrMinima dispositivo     = new DatoDescrMinima();
    DatoDescrMinima accesorios      = new DatoDescrMinima();
    DatoDescrMinima uso             = new DatoDescrMinima();

    DatoItem item                   = new DatoItem();

    item.setNumpartnandi(new Long(39191000000L)); //960840000

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("041");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("UT0201");
    marcaComercial.setValtipdescri("Lube");

    modeloComercial.setCodtipvalor(TEXTO);
    modeloComercial.setCodtipdescr("UT0202");
    modeloComercial.setValtipdescri("LF831 A");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("UT0205");
    acabado.setValtipdescri("002");

    dimensiones.setCodtipvalor(TEXTO);
    dimensiones.setCodtipdescr("UT0206");
    dimensiones.setValtipdescri("125 X 10 X 15");

    volumenUnitario.setCodtipvalor(TEXTO);
    volumenUnitario.setCodtipdescr("UT0220");
    volumenUnitario.setValtipdescri("6.5 gr");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("UT0209");
    presentacion.setValtipdescri("004");

    materialExterno.setCodtipvalor(CATALOGO);
    materialExterno.setCodtipdescr("UT0203");
    materialExterno.setValtipdescri("017");

    materialInterno.setCodtipvalor(CATALOGO);
    materialInterno.setCodtipdescr("UT0221");
    materialInterno.setCodtipdescr("003");

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0214");
    dureza.setValtipdescri("007");

    dispositivo.setCodtipvalor(CATALOGO);
    dispositivo.setCodtipdescr("UT0217");
    dispositivo.setValtipdescri("001");

    accesorios.setCodtipvalor(CATALOGO);
    accesorios.setCodtipdescr("UT0218");
    accesorios.setValtipdescri("003"); 

    uso.setCodtipvalor(CATALOGO);
    uso.setCodtipdescr("UT0208");
    uso.setValtipdescri("001");

    util.setNombreComercial(nombreComercial);
    util.setMarcaComercial(marcaComercial);
    util.setModelo(modeloComercial);
    util.setAcabado(acabado);
    util.setDimensiones(dimensiones);
    util.setModoPresentacion(presentacion);
    util.setPrimerComponente(materialExterno);
    util.setTipoMaterialInterior(materialInterno);
    util.setTipoDureza(dureza);
    util.setDispositivo(dispositivo);
    util.setPrimerAccesorio(accesorios);
    util.setUso(uso);

    return new Object[][]{{ util, item}};
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void nombreComercial_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarNombre(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void  marcaComercial_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarMarcaComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void modeloComercial_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarModeloComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void acabado_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAcabado(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void dimensiones_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(1, validador.validarDimensiones(object, item).size());
  }


  @Test(dataProvider = "initDataInterAmericanService_181")
  public void presentacion_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarPresentacion(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void composicion_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(), validador.validarComposicionMercancia(object, item));
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void materialInterno_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(), validador.validarTipoMaterial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void dureza_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarTipoDureza(object).size(),0);
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void dispositivos_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(), validador.validarDispositivos(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_181")
  public void aplicacion_181Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAplicacionUso(object));
  }

  @DataProvider ( name ="initDataInterAmericanService_183")
  private Object[][] initDataInterAmericanService_183(){

    UtilesOtros util  = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima marcaComercial  = new DatoDescrMinima();
    DatoDescrMinima modeloComercial = new DatoDescrMinima();
    DatoDescrMinima acabado         = new DatoDescrMinima();
    DatoDescrMinima dimensiones     = new DatoDescrMinima();
    DatoDescrMinima pesoUnitario    = new DatoDescrMinima();
    DatoDescrMinima presentacion    = new DatoDescrMinima();
    DatoDescrMinima dispositivo     = new DatoDescrMinima();
    DatoDescrMinima accesorios      = new DatoDescrMinima();
    DatoDescrMinima materialExterno = new DatoDescrMinima();
    DatoDescrMinima materialInterno = new DatoDescrMinima();
    DatoDescrMinima dureza          = new DatoDescrMinima();
    DatoDescrMinima uso             = new DatoDescrMinima();
    DatoItem item                   = new DatoItem();

    item.setNumpartnandi(new Long(39191000000L));//960810100

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("005");

    marcaComercial.setCodtipvalor(TEXTO);
    marcaComercial.setCodtipdescr("UT0201");
    marcaComercial.setValtipdescri("durabol");

    modeloComercial.setCodtipvalor(TEXTO);
    modeloComercial.setCodtipdescr("UT0203");
    modeloComercial.setValtipdescri("LTA 28");

    acabado.setCodtipvalor(CATALOGO);
    acabado.setCodtipdescr("UT0205");
    acabado.setValtipdescri("001");

    dimensiones.setCodtipvalor(TEXTO);
    dimensiones.setCodtipdescr("UT0206");
    dimensiones.setValtipdescri("155 X10 X 5");

    pesoUnitario.setCodtipvalor(TEXTO);
    pesoUnitario.setCodtipdescr("UT0207");
    pesoUnitario.setValtipdescri("8");

    presentacion.setCodtipvalor(CATALOGO);
    presentacion.setCodtipdescr("UT0209");
    presentacion.setValtipdescri("017");

    dispositivo.setCodtipvalor(CATALOGO);
    dispositivo.setCodtipdescr("UT0217");
    dispositivo.setValtipdescri("002");

    accesorios.setCodtipvalor(CATALOGO);
    accesorios.setCodtipdescr("UT0218");
    accesorios.setValtipdescri("005");

    materialExterno.setCodtipvalor(CATALOGO);
    materialExterno.setCodtipdescr("UT0203");
    materialExterno.setValtipdescri("017");

    materialInterno.setCodtipvalor(TEXTO);
    materialInterno.setCodtipdescr("UT0211");
    materialInterno.setValtipdescri("Tinta Seca"); 

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0214");
    dureza.setValtipdescri("005");

    uso.setCodtipvalor(CATALOGO);
    uso.setCodtipdescr("UT0208");
    uso.setValtipdescri("003");

    util.setNombreComercial(nombreComercial);
    util.setMarcaComercial(marcaComercial);
    util.setModelo(modeloComercial);
    util.setAcabado(acabado);
    util.setDimensiones(dimensiones);
    util.setModoPresentacion(presentacion);
    util.setDispositivo(dispositivo);
    util.setPrimerAccesorio(accesorios);
    util.setPrimerComponente(materialExterno);
    util.setTipoMaterialInterior(materialInterno);
    util.setTipoDureza(dureza);
    util.setUso(uso);

    return new Object[][]{{ util, item}};
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void nombreComercial_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarNombre(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void  marcaComercial_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarMarcaComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void modeloComercial_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarModeloComercial(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void acabado_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAcabado(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void dimensiones_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(1, validador.validarDimensiones(object, item).size());
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void presentacion_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarPresentacion(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void composicion_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(), validador.validarComposicionMercancia(object, item));
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void materialInterno_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(1, validador.validarTipoMaterial(object).size());
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void dureza_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(validador.validarTipoDureza(object).size(), 0);
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void dispositivos_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(), validador.validarDispositivos(object));
  }

  @Test(dataProvider = "initDataInterAmericanService_183")
  public void aplicacion_183Test(ModelAbstract object, DatoItem item){
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarAplicacionUso(object));
  }

  @DataProvider(
                name = "initDataValidarUnidadComercialInvalido")
  public Object[][] validarUnidadComercialInvalido() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    nombreComercial.setNumcorredoc(new Long(1));
    // nombreComercial.setNumfact("1");
    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("");

    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("NI SET NI U");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    utiles.setNombreComercial(nombreComercial);

    return new Object[][] { { utiles, dua } };
  }

  @Test(
        dataProvider = "initDataValidarUnidadComercialInvalido")
  public void validarUnidadComercialInvalidoTest(ModelAbstract objeto,
                                                 Declaracion dua) {
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(1, validador.validarUnidadComercial(objeto, item).size());
  }

  @DataProvider(
                name = "initDataValidarUnidadComercial")
  public Object[][] validarUnidadComercial() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    nombreComercial.setNumcorredoc(new Long(1));
    nombreComercial.setNumsecfact(1);
    nombreComercial.setNumsecitem(1);
    nombreComercial.setNumsecprove(1);;
    Declaracion dua = new Declaracion();
    DUA dam = new DUA();
    dam.setNumcorredoc(new Long(1));
    Elementos<DAV> listDAVs = new Elementos<DAV>();

    DAV dav = new DAV();
    dav.setNumcorredoc(new Long(1));
    dav.setNumcodsecprove(new Long(1));

    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    factu.setNumcorredoc(new Long(1));
    factu.setNumfactura("1");
    factu.setNumsecfactu(1);
    factu.setNumsecprove(1);

    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumcorredoc(new Long(1));
    item.setNumfact("1");
    item.setNumsecitem(1);
    item.setNumsecprove(1);
    item.setCodunidcomer("U");
    lstitem.add(item);

    factu.setListItems(lstitem);
    lstFactu.add(factu);

    dav.setListFacturas(lstFactu);

    listDAVs.add(dav);
    dua.setListDAVs(listDAVs);
    dua.setDua(dam);

    utiles.setNombreComercial(nombreComercial);

    return new Object[][] { { utiles, dua } };
  }

  @Test(
        dataProvider = "initDataValidarUnidadComercial")
  public void validarUnidadComercialTest(ModelAbstract objeto,
                                         Declaracion dua) {
    DatoItem item = dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0);
    Assert.assertEquals(new ArrayList<ErrorDescrMinima>(),
                        validador.validarUnidadComercial(objeto,item));
  }

  /*
   * validarTipoMaterialUtil
   */
  @DataProvider(
                name = "initDataValidarTipoMaterialBoligrafoUtilInvalido")
  public Object[][] initDataValidarTipoMaterialBoligrafoUtilInvalidol() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima tipoMaterial = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("");
    nombreComercial.setValtipdescri("005");

    tipoMaterial.setCodtipvalor(CATALOGO);
    tipoMaterial.setCodtipdescr("");
    tipoMaterial.setValtipdescri("666");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(tipoMaterial);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarTipoMaterialBoligrafoUtilInvalido")
  public void ValidarTipoMaterialUtilBoligrafoInvalidoTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoMaterial(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarTipoMaterialBoligrafoUtil")
  public Object[][] initDataValidarTipoMaterialBoligrafoUtil() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima tipoMaterial = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("005");

    tipoMaterial.setCodtipvalor(CATALOGO);
    tipoMaterial.setCodtipdescr("UT0211");
    tipoMaterial.setValtipdescri("001");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(tipoMaterial);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarTipoMaterialBoligrafoUtil")
  public void ValidarTipoMaterialUtilBoligrafoTest(ModelAbstract objeto) {
    Assert.assertEquals(
                        validador.validarTipoMaterial(objeto).size(),0);
  }

  @DataProvider(
                name = "initDataValidarMaterialLapizInvalido")
  public Object[][] initDataValidarMaterialLapizInvalido() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima tipoMaterial = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("026");

    tipoMaterial.setCodtipvalor(CATALOGO);
    tipoMaterial.setCodtipdescr("UT0211");
    tipoMaterial.setValtipdescri("777");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(tipoMaterial);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarMaterialLapizInvalido")
  public void validarMaterialLapizInvalidoTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoMaterial(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarNoMaterialLapiz")
  public Object[][] initDataValidarNoMaterialLapiz() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima tipoMaterial = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("026");

    tipoMaterial.setCodtipvalor(CATALOGO);
    tipoMaterial.setCodtipdescr("UT0211");
    tipoMaterial.setValtipdescri("");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(tipoMaterial);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarNoMaterialLapiz")
  public void validarNoMaterialLapizTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoMaterial(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarMaterialLapiz")
  public Object[][] initDataValidarMaterialLapiz() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima tipoMaterial = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("026");

    tipoMaterial.setCodtipvalor(CATALOGO);
    tipoMaterial.setCodtipdescr("UT0212");
    tipoMaterial.setValtipdescri("002");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(tipoMaterial);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarMaterialLapiz")
  public void validarMaterialLapizTest(ModelAbstract objeto) {
    Assert.assertEquals(validador.validarTipoMaterial(objeto).size(),0);
  }

  @DataProvider(
                name = "initDataValidarMaterialRotuladoresInv")
  public Object[][] initDataValidarMaterialRotuladoresInv() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima tipoMaterial = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("042");

    tipoMaterial.setCodtipvalor(CATALOGO);
    tipoMaterial.setCodtipdescr("UT0213");
    tipoMaterial.setValtipdescri("668");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(tipoMaterial);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarMaterialRotuladoresInv")
  public void validarMaterialRotuladoresInvTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoMaterial(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarNoMaterialRotuladores")
  public Object[][] initDataValidarNoMaterialRotuladores() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    DatoDescrMinima tipoMaterial = new DatoDescrMinima();

    tipoMaterial.setCodtipvalor(CATALOGO);
    tipoMaterial.setCodtipdescr("UT0213");
    tipoMaterial.setValtipdescri("");

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("042");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(tipoMaterial);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarNoMaterialRotuladores")
  public void validarNoMaterialRotuladoresTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoMaterial(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarMaterialRotuladores")
  public Object[][] initDataValidarMaterialRotuladores() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima tipoMaterial = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("042");

    tipoMaterial.setCodtipvalor(CATALOGO);
    tipoMaterial.setCodtipdescr("UT0213");
    tipoMaterial.setValtipdescri("003");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(tipoMaterial);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarMaterialRotuladores")
  public void validarMaterialRotuladoresTest(ModelAbstract objeto) {
    Assert.assertEquals(validador.validarTipoMaterial(objeto).size(),0);
  }

  @DataProvider(
                name = "initDataValidarNoDurezaBoligrafo")
  public Object[][] initDataValidarNoDurezaBoligrafo() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima dureza = new DatoDescrMinima();

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0214");
    dureza.setValtipdescri("");

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("005");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoDureza(dureza);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarNoDurezaBoligrafo")
  public void validarNoDurezaBoligrafoTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoDureza(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarDurezaBoligrafoInv")
  public Object[][] initDataValidarDurezaBoligrafoInv() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima dureza = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("005");

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0214");
    dureza.setValtipdescri("444");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoDureza(dureza);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarDurezaBoligrafoInv")
  public void validarDurezaBoligrafoInvTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoDureza(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarDurezaBoligrafo")
  public Object[][] initDataValidarDurezaBoligrafo() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima dureza = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("005");

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0214");
    dureza.setValtipdescri("001");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoDureza(dureza);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarDurezaBoligrafo")
  public void validarDurezaBoligrafoTest(ModelAbstract objeto) {
    Assert.assertEquals(validador.validarTipoDureza(objeto).size(),0);
  }

  @DataProvider(
                name = "initDataValidarNoDurezaResaltador")
  public Object[][] initDataValidarNoDurezaResaltador() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();

    DatoDescrMinima dureza = new DatoDescrMinima();

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0216");
    dureza.setValtipdescri("");

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("042");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoDureza(dureza);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarNoDurezaResaltador")
  public void validarNoDurezaResaltadorTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoDureza(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarDurezaResaltadorInv")
  public Object[][] initDataValidarDurezaResaltadorInv() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima dureza = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("042");

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0216");
    dureza.setValtipdescri("4789");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoDureza(dureza);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarDurezaResaltadorInv")
  public void validarDurezaResaltadorInvTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoDureza(objeto).size());
  }

  @DataProvider(
                name = "initDataValidarDurezaResaltador")
  public Object[][] initDataValidarDurezaResaltador() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima dureza = new DatoDescrMinima();

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setCodtipdescr("042");

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0216");
    dureza.setValtipdescri("001");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoMaterialInterior(dureza);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarDurezaResaltador")
  public void validarDurezaResaltadorTest(ModelAbstract objeto) {
    List<ErrorDescrMinima> lst = new ArrayList<ErrorDescrMinima>();
    Assert.assertEquals(lst, validador.validarTipoMaterial(objeto));
  }

  @DataProvider(
                name = "initDataValidarNoDurezaLapiz")
  public Object[][] initDataValidarNoDurezaLapiz() {
    UtilesOtros utiles = new UtilesOtros();
    DatoDescrMinima nombreComercial = new DatoDescrMinima();
    DatoDescrMinima dureza = new DatoDescrMinima();

    dureza.setCodtipvalor(CATALOGO);
    dureza.setCodtipdescr("UT0215");
    dureza.setValtipdescri("");

    nombreComercial.setCodtipvalor(CATALOGO);
    nombreComercial.setCodtipdescr("UT0200");
    nombreComercial.setValtipdescri("028");

    utiles.setNombreComercial(nombreComercial);
    utiles.setTipoDureza(dureza);

    return new Object[][] { { utiles } };
  }

  @Test(
        dataProvider = "initDataValidarNoDurezaLapiz")
  public void validarNoDurezaLapizTest(ModelAbstract objeto) {
    Assert.assertEquals(1, validador.validarTipoDureza(objeto).size());
  }
}
