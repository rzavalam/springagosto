package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;


import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoMemoria;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorComputoMemoriaTestIntegration extends AbstractServiceTest{
	  @Autowired
	  @Qualifier("ValidadorComputoMemoria")
	  private ValidadorComputoMemoria validador;

	  @Autowired
	  @Qualifier("framework.fabricaDeServicios")
	  private FabricaDeServicios fabricaDeServicios;

	  @Autowired
	  @Qualifier("Ayuda.ayudaServiceCache")
	  private AyudaServiceCache ayudaServiceCache;
	  private Declaracion dua;

	  private Map<String,List<String>> getDuaFromXML(String filename) throws Exception{
	    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	    dua = new Declaracion();
	    Mensaje mensaje1001;

	    String numeroTransaccion = "1001";

	    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

	    Map<String, Object> parametros = new HashMap<String, Object>();

	    parametros.put("numeroTransaccion", numeroTransaccion);

	    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);

	    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
	    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
	    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

	    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);

	    assertNotNull(mensaje1001);
	    dua = (Declaracion) mensaje1001.getDocumento();

	    dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();

	    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima> listaDescripcionMinimas =
	        dua.getListDAVs().get(0).getListFacturas().get(0)
	        .getListItems().get(0).getListDecrMinima();

	    for (pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima dato : listaDescripcionMinimas)
	    {
	      List<String> data = new ArrayList<String>();
	      data.add(0, dato.getCodtipvalor());
	      data.add(1,dato.getValtipdescri());
	      valores.put(dato.getCodtipdescr(), data);
	    }
	    return valores;
	  }
	  
	  
	  private Object[][] initData(Map<String,List<String>> valores ){
		DatoDescrMinima nombreComercial = new DatoDescrMinima();	
		DatoDescrMinima marcaComercial = new DatoDescrMinima();
		DatoDescrMinima modelo = new DatoDescrMinima();
		DatoDescrMinima tipoMemoria = new DatoDescrMinima();
		DatoDescrMinima tipoMemoriaRAM = new DatoDescrMinima();
		DatoDescrMinima velocidadBus = new DatoDescrMinima();
		DatoDescrMinima capacidadMemoria = new DatoDescrMinima();
		DatoDescrMinima moduloMemoria = new DatoDescrMinima();
		ComputoMemoria memoria= new ComputoMemoria();
	    memoria.setNumsecitem(1);
		  
	    nombreComercial.setCodtipvalor(valores.get("CO0700").get(0));
	    nombreComercial.setCodtipdescr("CO0700");
	    nombreComercial.setValtipdescri(valores.get("CO0700").get(1));
	    
	    marcaComercial.setCodtipvalor(valores.get("CO0701").get(0));
	    marcaComercial.setCodtipdescr("CO0701");
	    marcaComercial.setValtipdescri(valores.get("CO0701").get(1));
	    
	    modelo.setCodtipvalor(valores.get("CO0702").get(0));
	    modelo.setCodtipdescr("CO0702");
	    modelo.setValtipdescri(valores.get("CO0702").get(1));
	    
	    tipoMemoria.setCodtipvalor(valores.get("CO0703").get(0));
	    tipoMemoria.setCodtipdescr("CO0703");
	    tipoMemoria.setValtipdescri(valores.get("CO0703").get(1));

	    tipoMemoriaRAM.setCodtipvalor(valores.get("CO0704").get(0));
	    tipoMemoriaRAM.setCodtipdescr("CO0704");
	    tipoMemoriaRAM.setValtipdescri(valores.get("CO0704").get(1));

	    velocidadBus.setCodtipvalor(valores.get("CO0705").get(0));
	    velocidadBus.setCodtipdescr("CO0705");
	    velocidadBus.setValtipdescri(valores.get("CO0705").get(1));

	    capacidadMemoria.setCodtipvalor(valores.get("CO0706").get(0));
	    capacidadMemoria.setCodtipdescr("CO0706");
	    capacidadMemoria.setValtipdescri(valores.get("CO0706").get(1));

	    moduloMemoria.setCodtipvalor(valores.get("CO0707").get(0));
	    moduloMemoria.setCodtipdescr("CO0707");
	    moduloMemoria.setValtipdescri(valores.get("CO0707").get(1));
	    
	    memoria.setNombreComercial(nombreComercial);
	    memoria.setMarcaComercial(marcaComercial);
	    memoria.setModelo(modelo);
	    memoria.setTipoMemoria(tipoMemoria);
	    memoria.setTipoMemoriaRAM(tipoMemoriaRAM);
	    memoria.setVelocidadBUS(velocidadBus);
	    memoria.setCapacidadMemoria(capacidadMemoria);
	    memoria.setModuloMemoria(moduloMemoria);
		  	  
		return new Object[][]{{ memoria }};
	  }
	  
	  @DataProvider ( name = "initData128")
	  private Object[][] initData128()  throws Exception{
		  Map<String,List<String>> valores = new HashMap<String,List<String>>();
		  String filename = "src/test/java/xmlComputo/XML_MEMORIA_CP00.xml";
		  valores = getDuaFromXML(filename);
		  return initData(valores);
	  }
	  
	  @Test(dataProvider="initData128")
	  public void validarComputadora128(ModelAbstract computadora) throws Exception{
		    Assert.assertEquals(validador.ejecutarValidaciones(computadora, dua).size(),0);
		  }
}