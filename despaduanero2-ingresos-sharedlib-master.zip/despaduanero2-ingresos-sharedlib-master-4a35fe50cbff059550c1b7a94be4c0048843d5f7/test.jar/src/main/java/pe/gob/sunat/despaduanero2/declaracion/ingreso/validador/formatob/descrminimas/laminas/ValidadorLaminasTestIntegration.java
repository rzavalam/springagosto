package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.laminas;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.laminas.model.Lamina;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorLaminasTestIntegration extends AbstractServiceTest{
	  @Autowired
	  @Qualifier("ValidadorLamina")
	  private ValidadorLamina validador;

	  @Autowired
	  @Qualifier("framework.fabricaDeServicios")
	  private FabricaDeServicios fabricaDeServicios;

	  @Autowired
	  @Qualifier("Ayuda.ayudaServiceCache")
	  private AyudaServiceCache ayudaServiceCache;
	  private Declaracion dua;

	  private Map<String,List<String>> getDuaFromXML(String filename) throws Exception{
	    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	    dua = new Declaracion();
	    Mensaje mensaje1001;

	    String numeroTransaccion = "1001";

	    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

	    Map<String, Object> parametros = new HashMap<String, Object>();

	    parametros.put("numeroTransaccion", numeroTransaccion);

	    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);

	    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
	    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
	    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

	    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);

	    assertNotNull(mensaje1001);
	    dua = (Declaracion) mensaje1001.getDocumento();

	    dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();

	    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima> listaDescripcionMinimas =
	        dua.getListDAVs().get(0).getListFacturas().get(0)
	        .getListItems().get(0).getListDecrMinima();

	    for (pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima dato : listaDescripcionMinimas)
	    {
	      List<String> data = new ArrayList<String>();
	      data.add(0, dato.getCodtipvalor());
	      data.add(1,dato.getValtipdescri());
	      valores.put(dato.getCodtipdescr(), data);
	    }
	    return valores;
	  }
	  
	  @DataProvider ( name = "initOrbis_114")
	  private Object[][] initOrbis_114() throws Exception{
		  DatoDescrMinima nombreComercial = new DatoDescrMinima();
		  DatoDescrMinima marcaComercial = new DatoDescrMinima();
		  DatoDescrMinima modelo = new DatoDescrMinima();
		  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
		  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
		  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
		  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
		  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
		  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
		  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
		  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
		  DatoDescrMinima acabado = new DatoDescrMinima();
		  DatoDescrMinima color = new DatoDescrMinima();
		  DatoDescrMinima gramaje = new DatoDescrMinima();
		  DatoDescrMinima ancho = new DatoDescrMinima();
		  Lamina lamina = new Lamina();
	    
	    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	    String filename = "src/test/java/xmlLaminas/XML_LAMINA_CP00.xml";
	    valores = getDuaFromXML(filename);
	    
	    
	    nombreComercial.setCodtipvalor(valores.get("LA0000").get(0));
	    nombreComercial.setCodtipdescr("LA0000");
	    nombreComercial.setValtipdescri(valores.get("LA0000").get(1));
	    
	    marcaComercial.setCodtipvalor(valores.get("LA0001").get(0));
	    marcaComercial.setCodtipdescr("LA0001");
	    marcaComercial.setValtipdescri(valores.get("LA0001").get(1));
	    
	    modelo.setCodtipvalor(valores.get("LA0002").get(0));
	    modelo.setCodtipdescr("LA0002");
	    modelo.setValtipdescri(valores.get("LA0002").get(1));
	    
	    primerComponentePlastico.setCodtipvalor(valores.get("LA0006").get(0));
	    primerComponentePlastico.setCodtipdescr("LA0006");
	    primerComponentePlastico.setValtipdescri(valores.get("LA0006").get(1));
	    
	    primerPorcentajeCompo.setCodtipvalor(valores.get("LA0007").get(0));
	    primerPorcentajeCompo.setCodtipdescr("LA0007");
	    primerPorcentajeCompo.setValtipdescri(valores.get("LA0007").get(1));
	    
	    primerGradoElaboracion.setCodtipvalor(valores.get("LA0003").get(0));
	    primerGradoElaboracion.setCodtipdescr("LA0003");
	    primerGradoElaboracion.setValtipdescri(valores.get("LA0003").get(1));
	    
	    segundoGradoElaboracion.setCodtipvalor(valores.get("LA0004").get(0));
	    segundoGradoElaboracion.setCodtipdescr("LA0004");
	    segundoGradoElaboracion.setValtipdescri(valores.get("LA0004").get(1));
	    
	    gradoElaboracionSoporte.setCodtipvalor(valores.get("LA0015").get(0));
	    gradoElaboracionSoporte.setCodtipdescr("LA0015");
	    gradoElaboracionSoporte.setValtipdescri(valores.get("LA0015").get(1));
	    
	    tipoSoporte.setCodtipvalor(valores.get("LA0010").get(0));
	    tipoSoporte.setCodtipdescr("LA0010");
	    tipoSoporte.setValtipdescri(valores.get("LA0010").get(1));
	    
	    compoTejidoNoTejido.setCodtipvalor(valores.get("LA0011").get(0));
	    compoTejidoNoTejido.setCodtipdescr("LA0011");
	    compoTejidoNoTejido.setValtipdescri(valores.get("LA0011").get(1));
	    
	    porcentajeTejidoNoTejido.setCodtipvalor(valores.get("LA0012").get(0));
	    porcentajeTejidoNoTejido.setCodtipdescr("LA0012");
	    porcentajeTejidoNoTejido.setValtipdescri(valores.get("LA0012").get(1));
	    
	    acabado.setCodtipvalor(valores.get("LA0017").get(0));
	    acabado.setCodtipdescr("LA0017");
	    acabado.setValtipdescri(valores.get("LA0017").get(1));
	    
	    gramaje.setCodtipvalor(valores.get("LA0020").get(0));
	    gramaje.setCodtipdescr("LA0020");
	    gramaje.setValtipdescri(valores.get("LA0020").get(1));
	    
	    color.setCodtipvalor(valores.get("LA0016").get(0));
	    color.setCodtipdescr("LA0016");
	    color.setValtipdescri(valores.get("LA0016").get(1));
	    
	    ancho.setCodtipvalor(valores.get("LA0021").get(0));
	    ancho.setCodtipdescr("LA0021");
	    ancho.setValtipdescri(valores.get("LA0021").get(1));
	    
	    lamina.setNumsecitem(1);
	    lamina.setNombreComercial(nombreComercial);
		  lamina.setMarcaComercial(marcaComercial);
		  lamina.setModelo(modelo);
		  lamina.setPrimerComponentePlastico(primerComponentePlastico);
		  lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
		  lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
		  lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
		  lamina.setGradoElaboracion(gradoElaboracionSoporte);
		  lamina.setTipoSoporte(tipoSoporte);
		  lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
		  lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
		  lamina.setAcabado(acabado);
		  lamina.setGramaje(gramaje);
		  lamina.setColor(color);
		  lamina.setAncho(ancho);
		  lamina.setPlastificante(new DatoDescrMinima());
	    
	    
	    return new Object[][]{{lamina}};
	  }
	  
	  @Test(dataProvider="initOrbis_114")
	  public void validarLaminas(ModelAbstract lamina) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(lamina, dua).size(),0);
	  }
	
	  @DataProvider ( name = "initOrbis_115")
	  private Object[][] initOrbis_115() throws Exception{
		  DatoDescrMinima nombreComercial = new DatoDescrMinima();
		  DatoDescrMinima marcaComercial = new DatoDescrMinima();
		  DatoDescrMinima modelo = new DatoDescrMinima();
		  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
		  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
		  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
		  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
		  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
		  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
		  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
		  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
		  DatoDescrMinima acabado = new DatoDescrMinima();
		  DatoDescrMinima color = new DatoDescrMinima();
		  DatoDescrMinima gramaje = new DatoDescrMinima();
		  DatoDescrMinima ancho = new DatoDescrMinima();
		  Lamina lamina = new Lamina();
	    
	    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	    String filename = "src/test/java/xmlLaminas/XML_LAMINA_CP01.xml";
	    valores = getDuaFromXML(filename);
	    
	    
	    nombreComercial.setCodtipvalor(valores.get("LA0000").get(0));
	    nombreComercial.setCodtipdescr("LA0000");
	    nombreComercial.setValtipdescri(valores.get("LA0000").get(1));
	    
	    marcaComercial.setCodtipvalor(valores.get("LA0001").get(0));
	    marcaComercial.setCodtipdescr("LA0001");
	    marcaComercial.setValtipdescri(valores.get("LA0001").get(1));
	    
	    modelo.setCodtipvalor(valores.get("LA0002").get(0));
	    modelo.setCodtipdescr("LA0002");
	    modelo.setValtipdescri(valores.get("LA0002").get(1));
	    
	    primerComponentePlastico.setCodtipvalor(valores.get("LA0006").get(0));
	    primerComponentePlastico.setCodtipdescr("LA0006");
	    primerComponentePlastico.setValtipdescri(valores.get("LA0006").get(1));
	    
	    primerPorcentajeCompo.setCodtipvalor(valores.get("LA0007").get(0));
	    primerPorcentajeCompo.setCodtipdescr("LA0007");
	    primerPorcentajeCompo.setValtipdescri(valores.get("LA0007").get(1));
	    
	    primerGradoElaboracion.setCodtipvalor(valores.get("LA0003").get(0));
	    primerGradoElaboracion.setCodtipdescr("LA0003");
	    primerGradoElaboracion.setValtipdescri(valores.get("LA0003").get(1));
	    
	    segundoGradoElaboracion.setCodtipvalor(valores.get("LA0004").get(0));
	    segundoGradoElaboracion.setCodtipdescr("LA0004");
	    segundoGradoElaboracion.setValtipdescri(valores.get("LA0004").get(1));
	    
	    gradoElaboracionSoporte.setCodtipvalor(valores.get("LA0015").get(0));
	    gradoElaboracionSoporte.setCodtipdescr("LA0015");
	    gradoElaboracionSoporte.setValtipdescri(valores.get("LA0015").get(1));
	    
	    tipoSoporte.setCodtipvalor(valores.get("LA0010").get(0));
	    tipoSoporte.setCodtipdescr("LA0010");
	    tipoSoporte.setValtipdescri(valores.get("LA0010").get(1));
	    
	    compoTejidoNoTejido.setCodtipvalor(valores.get("LA0011").get(0));
	    compoTejidoNoTejido.setCodtipdescr("LA0011");
	    compoTejidoNoTejido.setValtipdescri(valores.get("LA0011").get(1));
	    
	    porcentajeTejidoNoTejido.setCodtipvalor(valores.get("LA0012").get(0));
	    porcentajeTejidoNoTejido.setCodtipdescr("LA0012");
	    porcentajeTejidoNoTejido.setValtipdescri(valores.get("LA0012").get(1));
	    
	    gramaje.setCodtipvalor(valores.get("LA0020").get(0));
	    gramaje.setCodtipdescr("LA0020");
	    gramaje.setValtipdescri(valores.get("LA0020").get(1));
	    
	    acabado.setCodtipvalor("0");
	    acabado.setCodtipdescr("LA0017");
	    acabado.setValtipdescri("");
	    
	    color.setCodtipvalor(valores.get("LA0016").get(0));
	    color.setCodtipdescr("LA0016");
	    color.setValtipdescri(valores.get("LA0016").get(1));
	    
	    ancho.setCodtipvalor(valores.get("LA0021").get(0));
	    ancho.setCodtipdescr("LA0021");
	    ancho.setValtipdescri(valores.get("LA0021").get(1));
	    
	    lamina.setNumsecitem(1);
	    lamina.setNombreComercial(nombreComercial);
	    lamina.setMarcaComercial(marcaComercial);
		lamina.setModelo(modelo);
		lamina.setPrimerComponentePlastico(primerComponentePlastico);
		lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
		lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
		lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
		lamina.setGradoElaboracion(gradoElaboracionSoporte);
		lamina.setTipoSoporte(tipoSoporte);
		lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
		lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
	    lamina.setGramaje(gramaje);
		lamina.setColor(color);
		lamina.setAncho(ancho);
		lamina.setPlastificante(new DatoDescrMinima());
	    
	    return new Object[][]{{lamina}};
	  }
	  
	  @Test(dataProvider="initOrbis_115")
	  public void validarLaminas115(ModelAbstract lamina) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(lamina, dua).size(),0);
	  }
	  
	  @DataProvider ( name = "initOrbis_116")
	  private Object[][] initOrbis_116() throws Exception{
		  DatoDescrMinima nombreComercial = new DatoDescrMinima();
		  DatoDescrMinima marcaComercial = new DatoDescrMinima();
		  DatoDescrMinima modelo = new DatoDescrMinima();
		  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
		  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
		  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
		  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
		  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
		  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
		  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
		  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
		  DatoDescrMinima color = new DatoDescrMinima();
		  DatoDescrMinima acabado = new DatoDescrMinima();
		  DatoDescrMinima gramaje = new DatoDescrMinima();
		  DatoDescrMinima ancho = new DatoDescrMinima();
		  Lamina lamina = new Lamina();
	    
	    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	    String filename = "src/test/java/xmlLaminas/XML_LAMINA_CP02.xml";
	    valores = getDuaFromXML(filename);
	    
	    
	    nombreComercial.setCodtipvalor(valores.get("LA0000").get(0));
	    nombreComercial.setCodtipdescr("LA0000");
	    nombreComercial.setValtipdescri(valores.get("LA0000").get(1));
	    
	    marcaComercial.setCodtipvalor(valores.get("LA0001").get(0));
	    marcaComercial.setCodtipdescr("LA0001");
	    marcaComercial.setValtipdescri(valores.get("LA0001").get(1));
	    
	    modelo.setCodtipvalor(valores.get("LA0002").get(0));
	    modelo.setCodtipdescr("LA0002");
	    modelo.setValtipdescri(valores.get("LA0002").get(1));
	    
	    primerComponentePlastico.setCodtipvalor(valores.get("LA0006").get(0));
	    primerComponentePlastico.setCodtipdescr("LA0006");
	    primerComponentePlastico.setValtipdescri(valores.get("LA0006").get(1));
	    
	    primerPorcentajeCompo.setCodtipvalor(valores.get("LA0007").get(0));
	    primerPorcentajeCompo.setCodtipdescr("LA0007");
	    primerPorcentajeCompo.setValtipdescri(valores.get("LA0007").get(1));
	    
	    primerGradoElaboracion.setCodtipvalor(valores.get("LA0003").get(0));
	    primerGradoElaboracion.setCodtipdescr("LA0003");
	    primerGradoElaboracion.setValtipdescri(valores.get("LA0003").get(1));
	    
	    segundoGradoElaboracion.setCodtipvalor(valores.get("LA0004").get(0));
	    segundoGradoElaboracion.setCodtipdescr("LA0004");
	    segundoGradoElaboracion.setValtipdescri(valores.get("LA0004").get(1));
	    
	    gradoElaboracionSoporte.setCodtipvalor(valores.get("LA0015").get(0));
	    gradoElaboracionSoporte.setCodtipdescr("LA0015");
	    gradoElaboracionSoporte.setValtipdescri(valores.get("LA0015").get(1));
	    
	    tipoSoporte.setCodtipvalor("0");
	    tipoSoporte.setCodtipdescr("LA0015");
	    tipoSoporte.setValtipdescri("");
	    
	    compoTejidoNoTejido.setCodtipvalor(valores.get("LA0011").get(0));
	    compoTejidoNoTejido.setCodtipdescr("LA0011");
	    compoTejidoNoTejido.setValtipdescri(valores.get("LA0011").get(1));
	    
	    porcentajeTejidoNoTejido.setCodtipvalor(valores.get("LA0012").get(0));
	    porcentajeTejidoNoTejido.setCodtipdescr("LA0012");
	    porcentajeTejidoNoTejido.setValtipdescri(valores.get("LA0012").get(1));
	    
	    gramaje.setCodtipvalor(valores.get("LA0020").get(0));
	    gramaje.setCodtipdescr("LA0020");
	    gramaje.setValtipdescri(valores.get("LA0020").get(1));
	    
	    color.setCodtipvalor(valores.get("LA0016").get(0));
	    color.setCodtipdescr("LA0016");
	    color.setValtipdescri(valores.get("LA0016").get(1));
	    
	    acabado.setCodtipvalor(valores.get("LA0017").get(0));
	    acabado.setCodtipdescr("LA0017");
	    acabado.setValtipdescri(valores.get("LA0017").get(1));
	    
	    ancho.setCodtipvalor(valores.get("LA0021").get(0));
	    ancho.setCodtipdescr("LA0021");
	    ancho.setValtipdescri(valores.get("LA0021").get(1));
	    
	    lamina.setNumsecitem(1);
	    lamina.setNombreComercial(nombreComercial);
	    lamina.setMarcaComercial(marcaComercial);
		lamina.setModelo(modelo);
		lamina.setPrimerComponentePlastico(primerComponentePlastico);
		lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
		lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
		lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
		lamina.setGradoElaboracion(gradoElaboracionSoporte);
		lamina.setAcabado(acabado);
		lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
		lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
		lamina.setTipoSoporte(tipoSoporte);
	    lamina.setGramaje(gramaje);
		lamina.setColor(color);
		lamina.setAncho(ancho);
		lamina.setPlastificante(new DatoDescrMinima());
		
	    return new Object[][]{{lamina}};
	  }
	  
	  @Test(dataProvider="initOrbis_116")
	  public void validarLaminas116(ModelAbstract lamina) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(lamina, dua).size(),1);
	  }
	  
	  @DataProvider ( name = "initOrbis_117")
	  private Object[][] initOrbis_117() throws Exception{
		  DatoDescrMinima nombreComercial = new DatoDescrMinima();
		  DatoDescrMinima marcaComercial = new DatoDescrMinima();
		  DatoDescrMinima modelo = new DatoDescrMinima();
		  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
		  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
		  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
		  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
		  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
		  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
		  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
		  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
		  DatoDescrMinima color = new DatoDescrMinima();
		  DatoDescrMinima acabado = new DatoDescrMinima();
		  DatoDescrMinima gramaje = new DatoDescrMinima();
		  DatoDescrMinima ancho = new DatoDescrMinima();
		  Lamina lamina = new Lamina();
	    
	    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	    String filename = "src/test/java/xmlLaminas/XML_LAMINA_CP03.xml";
	    valores = getDuaFromXML(filename);
	    
	    
	    nombreComercial.setCodtipvalor(valores.get("LA0000").get(0));
	    nombreComercial.setCodtipdescr("LA0000");
	    nombreComercial.setValtipdescri(valores.get("LA0000").get(1));
	    
	    marcaComercial.setCodtipvalor(valores.get("LA0001").get(0));
	    marcaComercial.setCodtipdescr("LA0001");
	    marcaComercial.setValtipdescri(valores.get("LA0001").get(1));
	    
	    modelo.setCodtipvalor(valores.get("LA0002").get(0));
	    modelo.setCodtipdescr("LA0002");
	    modelo.setValtipdescri(valores.get("LA0002").get(1));
	    
	    primerComponentePlastico.setCodtipvalor(valores.get("LA0006").get(0));
	    primerComponentePlastico.setCodtipdescr("LA0006");
	    primerComponentePlastico.setValtipdescri(valores.get("LA0006").get(1));
	    
	    primerPorcentajeCompo.setCodtipvalor(valores.get("LA0007").get(0));
	    primerPorcentajeCompo.setCodtipdescr("LA0007");
	    primerPorcentajeCompo.setValtipdescri(valores.get("LA0007").get(1));
	    
	    primerGradoElaboracion.setCodtipvalor(valores.get("LA0003").get(0));
	    primerGradoElaboracion.setCodtipdescr("LA0003");
	    primerGradoElaboracion.setValtipdescri(valores.get("LA0003").get(1));
	    
	    segundoGradoElaboracion.setCodtipvalor(valores.get("LA0004").get(0));
	    segundoGradoElaboracion.setCodtipdescr("LA0004");
	    segundoGradoElaboracion.setValtipdescri(valores.get("LA0004").get(1));
	    
	    gradoElaboracionSoporte.setCodtipvalor(valores.get("LA0015").get(0));
	    gradoElaboracionSoporte.setCodtipdescr("LA0015");
	    gradoElaboracionSoporte.setValtipdescri(valores.get("LA0015").get(1));
	    
	    tipoSoporte.setCodtipvalor(valores.get("LA0010").get(0));
	    tipoSoporte.setCodtipdescr("LA0010");
	    tipoSoporte.setValtipdescri(valores.get("LA0010").get(1));
	    
	    gramaje.setCodtipvalor(valores.get("LA0020").get(0));
	    gramaje.setCodtipdescr("LA0020");
	    gramaje.setValtipdescri(valores.get("LA0020").get(1));
	    
	    color.setCodtipvalor(valores.get("LA0016").get(0));
	    color.setCodtipdescr("LA0016");
	    color.setValtipdescri(valores.get("LA0016").get(1));
	    
	    acabado.setCodtipvalor(valores.get("LA0017").get(0));
	    acabado.setCodtipdescr("LA0017");
	    acabado.setValtipdescri(valores.get("LA0017").get(1));
	    
	    ancho.setCodtipvalor(valores.get("LA0021").get(0));
	    ancho.setCodtipdescr("LA0021");
	    ancho.setValtipdescri(valores.get("LA0021").get(1));
	    
	    lamina.setNumsecitem(1);
	    lamina.setNombreComercial(nombreComercial);
	    lamina.setMarcaComercial(marcaComercial);
		lamina.setModelo(modelo);
		lamina.setPrimerComponentePlastico(primerComponentePlastico);
		lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
		lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
		lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
		lamina.setGradoElaboracion(gradoElaboracionSoporte);
		lamina.setAcabado(acabado);
		lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
		lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
		lamina.setTipoSoporte(tipoSoporte);
	    lamina.setGramaje(gramaje);
		lamina.setColor(color);
		lamina.setAncho(ancho);
		lamina.setPlastificante(new DatoDescrMinima());
	    
	    return new Object[][]{{lamina}};
	  }
	  
	  @Test(dataProvider="initOrbis_117")
	  public void validarLaminas117(ModelAbstract lamina) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(lamina, dua).size(),0);
	  }
}

