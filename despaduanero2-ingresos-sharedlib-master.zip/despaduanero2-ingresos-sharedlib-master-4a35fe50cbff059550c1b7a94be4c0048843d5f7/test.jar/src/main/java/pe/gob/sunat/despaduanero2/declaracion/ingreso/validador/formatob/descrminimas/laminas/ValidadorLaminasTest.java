package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.laminas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.laminas.model.Lamina;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.test.service.AbstractServiceTest;

/**
 * 
 * @author lalberti
 *
 */
public class ValidadorLaminasTest extends AbstractServiceTest{
	
  @Autowired
  @Qualifier("ValidadorLamina")
  private final ValidadorLamina validador = new ValidadorLamina();
  private final static String CATALOGO = "0";
  private final static String TEXTO    = "1";
	
  @DataProvider (name = "initOrbis_114")
  private Object[][] initOrbis_114(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
	  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
	  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
	  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
	  DatoDescrMinima acabado = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoDescrMinima gramaje = new DatoDescrMinima();
	  DatoDescrMinima ancho = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  Lamina lamina = new Lamina();
	  
	  item.setNumpartnandi(new Long(3921909000L));
	  item.setCodunidcomer("M2");
	  
	  nombreComercial.setCodtipvalor(TEXTO);
	  nombreComercial.setCodtipdescr("LA0000");
	  nombreComercial.setValtipdescri("LONA DE PVC. BANNER");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LA0001");
	  marcaComercial.setValtipdescri("ASAP BANNER");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LA0002");
	  modelo.setValtipdescri("S/M");
	  
	  primerComponentePlastico.setCodtipvalor(CATALOGO);
	  primerComponentePlastico.setCodtipdescr("LA0006");
	  primerComponentePlastico.setValtipdescri("20");
	  
	  primerPorcentajeCompo.setCodtipvalor(TEXTO);
	  primerPorcentajeCompo.setCodtipdescr("LA0007");
	  primerPorcentajeCompo.setValtipdescri("100");
	  
	  primerGradoElaboracion.setCodtipvalor(CATALOGO);
	  primerGradoElaboracion.setCodtipdescr("LA0003");
	  primerGradoElaboracion.setValtipdescri("CSP");
	  
	  segundoGradoElaboracion.setCodtipvalor(CATALOGO);
	  segundoGradoElaboracion.setCodtipdescr("LA0004A");
	  segundoGradoElaboracion.setValtipdescri("COP");
	  
	  tipoSoporte.setCodtipvalor(CATALOGO);
	  tipoSoporte.setCodtipdescr("LA0010");
	  tipoSoporte.setValtipdescri("06");
	  
	  compoTejidoNoTejido.setCodtipdescr(CATALOGO);
	  compoTejidoNoTejido.setCodtipdescr("LA0011");
	  compoTejidoNoTejido.setValtipdescri("16");
	  
	  porcentajeTejidoNoTejido.setCodtipvalor(TEXTO);
	  porcentajeTejidoNoTejido.setCodtipdescr("LA0012");
	  porcentajeTejidoNoTejido.setValtipdescri("100%");
	  
	  gradoElaboracionSoporte.setCodtipvalor(CATALOGO);
	  gradoElaboracionSoporte.setCodtipdescr("LA0015");
	  gradoElaboracionSoporte.setValtipdescri("02");
	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LA0016");
	  color.setValtipdescri("BLA");
	  
	  acabado.setCodtipvalor(CATALOGO);
	  acabado.setCodtipdescr("LA0017");
	  acabado.setValtipdescri("LIS");
	  	  
	  gramaje.setCodtipvalor(TEXTO);
	  gramaje.setCodtipvalor("LA0020");
	  gramaje.setValtipdescri("381");
	  
	  ancho.setCodtipvalor(TEXTO);
	  ancho.setCodtipdescr("LA0021");
	  ancho.setValtipdescri("2.20m");
	  
	  lamina.setNombreComercial(nombreComercial);
	  lamina.setMarcaComercial(marcaComercial);
	  lamina.setModelo(modelo);
	  lamina.setPrimerComponentePlastico(primerComponentePlastico);
	  lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
	  lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
	  lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
	  lamina.setGradoElaboracion(gradoElaboracionSoporte);
	  lamina.setTipoSoporte(tipoSoporte);
	  lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
	  lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
	  lamina.setAcabado(acabado);
	  lamina.setGramaje(gramaje);
	  lamina.setColor(color);
	  lamina.setAncho(ancho);
	  
	  return new Object[][]{{lamina, item}};
  }
	
  @Test (dataProvider = "initOrbis_114")
  public void initOrbis_144TestUnidadComercial(ModelAbstract object,
                                               DatoItem item){
     Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 0);
  }
  
  @Test (dataProvider = "initOrbis_114")
  public void initOrbis_144TestvalidadorPrimerGradoElaboracionProducto
  														(ModelAbstract object,
  														 DatoItem item){
     Assert.assertEquals(validador.validadorGradoElaboracionProducto(object,item).size(), 0);
  }
  
  
  @DataProvider (name = "initOrbis_115")
  private Object[][] initOrbis_115(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
	  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
	  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
	  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
	  DatoDescrMinima acabado = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoDescrMinima gramaje = new DatoDescrMinima();
	  DatoDescrMinima ancho = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  Lamina lamina = new Lamina();
	  
	  item.setNumpartnandi(new Long(3921909000L));
	  item.setCodunidcomer("M2");
	  
	  nombreComercial.setCodtipvalor(TEXTO);
	  nombreComercial.setCodtipdescr("LA0000");
	  nombreComercial.setValtipdescri("BANNER");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LA0001");
	  marcaComercial.setValtipdescri("S/M");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LA0002");
	  modelo.setValtipdescri("S/M");
	  
	  primerComponentePlastico.setCodtipvalor(CATALOGO);
	  primerComponentePlastico.setCodtipdescr("LA0006");
	  primerComponentePlastico.setValtipdescri("20");
	  
	  primerPorcentajeCompo.setCodtipvalor(TEXTO);
	  primerPorcentajeCompo.setCodtipdescr("LA0007");
	  primerPorcentajeCompo.setValtipdescri("100");
	  
	  primerGradoElaboracion.setCodtipvalor(CATALOGO);
	  primerGradoElaboracion.setCodtipdescr("LA0003");
	  primerGradoElaboracion.setValtipdescri("CSP");
	  
	  segundoGradoElaboracion.setCodtipvalor(CATALOGO);
	  segundoGradoElaboracion.setCodtipdescr("LA0004A");
	  segundoGradoElaboracion.setValtipdescri("LAM");
	  
	  tipoSoporte.setCodtipvalor(CATALOGO);
	  tipoSoporte.setCodtipdescr("LA0010");
	  tipoSoporte.setValtipdescri("01");
	  
	  compoTejidoNoTejido.setCodtipdescr(CATALOGO);
	  compoTejidoNoTejido.setCodtipdescr("LA0011");
	  compoTejidoNoTejido.setValtipdescri("16");
	  
	  porcentajeTejidoNoTejido.setCodtipvalor(TEXTO);
	  porcentajeTejidoNoTejido.setCodtipdescr("LA0012");
	  porcentajeTejidoNoTejido.setValtipdescri("100");
	  
	  gradoElaboracionSoporte.setCodtipvalor(CATALOGO);
	  gradoElaboracionSoporte.setCodtipdescr("LA0015");
	  gradoElaboracionSoporte.setValtipdescri("02");
	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LA0016");
	  color.setValtipdescri("BLA");
	  
	  gramaje.setCodtipvalor(TEXTO);
	  gramaje.setCodtipvalor("LA0020");
	  gramaje.setValtipdescri("338");
	  
	  ancho.setCodtipvalor(TEXTO);
	  ancho.setCodtipdescr("LA0021");
	  ancho.setValtipdescri("2.20m");
	  
	  lamina.setNombreComercial(nombreComercial);
	  lamina.setMarcaComercial(marcaComercial);
	  lamina.setModelo(modelo);
	  lamina.setPrimerComponentePlastico(primerComponentePlastico);
	  lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
	  lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
	  lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
	  lamina.setGradoElaboracion(gradoElaboracionSoporte);
	  lamina.setTipoSoporte(tipoSoporte);
	  lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
	  lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);	  
	  lamina.setAcabado(acabado);
	  lamina.setGramaje(gramaje);
	  lamina.setColor(color);
	  lamina.setAncho(ancho);
	  
	  return new Object[][]{{lamina, item}};
  }

  @Test (dataProvider = "initOrbis_115")
  public void initOrbis_115TestUnidadComercial(ModelAbstract object,
                                               DatoItem item){
     Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 0);
  }
  
  @Test (dataProvider = "initOrbis_115")
  public void initOrbis_115TestvalidadorPrimerGradoElaboracionProducto
  														(ModelAbstract object,
  														 DatoItem item){
     Assert.assertEquals(validador.validadorGradoElaboracionProducto(object,item).size(), 0);
  }  
  
  @DataProvider (name = "initOrbis_116")
  private Object[][] initOrbis_116(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
	  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
	  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
	  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
	  DatoDescrMinima acabado = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoDescrMinima gramaje = new DatoDescrMinima();
	  DatoDescrMinima ancho = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  Lamina lamina = new Lamina();
	  
	  item.setNumpartnandi(new Long(3921120000L));
	  item.setCodunidcomer("M2");
	  
	  nombreComercial.setCodtipvalor(TEXTO);
	  nombreComercial.setCodtipdescr("LA0000");
	  nombreComercial.setValtipdescri("Cuerina");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LA0001");
	  marcaComercial.setValtipdescri("S/M");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LA0002");
	  modelo.setValtipdescri("S/M");
	  
	  primerComponentePlastico.setCodtipvalor(CATALOGO);
	  primerComponentePlastico.setCodtipdescr("LA0006");
	  primerComponentePlastico.setValtipdescri("20");
	  
	  primerPorcentajeCompo.setCodtipvalor(TEXTO);
	  primerPorcentajeCompo.setCodtipdescr("LA0007");
	  primerPorcentajeCompo.setValtipdescri("100");
	  
	  primerGradoElaboracion.setCodtipvalor(CATALOGO);
	  primerGradoElaboracion.setCodtipdescr("LA0003");
	  primerGradoElaboracion.setValtipdescri("CSP");
	  
	  segundoGradoElaboracion.setCodtipvalor(CATALOGO);
	  segundoGradoElaboracion.setCodtipdescr("LA0004A");
	  segundoGradoElaboracion.setValtipdescri("CRF");
	  
	  compoTejidoNoTejido.setCodtipdescr(CATALOGO);
	  compoTejidoNoTejido.setCodtipdescr("LA0011");
	  compoTejidoNoTejido.setValtipdescri("16");
	  
	  porcentajeTejidoNoTejido.setCodtipvalor(TEXTO);
	  porcentajeTejidoNoTejido.setCodtipdescr("LA0012");
	  porcentajeTejidoNoTejido.setValtipdescri("100");
	  
	  gradoElaboracionSoporte.setCodtipvalor(CATALOGO);
	  gradoElaboracionSoporte.setCodtipdescr("LA0015");
	  gradoElaboracionSoporte.setValtipdescri("02");
	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LA0016");
	  color.setValtipdescri("BLA");
	  
	  acabado.setCodtipvalor(CATALOGO);
	  acabado.setCodtipdescr("LA0017");
	  acabado.setValtipdescri("RUG");
	  
	  gramaje.setCodtipvalor(TEXTO);
	  gramaje.setCodtipvalor("LA0020");
	  gramaje.setValtipdescri("340");
	  
	  ancho.setCodtipvalor(TEXTO);
	  ancho.setCodtipdescr("LA0021");
	  ancho.setValtipdescri("2.20m");
	  
	  lamina.setNombreComercial(nombreComercial);
	  lamina.setMarcaComercial(marcaComercial);
	  lamina.setModelo(modelo);
	  lamina.setPrimerComponentePlastico(primerComponentePlastico);
	  lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
	  lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
	  lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
	  lamina.setGradoElaboracion(gradoElaboracionSoporte);
	  lamina.setTipoSoporte(tipoSoporte);
	  lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
	  lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
	  lamina.setAcabado(acabado);
	  lamina.setGramaje(gramaje);
	  lamina.setColor(color);
	  lamina.setAncho(ancho);
	  
	  return new Object[][]{{lamina, item}};
  }

  @Test (dataProvider = "initOrbis_116")
  public void initOrbis_116TestUnidadComercial(ModelAbstract object,
                                               DatoItem item){
     Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 0);
  }
  
  @Test (dataProvider = "initOrbis_116")
  public void initOrbis_116TestvalidadorPrimerGradoElaboracionProducto
  														(ModelAbstract object,
  														 DatoItem item){
     Assert.assertEquals(validador.validadorGradoElaboracionProducto(object,item).size(), 1);
  } 
  
  @DataProvider (name = "initOrbis_117")
  private Object[][] initOrbis_117(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
	  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
	  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
	  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
	  DatoDescrMinima acabado = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoDescrMinima gramaje = new DatoDescrMinima();
	  DatoDescrMinima ancho = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  Lamina lamina = new Lamina();
	  
	  item.setNumpartnandi(new Long(3921130000L));
	  item.setCodunidcomer("M");
	  
	  nombreComercial.setCodtipvalor(TEXTO);
	  nombreComercial.setCodtipdescr("LA0000");
	  nombreComercial.setValtipdescri("Cuero Sintético");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LA0001");
	  marcaComercial.setValtipdescri("S/M");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LA0002");
	  modelo.setValtipdescri("S/M");
	  
	  primerComponentePlastico.setCodtipvalor(CATALOGO);
	  primerComponentePlastico.setCodtipdescr("LA0006");
	  primerComponentePlastico.setValtipdescri("18");
	  
	  primerPorcentajeCompo.setCodtipvalor(TEXTO);
	  primerPorcentajeCompo.setCodtipdescr("LA0007");
	  primerPorcentajeCompo.setValtipdescri("100");
	  
	  primerGradoElaboracion.setCodtipvalor(CATALOGO);
	  primerGradoElaboracion.setCodtipdescr("LA0003");
	  primerGradoElaboracion.setValtipdescri("CSP");
	  
	  segundoGradoElaboracion.setCodtipvalor(CATALOGO);
	  segundoGradoElaboracion.setCodtipdescr("LA0004A");
	  segundoGradoElaboracion.setValtipdescri("COP");
	  
	  tipoSoporte.setCodtipvalor(CATALOGO);
	  tipoSoporte.setCodtipdescr("LA0010");
	  tipoSoporte.setValtipdescri("01");
	  	  
	  gradoElaboracionSoporte.setCodtipvalor(CATALOGO);
	  gradoElaboracionSoporte.setCodtipdescr("LA0015");
	  gradoElaboracionSoporte.setValtipdescri("03");
	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LA0016");
	  color.setValtipdescri("AZU");
	  
	  acabado.setCodtipvalor(CATALOGO);
	  acabado.setCodtipdescr("LA0017");
	  acabado.setValtipdescri("RUG");
	  
	  gramaje.setCodtipvalor(TEXTO);
	  gramaje.setCodtipvalor("LA0020");
	  gramaje.setValtipdescri("480");
	  
	  ancho.setCodtipvalor(TEXTO);
	  ancho.setCodtipdescr("LA0021");
	  ancho.setValtipdescri("1.5");
	  
	  lamina.setNombreComercial(nombreComercial);
	  lamina.setMarcaComercial(marcaComercial);
	  lamina.setModelo(modelo);
	  lamina.setPrimerComponentePlastico(primerComponentePlastico);
	  lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
	  lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
	  lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
	  lamina.setGradoElaboracion(gradoElaboracionSoporte);
	  lamina.setTipoSoporte(tipoSoporte);
	  lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
	  lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
	  lamina.setAcabado(acabado);
	  lamina.setGramaje(gramaje);
	  lamina.setColor(color);
	  lamina.setAncho(ancho);
	  
	  return new Object[][]{{lamina, item}};
  }

  @Test (dataProvider = "initOrbis_117")
  public void initOrbis_117TestUnidadComercial(ModelAbstract object,
                                               DatoItem item){
     Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 0);
  }
  
  @Test (dataProvider = "initOrbis_117")
  public void initOrbis_117TestvalidadorPrimerGradoElaboracionProducto
  														(ModelAbstract object,
  														 DatoItem item){
     Assert.assertEquals(validador.validadorGradoElaboracionProducto(object,item).size(), 0);
  } 
    
  @DataProvider (name = "initOrbis_118")
  private Object[][] initOrbis_118(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
	  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
	  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
	  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima segundoCompoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima porcentajeSegundoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
	  DatoDescrMinima acabado = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoDescrMinima gramaje = new DatoDescrMinima();
	  DatoDescrMinima ancho = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  Lamina lamina = new Lamina();
	  
	  item.setNumpartnandi(new Long(3921130000L));
	  item.setCodunidcomer("U");
	  
	  nombreComercial.setCodtipvalor(TEXTO);
	  nombreComercial.setCodtipdescr("LA0000");
	  nombreComercial.setValtipdescri("Material Sintético Laminado");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LA0001");
	  marcaComercial.setValtipdescri("S/M");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LA0002");
	  modelo.setValtipdescri("S/M");
	  
	  primerComponentePlastico.setCodtipvalor(CATALOGO);
	  primerComponentePlastico.setCodtipdescr("LA0006");
	  primerComponentePlastico.setValtipdescri("18");
	  
	  primerPorcentajeCompo.setCodtipvalor(TEXTO);
	  primerPorcentajeCompo.setCodtipdescr("LA0007");
	  primerPorcentajeCompo.setValtipdescri("100");
	  
	  primerGradoElaboracion.setCodtipvalor(CATALOGO);
	  primerGradoElaboracion.setCodtipdescr("LA0003");
	  primerGradoElaboracion.setValtipdescri("CSP");
	  
	  segundoGradoElaboracion.setCodtipvalor(CATALOGO);
	  segundoGradoElaboracion.setCodtipdescr("LA0004A");
	  segundoGradoElaboracion.setValtipdescri("CRF");
	  
	  tipoSoporte.setCodtipvalor(CATALOGO);
	  tipoSoporte.setCodtipdescr("LA0010");
	  tipoSoporte.setValtipdescri("05");
	  	  
	  gradoElaboracionSoporte.setCodtipvalor(CATALOGO);
	  gradoElaboracionSoporte.setCodtipdescr("LA0015");
	  gradoElaboracionSoporte.setValtipdescri("03");
	  
	  compoTejidoNoTejido.setCodtipdescr(CATALOGO);
	  compoTejidoNoTejido.setCodtipdescr("LA0011");
	  compoTejidoNoTejido.setValtipdescri("16");
	  
	  porcentajeTejidoNoTejido.setCodtipvalor(TEXTO);
	  porcentajeTejidoNoTejido.setCodtipdescr("LA0012");
	  porcentajeTejidoNoTejido.setValtipdescri("90");
	  
	  segundoCompoTejidoNoTejido.setCodtipdescr(CATALOGO);
	  segundoCompoTejidoNoTejido.setCodtipdescr("LA0013");
	  segundoCompoTejidoNoTejido.setValtipdescri("15");
	  
	  porcentajeSegundoTejidoNoTejido.setCodtipvalor(TEXTO);
	  porcentajeSegundoTejidoNoTejido.setCodtipdescr("LA0014");
	  porcentajeSegundoTejidoNoTejido.setValtipdescri("10");
	  
	  color.setCodtipvalor(TEXTO);
	  color.setCodtipdescr("LA0016");
	  color.setValtipdescri("VINO");
	  
	  acabado.setCodtipvalor(CATALOGO);
	  acabado.setCodtipdescr("LA0017");
	  acabado.setValtipdescri("AGA");
	  
	  gramaje.setCodtipvalor(TEXTO);
	  gramaje.setCodtipvalor("LA0020");
	  gramaje.setValtipdescri("420");
	  
	  ancho.setCodtipvalor(TEXTO);
	  ancho.setCodtipdescr("LA0021");
	  ancho.setValtipdescri("1.5");
	  
	  lamina.setNombreComercial(nombreComercial);
	  lamina.setMarcaComercial(marcaComercial);
	  lamina.setModelo(modelo);
	  lamina.setPrimerComponentePlastico(primerComponentePlastico);
	  lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
	  lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
	  lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
	  lamina.setGradoElaboracion(gradoElaboracionSoporte);
	  lamina.setTipoSoporte(tipoSoporte);
	  lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
	  lamina.setSegundoCompoTejidoYNoTejido(segundoCompoTejidoNoTejido);
	  lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
	  lamina.setPorcentaje2doCompoTejidoYNoTejido(porcentajeSegundoTejidoNoTejido);
	  lamina.setAcabado(acabado);
	  lamina.setGramaje(gramaje);
	  lamina.setColor(color);
	  lamina.setAncho(ancho);
	  
	  return new Object[][]{{lamina, item}};
  }

  @Test (dataProvider = "initOrbis_118")
  public void initOrbis_118TestUnidadComercial(ModelAbstract object,
                                               DatoItem item){
     Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 1);
  }
  
  @DataProvider (name = "initOrbis_130")
  private Object[][] initOrbis_130(){
	  DatoDescrMinima nombreComercial = new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima primerComponentePlastico = new DatoDescrMinima();
	  DatoDescrMinima primerPorcentajeCompo = new DatoDescrMinima();
	  DatoDescrMinima primerGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima segundoGradoElaboracion = new DatoDescrMinima();
	  DatoDescrMinima tipoSoporte = new DatoDescrMinima();
	  DatoDescrMinima compoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima segundoCompoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima porcentajeTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima porcentajeSegundoTejidoNoTejido = new DatoDescrMinima();
	  DatoDescrMinima gradoElaboracionSoporte = new DatoDescrMinima();
	  DatoDescrMinima acabado = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoDescrMinima gramaje = new DatoDescrMinima();
	  DatoDescrMinima ancho = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  Lamina lamina = new Lamina();
	  
	  item.setNumpartnandi(new Long(3921130000L));
	  item.setCodunidcomer("U");
	  
	  nombreComercial.setCodtipvalor(TEXTO);
	  nombreComercial.setCodtipdescr("LA0000");
	  nombreComercial.setValtipdescri("Material Sintético Laminado");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LA0001");
	  marcaComercial.setValtipdescri("S/M");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LA0002");
	  modelo.setValtipdescri("S/M");
	  
	  primerComponentePlastico.setCodtipvalor(CATALOGO);
	  primerComponentePlastico.setCodtipdescr("LA0006");
	  primerComponentePlastico.setValtipdescri("18");
	  
	  primerPorcentajeCompo.setCodtipvalor(TEXTO);
	  primerPorcentajeCompo.setCodtipdescr("LA0007");
	  primerPorcentajeCompo.setValtipdescri("100");
	  
	  primerGradoElaboracion.setCodtipvalor(CATALOGO);
	  primerGradoElaboracion.setCodtipdescr("LA0003");
	  primerGradoElaboracion.setValtipdescri("CSP");
	  
	  segundoGradoElaboracion.setCodtipvalor(CATALOGO);
	  segundoGradoElaboracion.setCodtipdescr("LA0004A");
	  segundoGradoElaboracion.setValtipdescri("CRF");
	  
	  tipoSoporte.setCodtipvalor(CATALOGO);
	  tipoSoporte.setCodtipdescr("LA0010");
	  tipoSoporte.setValtipdescri("05");
	  	  
	  gradoElaboracionSoporte.setCodtipvalor(CATALOGO);
	  gradoElaboracionSoporte.setCodtipdescr("LA0015");
	  gradoElaboracionSoporte.setValtipdescri("03");
	  
	  compoTejidoNoTejido.setCodtipdescr(CATALOGO);
	  compoTejidoNoTejido.setCodtipdescr("LA0011");
	  compoTejidoNoTejido.setValtipdescri("16");
	  
	  porcentajeTejidoNoTejido.setCodtipvalor(TEXTO);
	  porcentajeTejidoNoTejido.setCodtipdescr("LA0012");
	  porcentajeTejidoNoTejido.setValtipdescri("90");
	  
	  segundoCompoTejidoNoTejido.setCodtipdescr(CATALOGO);
	  segundoCompoTejidoNoTejido.setCodtipdescr("LA0013");
	  segundoCompoTejidoNoTejido.setValtipdescri("15");
	  
	  porcentajeSegundoTejidoNoTejido.setCodtipvalor(TEXTO);
	  porcentajeSegundoTejidoNoTejido.setCodtipdescr("LA0014");
	  porcentajeSegundoTejidoNoTejido.setValtipdescri("10");
	  
	  color.setCodtipvalor(TEXTO);
	  color.setCodtipdescr("LA0016");
	  color.setValtipdescri("VINO");
	  
	  acabado.setCodtipvalor(CATALOGO);
	  acabado.setCodtipdescr("LA0017");
	  acabado.setValtipdescri("AGA");
	  
	  gramaje.setCodtipvalor(TEXTO);
	  gramaje.setCodtipvalor("LA0020");
	  gramaje.setValtipdescri("420");
	  
	  ancho.setCodtipvalor(TEXTO);
	  ancho.setCodtipdescr("LA0021");
	  ancho.setValtipdescri("1.5");
	  
	  lamina.setNombreComercial(nombreComercial);
	  lamina.setMarcaComercial(marcaComercial);
	  lamina.setModelo(modelo);
	  lamina.setPrimerComponentePlastico(primerComponentePlastico);
	  lamina.setPorcentaje1erCompPlastico(primerPorcentajeCompo);
	  lamina.setPrimerGradoElaboracionProducto(primerGradoElaboracion);
	  lamina.setSegundoGradoElaboracionProducto(segundoGradoElaboracion);
	  lamina.setGradoElaboracion(gradoElaboracionSoporte);
	  lamina.setTipoSoporte(tipoSoporte);
	  lamina.setPrimerCompoTejidoYNoTejido(compoTejidoNoTejido);
	  lamina.setSegundoCompoTejidoYNoTejido(segundoCompoTejidoNoTejido);
	  lamina.setPorcentaje1erCompoTejidoYNoTejido(porcentajeTejidoNoTejido);
	  lamina.setPorcentaje2doCompoTejidoYNoTejido(porcentajeSegundoTejidoNoTejido);
	  lamina.setAcabado(acabado);
	  lamina.setGramaje(gramaje);
	  lamina.setColor(color);
	  lamina.setAncho(ancho);
	  
	  return new Object[][]{{lamina, item}};
  }

  @Test (dataProvider = "initOrbis_130")
  public void initOrbis_130TestUnidadComercial(ModelAbstract object,
                                               DatoItem item){
     Assert.assertEquals(validador.validarUnidadComercial(object, item).size(), 1);
  }
  @Test (dataProvider = "initOrbis_118")
  public void initOrbis_118TestvalidadorPrimerGradoElaboracionProducto
  														(ModelAbstract object,
  														 DatoItem item){
     Assert.assertEquals(validador.validadorGradoElaboracionProducto(object,item).size(), 0);
  } 
      
}
