package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.pilas;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.pilas.model.Pila;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorPilaTestIntegration extends AbstractServiceTest {

	 @Autowired
	 @Qualifier("ValidadorPila")
	 private ValidadorPila validador;

	 @Autowired
	 @Qualifier("framework.fabricaDeServicios")
	 private FabricaDeServicios fabricaDeServicios;
	 private static Mensaje               mensaje1001;
	 private static Declaracion           declaracion1001;

	 @Autowired
	 @Qualifier("Ayuda.ayudaServiceCache")
	 private AyudaServiceCache            ayudaServiceCache;

	 private Pila			pila;
	 private Declaracion	declaracion;

	  @BeforeClass
	  public void initData() throws Exception{
	    System.out.println("CARGANDO TEST INTEGRADO (CON XML) ...");

	    assertNotNull(fabricaDeServicios, "No se cargo la fabrica de servicios desde el contexto");
	    String filename = "src/test/java/xmlPilas/XML_PILAS_CP01.xml";
	    String numeroTransaccion = "1001";

	    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

	    Map<String, Object> parametros = null;

	    parametros = new HashMap<String, Object>();
	    parametros.put("numeroTransaccion", numeroTransaccion);
	    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);
	    //Verificar la Existencia de Reglas
	    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
	    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
	    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

	    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);
	    //Verificar que Convirtio el XML a Mensaje
	    assertNotNull(mensaje1001);
	    declaracion1001 = (Declaracion) mensaje1001.getDocumento();

	    // ---------PILAS------------//
	    Integer item_numseitem = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getNumsecitem();
	    Pila pila = new Pila();
	    String codigo, valor;
	    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima>  listaDescripcionMinimas = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getListDecrMinima();
	    for(pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima descripcion : listaDescripcionMinimas){
	      codigo =  descripcion.getCodtipdescr().trim();
	      valor = descripcion.getValtipdescri().trim();
	      Integer codigo_int = Integer.parseInt(codigo.substring(4,6));
	      System.out.println("Descripcion minima  --> " + codigo + " -> " + valor);
	      switch (codigo_int) {
	      
	      case 0:   DatoDescrMinima nombrecomercial = new DatoDescrMinima();
	      nombrecomercial.setValtipdescri(valor);
	      nombrecomercial.setNumsecitem(item_numseitem);
	      pila.setNombreComercial(nombrecomercial);
	      pila.setNumsecitem(item_numseitem);
	        break;
	      case 1:   DatoDescrMinima marcaComercial = new DatoDescrMinima();marcaComercial.setValtipdescri(valor);pila.setMarcaComercial(marcaComercial);break;
	      case 2:   DatoDescrMinima modelo = new DatoDescrMinima();modelo.setValtipdescri(valor);pila.setModelo(modelo);break;
	      case 3:   DatoDescrMinima tipo = new DatoDescrMinima();tipo.setValtipdescri(valor);pila.setTipo(tipo);break;
	      case 4:   DatoDescrMinima formato = new DatoDescrMinima();formato.setValtipdescri(valor);pila.setFormato(formato);break;
	      case 5:   DatoDescrMinima designacion = new DatoDescrMinima();designacion.setValtipdescri(valor);pila.setDesignacion(designacion);break;
	      case 6:   DatoDescrMinima voltaje = new DatoDescrMinima();voltaje.setValtipdescri(valor);pila.setVoltaje(voltaje);break;
	      default:  break;
	      }
	    }

	    this.declaracion = declaracion1001;
		this.pila = pila;
	  }

	 	@Test
	 	public void testValidarUnidadComercial(){
	 		Assert.assertEquals(validador.validarUnidadComercial(pila, declaracion).size(),0);
	 	}
	 	
	 	@Test
	 	public void testValidarNombreComercial(){
	 		Assert.assertEquals(validador.validarNombreComercial(pila).size(),0);
	 	} 	
	 	
	 	@Test
	 	public void testValidarMarcaComercial(){
	 		Assert.assertEquals(validador.validarMarcaComercial(pila).size(),0);
	 	} 	
	 	
	 	@Test
	 	public void testValidarModelo(){
	 		Assert.assertEquals(validador.validarModelo(pila).size(),0);
	 	} 	
	 	
	 	@Test
	 	public void testValidarTipo(){
	 	    String tipo = pila.getTipo().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(tipo,"TA"),true);
	 	  } 	
		
	 	@Test
	 	public void testValidarFormato(){
	 	    String formato = pila.getFormato().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(formato,"TB"),true);
	 	  } 	
		
	 	@Test
	 	public void testValidarDesignacion(){
	 	    String designacion = pila.getDesignacion().getValtipdescri(); 
	 	    Assert.assertEquals(validador.estaEnCatalogo(designacion,"TC"),true);
	 	  }
		
	 	@Test
	 	public void testValidarVoltaje(){
	 		Assert.assertEquals(validador.validarVoltaje(pila).size(),0);
	 	} 	

	 	@Test
	 	public void testValidarCorrelacionTipoYFormaConSubPartida(){
	 		Assert.assertEquals(validador.validarCorrelacionTipoYFormaConSubPartida(pila, declaracion).size(),0);
	 	}	
}