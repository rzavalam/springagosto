package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.domesticos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.domesticos.model.ArticuloDomestico;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorArticuloDomesticoTest extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorArticuloDomestico")
  private ValidadorArticuloDomestico validador;

  private ArticuloDomestico		articuloDomestico;
  private Declaracion			declaracion;

  @BeforeClass
  public void initData() throws Exception{
    System.out.println("LOAD TEST UNITARIOS ...");
    ArticuloDomestico articuloDomestico = new ArticuloDomestico();
    //PesoVolumen
    DatoDescrMinima pesoVolumen = new DatoDescrMinima();
    pesoVolumen.setValtipdescri("99,999.999");  //NO HAY CATALOGO
    articuloDomestico.setPesoVolumen(pesoVolumen);
    //unidadMedidaPesoVolumen
    DatoDescrMinima unidadMedidaPesoVolumen = new DatoDescrMinima();
    unidadMedidaPesoVolumen.setValtipdescri("CIL");  //NO HAY CATALOGO
    articuloDomestico.setUnidadMedidaPesoVolumen(unidadMedidaPesoVolumen);    
    //Presentacion
    DatoDescrMinima presentacion = new DatoDescrMinima();
    presentacion.setValtipdescri("PRESENTACION");  //NO HAY CATALOGO
    articuloDomestico.setModoPresentacion(presentacion);
    //NombreComercial
    DatoDescrMinima nombre = new DatoDescrMinima();
    nombre.setValtipdescri("001"); //001,002,003,004,005...
    articuloDomestico.setNombreComercial(nombre);
    //Marca
    DatoDescrMinima marca = new DatoDescrMinima();
    marca.setValtipdescri("MARCA"); //NO HAY CATALOGO
    articuloDomestico.setMarcaComercial(marca);
    //Modelo
    DatoDescrMinima modelo = new DatoDescrMinima();
    modelo.setValtipdescri("MODELO"); //NO HAY CATALOGO
    articuloDomestico.setModelo(modelo);
    //Composicion
    DatoDescrMinima composicion = new DatoDescrMinima();
    composicion.setValtipdescri("001"); //001,002,003,004,005...
    articuloDomestico.setPrimerComponente(composicion);
    //Acabado
    DatoDescrMinima acabado = new DatoDescrMinima();
    acabado.setValtipdescri("001"); //001,002,003...
    articuloDomestico.setAcabado(acabado);
    //Color
    DatoDescrMinima color = new DatoDescrMinima();
    color.setValtipdescri("001"); //001,002,003...
    articuloDomestico.setColor(color);
    //Accesorio
    DatoDescrMinima accesorio = new DatoDescrMinima();
    accesorio.setValtipdescri("001"); //001,002,003...
    articuloDomestico.setAccesorios(accesorio);
    //UnidadComercial
    Declaracion declaracion = new Declaracion();
    Elementos<DAV> listDAVs = new Elementos<DAV>();
    DAV dav = new DAV();
    Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
    DatoFactura factu = new DatoFactura();
    Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
    DatoItem item = new DatoItem();
    item.setNumsecitem(3);
    item.setCodunidcomer("SET"); 
    lstitem.add(item);
    factu.setListItems(lstitem);
    lstFactu.add(factu);
    dav.setListFacturas(lstFactu);
    listDAVs.add(dav);
    declaracion.setListDAVs(listDAVs);
    articuloDomestico.setNumsecitem(3);
    this.declaracion = declaracion;
    this.articuloDomestico = articuloDomestico;
  }

  @Test
  public void testValidarUnidadComercialUtiles(){
    Assert.assertEquals(validador.validarUnidadComercial(articuloDomestico, declaracion).size(),0);
  }
  @Test
  public void testValidarNombreArticuloDomestico(){
    String nombre = articuloDomestico.getNombreComercial().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(nombre, "473"), true);
  }
  @Test
  public void testValidarComposicionArticulosDomesticos(){
    String composicion = articuloDomestico.getPrimerComponente().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(composicion,"474"),true);
  }
  @Test
  public void testValidarAcabadoArticulosDomesticos(){
    String acabado = articuloDomestico.getAcabado().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(acabado,"475"),true);
  }
  @Test
  public void testValidarColorArticuloDomestico(){
    String color = articuloDomestico.getColor().getValtipdescri();
    Assert.assertEquals(validador.estaEnCatalogo(color,"476"),true);
  }
  @Test
  public void testValidarAccesoriosArticulosDomesticos(){
    String accesorio = articuloDomestico.getAccesorios().getValtipdescri(); 
    Assert.assertEquals(validador.estaEnCatalogo(accesorio,"477"),true);
  }
  @Test
  public void testValidarPresentacionCantidadPiezasArticulosDomesticos(){
    Assert.assertEquals(validador.validarPresentacionCantidadPiezas(articuloDomestico, declaracion).size(),0);
  }
  @Test
  public void testValidarPesoVolumenArticulosDomesticos(){
    Assert.assertEquals(validador.validarPesoVolumen(articuloDomestico).size(),0);
  }
  @Test
  public void testValidarUnidadMedidaPesoVolumen(){
    String UnidadMedidaPesoVolumen = articuloDomestico.getUnidadMedidaPesoVolumen().getValtipdescri(); 
    Assert.assertEquals(validador.estaEnCatalogo(UnidadMedidaPesoVolumen,"29"),true);
  }  
}