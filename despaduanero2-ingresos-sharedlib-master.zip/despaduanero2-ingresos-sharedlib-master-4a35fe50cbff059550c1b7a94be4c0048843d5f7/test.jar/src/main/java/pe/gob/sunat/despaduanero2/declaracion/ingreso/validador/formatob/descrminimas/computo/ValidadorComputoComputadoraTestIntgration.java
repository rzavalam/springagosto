package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoComputadora;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorComputoComputadoraTestIntgration extends AbstractServiceTest{
	  @Autowired
	  @Qualifier("ValidadorComputoComputadora")
	  private ValidadorComputoComputadora validador;

	  @Autowired
	  @Qualifier("framework.fabricaDeServicios")
	  private FabricaDeServicios fabricaDeServicios;

	  @Autowired
	  @Qualifier("Ayuda.ayudaServiceCache")
	  private AyudaServiceCache ayudaServiceCache;
	  private Declaracion dua;

	  private Map<String,List<String>> getDuaFromXML(String filename) throws Exception{
	    Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	    dua = new Declaracion();
	    Mensaje mensaje1001;

	    String numeroTransaccion = "1001";

	    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

	    Map<String, Object> parametros = new HashMap<String, Object>();

	    parametros.put("numeroTransaccion", numeroTransaccion);

	    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);

	    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
	    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
	    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

	    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);

	    assertNotNull(mensaje1001);
	    dua = (Declaracion) mensaje1001.getDocumento();

	    dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();

	    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima> listaDescripcionMinimas =
	        dua.getListDAVs().get(0).getListFacturas().get(0)
	        .getListItems().get(0).getListDecrMinima();

	    for (pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima dato : listaDescripcionMinimas)
	    {
	      List<String> data = new ArrayList<String>();
	      data.add(0, dato.getCodtipvalor());
	      data.add(1,dato.getValtipdescri());
	      valores.put(dato.getCodtipdescr(), data);
	    }
	    return valores;
	  }
	  
	  
	  private Object[][] initData(Map<String,List<String>> valores ){
		  DatoDescrMinima nombreComercial = new DatoDescrMinima();	
		  DatoDescrMinima marcaComercial = new DatoDescrMinima();
		  DatoDescrMinima modelo = new DatoDescrMinima();
		  DatoDescrMinima tipoComputadora = new DatoDescrMinima();
		  DatoDescrMinima tipoProcesador = new DatoDescrMinima();
		  DatoDescrMinima tipoMonitor = new DatoDescrMinima();
		  DatoDescrMinima tipoTeclado = new DatoDescrMinima();
		  DatoDescrMinima velocidadProcesador = new DatoDescrMinima();
		  DatoDescrMinima velocidadLectura = new DatoDescrMinima();
		  DatoDescrMinima velocidadGrabacion = new DatoDescrMinima();
		  DatoDescrMinima capacidadRAM = new DatoDescrMinima();
		  DatoDescrMinima capacidadDiscoDuro = new DatoDescrMinima();
		  DatoDescrMinima tamanoMonitor = new DatoDescrMinima();
		  ComputoComputadora computadora = new ComputoComputadora();
	      computadora.setNumsecitem(1);
		  
	    nombreComercial.setCodtipvalor(valores.get("CO0100").get(0));
	    nombreComercial.setCodtipdescr("CO0100");
	    nombreComercial.setValtipdescri(valores.get("CO0100").get(1));
	    
	    marcaComercial.setCodtipvalor(valores.get("CO0101").get(0));
	    marcaComercial.setCodtipdescr("CO0101");
	    marcaComercial.setValtipdescri(valores.get("CO0101").get(1));
	    
	    modelo.setCodtipvalor(valores.get("CO0102").get(0));
	    modelo.setCodtipdescr("CO0102");
	    modelo.setValtipdescri(valores.get("CO0102").get(1));
	    
	    tipoComputadora.setCodtipvalor(valores.get("CO0103").get(0));
	    tipoComputadora.setCodtipdescr("CO0103");
	    tipoComputadora.setValtipdescri(valores.get("CO0103").get(1));

	    tipoProcesador.setCodtipvalor(valores.get("CO0104").get(0));
	    tipoProcesador.setCodtipdescr("CO0104");
	    tipoProcesador.setValtipdescri(valores.get("CO0104").get(1));

	    tipoMonitor.setCodtipvalor(valores.get("CO0105").get(0));
	    tipoMonitor.setCodtipdescr("CO0105");
	    tipoMonitor.setValtipdescri(valores.get("CO0105").get(1));

	    tipoTeclado.setCodtipvalor(valores.get("CO0106").get(0));
	    tipoTeclado.setCodtipdescr("CO0106");
	    tipoTeclado.setValtipdescri(valores.get("CO0106").get(1));

	    velocidadProcesador.setCodtipvalor(valores.get("CO0107").get(0));
	    velocidadProcesador.setCodtipdescr("CO0107");
	    velocidadProcesador.setValtipdescri(valores.get("CO0107").get(1));

	    velocidadLectura.setCodtipvalor(valores.get("CO0108").get(0));
	    velocidadLectura.setCodtipdescr("CO0108");
	    velocidadLectura.setValtipdescri(valores.get("CO0108").get(1));

	    velocidadGrabacion.setCodtipvalor(valores.get("CO0109").get(0));
	    velocidadGrabacion.setCodtipdescr("CO0109");
	    velocidadGrabacion.setValtipdescri(valores.get("CO0109").get(1));
	    
	    capacidadRAM.setCodtipvalor(valores.get("CO0110").get(0));
	    capacidadRAM.setCodtipdescr("CO0110");
	    capacidadRAM.setValtipdescri(valores.get("CO0110").get(1));
	    
	    capacidadDiscoDuro.setCodtipvalor(valores.get("CO0111").get(0));
	    capacidadDiscoDuro.setCodtipdescr("CO0111");
	    capacidadDiscoDuro.setValtipdescri(valores.get("CO0111").get(1));
	    
	    tamanoMonitor.setCodtipvalor(valores.get("CO0112").get(0));
	    tamanoMonitor.setCodtipdescr("CO0112");
	    tamanoMonitor.setValtipdescri(valores.get("CO0112").get(1));
	    
	    
	    computadora.setNombreComercial(nombreComercial);
		computadora.setMarcaComercial(marcaComercial);
		computadora.setModelo(modelo);
		computadora.setTipoComputadora(tipoComputadora);
		computadora.setTipoProcesador(tipoProcesador);
		computadora.setTipoMonitor(tipoMonitor);
		computadora.setTipoProcesador(tipoProcesador);
		computadora.setTipoMonitor(tipoMonitor);
		computadora.setTipoTeclado(tipoTeclado);
		computadora.setVelocidadProcesador(velocidadProcesador);
		computadora.setVelocidadLectura(velocidadLectura);
		computadora.setVelocidadGrabacion(velocidadGrabacion);
		computadora.setCapacidadRAM(capacidadRAM);
		computadora.setCapacidadDiscoDuro(capacidadDiscoDuro);
		computadora.setTamanoMonitor(tamanoMonitor);
		  	  
		return new Object[][]{{ computadora }};
	  }
	  
	  @DataProvider ( name = "initData126")
	  private Object[][] initData126()  throws Exception{
		  Map<String,List<String>> valores = new HashMap<String,List<String>>();
		  String filename = "src/test/java/xmlComputo/XML_COMPUTADORA_CP00.xml";
		  valores = getDuaFromXML(filename);
		  return initData(valores);
	  }
	  
	  @Test(dataProvider="initData126")
	  public void validarComputadora126(ModelAbstract computadora) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(computadora, dua).size(),0);
	  }
	  
	  
	  @DataProvider ( name = "initData127")
	  private Object[][] initData127()  throws Exception{
		  Map<String,List<String>> valores = new HashMap<String,List<String>>();
		  String filename = "src/test/java/xmlComputo/XML_COMPUTADORA_CP01.xml";
		  valores = getDuaFromXML(filename);
		  return initData(valores);
	  }
	  
	  @Test(dataProvider="initData127")
	  public void validarComputadora127(ModelAbstract computadora) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(computadora, dua).size(),0);
	  }
	  
	  @DataProvider ( name = "initData130")
	  private Object[][] initData130()  throws Exception{
		  Map<String,List<String>> valores = new HashMap<String,List<String>>();
		  String filename = "src/test/java/xmlComputo/XML_COMPUTADORA_CP02.xml";
		  valores = getDuaFromXML(filename);
		  return initData(valores);
	  }
	  
	  @Test(dataProvider="initData130")
	  public void validarComputadora130(ModelAbstract computadora) throws Exception{
	    Assert.assertEquals(validador.ejecutarValidaciones(computadora, dua).size(),0);
	  }
}
