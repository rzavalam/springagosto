package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.fomatob.descrminimas.sanitarios;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.sanitarios.model.SanitarioInodoro;
import pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.sanitarios.ValidadorSanitarioInodoro;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorSanitarioInodoroTestIntegration extends AbstractServiceTest {

  @Autowired
  @Qualifier("ValidadorSanitarioInodoro")
  private ValidadorSanitarioInodoro validador;

  @Autowired
  @Qualifier("framework.fabricaDeServicios")
  private FabricaDeServicios fabricaDeServicios;
  private static Mensaje               mensaje1001;
  private static Declaracion           declaracion1001;

  @Autowired
  @Qualifier("Ayuda.ayudaServiceCache")
  private AyudaServiceCache         ayudaServiceCache;

  private SanitarioInodoro	sanitarioInodoro;

  @BeforeClass
  public void initData() throws Exception{
    System.out.println("CARGANDO TEST INTEGRADO (CON XML) ...");

    assertNotNull(fabricaDeServicios, "No se cargo la fabrica de servicios desde el contexto");
    String filename = "src/test/java/xmlDomesticos/XML_DOMESTICOS_CP01.xml";
    String numeroTransaccion = "1001";

    ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

    Map<String, Object> parametros = null;

    parametros = new HashMap<String, Object>();
    parametros.put("numeroTransaccion", numeroTransaccion);
    List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);
    //Verificar la Existencia de Reglas
    assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
    XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
    xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

    mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);
    //Verificar que Convirtio el XML a Mensaje
    assertNotNull(mensaje1001);
    declaracion1001 = (Declaracion) mensaje1001.getDocumento();

    //---------SANITARIO - INODOROS------------//
    Integer item_numseitem = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getNumsecitem();
    SanitarioInodoro sanitarioInodoro = new SanitarioInodoro();
    String codigo, valor;
    Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima>  listaDescripcionMinimas = declaracion1001.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getListDecrMinima();
    for(pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima descripcion : listaDescripcionMinimas){
      codigo =  descripcion.getCodtipdescr().trim();
      valor = descripcion.getValtipdescri().trim();
      Integer codigo_int = Integer.parseInt(codigo.substring(4,6));
      System.out.println("Descripcion minima  --> " + codigo + " -> " + valor);
      switch (codigo_int) {
      case 0:    DatoDescrMinima nombrecomercial = new DatoDescrMinima();
      nombrecomercial.setValtipdescri(valor);
      nombrecomercial.setNumsecitem(item_numseitem);
      sanitarioInodoro.setNombreComercial(nombrecomercial);
      break;
      case 1:    DatoDescrMinima marcaComercial = new DatoDescrMinima();marcaComercial.setValtipdescri(valor);sanitarioInodoro.setMarcaComercial(marcaComercial);break;
      case 2:    DatoDescrMinima modelo = new DatoDescrMinima();modelo.setValtipdescri(valor);sanitarioInodoro.setModelo(modelo);break;
      case 3:    DatoDescrMinima tipo = new DatoDescrMinima();tipo.setValtipdescri(valor);sanitarioInodoro.setTipo(tipo);break;
      case 4:    DatoDescrMinima aroInodoro = new DatoDescrMinima();aroInodoro.setValtipdescri(valor);sanitarioInodoro.setAroInodoro(aroInodoro);break;
      case 5:    DatoDescrMinima usuario = new DatoDescrMinima();usuario.setValtipdescri(valor);sanitarioInodoro.setUsuario(usuario);break;
      case 6:    DatoDescrMinima accionamiento = new DatoDescrMinima();accionamiento.setValtipdescri(valor);sanitarioInodoro.setAccionamiento(accionamiento);break;
      case 7:    DatoDescrMinima valvula = new DatoDescrMinima();valvula.setValtipdescri(valor);sanitarioInodoro.setValvula(valvula);break;
      case 8:    DatoDescrMinima asiento = new DatoDescrMinima();asiento.setValtipdescri(valor);sanitarioInodoro.setAsiento(asiento);break;
      case 9:    DatoDescrMinima materialAsiento = new DatoDescrMinima();materialAsiento.setValtipdescri(valor);sanitarioInodoro.setMaterialAsiento(materialAsiento);break;
      case 10:   DatoDescrMinima calidad = new DatoDescrMinima();calidad.setValtipdescri(valor);sanitarioInodoro.setCalidad(calidad);break;
      case 11:   DatoDescrMinima colores = new DatoDescrMinima();colores.setValtipdescri(valor);sanitarioInodoro.setColores(colores);break;
      case 12:   DatoDescrMinima material = new DatoDescrMinima();material.setValtipdescri(valor);sanitarioInodoro.setMaterial(material);break;
      case 13:   DatoDescrMinima consumoAgua = new DatoDescrMinima();consumoAgua.setValtipdescri(valor);sanitarioInodoro.setConsumoAgua(consumoAgua);break;
      default:  break;
      }
    }
    this.sanitarioInodoro = sanitarioInodoro;
  }

  @Test
  public void testValidarAroInodoro(){
    System.out.println("Ingreso al Test -testValidarAroInodoro-");
    String aroInodoro = sanitarioInodoro.getAroInodoro().getValtipdescri();
    System.out.println("AroInodoro: " + aroInodoro);
    Assert.assertEquals(validador.estaEnCatalogo(aroInodoro,"427"),true);
  }

  @Test
  public void testValidarUsuario(){
    System.out.println("Ingreso al Test -testValidarUsuario-");
    String usuario = sanitarioInodoro.getUsuario().getValtipdescri();
    System.out.println("Usuario: " + usuario);
    Assert.assertEquals(validador.estaEnCatalogo(usuario,"428"),true);
  }

  @Test
  public void testValidarAccionamiento(){
    System.out.println("Ingreso al Test -testValidarAccionamiento-");
    String accionamiento = sanitarioInodoro.getAccionamiento().getValtipdescri();
    System.out.println("Accionamiento: " + accionamiento);
    Assert.assertEquals(validador.estaEnCatalogo(accionamiento,"429"),true);
  }

  @Test
  public void testValidarAsiento(){
    System.out.println("Ingreso al Test -testValidarAsiento-");
    String asiento = sanitarioInodoro.getAsiento().getValtipdescri();
    System.out.println("Asiento: " + asiento);
    Assert.assertEquals(validador.estaEnCatalogo(asiento,"431"),true);
  }

  @Test
  public void testValidarMaterialAsiento(){
    System.out.println("Ingreso al Test -testValidarMaterialAsiento-");
    String materialAsiento = sanitarioInodoro.getMaterialAsiento().getValtipdescri();
    System.out.println("MaterialAsiento: " + materialAsiento);
    Assert.assertEquals(validador.estaEnCatalogo(materialAsiento,"432"),true);
  }

  @Test
  public void testValidarTipo(){
    System.out.println("Ingreso al Test -testValidarTipo-");
    String nombreComercial = sanitarioInodoro.getNombreComercial().getValtipdescri();
    String tipo = sanitarioInodoro.getTipo().getValtipdescri();
    System.out.println("NombreComercial/Tipo: " + nombreComercial+"/"+tipo);
    Assert.assertEquals(validador.validartipo(sanitarioInodoro).size(),1);
  }

  @Test
  public void testValidarValvula(){
    System.out.println("Ingreso al Test -testValidarValvula-");
    String valvula = sanitarioInodoro.getValvula().getValtipdescri();
    System.out.println("Valvula: " + valvula);
    Assert.assertEquals(validador.validarValvula(sanitarioInodoro).size(),0);
  }

  @Test
  public void testValidarConsumoAgua(){
    System.out.println("Ingreso al Test -testValidarConsumoAgua-");
    String consumoAgua = sanitarioInodoro.getConsumoAgua().getValtipdescri();
    System.out.println("consumoAgua: " + consumoAgua);
    Assert.assertEquals(validador.validarConsumoAgua(sanitarioInodoro).size(),1);
  }
}