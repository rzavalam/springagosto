package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.ayudas.service.AyudaServiceCache;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoDiscoDuro;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.tecnologia.receptor.bean.ReglasConversionBean;
import pe.gob.sunat.tecnologia.receptor.model.Mensaje;
import pe.gob.sunat.tecnologia.receptor.service.ReglaConversionService;
import pe.gob.sunat.tecnologia.receptor.util.xml.XMLConvertirObjetosUtil;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorDiscoDuroTestIntegration extends AbstractServiceTest{
  @Autowired
  @Qualifier("ValidadorComputoDiscoDuro")
  private ValidadorComputoDiscoDuro validador;

  @Autowired
  @Qualifier("framework.fabricaDeServicios")
  private FabricaDeServicios fabricaDeServicios;

  @Autowired
  @Qualifier("Ayuda.ayudaServiceCache")
  private AyudaServiceCache ayudaServiceCache;
  private Declaracion dua;

  private Map<String,List<String>> getDuaFromXML(String filename) throws Exception{
	Map<String,List<String>> valores       = new HashMap<String,List<String>>();
	dua = new Declaracion();
	Mensaje mensaje1001;

	String numeroTransaccion = "1001";

	ReglaConversionService reglaConversionService = fabricaDeServicios.getService("receptor.reglaConversionService");

	Map<String, Object> parametros = new HashMap<String, Object>();

	parametros.put("numeroTransaccion", numeroTransaccion);

	List<ReglasConversionBean> listaReglas = reglaConversionService.obtenerReglasConversion(parametros);

	assertTrue(listaReglas.size() > 0, "No hay reglas de conversion? para la transaccion:"+numeroTransaccion);
	XMLConvertirObjetosUtil xmlConvertirObjetosUtil = new XMLConvertirObjetosUtil();
	xmlConvertirObjetosUtil.setAyudaServiceCache(ayudaServiceCache);

	mensaje1001 = xmlConvertirObjetosUtil.convertir(listaReglas, filename, numeroTransaccion);

	assertNotNull(mensaje1001);
	dua = (Declaracion) mensaje1001.getDocumento();

	dua.getListDAVs().get(0).getListFacturas().get(0).getListItems().get(0).getDescaracteristicas();

	Elementos<pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima> listaDescripcionMinimas =
	        dua.getListDAVs().get(0).getListFacturas().get(0)
	        .getListItems().get(0).getListDecrMinima();

	for (pe.gob.sunat.despaduanero2.declaracion.model.DatoDescrMinima dato : listaDescripcionMinimas)
	{
	  List<String> data = new ArrayList<String>();
	  data.add(0, dato.getCodtipvalor());
	  data.add(1,dato.getValtipdescri());
	  valores.put(dato.getCodtipdescr(), data);
	}
    return valores;
  }
	  
  private Object[][] initData(Map<String,List<String>> valores ){
	DatoDescrMinima nombreComercial = new DatoDescrMinima();	
	DatoDescrMinima marcaComercial = new DatoDescrMinima();
	DatoDescrMinima modelo = new DatoDescrMinima();
	DatoDescrMinima tipoInterface = new DatoDescrMinima();
	DatoDescrMinima velocidadRotacion = new DatoDescrMinima();
	DatoDescrMinima capacidadDiscoDuro = new DatoDescrMinima();
	ComputoDiscoDuro disco= new ComputoDiscoDuro();
	disco.setNumsecitem(1);
			  
	nombreComercial.setCodtipvalor(valores.get("CO0300").get(0));
	nombreComercial.setCodtipdescr("CO0300");
	nombreComercial.setValtipdescri(valores.get("CO0300").get(1));
		    
	marcaComercial.setCodtipvalor(valores.get("CO0301").get(0));
	marcaComercial.setCodtipdescr("CO0301");
	marcaComercial.setValtipdescri(valores.get("CO0301").get(1));
		    
	modelo.setCodtipvalor(valores.get("CO0302").get(0));
	modelo.setCodtipdescr("CO0302");
	modelo.setValtipdescri(valores.get("CO0302").get(1));
		    
	tipoInterface.setCodtipvalor(valores.get("CO0303").get(0));
	tipoInterface.setCodtipdescr("CO0303");
	tipoInterface.setValtipdescri(valores.get("CO0303").get(1));

	velocidadRotacion.setCodtipvalor(valores.get("CO0304").get(0));
	velocidadRotacion.setCodtipdescr("CO0304");
	velocidadRotacion.setValtipdescri(valores.get("CO0304").get(1));

	capacidadDiscoDuro.setCodtipvalor(valores.get("CO0305").get(0));
	capacidadDiscoDuro.setCodtipdescr("CO0305");
	capacidadDiscoDuro.setValtipdescri(valores.get("CO0305").get(1));

	disco.setNombreComercial(nombreComercial);
	disco.setMarcaComercial(marcaComercial);
	disco.setModelo(modelo);
	disco.setTipoInterface(tipoInterface);
	disco.setVelocidadRotacion(velocidadRotacion);
	disco.setCapacidadDiscoDuro(capacidadDiscoDuro);
			  	  
	return new Object[][]{{ disco }};
  }
		  
  @DataProvider ( name = "initData129")
  private Object[][] initData129()  throws Exception{
	Map<String,List<String>> valores = new HashMap<String,List<String>>();
	String filename = "src/test/java/xmlComputo/XML_DISCODURO_CP00.xml";
	valores = getDuaFromXML(filename);
	return initData(valores);
  }
		  
  @Test(dataProvider="initData129")
  public void validarDisco129(ModelAbstract computadora) throws Exception{
	Assert.assertEquals(validador.ejecutarValidaciones(computadora, dua).size(),0);
  }
}
