package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.computo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.computo.model.ComputoDiscoDuro;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DAV;
import pe.gob.sunat.despaduanero2.declaracion.model.DUA;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoFactura;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.despaduanero2.declaracion.model.Declaracion;
import pe.gob.sunat.framework.spring.util.visitor.model.Elementos;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorDiscoDuroTest extends AbstractServiceTest{
	@Autowired
	  @Qualifier("ValidadorComputoDiscoDuro")
	  private ValidadorComputoDiscoDuro validador = new ValidadorComputoDiscoDuro();

	  private final static String TEXTO = "1";
	  private final static String CATALOGO = "0";
		  
	  @DataProvider(name="initData129")
	  private Object[][] initData129(){
		ComputoDiscoDuro disco = new ComputoDiscoDuro();
		Declaracion dua = new Declaracion();
		DatoDescrMinima nombreComercial = new DatoDescrMinima();
		DatoDescrMinima marcaComercial = new DatoDescrMinima();
		DatoDescrMinima modelo = new DatoDescrMinima();
		DatoDescrMinima tipoInterface = new DatoDescrMinima();
		DatoDescrMinima velocidadRotacion = new DatoDescrMinima();
		DatoDescrMinima capacidadDiscoDuro = new DatoDescrMinima();
		DatoItem item = new DatoItem();
		disco.setNumsecitem(1);
		    
		DUA dam = new DUA();
		dam.setNumcorredoc(new Long(1));
		Elementos<DAV> listDAVs = new Elementos<DAV>();

		DAV dav = new DAV();
		dav.setNumcorredoc(new Long(1));
		dav.setNumcodsecprove(new Long(1));

		Elementos<DatoFactura> lstFactu = new Elementos<DatoFactura>();
		DatoFactura factu = new DatoFactura();
		factu.setNumcorredoc(new Long(1));
		factu.setNumfactura("1");
		factu.setNumsecfactu(1);
		factu.setNumsecprove(1);

		Elementos<DatoItem> lstitem = new Elementos<DatoItem>();
		item.setNumcorredoc(new Long(1));
		item.setNumfact("1");
		item.setNumsecitem(1);
		item.setNumsecprove(1);
		item.setCodunidcomer("U");
		item.setNumpartnandi(new Long(8471700000L));
		lstitem.add(item);

		factu.setListItems(lstitem);
		lstFactu.add(factu);
		dav.setListFacturas(lstFactu);
		listDAVs.add(dav);
		dua.setListDAVs(listDAVs);
		dua.setDua(dam);
			    
	    nombreComercial.setCodtipvalor(CATALOGO);
	    nombreComercial.setCodtipdescr("CO0300");
	    nombreComercial.setValtipdescri("DDR");
	    
	    marcaComercial.setCodtipvalor(CATALOGO);
	    marcaComercial.setCodtipdescr("CO0301");
	    marcaComercial.setValtipdescri("SEA");

	    modelo.setCodtipvalor(TEXTO);
		modelo.setCodtipdescr("CO0302");
	    modelo.setValtipdescri("9ZFAAE-570");
		    
	    tipoInterface.setCodtipvalor(CATALOGO);
	    tipoInterface.setCodtipdescr("CO0303");
	    tipoInterface.setValtipdescri("US3");
		    
	    velocidadRotacion.setCodtipvalor(CATALOGO);
	    velocidadRotacion.setCodtipdescr("CO0304");
	    velocidadRotacion.setValtipdescri("540");
		    
	    capacidadDiscoDuro.setCodtipvalor(CATALOGO);
	    capacidadDiscoDuro.setCodtipdescr("CO0305");
	    capacidadDiscoDuro.setValtipdescri("1TB");
	  
		    
	    disco.setNombreComercial(nombreComercial);
	    disco.setMarcaComercial(marcaComercial);
	    disco.setModelo(modelo);
	    disco.setVelocidadRotacion(velocidadRotacion);
	    disco.setCapacidadDiscoDuro(capacidadDiscoDuro);
	    disco.setCapacidadDiscoDuro(capacidadDiscoDuro);
	    
			  
	    return new Object[][]{{ disco, dua }};
	  }
		
	  @Test(dataProvider = "initData129")
	  public void validarNombreComercial129Test(ModelAbstract object, Declaracion dua) throws Exception{
		 Assert.assertEquals(validador.ejecutarValidaciones(object, dua).size(), 0);
	  }
}
