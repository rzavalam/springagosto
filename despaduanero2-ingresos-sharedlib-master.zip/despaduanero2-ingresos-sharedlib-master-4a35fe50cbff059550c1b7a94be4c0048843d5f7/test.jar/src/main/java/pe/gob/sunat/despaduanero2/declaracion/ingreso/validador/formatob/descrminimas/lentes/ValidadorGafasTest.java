package pe.gob.sunat.despaduanero2.declaracion.ingreso.validador.formatob.descrminimas.lentes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pe.gob.sunat.despaduanero2.declaracion.descrminimas.lentes.model.LentesGafa;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.DatoDescrMinima;
import pe.gob.sunat.despaduanero2.declaracion.descrminimas.model.ModelAbstract;
import pe.gob.sunat.despaduanero2.declaracion.model.DatoItem;
import pe.gob.sunat.test.service.AbstractServiceTest;

public class ValidadorGafasTest extends AbstractServiceTest{
	@Autowired
	@Qualifier("ValidadorLentesGafa")
	private ValidadorLentesGafa validador;

	private static final String TEXTO    = "1";
	private static final String CATALOGO = "0";

	
	@DataProvider(name = "initEnlaceAduanero_121")
	public Object[][] initEnlaceAduanero_121(){
	  LentesGafa gafa = new LentesGafa();
	  DatoDescrMinima nombreComercial =  new DatoDescrMinima();
	  DatoDescrMinima marcaComercial = new DatoDescrMinima();
	  DatoDescrMinima modelo = new DatoDescrMinima();
	  DatoDescrMinima materialLente = new DatoDescrMinima();
	  DatoDescrMinima materialMontura = new DatoDescrMinima();
	  DatoDescrMinima color = new DatoDescrMinima();
	  DatoItem item = new DatoItem();
	  
	  item.setNumpartnandi(new Long(9004100000L));
	  
	  nombreComercial.setCodtipvalor(CATALOGO);
	  nombreComercial.setCodtipdescr("LE0200");
	  nombreComercial.setValtipdescri("GFS");
	  
	  marcaComercial.setCodtipvalor(TEXTO);
	  marcaComercial.setCodtipdescr("LE0201");
	  marcaComercial.setValtipdescri("Armani");
	  
	  modelo.setCodtipvalor(TEXTO);
	  modelo.setCodtipdescr("LE0202");
	  modelo.setValtipdescri("01-1514");
	  
	  materialLente.setCodtipvalor(CATALOGO);
	  materialLente.setCodtipdescr("LE0203");
	  materialLente.setValtipdescri("CRT");
	  
	  materialMontura.setCodtipvalor(CATALOGO);
	  materialMontura.setCodtipdescr("LE0204");
	  materialMontura.setValtipdescri("TTN");
	  	  
	  color.setCodtipvalor(CATALOGO);
	  color.setCodtipdescr("LE0210");
	  color.setValtipdescri("NEG");
	  
	  gafa.setNombreComercial(nombreComercial);
	  gafa.setMarcaComercial(marcaComercial);
	  gafa.setModelo(modelo);
	  gafa.setMaterialLente(materialLente);
	  gafa.setMaterialMontura(materialMontura);
	  gafa.setColor(color);
	  gafa.setTipoLente(new DatoDescrMinima());
	  gafa.setTratamiento(new DatoDescrMinima());
	  gafa.setNumeroFocos(new DatoDescrMinima());
	  gafa.setAcabado(new DatoDescrMinima());
	  
	  
	  return new Object[][]{{gafa,item}};
	}
	
	@Test(dataProvider = "initEnlaceAduanero_121")
	  public void testValidarNombreComercial121(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(contacto, item).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_121")
	  public void testValidarMAterial121(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarMaterial(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_121")
	  public void testValidarTipoLente121(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarTipoLente(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_121")
	  public void testValidarNroFocos121(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarNroFocos(contacto).size(),0);
	  }

	@Test(dataProvider = "initEnlaceAduanero_121")
	  public void testValidarColor121(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarColor(contacto).size(),1);
	  }

	@Test(dataProvider = "initEnlaceAduanero_121")
	  public void testValidarTratamiento121(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarTratamiento(contacto).size(),0);
	  }

	@Test(dataProvider = "initEnlaceAduanero_121")
	  public void testValidarAcabado121(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarAcabado(contacto).size(),0);
	  }
	
	@DataProvider(name = "initEnlaceAduanero_124")
	public Object[][] initEnlaceAduanero_124(){
		LentesGafa gafa = new LentesGafa();
		DatoDescrMinima nombreComercial = new DatoDescrMinima();
		DatoDescrMinima marcaComercial = new DatoDescrMinima();
		DatoDescrMinima modelo = new DatoDescrMinima();
		DatoDescrMinima materialLente = new DatoDescrMinima();
		DatoDescrMinima materialMontura = new DatoDescrMinima();
		DatoDescrMinima seriesDeMedida = new DatoDescrMinima();
		DatoDescrMinima tipoLente = new DatoDescrMinima();
		DatoDescrMinima usoLenteContacto = new DatoDescrMinima();
		DatoDescrMinima numeroFocos = new DatoDescrMinima();
		DatoDescrMinima tipoNumeroFocos = new DatoDescrMinima();
		DatoDescrMinima color = new DatoDescrMinima();
		DatoDescrMinima tratamiento = new DatoDescrMinima();
		DatoDescrMinima acabado = new DatoDescrMinima(); 
		
		DatoItem item = new DatoItem();
		item.setNumpartnandi(new Long(9004909000L));
		  
		nombreComercial.setCodtipvalor(CATALOGO);
		nombreComercial.setCodtipdescr("LE0200");
		nombreComercial.setValtipdescri("GFS");
		
		marcaComercial.setCodtipvalor(TEXTO);
		marcaComercial.setCodtipdescr("LE0201");
		marcaComercial.setValtipdescri("CARTIER");
		
		modelo.setCodtipvalor(TEXTO);
		modelo.setCodtipdescr("LE0202");
		modelo.setValtipdescri("T8200782");
		
		materialLente.setCodtipvalor(CATALOGO);
		materialLente.setCodtipdescr("LE0203");
		materialLente.setValtipdescri("RSN");
		
		materialMontura.setCodtipvalor(CATALOGO);
		materialMontura.setCodtipdescr("LE0204");
		materialMontura.setValtipdescri("MET");
		
		color.setCodtipvalor(CATALOGO);
		color.setCodtipdescr("LE0210");
		color.setValtipdescri("BLA");
		
		gafa.setNombreComercial(nombreComercial);
		gafa.setMarcaComercial(marcaComercial);
		gafa.setModelo(modelo);
		gafa.setMaterialLente(materialLente);
		gafa.setMaterialMontura(materialMontura);
		gafa.setSeriesDeMedida(seriesDeMedida);
		gafa.setTipoLente(tipoLente);
		gafa.setUsoLenteContacto(usoLenteContacto);
		gafa.setNumeroFocos(numeroFocos);
		gafa.setTipoNumeroFocos(tipoNumeroFocos);
		gafa.setColor(color);
		gafa.setTratamiento(tratamiento);
		gafa.setAcabado(acabado);
		
		return new Object[][]{{gafa, item}};
	}
	
	@Test(dataProvider = "initEnlaceAduanero_124")
	  public void testValidarNombreComercial124(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarNombreComercial(contacto, item).size(),1);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_124")
	  public void testValidarMaterial124(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarMaterial(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_124")
	  public void testValidarTipoLente124(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarTipoLente(contacto).size(),0);
	  }
	
	@Test(dataProvider = "initEnlaceAduanero_124")
	  public void testValidarNroFocos124(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarNroFocos(contacto).size(),0);
	  }

	@Test(dataProvider = "initEnlaceAduanero_124")
	  public void testValidarColor124(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarColor(contacto).size(),1);
	  }

	@Test(dataProvider = "initEnlaceAduanero_124")
	  public void testValidarTratamiento124(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarTratamiento(contacto).size(),0);
	  }

	@Test(dataProvider = "initEnlaceAduanero_124")
	  public void testValidarAcabado124(ModelAbstract contacto, DatoItem item){
	    Assert.assertEquals(validador.validarAcabado(contacto).size(),0);
	  }
}
