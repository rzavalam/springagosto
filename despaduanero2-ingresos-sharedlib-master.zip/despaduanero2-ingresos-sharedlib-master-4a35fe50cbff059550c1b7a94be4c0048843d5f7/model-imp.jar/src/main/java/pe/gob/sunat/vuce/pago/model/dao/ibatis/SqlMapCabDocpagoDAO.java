package pe.gob.sunat.vuce.pago.model.dao.ibatis;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.vuce.pago.model.CabDocpago;
import pe.gob.sunat.vuce.pago.model.dao.CabDocpagoDAO;

public class SqlMapCabDocpagoDAO extends SqlMapClientDaoSupport implements CabDocpagoDAO {

    public SqlMapCabDocpagoDAO() {
        super();
    }

    public void insert(CabDocpago record) {
        getSqlMapClientTemplate().insert("CabDocpago.insert", record);
    }

    public int updateByPrimaryKey(CabDocpago record) {
        int rows = getSqlMapClientTemplate().update("CabDocpago.updateByPrimaryKey", record);
        return rows;
    }

    public int updateByPrimaryKeySelective(CabDocpago record) {
        int rows = getSqlMapClientTemplate().update("CabDocpago.updateByPrimaryKeySelective", record);
        return rows;
    }

    public CabDocpago selectByPrimaryKey(String indSufijo, String numCda) {
        CabDocpago key = new CabDocpago();
        key.setIndSufijo(indSufijo);
        key.setNumCda(numCda);
        CabDocpago record = (CabDocpago) getSqlMapClientTemplate().queryForObject("CabDocpago.selectByPrimaryKey", key);
        return record;
    }
    
    @SuppressWarnings("unchecked")
	public List<CabDocpago> selectBySelective(CabDocpago key) {
		List<CabDocpago> lista = (List<CabDocpago>) getSqlMapClientTemplate().queryForList("CabDocpago.selectBySelective", key);
		return lista;
	}

}