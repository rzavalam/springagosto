package pe.gob.sunat.despaduanero2.ingreso.vuce.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ItemDocControlMercRestringidaVuce implements Serializable {

	private static final long serialVersionUID = -9057546202459144766L;

	@JsonProperty("numeroCorrelativo")
	private Long numeroCorrelativo;
	@JsonProperty("numeroSecuenciaSerie")
	private Integer numeroSecuenciaSerie;
	@JsonProperty("numeroPartida")
	private Long numeroPartida;
	@JsonProperty("descripcionProducto")
	private String descripcionProducto;
	@JsonProperty("indicadorDelete")
	private String indicadorDelete;


	@JsonProperty("numeroCorrelativo")
	public Long getNumeroCorrelativo() {
		return numeroCorrelativo;
	}

	@JsonProperty("numeroCorrelativo")
	public void setNumeroCorrelativo(Long numeroCorrelativo) {
		this.numeroCorrelativo = numeroCorrelativo;
	}

	@JsonProperty("numeroSecuenciaSerie")
	public Integer getNumeroSecuenciaSerie() {
		return numeroSecuenciaSerie;
	}

	@JsonProperty("numeroSecuenciaSerie")
	public void setNumeroSecuenciaSerie(Integer numeroSecuenciaSerie) {
	this.numeroSecuenciaSerie = numeroSecuenciaSerie;
	}

	@JsonProperty("numeroPartida")
	public Long getNumeroPartida() {
		return numeroPartida;
	}

	@JsonProperty("numeroPartida")
	public void setNumeroPartida(Long numeroPartida) {
		this.numeroPartida = numeroPartida;
	}

	@JsonProperty("descripcionProducto")
	public String getDescripcionProducto() {
		return descripcionProducto;
	}

	@JsonProperty("descripcionProducto")
	public void setDescripcionProducto(String descripcionProducto) {
		this.descripcionProducto = descripcionProducto;
	}

	@JsonProperty("indicadorDelete")
	public String getIndicadorDelete() {
		return indicadorDelete;
	}

	@JsonProperty("indicadorDelete")
	public void setIndicadorDelete(String indicadorDelete) {
		this.indicadorDelete = indicadorDelete;
	}
}
