package pe.gob.sunat.vuce.pago.model;

import java.math.BigDecimal;
import java.util.Date;

public class CabDocpago {
    
    private String indSufijo;

    
    private String numCda;

    
    private String indChequeo;

    
    private String codAduaaso;

    
    private Integer annDeclaso;

    
    private Integer numDeclaso;

    
    private String codRegiaso;

    
    private BigDecimal valMonto;

    
    private String codMoneda;

    
    private String codTdocpag;

    
    private String numDocpag;

    
    private String codEmpracre;

    
    private Date fecPago;

    
    private String codBanco;

    
    private String codTipopago;

    
    private Date fecEmision;

    
    private Date fecIngres;

    
    private Date fecAnul;

    
    private String codMotanul;

    
    private BigDecimal valMontoOrig;

    
    private Date fecRetorno;

    
    private Date fecExtorno;

    
    private Date fecConsulta;

    
    private String codUsuario;

    
    private String codEntidadusu;

    
    private Date fecModif;

    
    private String codUsumodif;

    
    private String indEstado;

    
    private BigDecimal valMontopag;

    
    private String numCheque;

    
    private String codBancocheq;

    
    private String indFlag;

    
    private String numOperacion;

    
    private String codAgente;


	public String getIndSufijo() {
		return indSufijo;
	}


	public void setIndSufijo(String indSufijo) {
		this.indSufijo = indSufijo;
	}


	public String getNumCda() {
		return numCda;
	}


	public void setNumCda(String numCda) {
		this.numCda = numCda;
	}


	public String getIndChequeo() {
		return indChequeo;
	}


	public void setIndChequeo(String indChequeo) {
		this.indChequeo = indChequeo;
	}


	public String getCodAduaaso() {
		return codAduaaso;
	}


	public void setCodAduaaso(String codAduaaso) {
		this.codAduaaso = codAduaaso;
	}


	public Integer getAnnDeclaso() {
		return annDeclaso;
	}


	public void setAnnDeclaso(Integer annDeclaso) {
		this.annDeclaso = annDeclaso;
	}


	public Integer getNumDeclaso() {
		return numDeclaso;
	}


	public void setNumDeclaso(Integer numDeclaso) {
		this.numDeclaso = numDeclaso;
	}


	public String getCodRegiaso() {
		return codRegiaso;
	}


	public void setCodRegiaso(String codRegiaso) {
		this.codRegiaso = codRegiaso;
	}


	public BigDecimal getValMonto() {
		return valMonto;
	}


	public void setValMonto(BigDecimal valMonto) {
		this.valMonto = valMonto;
	}


	public String getCodMoneda() {
		return codMoneda;
	}


	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}


	public String getCodTdocpag() {
		return codTdocpag;
	}


	public void setCodTdocpag(String codTdocpag) {
		this.codTdocpag = codTdocpag;
	}


	public String getNumDocpag() {
		return numDocpag;
	}


	public void setNumDocpag(String numDocpag) {
		this.numDocpag = numDocpag;
	}


	public String getCodEmpracre() {
		return codEmpracre;
	}


	public void setCodEmpracre(String codEmpracre) {
		this.codEmpracre = codEmpracre;
	}


	public Date getFecPago() {
		return fecPago;
	}


	public void setFecPago(Date fecPago) {
		this.fecPago = fecPago;
	}


	public String getCodBanco() {
		return codBanco;
	}


	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}


	public String getCodTipopago() {
		return codTipopago;
	}


	public void setCodTipopago(String codTipopago) {
		this.codTipopago = codTipopago;
	}


	public Date getFecEmision() {
		return fecEmision;
	}


	public void setFecEmision(Date fecEmision) {
		this.fecEmision = fecEmision;
	}


	public Date getFecIngres() {
		return fecIngres;
	}


	public void setFecIngres(Date fecIngres) {
		this.fecIngres = fecIngres;
	}


	public Date getFecAnul() {
		return fecAnul;
	}


	public void setFecAnul(Date fecAnul) {
		this.fecAnul = fecAnul;
	}


	public String getCodMotanul() {
		return codMotanul;
	}


	public void setCodMotanul(String codMotanul) {
		this.codMotanul = codMotanul;
	}


	public BigDecimal getValMontoOrig() {
		return valMontoOrig;
	}


	public void setValMontoOrig(BigDecimal valMontoOrig) {
		this.valMontoOrig = valMontoOrig;
	}


	public Date getFecRetorno() {
		return fecRetorno;
	}


	public void setFecRetorno(Date fecRetorno) {
		this.fecRetorno = fecRetorno;
	}


	public Date getFecExtorno() {
		return fecExtorno;
	}


	public void setFecExtorno(Date fecExtorno) {
		this.fecExtorno = fecExtorno;
	}


	public Date getFecConsulta() {
		return fecConsulta;
	}


	public void setFecConsulta(Date fecConsulta) {
		this.fecConsulta = fecConsulta;
	}


	public String getCodUsuario() {
		return codUsuario;
	}


	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}


	public String getCodEntidadusu() {
		return codEntidadusu;
	}


	public void setCodEntidadusu(String codEntidadusu) {
		this.codEntidadusu = codEntidadusu;
	}


	public Date getFecModif() {
		return fecModif;
	}


	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}


	public String getCodUsumodif() {
		return codUsumodif;
	}


	public void setCodUsumodif(String codUsumodif) {
		this.codUsumodif = codUsumodif;
	}


	public String getIndEstado() {
		return indEstado;
	}


	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}


	public BigDecimal getValMontopag() {
		return valMontopag;
	}


	public void setValMontopag(BigDecimal valMontopag) {
		this.valMontopag = valMontopag;
	}


	public String getNumCheque() {
		return numCheque;
	}


	public void setNumCheque(String numCheque) {
		this.numCheque = numCheque;
	}


	public String getCodBancocheq() {
		return codBancocheq;
	}


	public void setCodBancocheq(String codBancocheq) {
		this.codBancocheq = codBancocheq;
	}


	public String getIndFlag() {
		return indFlag;
	}


	public void setIndFlag(String indFlag) {
		this.indFlag = indFlag;
	}


	public String getNumOperacion() {
		return numOperacion;
	}


	public void setNumOperacion(String numOperacion) {
		this.numOperacion = numOperacion;
	}


	public String getCodAgente() {
		return codAgente;
	}


	public void setCodAgente(String codAgente) {
		this.codAgente = codAgente;
	}

    
}