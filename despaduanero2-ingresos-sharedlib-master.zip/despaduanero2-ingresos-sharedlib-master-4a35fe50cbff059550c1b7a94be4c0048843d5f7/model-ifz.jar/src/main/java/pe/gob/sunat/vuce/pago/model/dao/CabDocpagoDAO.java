package pe.gob.sunat.vuce.pago.model.dao;

import java.util.List;

import pe.gob.sunat.vuce.pago.model.CabDocpago;

public interface CabDocpagoDAO {

    void insert(CabDocpago record);

    int updateByPrimaryKey(CabDocpago record);

    int updateByPrimaryKeySelective(CabDocpago record);

    CabDocpago selectByPrimaryKey(String indSufijo, String numCda);
    
    List<CabDocpago> selectBySelective(CabDocpago record);

}