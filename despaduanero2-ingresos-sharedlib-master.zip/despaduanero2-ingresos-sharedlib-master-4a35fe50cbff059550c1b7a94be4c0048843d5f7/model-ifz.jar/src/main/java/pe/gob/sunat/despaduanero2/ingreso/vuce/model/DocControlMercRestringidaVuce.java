package pe.gob.sunat.despaduanero2.ingreso.vuce.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.*;

import pe.gob.sunat.despaduanero2.ingreso.vuce.bean.DeclaracionVuceBean;
import pe.gob.sunat.despaduanero2.ingreso.vuce.bean.ParticipanteVuceBean;

/**
 * Clase de negocio contenedora de los datos de la mercaciancia restringida 
 * mapeo con la tabla cab_doccontrolmr
 * 
 * @author amancillaa
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"numeroCorrelativo",
"tipoDocumento",
"fechaDocumento",
"estadoDocumento",
"codigoAduana",
"numeroDocumentoControl",
"tipo",
"numeroCUT",
"entidad",
"subEntidad",
"nroEntidadesByCutmayoraUno",
"fechaInicioVigencia",
"fechaFinVigencia",
"lstItems",
"indicadorDelete",
"codAduanaDocumento",
"numSUCEAsociado",
"titularDRVuce",
"subEntidadDesc",
"tipoDocumentoDesc",
"codAduanaDocumentoDesc",
"cutDesc",
"estadoDocumentoDesc",
"nomEspecialista",
"lstSubEntidad"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocControlMercRestringidaVuce implements Serializable{
	
	private static final long serialVersionUID = -6558909507435508282L;

	@JsonProperty("numeroCorrelativo")
	private Long numeroCorrelativo;
	
	@JsonProperty("tipoDocumento")
	private String tipoDocumento;
	
	@JsonProperty("fechaDocumento")
	private Date fechaDocumento;
		
	@JsonProperty("estadoDocumento")
	private String estadoDocumento;
	
	@JsonProperty("codAduanaDocumento")
	private String codAduanaDocumento;
	
	@JsonProperty("numSUCEAsociado")
	private Object numSUCEAsociado;
	
	@JsonProperty("codigoAduana")
	private Object codigoAduana;

	@JsonProperty("numeroDocumentoControl")
	private Integer numeroDocumentoControl;
	
	@JsonProperty("tipo")
	private String tipo;

	@JsonProperty("numeroCUT")
	private Integer numeroCUT;
	
	@JsonProperty("entidad")
	private String entidad;
	
	@JsonProperty("subEntidad")
	private String subEntidad;
	
	@JsonProperty("nroEntidadesByCutmayoraUno")
	private String nroEntidadesByCutmayoraUno;
	
	@JsonProperty("fechaInicioVigencia")
	private Date fechaInicioVigencia;
	
	@JsonProperty("fechaFinVigencia")
	private Date fechaFinVigencia;

    @JsonProperty("lstItems")
	private List<ItemDocControlMercRestringidaVuce> lstItems = new ArrayList<ItemDocControlMercRestringidaVuce>();
	
	@JsonProperty("indicadorDelete")
	private Object indicadorDelete;

    //gg vuce
    @JsonProperty("titularDRVuce")
    private ParticipanteVuceBean titularDRVuce;

    @JsonProperty("subEntidadDesc")
    private String subEntidadDesc;

    @JsonProperty("tipoDocumentoDesc")
    private String tipoDocumentoDesc;

    @JsonProperty("codAduanaDocumentoDesc")
    private String codAduanaDocumentoDesc;

    @JsonProperty("cutDesc")
    private String cutDesc;

	@JsonProperty("estadoDocumentoDesc")
	private String estadoDocumentoDesc;
    
	@JsonProperty("nomEspecialista")
	private Object nomEspecialista;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	//20160818 - mtorralba - Atencion  bug P_SNADE046-2081 - Inicio
    @JsonProperty("lstSubEntidad")
    private List<String> lstSubEntidad;

    public List<String> getLstSubEntidad() {
        return lstSubEntidad;
    }

    public void setLstSubEntidad(List<String> lstSubEntidad) {
        this.lstSubEntidad = lstSubEntidad;
    }
	//20160818 - mtorralba - Atencion  bug P_SNADE046-2081 - Fin
	
    //region amancillaa VUCE-RIN04
    @JsonProperty("lstArchivosAnexos")
    private List<ArchivoAnexoDocControlMR> lstArchivosAnexos;

    public List<ArchivoAnexoDocControlMR> getLstArchivosAnexos() {
        return lstArchivosAnexos;
    }

    public void setLstArchivosAnexos(List<ArchivoAnexoDocControlMR> lstArchivosAnexos) {
        this.lstArchivosAnexos = lstArchivosAnexos;
    }
      //endregion amancillaa

    @JsonProperty("lstDeclaracionesAsociadas")
    public List<DeclaracionVuceBean> getLstDeclaracionesAsociadas() {
        return lstDeclaracionesAsociadas;
    }

    public void setLstDeclaracionesAsociadas(List<DeclaracionVuceBean> lstDeclaracionesAsociadas) {
        this.lstDeclaracionesAsociadas = lstDeclaracionesAsociadas;
    }

    private List<DeclaracionVuceBean> lstDeclaracionesAsociadas;

    public DocControlMercRestringidaVuce() {
        super();
        lstItems = new ArrayList<ItemDocControlMercRestringidaVuce>();
    }

    /*Setters and getters*/
    @JsonProperty("numeroCorrelativo")
    public Long getNumeroCorrelativo() {
        return numeroCorrelativo;
    }

    @JsonProperty("numeroCorrelativo")
    public void setNumeroCorrelativo(Long numeroCorrelativo) {
        this.numeroCorrelativo = numeroCorrelativo;
    }

    @JsonProperty("tipoDocumento")
    public String getTipoDocumento() {
        return tipoDocumento;
    }

    @JsonProperty("tipoDocumento")
    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    @JsonProperty("fechaDocumento")
    public Date getFechaDocumento() {
        return fechaDocumento;
    }

    @JsonProperty("fechaDocumento")
    public void setFechaDocumento(Date fechaDocumento) {
        this.fechaDocumento = fechaDocumento;
    }

    @JsonProperty("estadoDocumento")
    public String getEstadoDocumento() {
        return estadoDocumento;
    }

    @JsonProperty("estadoDocumento")
    public void setEstadoDocumento(String estadoDocumento) {
        this.estadoDocumento = estadoDocumento;
    }

    @JsonProperty("codAduanaDocumento")
    public Object getcodAduanaDocumento() {
        return codAduanaDocumento;
    }

    @JsonProperty("codAduanaDocumento")
    public void setcodAduanaDocumento(String codAduanaDocumento) {
        this.codAduanaDocumento = codAduanaDocumento;
    }

    @JsonProperty("numSUCEAsociado")
    public Object getnumSUCEAsociado() {
        return numSUCEAsociado;
    }

    @JsonProperty("numSUCEAsociado")
    public void numSUCEAsociado(Object numSUCEAsociado) {
        this.numSUCEAsociado = numSUCEAsociado;
    }

    @JsonProperty("numeroDocumentoControl")
    public Integer getNumeroDocumentoControl() {
        return numeroDocumentoControl;
    }

    @JsonProperty("numeroDocumentoControl")
    public void setNumeroDocumentoControl(Integer numeroDocumentoControl) {
        this.numeroDocumentoControl = numeroDocumentoControl;
    }

    @JsonProperty("tipo")
    public String getTipo() {
        return tipo;
    }

    @JsonProperty("tipo")
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @JsonProperty("numeroCUT")
    public Integer getNumeroCUT() {
        return numeroCUT;
    }

    @JsonProperty("numeroCUT")
    public void setNumeroCUT(Integer numeroCUT) {
        this.numeroCUT = numeroCUT;
    }

    @JsonProperty("entidad")
    public String getEntidad() {
        return entidad;
    }

    @JsonProperty("entidad")
    public void setEntidad(String entidad) {
        this.entidad = entidad;
    }

    @JsonProperty("subEntidad")
    public String getSubEntidad() {
        return subEntidad;
    }

    @JsonProperty("nroEntidadesByCutmayoraUno")
    public void setNroEntidadesByCutmayoraUno(String nroEntidadesByCutmayoraUno) {
        this.nroEntidadesByCutmayoraUno = nroEntidadesByCutmayoraUno;
    }

    @JsonProperty("nroEntidadesByCutmayoraUno")
    public String getNroEntidadesByCutmayoraUno() {
        return nroEntidadesByCutmayoraUno;
    }

    @JsonProperty("subEntidad")
    public void setSubEntidad(String subEntidad) {
        this.subEntidad = subEntidad;
    }

    @JsonProperty("fechaInicioVigencia")
    public Date getFechaInicioVigencia() {
        return fechaInicioVigencia;
    }

    @JsonProperty("fechaInicioVigencia")
    public void setFechaInicioVigencia(Date fechaInicioVigencia) {
        this.fechaInicioVigencia = fechaInicioVigencia;
    }

    @JsonProperty("fechaFinVigencia")
    public Date getFechaFinVigencia() {
        return fechaFinVigencia;
    }

    @JsonProperty("fechaFinVigencia")
    public void setFechaFinVigencia(Date fechaFinVigencia) {
        this.fechaFinVigencia = fechaFinVigencia;
    }

    @JsonProperty("indicadorDelete")
    public Object getIndicadorDelete() {
        return indicadorDelete;
    }

    @JsonProperty("indicadorDelete")
    public void setIndicadorDelete(Object indicadorDelete) {
        this.indicadorDelete = indicadorDelete;
    }

    @JsonProperty("nomEspecialista")
    public Object getNomEspecialista() {
        return nomEspecialista;
    }

    @JsonProperty("nomEspecialista")
    public void setNomEspecialista(Object nomEspecialista) {
        this.nomEspecialista = nomEspecialista;
    }

	public String getCodAduanaDocumento() {
		return codAduanaDocumento;
	}

	public void setCodAduanaDocumento(String codAduanaDocumento) {
		this.codAduanaDocumento = codAduanaDocumento;
	}
	
	public Object getNumSUCEAsociado() {
		return numSUCEAsociado;
	}

	public void setNumSUCEAsociado(Object numSUCEAsociado) {
		this.numSUCEAsociado = numSUCEAsociado;
	}
	
	public Object getCodigoAduana() {
		return codAduanaDocumento;
	}

	public void setCodigoAduana(Object codigoAduana) {
		this.codigoAduana = codigoAduana;
	}

    //gg vuce
    public List<ItemDocControlMercRestringidaVuce> getLstItems() {
        return lstItems;
    }

    public void setLstItems(List<ItemDocControlMercRestringidaVuce> lstItems) {
        this.lstItems = lstItems;
    }

    public String getSubEntidadDesc() {
        return subEntidadDesc;
    }

    public void setSubEntidadDesc(String subEntidadDesc) {
        this.subEntidadDesc = subEntidadDesc;
    }

    public String getTipoDocumentoDesc() {
        return tipoDocumentoDesc;
    }

    public void setTipoDocumentoDesc(String tipoDocumentoDesc) {
        this.tipoDocumentoDesc = tipoDocumentoDesc;
    }

    public String getCodAduanaDocumentoDesc() {
        return codAduanaDocumentoDesc;
    }

    public void setCodAduanaDocumentoDesc(String codAduanaDocumentoDesc) {
        this.codAduanaDocumentoDesc = codAduanaDocumentoDesc;
    }

    public String getCutDesc() {
        return cutDesc;
    }

    public void setCutDesc(String cutDesc) {
        this.cutDesc = cutDesc;
    }

    public String getEstadoDocumentoDesc() {
        return estadoDocumentoDesc;
    }

    public void setEstadoDocumentoDesc(String estadoDocumentoDesc) {
        this.estadoDocumentoDesc = estadoDocumentoDesc;
    }

    @JsonProperty("titularDRVuce")
    public ParticipanteVuceBean getTitularDRVuce() {
        return titularDRVuce;
    }

    @JsonProperty("titularDRVuce")
    public void setTitularDRVuce(ParticipanteVuceBean titularDRVuce) {
        this.titularDRVuce = titularDRVuce;
    }
}