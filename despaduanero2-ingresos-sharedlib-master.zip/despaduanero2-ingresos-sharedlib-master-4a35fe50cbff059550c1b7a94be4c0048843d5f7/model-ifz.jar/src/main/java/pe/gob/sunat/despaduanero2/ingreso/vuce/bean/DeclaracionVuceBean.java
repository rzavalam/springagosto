package pe.gob.sunat.despaduanero2.ingreso.vuce.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

/**
 * Created by ggranados on 25/11/2016.
 */
public class DeclaracionVuceBean implements Serializable{

    @JsonProperty("numCorredoc")
    private Long numCorredoc;
    @JsonProperty("codRegimen")
    private String codRegimen;
    @JsonProperty("codAduana")
    private String codAduana;
    @JsonProperty("annPresen")
    private Long annPresen;
    @JsonProperty("numDeclaracion")
    private Long numDeclaracion;

    public Long getNumCorredoc() {
        return numCorredoc;
    }

    public void setNumCorredoc(Long numCorredoc) {
        this.numCorredoc = numCorredoc;
    }

    public String getCodRegimen() {
        return codRegimen;
    }

    public void setCodRegimen(String codRegimen) {
        this.codRegimen = codRegimen;
    }

    public String getCodAduana() {
        return codAduana;
    }

    public void setCodAduana(String codAduana) {
        this.codAduana = codAduana;
    }

    public Long getAnnPresen() {
        return annPresen;
    }

    public void setAnnPresen(Long annPresen) {
        this.annPresen = annPresen;
    }

    public Long getNumDeclaracion() {
        return numDeclaracion;
    }

    public void setNumDeclaracion(Long numDeclaracion) {
        this.numDeclaracion = numDeclaracion;
    }
}
