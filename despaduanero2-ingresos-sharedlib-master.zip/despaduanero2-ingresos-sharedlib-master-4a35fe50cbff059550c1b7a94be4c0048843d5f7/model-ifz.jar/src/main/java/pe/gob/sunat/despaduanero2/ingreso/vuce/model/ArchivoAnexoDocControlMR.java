package pe.gob.sunat.despaduanero2.ingreso.vuce.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

/**
 * Created by amancillaa on 15/07/2016.
 */
public class ArchivoAnexoDocControlMR implements Serializable {

    private static final long serialVersionUID = 72815874122L;

    @JsonProperty("numeroCorrelativo")
    private Long numeroCorrelativo;

    @JsonProperty("numeroSecuenciaDocAdjunto")
    private Long numeroSecuenciaDocAdjunto;

    @JsonProperty("codigoIdDocAdjunto")
    private String codigoIdDocAdjunto;

    @JsonProperty("nombreDocAdjunto")
    private String nombreDocAdjunto;

    @JsonProperty("archivoDocAdjunto")
    private byte [] archivoDocAdjunto;

    @JsonProperty("indicadorActivo")
    private String  indicadorActivo;

    /******************** CONSTRUCTORES *********************************/


    /**
     * Constructor necesita ibatis
     */
    public ArchivoAnexoDocControlMR() {
        super();

    }


    /******************** SET AND GET *********************************/


    public String getCodigoIdDocAdjunto() {
        return codigoIdDocAdjunto;
    }

    public void setCodigoIdDocAdjunto(String codigoIdDocAdjunto) {
        this.codigoIdDocAdjunto = codigoIdDocAdjunto;
    }

    public byte[] getArchivoDocAdjunto() {
        return archivoDocAdjunto;
    }

    public void setArchivoDocAdjunto(byte[] archivoDocAdjunto) {

        this.archivoDocAdjunto = archivoDocAdjunto;
    }

    public Long getNumeroCorrelativo() {
        return numeroCorrelativo;
    }

    public void setNumeroCorrelativo(Long numeroCorrelativo) {
        this.numeroCorrelativo = numeroCorrelativo;
    }

    public Long getNumeroSecuenciaDocAdjunto() {
        return numeroSecuenciaDocAdjunto;
    }

    public void setNumeroSecuenciaDocAdjunto(Long numeroSecuenciaDocAdjunto) {
        this.numeroSecuenciaDocAdjunto = numeroSecuenciaDocAdjunto;
    }



    public String getNombreDocAdjunto() {
        return nombreDocAdjunto;
    }

    public void setNombreDocAdjunto(String nombreDocAdjunto) {
        this.nombreDocAdjunto = nombreDocAdjunto;
    }



    public String getIndicadorActivo() {
        return indicadorActivo;
    }

    public void setIndicadorActivo(String indicadorActivo) {
        this.indicadorActivo = indicadorActivo;
    }

}
