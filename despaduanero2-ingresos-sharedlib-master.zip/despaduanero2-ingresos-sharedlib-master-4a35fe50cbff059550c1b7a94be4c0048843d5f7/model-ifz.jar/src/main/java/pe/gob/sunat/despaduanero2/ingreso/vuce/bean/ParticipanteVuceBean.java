package pe.gob.sunat.despaduanero2.ingreso.vuce.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.Generated;
import java.io.Serializable;

/**
 * Created by ggranados on 09/06/2016.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
        "tipoDocumento",
        "numeroDocumento",
        "razonSocial",
        "tipoDocumentoDesc","secuenciaDeParticipantes"
})
public class ParticipanteVuceBean implements Serializable {

    @JsonProperty("tipoDocumento")
    private String tipoDocumento;
    @JsonProperty("numeroDocumento")
    private String numeroDocumento;
    @JsonProperty("razonSocial")
    private String razonSocial;
    @JsonProperty("tipoDocumentoDesc")
    private String tipoDocumentoDesc;
    @JsonProperty("secuenciaDeParticipantes")
	private Long secuenciaDeParticipantes; 

    public ParticipanteVuceBean(){
		super();
    }

    public ParticipanteVuceBean(String tipoDoc, String numDoc, String razonSocial,
                                String tipoDocumentoDesc) {
        this.tipoDocumento = tipoDoc;
        this.numeroDocumento = numDoc;
        this.razonSocial = razonSocial;
        this.tipoDocumentoDesc = tipoDocumentoDesc;
    }

    @JsonProperty("tipoDocumento")
    public String getTipoDocumento() {
        return tipoDocumento;
    }

    @JsonProperty("tipoDocumento")
    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    @JsonProperty("numeroDocumento")
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    @JsonProperty("numeroDocumento")
    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    @JsonProperty("razonSocial")
    public String getRazonSocial() {
        return razonSocial;
    }

    @JsonProperty("razonSocial")
    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    @JsonProperty("tipoDocumentoDesc")
    public String getTipoDocumentoDesc() {
        return tipoDocumentoDesc;
    }

    @JsonProperty("tipoDocumentoDesc")
    public void setTipoDocumentoDesc(String tipoDocumentoDesc) {
        this.tipoDocumentoDesc = tipoDocumentoDesc;
    }

@JsonProperty("secuenciaDeParticipantes")
	public Long getSecuenciaDeParticipantes() {
		return secuenciaDeParticipantes;
	}

@JsonProperty("secuenciaDeParticipantes")
	public void setSecuenciaDeParticipantes(Long secuenciaDeParticipantes) {
		this.secuenciaDeParticipantes = secuenciaDeParticipantes;
	}
}